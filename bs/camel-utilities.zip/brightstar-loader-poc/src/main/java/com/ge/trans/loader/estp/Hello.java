package com.ge.trans.loader.estp;

/**
 * An interface for implementing Hello services.
 */
public interface Hello {

    String hello();
	
}
