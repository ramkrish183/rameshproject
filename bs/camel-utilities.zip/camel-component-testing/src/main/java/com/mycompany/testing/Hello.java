package com.mycompany.testing;

/**
 * An interface for implementing Hello services.
 */
public interface Hello {

    String hello();
	
}
