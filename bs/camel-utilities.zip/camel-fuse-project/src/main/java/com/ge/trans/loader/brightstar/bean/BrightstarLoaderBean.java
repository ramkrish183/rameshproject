package com.ge.trans.loader.brightstar.bean;

import org.apache.camel.Exchange;

import com.ge.trans.loader.brightstar.model.KazakDataFile;

public class BrightstarLoaderBean {

	public static KazakDataFile kazakDataFile;
	public void validateExchange(Exchange ex){
		
		try {
			System.out.println("object---->"+(Object)ex.getIn().getBody());
			
			
			System.out.println("kazak data file"+getKazakDataFile());
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	public static KazakDataFile getKazakDataFile() {
		return kazakDataFile;
	}
	public static void setKazakDataFile(KazakDataFile kazakDataFile) {
		BrightstarLoaderBean.kazakDataFile = kazakDataFile;
	}
	
	
}
