//package com.ge.trans.loader.test;
//
//import org.apache.camel.test.blueprint.CamelBlueprintTestSupport;
//import org.junit.Test;
//
//public class MyRouteTest extends CamelBlueprintTestSupport {
//
//	@Override
//	protected String getBlueprintDescriptor() {
//		return "OSGI-INF/blueprint/blueprint.xml";
//	}
//
//	@Test
//	public void testMyRoute() throws Exception {
//
//	/*	// mocking the file endpoint and define the expectation
//		MockEndpoint mockEndpoint = getMockEndpoint("mock:file:camel-output");
//		mockEndpoint.expectedMessageCount(1);
//		mockEndpoint.expectedBodiesReceived("Echoing Hello Blog");
//*/
//		// send a message at the timer endpoint level
//		template.sendBody("direct:fireSql", "empty");
//		
//		// check if the expectation is satisfied
////		assertMockEndpointsSatisfied();
//	}
//
//}