package com.ge.trans.loader;

/**
 * An interface for implementing Hello services.
 */
public interface Hello {

    String hello();
	
}
