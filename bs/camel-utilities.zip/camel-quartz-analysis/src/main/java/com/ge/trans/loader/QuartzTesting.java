package com.ge.trans.loader;

/**
 * @author 502166888
 *
 */
public class QuartzTesting {

  
  /**
   * 
   */
  public void testCamelQuartz(String body) {
    // TODO Auto-generated method stub
    System.out.println("testing camel quartz"+body);
  }
}
