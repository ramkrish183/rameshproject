package com.ge.trans.loader.manual.common.data.response;

import java.math.BigDecimal;

public enum MPDataType {

	HEX(0), ASCII(1), FLOAT(2), INTEGER(3), DECIMAL(4), FLOAT2HEX(5), UNKNOWN(-1);

	private final BigDecimal dataType;

	private MPDataType(int dataType) {
		this.dataType = BigDecimal.valueOf(dataType);
	}

	public BigDecimal getDataType() {
		return dataType;
	}

}
