package com.ge.trans.loader.manual.common.enums;

/**
 * @author 502166888
 *
 */
public enum ManualLoaderError {

  VEHICLE_NOT_FOUND_EXCEPTION(1100001, "Vehicle Not Found Exception"),
  EXCEPTION_WHILE_FINDING_BS_PARAMS(1100002, "Error while finding BS Eng Params"),
  NO_BS_PARAMS_FOUND_EXCEPTION(1100003, "Brightstar Engineering params are not found in Database"),
  EXCEPTION_WHILE_UPDATING_TOOLRUNNEXT_COLUMN(1100004, "Exception while updating tool_run_next column in GETS_RMD_VEHICLE table "),
  EXCEPTION_WHILE_FINDING_FAULTCODEDESCRIPTION(1100005, "Exception while finding Fault Code Description"),
  EXCEPTION_WHILE_FINDING_VEHICLE_DETAILS(1100006, "Exception while finding Vehicle Details"),
  EXCEPTION_WHILE_PARSING_FAULT_DATA(1100007, "Exception while Parsing Fault Data"),
  EXCEPTION_WHILE_PARSING_MP_DATA(1100008, "Exception while Parsing MP Data"),
  EXCEPTION_WHILE_PARSING_STATISTICS_DATA(1100009, "Exception while Parsing Statistics Data "),
  EXCEPTION_WHILE_PARSING_TEXT_DATA(1100010, "Exception while Parsing Text Data "),
  EXCEPTION_WHILE_LOADING_KTZ_MESSAGE_DEFINITION(1100011, "Exception while Loading KTZ Message definition "),
  FILE_LIST_EMPTY_EXCEPTION(1100012, "No data to parse as file List is empty "),
  ESERVICES_RESPONSE_FAILURE_EXCEPTION(1100013, "Eservices Response Failure Exception "),
  INVALID_CUSTOMER_ID(1100014, "Invalid Customer Id "),
  INVALID_VEHICLE_NUMBER(1100015, "Invalid Vehicle Number "),
  INVALID_CABCAXTIME(1100016, "Invalid CabCaxTime "),
  NO_INCIDENT_SNAPSHOT_DATA(1100017, "Not Enough Data to Parse Incident or Snapshot data "),
  INVALID_FIRST_LINE(1100018, "Unable to parse first line of the Input File "),
  BS_ENGINEERING_PARMS_EMPTY(1100019, "BrightStar Engineering Params are empty in the File"),

  EXCEPTION_WHILE_LOADING_INC_SNP_DATA(1100020, "Exception while loading Incident or Snapshot Data "),
  INVALID_FILE_TYPE(1100021, "Invalid Bright Star Loader File Type : "),
  EXCEPTION_WHILE_CONVERTING_BS_FIELDS(1100022, "Error While applying transformation logic on Bright Star Message Fields"),
  EMPTY_INPUT_DATE(1100023, "Empty Input Date Field : "),
  EXCEPTION_WHILE_PARSING_INPUT_DATE(1100024, "Exception occured while parsing Input Date "),
  EXCEPTION_WHILE_PARSING_RESET_DATE(1100025, "Exception occured while parsing Reset Date : "),
  EXCEPTION_WHILE_PREPARING_JSON_REQUEST_FOR_ESERVICES(1100026, "Error in preparing JSON request : "),
  EXCEPTION_WHILE_SETTING_PARSED_VALUES(1100027, "Error while setting parsed BS fields "),
  EXCEPTION_WHILE_PREPARING_ESERVICES_FAULT_DATA(1100028, "Error while preparing eServices Fault Request :"),
  EXCEPTION_IN_MAPPING_JSON_OBJECT(1100029, "Error in mapping JSON to object :"),
  NOT_AN_ELIGIBLE_ROUTES_TO_START(1100030, "Not An eligible routes to start"),
  FAULT_CODE_IS_EMPTY(1100031, "Faultcode is empty"),
  // NOTE: 6060102 is reserved for Invalid Fault Codes
  // If this error code/message is thrown, then Loader-common would send email's to configured Users, i.e., GAMS
  INVALID_FAULT_CODES(6060102, "Unable to find FaultCode information for Fault Code : ");

  private final int errorCode;
  private final String errorDesc;

  /**
   * @param errorCode
   * @param errorDesc
   */
  private ManualLoaderError(int errorCode, String errorDesc) {
    this.errorCode = errorCode;
    this.errorDesc = errorDesc;
  }

  /**
   * @return the errorCode
   */
  public int getErrorCode() {
    return errorCode;
  }

  /**
   * @return the errorDesc
   */
  public String getErrorDesc() {
    return errorDesc;
  }

}
