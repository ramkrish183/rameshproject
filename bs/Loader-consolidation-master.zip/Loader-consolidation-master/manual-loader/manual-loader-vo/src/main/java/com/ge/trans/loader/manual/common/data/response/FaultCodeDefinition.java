package com.ge.trans.loader.manual.common.data.response;

import java.io.Serializable;

public class FaultCodeDefinition implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long objId;
    private String faultCode;
    private String subId;
    private String faultDesc;
    private String faultLabel;
    private Long controllerSourceId;
    private String faultOrigin;
    private String modeDesc;
    private String criticalFlag;
    
    public Long getObjId() {
        return objId;
    }
    
    public void setObjId(Long objId) {
        this.objId = objId;
    }
    
    public String getFaultCode() {
        return faultCode;
    }
    
    public void setFaultCode(String faultCode) {
        this.faultCode = faultCode;
    }
    
    public String getSubId() {
        return subId;
    }
    
    public void setSubId(String subId) {
        this.subId = subId;
    }
    
    public String getFaultDesc() {
        return faultDesc;
    }
    
    public void setFaultDesc(String faultDesc) {
        this.faultDesc = faultDesc;
    }
    
    public String getFaultLabel() {
        return faultLabel;
    }
    
    public void setFaultLabel(String faultLabel) {
        this.faultLabel = faultLabel;
    }
    
    public Long getControllerSourceId() {
        return controllerSourceId;
    }
    
    public void setControllerSourceId(Long controllerSourceId) {
        this.controllerSourceId = controllerSourceId;
    }
    
    public String getFaultOrigin() {
        return faultOrigin;
    }
    
    public void setFaultOrigin(String faultOrigin) {
        this.faultOrigin = faultOrigin;
    }
    
    public String getModeDesc() {
        return modeDesc;
    }
    
    public void setModeDesc(String modeDesc) {
        this.modeDesc = modeDesc;
    }
    
    public String getCriticalFlag() {
        return criticalFlag;
    }
    
    public void setCriticalFlag(String criticalFlag) {
        this.criticalFlag = criticalFlag;
    }
    
}