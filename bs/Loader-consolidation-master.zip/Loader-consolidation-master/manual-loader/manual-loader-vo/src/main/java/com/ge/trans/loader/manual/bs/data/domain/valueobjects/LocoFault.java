package com.ge.trans.loader.manual.bs.data.domain.valueobjects;

import java.io.Serializable;

/**
 * @author 502166888
 *
 */
public class LocoFault implements Serializable {

	private static final long serialVersionUID = -1421647731294760135L;
	private String objid;
	private String faultCode;
	private String occurTime;
	private String occurDate;
	private String locoSpeed;
	private String direction;
	private String notch;
	private String engineSpeed;
	private String volts;
	private String currentAmps;
	private String fldAmps;
	private String waterTemp;
	private String oilTemp;
	private String radFan;
	private String hp;
	private String customerId;
	private String customerName;
	private String locoId;
	private String vehicleNo;
	private String faultIndex;
	private String offboardLoadDate;
	private String faultResetDate;
	private String lastUpdatedDate;
	private String recordType;
	private String subId;
	private String controllerSourceId;
	private String fault2vehicle;
	private String fault2faultCode;
	private String faultResetLoadDate;
	private String faultResetTime;
	private String getsMessageId;
	private String eservicesOccurTime;
	/**
	 * @return the objid
	 */
	public String getObjid() {
		return objid;
	}
	/**
	 * @param objid the objid to set
	 */
	public void setObjid(String objid) {
		this.objid = objid;
	}
	/**
	 * @return the faultCode
	 */
	public String getFaultCode() {
		return faultCode;
	}
	/**
	 * @param faultCode the faultCode to set
	 */
	public void setFaultCode(String faultCode) {
		this.faultCode = faultCode;
	}
	/**
	 * @return the occurTime
	 */
	public String getOccurTime() {
		return occurTime;
	}
	/**
	 * @param occurTime the occurTime to set
	 */
	public void setOccurTime(String occurTime) {
		this.occurTime = occurTime;
	}
	/**
	 * @return the occurDate
	 */
	public String getOccurDate() {
		return occurDate;
	}
	/**
	 * @param occurDate the occurDate to set
	 */
	public void setOccurDate(String occurDate) {
		this.occurDate = occurDate;
	}
	
	/**
	 * @return the locoSpeed
	 */
	public String getLocoSpeed() {
		return locoSpeed;
	}
	/**
	 * @param locoSpeed the locoSpeed to set
	 */
	public void setLocoSpeed(String locoSpeed) {
		this.locoSpeed = locoSpeed;
	}
	/**
	 * @return the direction
	 */
	public String getDirection() {
		return direction;
	}
	/**
	 * @param direction the direction to set
	 */
	public void setDirection(String direction) {
		this.direction = direction;
	}
	/**
	 * @return the notch
	 */
	public String getNotch() {
		return notch;
	}
	/**
	 * @param notch the notch to set
	 */
	public void setNotch(String notch) {
		this.notch = notch;
	}
	/**
	 * @return the engineSpeed
	 */
	public String getEngineSpeed() {
		return engineSpeed;
	}
	/**
	 * @param engineSpeed the engineSpeed to set
	 */
	public void setEngineSpeed(String engineSpeed) {
		this.engineSpeed = engineSpeed;
	}
	/**
	 * @return the volts
	 */
	public String getVolts() {
		return volts;
	}
	/**
	 * @param volts the volts to set
	 */
	public void setVolts(String volts) {
		this.volts = volts;
	}
	/**
	 * @return the currentAmps
	 */
	public String getCurrentAmps() {
		return currentAmps;
	}
	/**
	 * @param currentAmps the currentAmps to set
	 */
	public void setCurrentAmps(String currentAmps) {
		this.currentAmps = currentAmps;
	}
	/**
	 * @return the fldAmps
	 */
	public String getFldAmps() {
		return fldAmps;
	}
	/**
	 * @param fldAmps the fldAmps to set
	 */
	public void setFldAmps(String fldAmps) {
		this.fldAmps = fldAmps;
	}
	/**
	 * @return the waterTemp
	 */
	public String getWaterTemp() {
		return waterTemp;
	}
	/**
	 * @param waterTemp the waterTemp to set
	 */
	public void setWaterTemp(String waterTemp) {
		this.waterTemp = waterTemp;
	}
	/**
	 * @return the oilTemp
	 */
	public String getOilTemp() {
		return oilTemp;
	}
	/**
	 * @param oilTemp the oilTemp to set
	 */
	public void setOilTemp(String oilTemp) {
		this.oilTemp = oilTemp;
	}
	/**
	 * @return the radFan
	 */
	public String getRadFan() {
		return radFan;
	}
	/**
	 * @param radFan the radFan to set
	 */
	public void setRadFan(String radFan) {
		this.radFan = radFan;
	}
	/**
	 * @return the hp
	 */
	public String getHp() {
		return hp;
	}
	/**
	 * @param hp the hp to set
	 */
	public void setHp(String hp) {
		this.hp = hp;
	}
	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * @return the locoId
	 */
	public String getLocoId() {
		return locoId;
	}
	/**
	 * @param locoId the locoId to set
	 */
	public void setLocoId(String locoId) {
		this.locoId = locoId;
	}
	/**
	 * @return the vehicleNo
	 */
	public String getVehicleNo() {
		return vehicleNo;
	}
	/**
	 * @param vehicleNo the vehicleNo to set
	 */
	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}
	/**
	 * @return the faultIndex
	 */
	public String getFaultIndex() {
		return faultIndex;
	}
	/**
	 * @param faultIndex the faultIndex to set
	 */
	public void setFaultIndex(String faultIndex) {
		this.faultIndex = faultIndex;
	}
	/**
	 * @return the offboardLoadDate
	 */
	public String getOffboardLoadDate() {
		return offboardLoadDate;
	}
	/**
	 * @param offboardLoadDate the offboardLoadDate to set
	 */
	public void setOffboardLoadDate(String offboardLoadDate) {
		this.offboardLoadDate = offboardLoadDate;
	}
	/**
	 * @return the faultResetDate
	 */
	public String getFaultResetDate() {
		return faultResetDate;
	}
	/**
	 * @param faultResetDate the faultResetDate to set
	 */
	public void setFaultResetDate(String faultResetDate) {
		this.faultResetDate = faultResetDate;
	}
	/**
	 * @return the lastUpdatedDate
	 */
	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}
	/**
	 * @param lastUpdatedDate the lastUpdatedDate to set
	 */
	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}
	/**
	 * @return the recordType
	 */
	public String getRecordType() {
		return recordType;
	}
	/**
	 * @param recordType the recordType to set
	 */
	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
	/**
	 * @return the subId
	 */
	public String getSubId() {
		return subId;
	}
	/**
	 * @param subId the subId to set
	 */
	public void setSubId(String subId) {
		this.subId = subId;
	}
	/**
	 * @return the controllerSourceId
	 */
	public String getControllerSourceId() {
		return controllerSourceId;
	}
	/**
	 * @param controllerSourceId the controllerSourceId to set
	 */
	public void setControllerSourceId(String controllerSourceId) {
		this.controllerSourceId = controllerSourceId;
	}
	/**
	 * @return the fault2vehicle
	 */
	public String getFault2vehicle() {
		return fault2vehicle;
	}
	/**
	 * @param fault2vehicle the fault2vehicle to set
	 */
	public void setFault2vehicle(String fault2vehicle) {
		this.fault2vehicle = fault2vehicle;
	}
	/**
	 * @return the fault2faultCode
	 */
	public String getFault2faultCode() {
		return fault2faultCode;
	}
	/**
	 * @param fault2faultCode the fault2faultCode to set
	 */
	public void setFault2faultCode(String fault2faultCode) {
		this.fault2faultCode = fault2faultCode;
	}
	/**
	 * @return the faultResetLoadDate
	 */
	public String getFaultResetLoadDate() {
		return faultResetLoadDate;
	}
	/**
	 * @param faultResetLoadDate the faultResetLoadDate to set
	 */
	public void setFaultResetLoadDate(String faultResetLoadDate) {
		this.faultResetLoadDate = faultResetLoadDate;
	}
	/**
	 * @return the faultResetTime
	 */
	public String getFaultResetTime() {
		return faultResetTime;
	}
	/**
	 * @param faultResetTime the faultResetTime to set
	 */
	public void setFaultResetTime(String faultResetTime) {
		this.faultResetTime = faultResetTime;
	}
	/**
	 * @return the getsMessageId
	 */
	public String getGetsMessageId() {
		return getsMessageId;
	}
	/**
	 * @param getsMessageId the getsMessageId to set
	 */
	public void setGetsMessageId(String getsMessageId) {
		this.getsMessageId = getsMessageId;
	}
	/**
	 * @return the eservicesOccurTime
	 */
	public String getEservicesOccurTime() {
		return eservicesOccurTime;
	}
	/**
	 * @param eservicesOccurTime the eservicesOccurTime to set
	 */
	public void setEservicesOccurTime(String eservicesOccurTime) {
		this.eservicesOccurTime = eservicesOccurTime;
	}
	
	
	
	
}
