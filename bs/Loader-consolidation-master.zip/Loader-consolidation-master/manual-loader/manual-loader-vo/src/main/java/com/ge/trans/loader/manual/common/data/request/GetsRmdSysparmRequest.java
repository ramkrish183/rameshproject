package com.ge.trans.loader.manual.common.data.request;

import com.ge.trans.loader.manual.common.data.GetsRmdSysparmVO;

public class GetsRmdSysparmRequest extends  GetsRmdSysparmVO{

	
}
