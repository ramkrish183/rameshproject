package com.ge.trans.loader.manual.bs.data.domain.valueobjects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class FaultSnapshotWrapper {
    
    private LocoFault locoFault;
    private List<Map<String, Object>> monitoringParamMaps;
    private String faultObjId;
    
    public LocoFault getLocoFault() {
        return locoFault;
    }
    
    public void setLocoFault(LocoFault locoFault) {
        this.locoFault = locoFault;
    }
    
    public List<Map<String, Object>> getMonitoringParamMaps() {
        if (monitoringParamMaps == null) {
            monitoringParamMaps = new ArrayList<Map<String, Object>>();
        }
        return monitoringParamMaps;
    }
    
    
    public String getFaultObjId() {
        return faultObjId;
    }
    
    /**
	 * @param monitoringParamMaps the monitoringParamMaps to set
	 */
	public void setMonitoringParamMaps(List<Map<String, Object>> monitoringParamMaps) {
		this.monitoringParamMaps = monitoringParamMaps;
	}

	public void setFaultObjId(String faultObjId) {
        this.faultObjId = faultObjId;
        if (locoFault != null) {
            locoFault.setObjid(faultObjId);
        }
    }
}
