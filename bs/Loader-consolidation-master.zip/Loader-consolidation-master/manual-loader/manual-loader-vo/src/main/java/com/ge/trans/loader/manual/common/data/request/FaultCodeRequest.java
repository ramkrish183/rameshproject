package com.ge.trans.loader.manual.common.data.request;

import java.io.Serializable;

public class FaultCodeRequest implements Serializable{
    
    private static final long serialVersionUID = 8331422841170928896L;
    private String faultCode;
    private String subId;
    private String controllerSourceID;
    
    public String getFaultCode() {
        return faultCode;
    }
    
    public void setFaultCode(String faultCode) {
        this.faultCode = faultCode;
    }
    
    public String getSubId() {
        return subId;
    }
    
    public void setSubId(String subId) {
        this.subId = subId;
    }
    
    public String getControllerSourceID() {
        return controllerSourceID;
    }
    
    public void setControllerSourceID(String controllerSourceID) {
        this.controllerSourceID = controllerSourceID;
    }
    
}
