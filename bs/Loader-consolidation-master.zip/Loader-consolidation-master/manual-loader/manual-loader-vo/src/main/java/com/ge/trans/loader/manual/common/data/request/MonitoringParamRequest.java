package com.ge.trans.loader.manual.common.data.request;

import java.io.Serializable;

import com.ge.trans.loader.manual.common.data.response.ParamDefinition;

public class MonitoringParamRequest implements Serializable{
  
    private static final long serialVersionUID = 361821175476103539L;
    private String paramNumber;
    private String paramLoadColumn;
    private String controllerSourceId;
    private ParamDefinition paramDefinition;
    
    public String getParamNumber() {
        return paramNumber;
    }
    
    public void setParamNumber(String paramNumber) {
        this.paramNumber = paramNumber;
    }
    
    public String getParamLoadColumn() {
        return paramLoadColumn;
    }
    
    public void setParamLoadColumn(String paramLoadColumn) {
        this.paramLoadColumn = paramLoadColumn;
    }
    
    public String getControllerSourceId() {
        return controllerSourceId;
    }
    
    public void setControllerSourceId(String controllerSourceId) {
        this.controllerSourceId = controllerSourceId;
    }
    
    public ParamDefinition getParamDefinition() {
        return paramDefinition;
    }
    
    public void setParamDefinition(ParamDefinition paramDefinition) {
        this.paramDefinition = paramDefinition;
    }
}
