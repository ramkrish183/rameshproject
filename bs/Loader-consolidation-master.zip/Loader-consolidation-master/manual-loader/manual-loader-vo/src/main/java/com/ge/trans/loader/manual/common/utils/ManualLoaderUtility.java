package com.ge.trans.loader.manual.common.utils;

import static java.util.Calendar.getInstance;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.ThreadLocalRandom;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;

/**
 * @author 502166888
 *
 */
public class ManualLoaderUtility {

  private static final Logger LOGGER = LoggerFactory.getLogger(ManualLoaderUtility.class);

  private ManualLoaderUtility() {
    // private constructor
  }

  public static boolean isAlphaString(String input) {
    return input.matches(ManualLoaderConstants.REGEX_ALPHA_PATTERN);
  }

  public static boolean isAlphaNumericString(String input) {
    return input.matches(ManualLoaderConstants.REGEX_ALPHA_NUMERIC_PATTERN);
  }
  
  public static boolean isFloatingPointNumber(String input) {
    return input.matches(ManualLoaderConstants.REGEX_FLOAT_NUMBER_PATTERN);
  }

  public static boolean validateDataFormat(String inputDate, String pattern) {
    SimpleDateFormat dateformat = new SimpleDateFormat(pattern);
    boolean output = false;
    try {
      Date parsedDate = dateformat.parse(inputDate);
      if (inputDate.equals(dateformat.format(parsedDate))) {
        output = true;
      }
    } catch (ParseException e) {
      output = false;
    }
    return output;
  }

  public static String convertKmtoMiles(double valueinKMs) {
      double valueinMiles=valueinKMs * 0.621371;
    return Double.toString(valueinMiles);
  }

  /**
   * @param motoring
   * @return
   */
  public static double convertToMWHrs(String motoring) {
    double dMotoringMwHr;
    dMotoringMwHr = Double.parseDouble(motoring);
    dMotoringMwHr = dMotoringMwHr / 1000;
    return dMotoringMwHr;
  }

  public static boolean isNumericString(String input) {
    return input.matches(ManualLoaderConstants.REGEX_NUMERIC_PATTERN);
  }

  /**
   * Converts String to a given date format
   * 
   * @param strDate
   * @param format
   * @return Date
   */
  public static Date getStringAsDate(String strDate, String format) {
    Date currentDate = null;
    Calendar calLocal = Calendar.getInstance();
    SimpleDateFormat formatLocal = new SimpleDateFormat(format);
    try {
      formatLocal.setCalendar(calLocal);
      currentDate = (Date) formatLocal.parse(strDate);
    } catch (Exception exception) {
      LOGGER.error("Exception from Utility getStringAsDate() : ", exception);
    }

    return currentDate;
  }

  public static String convertDateToString(Date dateValue, String toFormat) {
    String toDate = null;
    if (dateValue == null) {
      return toDate;
    }
    DateFormat localFormat = new SimpleDateFormat(toFormat);
    try {     
      LOGGER.debug("Received Date {} , requires conversion to  {}", dateValue, toFormat);
      toDate = localFormat.format(dateValue);
      LOGGER.debug("Converted Message Header Date from {} to {}", dateValue, toDate);
    } catch (Exception e) {
      LOGGER.error("Exception Occurred in convertDateToString Method: ", e);
    }
    return toDate;
  }

  public static Date stringToDate(String dateString, String dateFormatPattern, TimeZone tz) {
    Date date = null;
    SimpleDateFormat formatter = new SimpleDateFormat();
    formatter.applyPattern(dateFormatPattern);
    // Specify strict parsing (i.e. inputs must match object's format)
    formatter.setLenient(false);
    try {
      date = formatter.parse(dateString);
      if (tz != null) {
        Calendar cal = getInstance(tz);
        cal.setTime(date);
        date = cal.getTime();
      }
    } catch (Exception e) {
      LOGGER.error("Exception Occurred in stringToDate Method: ", e);
    }
    return date;
  }
  
  public static String checkFaultIndex(String faultIndex) {
    return null != faultIndex && ManualLoaderUtility.isNumericString(faultIndex.trim()) ? faultIndex : ManualLoaderConstants.ZERO_STRING;
  }
  
  public static String getRandomNumberInRange(int min, int max) {
    // Modified to TheadLocalRandom from math.random to avoid duplicates
    int randomNumber = ThreadLocalRandom.current().nextInt(min, max);
    return ManualLoaderConstants.HYPHEN + StringUtils.leftPad(randomNumber + ManualLoaderConstants.EMPTY, 4, ManualLoaderConstants.ZERO_STRING);
  }
  
 
  

}
