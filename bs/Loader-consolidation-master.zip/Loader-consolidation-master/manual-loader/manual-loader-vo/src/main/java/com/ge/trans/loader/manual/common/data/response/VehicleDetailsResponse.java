package com.ge.trans.loader.manual.common.data.response;

import java.io.Serializable;

import com.ge.trans.loader.manual.common.data.VehicleDetailsVO;

public class VehicleDetailsResponse extends VehicleDetailsVO implements Serializable {
    
    private static final long serialVersionUID = 2972090998581950589L;
    private Long vehicleObjid;
    private String orgName;
    
    public Long getVehicleObjid() {
        return vehicleObjid;
    }
    
    public void setVehicleObjid(Long vehicleObjid) {
        this.vehicleObjid = vehicleObjid;
    }
    
    public String getOrgName() {
        return orgName;
    }
    
    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }
}
