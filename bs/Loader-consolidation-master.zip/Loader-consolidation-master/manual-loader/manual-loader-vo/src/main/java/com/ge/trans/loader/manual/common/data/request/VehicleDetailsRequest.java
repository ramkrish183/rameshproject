package com.ge.trans.loader.manual.common.data.request;

import java.io.Serializable;

import com.ge.trans.loader.manual.common.data.VehicleDetailsVO;

public class VehicleDetailsRequest extends  VehicleDetailsVO implements Serializable {
    
    private static final long serialVersionUID = 5324742225984339263L;
    
}
