package com.ge.trans.loader.manual.common.data.response;

import java.io.Serializable;
import java.math.BigDecimal;

public class ParamDefinition implements Serializable{
    
    private static final long serialVersionUID = -8784104520231935057L;
    private BigDecimal destType;
    private String dataType;
    private MPDataType dataTypeEnum;
    private BigDecimal startBit;
    private BigDecimal bitToCount;
    private BigDecimal decimalWidth;
    private BigDecimal multiplierScaling;
    private BigDecimal divisorScaling;
    private BigDecimal decimalPosition;
    private boolean sdpDecode;
    private boolean includeInSDP;
    private String paramLoadTable;
    private String paramLoadColumn;
    private String mpFaultLogTable;
    private String mpFaultLogColumn;
    private BigDecimal controllerSourceId;
    private BigDecimal mpDataSignedType;
    private BigDecimal mpDatasize;
    
    /**
     * This method returns True/False based on given bitToCount property.
     * 
     * @return the bitPacked
     */
    public boolean isBitPacked() {
        return null != bitToCount && bitToCount.intValue() > 0;
    }
    
    public BigDecimal getDestType() {
        return destType;
    }
    
    public void setDestType(BigDecimal destType) {
        this.destType = destType;
    }
    
    public BigDecimal getStartBit() {
        return startBit;
    }
    
    public void setStartBit(BigDecimal startBit) {
        this.startBit = startBit;
    }
    
    public BigDecimal getBitToCount() {
        return bitToCount;
    }
    
    public void setBitToCount(BigDecimal bitToCount) {
        this.bitToCount = bitToCount;
    }
    
    public BigDecimal getDecimalWidth() {
        return decimalWidth;
    }
    
    public void setDecimalWidth(BigDecimal decimalWidth) {
        this.decimalWidth = decimalWidth;
    }
    
    public BigDecimal getMultiplierScaling() {
        return multiplierScaling;
    }
    
    public void setMultiplierScaling(BigDecimal multiplierScaling) {
        this.multiplierScaling = multiplierScaling;
    }
    
    public BigDecimal getDivisorScaling() {
        return divisorScaling;
    }
    
    public void setDivisorScaling(BigDecimal divisorScaling) {
        this.divisorScaling = divisorScaling;
    }
    
    public BigDecimal getDecimalPosition() {
        return decimalPosition;
    }
    
    public void setDecimalPosition(BigDecimal decimalPosition) {
        this.decimalPosition = decimalPosition;
    }
    
    public String getParamLoadTable() {
        return paramLoadTable;
    }
    
    public void setParamLoadTable(String paramLoadTable) {
        this.paramLoadTable = paramLoadTable;
    }
    
    public String getParamLoadColumn() {
        return paramLoadColumn;
    }
    
    public void setParamLoadColumn(String paramLoadColumn) {
        this.paramLoadColumn = paramLoadColumn;
    }
    
    public String getMpFaultLogTable() {
        return mpFaultLogTable;
    }
    
    public void setMpFaultLogTable(String mpFaultLogTable) {
        this.mpFaultLogTable = mpFaultLogTable;
    }
    
    public String getMpFaultLogColumn() {
        return mpFaultLogColumn;
    }
    
    public void setMpFaultLogColumn(String mpFaultLogColumn) {
        this.mpFaultLogColumn = mpFaultLogColumn;
    }
    
    public BigDecimal getControllerSourceId() {
        return controllerSourceId;
    }
    
    public void setControllerSourceId(BigDecimal controllerSourceId) {
        this.controllerSourceId = controllerSourceId;
    }
    
    public BigDecimal getMpDataSignedType() {
        return mpDataSignedType;
    }
    
    public void setMpDataSignedType(BigDecimal mpDataSignedType) {
        this.mpDataSignedType = mpDataSignedType;
    }
    
    public BigDecimal getMpDatasize() {
        return mpDatasize;
    }
    
    public void setMpDatasize(BigDecimal mpDatasize) {
        this.mpDatasize = mpDatasize;
    }
    
    public MPDataType getDataTypeEnum() {
        return dataTypeEnum;
    }
    
    public void setDataTypeEnum(MPDataType dataTypeEnum) {
        this.dataTypeEnum = dataTypeEnum;
    }
    
    /**
     * @return the dataType
     */
    public String getDataType() {
        return dataType;
    }
    
    /**
     * @param dataType
     *            the dataType to set
     */
    public void setDataType(String dataType) {
        this.dataType = dataType;
    }
    
    /**
     * @return the sdpDecode
     */
    public boolean isSdpDecode() {
        return sdpDecode;
    }
    
    /**
     * @param sdpDecode
     *            the sdpDecode to set
     */
    public void setSdpDecode(boolean sdpDecode) {
        this.sdpDecode = sdpDecode;
    }
    
    /**
     * @return the includeInSDP
     */
    public boolean isIncludeInSDP() {
        return includeInSDP;
    }
    
    /**
     * @param includeInSDP
     *            the includeInSDP to set
     */
    public void setIncludeInSDP(boolean includeInSDP) {
        this.includeInSDP = includeInSDP;
    }
    
}