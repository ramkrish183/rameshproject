package com.ge.trans.loader.manual.common.data.response;

import com.ge.trans.loader.manual.common.data.GetsRmdSysparmVO;

/**
 * @author 502166888
 *
 */
public class GetsRmdSysparmResponse extends GetsRmdSysparmVO{
	
}
