package com.ge.trans.loader.manual.bs.data.domain.valueobjects;

import java.io.Serializable;
import java.util.Date;

public class BSStatisticsVO implements Serializable {

	private static final long serialVersionUID = 2532269491082954490L;
	private String objid;
	private String custId;
	private String custName;
	private String locoId;
	private String roadNumber;
	private Date lastUpdatedDate;
	private String lastUpdatedBy;
	private Date creationDate;
	private String createdBy;
	private Date offboardLoadDate;
	private String cabCaxTime;
	private String motorMWHrs;
	private String totalMiles;
	private String idleHours;
	private String n1Param;
	private String n2Param;
	private String n3Param;
	private String n4Param;
	private String n5Param;
	private String n6Param;
	private String n7Param;
	private String n8Param;
	private String totalEngHours;

	public String getObjid() {
		return objid;
	}

	public void setObjid(String objid) {
		this.objid = objid;
	}

	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getLocoId() {
		return locoId;
	}

	public void setLocoId(String locoId) {
		this.locoId = locoId;
	}

	public String getRoadNumber() {
		return roadNumber;
	}

	public void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public Date getCreationDate() {
		return creationDate;
	}

	public void setCreationDate(Date creationDate) {
		this.creationDate = creationDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getOffboardLoadDate() {
		return offboardLoadDate;
	}

	public void setOffboardLoadDate(Date offboardLoadDate) {
		this.offboardLoadDate = offboardLoadDate;
	}

	public String getCabCaxTime() {
		return cabCaxTime;
	}

	public void setCabCaxTime(String cabCaxTime) {
		this.cabCaxTime = cabCaxTime;
	}

	public String getMotorMWHrs() {
		return motorMWHrs;
	}

	public void setMotorMWHrs(String motorMWHrs) {
		this.motorMWHrs = motorMWHrs;
	}

	public String getTotalMiles() {
		return totalMiles;
	}

	public void setTotalMiles(String totalMiles) {
		this.totalMiles = totalMiles;
	}

	public String getIdleHours() {
		return idleHours;
	}

	public void setIdleHours(String idleHours) {
		this.idleHours = idleHours;
	}

	public String getN1Param() {
		return n1Param;
	}

	public void setN1Param(String n1Param) {
		this.n1Param = n1Param;
	}

	public String getN2Param() {
		return n2Param;
	}

	public void setN2Param(String n2Param) {
		this.n2Param = n2Param;
	}

	public String getN3Param() {
		return n3Param;
	}

	public void setN3Param(String n3Param) {
		this.n3Param = n3Param;
	}

	public String getN4Param() {
		return n4Param;
	}

	public void setN4Param(String n4Param) {
		this.n4Param = n4Param;
	}

	public String getN5Param() {
		return n5Param;
	}

	public void setN5Param(String n5Param) {
		this.n5Param = n5Param;
	}

	public String getN6Param() {
		return n6Param;
	}

	public void setN6Param(String n6Param) {
		this.n6Param = n6Param;
	}

	public String getN7Param() {
		return n7Param;
	}

	public void setN7Param(String n7Param) {
		this.n7Param = n7Param;
	}

	public String getN8Param() {
		return n8Param;
	}

	public void setN8Param(String n8Param) {
		this.n8Param = n8Param;
	}

	public String getTotalEngHours() {
		return totalEngHours;
	}

	public void setTotalEngHours(String totalEngHours) {
		this.totalEngHours = totalEngHours;
	}

}
