package com.ge.trans.loader.manual.bs.data.domain.valueobjects;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BSDecodedResponse implements Serializable {

  private static final long serialVersionUID = 6235297915753324236L;
  private List<FaultSnapshotWrapper> faultAndSnapshots;
  private BSStatisticsVO bsStatisticsVO;
  private List<Exception> errorList = new ArrayList<Exception>();

  public List<FaultSnapshotWrapper> getFaultAndSnapshots() {
    if (faultAndSnapshots == null) {
      faultAndSnapshots = new ArrayList<FaultSnapshotWrapper>();
    }
    return faultAndSnapshots;
  }

  public void setFaultAndSnapshots(List<FaultSnapshotWrapper> faultAndSnapshots) {
    List<FaultSnapshotWrapper> faults = getFaultAndSnapshots();
    if (faultAndSnapshots != null) {
      faults.addAll(faultAndSnapshots);
    }
  }

  public BSStatisticsVO getBsStatisticsVO() {
    return bsStatisticsVO;
  }

  public void setBsStatisticsVO(BSStatisticsVO bsStatisticsVO) {
    this.bsStatisticsVO = bsStatisticsVO;
  }

  /**
   * @return the errorList
   */
  public List<Exception> getErrorList() {
    return errorList;
  }

  /**
   * @param errorList the errorList to set
   */
  public void setErrorList(List<Exception> errorList) {
    this.errorList = errorList;
  }

}
