package com.ge.trans.loader.manual.common.data;

import java.io.Serializable;

public class VehicleDetailsVO implements Serializable {
    
    private static final long serialVersionUID = 5324742225984339263L;
    private String customerId;
    private String vehicleNumber;
    private String vehicleInitial;
    private String eservicesVehicleNo;
    
    public String getCustomerId() {
        return customerId;
    }
    
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
    
    public String getVehicleNumber() {
        return vehicleNumber;
    }
    
    public void setVehicleNumber(String vehicleNumber) {
        this.vehicleNumber = vehicleNumber;
    }
    
    public String getVehicleInitial() {
        return vehicleInitial;
    }
    
    public void setVehicleInitial(String vehicleInitial) {
        this.vehicleInitial = vehicleInitial;
    }

    /**
     * @return the eservicesVehicleNo
     */
    public String getEservicesVehicleNo() {
      return eservicesVehicleNo;
    }

    /**
     * @param eservicesVehicleNo the eservicesVehicleNo to set
     */
    public void setEservicesVehicleNo(String eservicesVehicleNo) {
      this.eservicesVehicleNo = eservicesVehicleNo;
    }
    
}
