package com.ge.trans.loader.manual.common.constant;

/**
 * @author 502166888
 *
 */
public final class ManualLoaderConstants {
  private ManualLoaderConstants() {
    // PRIVATE CONSTRUCTOR
  }

  // Date constants
  public static final String MM_DD_YY_HH_MM_SS = "MM/dd/yy HH:mm:ss";
  public static final String GMT = "GMT";
  public static final String MMM_DD_HH_MM_SS_YYYY = "MMM dd HH:mm:ss yyyy";
  public static final String EEE_MMM_D_HH_MM_SS_YYYY = "EEE MMM d HH:mm:ss yyyy";
  public static final String MM_DD_YYYY_HH_MM_SS = "MM/dd/yyyy HH:mm:ss";
  public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
  public static final String DEFAULT_CAB_CAX_DATE_FORMAT = "MM/dd/yyyy HH:mm:ss";

  // Regex constants
  public static final String REGEX_FIND_ALL_LEADING_ZEROS_PATTERN = "^0+(?!$)";
  public static final String REGEX_ALPHA_PATTERN = "^[a-zA-Z]*$";
  public static final String REGEX_ALPHA_NUMERIC_PATTERN = "^[a-zA-Z0-9]*$";
  public static final String REGEX_NUMERIC_PATTERN = "[0-9]+";
  public static final String REGEX_FLOAT_NUMBER_PATTERN ="[+-]?([0-9]*[.])?[0-9]+";
  public static final String REGEX_FIND_ONE_LEADING_ZERO_PATTERN ="^0?";

  // Numeric constants
  public static final String ZERO_STRING = "0";
  public static final int DEFAULT_LOOKBACK_DOWNLOAD_TIME = 60;
  public static final int DEFAULT_BS_FAULT_COLLECTION_TIME = 240;
  public static final String ONE_STRING = "1";
  public static final String MINUS_ONE_STRING = "-1";
  public static final int BRIGHTSTAR_FILE_VEHICLENO_START_POSITION = 64;
  public static final int BRIGHTSTAR_FILE_VEHICLENO_END_POSITION = 70;
  public static final int BRIGHTSTAR_FILE_CABCAXTIME_START_POSITION = 1;
  public static final int BRIGHTSTAR_FILE_CABCAXTIME_END_POSITION = 1;
  public static final String BS_DEFAULT_CONTROLLER_SRC_ID = "26";

  // Special constants
  public static final String NA = "NA";
  public static final String ONE_SPACE_STRING = " ";
  public static final String TILDE_SYMBOL = "~";
  public static final String HYPHEN = "-";
  public static final String EMPTY = "";
  // Alpha constants
  public static final String LOCO_MSG_TYPE = "locoMsgType";
  public static final String LOCO_ID = "locoID";
  public static final String APP_NAME = "app.name";
  public static final String BS_FAULT_COLLECTION_TIME_TITLE = "bs_fault_collection_time";
  public static final String DOWNLOAD_LOOKBACK_TIME_TITLE = "download_lookback_time";
  public static final String EGU = "EGU";
  public static final String CAB_CAX_TIME = "CAB_CAX_TIME";
  public static final int ZERO_INDEX = 0;
  public static final String MESSAGE_TYPE_BS = "BS-MESSAGE";
  public static final String CAMEL_FILE_HOST = "CamelFileHost";
  public static final String ACTUAL_FAULTS_PROCESSED = "ACTUAL_FAULTS_PROCESSED";
  public static final String PROGRAM_NAME = "programName";
  public static final String MSGUUID = "msgUUID";
  public static final String VEHICLE_REQUEST = "VEHICLE_REQUEST";
  public static final String FILE_NAME = "FILE_NAME";
  public static final String SPLITTED_FILE = "SPLITTED_FILE";
  public static final String OCCUR_TIME = "occurTime";
  public static final String OCCUR_DATE = "occurDate";
  public static final String FAULT_RESET_TIME = "faultResetTime";
  public static final String FAULT_RESET_DATE = "faultResetDate";
  public static final String MP_ENGR_BITS = "MP_Engr_Bits";
  public static final String COLON = ":";
  public static final String BASIC = "Basic ";
  public static final String AUTHORIZATION_HEADER = "Authorization";
  public static final String INPROGRESS = "INPROGRESS";
  public static final String ESERVICESREQUEST = "eserviceRequest";
  public static final String MESSAGEUID = "messageUID";
  public static final String FAILED = "FAILED";
  public static final String POST = "POST:";
  public static final String LAST_FAULT_INDEX_LIST = "LAST_FAULT_INDEX_LIST";
  public static final String LAST_FAULT_INDEX = "LAST_FAULT_INDEX";
  public static final String BS_DEFAULT_PARAM_NUMBER = "ENGR_BITS";
  public static final String MP_ENGR_BITS_CAPS = "MP_ENGR_BITS";
  public static final String FAULT2FAULT_CODE = "fault2fault_Code";
  public static final String FAULT2_VEHICLE = "fault2Vehicle";
  public static final String DURATION = "duration";
  public static final String RECORD_TYPE = "recordType";
  public static final String TITLE2 = "title";
  public static final String LAST_UPDATED_BY = "lastUpdatedBy";
  public static final String FAULT_COLLECTION_TIME = "faultCollectionTime";
  public static final String VEHICLE_OBJID2 = "vehicleObjid";
  public static final String FAULT_DESC = "FAULT_DESC";
  public static final String FAULT_CODE2 = "FAULT_CODE";
  public static final String OBJID = "OBJID";
  public static final String CRITICAL_FLAG = "CRITICAL_FLAG";
  public static final String PARM_LOAD_COLUMN = "PARM_LOAD_COLUMN";
  public static final String PARM_LOAD_TABLE = "PARM_LOAD_TABLE";
  public static final String BIT_TO_COUNT = "BIT_TO_COUNT";
  public static final String START_BIT = "START_BIT";
  public static final String SUB_ID = "subId";
  public static final String FAULT_CODE = "faultCode";
  public static final String VEHICLE_OBJID = "VEHICLE_OBJID";
  public static final String SERIAL_NO = "SERIAL_NO";
  public static final String ORG_NAME = "ORG_NAME";
  public static final String ORG_ID = "ORG_ID";
  public static final String VEHICLE_HEADER = "vehicleHeader";
  public static final String CUSTOMER_ID = "customerId";
  public static final String VEHICLE_NUMBER = "vehicleNumber";
  public static final String PARAM_NUMBER = "paramNumber";
  public static final String PARAM_LOAD_COLUMN = "paramLoadColumn";
  public static final String CONTROLLER_SOURCE_ID = "controllerSourceId";
}
