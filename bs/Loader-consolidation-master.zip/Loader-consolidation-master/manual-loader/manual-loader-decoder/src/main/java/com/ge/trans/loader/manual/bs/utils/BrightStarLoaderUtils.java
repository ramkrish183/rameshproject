package com.ge.trans.loader.manual.bs.utils;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.SimpleTimeZone;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.common.exception.LoaderException;
import com.ge.trans.loader.common.exception.LoaderRuntimeException;
import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;
import com.ge.trans.loader.manual.common.enums.ManualLoaderError;

public class BrightStarLoaderUtils {

  private static final String BASE_GMT_TIME_01_01_1987_05_00_00 = "01/01/1987 05:00:00";
  private static final Logger LOGGER = LoggerFactory.getLogger(BrightStarLoaderUtils.class);

  private BrightStarLoaderUtils() {

  }

  @SuppressWarnings({"unchecked", "rawtypes"})
  public static String callClassMethod(String strClassName, String strMethodName, String strInputParam) {
    try {
      Class[] params = new Class[] {String.class};
      Class thisClass = Class.forName(strClassName);
      Method thisMethod = thisClass.getDeclaredMethod(strMethodName, params);
      return thisMethod.invoke(thisClass.newInstance(), new Object[] {strInputParam}).toString();
    } catch (ClassNotFoundException | IllegalAccessException | IllegalArgumentException | InvocationTargetException | InstantiationException | NoSuchMethodException
      | SecurityException e) {
      throw new LoaderRuntimeException(ManualLoaderError.EXCEPTION_WHILE_CONVERTING_BS_FIELDS.getErrorCode(),
        ManualLoaderError.EXCEPTION_WHILE_CONVERTING_BS_FIELDS.getErrorDesc() + ":" + e.getMessage());
    }
  }

  public static String getOccurTimeForEservices(String date) {
    return getTimeInMilliseconds(date, ManualLoaderConstants.EEE_MMM_D_HH_MM_SS_YYYY);
  }

  public static String getTimeInMilliseconds(String input, String format) {
    SimpleDateFormat formatter = new SimpleDateFormat(format);
    String output = null;
    try {
      if (StringUtils.isNotBlank(input)) {
        long dateTimeinMilliSeconds = formatter.parse(input).getTime();
        output = Long.toString(dateTimeinMilliSeconds);
      }
    } catch (ParseException e) {
      LOGGER.error("Error while parsing Date/Time ");
    }
    return output;
  }

  public static String convertKPH2Miles(String strKPH) {
    String strMiles = "";
    if (strKPH != null && !"".equals(strKPH)) {
      double iMiles = 0;
      double iKPH = Double.parseDouble(strKPH);
      iMiles = 0.621371 * iKPH;
      strMiles = String.valueOf(iMiles);
    }
    return strMiles;
  }

  public static String getConvertedDateTime(String strTime) throws LoaderException {
    String strReturnString = "";
    if (StringUtils.isNotBlank(strTime)) {
      Date dtoccrDt = getCurrentTimeStampForDB(strTime, ManualLoaderConstants.MM_DD_YY_HH_MM_SS);
      Float occurTime = getConvertedOccurResetTime(dtoccrDt);
      strReturnString = Float.toString(occurTime);
    } else {
      throw new LoaderException(ManualLoaderError.EMPTY_INPUT_DATE.getErrorCode(), ManualLoaderError.EMPTY_INPUT_DATE.getErrorDesc());
    }

    return strReturnString;

  }

  public static Date getCurrentTimeStampForDB(String strDate, String format1) throws LoaderException {
    Date currentDate = null;
    Date dateTemp = null;
    Calendar calLocal = Calendar.getInstance();
    DateFormat formatter;
    formatter = new SimpleDateFormat(ManualLoaderConstants.MMM_DD_HH_MM_SS_YYYY);
    SimpleDateFormat formatLocal = new SimpleDateFormat(format1);

    formatLocal.setCalendar(calLocal);
    try {
      dateTemp = formatter.parse(strDate);
      String s2 = formatLocal.format(dateTemp);
      currentDate = formatLocal.parse(s2);
    } catch (ParseException e) {
      throw new LoaderException(ManualLoaderError.EXCEPTION_WHILE_PARSING_INPUT_DATE.getErrorCode(),
        ManualLoaderError.EXCEPTION_WHILE_PARSING_INPUT_DATE.getErrorDesc() + strDate + " : Expected Format : " + ManualLoaderConstants.MMM_DD_HH_MM_SS_YYYY);
    }
    return currentDate;
  }

  public static Float getConvertedOccurResetTime(Date input) throws LoaderException {
    try {
      SimpleDateFormat sdf = new SimpleDateFormat(ManualLoaderConstants.MM_DD_YY_HH_MM_SS);
      sdf.setTimeZone(new SimpleTimeZone(0, ManualLoaderConstants.GMT));
      long argMilliSeconds = input.getTime();
      long gmtMilliSeconds = sdf.parse(BASE_GMT_TIME_01_01_1987_05_00_00).getTime();
      return (float) (argMilliSeconds - gmtMilliSeconds) / (60 * 60 * 1000);
    } catch (ParseException e) {
      throw new LoaderException(ManualLoaderError.EXCEPTION_WHILE_PARSING_RESET_DATE.getErrorCode(),
        ManualLoaderError.EXCEPTION_WHILE_PARSING_RESET_DATE.getErrorDesc() + input + " : Expected Format : " + ManualLoaderConstants.MMM_DD_HH_MM_SS_YYYY);
    }
  }

  public static String checkPreCurPost(String strPrePost) {
    String strReturnString = "''";
    if (strPrePost != null && !"".equals(strPrePost)) {
      if ("PRE:".equals(strPrePost.trim())) {
        strReturnString = ManualLoaderConstants.ONE_STRING;
      } else if ("POST:".equals(strPrePost.trim())) {
        strReturnString = ManualLoaderConstants.MINUS_ONE_STRING;
      } else {
        strReturnString = ManualLoaderConstants.ZERO_STRING;
      }
    }

    return strReturnString;
  }

  public static String convertKgSqcm2PSI(String kgSqCm) {
    double dPSI = 0.0D;
    if (StringUtils.isNotBlank(kgSqCm)) {
      double dkgSqCm = Double.parseDouble(kgSqCm);
      dPSI = dkgSqCm * 14.22334D;
    }
    return Double.toString(dPSI);
  }

  public static String convertCelsius2Farenheit(String celsius) {
    double farenheit = 0.0D;
    if (StringUtils.isNotBlank(celsius)) {
      double d2 = Double.parseDouble(celsius);
      farenheit = 1.8D * d2 + 32.0D;
    }
    return Double.toString(farenheit);
  }
  public static boolean set(Object object, String fieldName, Object fieldValue) {
    Class<?> clazz = object.getClass();
    while (clazz != null) {
      try {
        Field field = clazz.getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(object, fieldValue);
        return true;
      } catch (NoSuchFieldException e) {
        clazz = clazz.getSuperclass();
      } catch (Exception e) {
        throw new LoaderRuntimeException(ManualLoaderError.EXCEPTION_WHILE_SETTING_PARSED_VALUES.getErrorCode(),
          ManualLoaderError.EXCEPTION_WHILE_SETTING_PARSED_VALUES.getErrorDesc() + ":" + e.getMessage());
      }
    }
    return false;
  }
}
