package com.ge.trans.loader.manual.bs.decoder.api;

import java.util.List;

import com.ge.trans.loader.common.exception.LoaderException;
import com.ge.trans.loader.manual.bs.data.domain.valueobjects.BSDecodedResponse;
import com.ge.trans.loader.manual.common.data.response.ParamDefinition;
import com.ge.trans.loader.manual.common.data.response.VehicleDetailsResponse;
public interface BSMessageParserAPI {

    BSDecodedResponse decode(List<String> splittedFile, List<ParamDefinition> paramDefinitions, VehicleDetailsResponse vInfo,Integer lastFaultIndex,Integer startIndicator) throws LoaderException;
    
}
