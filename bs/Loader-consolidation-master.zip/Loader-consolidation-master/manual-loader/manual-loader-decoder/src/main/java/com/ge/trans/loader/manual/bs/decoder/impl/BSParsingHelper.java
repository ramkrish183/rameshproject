package com.ge.trans.loader.manual.bs.decoder.impl;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import com.ge.trans.loader.common.exception.LoaderException;
import com.ge.trans.loader.manual.bs.decoder.domain.jaxb.KtzMessageVO.Incident.Field;
import com.ge.trans.loader.manual.bs.utils.BrightStarLoaderUtils;
import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;
import com.ge.trans.loader.manual.common.data.response.ParamDefinition;
import com.ge.trans.loader.manual.common.enums.ManualLoaderError;
import com.ge.trans.loader.manual.common.utils.ManualLoaderUtility;

public class BSParsingHelper {

  public String transformOrApplyDefaultValue(String value, Field field) {
    String tempValue = null;
    if (StringUtils.isNotBlank(field.getLogic()) && !StringUtils.equals(StringUtils.trim(value), StringUtils.EMPTY)) {
      tempValue = applyTransformationLogic(field.getLogic(), value);
    } else if (StringUtils.isNotBlank(field.getDefaultValue())) {
      tempValue = field.getDefaultValue();
    }
    return (StringUtils.isBlank(tempValue)) ? value : tempValue.trim();
  }

  public String validateFaultResetDateAndTime(String value, Field field) throws LoaderException {
    if (StringUtils.equalsIgnoreCase(field.getName(), ManualLoaderConstants.FAULT_RESET_DATE)
      || StringUtils.equalsIgnoreCase(field.getName(), ManualLoaderConstants.FAULT_RESET_TIME)) {
      if (StringUtils.isBlank(value)) {
        return StringUtils.EMPTY;
      } else if (StringUtils.equals(StringUtils.trim(value), "0.0")) {
        return StringUtils.EMPTY;
      }
    }
    return value;
  }

  public void validateOccurDateAndTime(String value, Field field) throws LoaderException {
    if ((StringUtils.equalsIgnoreCase(field.getName(), ManualLoaderConstants.OCCUR_DATE) || StringUtils.equalsIgnoreCase(field.getName(), ManualLoaderConstants.OCCUR_TIME))
      && (StringUtils.isBlank(value))) {
      throw new LoaderException(ManualLoaderError.EMPTY_INPUT_DATE.getErrorCode(), ManualLoaderError.EMPTY_INPUT_DATE.getErrorDesc() + ManualLoaderConstants.OCCUR_DATE);
    }
  }

  public String applyTransformationLogic(String logic, String fieldData) {
    String className = logic.substring(0, logic.indexOf(ManualLoaderConstants.TILDE_SYMBOL));
    String methodName = logic.substring(logic.indexOf(ManualLoaderConstants.TILDE_SYMBOL) + 1, logic.length());
    return BrightStarLoaderUtils.callClassMethod(className, methodName, fieldData);
  }

  public void processingEngrBitColumns(String strMPData, Map<String, Object> mpColumnNameValue, List<ParamDefinition> paramDefinitions) throws LoaderException {
    if (StringUtils.isBlank(strMPData) || CollectionUtils.isEmpty(paramDefinitions)) {
      throw new LoaderException(ManualLoaderError.BS_ENGINEERING_PARMS_EMPTY.getErrorCode(), ManualLoaderError.BS_ENGINEERING_PARMS_EMPTY.getErrorDesc());
    }

    Long lngMPBinaryValue = Long.parseLong(strMPData.trim(), 16);
    String strMpBinaryValue = Long.toBinaryString(lngMPBinaryValue);
    for (Iterator<ParamDefinition> iterator = paramDefinitions.iterator(); iterator.hasNext();) {
      ParamDefinition paramDefinition = iterator.next();
      String strHexValue = mpBitPackLogic(strMpBinaryValue, paramDefinition.getStartBit().intValue(), paramDefinition.getBitToCount().intValue());
      mpColumnNameValue.put(paramDefinition.getParamLoadColumn(), strHexValue);
    }
  }

  private String mpBitPackLogic(String strMpBinaryValue, int startBit, int bitToCount) {
    int binLength = 0;
    long bits = 0;
    String strHexValue = null;
    int noOFBitsRequired = 0;
    int totalBits = 0;
    totalBits = bitToCount + startBit;
    if (StringUtils.isBlank(strMpBinaryValue)) {
      return null;
    }
    binLength = strMpBinaryValue.length();
    String tempMPBinaryValue = strMpBinaryValue;
    if (binLength < (totalBits)) {
      noOFBitsRequired = totalBits - binLength;
      for (int i = 0; i <= noOFBitsRequired; i++) {
        tempMPBinaryValue = ManualLoaderConstants.ZERO_STRING + tempMPBinaryValue;
      }
    }
    binLength = tempMPBinaryValue.length();
    bits = Long.parseLong(tempMPBinaryValue.substring((binLength - (startBit + bitToCount)), (binLength - startBit)), 2);
    strHexValue = Long.toHexString(bits);
    return strHexValue != null ? String.valueOf(Long.parseLong(strHexValue, 16)) : null;

  }

  /**
   * @param faultdataEndposition
   * @param splittedInputData
   * @return
   */
  public String extractValuesFromList(int faultdataEndposition, List<String> splittedInputData) {
    String extractedValue = ManualLoaderConstants.EMPTY;
    if (splittedInputData.size() >= faultdataEndposition) {
      extractedValue = StringUtils.substring(splittedInputData.get(faultdataEndposition), 24, 32).trim();
      return ManualLoaderUtility.isFloatingPointNumber(extractedValue) ? extractedValue : ManualLoaderConstants.EMPTY;
    }
    return extractedValue;
  }

}
