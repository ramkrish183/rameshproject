package com.ge.trans.loader.manual.bs.decoder.impl;

import java.io.File;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.common.exception.LoaderException;
import com.ge.trans.loader.common.exception.LoaderRuntimeException;
import com.ge.trans.loader.manual.bs.data.domain.valueobjects.BSDecodedResponse;
import com.ge.trans.loader.manual.bs.data.domain.valueobjects.BSStatisticsVO;
import com.ge.trans.loader.manual.bs.data.domain.valueobjects.FaultSnapshotWrapper;
import com.ge.trans.loader.manual.bs.data.domain.valueobjects.LocoFault;
import com.ge.trans.loader.manual.bs.decoder.api.BSMessageParserAPI;
import com.ge.trans.loader.manual.bs.decoder.domain.jaxb.KtzMessageVO;
import com.ge.trans.loader.manual.bs.decoder.domain.jaxb.KtzMessageVO.Incident.Field;
import com.ge.trans.loader.manual.bs.utils.BrightStarLoaderUtils;
import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;
import com.ge.trans.loader.manual.common.data.response.ParamDefinition;
import com.ge.trans.loader.manual.common.data.response.VehicleDetailsResponse;
import com.ge.trans.loader.manual.common.enums.ManualLoaderError;
import com.ge.trans.loader.manual.common.utils.ManualLoaderUtility;

public class BSMessageParserImpl implements BSMessageParserAPI {
    private static final String PERCENTAGE_SYMBOL = "%";
    private String xmlPath;
    private KtzMessageVO ktzJaxBVo;
    public BSParsingHelper bsParsingHelper;
    private static final Logger LOGGER = LoggerFactory.getLogger(BSMessageParserImpl.class);
    
    public void init() throws LoaderException {
        try {
            File file = new File(xmlPath);
            JAXBContext jaxbContext = JAXBContext.newInstance(KtzMessageVO.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            setKtzJaxBVo((KtzMessageVO) jaxbUnmarshaller.unmarshal(file));
        } catch (JAXBException ex) {
            processException(ex);
        } catch (Exception ex) {
            processException(ex);
        }
    }
    
    @Override
    public BSDecodedResponse decode(List<String> splittedFile, List<ParamDefinition> paramDefinitions, VehicleDetailsResponse vInfo, Integer lastFaultIndex,Integer startIndicator) throws LoaderException {
        if (splittedFile == null) {
            throw new LoaderRuntimeException(ManualLoaderError.FILE_LIST_EMPTY_EXCEPTION.getErrorCode(), ManualLoaderError.FILE_LIST_EMPTY_EXCEPTION.getErrorDesc());
        }
        BSDecodedResponse decodedResponse = processTextData(splittedFile, paramDefinitions, vInfo, lastFaultIndex,startIndicator);
        return decodedResponse;
    }
    
    private BSDecodedResponse processTextData(List<String> splittedInputData, List<ParamDefinition> paramDefinitions, VehicleDetailsResponse vehicleInfo, Integer lastFaultIndex,Integer startIndicator)
            throws LoaderException {
        BSDecodedResponse decodedResponse = new BSDecodedResponse();
        try {
            int faultendposition = lastFaultIndex;
            for (int lineNumber = 12; lineNumber <= faultendposition; lineNumber += 3) {
                if (splittedInputData.get(lineNumber) == null || splittedInputData.get(lineNumber).trim().isEmpty()) {
                    continue;
                }
                processIncidentSnapshotData(splittedInputData, paramDefinitions, vehicleInfo,
                        decodedResponse, lineNumber);
            }
            if (faultendposition == 0) {
                faultendposition = /*12*/startIndicator;
            }
            BSStatisticsVO bsStatisticsVO = new BSStatisticsVO();
            parseStatistics(faultendposition - 1, splittedInputData, bsStatisticsVO, decodedResponse);
            decodedResponse.setBsStatisticsVO(bsStatisticsVO);
            
        } catch (LoaderException e) {
            LOGGER.error("Exception while parsing Input File. Error Code {}, Error Message {}", e.getErrorCode(), e.getErrorMessage());
            throw new LoaderException(e.getErrorCode(), e.getErrorMessage());
        } catch (Exception ex) {
            LOGGER.error("BRIGHT STAR IS UNABLE TO PARSE  THE TEXT ");
            throw new LoaderException(ManualLoaderError.EXCEPTION_WHILE_PARSING_TEXT_DATA.getErrorCode(), ManualLoaderError.EXCEPTION_WHILE_PARSING_TEXT_DATA.getErrorDesc());
        }
        
        return decodedResponse;
    }
    
    /**
     * @param splittedInputData
     * @param paramDefinitions
     * @param vehicleInfo
     * @param decodedResponse
     * @param monitoringParamMaps
     * @param lineNumber
     * @return
     * @throws LoaderException
     * @throws Exception
     */
    private void processIncidentSnapshotData(List<String> splittedInputData,
            List<ParamDefinition> paramDefinitions, VehicleDetailsResponse vehicleInfo, BSDecodedResponse decodedResponse, int lineNumber) {
        List<Map<String, Object>> monitoringParamMaps = null;
        FaultSnapshotWrapper wrapper = null;
        try {
            for (int index = lineNumber; index <= (lineNumber + 2); index++) {
                if (index % 3 == 0) {
                    monitoringParamMaps = new ArrayList<Map<String, Object>>();
                    wrapper = new FaultSnapshotWrapper();
                    wrapper.setMonitoringParamMaps(monitoringParamMaps);
                    wrapper.setLocoFault(parseIncidentData(splittedInputData.get(index)));
                    wrapper.getLocoFault().setFault2vehicle(Long.toString(vehicleInfo.getVehicleObjid()));
                    parseSnapShotData(splittedInputData.get(index), monitoringParamMaps, paramDefinitions, decodedResponse);
                } else {
                    parseSnapShotData(splittedInputData.get(index), monitoringParamMaps, paramDefinitions, decodedResponse);
                }
            }
            decodedResponse.getFaultAndSnapshots().add(wrapper);
        } catch (LoaderException loaderException) {
            LOGGER.error("Error while parsing Incident and Snapshot Data");
            decodedResponse.getErrorList().add(loaderException);
        } catch (Exception e) {
            LOGGER.error("Error while parsing Incident and Snapshot Data");
            decodedResponse.getErrorList()
            .add(new LoaderException(ManualLoaderError.EXCEPTION_WHILE_PARSING_FAULT_DATA.getErrorCode(), ManualLoaderError.EXCEPTION_WHILE_PARSING_FAULT_DATA.getErrorDesc()));
        }
        
    }
    
    private LocoFault parseIncidentData(String line) throws LoaderException {
        List<KtzMessageVO.Incident.Field> incidentFieldList = null;
        String value = null;
        LocoFault locoFault = new LocoFault();
        String columnName = null;
        try {
            incidentFieldList = getKtzJaxBVo().getIncident().getField();
            for (Field field : incidentFieldList) {
                columnName = field.getName();
                if (StringUtils.length(line) > field.getStartPos()) {
                    if (StringUtils.length(line) < field.getEndPos()) {
                        value = line.substring(field.getStartPos());
                    } else {
                        value = line.substring(field.getStartPos(), field.getEndPos());
                    }
                    bsParsingHelper.validateOccurDateAndTime(value, field);
                    value = bsParsingHelper.validateFaultResetDateAndTime(value, field);
                    value = bsParsingHelper.transformOrApplyDefaultValue(value, field);
                    BrightStarLoaderUtils.set(locoFault, field.getName(), value);
                } else if (StringUtils.isNotBlank(field.getDefaultValue())) {
                    value = field.getDefaultValue();
                    BrightStarLoaderUtils.set(locoFault, field.getName(), value);
                }
            }
        } catch (LoaderException ex) {
            throw ex;
        } catch (Exception e) {
            LOGGER.error("Exception while parsing Fault data , Line : {},  Column Name: {}, Value : {}", line, columnName, value);
            String errorMessageDetails = "  Line : " + line + ",  Column Name: " + columnName + ", Value : " + value;
            throw new LoaderException(ManualLoaderError.EXCEPTION_WHILE_PARSING_FAULT_DATA.getErrorCode(), ManualLoaderError.EXCEPTION_WHILE_PARSING_FAULT_DATA.getErrorDesc()
                    + errorMessageDetails);
        }
        return locoFault;
    }
    
    private void parseSnapShotData(String line, List<Map<String, Object>> monitoringParamMaps, List<ParamDefinition> paramDefinitions, BSDecodedResponse decodedResponse) {
        String columnName = null;
        String value = null;
        try {
            List<KtzMessageVO.Snapshot.Field> snapShotFields = getKtzJaxBVo().getSnapshot().getField();
            Map<String, Object> mpColumnNameValue = new HashMap<String, Object>();
            for (com.ge.trans.loader.manual.bs.decoder.domain.jaxb.KtzMessageVO.Snapshot.Field field : snapShotFields) {
                if (StringUtils.length(line) > field.getEndPos() && StringUtils.length(line) > field.getStartPos() && StringUtils.isNotBlank(field.getName())) {
                    value = line.substring(field.getStartPos(), field.getEndPos());
                    columnName = field.getName();
                    if (StringUtils.equalsIgnoreCase(field.getName(), ManualLoaderConstants.MP_ENGR_BITS)) {
                        bsParsingHelper.processingEngrBitColumns(value, mpColumnNameValue, paramDefinitions);
                    } else if (StringUtils.isNotBlank(field.getDefaultValue())) {
                        value = field.getDefaultValue();
                    }
                    if (StringUtils.isNotBlank(field.getLogic())) {
                        value = bsParsingHelper.applyTransformationLogic(field.getLogic(), value);
                    }
                    value = (StringUtils.isBlank(value)) ? value : value.trim();
                    mpColumnNameValue.put(field.getName(), value);
                }
            }
            monitoringParamMaps.add(mpColumnNameValue);
        } catch (LoaderException loaderException) {
            LOGGER.error("Error while parsing Incident and Snapshot Data");
            decodedResponse.getErrorList().add(loaderException);
        } catch (Exception e) {
            LOGGER.error("Exception while parsing MP data , Line : {},  Column Name: {}, Value : {}", line, columnName, value);
            String errorMessageDetails = "  Line : " + line + ",  Column Name: " + columnName + ", Value : " + value;
            decodedResponse.getErrorList()
            .add(new LoaderException(ManualLoaderError.EXCEPTION_WHILE_PARSING_MP_DATA.getErrorCode(), ManualLoaderError.EXCEPTION_WHILE_PARSING_MP_DATA.getErrorDesc()
                    + e.getMessage() + errorMessageDetails));
        }
        
    }
    
    private void parseStatistics(int faultdataEndposition, List<String> splittedInputData, BSStatisticsVO bsStatisticsVO, BSDecodedResponse decodedResponse) throws LoaderException {
        try {
            double dMotoringMwHr = 0;
            int lineIndex = faultdataEndposition + 2;
            String motorValue = bsParsingHelper.extractValuesFromList(lineIndex, splittedInputData);
            dMotoringMwHr = ManualLoaderUtility.convertToMWHrs(motorValue);
            bsStatisticsVO.setMotorMWHrs(Double.toString(dMotoringMwHr));
            String distanceKM = bsParsingHelper.extractValuesFromList(faultdataEndposition + 5, splittedInputData);
            bsStatisticsVO.setTotalMiles(ManualLoaderUtility.convertKmtoMiles(Double.parseDouble(distanceKM)));
            
            bsStatisticsVO.setIdleHours(bsParsingHelper.extractValuesFromList(faultdataEndposition + 7, splittedInputData));
            bsStatisticsVO.setN1Param(bsParsingHelper.extractValuesFromList(faultdataEndposition + 8, splittedInputData));
            bsStatisticsVO.setN2Param(bsParsingHelper.extractValuesFromList(faultdataEndposition + 9, splittedInputData));
            bsStatisticsVO.setN3Param(bsParsingHelper.extractValuesFromList(faultdataEndposition + 10, splittedInputData));
            bsStatisticsVO.setN4Param(bsParsingHelper.extractValuesFromList(faultdataEndposition + 11, splittedInputData));
            bsStatisticsVO.setN5Param(bsParsingHelper.extractValuesFromList(faultdataEndposition + 12, splittedInputData));
            bsStatisticsVO.setN6Param(bsParsingHelper.extractValuesFromList(faultdataEndposition + 13, splittedInputData));
            bsStatisticsVO.setN7Param(bsParsingHelper.extractValuesFromList(faultdataEndposition + 14, splittedInputData));
            bsStatisticsVO.setN8Param(bsParsingHelper.extractValuesFromList(faultdataEndposition + 15, splittedInputData));
            //  bsStatisticsVO.setTotalEngHours(bsParsingHelper.extractValuesFromList(faultdataEndposition + 16, splittedInputData));
            bsStatisticsVO.setTotalEngHours(findTotalEnghours(faultdataEndposition + 16, splittedInputData));
        } catch (Exception e) {
            LOGGER.error("Exception while parsing Statistics data , line number {}", faultdataEndposition);
            LoaderException exception = new LoaderException(ManualLoaderError.EXCEPTION_WHILE_PARSING_STATISTICS_DATA.getErrorCode(),
                    ManualLoaderError.EXCEPTION_WHILE_PARSING_STATISTICS_DATA.getErrorDesc());
            decodedResponse.getErrorList().add(exception);
            
        }
    }
    private String findTotalEnghours(int position,List<String> splittedInputData ){
        String value="";
        for(int  index=position;index<splittedInputData.size();index++){
            value=bsParsingHelper.extractValuesFromList(index, splittedInputData);
            if( !splittedInputData.get(index).contains(PERCENTAGE_SYMBOL)){
                break;
            }
        }
        return value;
    }
    private void processException(Exception ex) throws LoaderException {
        StringWriter errors = new StringWriter();
        ex.printStackTrace(new PrintWriter(errors));
        LOGGER.error("BRIGHT STAR IS UNABLE TO LOAD THE RULE DEFINITION FILE" + ":EXCEPTION TRACE:" + errors);
        throw new LoaderException(ManualLoaderError.EXCEPTION_WHILE_LOADING_KTZ_MESSAGE_DEFINITION.getErrorCode(),
                ManualLoaderError.EXCEPTION_WHILE_LOADING_KTZ_MESSAGE_DEFINITION.getErrorDesc());
    }
    
    public void setXmlPath(String xmlPath) {
        this.xmlPath = xmlPath;
    }
    
    /**
     * @return the ktzJaxBVo
     */
    public KtzMessageVO getKtzJaxBVo() {
        return ktzJaxBVo;
    }
    
    /**
     * @param ktzJaxBVo the ktzJaxBVo to set
     */
    public void setKtzJaxBVo(KtzMessageVO ktzJaxBVo) {
        this.ktzJaxBVo = ktzJaxBVo;
    }
    
    /**
     * @param bsParsingHelper the bsParsingHelper to set
     */
    public void setBsParsingHelper(BSParsingHelper bsParsingHelper) {
        this.bsParsingHelper = bsParsingHelper;
    }
    
}
