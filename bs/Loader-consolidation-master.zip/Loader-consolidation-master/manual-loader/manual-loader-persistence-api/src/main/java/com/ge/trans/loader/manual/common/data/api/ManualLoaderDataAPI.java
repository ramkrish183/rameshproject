package com.ge.trans.loader.manual.common.data.api;

import java.math.BigDecimal;
import java.util.List;

import com.ge.trans.loader.manual.bs.data.domain.valueobjects.LocoFault;
import com.ge.trans.loader.manual.common.data.request.FaultCodeRequest;
import com.ge.trans.loader.manual.common.data.request.MonitoringParamRequest;
import com.ge.trans.loader.manual.common.data.request.VehicleDetailsRequest;
import com.ge.trans.loader.manual.common.data.response.FaultCodeDefinition;
import com.ge.trans.loader.manual.common.data.response.ParamDefinition;
import com.ge.trans.loader.manual.common.data.response.VehicleDetailsResponse;

public interface ManualLoaderDataAPI {
     VehicleDetailsResponse findVehicleDetails(VehicleDetailsRequest request);    
     List<ParamDefinition> findParamDefinition(MonitoringParamRequest request);    
     FaultCodeDefinition findFaultCodeDefinition(FaultCodeRequest request);
     BigDecimal findFaultObjid(LocoFault locoFault);     
     int updateToolRunNextwithFCT(VehicleDetailsResponse vehicleDetails, double faultCollectionTime, String programName);    
     int getToolFaultRecordCount(String recordType,String lookupBackTime, long vehicleObjid);     
     String getRmdSysParmValue(String title);    
     Long getMessageIdSequenceValue();
     
     
}