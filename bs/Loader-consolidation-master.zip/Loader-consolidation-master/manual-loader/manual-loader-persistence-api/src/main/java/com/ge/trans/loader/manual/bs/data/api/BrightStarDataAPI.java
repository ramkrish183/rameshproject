package com.ge.trans.loader.manual.bs.data.api;


import com.ge.trans.loader.manual.bs.data.domain.valueobjects.FaultSnapshotWrapper;

/**
 * An interface for DECLARING BRIGHT-STAR  PERSISTENCE  SERVICES.
 */
public interface BrightStarDataAPI {
    void saveIncidentAndSnapshot(FaultSnapshotWrapper input);
    
    
}