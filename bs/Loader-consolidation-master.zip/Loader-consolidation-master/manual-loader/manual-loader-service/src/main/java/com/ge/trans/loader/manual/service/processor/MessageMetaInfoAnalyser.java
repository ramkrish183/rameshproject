package com.ge.trans.loader.manual.service.processor;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;

import com.ge.trans.loader.common.constant.CommonConstants;
import com.ge.trans.loader.common.exception.LoaderException;
import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;
import com.ge.trans.loader.manual.common.data.request.VehicleDetailsRequest;

public class MessageMetaInfoAnalyser implements Processor {

  private static final Logger LOGGER = LoggerFactory.getLogger(MessageMetaInfoAnalyser.class);

  @SuppressWarnings("unchecked")
  @Override
  public void process(Exchange exchange) throws LoaderException {
    List<String> splittedFile = exchange.getProperty(ManualLoaderConstants.SPLITTED_FILE, List.class);
    populateCamelExchange(exchange, ManualLoaderConstants.NA, ManualLoaderConstants.NA, ManualLoaderConstants.NA, ManualLoaderConstants.NA, ManualLoaderConstants.MESSAGE_TYPE_BS);
    logFileParameters(exchange);

    String textMessage = splittedFile.get(ManualLoaderConstants.ZERO_INDEX);
    String fileName = exchange.getIn().getHeader(Exchange.FILE_NAME_ONLY, String.class);
    setCamelExchangeProperties(exchange, ManualLoaderConstants.FILE_NAME, fileName);
    exchange.getOut().setBody(textMessage);

    String vehicleNumberFromFile = extractVehicleNo(textMessage);
    // Remove all leading zeros
    String vehicleNo=vehicleNumberFromFile.replaceFirst(ManualLoaderConstants.REGEX_FIND_ALL_LEADING_ZEROS_PATTERN, CommonConstants.EMPTY_STRING);
    // Remove one leading zeros
    String eservicesVehicleNo=vehicleNumberFromFile.replaceFirst(ManualLoaderConstants.REGEX_FIND_ONE_LEADING_ZERO_PATTERN, CommonConstants.EMPTY_STRING);
    String cabCaxTime = formCabCaxDateTime(textMessage);
    String customerId = textMessage.substring(0, 5).trim();
    String vehicleInitial = customerId;
    String headerDate = cabCaxTime;
    LOGGER.info("### CUSTOMER NAME:{}:Vehicle NUMBER:{}:Vehicle Header : {}: cabCaxTime:{} ###", customerId, vehicleNo, vehicleInitial, cabCaxTime);

    populateVehicleInfoRequest(exchange, vehicleNo, customerId,eservicesVehicleNo);

    setCamelExchangeProperties(exchange, ManualLoaderConstants.CAB_CAX_TIME, cabCaxTime);

    long startTime = System.currentTimeMillis();

    StringBuilder messageUUID = prepareMessageUUID(vehicleNo, customerId, vehicleInitial, headerDate, startTime);

    String messageType = ManualLoaderConstants.MESSAGE_TYPE_BS;

    populateCamelExchange(exchange, vehicleNo, vehicleInitial, customerId, messageUUID.toString(), messageType);

    exchange.setProperty(CommonConstants.START_TIME, startTime);
    exchange.setProperty(ManualLoaderConstants.ACTUAL_FAULTS_PROCESSED, new ArrayList<Integer>());

    populateMDCParams(exchange, vehicleNo, customerId, vehicleInitial, messageUUID, messageType);

  }

  /**
   * @param exchange
   * @param vehicleNo
   * @param customerId
   * @param vehicleInitial
   * @param messageUUID
   * @param messageType
   */
  private void populateMDCParams(Exchange exchange, String vehicleNo, String customerId, String vehicleInitial,
    StringBuilder messageUUID, String messageType) {
    MDC.put(ManualLoaderConstants.APP_NAME, exchange.getProperty(ManualLoaderConstants.PROGRAM_NAME, String.class));
    MDC.put(ManualLoaderConstants.LOCO_ID, prepareMDCLocoId(customerId, vehicleInitial, vehicleNo));
    MDC.put(ManualLoaderConstants.LOCO_MSG_TYPE, messageType);
    MDC.put(ManualLoaderConstants.MSGUUID, messageUUID.toString());
    LOGGER.debug("||==Received a valid message from {}, of message type {} . Required MDC properties are set for logging.==||", MDC.get(ManualLoaderConstants.LOCO_ID),
      MDC.get(ManualLoaderConstants.LOCO_MSG_TYPE));
  }

  /**
   * @param exchange
   * @param vehicleNo
   * @param customerId
   */
  private void populateVehicleInfoRequest(Exchange exchange, String vehicleNo, String customerId, String eservicesVehicleNo) {
    VehicleDetailsRequest vehicledetailsrequest = new VehicleDetailsRequest();
    vehicledetailsrequest.setCustomerId(customerId);
    vehicledetailsrequest.setVehicleInitial(customerId);
    vehicledetailsrequest.setVehicleNumber(vehicleNo);
    vehicledetailsrequest.setEservicesVehicleNo(eservicesVehicleNo);
    exchange.setProperty(ManualLoaderConstants.VEHICLE_REQUEST, vehicledetailsrequest);
  }

  /**
   * @param vehicleNo
   * @param customerId
   * @param vehicleInitial
   * @param headerDate
   * @param startTime
   * @return
   */
  private StringBuilder prepareMessageUUID(String vehicleNo, String customerId, String vehicleInitial,
    String headerDate, long startTime) {
    StringBuilder messageUUID = new StringBuilder();
    prepareHeader(messageUUID, customerId, false);// CUSTOMER ID
    prepareHeader(messageUUID, vehicleInitial, false);// INITIAL
    prepareHeader(messageUUID, vehicleNo, false);// VEHICLE NUMBER
    prepareHeader(messageUUID, headerDate, false);// MESSAGE HEADER DATE
    prepareHeader(messageUUID, startTime + CommonConstants.EMPTY_STRING, true);
    return messageUUID;
  }

  private void populateCamelExchange(Exchange exchange, String vehicleNo, String vehicleInitial, String customerId, String messageUID, String messageType) {
    setCamelExchangeProperties(exchange, CommonConstants.VEHICLENUMBER, vehicleNo);
    setCamelExchangeProperties(exchange, CommonConstants.VEHICLEINITIAL, vehicleInitial);
    setCamelExchangeProperties(exchange, CommonConstants.CUSTOMERID, customerId);
    setCamelExchangeProperties(exchange, CommonConstants.MESSAGE_ID, messageUID);
    setCamelExchangeProperties(exchange, CommonConstants.MESSAGE_TYPE, messageType);
  }

  /**
   * Append given values to the messageUUID field
   * 
   * @param headerVO
   * @param messageUUID
   */
  protected void prepareHeader(StringBuilder messageUUID, String value, boolean lastElement) {
    if (value != null && !value.trim().equals("")) {
      messageUUID.append(value.replaceAll("[\\s\\.:/]", "_"));
      if (!lastElement) {
        messageUUID.append(CommonConstants.UNDERSCORE);
      }
    }

  }

  /**
   * Prepare the MDC id for logging
   * 
   * @param headerVO
   * @return
   */
  protected String prepareMDCLocoId(String customerId, String vInitial, String roadNumber) {
    return new StringBuilder(customerId).append(CommonConstants.COLON_STR).append(vInitial).append(CommonConstants.COLON_STR).append(roadNumber).toString();
  }

  /**
   * @param firstLine
   * @return
   */
  private String formCabCaxDateTime(String firstLine) {
    return firstLine.substring(28, 39).trim() + ManualLoaderConstants.ONE_SPACE_STRING
      + firstLine.substring(42, 50).trim();
  }

  private void logFileParameters(Exchange exchange) {
    String fileName = exchange.getIn().getHeader(Exchange.FILE_NAME_ONLY, String.class);
    String fileLength = exchange.getIn().getHeader(Exchange.FILE_LENGTH, String.class);
    String hostName = exchange.getIn().getHeader(ManualLoaderConstants.CAMEL_FILE_HOST, String.class);
    LOGGER.debug("CREATED BY {}", exchange.getProperty("createdBy"));
    LOGGER.debug("programName  {}", exchange.getProperty("programName"));
    LOGGER.debug("HOST NAME:{}:FILE NAME:{}:FILE LENGTH:{}", hostName, fileName, fileLength);
  }

  private void setCamelExchangeProperties(Exchange exchange, String propertyName, String value) {
    exchange.setProperty(propertyName, value);
  }

  private String extractVehicleNo(String firstLine) {
    int lastIndex = (firstLine.length() >= 70) ? 70 : firstLine.length();
    // changed to 70 to pick the last alphabet 509B
    String vehicleNo = firstLine.substring(ManualLoaderConstants.BRIGHTSTAR_FILE_VEHICLENO_START_POSITION, lastIndex).trim();
    return vehicleNo;
  }

}
