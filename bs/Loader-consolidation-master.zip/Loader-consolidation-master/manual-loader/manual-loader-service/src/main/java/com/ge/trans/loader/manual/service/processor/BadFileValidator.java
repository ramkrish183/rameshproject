package com.ge.trans.loader.manual.service.processor;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.ge.trans.loader.manual.bs.data.domain.valueobjects.BSDecodedResponse;
import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;

public class BadFileValidator implements Processor {
    private static final String DATA_START_INDICATOR = "DATA_START_INDICATOR";
    private static final String IS_BAD_FILE = "IS_BAD_FILE";
    private String faultTolerance;
    
    @Override
    public void process(Exchange exchange) throws Exception {
        BSDecodedResponse response = exchange.getIn().getBody(BSDecodedResponse.class);
        int maxTolerance=0;
        try {
            maxTolerance = Integer.parseInt(faultTolerance);
        } catch (Exception e) {
            maxTolerance = 10;
        }
        if (response.getErrorList().size() > maxTolerance) {
            String[] fileParts = exchange.getProperty(Exchange.FILE_NAME_ONLY, String.class).split("\\.");
            StringBuilder newFileBuilder = new StringBuilder();
            newFileBuilder.append(fileParts[0]).append("-").append(System.currentTimeMillis()).append(".").append(fileParts[1]);
            exchange.getIn().setHeader(Exchange.FILE_NAME, newFileBuilder.toString());
            exchange.setProperty(IS_BAD_FILE, true);
        } else if (exchange.getProperty(DATA_START_INDICATOR, Integer.class) == 0 && exchange.getProperty(ManualLoaderConstants.LAST_FAULT_INDEX, Integer.class) == 0) {
            exchange.setProperty(IS_BAD_FILE, true);
        }
    }
    
    public void setFaultTolerance(String faultTolerance) {
        this.faultTolerance = faultTolerance;
    }
}
