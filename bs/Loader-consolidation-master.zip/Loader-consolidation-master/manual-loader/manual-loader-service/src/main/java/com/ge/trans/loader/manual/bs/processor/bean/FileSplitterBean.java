package com.ge.trans.loader.manual.bs.processor.bean;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;

public class FileSplitterBean {
    
    
    private static final Logger LOGGER = LoggerFactory.getLogger(FileSplitterBean.class);
    
    public Object init(Exchange exchange) {
        exchange.setProperty(ManualLoaderConstants.SPLITTED_FILE, new LinkedList<String>());
        exchange.setProperty(ManualLoaderConstants.LAST_FAULT_INDEX_LIST, new ArrayList<Integer>(1));
        exchange.setProperty("DATA_START_INDICATOR_LIST", new ArrayList<Integer>(1));
        return exchange.getIn().getBody();
    }
    
    @SuppressWarnings("unchecked")
    public void addSplittedLine(Exchange exchange) {
        String line = exchange.getIn().getBody(String.class);
        exchange.getProperty(ManualLoaderConstants.SPLITTED_FILE, List.class).add(line);
        if (StringUtils.contains(line, ManualLoaderConstants.POST)) {
            exchange.getProperty(ManualLoaderConstants.LAST_FAULT_INDEX_LIST, List.class).add(0, exchange.getProperty(Exchange.SPLIT_INDEX, Integer.class).intValue() + 1);
        }
        if(StringUtils.contains(line, "--------------")){
            exchange.getProperty("DATA_START_INDICATOR_LIST", List.class).add(0, exchange.getProperty(Exchange.SPLIT_INDEX, Integer.class).intValue() + 1);  
        }
    }
    
    public void done(Exchange exchange) {
        Integer lastFaultIndex = 0;
        Integer dataStartIndicator=0;
        LOGGER.info("SPLITTING OF FILE  COMPLETED:NUMBER OF LINES SPLITTED:{}", exchange.getProperty(ManualLoaderConstants.SPLITTED_FILE, List.class).size());
        if (exchange.getProperty(ManualLoaderConstants.LAST_FAULT_INDEX_LIST, List.class).size() > 0) {
            lastFaultIndex = (Integer) exchange.getProperty(ManualLoaderConstants.LAST_FAULT_INDEX_LIST, List.class).get(Integer.valueOf(0));
            LOGGER.info("LAST INDEX LOCATION OF FAULT FOUND IS:{}", lastFaultIndex);
        }
        if (exchange.getProperty("DATA_START_INDICATOR_LIST", List.class).size() > 0) {
            dataStartIndicator = (Integer) exchange.getProperty("DATA_START_INDICATOR_LIST", List.class).get(Integer.valueOf(0));
            LOGGER.info("DATA START INDICATOR LOCATION OF FILE IS:{}", dataStartIndicator);
        }
        exchange.setProperty(ManualLoaderConstants.LAST_FAULT_INDEX, lastFaultIndex);
        exchange.setProperty("DATA_START_INDICATOR", dataStartIndicator);
    }
    
}
