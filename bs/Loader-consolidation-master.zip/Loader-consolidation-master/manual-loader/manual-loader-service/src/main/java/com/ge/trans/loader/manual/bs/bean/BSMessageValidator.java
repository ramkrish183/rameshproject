package com.ge.trans.loader.manual.bs.bean;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.common.exception.LoaderException;
import com.ge.trans.loader.common.exception.LoaderRuntimeException;
import com.ge.trans.loader.manual.bs.data.domain.valueobjects.LocoFault;
import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;
import com.ge.trans.loader.manual.common.enums.ManualLoaderError;
import com.ge.trans.loader.manual.common.utils.ManualLoaderUtility;

/**
 * @author 502166888
 *
 */
public class BSMessageValidator {

  private static final Logger LOGGER = LoggerFactory.getLogger(BSMessageValidator.class);

  @SuppressWarnings("unchecked")
  public void validateInputMessage(Exchange messageExchange) throws LoaderException {
    LOGGER.info("Validating the Input Message- Start");
    List<String> splittedFile = messageExchange.getProperty(ManualLoaderConstants.SPLITTED_FILE, List.class);
    validateListSize(splittedFile);
    String firstLine = splittedFile.get(ManualLoaderConstants.ZERO_INDEX);
    LOGGER.debug("firstLine.length() " + firstLine.length());
    if (StringUtils.isNotBlank(firstLine) && firstLine.length() >= 64) {
      validateCustomerId(firstLine.substring(0, 5));
      validateCabCaxTime(formCabCaxDateTime(firstLine), ManualLoaderConstants.MM_DD_YYYY_HH_MM_SS);
      int lastIndex = (firstLine.length() >= 70) ? 70 : firstLine.length();
      validateVehicleNo(firstLine.substring(64, lastIndex).trim());
    } else {
      throw new LoaderException(ManualLoaderError.INVALID_FIRST_LINE.getErrorCode(), ManualLoaderError.INVALID_FIRST_LINE.getErrorDesc());
    }
    LOGGER.info("Validating the Input Message- End");
  }

  private void validateVehicleNo(String vehicleNo) throws LoaderException {
    if (!ManualLoaderUtility.isAlphaNumericString(vehicleNo.trim())) {
      LOGGER.error("Error while parsing VehicleNo : {}", vehicleNo);
      throw new LoaderException(ManualLoaderError.INVALID_VEHICLE_NUMBER.getErrorCode(), ManualLoaderError.INVALID_VEHICLE_NUMBER.getErrorDesc() + vehicleNo);
    }

  }

  private void validateCustomerId(String customerId) throws LoaderException {
    if (!ManualLoaderUtility.isAlphaString(customerId.trim())) {
      LOGGER.error("Error while parsing customerId : {}", customerId);
      throw new LoaderException(ManualLoaderError.INVALID_CUSTOMER_ID.getErrorCode(), ManualLoaderError.INVALID_CUSTOMER_ID.getErrorDesc() + customerId);
    }
  }

  private void validateListSize(List<String> splittedFile) throws LoaderException {
    if (CollectionUtils.sizeIsEmpty(splittedFile)) {
      throw new LoaderException(ManualLoaderError.FILE_LIST_EMPTY_EXCEPTION.getErrorCode(), ManualLoaderError.FILE_LIST_EMPTY_EXCEPTION.getErrorDesc());
    }
    if (splittedFile.size() < 15) {
      throw new LoaderException(ManualLoaderError.NO_INCIDENT_SNAPSHOT_DATA.getErrorCode(), ManualLoaderError.NO_INCIDENT_SNAPSHOT_DATA.getErrorDesc());
    }
  }

  private void validateCabCaxTime(String cabCaxTime, String format) throws LoaderException {
    if (!ManualLoaderUtility.validateDataFormat(cabCaxTime, format)) {
      LOGGER.error("Error while parsing cabcaxtime : {}", cabCaxTime);
      throw new LoaderException(ManualLoaderError.INVALID_CABCAXTIME.getErrorCode(), ManualLoaderError.INVALID_CABCAXTIME.getErrorDesc() + cabCaxTime);
    }
  }

  /**
   * @param firstLine
   * @return
   */
  private String formCabCaxDateTime(String firstLine) {
    return firstLine.substring(28, 39).trim() + ManualLoaderConstants.ONE_SPACE_STRING + firstLine.substring(42, 50).trim();
  }

  public void validateFaultCodes(LocoFault locofault) throws LoaderRuntimeException {
    String faultCodeObjid = locofault.getFault2faultCode();
    if (StringUtils.isNotBlank(faultCodeObjid)) {
      if (faultCodeObjid.equals(ManualLoaderConstants.MINUS_ONE_STRING)) {
        throw new LoaderRuntimeException(ManualLoaderError.INVALID_FAULT_CODES.getErrorCode(), ManualLoaderError.INVALID_FAULT_CODES.getErrorDesc() + locofault.getFaultCode()
          + " SubId : " + locofault.getSubId() + " Controller Source Id: " + locofault.getControllerSourceId());
      }
    } else if (StringUtils.isBlank((locofault.getFaultCode()))) {
      throw new LoaderRuntimeException(ManualLoaderError.INVALID_FAULT_CODES.getErrorCode(), ManualLoaderError.INVALID_FAULT_CODES.getErrorDesc() + locofault.getFaultCode()
        + " SubId : " + locofault.getSubId() + " Controller Source Id: " + locofault.getControllerSourceId());
    }

  }
}
