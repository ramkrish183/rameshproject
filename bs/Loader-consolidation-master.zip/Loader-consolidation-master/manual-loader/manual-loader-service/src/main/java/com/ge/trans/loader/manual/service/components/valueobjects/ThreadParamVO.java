package com.ge.trans.loader.manual.service.components.valueobjects;

/**
 * @author 502166888
 *
 */
public class ThreadParamVO {

  private int threadMaxPoolSize;
  private int threadPoolSize;
  private String rejectedPolicy;
  private int threadQueueSize;
  private String threadName;
  /**
   * @return the threadName
   */
  public String getThreadName() {
    return threadName;
  }
  /**
   * @param threadName the threadName to set
   */
  public void setThreadName(String threadName) {
    this.threadName = threadName;
  }
  /**
   * @return the threadMaxPoolSize
   */
  public int getThreadMaxPoolSize() {
    return threadMaxPoolSize;
  }
  /**
   * @return the threadPoolSize
   */
  public int getThreadPoolSize() {
    return threadPoolSize;
  }
  /**
   * @return the rejectedPolicy
   */
  public String getRejectedPolicy() {
    return rejectedPolicy;
  }
  /**
   * @return the threadQueueSize
   */
  public int getThreadQueueSize() {
    return threadQueueSize;
  }
  /**
   * @param threadMaxPoolSize the threadMaxPoolSize to set
   */
  public void setThreadMaxPoolSize(int threadMaxPoolSize) {
    this.threadMaxPoolSize = threadMaxPoolSize;
  }
  /**
   * @param threadPoolSize the threadPoolSize to set
   */
  public void setThreadPoolSize(int threadPoolSize) {
    this.threadPoolSize = threadPoolSize;
  }
  /**
   * @param rejectedPolicy the rejectedPolicy to set
   */
  public void setRejectedPolicy(String rejectedPolicy) {
    this.rejectedPolicy = rejectedPolicy;
  }
  /**
   * @param threadQueueSize the threadQueueSize to set
   */
  public void setThreadQueueSize(int threadQueueSize) {
    this.threadQueueSize = threadQueueSize;
  }
  
}
