package com.ge.trans.loader.manual.service.components;

import java.util.concurrent.ExecutorService;

import org.apache.camel.CamelContext;
import org.apache.camel.LoggingLevel;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.builder.ThreadPoolBuilder;

import com.ge.trans.loader.manual.service.components.valueobjects.SFTPParamVO;
import com.ge.trans.loader.manual.service.components.valueobjects.ThreadParamVO;

/**
 * @author 502166888
 *
 */
public class BrightStarFTPListener extends RouteBuilder {

  private SFTPParamVO paramVO;

  private String hostName;

  private boolean autoStartRoute;

  private ThreadParamVO threadParamVo;

  private String routeId;

  /**
   * @return the paramVO
   */
  public SFTPParamVO getParamVO() {
    return paramVO;
  }

  /**
   * @param paramVO the paramVO to set
   */
  public void setParamVO(SFTPParamVO paramVO) {
    this.paramVO = paramVO;
  }

  public String getValue() {
    return getParamVO().getHostName();
  }

  /*
   * (non-Javadoc)
   * 
   * @see org.apache.camel.builder.RouteBuilder#configure()
   */
  @Override
  public void configure() throws Exception {
    onException(Exception.class).handled(false).log(LoggingLevel.DEBUG, "EXCEPTION IN brightStarFTPMainRoute ${exception.message}").to("direct:logInvalidMessage");
    CamelContext context = getContext();
    
    ExecutorService executorService = new ThreadPoolBuilder(context).poolSize(getThreadParamVo().getThreadPoolSize()).maxQueueSize(getThreadParamVo().getThreadQueueSize())
      .maxPoolSize(getThreadParamVo().getThreadMaxPoolSize()).build(getThreadParamVo().getThreadName());
    
    from(getParamVO().getUri()).routeId(getRouteId()).autoStartup(autoStartRoute).routePolicyRef("mainRoutePolicy")
      .description("Primary FTP Listener for Brigth Star Loader, Supported for customer: Kazakhstan Temir Zholy (KTZ)")
      .threads().executorService(executorService)
      .log("Processing ${threadName} ${file:name.noext}")
      .processRef("fileValidator")
      .wireTap("direct:processTheFile")
      .log("###MESSAGE SENT FOR PROCESSING##");

  }

  /**
   * @return the hostName
   */
  public String getHostName() {
    return hostName;
  }

  /**
   * @param hostName the hostName to set
   */
  public void setHostName(String hostName) {
    this.hostName = hostName;
  }

  /**
   * @return the autoStartRoute
   */
  public boolean isAutoStartRoute() {
    return autoStartRoute;
  }

  /**
   * @param autoStartRoute the autoStartRoute to set
   */
  public void setAutoStartRoute(boolean autoStartRoute) {
    this.autoStartRoute = autoStartRoute;
  }

  /**
   * @return the threadParamVo
   */
  public ThreadParamVO getThreadParamVo() {
    return threadParamVo;
  }

  /**
   * @param threadParamVo the threadParamVo to set
   */
  public void setThreadParamVo(ThreadParamVO threadParamVo) {
    this.threadParamVo = threadParamVo;
  }

  /**
   * @return the routeId
   */
  public String getRouteId() {
    return routeId;
  }

  /**
   * @param routeId the routeId to set
   */
  public void setRouteId(String routeId) {
    this.routeId = routeId;
  }

}
