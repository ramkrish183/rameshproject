package com.ge.trans.loader.manual.bs.processor.bean;

import java.util.List;

import org.apache.camel.Exchange;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.common.exception.LoaderRuntimeException;
import com.ge.trans.loader.manual.bs.data.domain.valueobjects.FaultSnapshotWrapper;
import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;
import com.ge.trans.loader.manual.common.data.request.FaultCodeRequest;
import com.ge.trans.loader.manual.common.data.request.MonitoringParamRequest;
import com.ge.trans.loader.manual.common.data.response.FaultCodeDefinition;
import com.ge.trans.loader.manual.common.enums.ManualLoaderError;
import com.ge.trans.loader.manual.common.utils.ManualLoaderUtility;

public class RequestHelper {
    

    private static final Logger LOGGER = LoggerFactory.getLogger(RequestHelper.class);
    
    public MonitoringParamRequest prepareMPRequest() {
        MonitoringParamRequest request = new MonitoringParamRequest();
        request.setControllerSourceId(ManualLoaderConstants.BS_DEFAULT_CONTROLLER_SRC_ID);
        request.setParamNumber(ManualLoaderConstants.BS_DEFAULT_PARAM_NUMBER);
        request.setParamLoadColumn(ManualLoaderConstants.MP_ENGR_BITS_CAPS);
        return request;
    }
    
    public FaultCodeRequest prepareFaultCodeQueryKey(FaultSnapshotWrapper wrapper) {
        FaultCodeRequest request = new FaultCodeRequest();
        if (wrapper.getLocoFault().getFaultCode() == null) {
            throw new LoaderRuntimeException(ManualLoaderError.FAULT_CODE_IS_EMPTY.getErrorCode(),ManualLoaderError.FAULT_CODE_IS_EMPTY.getErrorDesc());
        }
        request.setFaultCode(wrapper.getLocoFault().getFaultCode());
        request.setSubId(wrapper.getLocoFault().getSubId());
        request.setControllerSourceID(wrapper.getLocoFault().getControllerSourceId());
        
        return request;
    }
    
    public void enrichFault2FaultCode(FaultCodeDefinition faultDefinition, FaultSnapshotWrapper wrapper) {
        if (faultDefinition != null && faultDefinition.getObjId() != null) {
            wrapper.getLocoFault().setFault2faultCode(faultDefinition.getObjId().toString());
            LOGGER.info("Fault Code {} | Ctrl Src Id {} | Sub Id {} | FAULT CODE OBJID {} | isCriticalFault [{}] | Fault Desc {} ", wrapper.getLocoFault().getFaultCode(), wrapper
                    .getLocoFault().getControllerSourceId(), wrapper.getLocoFault().getSubId(), faultDefinition.getObjId(), faultDefinition.getCriticalFlag(), faultDefinition
                    .getFaultDesc());
        } else {
        	
        	LOGGER.error("FAULT CODE NOT FOUND - UNABLE TO GET FAULT_OBJID FOR FAULT_CODE :" + wrapper.getLocoFault().getFaultCode() + " SUBID :"
                    + wrapper.getLocoFault().getSubId() + " and CONTROLLER_SOURCE_ID : " + wrapper.getLocoFault().getControllerSourceId());
            throw new LoaderRuntimeException(ManualLoaderError.INVALID_FAULT_CODES.getErrorCode(), ManualLoaderError.INVALID_FAULT_CODES.getErrorDesc() + wrapper.getLocoFault().getFaultCode() + " SUBID :"
                    + wrapper.getLocoFault().getSubId() + " and CONTROLLER_SOURCE_ID : " + wrapper.getLocoFault().getControllerSourceId());
            //6060102  error code is triggered  for mail alert in  error handler,hence use the same.
        	
        	
        }
    }
    
    public String getRandomString() {
        return ManualLoaderUtility.getRandomNumberInRange(1, 9999);
    }
    
    @SuppressWarnings("unchecked")
    public void updateActualFaultsProcessed(Exchange exchange) {
        exchange.getProperty(ManualLoaderConstants.ACTUAL_FAULTS_PROCESSED, List.class).add(Integer.valueOf(1));
    }
    
    public void enrichFaultwithMessageId(Long messageId, FaultSnapshotWrapper wrapper) {
        String messageIdString = (null != messageId) ? messageId.toString() : null;
        wrapper.getLocoFault().setGetsMessageId(messageIdString);
        LOGGER.debug("Message Id {} updated in the Fault ", messageIdString);
    }
    
}