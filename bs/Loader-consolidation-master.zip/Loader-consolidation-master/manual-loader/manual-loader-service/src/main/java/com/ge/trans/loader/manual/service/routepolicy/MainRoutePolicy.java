package com.ge.trans.loader.manual.service.routepolicy;

import org.apache.camel.Exchange;
import org.apache.camel.Route;
import org.apache.camel.spi.RoutePolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.common.exception.LoaderRuntimeException;
import com.ge.trans.loader.manual.common.enums.ManualLoaderError;

public class MainRoutePolicy implements RoutePolicy {
  private String eligibleRoutes;
  private static final Logger LOGGER = LoggerFactory.getLogger(MainRoutePolicy.class);

  @Override
  public void onExchangeBegin(Route route, Exchange arg1) {
    LOGGER.debug("onExchangeBegin:{}", route.getId());
  }

  @Override
  public void onExchangeDone(Route route, Exchange arg1) {
    LOGGER.debug("onExchangeDone:{}", route.getId());
  }

  @Override
  public void onInit(Route route) {
    LOGGER.debug("onInit:{}", route.getId());
  }

  @Override
  public void onRemove(Route route) {
    LOGGER.debug("onRemove:{}", route.getId());
  }

  @Override
  public void onResume(Route route) {
    LOGGER.debug("onResume:{}", route.getId());
  }

  @Override
  public void onStart(Route route) {
    if (this.eligibleRoutes.contains(route.getId())) {
      LOGGER.info("{} ELIGIBLE  TO START  IN  THIS CONTAINER UNDER {}", route.getId(), route.getRouteContext().getCamelContext().getName());
    } else {
      LOGGER.warn("{} NOT ELIGIBLE  TO START IN  THIS CONTAINER UNDER {}.PLEASE CONFIGURE IT IN PROPERTIES.", route.getId(), route.getRouteContext().getCamelContext().getName());
      throw new LoaderRuntimeException(ManualLoaderError.NOT_AN_ELIGIBLE_ROUTES_TO_START.getErrorCode(), ManualLoaderError.NOT_AN_ELIGIBLE_ROUTES_TO_START.getErrorDesc());
    }

  }

  @Override
  public void onStop(Route route) {
    LOGGER.debug("onStop:{}", route.getId());
  }

  @Override
  public void onSuspend(Route route) {
    LOGGER.debug("onSuspend:{}", route.getId());
  }

  public void setEligibleRoutes(String eligibleRoutes) {
    this.eligibleRoutes = eligibleRoutes;
  }

}
