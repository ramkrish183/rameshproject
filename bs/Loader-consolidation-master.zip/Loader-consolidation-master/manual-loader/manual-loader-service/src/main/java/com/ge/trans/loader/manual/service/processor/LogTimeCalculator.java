package com.ge.trans.loader.manual.service.processor;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.ge.trans.loader.common.constant.CommonConstants;

public class LogTimeCalculator implements Processor {

    @Override
    public void process(Exchange exchange) throws Exception {
        long endTime = System.currentTimeMillis();
        long startTime = (long) exchange.getProperty(CommonConstants.START_TIME);
        exchange.setProperty(CommonConstants.END_TIME, endTime);
        exchange.setProperty(CommonConstants.TOTAL_TIME, endTime - startTime);
    }

}
