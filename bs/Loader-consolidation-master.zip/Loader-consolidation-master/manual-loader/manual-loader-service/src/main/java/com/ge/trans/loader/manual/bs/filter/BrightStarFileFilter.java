package com.ge.trans.loader.manual.bs.filter;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.apache.camel.component.file.GenericFile;
import org.apache.camel.component.file.GenericFileFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class BrightStarFileFilter<T> implements GenericFileFilter<T> {
  private static final Logger LOGGER = LoggerFactory.getLogger(BrightStarFileFilter.class);
  private String allowedExt;
  private String allowedFileInitials;
  @Override
  public boolean accept(GenericFile<T> file) {
    LOGGER.info("File received {}" + file.getFileNameOnly());
    if (file.getFileNameOnly() != null && file.getFileNameOnly().endsWith(".filepart") ) {
      return false;
    }
    String fileName = file.getFileNameOnly();
    if (fileName != null) {
      String fileExtension = fileName.substring(fileName.lastIndexOf('.') + 1);
      if (!allowedExt.contains(fileExtension.toLowerCase()) || !fileName.toLowerCase().startsWith(allowedFileInitials) ) {
          return  false;
      }
    }
    long diff = differenceInMinutes(file.getLastModified());
    LOGGER.debug("File Last Updated  {} minutes before", diff);
    return diff > 3 ? true : false;
  }
  

  private long differenceInMinutes(long lastModifiedDateInMillis) {
    Calendar cal = Calendar.getInstance();
    cal.setTimeInMillis(lastModifiedDateInMillis);

    DateFormat formatter = new SimpleDateFormat("");
    String dateString = formatter.format(cal.getTime());
    LOGGER.info("Last Date Modified" + dateString);
    Date date = cal.getTime();
    Date currentDate = new Date();
    long millis = currentDate.getTime() - date.getTime();
    return TimeUnit.MINUTES.toMinutes(millis);
  }
  
  public void setAllowedExt(String allowedExt) {
    this.allowedExt = allowedExt;
  }


  /**
   * @param allowedFileInitials the allowedFileInitials to set
   */
  public void setAllowedFileInitials(String allowedFileInitials) {
    this.allowedFileInitials = allowedFileInitials;
  }
  
}
