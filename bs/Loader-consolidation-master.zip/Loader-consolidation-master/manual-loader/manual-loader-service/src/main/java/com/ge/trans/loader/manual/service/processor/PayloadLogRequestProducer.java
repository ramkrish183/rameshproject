package com.ge.trans.loader.manual.service.processor;

import java.util.Date;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.common.constant.CommonConstants;
import com.ge.trans.loader.common.domain.MessageLogRequest;
import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;

public class PayloadLogRequestProducer implements Processor {
    
    private static final String CAMEL_DEFAULT_CHARSET = "org.apache.camel.default.charset";
    private static final String CHARSET_CP865 = "Cp865";
    private static final Logger LOGGER = LoggerFactory.getLogger(PayloadLogRequestProducer.class);
    
    @SuppressWarnings("unchecked")
    @Override
    public void process(Exchange exchange) throws Exception {
        LOGGER.debug("LoaderPayloadProcessor begins");
        List<String> splittedFile=exchange.getProperty(ManualLoaderConstants.SPLITTED_FILE,List.class);
        if (null == splittedFile) {
            LOGGER.warn("### NULL FILE RECEIVED ###");
        }
        System.setProperty(CAMEL_DEFAULT_CHARSET, CHARSET_CP865);
        MessageLogRequest request = new MessageLogRequest();
        request.setProgramName(exchange.getProperty(CommonConstants.PROGRAM_NAME, String.class));
        request.setMessageId(exchange.getProperty(CommonConstants.MESSAGE_ID, String.class));
        request.setMessageType(exchange.getProperty(CommonConstants.MESSAGE_TYPE, String.class));
        request.setCustomerId(exchange.getProperty(CommonConstants.CUSTOMERID, String.class));
        request.setVehicleInitial(exchange.getProperty(CommonConstants.VEHICLEINITIAL, String.class));
        request.setVehicleNumber(exchange.getProperty(CommonConstants.VEHICLENUMBER, String.class));
        if(splittedFile!=null){
            request.setMessagePayload(StringUtils.join(splittedFile, "\n").getBytes(CHARSET_CP865));
        }else{
            request.setMessagePayload(("INVALID PAYLOAD RECEIVED:"+exchange.getIn().getHeader(Exchange.FILE_NAME_ONLY,String.class)).getBytes());
        }
        request.setLogTime(new Date());
        request.setCreatedBy(exchange.getProperty(CommonConstants.CREATED_BY, String.class));
        request.setCreationDate(new Date());
        
        exchange.getOut().setBody(request);
        LOGGER.debug("LoaderPayloadProcessor ends");
    }
    
}
