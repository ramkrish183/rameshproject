package com.ge.trans.loader.manual.service;

import java.math.BigDecimal;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.common.exception.LoaderException;
import com.ge.trans.loader.manual.bs.data.domain.valueobjects.LocoFault;
import com.ge.trans.loader.manual.cache.api.ManualLoaderCacheAPI;
import com.ge.trans.loader.manual.common.data.api.ManualLoaderDataAPI;
import com.ge.trans.loader.manual.common.data.request.FaultCodeRequest;
import com.ge.trans.loader.manual.common.data.request.VehicleDetailsRequest;
import com.ge.trans.loader.manual.common.data.response.FaultCodeDefinition;
import com.ge.trans.loader.manual.common.data.response.VehicleDetailsResponse;
import com.ge.trans.loader.manual.common.enums.ManualLoaderError;

/**
 * @author 502166888
 *
 */
public class ManualLoaderService {
  private static final Logger LOGGER = LoggerFactory.getLogger(ManualLoaderService.class);
  private ManualLoaderDataAPI manualLoaderDataAPI;
  private ManualLoaderCacheAPI manualLoaderCacheAPI;

  public void setManualLoaderCacheAPI(ManualLoaderCacheAPI manualLoaderCacheAPI) {
    this.manualLoaderCacheAPI = manualLoaderCacheAPI;
  }

  /**
   * @return the manualLoaderDataAPI
   */
  public ManualLoaderDataAPI getManualLoaderDataAPI() {
    return manualLoaderDataAPI;
  }

  /**
   * @param manualLoaderDataAPI
   *            the manualLoaderDataAPI to set
   */
  public void setManualLoaderDataAPI(ManualLoaderDataAPI manualLoaderDataAPI) {
    this.manualLoaderDataAPI = manualLoaderDataAPI;
  }

  public String getRmdSysParmValue(String title) {
    return manualLoaderDataAPI.getRmdSysParmValue(title);
  }

  public boolean hasRecentData(String recordType, String downloadLookbackTime, long vehicleObjid) {
    boolean hasRecentData = false;
    int recordCount;
    recordCount = manualLoaderDataAPI.getToolFaultRecordCount(recordType, downloadLookbackTime, vehicleObjid);
    hasRecentData = (recordCount > 0) ? true : false;
    return hasRecentData;
  }

  public int updateToolRunNextFCT(VehicleDetailsResponse vehicleDetails, String programName, int lagTime) throws LoaderException {
    int noOfRecordsUpdated = 0;
    try {
      LOGGER.info("START updateToolRunNextFCT- update toolrunnext with FCT for vehicle objid {}, vehicle Number {} ", vehicleDetails.getVehicleObjid(),
        vehicleDetails.getVehicleNumber());
      double faultCollectionTime = lagTime / 86400.0f;
      noOfRecordsUpdated = manualLoaderDataAPI.updateToolRunNextwithFCT(vehicleDetails, faultCollectionTime, programName);
    } catch (Exception e) {
      LOGGER.error("Exception in updateToolRunNextFCT -, Error message : {} ", e.getMessage());
      throw new LoaderException(ManualLoaderError.EXCEPTION_WHILE_UPDATING_TOOLRUNNEXT_COLUMN.getErrorCode(),
        ManualLoaderError.EXCEPTION_WHILE_UPDATING_TOOLRUNNEXT_COLUMN.getErrorDesc() + e.getMessage());
    }
    LOGGER.info("End updateToolRunNextFCT- Number of records updated {} ", noOfRecordsUpdated);
    return noOfRecordsUpdated;
  }

  public VehicleDetailsResponse findVehicleDetails(VehicleDetailsRequest request) throws LoaderException {
    VehicleDetailsResponse vehicleInfo = null;
    LOGGER.info("Start: findVehicleDetails for vehicle no {}, customer Id {}, vehicle Hdr {}", request.getVehicleNumber(), request.getCustomerId(), request.getVehicleInitial());
    vehicleInfo = manualLoaderCacheAPI.findVehicleDetails(request);
    if (null == vehicleInfo) {
      //throw new LoaderException(ManualLoaderError.VEHICLE_NOT_FOUND_EXCEPTION.getErrorCode(), ManualLoaderError.VEHICLE_NOT_FOUND_EXCEPTION.getErrorDesc());
        vehicleInfo=new VehicleDetailsResponse();
        vehicleInfo.setVehicleObjid(-1L);
        vehicleInfo.setVehicleNumber(request.getVehicleNumber());
        vehicleInfo.setCustomerId(request.getCustomerId());
    }

    return vehicleInfo;
  }

  public FaultCodeDefinition findFaultCodeDefinition(FaultCodeRequest faultCodeRequest) throws LoaderException {
    FaultCodeDefinition faultCodeDefinition = manualLoaderCacheAPI.findFaultCodeDefinition(faultCodeRequest);

    if (null == faultCodeDefinition) {
      faultCodeDefinition = new FaultCodeDefinition();
      faultCodeDefinition.setControllerSourceId(Long.parseLong(faultCodeRequest.getControllerSourceID()));
      faultCodeDefinition.setFaultCode(faultCodeRequest.getFaultCode());
      faultCodeDefinition.setObjId(-1L);
      faultCodeDefinition.setSubId(faultCodeRequest.getSubId());
    }

    return faultCodeDefinition;
  }

  public Long getMessageIdSequenceValue() {
    return manualLoaderDataAPI.getMessageIdSequenceValue();
  }

  public boolean isNewFault(LocoFault locoFault) {
    LOGGER.info("Start isNewFault()");
    BigDecimal faultObjid = manualLoaderDataAPI.findFaultObjid(locoFault);
    boolean result = faultObjid == BigDecimal.ZERO ? true : false;
    LOGGER.info("FaultObjid- {}, isNewFault? {} ", faultObjid, result);
    LOGGER.info("End isNewFault()");
    return result;
  }

}
