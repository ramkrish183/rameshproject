package com.ge.trans.loader.manual.service.processor;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.TimeZone;

import javax.jms.InvalidDestinationException;
import javax.jms.JMSException;
import javax.xml.xpath.XPathExpressionException;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.log4j.Logger;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.xml.sax.SAXParseException;

import com.ge.trans.loader.common.constant.CommonConstants;
import com.ge.trans.loader.common.constant.LoaderErrors;
import com.ge.trans.loader.common.exception.LoaderException;
import com.ge.trans.loader.common.exception.LoaderRuntimeException;

public class ErrorCodeProcessor implements Processor {

    private static final Logger LOGGER = Logger.getLogger(ErrorCodeProcessor.class);

    @Override
    public void process(Exchange exchange) throws Exception{
        LOGGER.debug("Exception Processing Start");
    	Exception exception=getExceptionObject(exchange);
    	ErrorObject errorObject = handleError(exception);
        populateCamelExchange(exchange, errorObject);
        Object object = exchange.getProperty(CommonConstants.ORIGINAL_REQUEST);
        exchange.getOut().setBody(object);
        LOGGER.error(errorObject.getErrorCode() + CommonConstants.COLON_STR + errorObject.getErrorMessage());
        LOGGER.debug(Arrays.toString(exception.getStackTrace()));         
        LOGGER.debug("Exception Processing End");
    }
    
    private Exception getExceptionObject(Exchange exchange){
    	Exception exception=(Exception) exchange.getProperty(Exchange.EXCEPTION_CAUGHT);
    	return (null!=exception)?exception:(Exception)exchange.getIn().getBody();
    }    

    private ErrorObject handleError(Exception exception) {
        ErrorObject errorObject = null;
        if (exception != null) {
            errorObject = getExceptionBasedErrorObject(exception);
            Throwable causeException = exception.getCause();
            if (errorObject == null && causeException != null) {
                errorObject = getExceptionBasedErrorObject(causeException);
                Throwable rootCauseException = causeException.getCause();
                if (errorObject == null && rootCauseException != null) {
                    errorObject = getExceptionBasedErrorObject(rootCauseException);
                }
            }
        }
        if (errorObject == null) {
            errorObject = getDefaultErrrorObject(exception);
        }
        return errorObject;
    }

    private ErrorObject getExceptionBasedErrorObject(Throwable exception) {
        ErrorObject errorObject = null;
        if (exception instanceof LoaderException) {
            errorObject = getErrorObjectForLoaderException((LoaderException) exception);
        } else if (exception instanceof LoaderRuntimeException) {
            errorObject = getErrorObjectForLoaderRuntimeException((LoaderRuntimeException) exception);
        } else if (exception instanceof SQLException) {
            errorObject = getErrorObjectForSQLException((SQLException) exception);
        } else if (exception instanceof org.springframework.jdbc.CannotGetJdbcConnectionException) {
            errorObject = getErrorObjectForSpringJdbcConnectionException((CannotGetJdbcConnectionException) exception);
        } else if (exception instanceof org.springframework.dao.DataAccessException) {// CamelExecutionException,
            errorObject = getErrorObjectForSpringDAOException((DataAccessException) exception);
        } else if (exception instanceof XPathExpressionException) {
            errorObject = getErrorObjectForXMLException((XPathExpressionException) exception);
        } else if (exception instanceof InvalidDestinationException) {
            errorObject = getErrorObjectForInvalidDestinationException((InvalidDestinationException) exception);
        } else if (exception instanceof JMSException) {
            errorObject = getErrorObjectForJMSException((JMSException) exception);
        }
        return errorObject;
    }

    private ErrorObject getDefaultErrrorObject(Exception exception) {
        ErrorObject errorObject;
        Throwable th = findOriginalException(exception);
        if (th instanceof DataAccessException) {
            errorObject = getErrorObjectForSpringDAOException((DataAccessException) th);
        } else if (th instanceof org.apache.camel.RollbackExchangeException) {
            errorObject = getErrorObjectForCamelRollbackException();
        } else if (th instanceof SQLException) {
            errorObject = getErrorObjectForSQLException((SQLException) th);
        } else if (th instanceof SAXParseException) {
            errorObject = getErrorObjectForSAXParseException((SAXParseException) th);
        } else if (exception instanceof InvalidDestinationException) {
            errorObject = getErrorObjectForInvalidDestinationException((InvalidDestinationException) exception);
        } else if (exception instanceof JMSException) {
            errorObject = getErrorObjectForJMSException((JMSException) exception);
        } else {
            errorObject = getErrorObjectForUnhandledException(exception);
        }
        return errorObject;
    }

    private ErrorObject getErrorObjectForSAXParseException(SAXParseException exception) {
        return new ErrorObject(LoaderErrors.XML_EXCEPTION_ERROR_CODE, LoaderErrors.XML_EXCEPTION_MESSAGE + CommonConstants.COLON_STR
                + exception.getMessage());
    }

    private ErrorObject getErrorObjectForCamelRollbackException() {
        return new ErrorObject(LoaderErrors.TRANSACTION_FAILURE_ERROR_CODE, LoaderErrors.TRANSACTION_FAILURE_ERROR_MESSAGE);
    }

    private ErrorObject getErrorObjectForSQLException(SQLException exception) {
        int errorCode = exception.getErrorCode();
        if (errorCode <= 0) {
            errorCode = LoaderErrors.SQL_OPERATION_ERROR_MESSAGE;
        }
        return new ErrorObject(errorCode, LoaderErrors.UNABLE_TO_PERFORM_SQL_OPERATION_ERROR_MESSAGE + CommonConstants.COLON_STR
                + exception.getMessage());
    }

    private ErrorObject getErrorObjectForLoaderException(LoaderException exception) {
        return new ErrorObject(exception.getErrorCode(), exception.getErrorMessage());
    }

    private ErrorObject getErrorObjectForLoaderRuntimeException(LoaderRuntimeException exception) {
        return new ErrorObject(exception.getErrorCode(), exception.getErrorMessage());
    }

    private ErrorObject getErrorObjectForUnhandledException(Exception ex) {
        StringWriter errors = new StringWriter();
        ex.printStackTrace(new PrintWriter(errors));
        LOGGER.error(errors.toString());
        return new ErrorObject(LoaderErrors.UNHANDLED_EXCEPTION_ERROR_CODE, LoaderErrors.UNHANDLED_EXCEPTION_ERROR_MESSAGE + CommonConstants.COLON_STR + ex.getMessage(),ex);// testing
    }


    private ErrorObject getErrorObjectForSpringDAOException(org.springframework.dao.DataAccessException exception) {
        if (exception.getCause().getMessage().substring(0, 9).equalsIgnoreCase(CommonConstants.ORA_00001)) {
            return new ErrorObject(LoaderErrors.SQL_OPERATION_ERROR_MESSAGE, LoaderErrors.UNABLE_TO_PERFORM_SQL_OPERATION_ERROR_MESSAGE
                    + CommonConstants.COLON_STR + LoaderErrors.RECORD_ALREADY_EXISTS + exception.getCause().getMessage().substring(9));
        } else if (exception.getCause().getMessage().substring(0, 9).equalsIgnoreCase(CommonConstants.ORA_01775)) {
            return new ErrorObject(LoaderErrors.SQL_OPERATION_ERROR_MESSAGE, LoaderErrors.UNABLE_TO_PERFORM_SQL_OPERATION_ERROR_MESSAGE
                    + CommonConstants.COLON_STR + LoaderErrors.SYNONYMS_NOT_CREATED + exception.getCause().getMessage());
        }
        return new ErrorObject(LoaderErrors.SQL_OPERATION_ERROR_MESSAGE, LoaderErrors.UNABLE_TO_PERFORM_SQL_OPERATION_ERROR_MESSAGE
                + CommonConstants.COLON_STR + ((java.sql.SQLException) exception.getCause()).getMessage());
    }

    private ErrorObject getErrorObjectForXMLException(XPathExpressionException exception) {
        if (exception.getCause().getMessage() != null) {
            String exceptionMessage = exception.getCause().getMessage();
            if (exceptionMessage.contains(LoaderErrors.PROLOG_ERROR_MESSAGE))
                return new ErrorObject(LoaderErrors.XML_EXCEPTION_ERROR_CODE, LoaderErrors.XML_EXCEPTION_MESSAGE
                        + CommonConstants.COLON_STR + LoaderErrors.MISSING_TAG_EXCEPTION_MESSAGE);
            else if (exceptionMessage.contains(LoaderErrors.AMPERSAND_ERROR_MESSAGE))
                return new ErrorObject(LoaderErrors.XML_EXCEPTION_ERROR_CODE, LoaderErrors.XML_EXCEPTION_MESSAGE
                        + CommonConstants.COLON_STR + LoaderErrors.SPECIAL_CHARACTER_EXCEPTION_MESSAGE);
            else if (exceptionMessage.contains(LoaderErrors.QUOTES_ERROR_MESSAGE))
                return new ErrorObject(LoaderErrors.XML_EXCEPTION_ERROR_CODE, LoaderErrors.XML_EXCEPTION_MESSAGE
                        + CommonConstants.COLON_STR + LoaderErrors.MISSING_QUOTES_EXCEPTION_MESSAGE);
        }
        return new ErrorObject(LoaderErrors.XML_EXCEPTION_ERROR_CODE, LoaderErrors.XML_EXCEPTION_MESSAGE + CommonConstants.COLON_STR
                + exception.getCause().getMessage());
    }

    private ErrorObject getErrorObjectForSpringJdbcConnectionException(CannotGetJdbcConnectionException exception) {

        return new ErrorObject(LoaderErrors.JDBC_EXCEPTION_ERROR_CODE, LoaderErrors.JDBC_EXCEPTION_MESSAGE + CommonConstants.COLON_STR
                + exception.getCause().getMessage(), true);
    }

    private ErrorObject getErrorObjectForInvalidDestinationException(InvalidDestinationException exception) {
        return new ErrorObject(LoaderErrors.INVALID_DESTINATION_ERROR_CODE, LoaderErrors.INVALID_DESTINATION_ERROR_MESSAGE
                + CommonConstants.COLON_STR + exception.getCause().getMessage(), true);
    }

    private ErrorObject getErrorObjectForJMSException(JMSException exception) {
        return new ErrorObject(LoaderErrors.JMS_EXCEPTION_ERROR_CODE, LoaderErrors.JMS_EXCEPTION_ERROR_MESSAGE + CommonConstants.COLON_STR
                + exception.getCause().getMessage(), true);
    }

    private Throwable findOriginalException(Throwable ex) {
        if (ex instanceof org.springframework.dao.DataAccessException || ex instanceof org.apache.camel.RollbackExchangeException
                || ex instanceof SQLException || ex instanceof SAXParseException || ex.getCause() == null
                || ex instanceof InvalidDestinationException || ex instanceof JMSException) {
            return ex;
        }
        return findOriginalException(ex.getCause());
    }

   

	/**
	 * @param exchange
	 * @param errorObject
	 */
	private void populateCamelExchange(Exchange exchange, ErrorObject errorObject) {
		exchange.setProperty(CommonConstants.ERROR_CODE_KEY, errorObject.getErrorCode());
          exchange.setProperty(CommonConstants.ERROR_MESSAGE, errorObject.getErrorMessage());
          exchange.setProperty(CommonConstants.TIME_STAMP, Calendar.getInstance(TimeZone.getDefault()).getTimeInMillis());
          exchange.setProperty(CommonConstants.SEVERITY_FLAG, errorObject.getSeverityFlag());
	}
    
    
    private static class ErrorObject {
        private String errorMessage;
        private int errorCode;
        private boolean severityFlag;

        public ErrorObject(int errorCode, String errorMessage) {
            this.errorCode = errorCode;
            this.errorMessage = errorMessage;
            this.severityFlag = false;
        }
        
        public ErrorObject(int errorCode, String errorMessage, Throwable th) {
            this.errorCode = errorCode;
            this.errorMessage = errorMessage;
            LOGGER.debug(th.toString());
        }


        public ErrorObject(int errorCode, String errorMessage, boolean severityFlag) {
            this.errorCode = errorCode;
            this.errorMessage = errorMessage;
            this.severityFlag = severityFlag;
        }

        public String getErrorMessage() {
            return this.errorMessage;
        }

        public int getErrorCode() {
            return this.errorCode;
        }

        public boolean getSeverityFlag() {
            return this.severityFlag;
        }

        @SuppressWarnings("unused")
        public void setSeverityFlag(boolean severityFlag) {
            this.severityFlag = severityFlag;
        }
    }

}
