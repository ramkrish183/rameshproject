package com.ge.trans.loader.manual.service.components.valueobjects;

/**
 * @author 502166888
 *
 */
public class SFTPParamVO {
 
  private String userName;
  private String password;
  private String hostName;
  private String port;
  private String filePath;
  private String routeId;
  private String uri;
  private String additionalParams;
  private String preMoveFolderPath;
  private String errorFolderPath;
  private String archiveFolderPath;
  private String delayInSeconds;
  /**
   * @return the uri
   */
  public String getUri() {
    //sftp://stgtoolbox.trans.ge.com:22/lms/inbound/bs-lcmq01?username=xface&amp;password=d0wnl0ad
    this.uri="sftp://"+getHostName()+":"+getPort()+"/"+getFilePath()+"?username="+getUserName()+"&password="+getPassword()+
      "&preMove="+getPreMoveFolderPath()+"&moveFailed="+getErrorFolderPath()+"${file:name.noext}-${date:now:yyyyMMddHHmmssSSS}.${file:ext}"
      +"&move="+getArchiveFolderPath()+"${file:name.noext}-${date:now:yyyyMMddHHmmssSSS}.${file:ext}&filter=#bsFilter&delay="+getDelayInSeconds()
        + "&preferredAuthentications=publickey,password";
    return uri;
  }
  
  /**
   * @return the preMoveFolderPath
   */
  public String getPreMoveFolderPath() {
    return preMoveFolderPath;
  }
  /**
   * @return the errorFolderPath
   */
  public String getErrorFolderPath() {
    return errorFolderPath;
  }
  /**
   * @return the archiveFolderPath
   */
  public String getArchiveFolderPath() {
    return archiveFolderPath;
  }
  /**
   * @param preMoveFolderPath the preMoveFolderPath to set
   */
  public void setPreMoveFolderPath(String preMoveFolderPath) {
    this.preMoveFolderPath = preMoveFolderPath;
  }
  /**
   * @param errorFolderPath the errorFolderPath to set
   */
  public void setErrorFolderPath(String errorFolderPath) {
    this.errorFolderPath = errorFolderPath;
  }
  /**
   * @param archiveFolderPath the archiveFolderPath to set
   */
  public void setArchiveFolderPath(String archiveFolderPath) {
    this.archiveFolderPath = archiveFolderPath;
  }
  /**
   * @return the userName
   */
  public String getUserName() {
    return userName;
  }
  /**
   * @return the password
   */
  public String getPassword() {
    return password;
  }
  /**
   * @return the hostName
   */
  public String getHostName() {
    return hostName;
  }
  /**
   * @return the port
   */
  public String getPort() {
    return port;
  }
  /**
   * @return the filePath
   */
  public String getFilePath() {
    return filePath;
  }
  /**
   * @return the routeId
   */
  public String getRouteId() {
    return routeId;
  }
  /**
   * @param userName the userName to set
   */
  public void setUserName(String userName) {
    this.userName = userName;
  }
  /**
   * @param password the password to set
   */
  public void setPassword(String password) {
    this.password = password;
  }
  /**
   * @param hostName the hostName to set
   */
  public void setHostName(String hostName) {
    this.hostName = hostName;
  }
  /**
   * @param port the port to set
   */
  public void setPort(String port) {
    this.port = port;
  }
  /**
   * @param filePath the filePath to set
   */
  public void setFilePath(String filePath) {
    this.filePath = filePath;
  }
  /**
   * @param routeId the routeId to set
   */
  public void setRouteId(String routeId) {
    this.routeId = routeId;
  }
 
  /**
   * @return the additionalParams
   */
  public String getAdditionalParams() {
    return additionalParams;
  }
  /**
   * @param uri the uri to set
   */
  public void setUri(String uri) {
    this.uri = uri;
  }
  /**
   * @param additionalParams the additionalParams to set
   */
  public void setAdditionalParams(String additionalParams) {
    this.additionalParams = additionalParams;
  }
  
  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "SFTPParamVO [userName=" + userName + ", password=" + password + ", hostName=" + hostName + ", port=" + port + ", filePath=" + filePath + ", routeId=" + routeId
      + ", uri=" + uri + ", additionalParams=" + additionalParams + "]";
  }

  /**
   * @return the delayInSeconds
   */
  public String getDelayInSeconds() {
    return delayInSeconds;
  }

  /**
   * @param delayInSeconds the delayInSeconds to set
   */
  public void setDelayInSeconds(String delayInSeconds) {
    this.delayInSeconds = delayInSeconds;
  }
}
