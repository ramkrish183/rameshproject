package com.ge.trans.loader.manual.bs.processor.bean;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.ge.trans.loader.common.exception.LoaderRuntimeException;
import com.ge.trans.loader.manual.common.enums.ManualLoaderError;

public class FileValidator implements Processor {
  private String allowedExt;

  @Override
  public void process(Exchange exchange) throws Exception {
    String fileName = exchange.getIn().getHeader(Exchange.FILE_NAME_ONLY, String.class);
    exchange.setProperty(Exchange.FILE_NAME_ONLY, fileName);
    exchange.setProperty("IS_BAD_FILE", false);
    if (fileName != null) {
      String fileExtension = fileName.substring(fileName.lastIndexOf('.') + 1);
      if (!allowedExt.contains(fileExtension.toLowerCase())) {
        throw new LoaderRuntimeException(ManualLoaderError.INVALID_FILE_TYPE.getErrorCode(), ManualLoaderError.INVALID_FILE_TYPE.getErrorDesc() + fileExtension);
      }
    }
  }

  public void setAllowedExt(String allowedExt) {
    this.allowedExt = allowedExt;
  }
}
