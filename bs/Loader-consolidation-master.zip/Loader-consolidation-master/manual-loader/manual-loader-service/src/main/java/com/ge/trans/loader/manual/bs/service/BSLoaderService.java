package com.ge.trans.loader.manual.bs.service;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.common.exception.LoaderException;
import com.ge.trans.loader.common.exception.LoaderRuntimeException;
import com.ge.trans.loader.manual.bs.data.api.BrightStarDataAPI;
import com.ge.trans.loader.manual.bs.data.domain.valueobjects.FaultSnapshotWrapper;
import com.ge.trans.loader.manual.cache.api.ManualLoaderCacheAPI;
import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;
import com.ge.trans.loader.manual.common.data.api.ManualLoaderDataAPI;
import com.ge.trans.loader.manual.common.data.request.MonitoringParamRequest;
import com.ge.trans.loader.manual.common.data.response.ParamDefinition;
import com.ge.trans.loader.manual.common.data.response.VehicleDetailsResponse;
import com.ge.trans.loader.manual.common.enums.ManualLoaderError;
import com.ge.trans.loader.manual.service.ManualLoaderService;

/**
 * @author 502166888
 *
 */
public class BSLoaderService {
  private ManualLoaderDataAPI manualLoaderDataAPI;
  private ManualLoaderService manualLoaderService;
  private ManualLoaderCacheAPI manualLoaderCacheAPI;
  private BrightStarDataAPI brightStarDataAPI;

  /**
   * @return the manualLoaderService
   */
  public ManualLoaderService getManualLoaderService() {
    return manualLoaderService;
  }

  /**
   * @param manualLoaderService the manualLoaderService to set
   */
  public void setManualLoaderService(ManualLoaderService manualLoaderService) {
    this.manualLoaderService = manualLoaderService;
  }

  /**
   * @return the manualLoaderDataAPI
   */
  public ManualLoaderDataAPI getManualLoaderDataAPI() {
    return manualLoaderDataAPI;
  }

  private static final Logger LOGGER = LoggerFactory.getLogger(BSLoaderService.class);

  public List<ParamDefinition> findBSParamDefinition(MonitoringParamRequest request) throws LoaderException {
    List<ParamDefinition> bsParamDefinitionLst = manualLoaderCacheAPI.findParamDefinition(request);
    if (null == bsParamDefinitionLst) {
      LOGGER.error("Brightstar Engineering params are not found");
      throw new LoaderException(ManualLoaderError.NO_BS_PARAMS_FOUND_EXCEPTION.getErrorCode(),
        ManualLoaderError.NO_BS_PARAMS_FOUND_EXCEPTION.getErrorDesc());
    }

    return bsParamDefinitionLst;
  }

  /**
   * @param manualLoaderDataAPI the manualLoaderDataAPI to set
   */
  public void setManualLoaderDataAPI(ManualLoaderDataAPI manualLoaderDataAPI) {
    this.manualLoaderDataAPI = manualLoaderDataAPI;
  }

  public int getBSFaultLagTime(VehicleDetailsResponse vehicleInfo) {
    int lagTime = 0;
    String downloadLookbackTime = getManualLoaderService().getRmdSysParmValue(ManualLoaderConstants.DOWNLOAD_LOOKBACK_TIME_TITLE);
    LOGGER.debug("Downloadlookbacktime {}", downloadLookbackTime);

    downloadLookbackTime = (null != downloadLookbackTime) ? downloadLookbackTime : Integer.toString(ManualLoaderConstants.DEFAULT_LOOKBACK_DOWNLOAD_TIME);

    boolean hasRecentEGUData = getManualLoaderService().hasRecentData(ManualLoaderConstants.EGU, downloadLookbackTime, vehicleInfo.getVehicleObjid());

    if (hasRecentEGUData) {
      lagTime = 0;
    } else {
      String bsFaultcollectionTime = getManualLoaderService().getRmdSysParmValue(ManualLoaderConstants.BS_FAULT_COLLECTION_TIME_TITLE);
      LOGGER.debug("bsFaultcollectionTime {}", bsFaultcollectionTime);
      lagTime = StringUtils.isBlank(bsFaultcollectionTime) ? ManualLoaderConstants.DEFAULT_BS_FAULT_COLLECTION_TIME : Integer.parseInt(bsFaultcollectionTime);
    }

    LOGGER.info("Bright Star Loader lagTime {}", lagTime);
    return lagTime;
  }

  public void setManualLoaderCacheAPI(ManualLoaderCacheAPI manualLoaderCacheAPI) {
    this.manualLoaderCacheAPI = manualLoaderCacheAPI;
  }

  public void saveIncidentAndSnapshot(FaultSnapshotWrapper wrapperInput) throws LoaderRuntimeException {
    try {
      getBrightStarDataAPI().saveIncidentAndSnapshot(wrapperInput);
    } catch (LoaderRuntimeException e) {
      LOGGER.error("Error while loading Incident Snapshot Data");
      throw e;
    } catch (Exception e) {
      LOGGER.error("Error while loading Incident Snapshot Data");
      throw new LoaderRuntimeException(ManualLoaderError.EXCEPTION_WHILE_LOADING_INC_SNP_DATA.getErrorCode(),
        ManualLoaderError.EXCEPTION_WHILE_LOADING_INC_SNP_DATA.getErrorDesc());
    }

  }

  /**
   * @return the brightStarDataAPI
   */
  public BrightStarDataAPI getBrightStarDataAPI() {
    return brightStarDataAPI;
  }

  /**
   * @param brightStarDataAPI the brightStarDataAPI to set
   */
  public void setBrightStarDataAPI(BrightStarDataAPI brightStarDataAPI) {
    this.brightStarDataAPI = brightStarDataAPI;
  }

}
