package com.ge.trans.loader.manual.cache.mapstore;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.ProducerTemplate;

import com.ge.trans.loader.manual.cache.helper.CacheUtil;
import com.ge.trans.loader.manual.common.data.response.FaultCodeDefinition;
import com.hazelcast.core.MapLoader;

public class FaultMapLoader implements MapLoader<String, FaultCodeDefinition> {

    private static final String FIND_FAULTCODE_DEFINITION_ENDPOINT_URI = "direct:findFaultCodeDefinition";

    @Override
    public FaultCodeDefinition load(String key) {
        FaultCodeDefinition faultDefinition=null;
        try {
            ProducerTemplate  producerTemplate=CacheUtil.getCacheContextTemplate();
            faultDefinition= producerTemplate.requestBody(FIND_FAULTCODE_DEFINITION_ENDPOINT_URI, key, FaultCodeDefinition.class);
        } catch (Exception e) {
            throw e;
        }
        return faultDefinition;
    }
    
    @Override
    public Map<String, FaultCodeDefinition> loadAll(Collection<String> keys) {
        Map<String, FaultCodeDefinition> map=new HashMap<>();
        for(String key:keys){
            map.put(key, load(key));
        }
        return map;
    }
    
    @Override
    public Iterable<String> loadAllKeys() {
        return null;
    }
        
}
