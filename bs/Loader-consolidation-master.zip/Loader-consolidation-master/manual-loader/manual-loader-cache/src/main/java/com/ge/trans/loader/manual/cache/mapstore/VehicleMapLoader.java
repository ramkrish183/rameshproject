package com.ge.trans.loader.manual.cache.mapstore;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.ProducerTemplate;

import com.ge.trans.loader.manual.cache.helper.CacheUtil;
import com.ge.trans.loader.manual.common.data.response.VehicleDetailsResponse;
import com.hazelcast.core.MapLoader;

public class VehicleMapLoader implements MapLoader<String,VehicleDetailsResponse>{ 
    private static final String FIND_VEHICLE_INFO_ENDPOINT_URI = "direct:findVehicleInfo";

    @Override
    public VehicleDetailsResponse load(String key) {
        VehicleDetailsResponse vInfo=null;
        try {
            ProducerTemplate  producerTemplate=CacheUtil.getCacheContextTemplate();
            vInfo= producerTemplate.requestBody(FIND_VEHICLE_INFO_ENDPOINT_URI, key, VehicleDetailsResponse.class);
        } catch (Exception e) {
            throw e;
        }
        return vInfo;
    }
    
    @Override
    public Map<String, VehicleDetailsResponse> loadAll(Collection<String> keys) {
        Map<String, VehicleDetailsResponse> map=new HashMap<>();
        for(String key:keys){
            map.put(key, load(key));
        }
        return map;
    }
    
    @Override
    public Iterable<String> loadAllKeys() {
        return null;
    }
    
}
