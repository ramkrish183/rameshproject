package com.ge.trans.loader.manual.cache.api;

import java.util.List;

import com.ge.trans.loader.manual.common.data.request.FaultCodeRequest;
import com.ge.trans.loader.manual.common.data.request.MonitoringParamRequest;
import com.ge.trans.loader.manual.common.data.request.VehicleDetailsRequest;
import com.ge.trans.loader.manual.common.data.response.FaultCodeDefinition;
import com.ge.trans.loader.manual.common.data.response.ParamDefinition;
import com.ge.trans.loader.manual.common.data.response.VehicleDetailsResponse;

public interface ManualLoaderCacheAPI {
    
    VehicleDetailsResponse findVehicleDetails(VehicleDetailsRequest request);
    
    FaultCodeDefinition  findFaultCodeDefinition(FaultCodeRequest request);  
    
    List<ParamDefinition>  findParamDefinition(MonitoringParamRequest request);
    
}
