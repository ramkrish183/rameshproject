package com.ge.trans.loader.manual.cache.impl;

import java.util.List;

import org.apache.camel.ProducerTemplate;

import com.ge.trans.loader.manual.cache.api.ManualLoaderCacheAPI;
import com.ge.trans.loader.manual.common.data.request.FaultCodeRequest;
import com.ge.trans.loader.manual.common.data.request.MonitoringParamRequest;
import com.ge.trans.loader.manual.common.data.request.VehicleDetailsRequest;
import com.ge.trans.loader.manual.common.data.response.FaultCodeDefinition;
import com.ge.trans.loader.manual.common.data.response.ParamDefinition;
import com.ge.trans.loader.manual.common.data.response.VehicleDetailsResponse;

public class ManualLoaderCacheImpl implements ManualLoaderCacheAPI {
    private static final String FIND_PARAM_DEFINITION_MAP_ENDPOINT_URI = "direct:findParamDefinitionMap";
    private static final String GET_VEHICLE_MAP_ENDPOINT_URI = "direct:getVehicleMap";
    private static final String GET_FAULTCODE_DEFINITION_ENDPOINT_URI = "direct:getFaultCodeDefinitionMap";
    private ProducerTemplate producerTemplate;
    
    @Override
    public VehicleDetailsResponse findVehicleDetails(VehicleDetailsRequest request) {
        
        ClassLoader ccl = Thread.currentThread().getContextClassLoader();
        ClassLoader classLoader = this.getClass().getClassLoader();
        Thread.currentThread().setContextClassLoader(classLoader);
        VehicleDetailsResponse vInfo = producerTemplate.requestBody(GET_VEHICLE_MAP_ENDPOINT_URI, request, VehicleDetailsResponse.class);
        Thread.currentThread().setContextClassLoader(ccl);
        return vInfo;
    }
    
    public void setProducerTemplate(ProducerTemplate producerTemplate) {
        this.producerTemplate = producerTemplate;
    }
    
    @Override
    public FaultCodeDefinition findFaultCodeDefinition(FaultCodeRequest request) {
        
        ClassLoader ccl = Thread.currentThread().getContextClassLoader();
        ClassLoader classLoader = this.getClass().getClassLoader();
        Thread.currentThread().setContextClassLoader(classLoader);
        FaultCodeDefinition definition = producerTemplate.requestBody(GET_FAULTCODE_DEFINITION_ENDPOINT_URI, request, FaultCodeDefinition.class);
        Thread.currentThread().setContextClassLoader(ccl);
        return definition;
    }
    
    @SuppressWarnings("unchecked")
    @Override
    public List<ParamDefinition> findParamDefinition(MonitoringParamRequest request) {
        ClassLoader ccl = Thread.currentThread().getContextClassLoader();
        ClassLoader classLoader = this.getClass().getClassLoader();
        Thread.currentThread().setContextClassLoader(classLoader);
        List<ParamDefinition> definitions = producerTemplate.requestBody(FIND_PARAM_DEFINITION_MAP_ENDPOINT_URI, request, List.class);
        Thread.currentThread().setContextClassLoader(ccl);
        return definitions;
    }
    
}
