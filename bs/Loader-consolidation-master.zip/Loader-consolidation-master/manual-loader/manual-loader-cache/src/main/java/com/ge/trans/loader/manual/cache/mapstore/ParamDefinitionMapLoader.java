package com.ge.trans.loader.manual.cache.mapstore;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.ProducerTemplate;

import com.ge.trans.loader.manual.cache.helper.CacheUtil;
import com.ge.trans.loader.manual.common.data.response.ParamDefinition;
import com.hazelcast.core.MapLoader;

public class ParamDefinitionMapLoader implements MapLoader<String, List<ParamDefinition>> {
    private static final String FIND_PARAM_DEFINITION_ENDPOINT_URI = "direct:findParamDefinition";
    
    @SuppressWarnings("unchecked")
    @Override
    public List<ParamDefinition> load(String key) {
        List<ParamDefinition> definitions = null;
        try {
            ProducerTemplate producerTemplate = CacheUtil.getCacheContextTemplate();
            definitions = producerTemplate.requestBody(FIND_PARAM_DEFINITION_ENDPOINT_URI, key, List.class);
        } catch (Exception e) {
            throw e;
        }
        return definitions;
    }
    
    @Override
    public Map<String, List<ParamDefinition>> loadAll(Collection<String> keys) {
        Map<String, List<ParamDefinition>> map = new HashMap<>();
        for (String key : keys) {
            map.put(key, load(key));
        }
        return map;
    }
    
    @Override
    public Iterable<String> loadAllKeys() {
        return null;
    }
    
}
