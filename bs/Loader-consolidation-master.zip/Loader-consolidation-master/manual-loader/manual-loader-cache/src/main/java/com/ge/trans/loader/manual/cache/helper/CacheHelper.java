package com.ge.trans.loader.manual.cache.helper;

import com.ge.trans.loader.manual.common.data.request.FaultCodeRequest;
import com.ge.trans.loader.manual.common.data.request.MonitoringParamRequest;
import com.ge.trans.loader.manual.common.data.request.VehicleDetailsRequest;

public class CacheHelper  {
    
    public String generateVehicleMapKey(VehicleDetailsRequest request){
        return request.getCustomerId()+"#"+request.getVehicleNumber();
    }
    
    public VehicleDetailsRequest generateVehicleRequest(String key){
        String[]  values=key.split("#");
        VehicleDetailsRequest request=new VehicleDetailsRequest();
        request.setCustomerId(values[0]);
        request.setVehicleNumber(values[1]);
        request.setVehicleInitial(values[0]);
        return request;
    }
    
    public FaultCodeRequest generateFaultCodeRequest(String key){
        String[] values=key.split("#");
        FaultCodeRequest request=new FaultCodeRequest();
        request.setFaultCode(values[0]);
        request.setControllerSourceID(values[1]);
        request.setSubId(values[2]);
        return request;
    }
    public String  generateFaultCodeDefinitionMapKey(FaultCodeRequest request){
        return request.getFaultCode()+"#"+request.getControllerSourceID()+"#"+request.getSubId();
    }
    
    public String generateParamDefinitionMapKey(MonitoringParamRequest request){
        return request.getControllerSourceId()+"#"+request.getParamLoadColumn()+"#"+request.getParamNumber();
    }
    
    public MonitoringParamRequest generateParamDefinitionRequest(String key){
        String[] values=key.split("#");
        MonitoringParamRequest request=new MonitoringParamRequest();
        request.setControllerSourceId(values[0]);
        request.setParamLoadColumn(values[1]);
        request.setParamNumber(values[2]);
        return request;
    }
}
