package com.ge.trans.loader.manual.cache.helper;

import java.util.EventObject;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.ProducerTemplate;
import org.apache.camel.impl.DefaultProducerTemplate;
import org.apache.camel.management.event.CamelContextStartedEvent;
import org.apache.camel.management.event.CamelContextStoppingEvent;
import org.apache.camel.support.EventNotifierSupport;

public class CacheUtil extends EventNotifierSupport {
    private static final String TEMPLATE_KEY = "template";
    private static Map<String, ProducerTemplate> templateMap = new HashMap<>();
    
    public static ProducerTemplate getCacheContextTemplate() {
        return CacheUtil.templateMap.get(TEMPLATE_KEY);
    }
    
    @Override
    public boolean isEnabled(EventObject event) {
        return (event instanceof CamelContextStartedEvent || event instanceof CamelContextStoppingEvent);
    }
    
    @Override
    public void notify(EventObject event) throws Exception {
        try {
            if (event instanceof CamelContextStartedEvent) {
                ProducerTemplate producerTemplate = new DefaultProducerTemplate(((CamelContextStartedEvent) event).getContext());
                producerTemplate.start();
                CacheUtil.templateMap.put(TEMPLATE_KEY, producerTemplate);
            }
            if (event instanceof CamelContextStoppingEvent) {
                CacheUtil.templateMap.get(TEMPLATE_KEY).stop();
                CacheUtil.templateMap.remove(TEMPLATE_KEY);
            }
        } catch (Exception e) {
            throw e;
        }
    }
    
}
