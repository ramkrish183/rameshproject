--------------------------------------------------------
--  DDL for Public Synonyms
--------------------------------------------------------
CREATE PUBLIC SYNONYM GETS_DW_EOA_LOADER_ESERV_REQ FOR "EOA_DW"."GETS_DW_EOA_LOADER_ESERV_REQ" ;
  
CREATE PUBLIC SYNONYM EOA_LOADER_ESERV_REQ_SEQ FOR "EOA_DW"."EOA_LOADER_ESERV_REQ_SEQ" ;