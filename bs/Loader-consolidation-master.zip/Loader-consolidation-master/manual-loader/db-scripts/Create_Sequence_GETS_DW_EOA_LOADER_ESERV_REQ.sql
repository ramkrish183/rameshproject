--------------------------------------------------------
--  DDL for Sequence
--------------------------------------------------------
 CREATE SEQUENCE EOA_DW.EOA_LOADER_ESERV_REQ_SEQ START WITH 1 INCREMENT BY 1 MAXVALUE 999999999999999999999999999 MINVALUE 1 NOCACHE;