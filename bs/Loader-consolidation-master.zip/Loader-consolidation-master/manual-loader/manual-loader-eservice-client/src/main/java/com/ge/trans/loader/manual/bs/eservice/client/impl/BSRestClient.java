package com.ge.trans.loader.manual.bs.eservice.client.impl;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

import org.apache.camel.ProducerTemplate;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.jaxrs.impl.ResponseImpl;
import org.apache.cxf.rs.security.oauth2.client.OAuthClientUtils;
import org.apache.cxf.rs.security.oauth2.common.ClientAccessToken;
import org.apache.cxf.rs.security.oauth2.grants.clientcred.ClientCredentialsGrant;
import org.apache.cxf.rs.security.oauth2.utils.OAuthConstants;
import org.codehaus.jackson.jaxrs.JacksonJaxbJsonProvider;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.common.domain.MessageLogRequest;
import com.ge.trans.loader.common.exception.LoaderRuntimeException;
import com.ge.trans.loader.manual.bs.eservice.jaxb.Error;
import com.ge.trans.loader.manual.bs.eservice.jaxb.Request;
import com.ge.trans.loader.manual.bs.eservice.jaxb.Response;
import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;
import com.ge.trans.loader.manual.common.enums.ManualLoaderError;

public class BSRestClient {
    
    private static final String YES = "Y";
    private static final String GRANT_SCOPE_API = "api";
    private String clientSecret;
    private String clientName;
    private String oauthUrl;
    private String authRequired;
    private String userPassword;
    private String baseServiceURL;
    private WebClient webClient;
    private ObjectMapper mapper = new ObjectMapper();
    private static final Logger LOGGER = LoggerFactory.getLogger(BSRestClient.class);
    private ProducerTemplate producerTemplate;
    
    public void init() {
        try {
            List<Object> providers = new ArrayList<Object>(1);
            providers.add(new JacksonJaxbJsonProvider());
            webClient = WebClient.create(baseServiceURL, providers);
           
            webClient = webClient.type(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON);
        } catch (Exception e) {
            LOGGER.error("ERROR WHILE INITIALISING REST CLIENT,PLEASE VALIDATE OAUTH/REST URL:" + e.getMessage());
        }
    }
    
    private void prepareOAuthHeaders(WebClient webclient) {
        org.apache.cxf.rs.security.oauth2.client.OAuthClientUtils.Consumer consumer = new org.apache.cxf.rs.security.oauth2.client.OAuthClientUtils.Consumer(clientName,
                clientSecret);
        WebClient accessTokenService = WebClient.create(oauthUrl);
        ClientAccessToken accessToken = OAuthClientUtils.getAccessToken(accessTokenService, consumer, new ClientCredentialsGrant(GRANT_SCOPE_API));
        accessToken.setTokenType(OAuthConstants.BEARER_TOKEN_TYPE);
        webclient.replaceHeader(ManualLoaderConstants.AUTHORIZATION_HEADER, OAuthClientUtils.createAuthorizationHeader(accessToken));
    }
    
    public void processEServiceRequest(Map<String, Object> requestMap) {
        Request eserviceRequest = (Request) requestMap.get(ManualLoaderConstants.ESERVICESREQUEST);
        String messageUID = (String) requestMap.get(ManualLoaderConstants.MESSAGEUID);
        String programName = (String) requestMap.get(ManualLoaderConstants.PROGRAM_NAME);
        prepareAndSendServiceRequest(eserviceRequest, messageUID, programName);
    }
    
    private void prepareAndSendServiceRequest(Request eserviceRequest, String messageUID, String programName) {
        String jsonRequest = prepareJSONRequest(eserviceRequest);
        producerTemplate.asyncRequestBody("direct:logServiceRequest",
                createLogRequest(messageUID, programName, jsonRequest, ManualLoaderConstants.INPROGRESS, ManualLoaderConstants.EMPTY));
        ResponseImpl response = send(jsonRequest);
        String jsonResponse = readServiceJSONResponse(response);
        Response serviceResponse = mapJSONToObject(jsonResponse);
        producerTemplate.asyncRequestBody("direct:updateServiceResponse",
                createLogRequest(messageUID, programName, ManualLoaderConstants.EMPTY, serviceResponse.getStatus().getStatusCode().value(), jsonResponse));
        validateResponse(serviceResponse);
    }
    
    private String prepareJSONRequest(Request request) {
        try {
            String jsonString = mapper.writeValueAsString(request);
            LOGGER.info("JSON REQUEST PREPARED:{}", jsonString);
            return jsonString;
        } catch (IOException e) {
            throw new LoaderRuntimeException(ManualLoaderError.EXCEPTION_WHILE_PREPARING_JSON_REQUEST_FOR_ESERVICES.getErrorCode(),
                    ManualLoaderError.EXCEPTION_WHILE_PREPARING_JSON_REQUEST_FOR_ESERVICES.getErrorDesc() + e.getMessage());
        }
    }
    
    private ResponseImpl send(String jsonString) {
        if (authRequired != null && YES.equalsIgnoreCase(authRequired)) {
            prepareOAuthHeaders(webClient);
        } else {
            webClient.header(ManualLoaderConstants.AUTHORIZATION_HEADER,
                    ManualLoaderConstants.BASIC.concat(org.apache.cxf.common.util.Base64Utility.encode(userPassword.getBytes())));
        }
        ResponseImpl jaxrsResponse=null;
        LOGGER.info("REQUEST  HEADERS :{}",webClient.getHeaders());
        try {
            jaxrsResponse = (ResponseImpl) webClient.post(jsonString);
        } catch (Exception ex) {
            StringWriter errors = new StringWriter();
            ex.printStackTrace(new PrintWriter(errors));
            LOGGER.error("ERROR  WHILE SENDING JSON REQUEST TO eSERVICE : {}",errors.toString());
            throw new LoaderRuntimeException(-1100051,"UNABLE TO SEND REQUEST TO :"+baseServiceURL+":"+ex.getMessage()); 
        }
        LOGGER.info("JSON REQUEST SENT TO:{}", baseServiceURL);
       
        return jaxrsResponse;
    }
    
    private String readServiceJSONResponse(ResponseImpl jaxrsResponse) {
        String responseString = jaxrsResponse.readEntity(String.class);
        LOGGER.info("JSON RESPONSE RECEIVED:{} STATUS  CODE:{}", responseString,jaxrsResponse.getStatus());
        if(200 !=jaxrsResponse.getStatus()){
            throw new LoaderRuntimeException(-1100051,"UNABLE TO SEND REQUEST TO :"+baseServiceURL); 
        }
        return responseString;
    }
    
    private Response mapJSONToObject(String responseString) {
        try {
            LOGGER.info("MAPPING JSON TO {} OBJECT", Response.class.getSimpleName());
            return mapper.readValue(responseString, Response.class);
        } catch (IOException e) {
            throw new LoaderRuntimeException(ManualLoaderError.EXCEPTION_IN_MAPPING_JSON_OBJECT.getErrorCode(), ManualLoaderError.EXCEPTION_IN_MAPPING_JSON_OBJECT.getErrorDesc()
                    + e.getMessage());
        }
    }
    
    private void validateResponse(Response response) {
        LOGGER.info("validating response");
        if (response.getStatus().getStatusCode().value().equals(ManualLoaderConstants.FAILED)) {
            LOGGER.error(ManualLoaderError.ESERVICES_RESPONSE_FAILURE_EXCEPTION.getErrorDesc() + ":UNSUCCESSFUL RESPONSE:" + response.getStatus().getMessage() + ":"
                    + response.getStatus().getFileIdentifier() + ":" + prepareErrorString(response.getStatus().getErrors().getError()));
            throw new LoaderRuntimeException(ManualLoaderError.ESERVICES_RESPONSE_FAILURE_EXCEPTION.getErrorCode(),
                    ManualLoaderError.ESERVICES_RESPONSE_FAILURE_EXCEPTION.getErrorDesc() + ":UNSUCCESSFUL RESPONSE:" + response.getStatus().getMessage() + ":"
                            + response.getStatus().getFileIdentifier() + ":" + prepareErrorString(response.getStatus().getErrors().getError()));
        }
    }
    
    private String prepareErrorString(List<Error> errors) {
        StringBuilder builder = new StringBuilder();
        for (Error error : errors) {
            builder.append(error.getErrorCode());
            builder.append(ManualLoaderConstants.COLON);
            builder.append(error.getErrorMsg());
            builder.append(ManualLoaderConstants.COLON);
            builder.append(error.getUuid());
        }
        return builder.toString();
    }
    
    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }
    
    public void setBaseServiceURL(String baseServiceURL) {
        this.baseServiceURL = baseServiceURL;
    }
    
    public void setProducerTemplate(ProducerTemplate producerTemplate) {
        this.producerTemplate = producerTemplate;
    }
    
    private MessageLogRequest createLogRequest(String messageId, String programName, String jsonRequest, String status, String remarks) {
        MessageLogRequest request = new MessageLogRequest();
        request.setProgramName(programName);
        request.setMessageId(messageId);
        request.setMessagePayload(jsonRequest.getBytes());
        request.setCreatedBy(programName);
        request.setStatus(status);
        request.setRemarks(remarks);
        return request;
    }

    public void setClientSecret(String clientSecret) {
        this.clientSecret = clientSecret;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public void setOauthUrl(String oauthUrl) {
        this.oauthUrl = oauthUrl;
    }

    public void setAuthRequired(String authRequired) {
        this.authRequired = authRequired;
    }
    
}
