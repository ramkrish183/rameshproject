package com.ge.trans.loader.manual.bs.eservice.client.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.common.exception.LoaderRuntimeException;
import com.ge.trans.loader.manual.bs.data.domain.valueobjects.BSStatisticsVO;
import com.ge.trans.loader.manual.bs.data.domain.valueobjects.FaultSnapshotWrapper;
import com.ge.trans.loader.manual.bs.data.domain.valueobjects.LocoFault;
import com.ge.trans.loader.manual.bs.eservice.jaxb.FaultRequest;
import com.ge.trans.loader.manual.bs.eservice.jaxb.StatRequest;
import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;
import com.ge.trans.loader.manual.common.enums.ManualLoaderError;
import com.ge.trans.loader.manual.common.utils.ManualLoaderUtility;

public class EServiceClientConverter {
  private static final Logger LOGGER = LoggerFactory.getLogger(EServiceClientConverter.class);

  private EServiceClientConverter() {
    // PRIVATE CONSTRUCTOR
  }

  public static StatRequest convertToStatsRequest(BSStatisticsVO statisticsVO) {
    StatRequest statsRequest = new StatRequest();
    try {
      statsRequest.setXMotorMwhrs(statisticsVO.getMotorMWHrs());
      statsRequest.setXTotMiles(statisticsVO.getTotalMiles());
      statsRequest.setXIdealHours(statisticsVO.getIdleHours());
      statsRequest.setXN1(statisticsVO.getN1Param());
      statsRequest.setXN2(statisticsVO.getN2Param());
      statsRequest.setXN3(statisticsVO.getN3Param());
      statsRequest.setXN4(statisticsVO.getN4Param());
      statsRequest.setXN5(statisticsVO.getN5Param());
      statsRequest.setXN6(statisticsVO.getN6Param());
      statsRequest.setXN7(statisticsVO.getN7Param());
      statsRequest.setXN8(statisticsVO.getN8Param());
      statsRequest.setXTotEngHours(statisticsVO.getTotalEngHours());
    } catch (Exception e) {
      LOGGER.error("ERROR IN PREPARING STATS DATA");
      throw e;
    }
    return statsRequest;
  }

  public static Collection<FaultRequest> convertToFaultRequest(List<FaultSnapshotWrapper> faultAndSnapshots) {
    List<FaultRequest> faults = new ArrayList<>();
    try {
      for (FaultSnapshotWrapper wrapper : faultAndSnapshots) {
        LocoFault locoFault = wrapper.getLocoFault();
        FaultRequest request = new FaultRequest();

        request.setUuid(UUID.randomUUID().toString().replace(ManualLoaderConstants.HYPHEN, ""));
        request.setXFaultCode(locoFault.getFaultCode());

        request.setXLocoSpeed(locoFault.getLocoSpeed());
        request.setXDirection(locoFault.getDirection());
        request.setXNotch(locoFault.getNotch());
        request.setXEngSpeed(locoFault.getEngineSpeed());
        request.setXVolts(locoFault.getVolts());
        request.setXCurrentAmps(locoFault.getCurrentAmps());
        request.setXFldAmps(locoFault.getFldAmps());
        request.setXTempWater(locoFault.getWaterTemp());
        request.setXTempOil(locoFault.getOilTemp());
        request.setXRadfan(locoFault.getRadFan());
        request.setXHp(locoFault.getHp());
        request.setXFltIndex(ManualLoaderUtility.checkFaultIndex(locoFault.getFaultIndex()));
        request.setXOccurTime(locoFault.getEservicesOccurTime());
        request.setXSubId(locoFault.getSubId());
        // DATE Fields
        Date occurDate = ManualLoaderUtility.stringToDate(locoFault.getOccurDate(), ManualLoaderConstants.MMM_DD_HH_MM_SS_YYYY, null);
        request.setXOccurDate(ManualLoaderUtility.convertDateToString(occurDate, ManualLoaderConstants.YYYY_MM_DD_HH_MM_SS));
        Date resetDate = ManualLoaderUtility.stringToDate(locoFault.getFaultResetDate(), ManualLoaderConstants.MMM_DD_HH_MM_SS_YYYY, null);
        request.setXResetDate(ManualLoaderUtility.convertDateToString(resetDate, ManualLoaderConstants.YYYY_MM_DD_HH_MM_SS));
        faults.add(request);
      }
    } catch (Exception e) {
      LOGGER.error("ERROR IN PREPARING FAULTREQUEST");
      throw new LoaderRuntimeException(ManualLoaderError.EXCEPTION_WHILE_PREPARING_ESERVICES_FAULT_DATA.getErrorCode(),
        ManualLoaderError.EXCEPTION_WHILE_PREPARING_ESERVICES_FAULT_DATA.getErrorDesc() + e.getMessage());
    }
    return faults;
  }

}
