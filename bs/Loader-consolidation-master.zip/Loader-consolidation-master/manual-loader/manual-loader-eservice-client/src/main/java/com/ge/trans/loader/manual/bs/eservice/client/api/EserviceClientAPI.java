package com.ge.trans.loader.manual.bs.eservice.client.api;

import com.ge.trans.loader.manual.bs.data.domain.valueobjects.BSDecodedResponse;
import com.ge.trans.loader.manual.common.data.response.VehicleDetailsResponse;

public interface EserviceClientAPI {
    
    boolean sendDataToEService(BSDecodedResponse decodedData,VehicleDetailsResponse vInfo,String cabCaxTime,String messageUID,String programName);
}
