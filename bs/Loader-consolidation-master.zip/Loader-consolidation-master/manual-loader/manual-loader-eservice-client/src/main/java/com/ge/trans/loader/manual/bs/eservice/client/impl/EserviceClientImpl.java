package com.ge.trans.loader.manual.bs.eservice.client.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.ProducerTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.manual.bs.data.domain.valueobjects.BSDecodedResponse;
import com.ge.trans.loader.manual.bs.eservice.client.api.EserviceClientAPI;
import com.ge.trans.loader.manual.bs.eservice.jaxb.Request;
import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;
import com.ge.trans.loader.manual.common.data.response.VehicleDetailsResponse;
import com.ge.trans.loader.manual.common.utils.ManualLoaderUtility;

public class EserviceClientImpl implements EserviceClientAPI {
    private BSRestClient client;
    private static final Logger LOGGER = LoggerFactory.getLogger(EserviceClientImpl.class);
    
    private ProducerTemplate producerTemplate;
    
    @Override
    public boolean sendDataToEService(BSDecodedResponse decodedData, VehicleDetailsResponse vInfo, String cabCaxTime, String messageUID, String programName) {
        LOGGER.info("EserviceClientImpl:sendDataToEService BEGINS");
        
        Request eserviceRequest = transformToEServiceRequest(decodedData, vInfo, cabCaxTime, messageUID);
                Map<String, Object> requestMap=new HashMap<>();
                requestMap.put("eserviceRequest",eserviceRequest);
                requestMap.put("messageUID",messageUID);
                requestMap.put("programName",programName);
                client.setProducerTemplate(producerTemplate);
                // Response response = producerTemplate.requestBody("direct:sendToEService",eserviceRequest, Response.class);//commented to avoid retry logic for now
                client.processEServiceRequest(requestMap);
        
        LOGGER.info("EserviceClientImpl:sendDataToEService ENDS");
        return true;
    }
    
    private Request transformToEServiceRequest(BSDecodedResponse decodedData, VehicleDetailsResponse vInfo, String cabCaxTime, String messageUID) {
        Request inputRequest = new Request();
        inputRequest.setXCustName(vInfo.getCustomerId());
        //inputRequest.setXRoadNumber(vInfo.getEservicesVehicleNo());
        inputRequest.setXRoadNumber(vInfo.getVehicleNumber());
        Date cabTime = ManualLoaderUtility.stringToDate(cabCaxTime, ManualLoaderConstants.DEFAULT_CAB_CAX_DATE_FORMAT, null);
        inputRequest.setXCabCaxTime(ManualLoaderUtility.convertDateToString(cabTime, ManualLoaderConstants.YYYY_MM_DD_HH_MM_SS));
        inputRequest.setDateFormat(ManualLoaderConstants.YYYY_MM_DD_HH_MM_SS);
        inputRequest.setFileIdentifier(messageUID);
        inputRequest.setStat(EServiceClientConverter.convertToStatsRequest(decodedData.getBsStatisticsVO()));
        inputRequest.getFaults().addAll(EServiceClientConverter.convertToFaultRequest(decodedData.getFaultAndSnapshots()));
        return inputRequest;
    }
    
    public void setClient(BSRestClient client) {
        this.client = client;
    }
    
    public void setProducerTemplate(ProducerTemplate producerTemplate) {
        this.producerTemplate = producerTemplate;
    }
}
