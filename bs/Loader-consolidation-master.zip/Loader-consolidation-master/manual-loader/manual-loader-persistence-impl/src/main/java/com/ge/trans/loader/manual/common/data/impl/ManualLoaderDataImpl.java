package com.ge.trans.loader.manual.common.data.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.ProducerTemplate;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.manual.bs.data.domain.valueobjects.LocoFault;
import com.ge.trans.loader.manual.common.constant.ManualLoaderConstants;
import com.ge.trans.loader.manual.common.data.api.ManualLoaderDataAPI;
import com.ge.trans.loader.manual.common.data.request.FaultCodeRequest;
import com.ge.trans.loader.manual.common.data.request.MonitoringParamRequest;
import com.ge.trans.loader.manual.common.data.request.VehicleDetailsRequest;
import com.ge.trans.loader.manual.common.data.response.FaultCodeDefinition;
import com.ge.trans.loader.manual.common.data.response.ParamDefinition;
import com.ge.trans.loader.manual.common.data.response.VehicleDetailsResponse;

public class ManualLoaderDataImpl implements ManualLoaderDataAPI {

  private ProducerTemplate producerTemplate;
  private static final Logger LOGGER = LoggerFactory.getLogger(ManualLoaderDataImpl.class);

  @SuppressWarnings("unchecked")
  @Override
  public VehicleDetailsResponse findVehicleDetails(VehicleDetailsRequest request) {
    VehicleDetailsResponse output = null;
    Map<String, Object> argumentsMap = new HashMap<String, Object>();
    argumentsMap.put(ManualLoaderConstants.VEHICLE_NUMBER, request.getVehicleNumber());
    argumentsMap.put(ManualLoaderConstants.CUSTOMER_ID, request.getCustomerId());
    argumentsMap.put(ManualLoaderConstants.VEHICLE_HEADER, request.getVehicleInitial());
    List<Map<String, Object>> list = producerTemplate.requestBody("direct:findVehicleDetails", argumentsMap, List.class);
    for (Map<String, Object> map : list) {
      output = new VehicleDetailsResponse();
      String customerId = map.get(ManualLoaderConstants.ORG_ID).toString();
      output.setCustomerId(customerId);
      String orgName = map.get(ManualLoaderConstants.ORG_NAME).toString();
      BigDecimal vehicleObjid = (BigDecimal) map.get(ManualLoaderConstants.VEHICLE_OBJID);
      output.setOrgName(orgName);
      output.setVehicleObjid(vehicleObjid.longValue());
      String vehicleNumber = map.get(ManualLoaderConstants.SERIAL_NO).toString();
      output.setVehicleNumber(vehicleNumber);
      LOGGER.info("VEHICLE OBJID:{}|CUSTOMER ID:{}|VEHICLE NUMBER:{}", vehicleObjid, customerId, vehicleNumber);
    }
    return output;
  }

  public void setProducerTemplate(ProducerTemplate producerTemplate) {
    this.producerTemplate = producerTemplate;
  }

  @SuppressWarnings("unchecked")
  @Override
  public List<ParamDefinition> findParamDefinition(MonitoringParamRequest request) {
    List<ParamDefinition> paramDetails = null;
    Map<String, Object> argumentsMap = new HashMap<String, Object>();
    argumentsMap.put(ManualLoaderConstants.CONTROLLER_SOURCE_ID, request.getControllerSourceId());
    argumentsMap.put(ManualLoaderConstants.PARAM_LOAD_COLUMN, request.getParamLoadColumn());
    argumentsMap.put(ManualLoaderConstants.PARAM_NUMBER, request.getParamNumber());
    List<Map<String, Object>> list = producerTemplate.requestBody("direct:getParamDefinitionDetails", argumentsMap, List.class);
    paramDetails = new ArrayList<>();
    for (Map<String, Object> map : list) {
      ParamDefinition definition = new ParamDefinition();
      String startBit = map.get(ManualLoaderConstants.START_BIT).toString();
      definition.setStartBit(new BigDecimal(startBit));
      String bitToCount = map.get(ManualLoaderConstants.BIT_TO_COUNT).toString();
      definition.setBitToCount(new BigDecimal(bitToCount));
      String paramLoadTable = map.get(ManualLoaderConstants.PARM_LOAD_TABLE).toString();
      definition.setParamLoadTable(paramLoadTable);
      String paramLoadColumn = map.get(ManualLoaderConstants.PARM_LOAD_COLUMN).toString();
      definition.setParamLoadColumn(paramLoadColumn);
      paramDetails.add(definition);
      LOGGER.debug("STAR BIT:{}|BIT TO COUNT:{}|PARAM LOAD TABLE:{}|PARAM LOAD COLUMN:{}", startBit, bitToCount, paramLoadTable, paramLoadColumn);
    }

    return paramDetails;
  }

  @SuppressWarnings("unchecked")
  @Override
  public FaultCodeDefinition findFaultCodeDefinition(FaultCodeRequest request) {
    LOGGER.debug("findFaultCodeDefinition for keys faultCode: {}, subId: {}, controllerSourceID: {}", request.getFaultCode(), request.getSubId(),
      request.getControllerSourceID());
    FaultCodeDefinition faultCodeDefinition = null;
    Map<String, Object> argumentsMap = new HashMap<String, Object>();
    argumentsMap.put(ManualLoaderConstants.CONTROLLER_SOURCE_ID, request.getControllerSourceID());
    argumentsMap.put(ManualLoaderConstants.FAULT_CODE, request.getFaultCode());
    argumentsMap.put(ManualLoaderConstants.SUB_ID, request.getSubId());
    List<Map<String, Object>> rows = producerTemplate.requestBody("direct:findFaultCodeDefinition", argumentsMap, List.class);
    if (CollectionUtils.isNotEmpty(rows)) {
      faultCodeDefinition = new FaultCodeDefinition();
      Map<String, Object> map = rows.get(0);
      faultCodeDefinition.setCriticalFlag(map.get(ManualLoaderConstants.CRITICAL_FLAG).toString());
      faultCodeDefinition.setObjId(Long.parseLong(map.get(ManualLoaderConstants.OBJID).toString()));
      faultCodeDefinition.setFaultCode(map.get(ManualLoaderConstants.FAULT_CODE2).toString());
      faultCodeDefinition.setFaultDesc(map.get(ManualLoaderConstants.FAULT_DESC).toString());
    }
    return faultCodeDefinition;
  }

  @SuppressWarnings("unchecked")
  public BigDecimal findFaultObjid(LocoFault locoFault) {
    Map<String, Object> paramMap = new HashMap<String, Object>();
    BigDecimal toolsFltObjid = BigDecimal.ZERO;
    paramMap.put(ManualLoaderConstants.FAULT_CODE, locoFault.getFaultCode());
    paramMap.put(ManualLoaderConstants.SUB_ID, locoFault.getSubId());
    paramMap.put(ManualLoaderConstants.CONTROLLER_SOURCE_ID, locoFault.getControllerSourceId());
    paramMap.put(ManualLoaderConstants.OCCUR_DATE, locoFault.getOccurDate());
    paramMap.put(ManualLoaderConstants.OCCUR_TIME, locoFault.getOccurTime());
    paramMap.put(ManualLoaderConstants.FAULT2_VEHICLE, locoFault.getFault2vehicle());
    paramMap.put(ManualLoaderConstants.FAULT2FAULT_CODE, locoFault.getFault2faultCode());
    List<Map<String, Object>> list = producerTemplate.requestBody("direct:isNewFault", paramMap, List.class);
    if (CollectionUtils.isNotEmpty(list)) {
      toolsFltObjid = (BigDecimal) list.get(0).get("objid");
      LOGGER.info("Fault Already Exists and  GETS_TOOL_FAULT [OBJID={} ] ", toolsFltObjid);
    }

    return toolsFltObjid;
  }

  @Override
  public int updateToolRunNextwithFCT(VehicleDetailsResponse vehicleDetails, double faultCollectionTime, String programName) {
    LOGGER.info("START updateToolRunNextwithFCT");
    int noOfRecordsUpdated = 0;
    Map<String, Object> argumentsMap = new HashMap<String, Object>();
    argumentsMap.put(ManualLoaderConstants.VEHICLE_OBJID2, vehicleDetails.getVehicleObjid());
    argumentsMap.put(ManualLoaderConstants.FAULT_COLLECTION_TIME, faultCollectionTime);
    argumentsMap.put(ManualLoaderConstants.LAST_UPDATED_BY, programName);
    BigDecimal updatedRecordCount = producerTemplate.requestBody("direct:updateToolRunNextwithFCT", argumentsMap, BigDecimal.class);
    noOfRecordsUpdated = (null != updatedRecordCount) ? updatedRecordCount.intValue() : 0;
    LOGGER.info("Number of records updated {}", noOfRecordsUpdated);
    LOGGER.info("END updateToolRunNextwithFCT");
    return noOfRecordsUpdated;

  }

  @Override
  public String getRmdSysParmValue(String title) {
    Map<String, Object> argumentsMap = new HashMap<String, Object>();
    argumentsMap.put(ManualLoaderConstants.TITLE2, title);
    return producerTemplate.requestBody("direct:getRmdSysParmValue", argumentsMap, String.class);
  }

  @Override
  public int getToolFaultRecordCount(String recordType, String lookupBackTime, long vehicleObjid) {
    Map<String, Object> argumentsMap = new HashMap<String, Object>();
    argumentsMap.put(ManualLoaderConstants.RECORD_TYPE, recordType);
    argumentsMap.put(ManualLoaderConstants.DURATION, lookupBackTime);
    argumentsMap.put(ManualLoaderConstants.VEHICLE_OBJID2, vehicleObjid);
    BigDecimal result = producerTemplate.requestBody("direct:getToolFaultRecordCount", argumentsMap, BigDecimal.class);
    return (null != result) ? result.intValue() : 0;
  }

  @Override
  public Long getMessageIdSequenceValue() {
    BigDecimal result = (BigDecimal) producerTemplate.requestBody("direct:getMessageIdSequence", null, BigDecimal.class);
    return (null != result) ? result.longValue() : 0;
  }
}
