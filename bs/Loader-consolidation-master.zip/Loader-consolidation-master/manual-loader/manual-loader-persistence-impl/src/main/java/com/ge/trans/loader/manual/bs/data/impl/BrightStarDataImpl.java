package com.ge.trans.loader.manual.bs.data.impl;

import org.apache.camel.ProducerTemplate;

import com.ge.trans.loader.manual.bs.data.api.BrightStarDataAPI;
import com.ge.trans.loader.manual.bs.data.domain.valueobjects.FaultSnapshotWrapper;

/**
 * AN INTERFACE FOR IMPLEMENTING BRIGHT-STAR PERSISTENCE SERVICES.
 */
public class BrightStarDataImpl implements BrightStarDataAPI {
  private ProducerTemplate producerTemplate;

  public void setProducerTemplate(ProducerTemplate producerTemplate) {
    this.producerTemplate = producerTemplate;
  }

  @Override
  public void saveIncidentAndSnapshot(FaultSnapshotWrapper wrapperInput) {
    producerTemplate.sendBody("direct:saveBSIncidentAndSnapshot", wrapperInput);
  }

}
