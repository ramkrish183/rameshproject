package com.ge.trans.loader.manual.bs.data.helper;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.ge.trans.loader.manual.bs.data.domain.valueobjects.FaultSnapshotWrapper;

public class SQLParamHelper {
    private static final Logger LOGGER = LoggerFactory.getLogger(SQLParamHelper.class);
    public Map<String, Object> createFaultRequestParam(FaultSnapshotWrapper wrapper, String createdBy) {
        Map<String, Object> paramMap = new HashMap<String, Object>();
        paramMap.put("faultSequenceId", wrapper.getLocoFault().getObjid());
        paramMap.put("recordType", wrapper.getLocoFault().getRecordType());
        paramMap.put("faultCode", wrapper.getLocoFault().getFaultCode());
        paramMap.put("subId", wrapper.getLocoFault().getSubId());
        paramMap.put("controllerSourceId", wrapper.getLocoFault().getControllerSourceId());
        paramMap.put("occurDate", wrapper.getLocoFault().getOccurDate());
        paramMap.put("faultResetDate", wrapper.getLocoFault().getFaultResetDate());
        paramMap.put("occurTime", wrapper.getLocoFault().getOccurTime());
        paramMap.put("offboardLoadDate", wrapper.getLocoFault().getOffboardLoadDate());
        paramMap.put("fault2FaultCode", wrapper.getLocoFault().getFault2faultCode());
        paramMap.put("faultResetLoadDate", wrapper.getLocoFault().getFaultResetLoadDate());
        paramMap.put("faultResetTime", wrapper.getLocoFault().getFaultResetTime());
        paramMap.put("fault2Vehicle", wrapper.getLocoFault().getFault2vehicle());
        paramMap.put("lastUpdatedBy", createdBy);
        paramMap.put("createdBy",createdBy); 
        paramMap.put("getsMessageId",wrapper.getLocoFault().getGetsMessageId()); 
        String faultIndex= (StringUtils.isNotBlank(wrapper.getLocoFault().getFaultIndex())? wrapper.getLocoFault().getFaultIndex():"0");
        paramMap.put("faultIndex",faultIndex.trim());
        return paramMap;
    }
    
    public Map<String, Object> createSnapshotParams(Map<String, Object> paramMap, String faultObjId, String createdBy) {
        paramMap.put("faultSequenceId", faultObjId);
        paramMap.put("lastUpdatedBy", createdBy);
        paramMap.put("createdBy",createdBy);
        LOGGER.info("MP PARAMS:{}", paramMap.toString());
        return paramMap;
    }
}
