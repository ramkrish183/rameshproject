package com.ge.trans.rmd.aop.interceptors;

 
import java.lang.reflect.Method;

import org.aopalliance.intercept.MethodInvocation;
 
 
import org.springframework.web.bind.annotation.RequestMapping;

public class PerformanceAroundLogPrint {

	public static Object logPerformanceStats(MethodInvocation methodInvocation) throws Throwable {

		long startTime = System.currentTimeMillis();

		printRequestUrl(methodInvocation);

		Object result;
		try {
			result = methodInvocation.proceed();
		} catch (Exception e) {
			throw e;
		}
		finally{
			long endTime = System.currentTimeMillis();
		}
		return result;

	}

	private static void printRequestUrl(MethodInvocation methodInvocation) {

		try {

			Method method = methodInvocation.getMethod();
			String name = method.getDeclaringClass().getName();
			if (name.contains("controller")) {
				RequestMapping annotation = method.getAnnotation(org.springframework.web.bind.annotation.RequestMapping.class);
				String[] value = annotation.value();
				System.out.println("*** RWeb::Begin : Request URL :: " + value[0]);
			}
		} catch (Exception e) {
		}

	}

}
