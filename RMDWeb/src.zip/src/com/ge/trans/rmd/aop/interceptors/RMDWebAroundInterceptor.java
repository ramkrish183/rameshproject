package com.ge.trans.rmd.aop.interceptors;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class RMDWebAroundInterceptor implements MethodInterceptor {

	public Object invoke(MethodInvocation methodInvocation) throws Throwable {
		
		Object o =PerformanceAroundLogPrint.logPerformanceStats(methodInvocation);
		
		return o;
	}

	
}
