/**
 * ============================================================
 * File : RoleManagementServiceImpl.java
 * Description : ServiceImpl layer class for Role management
 * 
 * Package : com.ge.trans.rmd.common.mvc.controller
 * Author : iGATE
 * Last Edited By :
 * Version : 1.0
 * Created on : November 19, 2012
 * History :
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2012 General Electric Company. All rights reserved
 *
 * ============================================================
 */

package com.ge.trans.rmd.common.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.common.beans.PrivilegeBean;
import com.ge.trans.rmd.common.beans.RoleManagementBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.vo.DeleteRolesResponseVO;
import com.ge.trans.rmd.common.vo.DeleteRolesUpdateVO;
import com.ge.trans.rmd.common.vo.PrivilegeVO;
import com.ge.trans.rmd.common.vo.RolesVO;
import com.ge.trans.rmd.services.authorization.valueobjects.DeleteRoleListType;
import com.ge.trans.rmd.services.authorization.valueobjects.DeleteRolesDetailsType;
import com.ge.trans.rmd.services.authorization.valueobjects.DeleteRoleType;
import com.ge.trans.rmd.services.authorization.valueobjects.PrivilegeDetailsType;
import com.ge.trans.rmd.services.authorization.valueobjects.RoleManagementRequestType;
import com.ge.trans.rmd.services.authorization.valueobjects.RolesResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

/*******************************************************************************
 * 
 * @Author : iGATE
 * @Version : 1.0
 * @Date Created:
 * @Date Modified :
 * @Modified By :
 * @Contact :
 * @Description : This is the service layer class which is used for
 *              RoleManagement
 * @History :
 * 
 ******************************************************************************/
@Service
public class RoleManagementServiceImpl extends RMDBaseServiceImpl implements
		RoleManagementService {

	@Autowired
	private WebServiceInvoker rsInvoker;
	@Autowired
	private AuthorizationService authService;
	
	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());
	
	

	/**
	 * @Author:iGATE
	 * @param roleId
	 * @return List<PrivilegeVO>
	 * @Description: method to get all the privileges in a tree structure with
	 *               child inside parent structure.
	 */
	public List<PrivilegeVO> getAllPrivileges(String roleId)
			throws GenericAjaxException, RMDWebException {

		List<PrivilegeVO> arlPrivilegeBeans = null;
		PrivilegeVO objPrivilegeVO = null;
		Map<Long, PrivilegeVO> hm = new HashMap<Long, PrivilegeVO>();
		List<PrivilegeVO> tempChildList = null;
		PrivilegeVO objBean2 = new PrivilegeVO();
		PrivilegeDetailsType[] arlPrivilegeResponseType = null;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		String dragAndDrop = AppConstants.STR_Y;
		List<String> arlDragAndDrop = null;

		try {
			queryParams.put(AppConstants.ROLE_ID, roleId);
			arlPrivilegeResponseType = (PrivilegeDetailsType[]) rsInvoker.get(
					ServiceConstants.GET_ALL_PRIVILEGES, null, queryParams,
					null, PrivilegeDetailsType[].class);

			if (arlPrivilegeResponseType != null
					&& arlPrivilegeResponseType.length > 0) {
				String dragAndDropPriv = authService
						.getLookUpValueForName(AppConstants.ROLE_TREE_DRAG_AND_DROP_PRIVILEGE);
				if (null != dragAndDropPriv
						&& !RMDCommonConstants.EMPTY_STRING
								.equalsIgnoreCase(dragAndDropPriv)) {
					String[] resourceTypes = dragAndDropPriv
							.split(AppConstants.COMMA);
					arlDragAndDrop = Arrays.asList(resourceTypes);
				}

				for (PrivilegeDetailsType objPrivilege : arlPrivilegeResponseType) {
					objPrivilegeVO = new PrivilegeVO();
					if (null != arlDragAndDrop && !arlDragAndDrop.isEmpty()) {
						if (arlDragAndDrop.contains(objPrivilege
								.getResourceType())) {
							dragAndDrop = AppConstants.STR_Y;
						} else {
							dragAndDrop = AppConstants.STR_N;
						}
					}

					String roleDescription = objPrivilege.getDescription();
					if (null != roleDescription && !roleDescription.isEmpty()) {
						if (roleDescription.length() > 30) {
							roleDescription = roleDescription.substring(0, 29)
									+ "...";
							objPrivilegeVO.setTooltip(objPrivilege
									.getDescription());
						}
					}

					
					objPrivilegeVO.setPrivilegeName(objPrivilege
							.getPrivilegeName());
					objPrivilegeVO.setTitle(objPrivilege.getDisplayName()
							+ RMDCommonConstants.OPEN_BRACKET + roleDescription
							+ RMDCommonConstants.CLOSE_BRACKET);

					objPrivilegeVO.setKey(objPrivilege.getLevel()
							+ AppConstants.NEGOTION_SYMBOL
							+ objPrivilege.getPrivilegeId()
							+ AppConstants.NEGOTION_SYMBOL + dragAndDrop);
					objPrivilegeVO
							.setDisplayName(objPrivilege.getDisplayName());
					objPrivilegeVO.setSortOrder(objPrivilege.getSortOrder());
					objPrivilegeVO.setEnabled(objPrivilege.isEnabled());
					objPrivilegeVO.setPrivilegeId(objPrivilege.getPrivilegeId()
							.toString());
					objPrivilegeVO.setParentId(objPrivilege.getParentId()
							.toString());
					objPrivilegeVO.setResourceType(objPrivilege
							.getResourceType());
					if (objPrivilege.getParentId() == 0L) {

						hm.put(objPrivilege.getPrivilegeId(), objPrivilegeVO);

					} else {

						if (hm.containsKey(objPrivilege.getParentId())) {
							objBean2 = hm.get(objPrivilege.getParentId());
							if (null != objBean2.getArlChild()
									&& objBean2.getArlChild().size() > 0) {
								tempChildList.add(objPrivilegeVO);
							} else {
								tempChildList = new ArrayList<PrivilegeVO>();
								tempChildList.add(objPrivilegeVO);
							}
							Collections.sort(tempChildList);
							objBean2.setArlChild(tempChildList);
							hm.put(objPrivilege.getParentId(), objBean2);

						} else {

							getPrivilegeTreeStructure(hm, objPrivilege
									.getParentId().toString(), objPrivilegeVO);

						}

					}

				}
				arlPrivilegeBeans = new ArrayList<PrivilegeVO>(hm.values());
				Collections.sort(arlPrivilegeBeans);
			}
		} catch (Exception ex) {
			logger.error("Exception occured in getAllPrivileges method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return arlPrivilegeBeans;
	}

	/**
	 * @Author:iGATE
	 * @param roleManagementBean
	 * @return void
	 * @Description: method to edit the roles
	 */
	public void editRole(RoleManagementBean roleManagementBean)
			throws GenericAjaxException, RMDWebException {
		final Map<String, String> headerParams = getHeaderMap(roleManagementBean);
		RoleManagementRequestType objRoleManagementRequestType = new RoleManagementRequestType();
		PrivilegeDetailsType objPrivilegeDetailsType = null;
		try {
			objRoleManagementRequestType.setRoleId(roleManagementBean
					.getRoleId());
			objRoleManagementRequestType.setRoleName(roleManagementBean
					.getRoleName());
			objRoleManagementRequestType.setRoleDescription(roleManagementBean
					.getRoleDescription());
			List<PrivilegeBean> arlPrivilegeBean = roleManagementBean
					.getPrivileges();
			for (PrivilegeBean privilegeBean : arlPrivilegeBean) {
				objPrivilegeDetailsType = new PrivilegeDetailsType();
				objPrivilegeDetailsType.setPrivilegeId(Long
						.valueOf(privilegeBean.getPrivilegeId()));
				objPrivilegeDetailsType.setSortOrder(privilegeBean
						.getSortOrder());
				objRoleManagementRequestType.getPrivileges().add(
						objPrivilegeDetailsType);
			}

			rsInvoker.put(ServiceConstants.EDIT_ROLE,
					objRoleManagementRequestType, headerParams);
		} catch (Exception ex) {
			logger.error("Exception occured in editRole method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}

	}
	
	public void deleteRole(RoleManagementBean objRoleManagementBean)
			throws GenericAjaxException, RMDWebException{
		final Map<String, String> headerParams = getHeaderMap(objRoleManagementBean);
		RoleManagementRequestType objRoleManagementRequestType = new RoleManagementRequestType();
		try {
			objRoleManagementRequestType.setRoleId(objRoleManagementBean
					.getRoleId());
			rsInvoker.put(ServiceConstants.DELETE_ROLE,
					objRoleManagementRequestType, headerParams);
		} catch (Exception ex) {
			logger.error("Exception occured in deleteRole method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
	}
	

	/**
	 * @Author:iGATE
	 * @param roleManagementBean
	 * @return void
	 * @Description: method to add the roles
	 */
	public void addOrCopyRole(RoleManagementBean roleManagementBean)
			throws GenericAjaxException, RMDWebException {
		final Map<String, String> headerParams = getHeaderMap(roleManagementBean);
		RoleManagementRequestType objRoleManagementRequestType = new RoleManagementRequestType();
		PrivilegeDetailsType objPrivilegeDetailsType = null;
		try {
			objRoleManagementRequestType.setRoleName(roleManagementBean
					.getRoleName());
			objRoleManagementRequestType.setRoleDescription(roleManagementBean
					.getRoleDescription());
			List<PrivilegeBean> arlPrivilegeBean = roleManagementBean
					.getPrivileges();
			for (PrivilegeBean privilegeBean : arlPrivilegeBean) {
				objPrivilegeDetailsType = new PrivilegeDetailsType();
				objPrivilegeDetailsType.setPrivilegeId(Long
						.valueOf(privilegeBean.getPrivilegeId()));
				objPrivilegeDetailsType.setSortOrder(privilegeBean
						.getSortOrder());
				objRoleManagementRequestType.getPrivileges().add(
						objPrivilegeDetailsType);
			}

			rsInvoker.put(ServiceConstants.ADD_ROLE,
					objRoleManagementRequestType, headerParams);

		} catch (Exception ex) {
			logger.error("Exception occured in addRole method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}

	}

	/**
	 * @Author:iGATE
	 * @param UserManagementBean
	 * @return void
	 * @Description: This method will return all roles from database
	 */
	public List<RolesVO> getAllRoles(RoleManagementBean objRoleManagementBean)
			throws RMDWebException, Exception {

		RolesResponseType[] arRoleRespType = null;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		final Map<String, String> headerParams = getHeaderMap(objRoleManagementBean);
		final List<RolesVO> rolesVOLst = new ArrayList<RolesVO>();
		RolesVO roleVO = null;

		try {

			arRoleRespType = (RolesResponseType[]) rsInvoker.get(
					ServiceConstants.ADMIN_SERVICE_GET_ALL_ROLES, null,
					queryParams, headerParams, RolesResponseType[].class);

			if (arRoleRespType != null && arRoleRespType.length > 0) {
				for (RolesResponseType roleRespType : arRoleRespType) {
					roleVO = new RolesVO();
					roleVO.setGetUsrRolesSeqId(roleRespType.getRoleSeqId());
					roleVO.setRoleName(roleRespType.getRoleName());
					roleVO.setStatus(roleRespType.getStatus());
					roleVO.setRoleDesc(roleRespType.getRoleDescription());
					roleVO.setLastUpdatedBy(roleRespType.getLastUpdatedBy());
					
					//yyyy-MM-dd HH:mm:ss.SSS
					String startDateString =roleRespType.getLastUpdatedTime();
					DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS"); 
					SimpleDateFormat sm = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				    Date startDate;
				    startDate = df.parse(startDateString);
				    String newDateString = sm.format(startDate);
				   
				    roleVO.setLastUpdatedTime(newDateString);
				   
					
					rolesVOLst.add(roleVO);
				}
			}
		} catch (Exception ex) {
			logger.error("Exception occured in getAllRoles method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		logger.debug("UserManagementServiceImpl : getAllRoles() method Ends");
		return rolesVOLst;
	}

	/**
	 * @Author:iGATE
	 * @param hmMapChild
	 *            ,parentId,objBean
	 * @return void
	 * @throws Exception
	 * @Description: This method is used to get the Privilege tree structure for
	 *               n-levels
	 */
	public void getPrivilegeTreeStructure(Map<Long, PrivilegeVO> hmMapChild,
			String parentId, PrivilegeVO objBean) throws Exception {
		try {
			PrivilegeVO objBean2 = new PrivilegeVO();
			Iterator entry = hmMapChild.entrySet().iterator();
			while (entry.hasNext()) {
				Map.Entry<Long, PrivilegeVO> map = (Map.Entry<Long, PrivilegeVO>) entry
						.next();
				objBean2 = map.getValue();
				addChildsToParent(objBean2, parentId, objBean);

			}
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * @Author:iGATE
	 * @param hmMapChild
	 *            ,parentId,objBean
	 * @return void
	 * @throws Exception
	 * @Description: This method is used to get the Privilege tree structure for
	 *               n-levels. In this method we will add the childs to the
	 *               parent for n-levels
	 */
	public void addChildsToParent(PrivilegeVO objBean2, String parentId,
			PrivilegeVO objBean) throws Exception {
		try {
			PrivilegeVO objBean3 = new PrivilegeVO();
			int size = objBean2.getArlChild().size();
			for (int i = 0; i < size; i++) {
				objBean3 = objBean2.getArlChild().get(i);
				if (parentId.equalsIgnoreCase(objBean3.getPrivilegeId())) {
					objBean3.getArlChild().add(objBean);
					Collections.sort(objBean3.getArlChild());
				} else if (null != objBean3.getArlChild()
						&& objBean3.getArlChild().size() > 0) {
					addChildsToParent(objBean3, parentId, objBean);
				}

			}
		} catch (Exception e) {
			throw e;
		}

	}
	
	@Override
	public List<DeleteRolesResponseVO> getDeleteRoleList(RoleManagementBean objRoleManagementBean)
	throws GenericAjaxException, RMDWebException{
		final Map<String, String> headerParams = getHeaderMap(objRoleManagementBean);
		
		DeleteRolesDetailsType[] responseDeleteRolesDetailsType = null;
		
		List<DeleteRolesResponseVO> responseList = new ArrayList<DeleteRolesResponseVO>();
		String roleId = objRoleManagementBean.getRoleId();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		
		try {
			queryParams.put(AppConstants.ROLE_ID, roleId);
			
			responseDeleteRolesDetailsType =(DeleteRolesDetailsType[]) rsInvoker.get(ServiceConstants.DELETE_ROLE_LIST,null,
					queryParams, headerParams,DeleteRolesDetailsType[].class);
			if(responseDeleteRolesDetailsType!=null){
				
				for (DeleteRolesDetailsType deleteRolesDetailsType2 : responseDeleteRolesDetailsType) {
					DeleteRolesResponseVO deleteRolesResponseVO = new DeleteRolesResponseVO();
					deleteRolesResponseVO.setFirstName(deleteRolesDetailsType2.getFirstName());
					deleteRolesResponseVO.setLastName(deleteRolesDetailsType2.getLastName());
					deleteRolesResponseVO.setUserId(deleteRolesDetailsType2.getUserId());
					deleteRolesResponseVO.setUserSeqId(deleteRolesDetailsType2.getUserSeqId());
					deleteRolesResponseVO.setUserCustomers(deleteRolesDetailsType2.getUserCustomers());
					responseList.add(deleteRolesResponseVO);
				}
		
			}
			
			
		} catch (Exception ex) {
			ex.printStackTrace();
			logger.error("Exception occured in getDeleteRoleList method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		
		return responseList;
	}

	
	public void deleteRoleUpdateList(List<DeleteRolesUpdateVO> tempList, String userId) throws GenericAjaxException, RMDWebException{
		
		DeleteRoleListType responseType = new DeleteRoleListType();
		List<DeleteRoleType> deleteRoleTypes = new ArrayList<DeleteRoleType>();
		try {
			if (!tempList.isEmpty()) {
				for (DeleteRolesUpdateVO updateListItem : tempList) {
					DeleteRoleType deleteRoleType = new DeleteRoleType();

					if (!RMDCommonUtility.isNullOrEmpty(updateListItem.getUserId())) {
						deleteRoleType.setUserId(updateListItem.getUserId());
					}
					if (!RMDCommonUtility.isNullOrEmpty(updateListItem.getCurrentRole())) {
						deleteRoleType.setCurrentRole(updateListItem.getCurrentRole());
					}
					if (!RMDCommonUtility.isNullOrEmpty(updateListItem.getChangedRoleId())){
						deleteRoleType.setChangedRoleId(updateListItem.getChangedRoleId());
					}
					if (!RMDCommonUtility.isNullOrEmpty(updateListItem.getUserSeqId())){
						deleteRoleType.setUserSeqId(updateListItem.getUserSeqId());
					}
					
					deleteRoleTypes.add(deleteRoleType);
				}
				responseType.setDeleteRoleTypeList(deleteRoleTypes);
			}
			responseType.setUserId(userId);
			rsInvoker.post(ServiceConstants.DELETE_ROLE_UPDATE_LIST, responseType, String.class);
			 
			} catch (Exception ex) {
				logger.error("Exception occured in deleteRoleUpdateList method ", ex);
				RMDWebErrorHandler.handleException(ex);
			}
		}


}
