/**
 * ============================================================
 * Classification: GE Confidential
 * File : AuthorizationServI.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.service;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on : November 14, 2011
 * History
 * Modified By : iGATE
 *
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.common.beans.UserLoginBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.AuthorizationException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.vo.ErrorVO;
import com.ge.trans.rmd.common.vo.MenuListResourceVO;
import com.ge.trans.rmd.common.vo.ResourceVO;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.authorization.valueobjects.RolePrivilegesType;
import com.ge.trans.rmd.services.error.valueobjects.ExceptionRequestType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class AuthorizationServiceImpl extends RMDBaseServiceImpl implements
		AuthorizationService {

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	private WebServiceInvoker rsInvoker;
	@Autowired
	private CachedService cachedService;

	
	/**
	 * @throws RMDWebException
	 *             This Method is used for calling Web Service and get list of
	 *             RolePrivilegesType parameters passed in roleID
	 * 
	 * @param roleID
	 * @return List of RolePrivilegesType
	 * @throws
	 */
	@Override
	public List<RolePrivilegesType> authorize(final UserLoginBean userBean)
			throws RMDWebException, Exception {
		rmdWebLogger.debug("Entered into authorize() method ");
		

		RolePrivilegesType[] rolePrivList = null;
		final List<RolePrivilegesType> rolePrevType = new ArrayList<RolePrivilegesType>();
		try {
			final Map<String, String> qParamLogin = new LinkedHashMap<String, String>();
			qParamLogin.put(AppConstants.ROLE_ID,
					String.valueOf(userBean.getUserVO().getRoleId()));

			final Map<String, String> headerParams = getHeaderMap(userBean);

			rolePrivList = (RolePrivilegesType[]) rsInvoker
					.get(ServiceConstants.SECURITY_SERVICE_GET_ROLE_PRIVILAGES,
							qParamLogin, null, headerParams,
							RolePrivilegesType[].class);
			if (rolePrivList != null && rolePrivList.length > 0) {
				for (RolePrivilegesType rPL : rolePrivList) {
					rolePrevType.add(rPL);
				}
			}
		} catch (RMDWebException rmdEx) {
			// TODO Auto-generated catch block
			rmdWebLogger.error(
					"RMDWebException occured in authorize() method ", rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error("Exception occured in authorize() method ", exp);
			throw exp;
		}
		rmdWebLogger.debug("authorize():End");
		return rolePrevType;
	}

	/**
	 * This Method is used for calling authorize() and return List of MAP
	 * parameters passed in Map<String, ResourceVO> primaryNavMap, Map<String,
	 * List<ResourceVO>> secondaryNAvMap,Integer roleID
	 * 
	 * @param Map
	 *            <String, ResourceVO> primaryNavMap, Map<String,
	 *            List<ResourceVO>> secondaryNAvMap,Integer roleID
	 * @return List of MAP
	 * @throws
	 */
	@Override
	public MenuListResourceVO getPrivileges(
			final Map<String, ResourceVO> primaryNavMap,
			final Map<String, List<ResourceVO>> secondaryNAvMap,
			final UserLoginBean userBean) throws RMDWebException, Exception {
		rmdWebLogger.debug("getPrivileges():Start");
		MenuListResourceVO menuListResourceVO = null;
		final Map<String, List<ResourceVO>> secondaryNAvURLMap = new LinkedHashMap<String, List<ResourceVO>>();
		try {

			//final List<RolePrivilegesType> rolePrevType = authorize(userBean);
			//final List<RolePrivilegesType> rolePrevTypeSec = authorizeSecNav(userBean);
			final List<RolePrivilegesType> rolePrevType = cachedService.getRolePrivileges(userBean);
			final List<RolePrivilegesType> rolePrevTypeSec = cachedService.authorizeSecNav(userBean);
			menuListResourceVO = getMenuForPrivilages(rolePrevType,
					primaryNavMap, secondaryNAvMap);
			 getSecondaryNavigationMenuForRole(menuListResourceVO,rolePrevTypeSec,secondaryNAvURLMap);
			
		} catch (RMDWebException rmdExp) {
			rmdWebLogger.error(
					"RMDWebException occured in getPrivileges() method ",
					rmdExp);
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(rmdExp
					.getMessage())) {
				throw new AuthorizationException(rmdExp.getCode(),
						rmdExp.getMessage());
			} else {
				throw rmdExp;
			}
		} catch (Exception exp) {
			rmdWebLogger.error("Exception occured in getPrivileges() method ",
					exp);
			throw exp;
		}
		rmdWebLogger.debug("getPrivileges():End");
		return menuListResourceVO;
	}

	/**
	 * This Method is used for filtering the Menu based on the Privilages for a
	 * User Role.In this method will get name,accesslevel,secNavigationURL,image and newFlag from RolePrivilegesType ]
	 * and set it to  ResourceVO
	 *  User Role parameters passed in List<RolePrivilegesType> rolePrevType,
	 * MenuListResourceVO menuListResourceVO,Map<String, ResourceVO> primaryNavMap, Map<String, List<ResourceVO>>
	 * secondaryNAvMap
	 * 
	 * @param List
	 * 				MenuListResourceVO menuListResourceVO,
	 *            <RolePrivilegesType> rolePrevType, Map<String, ResourceVO>
	 *            primaryNavMap, Map<String, List<ResourceVO>> secondaryNAvMap
	 * @return List of MAP
	 * @throws
	 */
	private void getSecondaryNavigationMenuForRole(final MenuListResourceVO menuListResourceVO,
			final List<RolePrivilegesType> rolePrevTypeSec,Map<String, 
			List<ResourceVO>> secondaryNAvURLMap)throws RMDWebException 
	{
			rmdWebLogger.debug("getSecondaryNavigationMenuForRole():Start");
			ResourceVO SecondaryNavResource;
			final List<ResourceVO> secnavResorceLst=new ArrayList<ResourceVO>();
			if(null != rolePrevTypeSec && !rolePrevTypeSec.isEmpty()){
				for (RolePrivilegesType roleSecNavPlge : rolePrevTypeSec) 
				{
					final String strTabName = roleSecNavPlge.getName();
					if(strTabName!=null && !AppConstants.BLANK_STRING.equalsIgnoreCase(strTabName))
					{
						SecondaryNavResource=new ResourceVO();
						SecondaryNavResource.setName(strTabName);
						SecondaryNavResource.setAccessLevels(roleSecNavPlge.getAccessLevel());
						SecondaryNavResource.setUrl(roleSecNavPlge.getSecNavigationURL());
						SecondaryNavResource.setImages(roleSecNavPlge.getImages());
						SecondaryNavResource.setLinkFlag(roleSecNavPlge.getNewFlag());
						secnavResorceLst.add(SecondaryNavResource);
					}
				}
			}
			
			menuListResourceVO.setSecNavigationLinks(secnavResorceLst);
		
	}

	/**
	 * @throws RMDWebException
	 *             This Method is used for calling Web Service and get list of
	 *             RolePrivilegesType parameters passed in roleID
	 * 
	 * @param roleID
	 * @return List of RolePrivilegesType
	 * @throws
	 */

	private List<RolePrivilegesType> authorizeSecNav(final UserLoginBean userBean)throws RMDWebException, Exception {
		rmdWebLogger.debug("Entered into authorizeSecNav() method ");
		

		RolePrivilegesType[] rolePrivList = null;
		final List<RolePrivilegesType> rolePrevTypeSec = new ArrayList<RolePrivilegesType>();
		try {
			final Map<String, String> qParamLogin = new LinkedHashMap<String, String>();
			qParamLogin.put(AppConstants.ROLE_ID,
					String.valueOf(userBean.getUserVO().getRoleId()));

			final Map<String, String> headerParams = getHeaderMap(userBean);

			rolePrivList = (RolePrivilegesType[]) rsInvoker
					.get(ServiceConstants.SECURITY_SERVICE_GET_ROLE_SEC_NAV_PRIVILAGES,
							qParamLogin, null, headerParams,
							RolePrivilegesType[].class);
			
			if (rolePrivList != null && rolePrivList.length > 0) {
				for (RolePrivilegesType rPL : rolePrivList) {
					rolePrevTypeSec.add(rPL);
				}
			}
			
		}catch (RMDWebException rmdEx) {
			   // TODO Auto-generated catch block
			rmdWebLogger.error("RMDWebException occured in authorizeSecNav() method ", rmdEx);
			if (!AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(rmdEx.getStatus())) {
				throw rmdEx;
			}
		} catch (Exception exp) {
			rmdWebLogger.error("Exception occured in authorizeSecNav() method ", exp);
			throw exp;
		}
		return rolePrevTypeSec;
	}


	/**
	 * This Method is used for filtering the Menu based on the Privilages for a
	 * User Role parameters passed in List<RolePrivilegesType> rolePrevType,
	 * Map<String, ResourceVO> primaryNavMap, Map<String, List<ResourceVO>>
	 * secondaryNAvMap
	 * 
	 * @param List
	 *            <RolePrivilegesType> rolePrevType, Map<String, ResourceVO>
	 *            primaryNavMap, Map<String, List<ResourceVO>> secondaryNAvMap
	 * @return List of MAP
	 * @throws
	 */
	private MenuListResourceVO getMenuForPrivilages(
			final List<RolePrivilegesType> rolePrevType,
			final Map<String, ResourceVO> primaryNavMap,
			final Map<String, List<ResourceVO>> secondaryNAvMap)
			throws Exception {
		rmdWebLogger.debug("getMenuForPrivilages():Start");
		// 1. authorize Previlages for user
		final MenuListResourceVO menuListResourceVO = new MenuListResourceVO();
		final Map<String, ResourceVO> priNavMapUdtedForARole = new LinkedHashMap<String, ResourceVO>();
		Map<String, List<ResourceVO>> secNavMapUdtedForARole = new LinkedHashMap<String, List<ResourceVO>>();
		try {
			final String subMenuPrefix = AppConstants.SUB_MENU_PREFIX;
			final Map<String, String> subMenuToShow = new  LinkedHashMap<String, String>();
			final Map<String, String> stickySubTabToShow = new  LinkedHashMap<String, String>();
			ResourceVO componentResouce;
			List<ResourceVO> compontResorceLst=new ArrayList<ResourceVO>();
			List<ResourceVO> utilityResorceLst=new ArrayList<ResourceVO>();
			
			for (RolePrivilegesType rolePlge : rolePrevType) {
				final String strTabName = rolePlge.getRolePrivilege();
				final String resourceType=rolePlge.getResourceType();
				final String strAccessLevel = rolePlge.getAccessLevel();
				
				if(resourceType.equalsIgnoreCase(AppConstants.PRIVILEGE_COMPONENT)&& AppConstants.MENU_ACCESS_LEVEL_SHOW
						.equalsIgnoreCase(strAccessLevel)){
					componentResouce=new ResourceVO();
					componentResouce.setName(strTabName);
					componentResouce.setAccessLevels(strAccessLevel);
					componentResouce.setSortOrder(rolePlge.getSortOrder());
					compontResorceLst.add(componentResouce);
				
				}
				if(resourceType.equalsIgnoreCase(AppConstants.PRIVILEGE_UTILITY)&& AppConstants.MENU_ACCESS_LEVEL_SHOW
						.equalsIgnoreCase(strAccessLevel)){
					componentResouce=new ResourceVO();
					componentResouce.setName(strTabName);
					componentResouce.setAccessLevels(strAccessLevel);
					componentResouce.setSortOrder(rolePlge.getSortOrder());
					compontResorceLst.add(componentResouce);
					utilityResorceLst.add(componentResouce);
				}
								

					
				if (AppConstants.PROFILE.equalsIgnoreCase(strTabName)) {
					menuListResourceVO.setProfile(strAccessLevel);

				}
				if (AppConstants.PREFERENCES.equalsIgnoreCase(strTabName)) {
					menuListResourceVO.setPreferences(strAccessLevel);
				}
				if (AppConstants.HEADERSEARCH.equalsIgnoreCase(strTabName)) {
					menuListResourceVO.setHeader(strAccessLevel);
				}
				if (primaryNavMap.get(strTabName) != null
						&& AppConstants.MENU_ACCESS_LEVEL_SHOW
								.equalsIgnoreCase(strAccessLevel) && AppConstants.MENU
								.equalsIgnoreCase(resourceType) ) {
					priNavMapUdtedForARole.put(strTabName,
							primaryNavMap.get(strTabName));
				}
				if ((secondaryNAvMap.get(strTabName) != null && secondaryNAvMap
						.get(strTabName).size() > 0)
						&& AppConstants.MENU_ACCESS_LEVEL_SHOW
								.equalsIgnoreCase(strAccessLevel)) {
					
					secNavMapUdtedForARole.put(strTabName,
							secondaryNAvMap.get(strTabName));
				}
				
							
				if (strTabName.startsWith(subMenuPrefix)
						&& AppConstants.MENU_ACCESS_LEVEL_SHOW
								.equalsIgnoreCase(strAccessLevel)) {
					subMenuToShow.put(strTabName, strAccessLevel);
				}
				
				if (resourceType.equalsIgnoreCase(AppConstants.MENU_STICKY_SUBTAB)
						&& AppConstants.MENU_ACCESS_LEVEL_SHOW
								.equalsIgnoreCase(strAccessLevel)) {
					stickySubTabToShow.put(strTabName, strAccessLevel);
				}
			}
			secNavMapUdtedForARole = getRestrictedSubMenu(
					secNavMapUdtedForARole, subMenuToShow);
			menuListResourceVO.setSticySubNavigationList(prepareStickySubTab(
					primaryNavMap, secondaryNAvMap, compontResorceLst, stickySubTabToShow));
			menuListResourceVO
					.setPriNavMapUdtedForARole(priNavMapUdtedForARole);
			menuListResourceVO
					.setSecNavMapUdtedForARole(secNavMapUdtedForARole);
			menuListResourceVO.setComponentList(compontResorceLst);
			menuListResourceVO.setUtilityList(utilityResorceLst);
		} catch (Exception exp) {
			rmdWebLogger.error("Exception occured in getMenuForPrivilages() method ",
					exp);
			throw exp;
		}
		rmdWebLogger.debug("getMenuForPrivilages():End");
		return menuListResourceVO;
	}

	/**
	 * @throws Exception
	 *             This Method is used for filtering the Submenu based on the
	 *             Privilages and restricted access for a User Role parameters
	 *             passed in Map<String, List<ResourceVO>>
	 *             secNavMapUdtedForARole, Map<String, String> subMenuToHide
	 * 
	 * @param Map
	 *            <String, List<ResourceVO>> secNavMapUdtedForARole, Map<String,
	 *            String> subMenuToHide
	 * @return List of MAP
	 * @throws
	 */
	private Map<String, List<ResourceVO>> getRestrictedSubMenu(
			final Map<String, List<ResourceVO>> secNavMapUdtedForARole,
			final Map<String, String> subMenuToShow) throws Exception {
		rmdWebLogger.debug("getRestrictedSubMenu():Start");
		final Map<String, List<ResourceVO>> restrictedSecNavMap = new LinkedHashMap<String, List<ResourceVO>>();
		try {
			final Set<String> mainMenuKeySet = secNavMapUdtedForARole.keySet();
			for (String mainTabName : mainMenuKeySet) {
				final List<ResourceVO> tempListResVO = secNavMapUdtedForARole
						.get(mainTabName);
				 List<ResourceVO> tempListResVOToUpd = new ArrayList<ResourceVO>();
				
				if (tempListResVO != null && !tempListResVO.isEmpty()) {
					for (int i = 0; i < tempListResVO.size(); i++) {
						final String resourceID = tempListResVO.get(i)
								.getResourceId();
						if (subMenuToShow.containsKey(resourceID)) {
							tempListResVOToUpd.add(tempListResVO.get(i));
						}
					}
				}
				//added sort_order for Permanent Tab Sort Order Implementation
				if(tempListResVOToUpd!=null && tempListResVOToUpd.size()>0)
				{
					tempListResVOToUpd=	reorderTheList(tempListResVOToUpd,subMenuToShow);
				}
				restrictedSecNavMap.put(mainTabName, tempListResVOToUpd);
			}
		
		} catch (Exception exp) {
			rmdWebLogger.error(
					"Exception occured in getRestrictedSubMenu() method ", exp);
			throw exp;
		}
		rmdWebLogger.debug("getRestrictedSubMenu():End");
		return restrictedSecNavMap;
	}

	private List<ResourceVO>  reorderTheList(final List<ResourceVO> tempListResVOToUpd,
			final Map<String, String> subMenuToShow) {
		final List<ResourceVO> tempList=new ArrayList<ResourceVO>();
		for (Map.Entry<String, String> entry : subMenuToShow.entrySet()) {   
			final String tempString=entry.getKey();
		
			for(int i=0;i<tempListResVOToUpd.size();i++)
			{
				if(tempString.equalsIgnoreCase(tempListResVOToUpd.get(i).getResourceId()))
				{
					tempList.add(tempListResVOToUpd.get(i));
				}
			}
		
		}
		return tempList;
	}
	/**
	 *added sort_order for Permanent Tab Sort Order Implementation
	 * @return List<ResourceVO>
	 * @throws
	 */

	private int findIndexofMap(final Map<String, String> subMenuToShow,
			final String resourceID) {
	
		int index=0;
		int i=0;
		for (Map.Entry<String, String> entry : subMenuToShow.entrySet()) {   
			
			if(entry.getKey().equalsIgnoreCase(resourceID) )
			{
				index=i;
				i++;
				break;
			}
			
			
			
		}
		return index;

	}


	/**
	 * @Author:
	 * @param Map
	 *            <String, ResourceVO> primaryNavMap, Map<String,
	 *            List<ResourceVO>> secondaryNAvMap, UserVO userVO
	 * @return image name
	 * @throws Exception
	 * @Description: This method will return List<Map>
	 */
	@Override
	public MenuListResourceVO getMenuListForARole(
			final Map<String, ResourceVO> primaryNavMap,
			final Map<String, List<ResourceVO>> secondaryNAvMap,
			final UserLoginBean userBean) throws RMDWebException, Exception {
		rmdWebLogger.debug("getMenuListForARole():Start");
		MenuListResourceVO menuListResourceVO = null;
		try {
			menuListResourceVO = getPrivileges(primaryNavMap, secondaryNAvMap,
					userBean);
		} catch (AuthorizationException authorEx) {
			rmdWebLogger
					.error("AuthorizationException occured in getMenuListForARole() method ",
							authorEx);
			throw authorEx;
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getMenuListForARole() method ",
					rmdEx);
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(rmdEx
					.getMessage())) {
				throw new AuthorizationException(rmdEx.getCode(),
						rmdEx.getMessage());
			} else {
				throw rmdEx;
			}
		} catch (Exception exp) {
			rmdWebLogger.error(
					"Exception occured in getMenuListForARole() method ", exp);
			throw exp;
		}
		rmdWebLogger.debug("getMenuListForARole():End");
		return menuListResourceVO;
	}

	@Override
	public String getSubPageIndexForHome(final String homePage,
			final Map<String, List<ResourceVO>> secondaryMap) {
		if (secondaryMap != null) {
			final List<ResourceVO> subNapLst = secondaryMap.get(homePage);
			if (subNapLst != null && !subNapLst.isEmpty()) {
				return subNapLst.get(0).getResourceId();
			}
		}
		return null;
	}

	/**
	 * @Author: iGATE Patni
	 * @param subTabSticky
	 * @param stkTabId
	 * @return subTabList
	 * @Description: To add sub tab for sticky tab.
	 */
	private Map<String, List<ResourceVO>> prepareStickySubTab(
			final Map<String, ResourceVO> primaryNavMap,
			final Map<String, List<ResourceVO>> secondaryNAvMap, List<ResourceVO> compontResorceLst, 
			Map<String, String> stickySubTabToShow)
			throws Exception {
		try {
			rmdWebLogger.debug("in prepareStickySubTab():Start");
			final Map<String, List<ResourceVO>> stickytabSubtabList = new LinkedHashMap<String, List<ResourceVO>>();
			final Set<String> mainMenuKeySet = primaryNavMap.keySet();
			List<ResourceVO> lsChildren = null;
			List<ResourceVO> restrictedChildren = null;
			String resourceId = null;
			for (String mainTabName : mainMenuKeySet) {
				final ResourceVO tempResVO = primaryNavMap.get(mainTabName);
				if (tempResVO != null
						&& AppConstants.STICKY_TAB_DESCR.equalsIgnoreCase(tempResVO
								.getDescr())) {
					/*
					 *creating sticky tab sub tabs based on role privilege starts
					 */
					lsChildren = tempResVO.getChildren();
					if(RMDCommonUtility.isCollectionNotEmpty(lsChildren)){
						restrictedChildren = new ArrayList<ResourceVO>();
						
						for (Iterator<ResourceVO> iterator = lsChildren.iterator(); iterator
								.hasNext();) {
							ResourceVO resourceVO = (ResourceVO) iterator
									.next();
							resourceId = resourceVO.getResourceId();
							if(stickySubTabToShow.get(resourceId)!= null
									&& stickySubTabToShow.get(resourceId).equalsIgnoreCase(AppConstants.MENU_ACCESS_LEVEL_SHOW)){
								restrictedChildren.add(resourceVO);
							}
						}
						
						//added sort_order for sticky sub Tab Sort Order Implementation
						if(restrictedChildren!=null && restrictedChildren.size()>0){
							restrictedChildren = reorderTheList(restrictedChildren, stickySubTabToShow);
						}
						
						stickytabSubtabList.put(mainTabName, restrictedChildren);
					}
					/*
					 *creating sticky tab sub tabs based on role privilege ends
					 */
				}
			}
			
			/**
			 *  Role based Header Search.
			 *  This code is for selecting the Sticky tab on role based
			 */
			List<ResourceVO> resultList=stickytabSubtabList.get(AppConstants.RESULTS_STICKYTAB);
			List<ResourceVO> restrictedResultList=new ArrayList<ResourceVO>();
			if(null != resultList && !resultList.isEmpty()){
				for (ResourceVO resourceVO : resultList) {
					for (ResourceVO resCompVO : compontResorceLst) {
						if(resourceVO.getDescr().equals(resCompVO.getName())){
							restrictedResultList.add(resourceVO);
							break;
						}
					}
				}
				stickytabSubtabList.put(AppConstants.RESULTS_STICKYTAB, restrictedResultList);
			}
			
			
			rmdWebLogger.debug("in prepareStickySubTab():End" );
			return stickytabSubtabList;
		} catch (Exception ex) {
			rmdWebLogger.error("Exception:ERORR:prepareStickySubTab", ex);
			throw ex;
		}
	}

	@Override
	public String getLookUpValueForName(String lookupName)
			throws RMDWebException, Exception {
		rmdWebLogger.debug("getLookUpValueForName():Start");
		String lookupValue=AppConstants.EMPTY_STRING;
		List<String> lookUpPrivileges=new ArrayList<String>();
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		try {
		
			queryParamMap.put(AppConstants.LIST_NAME, lookupName);
			
			//rmdWebLogger.debug(">>>>>>>  " + lookupName);
	
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService.getAllLookupValues().get(lookupName);
			if(null != applParamResponseTypeList){
				for (int i = 0; i < applParamResponseTypeList.size(); i++) {
					lookUpPrivileges.add(applParamResponseTypeList.get(i).getLookupValue());
				}
			}
			/*ApplicationParametersResponseType[] applParamResponseType=getLookupValue(queryParamMap);
			for (int i = 0; i < applParamResponseType.length; i++) {
				lookUpPrivileges.add(applParamResponseType[i].getLookupValue());
			}*/
			
			lookupValue=RMDCommonUtility.isCollectionNotEmpty(lookUpPrivileges)?
					lookUpPrivileges.get(0):AppConstants.EMPTY_STRING;
					
			return lookupValue;
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getLookUpValueForName method ", ex);
			RMDWebErrorHandler.handleException(ex);		
		}
		rmdWebLogger.debug("getLookUpValueForName():End");
		return lookupValue;
	}
	
	/**
	 * @Author: iGATE Patni
	 * @param lookupName
	 * @return List<ResourceVO>
	 * @Description: This method is used to populate lookup details for the
	 *               particular list name
	 * 
	 */

	public List<ResourceVO> getLegendsForMap(String lookupName)
			throws RMDWebException, Exception {
		rmdWebLogger.debug("getLookUpValueForLegends():Start");
		List<ResourceVO> arlResourceVO = new ArrayList<ResourceVO>();
		ResourceVO objResourceVO = null;
		//final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		try {
			
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService.getAllLookupValues().get(lookupName);			

			//queryParamMap.put(AppConstants.LIST_NAME, lookupName);
			
			//ApplicationParametersResponseType[] applParamResponseType = (ApplicationParametersResponseType[]) rsInvoker
			//.get(ServiceConstants.GET_LEGENDS_FOR_MAP,
				//	null, queryParamMap, null,
				//	ApplicationParametersResponseType[].class);

			
			for (ApplicationParametersResponseType applicationParametersResponseType : applParamResponseTypeList) {
				objResourceVO = new ResourceVO();
				// populating the lookup value and listDescription as image and
				// description respectively in ResourceVO
				objResourceVO.setImages(applicationParametersResponseType
						.getLookupValue());
				objResourceVO.setDescr(applicationParametersResponseType
						.getListDescription());
				arlResourceVO.add(objResourceVO);
			}

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getLookUpValueForLegends method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger.debug("getLookUpValueForLegends():End");
		return arlResourceVO;
	}
	
	/**
	 * @Author: iGATE Patni
	 * @param lookupName
	 * @return List<ResourceVO>
	 * @Description: This method is used to populate lookup details for the
	 *               particular list name
	 * 
	 */

	public List<ResourceVO> getKPIsForRole(String lookupName)
			throws RMDWebException, Exception {
		rmdWebLogger.debug("getKPIsForRole():Start");
		List<ResourceVO> arlResourceVO = new ArrayList<ResourceVO>();
		ResourceVO objResourceVO = null;
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		try {

			queryParamMap.put(AppConstants.LIST_NAME, lookupName);
			
			ApplicationParametersResponseType[] applParamResponseType = (ApplicationParametersResponseType[]) rsInvoker
			.get(ServiceConstants.GET_LEGENDS_FOR_MAP,
					null, queryParamMap, null,
					ApplicationParametersResponseType[].class);

			
			for (ApplicationParametersResponseType applicationParametersResponseType : applParamResponseType) {
				objResourceVO = new ResourceVO();
				// populating the lookup value and listDescription as resourceid and
				// description respectively in ResourceVO
				objResourceVO.setDescr(applicationParametersResponseType
						.getListDescription());
				objResourceVO.setResourceId(applicationParametersResponseType
						.getLookupValue());
				arlResourceVO.add(objResourceVO);
			}

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getKPIsForRole method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger.debug("getKPIsForRole():End");
		return arlResourceVO;
	}
	/**
	 * @Author: 
	 * @param authorizedPriMapForARole
	 * @param authorizedSecMapForRole
	 * @param stickyTabSubTabMap
	 * @param utilityList
	 * @return Map<String, List<String>>
	 * @Description: This method is used to collect utilities of
	 *               all Tab's resource id in a map.
	 * 
	 */

	@Override
	public Map<String, List<String>> collectUtilities(
			Map<String, ResourceVO> authorizedPriMapForARole,
			Map<String, List<ResourceVO>> authorizedSecMapForRole,
			Map<String, List<ResourceVO>> stickyTabSubTabMap,
			List<ResourceVO> utilityList) throws RMDWebException, Exception {
		Map<String, List<String>> utilityMap=new HashMap<String, List<String>>();
		rmdWebLogger.debug("collectUtilities():Starts");
		try {
			ResourceVO resourceItem = null;
			// Handling primaryTab Utilities
			int utilityCount = 0;
			String regex = "", utilityString = "";
			for (Map.Entry<String, ResourceVO> priNavEntry : authorizedPriMapForARole
					.entrySet()) {
				utilityCount = 0;
				resourceItem = priNavEntry.getValue();
				if (!resourceItem.getUrl().startsWith("#")) {
					List<String> utilityItems = new ArrayList<String>();
					regex = priNavEntry.getKey() + AppConstants.UTILITY;
					for (ResourceVO utilityResource : utilityList) {
						if (utilityResource.getName().startsWith(
								priNavEntry.getKey())) {
							utilityString = utilityResource.getName()
									.replaceAll(regex, "");
							utilityItems.add(utilityString);
							utilityCount++;
						}
					}
					if (utilityCount > 0) {
						utilityMap.put(priNavEntry.getKey(), utilityItems);
					}
				}
			}
			// Handling subTab Utilities
			utilityCount = 0;
			List<ResourceVO> resourceList = null;
			for (Map.Entry<String, List<ResourceVO>> secNavEntry : authorizedSecMapForRole
					.entrySet()) {
				resourceList = secNavEntry.getValue();
				for (ResourceVO secResource : resourceList) {
					utilityCount = 0;
					List<String> utilityItems = new ArrayList<String>();
					regex = secResource.getResourceId() + AppConstants.UTILITY;
					for (ResourceVO utilityResource : utilityList) {
						if (utilityResource.getName().startsWith(
								secResource.getResourceId())) {
							utilityString = utilityResource.getName()
									.replaceAll(regex, "");
							utilityItems.add(utilityString);
							utilityCount++;
						}
					}
					if (utilityCount > 0) {
						utilityMap.put(secResource.getResourceId(),
								utilityItems);
					}
				}
			}
			// Handling StickyTab Utilities
			List<ResourceVO> stickyResourceList = null;
			resourceList = null;
			utilityCount = 0;
			for (Map.Entry<String, List<ResourceVO>> stickyNavEntry : stickyTabSubTabMap
					.entrySet()) {
				stickyResourceList = stickyNavEntry.getValue();
				for (ResourceVO stickyResource : stickyResourceList) {
					utilityCount = 0;
					List<String> utilityItems = new ArrayList<String>();
					regex = stickyResource.getResourceId()
							+ AppConstants.UTILITY;
					for (ResourceVO utilityResource : utilityList) {
						if (utilityResource.getName().startsWith(
								stickyResource.getResourceId())) {
							utilityString = utilityResource.getName()
									.replaceAll(regex, "");
							utilityItems.add(utilityString);
							utilityCount++;
						}
					}
					if (utilityCount > 0) {
						utilityMap.put(stickyResource.getResourceId(),
								utilityItems);
					}

				}
				// Handling KM Utilities
				if (Arrays.asList(AppConstants.getKmResourceIds()).contains(
						stickyNavEntry.getKey())) {

					utilityCount = 0;
					List<String> utilityItems = new ArrayList<String>();
					regex = stickyNavEntry.getKey() + AppConstants.UTILITY;
					for (ResourceVO utilityResource : utilityList) {
						if (utilityResource.getName().startsWith(
								stickyNavEntry.getKey())) {
							utilityString = utilityResource.getName()
									.replaceAll(regex, "");
							utilityItems.add(utilityString);
							utilityCount++;
						}
					}
					if (utilityCount > 0) {
						utilityMap.put(stickyNavEntry.getKey(), utilityItems);
					}
				}

			}

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in collectUtilities method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger.debug("collectUtilities():End");
		return utilityMap;
	}
	
	@Override
	public void persistException(ErrorVO errorVO) {
		ExceptionRequestType exceptionRequestType = new ExceptionRequestType();
		exceptionRequestType.setBusinessKeys(errorVO.getBusinessKeys());
		exceptionRequestType.setExceptionDesc(errorVO.getExceptionDesc());
		exceptionRequestType.setExceptionType(errorVO.getExceptionType());
		exceptionRequestType.setScreenName(errorVO.getScreenName());
		exceptionRequestType.setTraceLog(errorVO.getTraceLog());
		exceptionRequestType.setUserId(errorVO.getUserId());
		try {
			rsInvoker.post(ServiceConstants.SAVE_EXCEPTION_DETAILS,
					exceptionRequestType, new HashMap<String, String>());
		} catch (RMDWebException e) {
			e.printStackTrace();
		}

	}
	
	@Override
    public long getLookUpObjidForName(String lookupName)
            throws RMDWebException, Exception {
        rmdWebLogger.debug("getLookUpObjidForName():Start");
        try {
    
            List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService.getAllLookupValues().get(lookupName);
            if(null != applParamResponseTypeList){
                for (int i = 0; i < applParamResponseTypeList.size(); i++) {
                    if(RMDCommonConstants.RX_CHANGE_STATUS_PENDING.equalsIgnoreCase(applParamResponseTypeList.get(i).getLookupValue())){
                        return applParamResponseTypeList.get(i).getSysLookupSeqId();
                    }
                }
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getLookUpValueForName method ", ex);
            RMDWebErrorHandler.handleException(ex);     
        }
        rmdWebLogger.debug("getLookUpValueForName():End");
        return 0;
    }

}