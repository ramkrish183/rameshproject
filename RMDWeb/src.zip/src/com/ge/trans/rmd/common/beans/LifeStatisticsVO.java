package com.ge.trans.rmd.common.beans;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.ge.trans.rmd.common.valueobjects.BaseVO;

public class LifeStatisticsVO  extends BaseVO  {
	private LinkedHashMap<String,Map<String,String>> timeStampValueMap;
	private List<String> headerDatesList;
	private int datesListSize;
	private String errorString;
	private Map<String,String> errorMap;
	private Map<String,String> attributeToolTip;
	public int getDatesListSize() {
		return datesListSize;
	}
	public void setDatesListSize(int datesListSize) {
		this.datesListSize = datesListSize;
	}

	public List<String> getHeaderDatesList() {
		return headerDatesList;
	}
	public void setHeaderDatesList(List<String> headerDatesList) {
		this.headerDatesList = headerDatesList;
	}

	public Map<String,String> getErrorMap() {
		return errorMap;
	}
	public void setErrorMap(Map<String,String> errorMap) {
		this.errorMap = errorMap;
	}
	public String getErrorString() {
		return errorString;
	}
	public void setErrorString(String errorString) {
		this.errorString = errorString;
	}

	public LinkedHashMap<String, Map<String, String>> getTimeStampValueMap() {
		return timeStampValueMap;
	}
	public void setTimeStampValueMap(
			LinkedHashMap<String, Map<String, String>> timeStampValueMap) {
		this.timeStampValueMap = timeStampValueMap;
	}
	public Map<String, String> getAttributeToolTip() {
		return attributeToolTip;
	}
	public void setAttributeToolTip(Map<String, String> attributeToolTip) {
		this.attributeToolTip = attributeToolTip;
	}
}
