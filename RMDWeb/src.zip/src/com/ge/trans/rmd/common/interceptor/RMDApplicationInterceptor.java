package com.ge.trans.rmd.common.interceptor;

import static com.ge.trans.rmd.common.util.AppConstants.ATTR_USER_OBJECT;

import java.util.Calendar;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebLogger;

/*******************************************************************************
*
* @Author 		: iGATE Patni
* @Version 	: 1.0
* @Date Created: Dec 02, 2011
* @Date Modified : 
* @Modified By : 
* @Contact 	:
* @Description : This class act as a Interceptor for session handling and redirect to login page if session expires
* @History		:
*
******************************************************************************/
public class RMDApplicationInterceptor extends HandlerInterceptorAdapter {
	@Value("${"+AppConstants.CACHE_TAB_THRESHOLD_LIMIT+"}")  String thresholdLimit;
	@Value("${"+AppConstants.DEFAULT_TIMEZONE_VALUE+"}")  String defaultTimezone;
	@Value("${"+AppConstants.FOOTER_PRIVACY_PATH+"}")  String FOOTER_PRIVACY_PATH;
	@Value("${"+AppConstants.FOOTER_TERMS_PATH+"}")  String FOOTER_TERMS_PATH;
	@Value("${"+AppConstants.PAGE_TO_REFRESH+"}")  String techCases;
	@Value("${"+AppConstants.VERSION_NUMBER+"}")  String versionNumber;
	@Value("${"+AppConstants.MASS_APPLY_RX_ASSET_LIMIT+"}")  Integer massApplyRxLimit;
	@Value("${" +  AppConstants.EDIT_RX_URL + "}")
	String editRxUrl;
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
	.getLogger(getClass());
	
	/**
	 * @Author: 
	 * @param request
	 * @param response
	 * @param handler
	 * @return boolean
	 * @Description: Redirect user to login page if session expires
	 */
	@Override
	public boolean preHandle(final HttpServletRequest request,
			final HttpServletResponse response, final Object handler)
			throws Exception {
		final String loginURI = request.getContextPath()
				+ AppConstants.LEVEL_SEPERATOR + AppConstants.LOGINURI;
		final String logoutURI = request.getContextPath()
				+ AppConstants.LEVEL_SEPERATOR + AppConstants.LOGOUTURI;

		final String requestURI = request.getRequestURI();
		final HttpSession session = request.getSession(false);
		request.setCharacterEncoding(AppConstants.UTF_8);
		//By pass login index page and images/css/scripts for
			request.setAttribute(AppConstants.MAX_STICKYTAB, thresholdLimit);
			request.setAttribute(AppConstants.DEFAULT_TIMEZONE, defaultTimezone);
			request.setAttribute(AppConstants.FOOTER_PRIVACY_PATH, FOOTER_PRIVACY_PATH);
			request.setAttribute(AppConstants.FOOTER_TERMS_PATH, FOOTER_TERMS_PATH);
			request.setAttribute(AppConstants.TECHNICIAN_CASES_VAL, techCases);
			request.setAttribute(AppConstants.VERSION_NUMBER, versionNumber);
			request.setAttribute(AppConstants.MASS_APPLY_RX_LIMIT, massApplyRxLimit);
			request.setAttribute(AppConstants.STR_EDIT_RX_URL,editRxUrl);
		final boolean isNotIndexPage = (!loginURI.equalsIgnoreCase(requestURI)
				&& !(requestURI.indexOf(AppConstants.JS) != -1)
				&& !(requestURI.indexOf(AppConstants.COMPONENTS) != -1)
				&& !(requestURI.indexOf(AppConstants.CSS) != -1) && !(requestURI
				.indexOf(AppConstants.IMG) != -1));
		if (isNotIndexPage
				&& (null == session || (null != session && null == session
						.getAttribute(ATTR_USER_OBJECT)))) {
		
			
			rmdWebLogger.debug("Session Invalidated at" + Calendar.getInstance().getTime());
			if (!logoutURI.equalsIgnoreCase(requestURI)) {
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
						AppConstants.SESSION_TIMEOUT_UNAUTHORIZED);
				return false;
			} else {
				return true;
			}
		}
		
		
		return true;
	}

	/**
	 * @Author: 
	 * @param request
	 * @param response
	 * @param handler
	 * @param modelAndView
	 * @return 
	 * @Description: prevent caching at the proxy server
	 */
	@Override
	public void postHandle(final HttpServletRequest request,
			final HttpServletResponse response, final Object handler,
			final ModelAndView modelAndView) throws Exception {
		response.setHeader(AppConstants.CACHING_CACHE_CONTROL,
				AppConstants.CACHING_NO_STORE); //HTTP 1.1
		response.setHeader(AppConstants.CACHING_PRAGMA,
				AppConstants.CACHING_NO_CACHE); //HTTP 1.0
		response.setDateHeader(AppConstants.CACHING_EXPIRES,
				AppConstants.DEFAULT_INT); //prevent caching at the proxy server
		 response.setCharacterEncoding(AppConstants.UTF_8);
		 response.setContentType(AppConstants.UTF_8);
		 super.postHandle(request, response, handler, modelAndView);
	}

}
