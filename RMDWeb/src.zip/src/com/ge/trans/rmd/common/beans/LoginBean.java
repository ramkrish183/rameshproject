/**
 * ============================================================
 * File : LoginBean.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.beans
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Dec 17, 2011
 * History
 * Modified By : Initial Release
 * Classification : iGATE Patni Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */

package com.ge.trans.rmd.common.beans;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.common.vo.ResourceVO;
import com.ge.trans.rmd.common.vo.UserVO;


/*******************************************************************************
 *
 * @Author 		: 
 * @Version 	: 1.0
 * @Date Created: Dec 17, 2011
 * @Date Modified : 
 * @Modified By : 
 * @Contact 	:
 * @Description : 
 * @History		:
 *
 ******************************************************************************/

public class LoginBean {
	
	private String result; 
	private UserVO userVO;
	private Map<String, ResourceVO> primaryNavDtls; 
	private Map<String, List<ResourceVO>> navigationDetails;
	
	/**
	 * @return the userVO
	 */
	public UserVO getUserVO() {
		return userVO;
	}
	
	/**
	 * @param userVO the userVO to set
	 */
	public void setUserVO(final UserVO userVO) {
		this.userVO = userVO;
	}
	

	/**
	 * @return the navigationDetails
	 */
	public Map<String, List<ResourceVO>> getNavigationDetails() {
		return navigationDetails;
	}
	
	/**
	 * @param navigationDetails the navigationDetails to set
	 */
	public void setNavigationDetails(final Map<String, List<ResourceVO>> navigationDetails) {
		this.navigationDetails = navigationDetails;
	}

	
	/**
	 * @return the result
	 */
	public String getResult() {
		return result;
	}

	
	/**
	 * @param result the result to set
	 */
	public void setResult(final String result) {
		this.result = result;
	}

	
	/**
	 * @return the primaryNavDtls
	 */
	public Map<String, ResourceVO> getPrimaryNavDtls() {
		return primaryNavDtls;
	}

	
	/**
	 * @param primaryNavDtls the primaryNavDtls to set
	 */
	public void setPrimaryNavDtls(final Map<String, ResourceVO> primaryNavDtls) {
		this.primaryNavDtls = primaryNavDtls;
	} 
	
	
}
