package com.ge.trans.rmd.common.beans;

import java.util.ArrayList;
import java.util.List;

public class PrivilegeBean extends RMDBaseBean implements
		Comparable<PrivilegeBean> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String privilegeName;
	private String displayName;
	private String parentId;
	private String privilegeId;
	private String Enabled;
	private String level;
	private String resourceType;
	private String description;
	private String sortOrder;

	public String getSortOrder() {
		return sortOrder;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	public String getPrivilegeId() {
		return privilegeId;
	}

	public void setPrivilegeId(String privilegeId) {
		this.privilegeId = privilegeId;
	}

	public String getResourceType() {
		return resourceType;
	}

	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	public String getEnabled() {
		return Enabled;
	}

	public void setEnabled(String enabled) {
		Enabled = enabled;
	}

	public String getPrivilegeName() {
		return privilegeName;
	}

	public void setPrivilegeName(String privilegeName) {
		this.privilegeName = privilegeName;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public int compareTo(PrivilegeBean o) {
		// TODO Auto-generated method stub
		return Integer.valueOf(this.getSortOrder())
				- Integer.valueOf(o.getSortOrder());
	}

}
