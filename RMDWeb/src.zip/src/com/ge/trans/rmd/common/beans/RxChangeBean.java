package com.ge.trans.rmd.common.beans;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.ge.trans.rmd.cm.valueobjects.RecommDeliverVO;
import com.ge.trans.rmd.cm.valueobjects.RecommDelvDocVO;

public class RxChangeBean extends RMDBaseBean{

    /**
     * 
     */
    private static final long serialVersionUID = 5284336067298829669L;
    private String objId;
    private String requestor;
    private String revisionType;
    private String specificRxTitle;
    private String generalRxTitle;
    private String roadNumber;
    private String caseId;
    private String changesSuggested;
    private String notes;
    private List<String> customerIdList;
    private List<String> modelIdList;
    private File attachedDoc;
    private String fileName;
    private byte[] fileData;
    private String status;
    private long statusObjId;
    private String filePath;
    private String requestOwner;  
    private List<String> typeOfRxChange;
    private List<RecommDelvDocVO> arlRecommDelDocVO;
    private String screenName;
    
    public String getObjId() {
        return objId;
    }
    public void setObjId(String objId) {
        this.objId = objId;
    }
    public String getRequestor() {
        return requestor;
    }
    public void setRequestor(String requestor) {
        this.requestor = requestor;
    }
    public String getRevisionType() {
        return revisionType;
    }
    public void setRevisionType(String revisionType) {
        this.revisionType = revisionType;
    }
    public String getSpecificRxTitle() {
        return specificRxTitle;
    }
    public void setSpecificRxTitle(String specificRxTitle) {
        this.specificRxTitle = specificRxTitle;
    }
    public String getGeneralRxTitle() {
        return generalRxTitle;
    }
    public void setGeneralRxTitle(String generalRxTitle) {
        this.generalRxTitle = generalRxTitle;
    }
    public String getRoadNumber() {
        return roadNumber;
    }
    public void setRoadNumber(String roadNumber) {
        this.roadNumber = roadNumber;
    }
    public String getCaseId() {
        return caseId;
    }
    public void setCaseId(String caseId) {
        this.caseId = caseId;
    }
    public String getChangesSuggested() {
        return changesSuggested;
    }
    public void setChangesSuggested(String changesSuggested) {
        this.changesSuggested = changesSuggested;
    }
    public List<String> getCustomerIdList() {
        return customerIdList;
    }
    public void setCustomerIdList(List<String> customerIdList) {
        this.customerIdList = customerIdList;
    }
    public List<String> getModelIdList() {
        return modelIdList;
    }
    public void setModelIdList(List<String> modelIdList) {
        this.modelIdList = modelIdList;
    }
    public File getAttachedDoc() {
        return attachedDoc;
    }
    public void setAttachedDoc(File attachedDoc) {
        this.attachedDoc = attachedDoc;
    }
    public String getNotes() {
        return notes;
    }
    public void setNotes(String notes) {
        this.notes = notes;
    }
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public byte[] getFileData() {
        return fileData;
    }
    public void setFileData(byte[] fileData) {
        this.fileData = fileData;
    }
    
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    
    public long getStatusObjId() {
        return statusObjId;
    }
    public void setStatusObjId(long statusObjId) {
        this.statusObjId = statusObjId;
    }
    
    /**
	 * @return the filePath
	 */
	public String getFilePath() {
		return filePath;
	}
	/**
	 * @param filePath the filePath to set
	 */
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	
	/**
	 * @return the requestOwner
	 */
	public String getRequestOwner() {
		return requestOwner;
	}
	/**
	 * @param requestOwner the requestOwner to set
	 */
	public void setRequestOwner(String requestOwner) {
		this.requestOwner = requestOwner;
	}
	
	public List<String> getTypeOfRxChange() {
        return typeOfRxChange;
    }
    public void setTypeOfRxChange(List<String> typeOfRxChange) {
        this.typeOfRxChange = typeOfRxChange;
    }
      
	/**
	 * @return the arlRecommDelDocVO
	 */
	public List<RecommDelvDocVO> getArlRecommDelDocVO() {
		return arlRecommDelDocVO;
	}
	/**
	 * @param arlRecommDelDocVO the arlRecommDelDocVO to set
	 */
	public void setArlRecommDelDocVO(List<RecommDelvDocVO> arlRecommDelDocVO) {
		this.arlRecommDelDocVO = arlRecommDelDocVO;
	}
	
	/**
	 * @return the screenName
	 */
	public String getScreenName() {
		return screenName;
	}
	/**
	 * @param screenName the screenName to set
	 */
	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}
	@Override
    public String toString() {
        return "RxChangeBean [objId=" + objId + "\t , requestor=" + requestor + "\t , revisionType=" + revisionType
                + "\t , specificRxTitle=" + specificRxTitle + "\t , generalRxTitle=" + generalRxTitle + "\t , roadNumber="
                + roadNumber + "\t , caseId=" + caseId + "\t , changesSuggested=" + changesSuggested + "\t , notes=" + notes
                + "\t , customerIdList=" + customerIdList + "\t , modelIdList=" + modelIdList + "\t , attachedDoc="
                + attachedDoc + "\t , fileName=" + fileName + "\t , fileData=" + Arrays.toString(fileData) + "\t , status="
                + status + "\t , statusObjId=" + statusObjId + "\t , filePath=" + filePath + "\t , requestOwner=" + requestOwner
                + "\t , typeOfRxChange=" + typeOfRxChange + "]";
    }
}
