package com.ge.trans.rmd.common.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Future;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.AssetCasesService;
import com.ge.trans.rmd.cm.service.CaseTrendService;
import com.ge.trans.rmd.cm.service.UnitShipperService;
import com.ge.trans.rmd.cm.valueobjects.CallLogReportBean;
import com.ge.trans.rmd.cm.valueobjects.CaseConversionBean;
import com.ge.trans.rmd.cm.valueobjects.CaseTrendBean;
import com.ge.trans.rmd.cm.valueobjects.CaseTrendDataVO;
import com.ge.trans.rmd.cm.valueobjects.CaseTrendStatisticsBean;
import com.ge.trans.rmd.cm.valueobjects.InboundTurnoverBean;
import com.ge.trans.rmd.cm.valueobjects.InboundTurnoverReportBean;
import com.ge.trans.rmd.cm.valueobjects.InfancyUnitBean;
import com.ge.trans.rmd.cm.valueobjects.OpenRXBean;
import com.ge.trans.rmd.cm.valueobjects.RunTurnoverResponseBean;
import com.ge.trans.rmd.cm.valueobjects.ShipUnitDataVO;
import com.ge.trans.rmd.cm.valueobjects.TopNoActionBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RunTurnoverService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.GenNotesVO;
import com.ge.trans.rmd.common.vo.TurnoverReportsVo;
import com.ge.trans.rmd.km.service.RxService;
import com.ge.trans.rmd.km.valueobjects.RxVO;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;

@Controller
public class RunTurnoverController extends RMDBaseController {

	@Autowired
	private RunTurnoverService runTurnoverService;
	@Autowired
	private UnitShipperService unitShipperService;
	@Autowired
	private AssetCasesService assetCasesService;
	@Autowired
	private RxService rxService;
	@Autowired
	private CaseTrendService caseTrendService;
	@Autowired
	private CachedService cachedService;
	@Autowired
    ApplicationContext appContext;

	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	@RequestMapping(value = AppConstants.REQ_URI_RUN_TURNOVER, method = RequestMethod.GET)
	public ModelAndView getRunTurnover(final HttpServletRequest request)
			throws Exception {
		String modelAndview = null;
		String minRecordCount =null;
		String minCallCount=null;
		try {
			List<ApplicationParametersResponseType> applParamResponseTypeList = null;
				applParamResponseTypeList = cachedService.getAllLookupValues().get(
						AppConstants.TOP_NO_ACTION_RX_ALLOWED_VALUE);
			
			if (applParamResponseTypeList != null
					&& !applParamResponseTypeList.isEmpty()) {

				for (ApplicationParametersResponseType objResponse : applParamResponseTypeList) {
					if (!(AppConstants.SPECIFY.equalsIgnoreCase(objResponse
							.getLookupValue()))) {
						minRecordCount =  objResponse.getLookupValue();
					}
				}
			}
			minCallCount=runTurnoverService.getMinCallCountOfAsset(AppConstants.CALL_REPORT_MIN_CALL_COUNT_VALUE);
			request.setAttribute("minRecordCount", minRecordCount);
			request.setAttribute("minCallCount", minCallCount);
			modelAndview = AppConstants.RUN_TURNOVER;
		} catch (Exception ex) {
			logger.error("Exception occured in getRunTurnover method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return new ModelAndView(modelAndview);
	}

	@RequestMapping(value = AppConstants.REQ_URI_GET_TURNOVER_REPORT, method = RequestMethod.GET)
	@ResponseBody public  RunTurnoverResponseBean getRunTurnoverReports(
			@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString,
			final HttpServletRequest request) throws RMDWebException {
		final ObjectMapper mapper = new ObjectMapper();
		logger.debug("Inside getRunTurnoverReports method");
		Future<List<InboundTurnoverBean>> futureInbound = null;
		Future<List<ShipUnitDataVO>> futureShipUnit = null;
		Future<List<InfancyUnitBean>> futureInfancyUnit = null;
		Future<List<CaseTrendDataVO>> futureOpenCommRX = null;
		Future<List<RxVO>> futureRepeatedRXList = null;
		Future<CaseConversionBean> futurecaseConversionGraph = null;
		Future<TopNoActionBean> futureTopNoActionRX = null;
		Future<List<OpenRXBean>> futureOpenRXBean = null;
		Future<CaseTrendBean> futureCaseTrendBean = null;
		Future<CaseTrendStatisticsBean> futureCaseTrendStatBean = null;
		Future<CallLogReportBean> futureCallCountByLoc = null;
		Future<CallLogReportBean> futureCustBrkDwnByMins = null;
		Future<CallLogReportBean> futureCallCountByBsnArea = null;
		Future<CallLogReportBean> futureWeeklyCallCountByBsnArea = null;
		Future<CallLogReportBean> futureVehCallCountByBsnArea = null;
		InboundTurnoverReportBean inboundTurnoverReportBean = new InboundTurnoverReportBean();
		RunTurnoverResponseBean runTurnoverResponseBean = new RunTurnoverResponseBean();
		List<GenNotesVO> arlCommNotesVO = null;
		String percentage = null;
		String manualCallCount = null;
		List<GenNotesVO> arlGenNotesVO = null;

		try {
			TurnoverReportsVo tempList = new TurnoverReportsVo();
			tempList = mapper.readValue(
					EsapiUtil.stripXSSCharacters(parameterString),
					TurnoverReportsVo.class);
			try {
				if (tempList.getInbound()!=null && tempList.getInbound() == true) {
					futureInbound = runTurnoverService.getInboundReportData();
					inboundTurnoverReportBean
							.setInboundTurnoverBean(futureInbound.get());
					runTurnoverResponseBean
					.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					
				}
			} catch (Exception ex) {
				logger.error("Exception occured in InboundReport method ", ex);
				inboundTurnoverReportBean
						.setInboundError("INBOUND_REPORT_ERROR");
				runTurnoverResponseBean
				.setInboundTurnoverReportBean(inboundTurnoverReportBean);
			}
			try {
				if (tempList.getNewShippers() != null && tempList.getNewShippers() == true) {
					futureShipUnit = unitShipperService.getShipUnitDetails();
					inboundTurnoverReportBean
							.setShipUnitDataVO(futureShipUnit.get());
					runTurnoverResponseBean
							.setInboundTurnoverReportBean(inboundTurnoverReportBean);
				}
			} catch (Exception ex) {
				logger.error("Exception occured in getShipUnitDetails method ", ex);
				inboundTurnoverReportBean
						.setShipUnitError("SHIPUNIT_REPORT_ERROR");
				runTurnoverResponseBean
				.setInboundTurnoverReportBean(inboundTurnoverReportBean);
			}
			try {
				if (tempList.getInfancyFailure()!=null && tempList.getInfancyFailure() == true) {
					futureInfancyUnit = unitShipperService.getInfancyFailureDetails();
					inboundTurnoverReportBean
							.setInfancyUnitBean(futureInfancyUnit.get());
					runTurnoverResponseBean
							.setInboundTurnoverReportBean(inboundTurnoverReportBean);
				}
			} catch (Exception ex) {
				logger.error("Exception occured in getInfancyFailureDetails method ", ex);
				inboundTurnoverReportBean
						.setInfancyUnitError("INFANCY_UNIT_REPORT_ERROR");
				runTurnoverResponseBean
				.setInboundTurnoverReportBean(inboundTurnoverReportBean);
			}
			try {
				if (tempList.getOpenCommRx()!= null && tempList.getOpenCommRx() == true) {
					try
					{
						futureOpenCommRX = assetCasesService.getOpenCommRXDetails();
						inboundTurnoverReportBean
						.setOpenCommRXBean(futureOpenCommRX.get());
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					catch(Exception ex){
						logger.error("Exception occured in getOpenCommRXDetails method ", ex);
						inboundTurnoverReportBean
								.setOpenCommRXError("OPEN_COMM_RX_REPORT_ERROR");
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					try
					{
					    arlCommNotesVO = assetCasesService.getCommNotesDetails();
						inboundTurnoverReportBean
						.setArlCommNotes(arlCommNotesVO);
						runTurnoverResponseBean
								.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					catch (Exception ex) {
						logger.error("Exception occured in getCommNotesDetails method ", ex);
						inboundTurnoverReportBean
								.setCommNotesError("COMM_NOTES_ERROR");
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					
				}
			} catch (Exception ex) {
				logger.error("Exception occured in getOpenCommRXDetails method ", ex);
				inboundTurnoverReportBean
						.setOpenCommRXError("OPEN_COMM_RX_REPORT_ERROR");
				runTurnoverResponseBean
				.setInboundTurnoverReportBean(inboundTurnoverReportBean);
			}
			try {
				if (tempList.getRepeatersHigher()!= null && tempList.getRepeatersHigher() == true) {
					futureRepeatedRXList = rxService.getRepeaterRxsList();
					inboundTurnoverReportBean
							.setRepeatedRXBean(futureRepeatedRXList.get());
					runTurnoverResponseBean
							.setInboundTurnoverReportBean(inboundTurnoverReportBean);
				}
			} catch (Exception ex) {
				logger.error("Exception occured in getRepeaterRxsList method ", ex);
				inboundTurnoverReportBean
						.setRepeatedRXError("REPEATED_RX_REPORT_ERROR");
				runTurnoverResponseBean
				.setInboundTurnoverReportBean(inboundTurnoverReportBean);
			}
			try {
				if (tempList.getNoActionRx() != null && tempList.getNoActionRx() == true) {
					try
					{
						futurecaseConversionGraph = assetCasesService.getCaseConversionDetails();
						inboundTurnoverReportBean
						.setCaseConversionBean(futurecaseConversionGraph.get());
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					catch(Exception ex){
						logger.error("Exception occured in getCaseConversionDetails method ", ex);
						inboundTurnoverReportBean
								.setCaseConversionError("CASE_CONVERSION_REPORT_ERROR");
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					try
					{
						percentage = assetCasesService.getCaseConversionPercentage();
						inboundTurnoverReportBean.setCaseConvPer(percentage);
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					catch(Exception ex){
						logger.error("Exception occured in getCaseConversionPercentage method ", ex);
						inboundTurnoverReportBean
								.setCasePercentageError("CASE_CONVERSION_PERCENTAGE_ERROR");
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					try
					{
						futureTopNoActionRX = assetCasesService.getTopNoActionRXDetails();
						inboundTurnoverReportBean
						.setTopNoActionBean(futureTopNoActionRX.get());
						runTurnoverResponseBean
								.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					catch(Exception ex){
						logger.error("Exception occured in getTopNoActionRXDetails method ", ex);
						inboundTurnoverReportBean
								.setTopNoActionRXError("TOP_NO_ACTION_RX_REPORT_ERROR");
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					
					
				}
			} catch (Exception ex) {
				logger.error("Exception occured in getCaseConversionDetails method ", ex);
				inboundTurnoverReportBean
						.setCaseConversionError("CASE_CONVERSION_REPORT_ERROR");
				runTurnoverResponseBean
				.setInboundTurnoverReportBean(inboundTurnoverReportBean);
			}
			try {
				if (tempList.getOpenRx() != null && tempList.getOpenRx() == true) {
					try{
						futureOpenRXBean = caseTrendService.getOpenRXCount();
						inboundTurnoverReportBean.setOpenRXBean(futureOpenRXBean.get());
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					catch(Exception ex){
						logger.error("Exception occured in getOpenRXCount method ", ex);
						inboundTurnoverReportBean
								.setOpenRXError("OPEN_RX_REPORT_ERROR");
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					try{
						futureCaseTrendBean = caseTrendService.getCaseTrend();
						inboundTurnoverReportBean.setCaseTrend(futureCaseTrendBean.get());
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					catch(Exception ex){
						logger.error("Exception occured in getCaseTrend method ", ex);
						inboundTurnoverReportBean
								.setCaseTrendError("CASE_TREND_REPORT_ERROR");
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					try{
						futureCaseTrendStatBean = caseTrendService.getCaseTrendStatistics();
						inboundTurnoverReportBean.setCaseTrendStatistics(futureCaseTrendStatBean.get());
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					catch(Exception ex){
						logger.error("Exception occured in getCaseTrendStatistics method ", ex);
						inboundTurnoverReportBean
								.setCaseTrendStatError("CASE_TREND_STAT_REPORT_ERROR");
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					try{
					    arlGenNotesVO = caseTrendService.getGeneralNotesDetails();
						inboundTurnoverReportBean.setArlGenNotes(arlGenNotesVO);
						runTurnoverResponseBean
								.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					catch(Exception ex){
						logger.error("Exception occured in getGeneralNotesDetails method ", ex);
						inboundTurnoverReportBean
								.setGeneralNotesError("GENERAL_NOTES_ERROR");
						runTurnoverResponseBean
						.setInboundTurnoverReportBean(inboundTurnoverReportBean);
					}
					
					
				}
			} catch (Exception ex) {
				logger.error("Exception occured in getCaseConversionDetails method ", ex);
				inboundTurnoverReportBean
						.setCaseTrendError("CASE_TREND_REPORT_ERROR");
				runTurnoverResponseBean
				.setInboundTurnoverReportBean(inboundTurnoverReportBean);
			}
			try {
				if (tempList.getCallReport()!=null && tempList.getCallReport()) {
				    try
                    {
				        futureCallCountByLoc = runTurnoverService.getCallCountByLocation();
                        inboundTurnoverReportBean
                                .setCallCountByLoc(futureCallCountByLoc.get());
                        runTurnoverResponseBean
                                .setInboundTurnoverReportBean(inboundTurnoverReportBean);
                    }
                    catch (Exception ex) {
                        logger.error("Exception occured in getCallCountByLocation method ", ex);
                        inboundTurnoverReportBean
                                .setCallCountByLocErr("CALL_LOG_REPORT_LOCATION_ERROR");
                        runTurnoverResponseBean
                        .setInboundTurnoverReportBean(inboundTurnoverReportBean);
                    }
				    
				    try
                    {
				        futureCustBrkDwnByMins = runTurnoverService.getCustBrkDownByMins();
                        inboundTurnoverReportBean
                                .setCustBrkDwnByMins(futureCustBrkDwnByMins.get());
                        runTurnoverResponseBean
                        .setInboundTurnoverReportBean(inboundTurnoverReportBean);
                    }
                    catch (Exception ex) {
                        logger.error("Exception occured in getCustBrkDownByMins method ", ex);
                        inboundTurnoverReportBean
                                .setCustBrkDwnByMinsError("CALL_LOG_REPORT_CUST_BREAK_DOWN_MIN_ERROR");
                        runTurnoverResponseBean
                        .setInboundTurnoverReportBean(inboundTurnoverReportBean);
                    }
				    			    
				    try
                    {
				        futureCallCountByBsnArea = runTurnoverService.getCallCntByBusnsArea();
                        inboundTurnoverReportBean
                            .setCallCntByBusnsArea(futureCallCountByBsnArea.get());
                        runTurnoverResponseBean
                            .setInboundTurnoverReportBean(inboundTurnoverReportBean);
                    }
                    catch(Exception ex){
                        logger.error("Exception occured in getCallCntByBusnsArea method ", ex);
                        inboundTurnoverReportBean
                                .setCallCntByBusnsAreaError("CALL_COUNT_BY_BUSSINESS_AREA_ERROR");
                        runTurnoverResponseBean
                                .setInboundTurnoverReportBean(inboundTurnoverReportBean);
                    }
				    
				    try
                    {
				        futureWeeklyCallCountByBsnArea = runTurnoverService.getWeeklyCallCntByBusnsArea();
                        inboundTurnoverReportBean
                            .setWeeklyCallCntByBusnsArea(futureWeeklyCallCountByBsnArea.get());
                        runTurnoverResponseBean
                            .setInboundTurnoverReportBean(inboundTurnoverReportBean);
                    }
                    catch(Exception ex){
                        logger.error("Exception occured in getCallCntByBusnsArea method ", ex);
                        inboundTurnoverReportBean
                                .setWeeklyCallCntByBusnsAreaError("WEEKLY_CALL_COUNT_BY_BUSSINESS_AREA_ERROR");
                        runTurnoverResponseBean
                                .setInboundTurnoverReportBean(inboundTurnoverReportBean);
                    }
				    
				    try
                    {
                        futureVehCallCountByBsnArea = runTurnoverService.getVehCallCntByBusnsArea();
                        inboundTurnoverReportBean
                            .setVehCallCntByBusnsArea(futureVehCallCountByBsnArea.get());
                        runTurnoverResponseBean
                            .setInboundTurnoverReportBean(inboundTurnoverReportBean);
                    }
                    catch(Exception ex){
                        logger.error("Exception occured in getVehCallCntByBusnsArea method ", ex);
                        inboundTurnoverReportBean
                                .setVehCallCntByBusnsAreaError("VEH_CALL_COUNT_BY_BUSSINESS_AREA_ERROR");
                        runTurnoverResponseBean
                                .setInboundTurnoverReportBean(inboundTurnoverReportBean);
                    }
				    
				    try
                    {
                        manualCallCount = runTurnoverService.getManualCallCount();
                        inboundTurnoverReportBean
                                .setManualCallCount(manualCallCount);
                        runTurnoverResponseBean
                        .setInboundTurnoverReportBean(inboundTurnoverReportBean);
                    }
                    catch (Exception ex) {
                        logger.error("Exception occured in getManualCallCount method ", ex);
                        inboundTurnoverReportBean
                                .setCustBrkDwnByMinsError("CALL_LOG_REPORT_CUST_BREAK_DOWN_MIN_ERROR");
                        runTurnoverResponseBean
                        .setInboundTurnoverReportBean(inboundTurnoverReportBean);
                    }

				}
			} catch (Exception ex) {
				logger.error("Exception occured in Calllog report method ", ex);
				inboundTurnoverReportBean
						.setInboundError("CALL_LOG_REPORT_ERROR");
				runTurnoverResponseBean
				.setInboundTurnoverReportBean(inboundTurnoverReportBean);
			}
		} catch (Exception ex) {
			logger.error("Exception occured in getRunTurnoverReports method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return runTurnoverResponseBean;
	}
	
    @RequestMapping(value = AppConstants.REQ_URI_EXPORT_REPORT, method = RequestMethod.POST)
    @ResponseBody
    public void exportReports(final HttpServletRequest request,
            final HttpServletResponse response, final Locale locale)
            throws RMDWebException, Exception {
        final ObjectMapper mapper = new ObjectMapper();
        logger.debug("Inside exportReports method");
        Future<List<InboundTurnoverBean>> futureInbound = null;
        Future<List<ShipUnitDataVO>> futureShipUnit = null;
        Future<List<InfancyUnitBean>> futureInfancyUnit = null;
        Future<List<CaseTrendDataVO>> futureOpenCommRX = null;
        Future<List<RxVO>> futureRepeatedRXList = null;
        InboundTurnoverReportBean inboundTurnoverReportBean = new InboundTurnoverReportBean();      
        String csvContent = null;
        ServletOutputStream objServletOutputStream = null;
        BufferedInputStream objBufferedInputStream = null;
        BufferedOutputStream objBufferedOutputStream = null;
        TurnoverReportsVo selReports = null;

        final String parameterString = request
                .getParameter(AppConstants.GET_PARAMETER_STRING);       
            selReports = mapper.readValue(
                    EsapiUtil.stripXSSCharacters(parameterString),
                    TurnoverReportsVo.class);
            try {
                if (selReports.getInbound() != null
                        && selReports.getInbound()) {
                    futureInbound = runTurnoverService.getInboundReportData();
                    inboundTurnoverReportBean
                            .setInboundTurnoverBean(futureInbound.get());
                }
            } catch (Exception ex) {
                logger.error("Failed to load Inbound review data in exportReports method", ex);    
            }
            try {
                if (selReports.getNewShippers() != null
                        && selReports.getNewShippers()) {
                    futureShipUnit = unitShipperService.getShipUnitDetails();
                    inboundTurnoverReportBean.setShipUnitDataVO(futureShipUnit
                            .get());
                }
            } catch (Exception ex) {
                logger.error("Failed to load New shippers data in exportReports method",
                        ex);               
            }
            try {
                if (selReports.getInfancyFailure() != null
                        && selReports.getInfancyFailure()) {
                    futureInfancyUnit = unitShipperService
                            .getInfancyFailureDetails();
                    inboundTurnoverReportBean
                            .setInfancyUnitBean(futureInfancyUnit.get());
                }
            } catch (Exception ex) {
                logger.error(
                        "Failed to load Infancy Failure Units data in exportReports method",
                        ex);               
            }
            try {
                if (selReports.getOpenCommRx() != null
                        && selReports.getOpenCommRx()) {                   
                        futureOpenCommRX = assetCasesService
                                .getOpenCommRXDetails();
                        inboundTurnoverReportBean
                                .setOpenCommRXBean(futureOpenCommRX.get());                   
                }
            } catch (Exception ex) {
                logger.error(
                        "Failed to load Open Comm Rx's by Customer data in exportReports method", ex);              
            }
            try {
                if (selReports.getRepeatersHigher() != null
                        && selReports.getRepeatersHigher()) {
                    futureRepeatedRXList = rxService.getRepeaterRxsList();
                    inboundTurnoverReportBean
                            .setRepeatedRXBean(futureRepeatedRXList.get());
                }
            } catch (Exception ex) {
                logger.error("Exception occured in getRepeaterRxsList method ",
                        ex);                
            }
            try {
            if (null != inboundTurnoverReportBean) {
                csvContent = convertToCSVTemplateReport(
                        inboundTurnoverReportBean, locale);
                response.setContentType(AppConstants.CONTENT_TYPE);
                response.setHeader(AppConstants.CONTENT,
                        AppConstants.ATTACH_FILENAME
                                + AppConstants.TURNOVER_REPORTS_EXPORT_FILENAME);
                objServletOutputStream = response.getOutputStream();
                ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
                        csvContent.getBytes());
                objBufferedInputStream = new BufferedInputStream(
                        objByteArrayInputStream);
                objBufferedOutputStream = new BufferedOutputStream(
                        objServletOutputStream);
                byte[] byteArr = new byte[2048];
                int bytesread;

                while ((bytesread = objBufferedInputStream.read(byteArr, 0,
                        byteArr.length)) != -1) {
                    objBufferedOutputStream.write(byteArr, 0, bytesread);
                    objBufferedOutputStream.flush();
                }
            }
        } catch (Exception ex) {
            logger.error("Exception occured in exportReports method ",
                    ex);
            RMDWebErrorHandler.handleException(ex);
        }

    }

    private String convertToCSVTemplateReport(
            InboundTurnoverReportBean runTurnoverResponseBean, Locale locale) {
        String csvContent = null;
        StringBuilder strBufferAssetHeader = new StringBuilder();
        List<InboundTurnoverBean> arlInboundTurnoverBean = null;
        try {
            if (null != runTurnoverResponseBean.getInboundTurnoverBean()
                    && !runTurnoverResponseBean.getInboundTurnoverBean()
                            .isEmpty()) {
                arlInboundTurnoverBean = runTurnoverResponseBean
                        .getInboundTurnoverBean();
                strBufferAssetHeader.append(AppConstants.QUOTE
                        + AppConstants.EMPTY_SPACE
                        + AppConstants.INBOUND_REVIEW_DETAILS
                        + AppConstants.QUOTE + RMDCommonConstants.NEWLINE
                        + RMDCommonConstants.NEWLINE);

                strBufferAssetHeader.append(appContext.getMessage(
                        AppConstants.INBOUND_REVIEW_DETAILS_HEADER, null,
                        locale));
                strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
                for (InboundTurnoverBean inboundTurnoverBean : arlInboundTurnoverBean) {
                    if (null != inboundTurnoverBean.getCaseId()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + inboundTurnoverBean.getCaseId()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }
                    if (null != inboundTurnoverBean.getRoadNumberHeader()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + inboundTurnoverBean.getRoadNumberHeader()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }
                    if (null != inboundTurnoverBean.getRoadNumber()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + inboundTurnoverBean.getRoadNumber()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }
                    if (null != inboundTurnoverBean.getGpocComments()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + inboundTurnoverBean.getGpocComments()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }

                    strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
                }
            }
            if (null != runTurnoverResponseBean.getRepeatedRXBean()
                    && !runTurnoverResponseBean.getRepeatedRXBean().isEmpty()) {
                List<RxVO> arlRxVO = runTurnoverResponseBean
                        .getRepeatedRXBean();
                strBufferAssetHeader.append(RMDCommonConstants.NEWLINE
                        + RMDCommonConstants.NEWLINE + AppConstants.QUOTE
                        + AppConstants.EMPTY_SPACE
                        + AppConstants.REPEATERS_TABLE + AppConstants.QUOTE
                        + RMDCommonConstants.NEWLINE
                        + RMDCommonConstants.NEWLINE);
                strBufferAssetHeader.append(appContext.getMessage(
                        AppConstants.REPEATERS_TABLE_COLUMNS, null, locale));

                strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);

                for (RxVO rxVO : arlRxVO) {
                    if (null != rxVO.getAssetDetail()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + rxVO.getAssetDetail() + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }
                    if (null != rxVO.getSolutionID()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + rxVO.getSolutionID() + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }
                    if (null != rxVO.getSolutionTitle()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + rxVO.getSolutionTitle() + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }
                    if (null != rxVO.getNotes()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + rxVO.getNotes()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }

                    strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
                }
            }

            if (null != runTurnoverResponseBean.getShipUnitDataVO()
                    && !runTurnoverResponseBean.getShipUnitDataVO().isEmpty()) {
                List<ShipUnitDataVO> arlShipUnitDataVO = runTurnoverResponseBean
                        .getShipUnitDataVO();
                strBufferAssetHeader.append(RMDCommonConstants.NEWLINE
                        + RMDCommonConstants.NEWLINE + AppConstants.QUOTE
                        + AppConstants.EMPTY_SPACE
                        + AppConstants.SHIPPED_UNITS_TABLE + AppConstants.QUOTE
                        + RMDCommonConstants.NEWLINE
                        + RMDCommonConstants.NEWLINE);
                strBufferAssetHeader
                        .append(appContext.getMessage(
                                AppConstants.SHIPPED_UNITS_TABLE_COLUMNS, null,
                                locale));

                strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);

                for (ShipUnitDataVO shipUnitDataVO : arlShipUnitDataVO) {
                    if (null != shipUnitDataVO.getRoadNumberHeader()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + shipUnitDataVO.getRoadNumberHeader()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }
                    if (null != shipUnitDataVO.getRoadNumber()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + shipUnitDataVO.getRoadNumber()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }
                    if (null != shipUnitDataVO.getShipDate()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + shipUnitDataVO.getShipDate()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }

                    strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
                }
            }

            if (null != runTurnoverResponseBean.getInfancyUnitBean()
                    && !runTurnoverResponseBean.getInfancyUnitBean().isEmpty()) {
                List<InfancyUnitBean> arlInfancyUnitBean = runTurnoverResponseBean
                        .getInfancyUnitBean();
                strBufferAssetHeader.append(RMDCommonConstants.NEWLINE
                        + RMDCommonConstants.NEWLINE + AppConstants.QUOTE
                        + AppConstants.EMPTY_SPACE
                        + AppConstants.INFANCY_FAILURE_TABLE
                        + AppConstants.QUOTE + RMDCommonConstants.NEWLINE
                        + RMDCommonConstants.NEWLINE);
                strBufferAssetHeader.append(appContext.getMessage(
                        AppConstants.INFANCY_FAILURE_TABLE_COLUMNS, null,
                        locale));

                strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);

                for (InfancyUnitBean infancyUnitBean : arlInfancyUnitBean) {
                    if (null != infancyUnitBean.getRoadNumberHeader()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + infancyUnitBean.getRoadNumberHeader()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }
                    if (null != infancyUnitBean.getRoadNumber()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + infancyUnitBean.getRoadNumber()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }
                    if (null != infancyUnitBean.getShipDate()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + infancyUnitBean.getShipDate()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }
                    if (null != infancyUnitBean.getCode()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + infancyUnitBean.getCode()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }
                    if (null != infancyUnitBean.getComment()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + infancyUnitBean.getComment()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }

                    strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
                }
            }

            if (null != runTurnoverResponseBean.getOpenCommRXBean()
                    && !runTurnoverResponseBean.getOpenCommRXBean().isEmpty()) {
                List<CaseTrendDataVO> arlCaseTrendDataVO = runTurnoverResponseBean
                        .getOpenCommRXBean();
                strBufferAssetHeader.append(RMDCommonConstants.NEWLINE
                        + RMDCommonConstants.NEWLINE + AppConstants.QUOTE
                        + AppConstants.EMPTY_SPACE + AppConstants.COMM_RX_TABLE
                        + AppConstants.QUOTE + RMDCommonConstants.NEWLINE
                        + RMDCommonConstants.NEWLINE);
                strBufferAssetHeader.append(appContext.getMessage(
                        AppConstants.COMM_RX_TABLE_COLUMNS, null, locale));

                strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);

                for (CaseTrendDataVO caseTrendDataVO : arlCaseTrendDataVO) {
                    if (null != caseTrendDataVO.getCount()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + caseTrendDataVO.getCount()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }
                    if (null != caseTrendDataVO.getCustomer()) {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE
                                + caseTrendDataVO.getCustomer()
                                + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    } else {
                        strBufferAssetHeader.append(AppConstants.QUOTE
                                + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                                + RMDCommonConstants.COMMMA_SEPARATOR);
                    }

                    strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
                }
            }

            csvContent = strBufferAssetHeader.toString();
        } catch (Exception exception) {
            logger.error("Export to CSV Asset Tracker Idle Report" + exception);
        }
        return csvContent;
    }
}
