package com.ge.trans.rmd.common.mvc.validator;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.model.UserProfileModel;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.utilities.RMDMD5;
import com.ge.trans.rmd.common.vo.RolesVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.exception.RMDException;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;

/**
 * *****************************************************************************
 * 
 * @Author :iGATE Patni
 * @Version : 1.0
 * @Date Created: Nov 15, 2011
 * @Date Modified :
 * @Modified By :
 * @Contact :
 * @Description : Validation rules are available for user profile popup
 * @History :
 * 
 ***************************************************************************** 
 */

@Service
public class UserProfileValidator {
	/**
	 * 
	 * @Author:iGATE Patni
	 * @param userVO
	 * @param obj
	 * @param e
	 * @Description: will validate the required fields and match the GE password
	 *               validation rules.
	 */

	public Map<String, String> validate(final UserVO userVO,
		final UserProfileModel objProfile, final ApplicationContext context,
			Locale locale, final HttpServletRequest request, Map<String, String> customers)
			throws RMDException, RMDWebException, Exception {

		final Map<String, String> failures = new HashMap<String, String>();
		final HttpSession session = request.getSession(false);

		boolean roleChangeFlag = false;
		boolean custChangeFlag = false;
		
		if (checkRequiredData(userVO)) {
			failures.put(AppConstants.USERPROFILE_PASSWORDIND, context
					.getMessage(AppConstants.USERPROFILE_ERR7, null, locale));
		}
		// check customer and role is there and password is not entered
		else if (checkCustRolePasswordInfo(userVO, objProfile)) {
			
			if (Long.valueOf(objProfile.getProfileRoles()) != userVO
					.getRoleId()) {
				userVO.setRoleId(Long.valueOf(objProfile.getProfileRoles()));
				roleChangeFlag = true;
			}
			
			if(null != objProfile.getCustomerId() && !objProfile.getCustomerId().equals(userVO.getCustomerId())){
				if (objProfile.getCustomerId().equals(RMDCommonConstants.ALL_CUSTOMER)) {
					objProfile.setCustomerId(null);
				}
				if(null == objProfile.getCustomerId() && null == userVO.getCustomerId()){
					custChangeFlag = false;	
				}else{
					userVO.setCustomerId(objProfile.getCustomerId());
					custChangeFlag = true;	
				}
				
				if (null != customers && !customers.isEmpty()
						&& null != objProfile.getCustomerId()) {
					if (customers.containsKey(objProfile.getCustomerId())) {
						userVO.setCustomerName(customers.get(objProfile
								.getCustomerId()));

					}
				} else {
					userVO.setCustomerName(AppConstants.EMPTY_STRING);
				}
			}
			if(roleChangeFlag || custChangeFlag){
				session.setAttribute(AppConstants.ATTR_USER_OBJECT, userVO);
				failures.put(AppConstants.USERPROFILE_ROLECUSTCHNG, AppConstants.SUCCESS);
			}else{
				failures.put(AppConstants.USERPROFILE_NOINPUT,
						context.getMessage(AppConstants.USERPROFILE_NOINPUTERR, null,
								locale));
			}
		} else {// if password fields are having value
			// Required Field Validations
			final List<RolesVO> rolesVOLst = userVO.getRolesVOLst();
			final List roleList = new ArrayList();

			// validating role -- part of validation framework story
			for (RolesVO role : rolesVOLst) {
				roleList.add(String.valueOf(role.getGetUsrRolesSeqId()));
			}
			final String selectedRole = objProfile.getProfileRoles();
			if (!roleList.contains(selectedRole)) {
				failures.put(AppConstants.USERPROFILE_VALIDATEROLE,
						context.getMessage(AppConstants.USERPROFILE_ERR8, null,
								locale));
			}

			if (!failures.isEmpty())
				return failures;

			// checking with oldpassword
			if (!checkOldPwdRule(userVO, objProfile))
				failures.put(AppConstants.USERPROFILE_OLDPASSWORD,
						context.getMessage(AppConstants.USERPROFILE_ERR4, null,
								locale));
			else if (!checkConfNewRule(objProfile))
				failures.put(AppConstants.USERPROFILE_CONFIRMPASSWORD,
						context.getMessage(AppConstants.USERPROFILE_ERR5, null,
								locale));
			else if (checkNewRule(objProfile))
				failures.put(AppConstants.USERPROFILE_CONFIRMPASSWORD,
						context.getMessage(AppConstants.USERPROFILE_ERR6, null,
								locale));
			else {
				// Check for GE Password Compliance

				if (!checkValidNewPassword(objProfile, userVO)) {
					failures.put(AppConstants.USERPROFILE_CONFIRMPASSWORD,
							context.getMessage(AppConstants.USERPROFILE_ERR6,
									null, locale));
				}

			}
			if (failures.isEmpty()) {
				if (Long.valueOf(objProfile.getProfileRoles()) != userVO
						.getRoleId()) {
					userVO.setRoleId(Long.valueOf(objProfile.getProfileRoles()));
					session.setAttribute(AppConstants.USERPROFILE_DEFAULTROLE,
							objProfile.getProfileRole());
				}
				if (objProfile.getCustomerId() != null && !objProfile.getCustomerId().equalsIgnoreCase(userVO.getCustomerId())) {
					userVO.setCustomerId(objProfile.getCustomerId());
					
					if (null != customers && !customers.isEmpty()
							&& null != objProfile.getCustomerId()) {
						if (customers.containsKey(objProfile.getCustomerId())) {
							userVO.setCustomerName(customers.get(objProfile
									.getCustomerId()));

						}
					} else {
						userVO.setCustomerName(AppConstants.EMPTY_STRING);
					}
				}
				session.setAttribute(AppConstants.ATTR_USER_OBJECT, userVO);
				failures.put(AppConstants.USERPROFILE_ROLECUSTPWDCHNG, AppConstants.SUCCESS);
			}
		}
		return failures;

	}

/**
 * Check for GE Password Compliance
 * @param objProfile
 * @param userVO
 * @return
 */
	public boolean checkValidNewPassword(final UserProfileModel objProfile,final UserVO userVO){
		boolean retVal=false;
		
		final String encryptedNewPassword = RMDMD5.encryptMD5(objProfile.getNewPassword());
		if (RMDCommonUtil.containsString(objProfile.getNewPassword(),userVO.getUserId()))
			retVal=false;
		else if (!RMDCommonUtility.isValidPassword(objProfile.getNewPassword())) {
			retVal=false;
		} else if (RMDCommonUtil.equalsString(encryptedNewPassword,
				objProfile.getOldPassword())) {
			retVal=false;
		} 
		else
			retVal=true;
		
		return retVal;
		
	}
	/**
	 * Check given passwords are equals
	 * @param password1
	 * @param password2
	 * @return
	 */
	public boolean isPasswordEqual(final String password1, final String password2){
		return RMDCommonUtil.equalsString(password1,password2);
	}
	
	/**
	 * check that Old password equals with logged in Password
	 * @param userVO
	 * @param objProfile
	 * @return
	 */
	public boolean checkOldPwdRule(final UserVO userVO, final UserProfileModel objProfile)
	{
		boolean retVal=false;
		String pswd = objProfile.getOldPassword();
		String encryptedOldPwrd = RMDMD5.encryptMD5(pswd);
		if(isPasswordEqual(userVO.getPassword(),encryptedOldPwrd))
			retVal=true;
		return retVal;
	}
	
	/**
	 * check that new password equals with confirm Password 
	 * @param objProfile
	 * @return
	 */
	public boolean checkConfNewRule(final UserProfileModel objProfile)
	{
		boolean retVal = false;
		
		if(isPasswordEqual(objProfile.getNewPassword(),
				objProfile.getConfirmPassword()))
		{
			retVal = true;
		}
		return retVal;
		
	}
	/**
	 * Check that new password equals with old password
	 * @param objProfile
	 * @return
	 */
	public boolean checkNewRule(final UserProfileModel objProfile)
	{
		boolean retVal = false;
		
		if(isPasswordEqual(objProfile.getNewPassword(),
				objProfile.getOldPassword()))
		{
			retVal = true;
		}
		return retVal;
		
	}
	/**
	 * Check that required data are there in required object UserVO
	 * @param userVO
	 * @return
	 */
	public boolean checkRequiredData(final UserVO userVO)
	{
		boolean retVal=false;
		if( userVO.getStrUserName() == null
		|| userVO.getStrUserName().equals(AppConstants.EMPTY_STRING)
		|| userVO.getUserId() == null
		|| userVO.getUserId().equals(AppConstants.EMPTY_STRING)
		|| userVO.getUsrUsersSeqId() == null
		|| userVO.getUsrContactSeqId() == null)
			
			retVal=true;
		
		return retVal;
		
		
	}
	
	public boolean checkCustRolePasswordInfo(UserVO userVO,UserProfileModel objProfile){
		if((objProfile.getProfileRoles() != null 
				|| (objProfile.getCustomerId() != null))	
				&& (null == objProfile.getOldPassword() || objProfile.getOldPassword().isEmpty()) && (null == objProfile.getNewPassword() || objProfile.getNewPassword().isEmpty())
				&& (null == objProfile.getConfirmPassword() || objProfile.getConfirmPassword().isEmpty())){
			return true;
		}else{
			return false;
		}
		
	}

}