package com.ge.trans.rmd.common.mvc.model;

import java.io.Serializable;

public class LoginModel implements Serializable{
       
	private static final long serialVersionUID = 1L;
        private String userName;
        
        private String password;

        public void setUserName(final String userName) {
                this.userName = userName;
        }
        public String getUserName() {
                return userName;
        }
        public void setPassword(final String password) {
                this.password = password;
        }
        public String getPassword() {
                return password;
        }
}
