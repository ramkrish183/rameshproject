package com.ge.trans.rmd.common.beans;

import java.util.List;

import com.ge.trans.rmd.cm.valueobjects.SolutionDetailVO;



public class CaseBean extends RMDBaseBean{
private String assetNumber;
private String caseStatus;
private String caseId;
private String caseTitle;
private String urgency;
private String owner;
private String priority;
private String queueName;
private String createdDate;
private String closedDate;
private String age;
private String timeZone;
private String customerId;
private String assetGrpName;
private String reason;
private String queuename;
private String caseType;
private int rowVersion;
private String customerName;
private SolutionDetailVO solutionInfo;
private String currentSolutionStatus;
private String currentSolutionDelvId;
private String ownerName;
private String noOfDays;
private String append;
private String condition;
private Long caseObjid;
private String roadNumber;
private String model;
private String caseNumber;
private String casePriority;
private String recPendingAlert;
private String heading;
private String onBoardRNH;
private String fleet;
private String pendingFaults;
private String services;
private String customerRNH;
private String appendedDate;
private String nextScheduledRun;
private String badActor;
private String title;
private String rxType;
private String repairTime;
private String deliveryDate;
private String revisionNo;
private Long messageId;
private String reIssue;
private Long rxObjId;
private String creationDate;
private String strCaseObjId;

private String gpsHeading;
private String gpsLatitude;
private String gpslongitude;
private String vehicleObjId;
private boolean requestFromToolOutput;
//Added for append
private String appendToCaseId;
private String ruleDefId;
private String toolId;
private String closeOption;
private String rxId;
private String rxDelivery;
private int skipCount;
//Added for merge
private Long mergedTo;
//Added for unit config
private String locoId;
private String toolObjId;

private String appendFlag;
private String controllerConfig;

public String getControllerConfig() {
	return controllerConfig;
}
public void setControllerConfig(String controllerConfig) {
	this.controllerConfig = controllerConfig;
}
public String getAppendFlag() {
	return appendFlag;
}
public void setAppendFlag(String appendFlag) {
	this.appendFlag = appendFlag;
}
public String getLocoId() {
	return locoId;
}
public void setLocoId(String locoId) {
	this.locoId = locoId;
}
public int getSkipCount() {
	return skipCount;
}
public void setSkipCount(int skipCount) {
	this.skipCount = skipCount;
}
public String getRxDelivery() {
	return rxDelivery;
}
public void setRxDelivery(String rxDelivery) {
	this.rxDelivery = rxDelivery;
}
public String getRxId() {
	return rxId;
}
public void setRxId(String rxId) {
	this.rxId = rxId;
}
public String getCloseOption() {
	return closeOption;
}
public void setCloseOption(String closeOption) {
	this.closeOption = closeOption;
}
public String getRuleDefId() {
	return ruleDefId;
}
public void setRuleDefId(String ruleDefId) {
	this.ruleDefId = ruleDefId;
}
private SolutionDetailVO[] arlSolutionInfo;



public SolutionDetailVO[] getArlSolutionInfo() {
	return arlSolutionInfo;
}
public void setArlSolutionInfo(SolutionDetailVO[] arlSolutionInfo) {
	this.arlSolutionInfo = arlSolutionInfo;
}
public String getStrCaseObjId() {
	return strCaseObjId;
}
public void setStrCaseObjId(String strCaseObjId) {
	this.strCaseObjId = strCaseObjId;
}

public String getGpsHeading() {
	return gpsHeading;
}
public void setGpsHeading(String gpsHeading) {
	this.gpsHeading = gpsHeading;
}
public String getGpsLatitude() {
	return gpsLatitude;
}
public void setGpsLatitude(String gpsLatitude) {
	this.gpsLatitude = gpsLatitude;
}
public String getGpslongitude() {
	return gpslongitude;
}
public void setGpslongitude(String gpslongitude) {
	this.gpslongitude = gpslongitude;
}
public String getVehicleObjId() {
	return vehicleObjId;
}
public void setVehicleObjId(String vehicleObjId) {
	this.vehicleObjId = vehicleObjId;
}


public String getCreationDate() {
	return creationDate;
}
public void setCreationDate(String creationDate) {
	this.creationDate = creationDate;
}


public Long getRxObjId() {
	return rxObjId;
}
public void setRxObjId(Long rxObjId) {
	this.rxObjId = rxObjId;
}
public String getRoadNumber() {
	return roadNumber;
}
public void setRoadNumber(String roadNumber) {
	this.roadNumber = roadNumber;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}
public String getCaseNumber() {
	return caseNumber;
}
public void setCaseNumber(String caseNumber) {
	this.caseNumber = caseNumber;
}
public String getCasePriority() {
	return casePriority;
}
public void setCasePriority(String casePriority) {
	this.casePriority = casePriority;
}
public String getRecPendingAlert() {
	return recPendingAlert;
}
public void setRecPendingAlert(String recPendingAlert) {
	this.recPendingAlert = recPendingAlert;
}
public String getHeading() {
	return heading;
}
public void setHeading(String heading) {
	this.heading = heading;
}
public String getOnBoardRNH() {
	return onBoardRNH;
}
public void setOnBoardRNH(String onBoardRNH) {
	this.onBoardRNH = onBoardRNH;
}
public String getFleet() {
	return fleet;
}
public void setFleet(String fleet) {
	this.fleet = fleet;
}
public String getPendingFaults() {
	return pendingFaults;
}
public void setPendingFaults(String pendingFaults) {
	this.pendingFaults = pendingFaults;
}
public String getServices() {
	return services;
}
public void setServices(String services) {
	this.services = services;
}
public String getCustomerRNH() {
	return customerRNH;
}
public void setCustomerRNH(String customerRNH) {
	this.customerRNH = customerRNH;
}
public String getAppendedDate() {
	return appendedDate;
}
public void setAppendedDate(String appendedDate) {
	this.appendedDate = appendedDate;
}
public String getNextScheduledRun() {
	return nextScheduledRun;
}
public void setNextScheduledRun(String nextScheduledRun) {
	this.nextScheduledRun = nextScheduledRun;
}
public String getBadActor() {
	return badActor;
}
public void setBadActor(String badActor) {
	this.badActor = badActor;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
public String getRepairTime() {
	return repairTime;
}
public void setRepairTime(String repairTime) {
	this.repairTime = repairTime;
}
public String getDeliveryDate() {
	return deliveryDate;
}
public void setDeliveryDate(String deliveryDate) {
	this.deliveryDate = deliveryDate;
}
public String getRevisionNo() {
	return revisionNo;
}
public void setRevisionNo(String revisionNo) {
	this.revisionNo = revisionNo;
}
public Long getMessageId() {
	return messageId;
}
public void setMessageId(Long messageId) {
	this.messageId = messageId;
}
public String getReIssue() {
	return reIssue;
}
public void setReIssue(String reIssue) {
	this.reIssue = reIssue;
}

public Long getCaseObjid() {
	return caseObjid;
}
public void setCaseObjid(Long caseObjid) {
	this.caseObjid = caseObjid;
}
public String getCondition() {
	return condition;
}
public void setCondition(String condition) {
	this.condition = condition;
}
public String getAppend() {
	return append;
}
public void setAppend(String append) {
	this.append = append;
}
public String getNoOfDays() {
	return noOfDays;
}
public void setNoOfDays(String noOfDays) {
	this.noOfDays = noOfDays;
}
public SolutionDetailVO getSolutionInfo() {
	return solutionInfo;
}
public void setSolutionInfo(SolutionDetailVO solutionInfo) {
	this.solutionInfo = solutionInfo;
}
public int getRowVersion() {
	return rowVersion;
}
public void setRowVersion(final int rowVersion) {
	this.rowVersion = rowVersion;
}

public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
/**
 * 
 * @return the queuename
 */
public String getQueuename() {
	return queuename;
}
/**
 * 
 * @param queuename the queuename to set
 */

public void setQueuename(final String queuename) {
	this.queuename = queuename;
}
/**
 * 
 * @return the caseType
 */
public String getCaseType() {
	return caseType;
}
/**
 * 
 * @param caseType the caseType to set
 */
public void setCaseType(final String caseType) {
	this.caseType = caseType;
}
/**
 * 
 * @return the reason
 */

public String getReason() {
	return reason;
}
/**
 * 
 * @param reason the reason to set
 */
public void setReason(final String reason) {
	this.reason = reason;
}
/**
 * 
 * @return the caseId
 */
public String getCaseId() {
	return caseId;
}
/**
 * 
 * @param caseId the caseId to set
 */
public void setCaseId(final String caseId) {
	this.caseId = caseId;
}
/**
 * 
 * @return the caseTitle
 */
public String getCaseTitle() {
	return caseTitle;
}
/**
 * 
 * @param caseTitle the caseTitle to set
 */
public void setCaseTitle(final String caseTitle) {
	this.caseTitle = caseTitle;
}
/**
 * 
 * @return the urgency
 */
public String getUrgency() {
	return urgency;
}
/**
 * 
 * @param urgency the urgency to set
 */
public void setUrgency(final String urgency) {
	this.urgency = urgency;
}
/**
 * 
 * @return the assetNumber
 */
public String getAssetNumber() {
	return assetNumber;
}
/**
 * 
 * @param assetNumber the assetNumber to set
 */
public void setAssetNumber(final String assetNumber) {
	this.assetNumber = assetNumber;
}
/**
 * 
 * @return the caseStatus
 */
public String getCaseStatus() {
	return caseStatus;
}
/**
 * 
 * @param caseStatus the caseStatus to set
 */
public void setCaseStatus(final String caseStatus) {
	this.caseStatus = caseStatus;
}

public String getOwner() {
	return owner;
}
public void setOwner(final String owner) {
	this.owner = owner;
}
public String getPriority() {
	return priority;
}
public void setPriority(final String priority) {
	this.priority = priority;
}

public String getQueueName() {
	return queueName;
}
public void setQueueName(final String queueName) {
	this.queueName = queueName;
}
public String getCreatedDate() {
	return createdDate;
}
public void setCreatedDate(final String createdDate) {
	this.createdDate = createdDate;
}
public String getClosedDate() {
	return closedDate;
}
public void setClosedDate(final String closedDate) {
	this.closedDate = closedDate;
}

public String getAge() {
	return age;
}
public void setAge(final String age) {
	this.age = age;
}

public String getTimeZone() {
	return timeZone;
}
public void setTimeZone(final String timeZone) {
	this.timeZone = timeZone;
}


public String getCustomerId() {
	return customerId;
}

public void setCustomerId(final String customerId) {
	this.customerId = customerId;
}

public String getAssetGrpName() {
	return assetGrpName;
}

public void setAssetGrpName(final String assetGrpName) {
	this.assetGrpName = assetGrpName;
}
/**
 * return the values of class fields
 */
@Override public String toString(){
	
	return "CaseId:"+caseId+", CaseStatus:"+caseStatus+", CaseTitle:"+caseTitle+", Urgency"+urgency;
}
public String getCurrentSolutionStatus() {
	return currentSolutionStatus;
}
public void setCurrentSolutionStatus(String currentSolutionStatus) {
	this.currentSolutionStatus = currentSolutionStatus;
}
public String getAppendToCaseId() {
	return appendToCaseId;
}
public void setAppendToCaseId(String appendToCaseId) {
	this.appendToCaseId = appendToCaseId;
}
public String getCurrentSolutionDelvId() {
	return currentSolutionDelvId;
}
public void setCurrentSolutionDelvId(String currentSolutionDelvId) {
	this.currentSolutionDelvId = currentSolutionDelvId;
}
public String getOwnerName() {
	return ownerName;
}
public void setOwnerName(String ownerName) {
	this.ownerName = ownerName;
}
public void setToolId(String toolId) {
	this.toolId = toolId;
	
}
public String getToolId() {
	return toolId;
	
}

public boolean getRequestfromToolOutput() {
	return requestFromToolOutput;
}
public void setRequestfromToolOutput(boolean requestFromToolOutput) {
	this.requestFromToolOutput = requestFromToolOutput;
}
/**
 * @return the toolObjId
 */
public String getToolObjId() {
	return toolObjId;
}
/**
 * @param toolObjId the toolObjId to set
 */
public void setToolObjId(String toolObjId) {
	this.toolObjId = toolObjId;
}
public Long getMergedTo() {
	return mergedTo;
}
public void setMergedTo(Long mergedTo) {
	this.mergedTo = mergedTo;
}
public String getRxType() {
	return rxType;
}
public void setRxType(String rxType) {
	this.rxType = rxType;
}


}
