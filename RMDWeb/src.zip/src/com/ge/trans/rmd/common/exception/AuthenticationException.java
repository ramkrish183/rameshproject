package com.ge.trans.rmd.common.exception;

public class AuthenticationException extends RMDWebException {

	private int code;
 	private String message;
 	private String errorMessageOnUI;
	public String getErrorMessageOnUI() {
		return errorMessageOnUI;
	}

	public void setErrorMessageOnUI(final String errorMessageOnUI) {
		this.errorMessageOnUI = errorMessageOnUI;
	}

	public int getCode() {
		return code;
	}

	public void setCode(final int code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(final String message) {
		this.message = message;
	}

	public AuthenticationException(final int status,final String errorMessage) {
		super(status,errorMessage);
		this.code=status;
		this.message=errorMessage;
		// TODO Auto-generated constructor stub
	}

	/**
	 * 
	 */
	
	private static final long serialVersionUID = 1L;
	
	public AuthenticationException()
	{
		super();
	}

}
