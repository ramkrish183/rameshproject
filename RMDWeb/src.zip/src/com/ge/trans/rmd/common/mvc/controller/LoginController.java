/**
 * ============================================================
 * File : LoginController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.mvc.controller
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Nov 17, 2011
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.mvc.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedSet;
import java.util.StringTokenizer;
import java.util.TimeZone;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.ge.trans.rmd.cm.service.NewsService;
import com.ge.trans.rmd.common.beans.CustomerAssetBean;
import com.ge.trans.rmd.common.beans.FavoriteFilterBean;
import com.ge.trans.rmd.common.beans.UserLoginBean;
import com.ge.trans.rmd.common.beans.UserPreferenceBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.AuthenticationException;
import com.ge.trans.rmd.common.exception.AuthorizationException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.model.LoginModel;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.FavoriteFilterService;
import com.ge.trans.rmd.common.service.LoginService;
import com.ge.trans.rmd.common.service.UserManagementService;
import com.ge.trans.rmd.common.service.UserPreferenceService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.MenuListResourceVO;
import com.ge.trans.rmd.common.vo.ResourceVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.km.util.KMConstants;
import com.ge.trans.rmd.utilities.RMDCommonUtility;


/*******************************************************************************
 * 
 * @Author : iGATE Patni
 * @Version : 1.0
 * @Date Created: Nov 17, 2011
 * @Date Modified :
 * @Modified By :
 * @Contact :
 * @Description : This class act as a controller to authenticate the user and
 *              store the authenticated user info like first name,last
 *              name,email, roles that are mapped to the user and user
 *              preferences into the session.
 * @History :
 * 
 ******************************************************************************/
@Controller
public class LoginController extends RMDBaseController {

	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	private LoginService loginService;
	@Autowired
	private AuthorizationService authorizationService;
	@Autowired
	private UserPreferenceService userPreferenceService;
	@Autowired
	private UserManagementService userManagementService;

	@Autowired
	private AuthorizationService authService;
	@Autowired
	private ServletContext context;
	
	@Autowired
	private FavoriteFilterService favFilterService;

	@Autowired
	private CachedService cachedService;
	@Autowired
	private NewsService newsService;
	@Value("${" + AppConstants.DASHBOARD_URL + "}")
	String dashboardUrl;
	@Value("${" + AppConstants.SSO_LOGOutPage + "}")
	String ssoLogOutPage;
	@Value("${" + AppConstants.SSO_ENV + "}")
	String SSO_ENV;
	@Value("${" + AppConstants.EDIT_RX_URL + "}")
	String editRxUrl;
	/**
	 * @Author:
	 * @return
	 * @Description: Displays the index page(login page) of the RMD application
	 */
	@RequestMapping(method = RequestMethod.GET, value = AppConstants.REQ_URI_LOGIN)
	public String showloginPage(final HttpServletRequest request) throws RMDWebException, Exception {
		// Clear existing session if any, before loading the landing page of the Application.
		
		final	HttpSession session = request.getSession(false);
		if (session != null) {
			session.invalidate();
		}

		//SPRINT13- SSO Enable - Changes Start
	final	String uid = request.getHeader(AppConstants.SSO_UID); 
	final	String userEmailId = request.getHeader(AppConstants.SM_MAIL);
		//String uid = request.getParameter(AppConstants.SSO_UID);commenting for SSO Testing using dummy JSP
		rmdWebLogger.debug("uid is"+uid);
		String result =  AppConstants.VIEW_INDEX;
		if (uid != null){
			request.setAttribute(AppConstants.USER_MAIL_ID, userEmailId);
		}
		if (uid != null) 
		{
			try {
				// 1. Authenticate the user
				final LoginModel loginModel = new LoginModel();
				loginModel.setUserName(uid);
				
				request.setAttribute(AppConstants.SSO_FLAG, AppConstants.SSO_URL);	
				result = performLogin(loginModel, request);
				
				String extDomain = authService.getLookUpValueForName(AppConstants.EXT_URL);
				String domainURL = request.getServerName();
				
				if (domainURL != null && extDomain != null && domainURL.indexOf(extDomain) > -1) {
					request.getSession().setAttribute("URL_TYPE", "EXTERNAL");
				} else {
					request.getSession().setAttribute("URL_TYPE", "INTERNAL");
				}				
				String extDomainCheck = authService.getLookUpValueForName(AppConstants.EXT_URL_CHECK);
				if (extDomainCheck != null && extDomainCheck.trim().equals("TRUE")) {
					if (domainURL != null && extDomain != null && domainURL.indexOf(extDomain) > -1) {
						request.getSession().setAttribute("EXT_URL", authService.getLookUpValueForName(AppConstants.EXT_TEXT));						
					}
				}
				String intDomainCheck = authService.getLookUpValueForName(AppConstants.INT_URL_CHECK);
				if (intDomainCheck != null && intDomainCheck.trim().equals("TRUE")) {
					String intDomain = authService.getLookUpValueForName(AppConstants.INT_URL);
					if (domainURL != null && intDomain != null && domainURL.indexOf(intDomain) > -1) {
						request.getSession().setAttribute("EXT_URL", authService.getLookUpValueForName(AppConstants.INT_TEXT));
					}
				}					 
			}
			catch (AuthenticationException authEx) {
				rmdWebLogger
						.error("Exception occured in showloginPage() method "
								, authEx);
				request.setAttribute(AppConstants.ERRORMSG,
						AppConstants.ACCESS_DENIED);
				result = AppConstants.VIEW_ACCESS_DENIED;
			}
			catch (AuthorizationException authorEx) {
				rmdWebLogger
						.error("Exception occured in showloginPage() method "
								, authorEx);
				request.setAttribute(AppConstants.ERRORMSG,
						AppConstants.ACCESS_DENIED_FOR_ROLE);
				if (AppConstants.USER_INACTIVE.equalsIgnoreCase(authorEx
						.getMessage())) {
					request.setAttribute(AppConstants.ERRORMSG,
							AppConstants.USER_INACTIVE);
				}
				if (AppConstants.NO_EOA_USER_VALIDATION.equalsIgnoreCase(authorEx
						.getMessage())) {
					request.setAttribute(AppConstants.ERRORMSG,
							AppConstants.NO_EOA_USER_VALIDATION);
				}
				result = AppConstants.VIEW_ACCESS_DENIED;
			}
			catch (RMDWebException rmdEx) {
				rmdWebLogger
						.error("Exception occured in showloginPage() method "
								, rmdEx);
				request.setAttribute(AppConstants.ERRORMSG,
						AppConstants.UNKNOWN_EXCEPTION);
				throw rmdEx;
			}
			catch (Exception ex) {
				rmdWebLogger
						.error("Exception occured in showloginPage() method "
								, ex);
				request.setAttribute(AppConstants.ERRORMSG,
						AppConstants.UNKNOWN_EXCEPTION);
				throw ex;
			}

			rmdWebLogger.debug("showloginPage():END ");

		}

		return result;

		// SPRINT13- SSO Enable - Changes End

	}

	/**
	 * @Author:
	 * @param loginModel
	 * @param result
	 * @param model
	 * @param request
	 * @return
	 * @throws RMDWebException 
	  * @Description: authenticates the user, in case of successful authentication
	 *               
	 *               1) retrieve the user information like roles,preferences etc
	 *               and set this user information in session.
	 * 
	 *               2) Authorizes the user
	 *               
	 *               3) Redirects the user to the page where the navigation is rendered
	 *                  based on the users default role(and privileges)       
	 * 
	 *  
	*/
	@RequestMapping(method = RequestMethod.POST, value = AppConstants.REQ_URI_LOGIN)
	@SuppressWarnings(AppConstants.UNCHECKED)
	public String login(
			@ModelAttribute(AppConstants.ATTR_LOGIN_MODEL) final LoginModel loginModel,
			final HttpServletRequest request) throws RMDWebException, Exception {
		rmdWebLogger.debug("login():START ");
		String result = null;		
		
		

		// Invalidate existing session if any, before user login
		final HttpSession session = request.getSession(false);
		if (null != session) {
			session.invalidate();
		}
		try {
			String extDomainCheck = authService.getLookUpValueForName(AppConstants.EXT_URL_CHECK);
			if (extDomainCheck != null && extDomainCheck.trim().equals("TRUE")) {
				String extDomain = authService.getLookUpValueForName(AppConstants.EXT_URL);
				String domainURL = request.getServerName();
				if (domainURL != null && extDomain != null && domainURL.indexOf(extDomain) > -1) {
					request.getSession().setAttribute("EXT_URL", authService.getLookUpValueForName(AppConstants.EXT_TEXT));
				}
			}
			String intDomainCheck = authService.getLookUpValueForName(AppConstants.INT_URL_CHECK);
			if (intDomainCheck != null && intDomainCheck.trim().equals("TRUE")) {
				String domainURL = request.getServerName();
				String intDomain = authService.getLookUpValueForName(AppConstants.INT_URL);
				if (domainURL != null && intDomain != null && domainURL.indexOf(intDomain) > -1) {
					request.getSession().setAttribute("EXT_URL", authService.getLookUpValueForName(AppConstants.INT_TEXT));
				}
			}	
			result = performLogin(loginModel, request);
		}		
		catch (AuthenticationException authEx) {
			rmdWebLogger
					.error("Exception occured in login() method "
							, authEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.LOGIN_FAILURE);
			result = AppConstants.VIEW_INDEX;
		}
		catch (AuthorizationException authorEx) {
			rmdWebLogger
					.error("Exception occured in login() method "
							, authorEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.ACCESS_DENIED_FOR_ROLE);
			if (AppConstants.USER_INACTIVE.equalsIgnoreCase(authorEx
					.getMessage())) {
				request.setAttribute(AppConstants.ERRORMSG,
						AppConstants.USER_INACTIVE);
			}
			
			if (AppConstants.NO_EOA_USER_VALIDATION.equalsIgnoreCase(authorEx
					.getMessage())) {
				request.setAttribute(AppConstants.ERRORMSG,
						AppConstants.NO_EOA_USER_VALIDATION);
			}
			result = AppConstants.VIEW_ACCESS_DENIED;
		}
		catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("Exception occured in login() method "
							, rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		}
		catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in login() method "
							, ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		}

		rmdWebLogger.debug("login():END ");
		
		return result;
	}

	/**
	 * @Author: To render the user's common default authentication method   
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description:
	 */

	// SPRINT13- SSO Enable - Changes Start
	private String performLogin(final LoginModel loginModel,
			final HttpServletRequest request) throws RMDWebException,
			Exception, AuthorizationException {
		String result;
		MenuListResourceVO menuListResourceVO;
		HttpSession session;
		String defaultTimezone = null;
		String applicationTimezone = null;
		TimeZone firstTime = null;
		DateFormat zoneFormater = null;
		Date lastLoginTime = null;
		String dateFormat=null;
		String bgstaticURL = "../../RMDWeb/img/app/train.jpg";
		String bgImageURL = null;
		Map<String, String> componentList = new HashMap<String, String>();
		componentList.put(AppConstants.USERPREFERENCE_TIMEZONE,
				AppConstants.PREFERENCE_TIMEZONE_PRIVILEGES);
		componentList.put(AppConstants.PREFERENCE_DROPDOWN_PRIVILEGES,
				AppConstants.PREFERENCE_DROPDOWN_PRIVILEGES_VAR);
		componentList.put(AppConstants.CREATE_CASE_PRIVILEGES,
				AppConstants.CREATE_CASE_SOLN_PRIVILEGE);
		componentList.put(AppConstants.PROFILE_DROPDOWN_PRIVILEGES,
				AppConstants.PROFILE_DROPDOWN_PRIVILEGES_VAR);
		componentList.put(AppConstants.PROFILE_PASSWORD_PRIVILEGES,
				AppConstants.PROFILE_PASSWORD_PRIVILEGES_VAR);
		componentList.put(AppConstants.NOTIFICATION_PRIVILEGES,
				AppConstants.NOTIFICATION_PRIVILEGES_VAR);
		//Added as part of MISC Story -Start
		componentList.put(AppConstants.USERPREFERENCE_LANGUAGE,
				AppConstants.PREFERENCE_LANGUAGE_PRIVILEGES);
		componentList.put(AppConstants.USERPREFERENCE_ROLE,
				AppConstants.PREFERENCE_ROLE_PRIVILEGES);
		componentList.put(AppConstants.USERPREFERENCE_UOM,
				AppConstants.PREFERENCE_UOM);
		//Added as part of MISC Story -End
		//Added as part CM_Previlige Check for Case Screen.
		componentList.put(AppConstants.CASE_MANAGEMENT_PRIVILEGE,AppConstants.IS_CASE_MGMT_PRIVILEGE);		
		//Added as part of Locovision Aurizon project 
		componentList.put(AppConstants.LOCO_VISION_PRIVILEGE,AppConstants.IS_LOCO_VISION_PRIVILEGE);
		componentList.put(AppConstants.TICKER_SECTION_DISPLAY_PRIVILEGE,AppConstants.IS_TICKER_SECTION_DISPLAY);	
		//Added as part of US251801:Rx Update Workflow - Migrate this process within EoA/OMD - Ryan & Todd
		componentList.put(AppConstants.RX_CHANGE_ADMIN_PRIVILEGE,AppConstants.IS_RX_CHANGE_ADMIN_PRIVILEGE);
		//Added as part of Asset Panel feature by Sriram B
		componentList.put(AppConstants.ASSET_PANEL_BUTTON,AppConstants.IS_ASSET_PANEL_PRIVILEGE);
		//Added as part of US248553: Customers: Leverage Mobile App simplification for Health Check on Portal by Raj.S(212687474)
		componentList.put(AppConstants.NOTIFICATION_RDR,AppConstants.IS_NOTIFICATION_RDR);
		Map<String, ResourceVO> authorizedPriMapForARole = new LinkedHashMap<String, ResourceVO>();
		Map<String, List<ResourceVO>> authorizedSecMapForRole = new LinkedHashMap<String, List<ResourceVO>>();
		Map<String, List<ResourceVO>> stickyTabSubTabMap = new LinkedHashMap<String, List<ResourceVO>>();
		Map<String, List<String>> utilityMap=new HashMap<String,List<String>>(); 
		ObjectMapper jsonMapper = new ObjectMapper();
		String jsonUtilityMap = "{}";
		// 1. Authenticate the user

		final UserLoginBean userLoginBean = new UserLoginBean();

		userLoginBean.setUserName(loginModel.getUserName());
		
		loginService.authenticate(userLoginBean);

		result = userLoginBean.getResult();
		rmdWebLogger.debug("Flag is ---> " + result);
		final UserVO userVO = userLoginBean.getUserVO();
		if (AppConstants.LOGIN_SUCCESS.equals(result)) {

			rmdWebLogger.debug(loginModel.getUserName()
					+ " is Authenticated successfully");

			// 2. User is authenticated, Create Fresh Session
			session = request.getSession(true);
			if (request.getAttribute(AppConstants.SSO_FLAG) != null) {
				session.setAttribute(AppConstants.SSO_FLAG,
						AppConstants.SSO_URL);
			}
			// 3. Authorize the user

			// a. Get the Navigation(tab info) detail information from context
			final Map<String, ResourceVO> primaryNavigationDetails = (Map<String, ResourceVO>) context
					.getAttribute(AppConstants.PRI_NAV_MAP);
			final Map<String, List<ResourceVO>> navigationDetails = (Map<String, List<ResourceVO>>) context
					.getAttribute(AppConstants.TAB_DETAIL_MAP);

			// b. authorize the user and retrieve privileges for user's default
			// role
			menuListResourceVO = authorizationService.getMenuListForARole(
					primaryNavigationDetails, navigationDetails, userLoginBean);

			// set value in UserVO
			/* for secondary navigation link */
			if (menuListResourceVO != null) {
				userVO.setSecNavLinks(menuListResourceVO
						.getSecNavigationLinks());
			}
			if (!menuListResourceVO.getComponentList().isEmpty()) {
				userVO.setComponentList(menuListResourceVO.getComponentList());
			}
			if (AppConstants.MENU_ACCESS_LEVEL_SHOW.equals(menuListResourceVO
					.getProfile())) {
				userVO.setProfile(menuListResourceVO.getProfile());
			} else {
				userVO.setProfile(AppConstants.MENU_ACCESS_LEVEL_HIDE);
			}
			if (AppConstants.MENU_ACCESS_LEVEL_SHOW.equals(menuListResourceVO
					.getPreferences())) {
				userVO.setPreferences(menuListResourceVO.getPreferences());
			} else {
				userVO.setPreferences(AppConstants.MENU_ACCESS_LEVEL_HIDE);
			}
			if (AppConstants.MENU_ACCESS_LEVEL_SHOW.equals(menuListResourceVO
					.getHeader())) {
				userVO.setHeader(menuListResourceVO.getHeader());
			} else {
				userVO.setHeader(AppConstants.MENU_ACCESS_LEVEL_HIDE);
			}

			if (userVO.getHeader() == null) {
				userVO.setHeader(AppConstants.MENU_ACCESS_LEVEL_HIDE);
			}
			
			// method call to get the enabled components for logged in user
			getComponentPrivilege(componentList,userVO,request);
			 
			String eoaUserName = userManagementService.getEoaUserName(userVO
					.getUserId());
			if (null != eoaUserName
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(eoaUserName)) {
				userVO.setCmAliasName(eoaUserName);
			}
			userVO.setCMPrivilege((Boolean) request
					.getAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE));
			userVO.setAssetPanelPrivilege((Boolean) request
					.getAttribute(AppConstants.IS_ASSET_PANEL_PRIVILEGE));
			
			//Added as part of US248553: Customers: Leverage Mobile App simplification for Health Check on Portal
			//SOC Raj.S(212687474)
			userVO.setNotificationRDR((Boolean) request
					.getAttribute(AppConstants.IS_NOTIFICATION_RDR));
			//EOC
			
			userVO.setLocoVisionPrivilege((Boolean) request
					.getAttribute(AppConstants.IS_LOCO_VISION_PRIVILEGE));
			//Added as part of  US251801:Rx Update Workflow - Migrate this process within EoA/OMD - Ryan & Todd
			userVO.setRxChangeAdminPrivilege((Boolean) request
					.getAttribute(AppConstants.IS_RX_CHANGE_ADMIN_PRIVILEGE));
			userVO.setTickerSectionDisplay((Boolean) request
					.getAttribute(AppConstants.IS_TICKER_SECTION_DISPLAY));
			
			if (userVO.getIsCMPrivilege()
					&& null == userVO.getCmAliasName()
					|| RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(userVO
							.getCmAliasName())) {
				throw new AuthorizationException(400,
						AppConstants.NO_EOA_USER_VALIDATION);
			}
			if (null != menuListResourceVO ) {
				authorizedPriMapForARole = menuListResourceVO
						.getPriNavMapUdtedForARole();
				if(authorizedPriMapForARole.containsKey("WELCOME")){
					Map<String, ResourceVO> newMapAuthorizedPriMapForARole = new LinkedHashMap<String, ResourceVO>(authorizedPriMapForARole.size());
					ResourceVO valueIWantToBeFirst= authorizedPriMapForARole.remove("WELCOME");
					newMapAuthorizedPriMapForARole.put("WELCOME", valueIWantToBeFirst);
					newMapAuthorizedPriMapForARole.putAll(authorizedPriMapForARole); 
					authorizedPriMapForARole.clear();
					authorizedPriMapForARole.putAll(newMapAuthorizedPriMapForARole);
				}
				authorizedSecMapForRole = menuListResourceVO
						.getSecNavMapUdtedForARole();
				stickyTabSubTabMap = menuListResourceVO
						.getSticySubNavigationList();
				if(RMDCommonUtility.isCollectionNotEmpty(menuListResourceVO.getUtilityList())){
					utilityMap=authorizationService.collectUtilities(authorizedPriMapForARole,authorizedSecMapForRole,stickyTabSubTabMap,menuListResourceVO.getUtilityList());
					jsonUtilityMap = jsonMapper.writeValueAsString(utilityMap);
				}
				
			}
			if (authorizedPriMapForARole == null
					|| authorizedPriMapForARole.isEmpty()) {
				throw new AuthorizationException(400,
						AppConstants.ACCESS_DENIED_FOR_ROLE);
			}
			final String strPageZeroIndx = authorizedPriMapForARole.keySet()
					.iterator().next();
			final String subPageIdxforHome = authorizationService
					.getSubPageIndexForHome(strPageZeroIndx, navigationDetails);

			// 4. set the values required in session to render on JSPs.
			session.setAttribute(AppConstants.TAB_DETAIL_MAP, navigationDetails);

			// 5. get users default preferences
			final UserPreferenceBean userPreferenceBean = userPreferenceService
					.getDefaultUserPreferences(userVO);

			setUserPreferencesToSession(userPreferenceBean, session);

			final SortedSet<Entry<String, String>> timeZoneMap;

			// 6. Check Timezone data available in the context,if available
			// fetch
			// otherwise hit the web service and get
			/*if (null != context.getAttribute(AppConstants.ATTR_TIMEZONE_MAP)) {
				timeZoneMap = (SortedSet<Entry<String, String>>) context
						.getAttribute(AppConstants.ATTR_TIMEZONE_MAP);
			} else {*/
				timeZoneMap = userPreferenceService.getTimezone(userVO);
				context.setAttribute(AppConstants.ATTR_TIMEZONE_MAP,
						timeZoneMap);
			//}

			final SortedSet<Entry<String, String>> languageMap;

			if (null != context.getAttribute(AppConstants.ATTR_LANGUAGES_MAP)) {
				languageMap = (SortedSet<Entry<String, String>>) context
						.getAttribute(AppConstants.ATTR_LANGUAGES_MAP);
			} else {
				languageMap = getLanguage();
				context.setAttribute(AppConstants.ATTR_LANGUAGES_MAP,
						languageMap);
			}

			context.setAttribute(AppConstants.WS_PARAM_CUSTID,
					userVO.getCustomerId());
			/*
			 * Favorite Filter Service call to fetch all screen's favorite filter criteria.
			 */
			FavoriteFilterBean favoriteFilterBean=new FavoriteFilterBean();
			Long linkUserRoleSeqId=getLinkUsrRoleSeqId(userVO.getRolesVOLst(), userVO.getRoleId());
			favoriteFilterBean.setLinkUserRoleSeqId(linkUserRoleSeqId);
			userVO.setFilterDetail(favFilterService.fetchFavoriteFilter(favoriteFilterBean));
			/*
			 * Favorite Filter Service call to fetch all screen's favorite filter criteria.
			 */
			
			/*
			 * Product WS call for customerAssets
			 */
			CustomerAssetBean custAssetBean=new CustomerAssetBean();
			custAssetBean.setRoleName(RMDCommonUtil.getRoleName(userVO));
			custAssetBean.setLanguage(userVO.getStrLanguage());
			custAssetBean.setUserFirstName(userVO.getStrFirstName());
			custAssetBean.setUserId(userVO.getUserId());
			custAssetBean.setUserLastName(userVO.getStrLastName());
			custAssetBean.setUserLanguage(userVO.getStrUserLanguage());	
			custAssetBean.setCustomerId(userVO.getCustomerId());
			List<String> products =loginService.getProductsForRole(custAssetBean);
			userVO.setProducts(products);
			if(userVO.getLastLoginDateTime()!=null && !userVO.getLastLoginDateTime().equals(AppConstants.EMPTYSTRING))
			{
			defaultTimezone=EsapiUtil.stripXSSCharacters(AppConstants.DEFAULT_TIME_ZONE);
			applicationTimezone=RMDCommonUtil.getTimezone(defaultTimezone,EsapiUtil.stripXSSCharacters(userVO.getTimeZone()));
			firstTime = TimeZone.getTimeZone(applicationTimezone); 
			zoneFormater = new SimpleDateFormat(AppConstants.TO_DATE_FORMAT, Locale.ENGLISH);
			dateFormat = AppConstants.TO_DATE_FORMAT;
			if (cachedService.getSDCustLookup().get(userVO.getCustomerId()) != null
			                && cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat() != null
			                && !cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat().trim().equals(AppConstants.EMPTY_STRING)) {
			zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat());
		dateFormat = AppConstants.DATE_FORMAT_DDMMYYY;
			} 
			zoneFormater.setTimeZone(firstTime);

			DateFormat estZoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_DDMMYYY);
			estZoneFormater.setTimeZone(TimeZone.getTimeZone("US/Eastern")); 
			lastLoginTime = estZoneFormater.parse(userVO.getLastLoginDateTime());
			userVO.setLastLoginDateTimeFormat(dateFormat);
			final String date = zoneFormater.format(lastLoginTime);
			userVO.setLastLoginDateTime(date);
			}
			
			boolean dashboarFlag = loginService.dashboardRoleFlagValue(userVO);
			if(dashboarFlag){
				session.setAttribute(AppConstants.DASHBOARD_BUTTON,RMDCommonConstants.STRING_TRUE);
			}
			else{
				session.setAttribute(AppConstants.DASHBOARD_BUTTON,RMDCommonConstants.STRING_FALSE);
			}
			session.setAttribute(AppConstants.STR_DASHBOARD_URL, dashboardUrl);
			
			session.setAttribute(AppConstants.ATTR_PRI_MAP,
					authorizedPriMapForARole);
			session.setAttribute(AppConstants.ATTR_SEC_MAP,
					authorizedSecMapForRole);
			session.setAttribute(AppConstants.ATTR_HOME_PAGE, strPageZeroIndx);
			session.setAttribute(AppConstants.ATTR_SUB_PAGE, subPageIdxforHome);
			session.setAttribute(AppConstants.ATTR_IMAGE_NAME,
					loginService.getBrandingImageName(userVO));
			session.setAttribute(AppConstants.ATTR_USER_OBJECT, userVO);

			session.setAttribute(AppConstants.STICKYTAB_SUBTAB,
					stickyTabSubTabMap);
			session.setAttribute(AppConstants.UTILITY_MAP,
					jsonUtilityMap);
			
				if(SSO_ENV.equals(AppConstants.STATUS_TRUE)){
				final String SSOURLLogout = AppConstants.HTTPS
				+ AppConstants.FORWARD_SLASH + request.getServerName()
				+ ssoLogOutPage +AppConstants.HTTPS
				+ AppConstants.FORWARD_SLASH +request.getServerName()
				+ request.getContextPath();
				request.setAttribute(AppConstants.LOGOUT_URL, SSOURLLogout);
				
				
			}
			else{
				request.setAttribute(AppConstants.LOGOUT_URL, AppConstants.NORMAL_LOGOUT);
			}
				
			
			/* Begin of Changes for fetching customer Date format */
			if (cachedService.getSDCustLookup().get(userVO.getCustomerId()) != null
					&& cachedService.getSDCustLookup()
							.get(userVO.getCustomerId()).getDateFormat() != null
					&& !cachedService.getSDCustLookup()
							.get(userVO.getCustomerId()).getDateFormat().trim()
							.equals(AppConstants.EMPTY_STRING)) {
				session.setAttribute(
						AppConstants.CUSTOMER_DATE_FORMAT,
						cachedService.getSDCustLookup()
								.get(userVO.getCustomerId()).getDateFormat()
								.replaceAll("HH", "hh"));
			} else {
				session.setAttribute(AppConstants.CUSTOMER_DATE_FORMAT,
						AppConstants.TO_DATE_FORMAT.replaceAll("HH", "hh"));
			}
			/* End of Changes */
			
			if(userVO.getCustomerId()!=null && !(AppConstants.EMPTYSTRING).equals(userVO.getCustomerId()) && !(AppConstants.ALL).equals(userVO.getCustomerId())){
    			bgImageURL = newsService.getBackgroundImage(userVO.getCustomerId());
    		}
    		else
    		{
    			bgImageURL = bgstaticURL;
    		}
			if(!RMDCommonUtility.isNullOrEmpty(bgImageURL)){
	    		request.setAttribute(AppConstants.BACKGROUND_IMAGE_URL, bgImageURL);
	    		}
	    		else
	    		{
	    		request.setAttribute(AppConstants.BACKGROUND_IMAGE_URL, bgstaticURL);
	    		}
			
			result = AppConstants.LOGIN_SUCCESS;

		}
		
		return result;
	}

	// SPRINT13- SSO Enable - Changes End

	/**
	 * @Author: To render the user's default page after authentication   
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description:
	 */
	@RequestMapping(method = RequestMethod.GET, value = AppConstants.REQ_URI_HOME)
	public String showHomePage() throws RMDWebException, Exception {
		return AppConstants.VIEW_HOME;
	}

	/**
	 * @Author: This method will set user preferences to session
	 * @param userPreferenceBean
	 * @param session
	 * @Description:
	 */
	private void setUserPreferencesToSession(
			final UserPreferenceBean userPreferenceBean,
			final HttpSession session) {

		session.setAttribute(AppConstants.ATTR_USER_PREFERENCE_MAP_LIST,
				userPreferenceBean.getUserPrefMap());

		session.setAttribute(AppConstants.ROLE_STRING,
				userPreferenceBean.getRole());
	}

	/**
	 * @Author:
	 * @return
	 * @throws Exception
	 * @Description:
	 */

	@Value("${" + AppConstants.OMD_SUPPORTED_LANGUAGES + "}")
	private String language;

	public SortedSet<Entry<String, String>> getLanguage() throws Exception {
		try {

			final HashMap<String, String> mapLanguage1 = new HashMap<String, String>();
			final StringTokenizer st = new StringTokenizer(language,
					AppConstants.ATTR_COLON);
			while (st.hasMoreTokens()) {
				final String key = st.nextToken();
				final String value = st.nextToken();
				mapLanguage1.put(key, value);
			}
			final SortedSet<Entry<String, String>> mapLanguage = RMDCommonUtil
					.entriesSortedByValues(mapLanguage1);
			return mapLanguage;
		}
		catch (Exception ex) {
			throw ex;
		}
	}
	
	@RequestMapping(method = RequestMethod.GET, value = AppConstants.ERROR_PAGE)
	public String errorPage(
			@RequestParam(KMConstants.CUSTOM_ERROR_MSG) final String msg,
			final HttpSession session, final HttpServletRequest request)
			throws RMDWebException {
		request.setAttribute(AppConstants.ERRORMSG, msg);
		return AppConstants.VIEW_GLOBAL_EXCEPTION_PAGE;

	}

	/**
	 * @Author: 
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description: To render the popout base page
	 */
	@RequestMapping(method = RequestMethod.GET, value = AppConstants.REQ_POPOUT_URL)
	public String showPopoutPage() throws RMDWebException, Exception {
		return AppConstants.VIEW_POPOUT;
	}
	
}
