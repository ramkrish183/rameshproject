package com.ge.trans.rmd.common.util;
import java.util.ResourceBundle;

import com.ge.trans.rmd.logging.RMDLogger;

/**
 * The Class PropertiesUtil.
 */
public class PropertiesUtil {

	public static final RMDLogger LOG = RMDLogger.getLogger(PropertiesUtil.class);
    /** The resource bundle. */
	private static ResourceBundle resourceBundle = ResourceBundle.getBundle(AppConstants.APPL_RESOURCE_PATH);

    /**
     * The Constructor.
     * 
     * @param resourceName the resource name
     */
    public PropertiesUtil() {
        if (resourceBundle == null) {
            resourceBundle = ResourceBundle.getBundle(AppConstants.APPL_RESOURCE_PATH);
        }
    }

    /**
     * Gets the property.
     * 
     * @param key the key
     * 
     * @return the property
     */
    public static String  getProperty(final String key) {
        String property = AppConstants.EMPTY_STRING;
        try {
            property = resourceBundle.getString(key);
        }
        catch (Exception e) {
        	LOG.error("In PropertiesUtil : Exception occured in getProperty method "+e.getMessage());

        }
        return property;
    }

}
