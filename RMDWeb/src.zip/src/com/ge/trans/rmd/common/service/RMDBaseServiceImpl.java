/**
 * 
 */
package com.ge.trans.rmd.common.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.pp.services.assets.valueobjects.PpAssetRequestType;
import com.ge.trans.rmd.cm.valueobjects.LookupSearchServiceVO;
import com.ge.trans.rmd.common.beans.RMDBaseBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.valueobjects.GetSysLookupVO;
import com.ge.trans.rmd.exception.RMDServiceException;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetLocRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.ProdAssetMapRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.CasesRequestType;
import com.ge.trans.rmd.services.kpi.valueobjects.KpiTotalCountRequestType;
/**
 * @author 501872812
 *
 */
@Service
public class RMDBaseServiceImpl {
	
	@Autowired
	private CachedService cachedService;

	protected Map<String, String> getHeaderMap(final RMDBaseBean baseBean) {
		final Map<String, String> headerMap = new HashMap<String, String>();

		if (null != baseBean.getLanguage()) {
			headerMap.put(AppConstants.LANGUAGE, baseBean.getLanguage());
		}
		if (null != baseBean.getUserLanguage()) {
			headerMap.put(AppConstants.USER_LANGUAGE,
					baseBean.getUserLanguage());
		}
		if (null != baseBean.getUserId()) {
			headerMap.put(AppConstants.GENERAL_PARAM_USER_ID,
					baseBean.getUserId());
		}
		if (null != baseBean.getUserFirstName()) {
			headerMap.put(AppConstants.GENERAL_PARAM_USER_FNAME,
					baseBean.getUserFirstName());
		}
		if (null != baseBean.getUserLastName()) {
			headerMap.put(AppConstants.GENERAL_PARAM_USER_LNAME,
					baseBean.getUserLastName());
		}
		if (null != baseBean.getCmAliasName()) {
			headerMap.put(AppConstants.CM_ALIAS_NAME,
					baseBean.getCmAliasName());
		}
		return headerMap;
	}

	protected ApplicationParametersResponseType[] getLookupValue(final Map<String, String> pathParamsPastDays) throws RMDWebException {
		ApplicationParametersResponseType[] applParamResponseType = null;
		Set<String> mapKeys = pathParamsPastDays.keySet();
		if (mapKeys != null && !mapKeys.isEmpty() ) {
			String listNameKey = mapKeys.iterator().next();
			String lookupName = pathParamsPastDays.get(listNameKey);
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService.getAllLookupValues().get(lookupName);
			if (applParamResponseTypeList != null && !applParamResponseTypeList.isEmpty()) {
				applParamResponseType = new ApplicationParametersResponseType[applParamResponseTypeList.size()];
				for (int i = 0; i < applParamResponseTypeList.size(); i++) {
					applParamResponseType[i] = applParamResponseTypeList.get(i);
				}
			}
		}
		return applParamResponseType;
	}
	/*
	 * To copy the product List in to selected request type. 
	 */
	protected void parseProducts(List<String> productList, Object obj)throws RMDWebException {
		
		if(null!=productList&&productList.size()>0){
			ProdAssetMapRequestType prodMapRequestType=null;
			
			for (String products : productList){
				prodMapRequestType=new ProdAssetMapRequestType();
				prodMapRequestType.setProductName(products);
				
				if(obj instanceof AssetsRequestType){
				((AssetsRequestType) obj).getProdAssetMap().add(prodMapRequestType); 
				} 
				if(obj instanceof AssetLocRequestType){
					((AssetLocRequestType) obj).getProdAssetMap().add(prodMapRequestType);
				}
				if(obj instanceof CasesRequestType){
					((CasesRequestType) obj).getProdAssetMap().add(prodMapRequestType);
				}
				
				if(obj instanceof KpiTotalCountRequestType){
					((KpiTotalCountRequestType) obj).getProdAssetMap().add(prodMapRequestType);
				}
				
			}
			}
			
		
		
	}
	
	/*
	 * To copy the Product List in to pinpoint request type. 
	 */
	protected void parsePPProducts(List<String> productsList, Object obj)throws RMDWebException {
		
		if(null!=productsList&&productsList.size()>0){
			com.ge.trans.pp.services.assets.valueobjects.ProdAssetMapRequestType prodMapRequestType=null;
			
			for (String product : productsList) {
				prodMapRequestType=new com.ge.trans.pp.services.assets.valueobjects.ProdAssetMapRequestType();
				prodMapRequestType.setProductName(product);
				
				if(obj instanceof PpAssetRequestType){
				((PpAssetRequestType) obj).getProdAssetMap().add(prodMapRequestType);
				}
			}
				
			
			
		}
		
	}
	
	public List<GetSysLookupVO> getPopupList(
			LookupSearchServiceVO objLookupServiceSearch)
			throws RMDServiceException {
		// TODO Auto-generated method stub
		return null;
	}

	public String updatePopupListValues(List<GetSysLookupVO> list)
			throws RMDServiceException, Exception {
		// TODO Auto-generated method stub
		return null;
	}

	
	
}
