package com.ge.trans.rmd.common.util;

import java.text.DecimalFormat;
import java.util.List;

import com.ge.trans.rmd.pp.beans.MetricsBean;
import com.ge.trans.rmd.pp.valueobjects.MetricsVO;

public final class MetricsConversionUtil {

	static DecimalFormat df = new DecimalFormat("#.00");
	/**
	 * 
	 * @param fromUnitValue
	 *            ,fromUnit,toUnit
	 * @return
	 * @Description:To get converted toUnitValue.
	 */
	public static String getConvertedDistanceVelocity(float fromUnitValue,
			String fromUnit, String toUnit) {
			if(Float.floatToRawIntBits(fromUnitValue) == 0) {
			return "0";
		}
		float toUnitValue = 0;
		if ((fromUnit.equalsIgnoreCase(AppConstants.VIEW_MPH) && toUnit
				.equalsIgnoreCase(AppConstants.VIEW_KPH))
				|| (fromUnit.equalsIgnoreCase(AppConstants.VIEW_MILES) && toUnit
						.equalsIgnoreCase(AppConstants.VIEW_KILOMETERS))) {
			toUnitValue = (float) (fromUnitValue * (1.609344));
		}

		else if ((fromUnit.equalsIgnoreCase(AppConstants.VIEW_KPH) && toUnit
				.equalsIgnoreCase(AppConstants.VIEW_MPH))
				|| (fromUnit.equalsIgnoreCase(AppConstants.VIEW_KILOMETERS) && toUnit
						.equalsIgnoreCase(AppConstants.VIEW_MILES))) {
			toUnitValue = (float) (fromUnitValue * (0.621371));
		}
		String toUnitStr = toUnitValue + AppConstants.EMPTY_STRING;
		if (Float.floatToRawIntBits(toUnitValue) != 0) {

			toUnitStr = df.format(toUnitValue);
			if (toUnitStr.contains(AppConstants.EMPTY_DECIMAL)) {
				toUnitStr = toUnitStr.replace(AppConstants.EMPTY_DECIMAL,
						AppConstants.EMPTY_STRING);
			}
		} else {
			toUnitStr = AppConstants.ZERO;
		}
		return toUnitStr;

	}
	
	public static String getConvertedTemperature(float tempFrom, String fromUnit, String toUnit) {
		if (Float.floatToRawIntBits(tempFrom)  == 0) {
			return "0";
		}
		float tempTo = 0;
		if (fromUnit.equalsIgnoreCase(AppConstants.VIEW_FAHRENHEIT)
				&& (toUnit.equalsIgnoreCase(AppConstants.VIEW_CENTIGRADE) ||toUnit.equalsIgnoreCase(AppConstants.VIEW_CELSIUS)) ) {
			tempTo = (float) ((tempFrom - 32) * 5 / 9);
		}

		if (fromUnit.equalsIgnoreCase(AppConstants.VIEW_CENTIGRADE)
				&& toUnit.equalsIgnoreCase(AppConstants.VIEW_FAHRENHEIT)) {
			tempTo = (float) ((tempFrom * 9 / 5) + 32);
		}
		String formattedTemp = String.valueOf(tempTo);
		if (Float.floatToRawIntBits(tempTo) != 0) {
			formattedTemp = df.format(tempTo);
		} else {
			formattedTemp = AppConstants.ZERO;
		}
		if (formattedTemp.contains(AppConstants.EMPTY_DECIMAL)) {
			formattedTemp = formattedTemp.replace(
					AppConstants.EMPTY_DECIMAL, AppConstants.EMPTY_STRING);
		}
		return formattedTemp;
	}
	
	public static String psigtobarg(float psig) {
		if (Float.floatToRawIntBits(psig) == 0) {
			return "0";
		}
		double Barg = 0;
		Barg = psig * 0.0689476;
		
		if (Double.doubleToRawLongBits(Barg) != 0) {
			return String.valueOf((new Double(Barg)).longValue());
		} else {
			return "";
		}
	}	
	
	public static String psigToBarginFloat(float psig) {
		double Barg = 0;
		Barg = psig * 0.0689476;
		
		if (Double.doubleToRawLongBits(Barg) != 0) {
			return df.format(Barg);
		} else {
			return "";
		}
	}
	
	public static String PSIToMMH2O(float PSI) {
		if (Float.floatToRawIntBits(PSI) == 0) {
			return "0";
		}
		double mmH2O = 0;
		mmH2O = PSI / 0.39370;
		//mmH2O = PSI / 703.06957829636; 

		if (Double.doubleToRawLongBits(mmH2O) != 0) {
			return df.format(mmH2O);
		} else {
			return "";
		}
	}
	
	public static String PSIToKiloPascal(float PSI) {
		if (Float.floatToRawIntBits(PSI) == 0) {
			return "0";
		}
		double kiloPascal = 0;
		kiloPascal = PSI * 6.89475729;

		if (Double.doubleToRawLongBits(kiloPascal) != 0) {
			return String.valueOf((new Double(kiloPascal)).longValue());
		} else {
			return "";
		}
	}
	
	public static String HPToKW(float HP) {
		if (Float.floatToRawIntBits(HP) == 0) {
			return "0";
		}
		double KW = 0;
		KW = HP * 0.745699872;

		if (Double.doubleToRawLongBits(KW) != 0) {
			return String.valueOf((new Double(KW)).longValue());
		} else {
			return "";
		}
	}
	
	public static String lbsToKiloNewtons(float lbs) {
		if (Float.floatToRawIntBits(lbs) == 0) {
			return "0";
		}
		double kiloNewtons = 0;
		kiloNewtons = lbs *  0.0044482216;
		
		if (Double.doubleToRawLongBits(kiloNewtons) != 0) {
			return df.format(kiloNewtons);
		} else {
			return "";
		}
	}	
	public static String PSIToPascal(float PSI) {
		double Pascal = 0;
		Pascal = PSI * 6.89475729;

		if (Double.doubleToRawLongBits(Pascal) != 0) {
			return String.valueOf((new Double(Pascal)).longValue());
		} else {
			return "";
		}
	}
	
	public static String PSIToPascalinFloat(float PSI) {
		double Pascal = 0;
		Pascal = PSI * 6.89475729;

		if (Double.doubleToRawLongBits(Pascal) != 0) {
			return df.format(Pascal);
		} else {
			return "";
		}
	}
	
	
	
	
	public static String HPToKWinFloat(float HP) {
		double KW = 0;
		KW = HP * 0.745699872;
		
		if (Double.doubleToRawLongBits(KW) != 0) {
			return String.valueOf((new Double(KW)).floatValue());
		} else {
			return "";
		}
	}
	
	
	
	public static String lbsToKiloNewtonsinFloat(float lbs) {
		double kiloNewtons = 0;
		kiloNewtons = lbs / 224.808943871;
		
		if (Double.doubleToRawLongBits(kiloNewtons) != 0) {
			return df.format(kiloNewtons);
		} else {
			return "";
		}
	}

	/**
	 * @param fuelLevelFrom
	 * @return
	 * @Description:To get Converted Fuel Level.
	 */
	public static String getConvertedFuelLevel(float fuelLevelFrom,
			String fromUnit, String toUnit) {

		if (Float.floatToRawIntBits(fuelLevelFrom) == 0) {
			return "0";
		}
		float fuelLevelTo = 0;
		if (fromUnit.equalsIgnoreCase(AppConstants.VIEW_GALLONS)
				&& toUnit.equalsIgnoreCase(AppConstants.VIEW_LITRES)) {
			fuelLevelTo = (float) (fuelLevelFrom * 3.78541);
		}

		if (fromUnit.equalsIgnoreCase(AppConstants.VIEW_LITRES)
				&& toUnit.equalsIgnoreCase(AppConstants.VIEW_GALLONS)) {
			fuelLevelTo = (float) (fuelLevelFrom * 0.264172);
		}

		String fuelLevelLitresStr = fuelLevelTo + AppConstants.EMPTY_STRING;
		if (Float.floatToRawIntBits(fuelLevelTo) != 0) {
			fuelLevelLitresStr = df.format(fuelLevelTo);
		} else {
			fuelLevelLitresStr = AppConstants.ZERO;
		}
		if (fuelLevelLitresStr.contains(AppConstants.EMPTY_DECIMAL)) {
			fuelLevelLitresStr = fuelLevelLitresStr.replace(
					AppConstants.EMPTY_DECIMAL, AppConstants.EMPTY_STRING);
		}
		return fuelLevelLitresStr;

	}

	/**
	 * @param customerId
	 * @param columnName
	 * @param screenName
	 * @param metricsData
	 * @return
	 * @Description:To get required metrics Data from Metrics Conversion table.
	 */
	public static MetricsVO getMetricsData(String customerId,
			String screenName, String columnName, List<MetricsBean> metricsData) {
		MetricsVO metricsVO = new MetricsVO();
		outerloop: for (MetricsBean responseType : metricsData) {
			if (responseType.getCustomerName().equalsIgnoreCase(customerId)
					&& responseType.getScreenName()
							.equalsIgnoreCase(screenName)
					&& responseType.getColumnName()
							.equalsIgnoreCase(columnName)) {
				metricsVO.setToUnit(responseType.getToUnit());
				metricsVO.setFromUnit(responseType.getFromUnit());
				metricsVO.setConvReq(responseType.getConvReq());
				break outerloop;
			}
		}

		return metricsVO;

	}
	
	public static String psiToCMH2O(float PSI) {
		if (Float.floatToRawIntBits(PSI) == 0) {
			return "0";
		}
		double cmH2O = PSI / 70.306957829636; 
		if (Double.doubleToRawLongBits(cmH2O) != 0) {
			return df.format(cmH2O);
		} else {
			return "";
		}
	}
	
	public static String inH2OToMMH2O(float inH2O) {
		if (Float.floatToRawIntBits(inH2O) == 0) {
			return "0";
		}
		double mmH2O = inH2O * 25.39999469733; 
		if (Double.doubleToRawLongBits(mmH2O) != 0) {
			return df.format(mmH2O);
		} else {
			return "";
		}
	}

}
