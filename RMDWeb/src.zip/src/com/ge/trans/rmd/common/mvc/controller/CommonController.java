package com.ge.trans.rmd.common.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ge.trans.rmd.common.service.CommonService;
import com.ge.trans.rmd.common.util.AppConstants;

@Controller
@SessionAttributes
public class CommonController extends RMDBaseController {

	@Autowired
	private CommonService commonService;
	
	// Added by Sriram.B(212601214) for Asset Panel feature
	// This method is used to fetch the constants needed for Asset Panel from DB
	@RequestMapping(value = AppConstants.GET_ASSET_PANEL_PARAMETERS,method =RequestMethod.GET)
	@ResponseBody public String getAssetPanelParameters()  throws Exception
	{
		String assetPanelParams = commonService.getAssetPanelParameters();
		return assetPanelParams;
	}
}
