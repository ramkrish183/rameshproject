/**
 * ============================================================
 * Classification: GE Confidential
 * File : EOAWebController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.mvc.controller
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on : August 2, 2011
 * History
 * Modified By : iGATE
 *
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.mvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.km.util.KMConstants;

/*******************************************************************************
 * 
 * @Author : iGATE
 * @Version : 1.0
 * @Date Created: July 21, 2011
 * @Date Modified : July 25, 2011
 * @Modified By :
 * @Contact :
 * @Description : Controller class invoke the web services for EOA Screens
 * @History :
 * 
 ******************************************************************************/
@Controller
public class EOAWebController extends RMDBaseController {

	private static final RMDWebLogger RMDWEBLOGGER = RMDWebLogger
			.getLogger(EOAWebController.class);
	
	@Value("${"+AppConstants.EMETRICS_URL+"}")
	String emetricsUrl;
	@Value("${"+AppConstants.OIL_FAULTS_URL+"}")
	String oilFaultsUrl;
	@Value("${"+AppConstants.MULTILINGUAL_RX_URL+"}")
	String multilingualRxUrl;

	@RequestMapping(value = KMConstants.REQ_URI_SHOW_EMETRICS_SCREEN, method = RequestMethod.GET)
	public String showEmetricsScreen(final Model model,
			final HttpServletRequest request) {
		request.setAttribute(AppConstants.STR_EMETRICS_URL,emetricsUrl);
		return KMConstants.EMETRICS_SCREEN;
	}

	@RequestMapping(value = KMConstants.REQ_URI_SHOW_OIL_FAULT_SCREEN, method = RequestMethod.GET)
	public String showOilFaultsScreen(final Model model,
			final HttpServletRequest request) {
		request.setAttribute(AppConstants.STR_OIL_FAULT_URL,oilFaultsUrl);
		return KMConstants.OIL_FAULTS_SCREEN;
	}
	
	@RequestMapping(value = KMConstants.REQ_URI_SHOW_MULTILINGUAL_SCREEN, method = RequestMethod.GET)
	public String showMultilingualScreen(final Model model,
			final HttpServletRequest request) {
		request.setAttribute(AppConstants.STR_MULTILINGUAL_URL,multilingualRxUrl);
		return KMConstants.MULTILINGUAL_RX_SCREEN;
	}
}
