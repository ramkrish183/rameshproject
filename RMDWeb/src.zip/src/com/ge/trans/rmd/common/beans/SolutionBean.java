package com.ge.trans.rmd.common.beans;

import java.util.Date;
import java.util.List;

import com.ge.trans.rmd.cm.valueobjects.CreateCasesVO;

/*******************************************************************************
 * 
 * @Author : Igate Patni
 * @Version : 1.0
 * @Date Created: Mar 12, 2012
 * @Date Modified :
 * @Modified By :
 * @Contact :
 * @Description :
 * @History :
 * 
 ******************************************************************************/

@SuppressWarnings("serial")
public class SolutionBean extends RMDBaseBean {

private String solutionId;

private String solutionTitle;
private String falseAlarm;
private String rxAccuracy;
private String rmdAccurate;
private String solutionStatus;
private String version;
private List<String> solUrgencyOfRepair;
private String solEstRepairTime;
private String solModelType;
private String solSelectBy;
private String solCondition;
private String solutionType;
private String solValue;
private String urgency;
private String delvDate;
// private String versionNo;
private String reissueFlag;
private String serviceReqId;
private String toolOutputFlag;
private Long currentRxId;
private String solSubSystem;
private String model;
private String isMassApplyRx;
private String addRxApply;
private String customer;
private String fromRN;
private String toRN;
private String fleet;
private String rnh;
private String assets;

public String getIsMassApplyRx() {
	return isMassApplyRx;
}
public void setIsMassApplyRx(String isMassApplyRx) {
	this.isMassApplyRx = isMassApplyRx;
}
public String getModel() {
	return model;
}
public void setModel(String model) {
	this.model = model;
}
public String getSolSubSystem() {
	return solSubSystem;
}
public void setSolSubSystem(String solSubSystem) {
	this.solSubSystem = solSubSystem;
}
/*public String getVersionNo() {
	return versionNo;
}
public void setVersionNo(String versionNo) {
	this.versionNo = versionNo;
}*/
public String getReissueFlag() {
	return reissueFlag;
}
public void setReissueFlag(String reissueFlag) {
	this.reissueFlag = reissueFlag;
}
public String getServiceReqId() {
	return serviceReqId;
}
public void setServiceReqId(String serviceReqId) {
	this.serviceReqId = serviceReqId;
}




public String getSolutionId() {
	return solutionId;
}
public void setSolutionId(final  String solutionId) {
	this.solutionId = solutionId;
}
private String recomNotes;

public String getRecomNotes() {
	return recomNotes;
}
public void setRecomNotes(final String recomNotes) {
	this.recomNotes = recomNotes;
}
public String getSolModelType() {
	return solModelType;
}
public void setSolModelType(String solModelType) {
	this.solModelType = solModelType;
}
public String getSolSelectBy() {
	return solSelectBy;
}
public void setSolSelectBy(String solSelectBy) {
	this.solSelectBy = solSelectBy;
}
public String getSolCondition() {
	return solCondition;
}
public void setSolCondition(String solCondition) {
	this.solCondition = solCondition;
}
private String solNote;
private String solChoice;
private List<CreateCasesVO> createCasesVO;

public List<CreateCasesVO> getCreateCasesVO() {
	return createCasesVO;
}
public void setCreateCasesVO(final List<CreateCasesVO> createCasesVO) {
	this.createCasesVO = createCasesVO;
}

public String getSolutionStatus() {
	return solutionStatus;
}
public void setSolutionStatus(final String solutionStatus) {
	this.solutionStatus = solutionStatus;
}
public String getSolNote() {
	return solNote;
}
public String getAddRxApply() {
	return addRxApply;
}
public void setAddRxApply(String addRxApply) {
	this.addRxApply = addRxApply;
}
public void setSolNote(final String solNote) {
	this.solNote = solNote;
}
/**
 * 
 * @return the solChoice
 */

public String getSolChoice() {
	return solChoice;
}
/**
 * 
 * @param solChoice the solChoice to set
 */
public void setSolChoice(final String solChoice) {
	this.solChoice = solChoice;
}

/**
 * 
 * @return the version
 */
public String getVersion() {
	return version;
}
/**
 * 
 * @param version the version to set
 */
public void setVersion(final  String version) {
	this.version = version;
}


public List<String> getSolUrgencyOfRepair() {
	return solUrgencyOfRepair;
}
public void setSolUrgencyOfRepair(final List<String> solUrgencyOfRepair) {
	this.solUrgencyOfRepair = solUrgencyOfRepair;
}
public String getSolEstRepairTime() {
	return solEstRepairTime;
}
public void setSolEstRepairTime(final String solEstRepairTime) {
	this.solEstRepairTime = solEstRepairTime;
}
/**
 * 
 * @return the solutionTitle
 */
public String getSolutionTitle() {
	return solutionTitle;
}
/**
 * 
 * @param solutionTitle the solutionTitle to set
 */
public void setSolutionTitle(final String solutionTitle) {
	this.solutionTitle = solutionTitle;
}
/**
 * 
 * @return falseAlarm
 */
public String getFalseAlarm() {
	return falseAlarm;
}
/**
 * 
 * @param falseAlarm the falseAlarm to set
 */
public void setFalseAlarm(final String falseAlarm) {
	this.falseAlarm = falseAlarm;
}
/**
 * 
 * @return the rxAccuracy
 */
public String getRxAccuracy() {
	return rxAccuracy;
}
/**
 * 
 * @param rxAccuracy the rxAccuracy to set
 */
public void setRxAccuracy(final String rxAccuracy) {
	this.rxAccuracy = rxAccuracy;
}
/**
 * 
 * @return the rmdAccurate
 */
public String getRmdAccurate() {
	return rmdAccurate;
}
/**
 * 
 * @param rmdAccurate the rmdAccurate to set
 */
public void setRmdAccurate(final String rmdAccurate) {
	this.rmdAccurate = rmdAccurate;
}
public String getSolutionType() {
	return solutionType;
}
public void setSolutionType(String solutionType) {
	this.solutionType = solutionType;
}
public String getSolValue() {
	return solValue;
}
public void setSolValue(String value) {
	this.solValue = value;
}
public String getUrgency() {
	return urgency;
}
public void setUrgency(String urgency) {
	this.urgency = urgency;
}
public String getToolOutputFlag() {
	return toolOutputFlag;
}
public void setToolOutputFlag(String toolOutputFlag) {
	this.toolOutputFlag = toolOutputFlag;
}
public String getDelvDate() {
	return delvDate;
}
public void setDelvDate(String delvDate) {
	this.delvDate = delvDate;
}
public Long getCurrentRxId() {
	return currentRxId;
}
public void setCurrentRxId(Long currentRxId) {
	this.currentRxId = currentRxId;
}
public String getCustomer() {
    return customer;
}
public void setCustomer(String customer) {
    this.customer = customer;
}
public String getFromRN() {
    return fromRN;
}
public void setFromRN(String fromRN) {
    this.fromRN = fromRN;
}
public String getToRN() {
    return toRN;
}
public void setToRN(String toRN) {
    this.toRN = toRN;
}
public String getFleet() {
    return fleet;
}
public void setFleet(String fleet) {
    this.fleet = fleet;
}
public String getRnh() {
    return rnh;
}
public void setRnh(String rnh) {
    this.rnh = rnh;
}
public String getAssets() {
    return assets;
}
public void setAssets(String assets) {
    this.assets = assets;
}



}
