/**
 * ============================================================
 * File : HeaderSearchServiceImpl.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.service
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Mar 01, 2011
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.CasesHeaderVO;
import com.ge.trans.rmd.cm.valueobjects.OpenCasesVO;
import com.ge.trans.rmd.common.beans.HeaderSearchBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.vo.HeaderSearchAssetVO;
import com.ge.trans.rmd.common.vo.HeaderSearchRespVO;
import com.ge.trans.rmd.common.vo.HeaderSearchResponseVO;
import com.ge.trans.rmd.common.vo.HeaderSearchVO;
import com.ge.trans.rmd.services.assets.valueobjects.AssetHeaderSearchResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseHeaderResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseInfoType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseRequestType;
@Service
public class HeaderSearchServiceImpl extends RMDBaseServiceImpl implements
		HeaderSearchService {

	@Autowired
	private WebServiceInvoker rsInvoker;

	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	/**
	 * @Author:
	 * @param
	 * @return AssetList
	 * @Description: This method will return List of assets from Database
	 */
	@Override
	public HeaderSearchResponseVO getAssets(
			final HeaderSearchBean headerSearchBean) throws RMDWebException,
			Exception {
		final HeaderSearchResponseVO headerResponseVO = new HeaderSearchResponseVO();

		AssetResponseType[] assetResponses = null;
		final Map<String, String> headerParams = getHeaderMap(headerSearchBean);
		List<HeaderSearchVO> headerSearchVOLst = new ArrayList<HeaderSearchVO>();
		final Map<String, String> assetResponseMap = new HashMap<String, String>();
		HeaderSearchVO headerSearchVO = null;
		int responseLength;

		try {
			AssetsRequestType objAssetsReqType = new AssetsRequestType();
			objAssetsReqType.setLanguage(headerParams
					.get(AppConstants.USER_LANGUAGE));
			objAssetsReqType.setCustomerId(headerSearchBean.getStrCustomerId());
		
			if (headerSearchBean.isGPOCUser()) {
				objAssetsReqType.setAssetNumber(headerSearchBean
						.getSearchString());
			} else {
				objAssetsReqType.setAssetNumberLike(headerSearchBean
						.getSearchString());
			}
			parseProducts(headerSearchBean.getProducts(), objAssetsReqType);
			assetResponses = (AssetResponseType[]) rsInvoker.post(
					ServiceConstants.GET_ASSETS, objAssetsReqType,
					AssetResponseType[].class);

			if (assetResponses != null) {
				responseLength = assetResponses.length;
				headerSearchVOLst = new ArrayList<HeaderSearchVO>(responseLength);

				assetResponseMap.put(AppConstants.ASSET_RESPONSE_LENGTH,
						Integer.toString(responseLength));
				for (int i = 0; i < assetResponses.length; i++) {

					headerSearchVO = new HeaderSearchVO();
					headerSearchVO.setAssetNumber(assetResponses[i]
							.getAssetNumber());
					headerSearchVO.setGroupName(assetResponses[i]
							.getAssetGroupName());
					headerSearchVO.setCustomerId(assetResponses[i]
							.getCustomerID());
					headerSearchVO.setFleet(assetResponses[i].getFleet());
					headerSearchVO.setModel(assetResponses[i].getModel());
					headerSearchVO.setLocation(assetResponses[i].getLocation());

					headerSearchVOLst.add(headerSearchVO);
					if (null != headerSearchBean.getRequestURI()
							&& headerSearchBean.getRequestURI()
									.equalsIgnoreCase(
											AppConstants.REQ_URI_HEADERSEARCH)
							&& i >= 4) {
						break;
					}
				}

				headerResponseVO.setAssets(headerSearchVOLst);
				headerResponseVO.setResponseLength(assetResponseMap);
			} else {
				responseLength = 0;
				assetResponseMap.put(AppConstants.ASSET_RESPONSE_LENGTH,
						Integer.toString(responseLength));
				headerResponseVO.setResponseLength(assetResponseMap);
			}
		headerSearchVOLst=null;
		assetResponses=null;
		} catch (RMDWebException rmdEx) {
			logger.error(
					"RMDWebException occured in HeaderSearchServiceImpl() getAssets method ",
					rmdEx);
			responseLength = 0;
			assetResponseMap.put(AppConstants.ASSET_RESPONSE_LENGTH,
					Integer.toString(responseLength));
			headerResponseVO.setResponseLength(assetResponseMap);
		} catch (Exception ex) {
			logger.error(
					"Exception occured in HeaderSearchServiceImpl() method getAssets",
					ex);
		}
		return headerResponseVO;
	}

	/**
	 * @Author:
	 * @param
	 * @return AssetList
	 * @Description: This method will return List of Cases from Database
	 */
	@Override
	public HeaderSearchResponseVO getCases(
			final HeaderSearchBean headerSearchBean) throws RMDWebException,
			Exception {
		final HeaderSearchResponseVO headerResponseVO = new HeaderSearchResponseVO();
		CaseInfoType[] casesResponses = null;

		/*
		 * final Map<String, String> queryParamsMap = new HashMap<String,
		 * String>();
		 */
		final Map<String, String> headerParams = getHeaderMap(headerSearchBean);
		final List<OpenCasesVO> openCaseLst = new ArrayList<OpenCasesVO>();
		final Map<String, String> casesResponseMap = new HashMap<String, String>();
		int responseLength;
		OpenCasesVO openCaseVO = null;
		String age = null;
		CaseRequestType objCaseRequestType = new CaseRequestType();
		try {
			objCaseRequestType.setCustomerId(headerSearchBean
					.getStrCustomerId());
			objCaseRequestType.setCaseLike(headerSearchBean.getSearchString());
			objCaseRequestType.setSearchTypeFlag(headerSearchBean
					.getSearchTypeFlag());
			parseProducts(headerSearchBean.getProducts(), objCaseRequestType);
			casesResponses = (CaseInfoType[]) rsInvoker.post(
					ServiceConstants.HEADER_SEARCH_CASES_SERVICE,
					objCaseRequestType, CaseInfoType[].class);
			if (casesResponses != null) {
				responseLength = casesResponses.length;

				casesResponseMap.put(AppConstants.CASE_RESPONSE_LENGTH,
						Integer.toString(responseLength));

				final DateFormat zoneFormater = new SimpleDateFormat(
						AppConstants.DATE_FORMAT_24HRS);
				final TimeZone firstTime = TimeZone
						.getTimeZone(headerSearchBean.getTimeZone());
				for (int i = 0; i < casesResponses.length; i++) {
					openCaseVO = new OpenCasesVO();

					zoneFormater.setTimeZone(firstTime);
					openCaseVO = new OpenCasesVO();
					openCaseVO.setCaseID(casesResponses[i].getCaseID());
					openCaseVO.setCaseTitle(casesResponses[i].getCaseTitle());
					openCaseVO.setOwner(casesResponses[i].getOwner());
					openCaseVO.setQueueName(casesResponses[i].getQueueName());
					openCaseVO.setCaseReason(casesResponses[i].getReason());
					openCaseVO.setCaseType(casesResponses[i].getCaseType());

					if (casesResponses[i].getCreatedDate() != null) {

						age = RMDCommonUtil.calculateAge(casesResponses[i]
								.getCreatedDate().toGregorianCalendar(),
								new GregorianCalendar(), headerSearchBean
										.getTimeZone());

						openCaseVO.setAge(age);
						final String creationDate = zoneFormater
								.format(casesResponses[i].getCreatedDate()
										.toGregorianCalendar().getTime());
						openCaseVO.setCreatedDate(creationDate);
					}

					openCaseVO.setPriority(casesResponses[i].getPriority());
					openCaseVO.setCaseCondition(casesResponses[i]
							.getCondition());
					if (casesResponses[i].getClosedDate() != null) {
						final String closedDate = zoneFormater
								.format(casesResponses[i].getClosedDate()
										.toGregorianCalendar().getTime());
						openCaseVO.setCloseDate(closedDate);
					}
					openCaseVO.setCaseObjId(casesResponses[i].getCaseObjid());
					openCaseVO.setAppend(casesResponses[i].getAppend());
					openCaseVO.setStrGrpName(casesResponses[i].getCustomerId());
					openCaseVO
							.setAssetNumber(casesResponses[i].getRoadNumber());
					openCaseVO.setCustomerName(casesResponses[i]
							.getCustomerName());
					openCaseLst.add(openCaseVO);
				}

				headerResponseVO.setCases(openCaseLst);
				headerResponseVO.setResponseLength(casesResponseMap);
			} else {
				responseLength = 0;
				casesResponseMap.put(AppConstants.CASE_RESPONSE_LENGTH,
						Integer.toString(responseLength));
				headerResponseVO.setResponseLength(casesResponseMap);
			}

		} catch (Exception ex) {
			logger.error("Exception occured in getCases method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return headerResponseVO;

	}
	
	
	@Override
	public HeaderSearchRespVO getAssetsData(HeaderSearchBean headerSearchBean) throws RMDWebException, Exception{
		final HeaderSearchRespVO headerResponseVO = new HeaderSearchRespVO();

		AssetHeaderSearchResponseType[] assetResponses = null;
		final Map<String, String> headerParams = getHeaderMap(headerSearchBean);
		List<HeaderSearchAssetVO> headerSearchVOLst = new ArrayList<HeaderSearchAssetVO>();
		final Map<String, String> assetResponseMap = new HashMap<String, String>();
		HeaderSearchAssetVO headerSearchVO = null;
		int responseLength;

		try {
			AssetsRequestType objAssetsReqType = new AssetsRequestType();
			objAssetsReqType.setLanguage(headerParams
					.get(AppConstants.USER_LANGUAGE));
			objAssetsReqType.setCustomerId(headerSearchBean.getStrCustomerId());
		
			if (headerSearchBean.isGPOCUser()) {
				objAssetsReqType.setAssetNumber(headerSearchBean
						.getSearchString());
			} else {
				objAssetsReqType.setAssetNumberLike(headerSearchBean
						.getSearchString());
			}
			parseProducts(headerSearchBean.getProducts(), objAssetsReqType);
			assetResponses = (AssetHeaderSearchResponseType[]) rsInvoker.post(
					ServiceConstants.GET_ASSETS_HEADER, objAssetsReqType,
					AssetHeaderSearchResponseType[].class);

			if (assetResponses != null && assetResponses.length>0) {
				responseLength = assetResponses.length;
				headerSearchVOLst = new ArrayList<HeaderSearchAssetVO>(responseLength);
				assetResponseMap.put(AppConstants.ASSET_RESPONSE_LENGTH,
						Integer.toString(responseLength));
				for (int i = 0; i < assetResponses.length; i++) {
					headerSearchVO = new HeaderSearchAssetVO();
					headerSearchVO.setAssetNumber(assetResponses[i]
							.getAssetNumber());
					headerSearchVO.setGroupName(assetResponses[i]
							.getAssetGroupName());
					headerSearchVO.setCustomerId(assetResponses[i].getCustomerID());
					headerSearchVOLst.add(headerSearchVO);
					if (null != headerSearchBean.getRequestURI()
							&& headerSearchBean.getRequestURI()
									.equalsIgnoreCase(
											AppConstants.REQ_URI_HEADERSEARCH)
							&& i >= 4) {
						break;
					}
				}

				headerResponseVO.setAssets(headerSearchVOLst);
				headerResponseVO.setResponseLength(assetResponseMap);
			} else {
				responseLength = 0;
				assetResponseMap.put(AppConstants.ASSET_RESPONSE_LENGTH,
						Integer.toString(responseLength));
				headerResponseVO.setResponseLength(assetResponseMap);
			}
		headerSearchVOLst=null;
		assetResponses=null;
		} catch (RMDWebException rmdEx) {
			logger.error(
					"RMDWebException occured in HeaderSearchServiceImpl() getAssetsData method ",
					rmdEx);
			responseLength = 0;
			assetResponseMap.put(AppConstants.ASSET_RESPONSE_LENGTH,
					Integer.toString(responseLength));
			headerResponseVO.setResponseLength(assetResponseMap);
		} catch (Exception ex) {
			logger.error(
					"Exception occured in HeaderSearchServiceImpl() method getAssetsData",
					ex);
		}
		return headerResponseVO;
	}
	
	
	/**
	 * @Author:
	 * @param
	 * @return AssetList
	 * @Description: This method will return List of Cases from Database
	 */
	@Override
	public HeaderSearchRespVO getCasesData(
			final HeaderSearchBean headerSearchBean) throws RMDWebException,
			Exception {
		final HeaderSearchRespVO headerResponseVO = new HeaderSearchRespVO();
		CaseHeaderResponseType[] casesResponses = null;

		final Map<String, String> headerParams = getHeaderMap(headerSearchBean);
		 List<CasesHeaderVO> openCaseLst = new ArrayList<CasesHeaderVO>();
		final Map<String, String> casesResponseMap = new HashMap<String, String>();
		int responseLength;
		CasesHeaderVO openCaseVO = null;
		String age = null;
		CaseRequestType objCaseRequestType = new CaseRequestType();
		try {
			objCaseRequestType.setCustomerId(headerSearchBean
					.getStrCustomerId());
			objCaseRequestType.setCaseLike(headerSearchBean.getSearchString());
			objCaseRequestType.setSearchTypeFlag(headerSearchBean
					.getSearchTypeFlag());
			parseProducts(headerSearchBean.getProducts(), objCaseRequestType);
			casesResponses = (CaseHeaderResponseType[]) rsInvoker.post(
					ServiceConstants.HEADER_SEARCH_CASES,
					objCaseRequestType, CaseHeaderResponseType[].class);
			if (casesResponses != null && casesResponses.length>0) {
				responseLength = casesResponses.length;
				openCaseLst = new ArrayList<CasesHeaderVO>(responseLength);
				casesResponseMap.put(AppConstants.CASE_RESPONSE_LENGTH,
						Integer.toString(responseLength));
				for (int i = 0; i < casesResponses.length; i++) {
					openCaseVO = new CasesHeaderVO();
					openCaseVO.setCaseID(casesResponses[i].getCaseID());
					openCaseVO.setStrGrpName(casesResponses[i].getCustomerId());
					openCaseVO
							.setAssetNumber(casesResponses[i].getRoadNumber());
					openCaseVO.setCustomerName(casesResponses[i]
							.getCustomerName());
					openCaseLst.add(openCaseVO);
				}

				headerResponseVO.setCases(openCaseLst);
				headerResponseVO.setResponseLength(casesResponseMap);
			} else {
				responseLength = 0;
				casesResponseMap.put(AppConstants.CASE_RESPONSE_LENGTH,
						Integer.toString(responseLength));
				headerResponseVO.setResponseLength(casesResponseMap);
			}
		casesResponses=null;
		openCaseLst=null;
		} catch (Exception ex) {
			logger.error("Exception occured in getCasesData method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return headerResponseVO;

	}

}