package com.ge.trans.rmd.common.util;


public class AppConstants {
	public static final String APP_RESOURCE_PATH =  "com.ge.trans.rmd.common.resources.rmd";
	public static final String APPL_RESOURCE_PATH =  "com.ge.trans.rmd.common.resources.AppResources";
	
	public static final String VEHICLE_FAULT_MAX_DATE_LIMIT="VEHICLE_FAULT_MAX_DATE_LIMIT";
	public static final String EQUIPMENT_FAULT_MAX_DATE_LIMIT="EQUIPMENT_FAULT_MAX_DATE_LIMIT";
	public static final String DPEAB_FAULT_MAX_DATE_LIMIT="DPEAB_FAULT_MAX_DATE_LIMIT";
	public static final String DHMS_FAULT_MAX_DATE_LIMIT="DHMS_FAULT_MAX_DATE_LIMIT";
	public static final String INCIDENT_FAULT_MAX_DATE_LIMIT="INCIDENT_FAULT_MAX_DATE_LIMIT";
	
	public static final String VEHICLE_FAULT_DEFAULT_NO_OF_DAYS="VEHICLE_FAULT_DEFAULT_NO_OF_DAYS";
	public static final String EQUIPMENT_FAULT_DEFAULT_NO_OF_DAYS="EQUIPMENT_FAULT_DEFAULT_NO_OF_DAYS";
	public static final String DPEAB_FAULT_DEFAULT_NO_OF_DAYS="DPEAB_FAULT_DEFAULT_NO_OF_DAYS";
	public static final String DHMS_DEFAULT_NO_OF_DAYS="DHMS_DEFAULT_NO_OF_DAYS";
	public static final String INCIDENT_FAULT_DEFAULT_NO_OF_DAYS="INCIDENT_FAULT_DEFAULT_NO_OF_DAYS";
	public static final String RAPID_VEHICLE_FAULT_DEFAULT_NO_OF_DAYS="RAPID_VEHICLE_FAULT_DEFAULT_NO_OF_DAYS";
	public static final String RAPID_EQUIPMENT_FAULT_DEFAULT_NO_OF_DAYS="RAPID_EQUIPMENT_FAULT_DEFAULT_NO_OF_DAYS";
	
	public static final String VEHICLE_FAULT_DROPDOWN_DAYS="VEHICLE_FAULT_DROPDOWN_DAYS";
	public static final String EQUIPMENT_FAULT_DROPDOWN_DAYS="EQUIPMENT_FAULT_DROPDOWN_DAYS";
	public static final String DHMS_FAULT_DROPDOWN_DAYS="DHMS_FAULT_DROPDOWN_DAYS";
	public static final String DPEAB_FAULT_DROPDOWN_DAYS="DPEAB_FAULT_DROPDOWN_DAYS";
	public static final String INCIDENT_FAULT_DROPDOWN_DAYS="INCIDENT_FAULT_DROPDOWN_DAYS";
	public static final String RR_VEHICLE_FAULT_DROPDOWN_DAYS="RR_VEHICLE_FAULT_DROPDOWN_DAYS";
	public static final String RR_EQUIPMENT_FAULT_DROPDOWN_DAYS="RR_EQUIPMENT_FAULT_DROPDOWN_DAYS";
	public static final String CASE_DROPDOWN_DAYS="CASE_DROPDOWN_DAYS";

	public static final String GET_RX_EXEC_RXCASEID="/getSolutionExecDetailsForRxCaseID";
	public static final String RESOURCE_PATH = "ps.application.appdata";   
	public static final String WS_RESOURCE_PATH =  "com.ge.trans.rmd.common.resources.RESTServices";
	public static final String RMD_ENV = "RMD_ENV";
	public static final String IMG_END_NAME = "_logo.gif";
	public static final String OMD_SUPPORTED_LANGUAGES = "OMD_SUPPORTED_LANGUAGES";
	public static final String OPEN_CASES_DROPDOWN = "OPEN_CASES_DROPDOWN";
	public static final String DEFAULT_TIME_ZONE = "US/Eastern";
	public static final String DOWNLOAD_STATUS_DAYS = "DOWNLOAD_STATUS_DAYS";
	public static final String ASSET_OVERVIEW_LAST_DOWNLOAD = "ASSETOVERVIEW_LASTDOWNLOAD";
	public static final String ASSET_OVERVIEW_FAULT_STATUS="ASSETOVERVIEW_FAULTSTATUS";
	public static final String DD_FILTER_DATASCREEN = "DATASCREEN_FILTER"; 
	public static final String DD_MULTISELECT_DROPDOWN = "DATASCREEN_DATASET";
	public static final String DD_RIGHT_DROPDOWN = "DATASCREEN_LATESTCASES";
	public static final String DD_FILTER_UNAVAILABLE = "DD_FILTER_UNAVAILABLE";
	public static final String DD_FILTER = "filterDD";
	public static final String DD_FILTER_MULTISELECT = "multiselectDD";
	public static final String DATASCREEN_DROPDOWN = "rightDropdown";
	public static final String FILTER_UNAVAILABLE = "filterUnavailable";
	public static final String ASSETOVERVIEW_NOTES = "ASSETOVERVIEW_NOTES";
	public static final String ASSETOVERVIEW_STATUS = "ASSETOVERVIEW_STATUS";
	//Added for Asset Overview Last Fault story
	public static final String ASSET_OVERVIEW_LAST_FAULT = "ASSETOVERVIEW_LASTFAULT";
	public static final String ASSET_OVERVIEW_NOTES_PRIV = "assetOverviewNotes";
	public static final String OWNER_UNASSIGNED = "Unassigned";
	//REQUEST URI - VIEWS
	public static final String REQ_URI_CASES="/cases";
	public static final String REQ_URI_USER_CASES="/myCases";
	public static final String REQ_URI_HOME="/home";
	public static final String REQ_URI_LOGIN ="/login";
	public static final String REQ_URI_SSOLOGIN ="/ssologin";
	public static final String REQ_URI_MSG_CENTER="/stickyTab";
	public static final String REQ_URI_DATA="/data";
	public static final String REQ_URI_MCASES="/maincases";
	public static final String REQ_URI_MY_PREF="/mypreferences";
	public static final String REQ_URI_NOTES="/notes";
	public static final String REQ_URI_FLEET="/getFleet";
	public static final String REQ_URI_OVERVIEW="/overview";
	public static final String REQ_URI_ASSETLIST="/assetlist";
	public static final String REQ_URI_CASELIST="/caselist";
	public static final String VIEW_ASSETLIST="assetlist";
	public static final String VIEW_CASELIST="caselist";
	public static final String REQ_URI_SHOPS="/shops";
	public static final String REQ_URI_SOLS="/solutions";
	public static final String REQ_URI_LOGOUT="/logout";
	public static final String REQ_URI_MYPREFERENCES="/userpreferences";
	public static final String REQ_URI_STICKYTAB="/stickyTab";
	public static final String REQ_URI_ASSETLIST_DATA="/getAssetList";
	public static final String REQ_URI_ASSETOVW_ASSETS="/getAsset";
	public static final String REQ_URI_ASSETOVW_CASE="/getAssetCases";
	public static final String REQ_URI_ASSETOVW_NOTES="/getAssetNotes";
	public static final String REQ_URI_ASSETOVW="/assetOverview";
	public static final String REQ_URI_PP_ASSETOVW="/ppAssetOverview";
	public static final String REQ_URI_PP_CURRENT_ASSETS="/getCurrentPPAsset";
	public static final String REQ_URI_ASSETOVW_FSTATUS="/getFaultStatus";
	public static final String REQ_URI_ASSETOVW_LAST_DOWNLOAD="/getDownloadStatus";
	public static final String REQ_URI_ASSETOVW_SETNOTES="/addAssetNotes";
	public static final String REQ_URI_VISUALIZATION="/visualization";
	public static final String REQ_URI_VISUALIZATION_DATA="/visualization/getData";
	public static final String REQ_URI_NUMBER_OF_DAYS="/getNumberOfDays";
	public static final String REQ_URI_ASSETCASES="/assetCases";
	public static final String REQ_URI_ASSETOVW_LOCATION="/getAssetLocation";
	public static final String REQ_URI_SOLNS="/getSolutions";
	public static final String REQ_URI_CASEHISTRY="/getCaseHistory";
	public static final String REQ_URI_POSTNOTES="/postNotes";
	public static final String REQ_URI_PP_ASSETS_HISTORY="/ppAssetStatusHistory";
	public static final String REQ_URI_PP_ASSETS_HISTORY_DATA="/ppAssetStatusHistoryData";
	
	//Added for Asset Overview Last Fault story
	public static final String REQ_URI_ASSETOVW_LST_FLT_STATUS="/getLastFaultStatus";
	public static final String REQ_POPOUT_URL ="/popout";
	
	public static final String REQ_URI_HEADER_SEARCH_CALL="/getSearchData";
	public static final String VIEW_HOME="home";
	public static final String VIEW_CASES = "cases";
	public static final String VIEW_MY_CASES = "mycases";
	public static final String VIEW_LOGIN = "loginSuccess";
	public static final String LOGIN_SUCCESS = "home";
	public static final String LOGIN_FAILURE = "loginModel.error.UserName.NotValid";
	public static final String ACCESS_DENIED = "acces.denied";
	public static final String ACCESS_DENIED_FOR_ROLE = "acces.role.denied";
	public static final String ACCESS_DENIED_FOR_PRIVILEGES = "acces.privileges.denied";
	public static final String UNKNOWN_EXCEPTION = "unknown.exception";
	public static final String EMPTY_STRING  ="";
	public static final String VIEW_MSG_CENTER="stickyTab";
	public static final String VIEW_DATA = "data";
	public static final String VIEW_MCASES = "maincases";
	public static final String VIEW_MY_PREF="mypreferences";
	public static final String VIEW_NOTES="notes";
	public static final String VIEW_FLEET="getFleet";
	public static final String VIEW_OVERVIEW="overview";
	public static final String VIEW_ASSETOVW="assetOverview";
	public static final String VIEW_PP_ASSETOVW="ppAssetOverview";
	public static final String VIEW_PP_ASSETHSRTY="ppAssetStatusHistory";
	public static final String VIEW_ASSETCASES="assetCases";
	public static final String VIEW_SHOPS="shops";
	public static final String VIEW_SOLUTIONS="solutions";
	public static final String VIEW_INDEX="index";
	public static final String VIEW_LOGOUT="logout";
	public static final String VIEW_ACCESS_DENIED="accessDenied";
	public static final String  VIEW_MYPREFERENCES="mypreferences";
	public static final String  VIEW_STICKYTAB="stickyTab";
	public static final String  STICKYTAB_ID="stkTabId";
	public static final int  DEFAULT_INT=0;
	public static final int  TAB_WIDTH=122;
	public static final String  BLANK_STRING=" ";
	public static final String LOG4JCONFIGLOCATION = "log4jConfigLocation";
	public static final String USER_PREFERENCE_UPDATE = "userPreferenceModel.update.message";
	public static final String USER_PREFERENCE_UPDATE_FAILED = "userPreferenceModel.update.message.failed";
	public static final String VIEW_GLOBAL_EXCEPTION_PAGE="globalException";
	public static final String REDIRECT = "redirect:";
	public static final String ERROR_PAGE = "errorPage";
	public static final String VIEW_POPOUT = "popout";
	
	public static final String RESOURCE_FILE = "/com/ge/trans/rmd/common/resources/RMDResources.xml";
	public static final String RESOURCE_ITEM = "RESOURCE_ITEM";
	
	public static final int MAX_RESOURCE_LEVELS = 10;
	public static final String LEVEL = "level-";
	public static final String RESOURCE_ID = "resourceId";
	public static final String TYPE = "type";
	public static final String FIELD_TYPE = "fieldType";
	public static final String ACCESS_LEVELS = "accessLevels";
	public static final String LABEL = "label";
	public static final String DESCR = "descr";
	public static final String URL = "url";
	public static final String FILTERFLAG = "filterFlag";
	public static final String LEVEL_SEPERATOR = "/";
	public static final String MSG_CENTER_URL= "/RMDWeb/stickyTab?";
	public static final String LABEL_LOGOUT_MSG ="logout.message";
	public static final String ATTR_PREFERENCE_MODEL = "preferenceModel";
	public static final Long INACTIVE_STATE = 0L;
	public static final Long ACTIVE_STATE = 1L;
	
	public static final String PROFILE = "PROFILE";
	public static final String PREFERENCES = "PREFERENCES";
	public static final String HEADERSEARCH = "HEADER_SEARCH";
	
	public static final String ESTTIME = "US/Eastern"; 
	public static final String LANG = "en";

	public static final String DEPLOYMENT_LOCATION= "DEPLOYMENT_LOCATION";
	
	//Chars
	public static final String CHAR_UNDER_SCORE= "_";
	
	
	public static final String SCRIPTS="/scripts";
	public static final String CSS="/css";
	public static final String IMAGES="/images";
	public static final String IMG="/img";
	public static final String JS="/js";
	public static final String COMPONENTS="/components";
    //ATTRIBUTES
	
	public static final String ATTR_LOGIN_MODEL = "loginModel";
	public static final String ATTR_TAB_LIST = "tabList";
	public static final String ATTR_NEW_TAB = "newTab";
	public static final String ATTR_CL_MAP = "clickedLinkMap";
	public static final String ATTR_PRI_MAP = "primaryNavMap";
	public static final String ATTR_SEC_MAP = "secondaryNavMap";
	public static final String ATTR_HOME_PAGE = "homePage";
	public static final String ATTR_SUB_PAGE = "subPageIdxforHome";
	public static final String ATTR_IMAGE_NAME = "ImageName";
	public static final String ATTR_LOGOUT_MSG = "logoutMessage";
	
	public static final String ATTR_LANGUAGES_MAP="mapLanguage";
	public static final String ATTR_TIMEZONE_MAP="maptimeZone";
	public static final String ATTR_ROLE_LIST="listRoles";
	public static final String ATTR_PREFERENCE_SEQ_ID_LIST="listPreferenceSeqId";
	public static final String ATTR_PREFERENCE_USER_ID_LIST="listPreferenceUserId";
	public static final String ATTR_PREFERENCE_USER_TYPE_LIST="listUserPreferenceType";
	public static final String ATTR_USER_OBJECT ="userVO";
	public static final String ATTR_TIME_ZONE ="timeZone";
	public static final String PLATFORM_EGA="EGA";
	public static final String PLATFORM_QNX="QNX";
	public static final String  LANGUAGE_STRING = "langCompare";
	public static final String  TIMEZONE_STRING = "timeCompare";
	public static final String  ROLE_STRING = "roleCompare";
	public static final String  ATTR_COLON = ":";
	public static final String  ATTR_DISPLAY_MSG = "msg";
	public static final String  ATTR_USER_PREFERENCE_MAP_LIST = "userPreferenceMapLst";
	//Web Services
	
	public static final String REST_SERVICE_BASE_URL = "REST_SERVICE_BASE_URL";
	
	//TEMP CONSTANTS-Value will come from database once.
	public static final int MIN_STICKY_TAB_COUNTER = 0;
	public static final String SUBTABURL = "/RMDWeb/stickyTab?";
	// For Sticky Tab String values.
	public static final String MAIN_PAGE = "mainPage";
	public static final String REMOVE = "remove";
	public static final String ALREADY_EXIST_STICKYTAB = "alreadyExistStickyTab";
	public static final String STICKYTAB = "stickyTab";
	public static final String MAXSTICKYTAB = "maxStickyTab";
	public static final String REMOVETABFLAG = "removeTabFlag";
	public static final String DIFAULT_STICKY_SUBTAB_FLAG = "defaultStickySubTab";
	public static final String ISSTICKYTAB = "isStickyTab";
	public static final String STICKYTAB_SUBTAB = "stickyTabSubTab";
	public static final String SUBTABEXIST = "subTabExist";
	public static final String EMPTYSTRING = "";
	public static final String YES_FLAG = "Y";
	public static final String INIT_LOAD = "INIT_LOAD";
	public static final String NO_FLAG = "N";
	public static final String CASE = "case";
	public static final String STICKY_TAB = "_STICKYTAB";
	public static final String STICKY_TAB_SPAWN_FROM = "stickyTabSpawnFrom";
	public static final String TAB_DETAIL_MAP = "tabDetailsMap";
	public static final String SESSION_ATT_STICKY_TAB_LIST  = "stickyTabList";
	public static final String  LANGUAGE = "language";
	public static final String  ROLE = "ROLE";
	public static final String  TIMEZONE = "timezone";
	public static final String DEFUALT_USER_PREFFERED_LANG = "userPreferredLanguage";
	public static final String TAB = "tab";
	public static final String REORDER = "reOrder";
	public static final String DIFFWINDOWTAB = "diffWindowTab";
	public static final String STICKYTABORDER = "stickyTabOrder";
	public static final String STICKYTABSPAWNFROM = "stickyTabSpawnFrom";
	public static final String STKTABID = "stkTabId";
	public static final String STICKYTABSUBTAB = "stickyTabSubTab";
	public static final String ACTION = "action";
	public static final String REMOVETABTD = "removeTabId";
	public static final String PRI_NAV_MAP ="primanyNavDetailsMap";
	public static final String UNCHECKED ="unchecked";
	public static final String  ROLE_PREF = "rolePreference";
	


		
	//WS PARAMS
	
	public static final String WS_PARAM_USER_ID = "userId";
	public static final String GENERAL_PARAM_USER_ID = "userID";
	public static final String WS_PARAM_PASSWD = "password";
	public static final String WS_PARAM_ASSTNUM = "assetNumber";
	public static final String WS_PARAM_ASSTGRP = "groupName";
	public static final String WS_PARAM_CUSTID = "customerId";
	public static final String WS_SOLUTION_STATUS = "solutionStatus";
	public static final String WS_PARAM_ASSTNUMFROM = "assetNumberFrom";
	public static final String WS_PARAM_ASSTNUMTO = "assetNumberTo";
	public static final String WS_PARAM_SOLUTIONSTATUS = "solutionStatus";
	public static final String WS_PARAM_QUEUENAME = "queueName";
	public static final String WS_PARAM_CASESTATUS = "caseStatus";
	public static final String WS_PARAM_CASEID = "caseid";
	public static final String WS_PARAM_CASEID_1 = "caseID";
	public static final String WS_PARAM_CASEID_2 = "caseId";
	public static final String WS_BUS_ORG_ID = "busOrgId";
	public static final String WS_VEHICLE_HEADER = "vehicleHeader";
	public static final String WS_VEHICLE_NUMBER = "vehicleNumber";
	public static final String CASEID = "caseID";
	public static final String USERID = "userID";
	public static final String USERTYPE = "userType";
	public static final String OLDUSERID = "oldUserId";	
	//PopUp Constants
	public static final String INDICATOR_MYPREFERENCE="X";
	
	//User Profile Constants
	
	public static final String INDICATOR2_USERPROFILE="userProfile.modal.Success";
	public static final String ZERO ="0";
	public static final String INDICATOR4_USERPROFILE="userProfile.modal.Failed";
	public static final String USERPROFILE_ERR1="userProfile.error.oldPassword.empty";
	public static final String USERPROFILE_ERR2="userProfile.error.newPassword.empty";
	public static final String USERPROFILE_ERR3="userProfile.error.confirmPassword.empty";
	public static final String USERPROFILE_ERR4="userProfile.error.oldPassword.valid";
	public static final String USERPROFILE_ERR5="userProfile.error.passwordMatch";
	public static final String USERPROFILE_ERR6="userProfile.error.newPassword.NotValid";
	public static final String USERPROFILE_ERR7="userProfile.modal.Failed";
	public static final String VIEW_ACCESS_DENIED_PROFILE="accessDeniedProfile";
	public static final String USERPROFILE_FORMVALUES="formValues";
	public static final String USERPROFILE_REQ_RESETPASS="/resetPassword";
	public static final String USERPROFILE_REQ_CHGROLE="/changeRole";
	public static final String SUCCESS="success";
	public static final String FAILURE="failure";
	public static final String USERPROFILE_MODEL="userProfile";
	public static final String USERPROFILE_PASSWORDIND="passwordIndicator";
	public static final String USERPROFILE_DEFAULTROLE="defaultRole";
	public static final String ERRORMSG="errorMessage";
	public static final String USERPROFILE_ROLES="roles";
	public static final String USERPROFILE_OLDPASSWORD="oldPassword";
	public static final String USERPROFILE_NEWPASSWORD="newPassword";
	public static final String USERPROFILE_CONFIRMPASSWORD="confirmPassword";
	public static final String USERPROFILE_LOG1="UserProfileController resetPassword():Start";
	public static final String USERPROFILE_LOG2="UserProfileController password Validation: Start";
	public static final String USERPROFILE_LOG3="UserProfileController password change: Start";
	public static final String USERPROFILE_LOG4="UserProfileController password change: Success";
	public static final String USERPROFILE_LOG5="UserProfileController password change: Failed";
	public static final String USERPROFILE_LOG6="UserProfileController password change: Exception";
	public static final String USERPROFILE_LOG7="UserProfileController changeRole(): Start";
	public static final String USERPROFILE_LOG8="UserProfileController changeRole(): Roles";
	public static final String USERPROFILE_LOG9="UserProfileController changeRole(): NO Roles";
	public static final String USERPROFILE_LOG10="UserProfileController changeRole(): Stickys Removed";
	public static final String USERPROFILE_LOG11="UserProfileController changeRole(): Privileges For Roles";
	public static final String USERPROFILE_LOG12="UserProfileController changeRole(): No Privileges For Role";
	public static final String USERPROFILE_LOG13="UserProfileController changeRole(): End";
	public static final String USERPROFILE_LOG14="UserProfileController changeRole(): Exception";
	
	//Added by Sri for Hits tab.
	public static final String HITS_RULE_TYPE = "ruleType";
	public static final String HITS_RULE_FAMILY = "ruleFamily";
	public static final String HITS_RULE_ID = "ruleId";
	public static final String HITS_RULE_TITLE = "ruleTitle";
	public static final String HITS_ROAD_HDR = "roadInit";
	public static final String HITS_ROAD_NO = "roadNo";
	public static final String HITS_SEARCH_START_DATE = "ruleSearchFromDate";
	public static final String HITS_SEARCH_END_DATE = "ruleSearchToDate";
	public static final String AURIZON_CUST_NAME = "ARZN";
	public static final String IS_AURIZON_CUST = "isAurizonRuleAuthor";
	public static final String GET_ROADNUM_HEADERS="/getRoadNumHeaders";
	
	
	//Authorize Constants
	public static final String MENU_ACCESS_LEVEL_SHOW = "Show";
	public static final String MENU_ACCESS_LEVEL_HIDE = "Hide";
	public static final String SUB_MENU_PREFIX="SUBMENU_";
	public static final String SUB_TAB_PREFIX="SUB_TAB_";
	public static final String MENU_STICKY_TAB="stickytab";
	public static final String MENU_STICKY_SUBTAB="stickysubtab";
	public static final String STICKY_TAB_DESCR="Sticky Tab Menu";
	public static final String UNDERSCORE="_";
	public static final String CM_MATCHED_ROLES="cmMatchedRoles";
	public static final String PRIMARY_NAV_IN_CONTEXT="roleId";
	public static final String SECONDARY_NAV_IN_CONTEXT="roleId";
		
	//Session time out constants
	public static final String LOGINURI = "login";
	public static final String CACHING_CACHE_CONTROL = "Cache-Control";
	public static final String CACHING_PRAGMA = "Pragma";
	public static final String CACHING_NO_CACHE = "no-cache";
	public static final String CACHING_NO_STORE = "no-store";
	public static final String CACHING_EXPIRES = "Expires";
	
	public static final String EXCEPTION_EOA_101="EOA_101";	
	public static final String EXCEPTION_EOA_109="EOA_109";
	public static final String EXCEP_DB_CONN_FAILURE="DB_CONNECTION_FAILURE_MESSAGE";
	public static final String EXCEPTION_EOA_3032="EOA_3032";
	public static final String USER_INACTIVE="user.inactive";

	public static final String VIEW_SOLUTIONS_PROFILE = "solutionsProfile";

	public static final String VIEW_SHOPS_PROFILE = "shopsProfile";
	public static final String REQ_URI_ASSET = "dummyAsset";
	public static final String VIEW_ASSET = "asset";
	public static final String VIEW_VISUALIZATION = "visualization";
	public static final String RESOURCE_OBJECT_SESSION = "resouceObjectSession";
	public static final String LIST_FAULT_ASSET_VALUE_PART = "lsFaultAssetValuePart";
	public static final String FREEZE_STYLE_FIXED = "fixed";
	public static final String DATE_FORMATTER_DATA_SCREEN = "^date";
	public static final String FROM_DATE = "fromDate";
	public static final String TO_DATE = "toDate";
	public static final String NO_OF_DAYS = "noOfDays";
	
	public static final String INDEX_0 = "0";
	public static final String INDEX_1 = "1";
	public static final String INDEX_2 = "2";
	public static final String INDEX_10 = "10";
	public static final String INDEX_11 = "11";
	public static final String INDEX_19 = "19";
	public static final int DEFAULT_COLUMN_WIDTH = 55;
	public static final String OCCUR_TIME = "OCCUR_TIME";
	public static final String DEFAULT_START_ROW = "0";
	public static final String DEFAULT_END_ROW = "500";
	public static final String MIN_DEFAULT_SEQ_ID = "0";
	public static final String MAX_DEFAULT_SEQ_ID = "10000000";
	public static final String RULE_DEFINITION_ID="ruleDefinitionId";
	
	public static final String LIST_NAME = "listName";
	public static final String LOOKUP_NUMBER_OF_DAYS = "NUMBER_OF_DAYS_IN_VISUALIZATION";
	public static final String ASSET_NUMBER = "assetNumber";
	public static final String CUSTOMER_ID = "customerId";
	public static final String ASSET_GROUP_NAME = "assetGrpName";
	public static final String SELECT_TYPE = "selectType";
	public static final String CASE_ID = "caseId";
	public static final String RULE_ID = "ruleId";
	public static final String RULE_TYPE = "ruleType";
	public static final String INITIAL_LOAD = "initialLoad";
	public static final String NOTCH_8 = "notch8";
	public static final String DS_ALL_RECORDS = "getAllRecords";
	public static final String RS_RULE_ID = "ruleID";
	public static final String STR_CASE = "case";
	public static final String STR_RULE = "rule";
	public static final String SEL_TYPE_DATA_SEGMENT = "data_segment";

	public static final String ALL_DATA = "alldata";
	public static final String ASSET_TAB_ID = "assetTabId";
	public static final String SORT_OPTIONS = "sortOptions";
	public static final String START_ROW = "startRow";
	public static final String MIN_FAULT_ID = "minFaultId";
	public static final String MAX_FAULT_ID = "maxFaultId";
	public static final String END_ROW = "endRow";
	public static final String FROM_DATE_FORMAT = "MM/dd/yyyy HH:mm:ss";
	public static final String TO_DATE_FORMAT = "MM/dd/yyyy HH:mm:ss";
	
	public static final String DATE_FORMAT = "MM/dd/yyyy hh:mm:ss";
	public static final String VISUAL_DATE_FORMAT = "MM/dd/yy HH:mm:ss";
		
	public static final String VISUALIZATION_DATE_FORMAT = "VISUALIZATION_DATE_FORMAT";	
	public static final String VIZ_DATE_FORMAT = "vizDateFormat";	
	public static final String HEATMAP_UPPER_LIMIT ="heatmapupperlimit";
	public static final String HEATMAP_LOWER_LIMIT ="heatmaplowerlimit";
	public static final String VISUALIZATION_NBSP ="&nbsp;";
	
	//AssetOverview Constants
	public static final String REQ_PARAM_CASEID ="caseID";
	public static final String REQ_PARAM_ASSTNUM ="assetNumber";
	public static final String REQ_PARAM_ASSTGRP="assetGrpName";
	public static final String REQ_PARAM_CUSID="customerId";
	public static final String REQ_PARAM_ASSTNOTES ="notes";
	public static final String REQ_PARAM_MP_NUMBER="mpNumber";
	public static final String REQ_PARAM_SAMPLERATE="sampleRate";
	public static final String REQ_PARAM_POST_SAMPLES="noOfPostSamples";
	public static final String REQ_PARAM_PLATFORM="platform";
	public static final String REQ_PARAM_ROADINTIAL="roadIntial";
	public static final String REQ_PARAM_ROAD_NUMBER="roadNumber";
	public static final String FLAG = "flag";
	public static final String STATUS_OPEN = "Open";
	public static final String URGENCY_R = "R";
	public static final String URGENCY_Y = "Y";
	public static final String URGENCY_W = "W";
	public static final String URGENCY_NONE = "None";
	public static final String ASST_OVW_ATTRIBUTE = "assetOverview";
	public static final String DATE_FORMAT_AMPM = "MM/dd/yyyy hh:mm:ss a";
	public static final String DATE_FORMAT_24HRS = "MM/dd/yyyy HH:mm:ss";
	public static final String DATE_FORMAT_DAY = "MM/dd/yyyy";
	public static final String MCS_DATE_FORMAT ="yyyy-MM-dd HH:mm:ss";
	public static final String UTF_8="UTF-8";
	public static final String DIESELDOC = "DieselDoc";
	public static final String DEFAULT_LOOKBACK = "defaultlookbackDays";
	public static final String REQ_METRICS_PRIVILEGE_FLAG ="metricsPrivilegeFlag";
	
	//AssetOverview Constants
	public static final String STATUS_CLOSED = "Closed";
	public static final String QUEUE_WORK = "Work";
	public static final String QUEUE_DELIVERED = "Delivered";
	public static final String MENU = "menu";
	public static final String CASE1 = "case";
	public static final String NO = "NO";
	public static final String MESSAGE = "message";
	public static final String RX_STATUS_RED = "Red";
	public static final String RX_STATUS_WHITE = "White";

	public static final String USER_LANGUAGE = "userLanguage";
	public static final String DATA_SCREEN_DEFAULT_NO_OF_DAYS = "DATA_SCREEN_DEFAULT_NO_OF_DAYS";
	public static final String PP_NOTIFICATION_LOOKBACK_DAYS = "PP_NOTIFICATION_LOOKBACK_DAYS";
	public static final String CALENDER_MINUTES = "minutes";
	public static final String CALENDER = "calendar";
	public static final String LOWER_HEATMAP = "^L";
	public static final String HIGER_HEATMAP = "^H";
	public static final char CARAT = '^';
	public static final String JDPAD_RADIO = "JDPADRadio";
	public static final String STR_FAULTS = "Faults";
	public static final String STR_JDPAD = "JDPAD";


	//Visualization Constants
	public static final String VISUALIZATION_MP_VALUE_ONE="MP_1501";
	public static final String VISUALIZATION_MP_VALUE_TWO="MP_1535";
	public static final String VISUALIZATION_MP_VALUE_THREE="MP_1511";
	public static final String VISUALIZATION_MP_VALUE_FOUR="MP_1531";
	public static final String VISUALIZATION_MP_VALUE_FIVE="MP_1506";
	public static final String ATTR_BR="<BR>";
	public static final String ATTR_EMPTY=" ";
	public static final String OPENCASES_VALUE_UNASSIGNED="Unassigned";
	public static final String OPENCASES_WS_VALUE="DWQ";
	
	public static final String VISUALIZATION_HEADER_WATER="Water<BR>Pressure";
	public static final String VISUALIZATION_HEADER_CRANKCASE="Crankcase<BR>Air<BR>Pressure";
	public static final String VISUALIZATION_HEADER_LUBE="Lube<BR>Oil<BR>Pressure";
	public static final String VISUALIZATION_HEADER_MANIFOLD="Manifold<BR>Air<BR>Pressure";
	public static final String VISUALIZATION_HEADER_FUEL="Fuel<BR>Pressure";
	
	public static final String FUEL_GRAPH="Fuel Graph";
	public static final String TBC_GRAPH="TBC Graph";
	public static final String LOCO_LOAD_GRAPH="Loco Load Graph";
	public static final String AIR_COMPRESSOR_GRAPH="Air Compressor Graph";
	public static final String BATTERY_CHARGER_CURRENT="Battery Charger Current";
	public static final String PRESSURE_GRAPH="Pressure Graph";
	public static final String PRETURBINE_TEMP_GRAPH="Preturbine Temp Graph";
	public static final String TEMPERATURE_GRAPH="Temperature Graph";
	public static final String GRID_BLOWER_SPEEDS="Grid Blower Speeds";
	public static final String RAD_FAN_GRAPH="Rad Fan Graph";
	public static final String HP_LIMITING="HP Limiting";
	
	public static final String MP_VALUES_FUEL_GRAPH_="MP_1055, MP_1056, MP_1057";
	public static final String MP_VALUES_TBC_GRAPH="MP_8005, MP_8006, MP_8007";
	public static final String MP_VALUES_LOCO_LOAD_GRAPH="MP_1000, MP_1005, MP_1025";
	public static final String MP_VALUES_AIR_COMPRESSOR_GRAPH="MP_2053, MP_3000";
	public static final String MP_VALUES_BATTERY_CHARGER_CURRENT="MP_2002, MP_2202, MP_2211";
	public static final String MP_VALUES_PRESSURE_GRAPH="MP_1501, MP_1506, MP_1511, MP_1531, MP_1535";
	public static final String MP_VALUES_PRETURBINE_TEMP_GRAPH="MP_1525, MP_1526";
	public static final String MP_VALUES_TEMPERATURE_GRAPH="MP_1500, MP_1510, MP_0110, MP_1503, MP_1505, MP_1530";
	public static final String MP_VALUES_GRID_BLOWER_SPEEDS="MP_6301, MP_6302, MP_6303";
	public static final String MP_VALUES_RAD_FAN_GRAPH="MP_2055, MP_2056, MP_1500, MP_1503, MP_0110";
	public static final String MP_VALUES_HP_LIMITING="MP_1025, MP_1021, MP_1022, MP_1137, MP_1032";
	
	
	public static final String MP_VALUES_NOT_IN_QTR_1503="MP_1503";
	public static final String MP_VALUES_NOT_IN_QTR_1505="MP_1505";
	public static final String MP_VALUES_NOT_IN_QTR_1530="MP_1530";
	public static final String MP_VALUES_NOT_IN_QTR_6303="MP_6303";
	public static final String MP_VALUES_NOT_IN_QTR_2055="MP_2055";
	public static final String MP_VALUES_NOT_IN_QTR_2056="MP_2056";
	public static final String MP_VALUES_NOT_IN_QTR_1021="MP_1021";
	public static final String MP_VALUES_NOT_IN_QTR_1022="MP_1022";
	public static final String MP_VALUES_NOT_IN_QTR_1137="MP_1137";
	public static final String MP_VALUES_NOT_IN_QTR_1032="MP_1032";
	public static final String COMMA = ",";
	
	public static final String WATER_OUTLET_TEMP="Water Outlet Temp";
	public static final String OIL_OUTLET_TEMP="Oil Outlet Temp";
	public static final String FUEL_TEMP="Fuel Temp";
	public static final String GRID_BLOWER_3_SPEED="Grid Blower 3 Speed";
	public static final String RAD_FAN_1_HP="Rad Fan 1 HP";
	public static final String RAD_FAN_2_HP="Rad Fan 2 HP";
	public static final String WATER_OUT_TEMP="Water Out Temp";
	public static final String DELTA_T_MAX_HP="Delta T Max HP";
	public static final String PRETURB_MAX_HP="Preturb Max HP";
	public static final String ALTITUDE_MAX_HP="Altitude Max HP";
	public static final String ENG_TEMP_MAX_HP="Eng Temp Max HP";
	
	
	//OpenCases Constants
	public static final String OPENCASES_VO_LST="openCasesVOLst";
	public static final String OPENCASES_DROPDOWN="mapDropdown";
	
	//HeaderSearch Constants
	public static final String REQ_URI_HEADERSEARCH="/getSearchData";
	public static final String REQ_URI_HEADERSEARCH_ALL="/searchallresults";
	public static final String VIEW_ALLRESULT="searchallresults";
	public static final String HEADERSEARCH_VO_LST="headerSearchVOLst";
	public static final String HEADERSEARCH_SEARCH_STRING="searchString";
	public static final String HEADER_SEARCH_CASEID="caseID";
	public static final String HEADER_SEARCH_CASE_CONDITION="caseCondition";
	public static final String HEADER_SEARCH_LIKE_PARAM="like";
	public static final String HEADER_SEARCH_ASSET_LENGTH="assetLength";
	public static final String HEADER_SEARCH_CASE_LENGTH="caseLength";
	
	public static final String OPEN_BRACKET = "(";
	public static final String CLOSE_BRACKET = ")";
	public static final String D = "d";
	public static final String HRS = "hrs";
	public static final String MIN = "min";
	public static final String d = "d";
	public static final String hrs = "hrs";
	public static final String min = "min";
	
	
	public static final String ASSETCASE_OPENLIST = "assetOpenCases";
	public static final String ASSETCASE_DELIVEREDLIST = "assetDeliveredCases";
	public static final String ASSETCASE_CLOSEDLIST = "assetClosedCases";
	
	public static final String HEADER_SEARCH_ASSETS = "Assets";
	public static final String HEADER_SEARCH_CASES = "Cases";
	public static final String DATA_ROW_SIZE="responseLength";
	public static final String DATA_ASSET_LENGTH="assetLength";
	public static final String DATA_CASE_LENGTH="caseLength";
	public static final String CASE_RESPONSE="caseReponseLenght";
	public static final String CASE_RESPONSE_LENGTH="casesResponseLength";
	
	public static final String REQ_URI_MSGCENTERTAB = "";
	public static final String DATA_SCREEN_DROPDOWN="caseId";
	public static final int DATA_SCREEN_INDEX=0;
	public static final int DATA_SCREEN_COUNT=3;

	//SPRINT13- SSO Enable - Changes Start
	public static final String SSO_FLAG="ssoFlag"; 
	public static final String SSO_URL="ssourl";
	public static final String RMD_URL="rmdurl";
	public static final String SSO_URL_REDIRECT="https://stg.getransro.com/";
	public static final String SSO_UID = "uid";
	public static final String VIEW_SSOINDEX = "ssoindex";
	//SPRINT13- SSO Enable - Changes End

	
	//Added for Technician Cases & Rx Execution Screen - START
	public static final String SOLUTION_STATUS = "solutionStatus";
	public static final String SOLUTION_STATUS_VALUE = "Open";
	public static final String GET_RXEXEC_CASES="/getCases";
	public static final String RX_DELV_ID="rxDelvId";
	public static final String GET_RX_EXEC="/getSolutionExecutionDetails";
	public static final String RX_CASE_ID="rxCaseId";
	public static final String SAVE_RX_EXEC= "/saveCaseExecution";
	public static final String TECHNICIAN_CASES="getCases";
	public static final String GET_FLEETS = "/getFleets";
	public static final String VIEW_RX_EXEC_DETAIL="rxExecutionDetails";
	public static final String RXCASE_SUBMIT_FLAG="YES";
	public static final String EXPORT_RX_EXEC="/exportSolutionExecutionDetails";
	//Added for Technician Cases & Rx Execution Screen - END
	public static final String GET_KPIS="/getKPIs";
	public static final String VIEW_KPIS="kpi";
	public static final String RX_KPI_NAME="kpiName";
	
	// Tech Closed SubTabs Changes
	public static final String GET_RXEXEC_CLOSED_CASES="/getClosedRxCases"; 	
	public static final String TECHNICIAN_CLOSED_CASES="getClosedRxCases";
	public static final String RX_FILTER_URGENCY_TECHCASES_CLOSED_PRIVILEGE="RX_FILTER_URGENCY_TECHCASES_CLOSED_PRIVILEGE";
	public static final String RX_FILTER_ESTREPTIME_TECHCASES_CLOSED_PRIVILEGE="RX_FILTER_ESTREPTIME_TECHCASES_CLOSED_PRIVILEGE";
	public static final String RX_FILTER_FLEET_TECHCASES_CLOSED_PRIVILEGE="RX_FILTER_FLEET_TECHCASES_CLOSED_PRIVILEGE";
	public static final String RX_FILTER_MODEL_TECHCASES_CLOSED_PRIVILEGE="RX_FILTER_MODEL_TECHCASES_CLOSED_PRIVILEGE";
	public static final String RX_FILTER_TITLES_TECHNICIAN_CLOSED_PRIVILEGE="RX_FILTER_TITLES_TECHNICIAN_CLOSED_PRIVILEGE";
	public static final String FILTER_CASETYPE_TECHNICIAN_CLOSED_PRIVILEGE="FILTER_CASETYPE_TECHNICIAN_CLOSED_PRIVILEGE";	
	public static final String RX_FILTER_ACTIONABLE_RXTYPE_TECHCASES_CLOSED_PRIVILEGE="RX_FILTER_ACTIONABLE_RXTYPE_TECH_CLOSED_PRIVILEGE";
	public static final String DEFAULT_FILTER_TECHNICIAN_CLOSED_PRIVILEGE="DEFAULT_FILTER_TECHNICIAN_CLOSED_PRIVILEGE";
	public static final String RX_FILTER_LOOKBACK_DAYS_TECHCASES_CLOSED_PRIVILEGE="RX_FILTER_LOOKBACK_DAYS_TECHCASES_CLOSED_PRIVILEGE";
	public static final String RX_FILTER_LOOKBACK_DAYS="isRxFilterLookBackDays";
	public static final String RX_LOOKBACK_DAYS="LOOKBACKDAYS";
	public static final String TECHNICIAN_CLOSEDRX_LOOKBACK_DAYS_DEFAULT ="TECHNICIAN_CLOSEDRX_LOOKBACK_DAYS_DEFAULT";
	public static final String CLOSED_RX_TAB = "CLOSED_RX_TAB";
	public static final String GET_NO_OF_DAYS = "/getNoOfDays";
	public static final String TECHNICIAN_CLOSED_RX_LOOKBACK_LIST_NAME = "TECHNICIAN_CLOSEDRX_LOOKBACK_DAYS";
	public static final String TECHNICIAN_CLOSED_RX_EXPORT_FILENAME="TechnicianClosedRxs.csv";
	//constants for fleet view save notes
	public static final String LOCO = "loco";
	public static final String REQ_URI_FLEET_SAVENOTES="/fleetSaveNotes";
	public static final String FLEET_NOTES_ERR="fleetViewSaveNotes.error.notes.empty";
	public static final String FLEET_DEFAULT_MSG="Compose note...";
	public static final String FLEET_NOTES_MESSAGE = "fleetNotesMessage";
	public static final String LOCOMOTIVE_NOTE = "Locomotive Note";
	/*
	 * Added for KPI Services
	 */
	public static final String WS_PARAM_KPINAME = "kpiname";
	public static final String WS_PARAM_DAYS = "days";
	public static final String IS_DATE_DIFF = "dateDiff";
	public static final String DEFAULT_KPI_NAME = "rxClosedByDelivered";
	public static final String NUMERIC_30_DAYS = "30";
	public static final String FLEET_VIEW_DEFAULT_NO_OF_DAYS = "FLEET_VIEW_DEFAULT_NO_OF_DAYS";
	public static final String WS_PARAM_NOTETYPE = "noteType";
	public static final String GENERIC_NOTE = "Generic Note";
	
	public static final String REQ_URI_FLEET_VIEW_TOOLTIP="/fleetViewToolTip";
	
	//Added for validation framework story
	public static final String USERPROFILE_VALIDATEROLE="validateRole";
	public static final String USERPROFILE_ERR8="userProfile.error.role.invalid";
	public static final String INVALID = "invalid";
	public static final String MAX_STICKYTAB = "maxNoOfStickyTabs";
	
	
	public static final String PP_ASSET_STATUS_LIST = "ppAssetStatusList";
	
	/**
	 * Added For PP Services
	 */
	public static final String VIEW_PP_MAP="/pinPointMap";
	public static final String REQ_URI_PP_ASSETS="/getPPAssets";
	public static final String RET_STR_PP_MAP="pinPointMap";
		public static final String TAKE_OWNERSHIP ="takeOwnership";
	public static final String  REOPNE_CASE ="reopenCase";
	public static final String ACCEPTED_CASE="AcceptedCase";
	public static final String VIEW_MPH="Mph";
	public static final String VIEW_KPH="kMph";
	public static final String VIEW_MILES="miles";
	public static final String VIEW_KILOMETERS="KMs";
	public static final String VIEW_GALLONS="Gallons";
	public static final String VIEW_LITRES="Litres";
	public static final String VIEW_FAHRENHEIT="Fahrenheit";
	public static final String VIEW_CENTIGRADE="Centigrade";
	public static final String VIEW_PSI="PSI";
	public static final String VIEW_PASCAL="Pascal";
	public static final String VIEW_KILOPASCAL="KiloPascal";
	public static final String VIEW_HP="HP";
	public static final String VIEW_KW="KW";
	public static final String VIEW_LBS="lbs";
	public static final String VIEW_KILONEWTON="KiloNewtons";
	public static final String VIEW_MMH2O="mmH2O";
	public static final String VIEW_HOURS="hours";
	public static final String VIEW_ON="ON";
	public static final String VIEW_OFF="OFF";
	public static final String VIEW_NA="N/A";
	public static final String VIEW_NA_ARZN="Center";
	public static final String VIEW_DECIMAL=".";
	public static final String VIEW_OF="of";
	public static final String VIEW_SHORT_LOCO="ShortHood Lead";
	public static final String VIEW_SHORT_LOCO_ARZN="Forward";
	public static final String VIEW_LONG_LOCO="LongHood Lead";
	public static final String VIEW_LONG_ARZN="Reverse";
	public static final String RPM=" RPM";

/**
	 * Added For takeOwnerShip
	 */
    public static final String ROW_VERSION="rowVersion";
	public static final int EXCEPTION_CODE_WHILE_CALLING_WEBSERVICES=500;
	public static final String EXCEPTION_OCCURED_WHILE_CALLING_WEBSERVICES="Exception occured while calling the Webservices";

	/*Added for dieseldoctor datascreen*/
	public static final String RMD_DD_LOOKUPVALUE="DATA_SET";
	public static final String RMD_DD_ROLENAME="DATASCREEN_ROLE_NAME";
	
	/*Added for SSO Story*/
	public static final String FORWARD_SLASH="://";
	public static final String HTTPS="https";
	public static final String ROLES_FOR_SOLUTION = "solutionRoles";
	
	public static final String CASE_DATASCREEN_FLAG="CASE_DATASCREEN_FLAG";
	public static final String DIESELDOCTOR="asset.label.dieselDoctor";
	public static final String DIESELDOCTOR_ROLENAME="roleNameDD";
	public static final String ASSET_OVW_COMPONENT="asstOvwComponent";
	public static final String USER_MGMT_ADD_COMPONENT="userMgmtAddComp";
	public static final String USER_MGMT_EDIT_COMPONENT="userMgmtEditComp";
	public static final String USERMANAGEMENT_ADDUSER="USERMANAGEMENT_ADDUSER";
	public static final String USERMANAGEMENT_EDITUSER="USERMANAGEMENT_EDITUSER";
	public static final String USERMANAGEMENT_DELETEUSER="USERMANAGEMENT_DELETEUSER";
	public static final String ASSET_OVW_ADMIN_COMPONENT="asstOvwAdmComponent";
	public static final String ASSET_FAULT="/assetFault";
	public static final String ASSET_FAULT_NEW="/assetFaultNew";
	public static final String ASSET_FAULT_POPOUT="/assetFaultPopout";
	public static final String  CASE_ID_LST="caseIdLst";
	//Added for Asset Overview Last Fault story
	public static final String ASSET_OVW_LST_FAULT="asstOvwCompLastFault";

	/* Added for CreateCase Story */
	public static final String REQ_URI_GETSOLSTAT="/getSolStatus";
	public static final String REQ_URI_GETSOLURG="/getSolUrgencyOfRepair";
	public static final String REQ_URI_GETSOLEST="/getSolEstRepairTime";
	public static final String REQ_URI_GETSOLDETAIL="/getSolDetails";
	public static final String REQ_URI_CREATECASE="/createCases";
	public static final String REQ_URI_CREATECASEWITHRX="/massApplyRx";
	public static final String REQ_URI_GETSOLTITLES="/getSolTitles";
	public static final String REQ_URI_GETSOLSEACHRES="/getSolSearchResults";
	public static final String REQ_URI_GETSOLASSETNUM="/getAssetNumbers";
	public static final String REQ_URI_GETSOLASSETNUM_UNITRENUM="/getAssetNumbersForUnitRenum";
	public static final String REQ_URI_GETCASESUTOMERS="/getCaseCustomers";
	public static final String REQ_URI_GETCASEASSTGROUP="/getCaseAssetGroups";
	public static final String CREATECASE_SOLN_BEAN="objSolBean";
	public static final String SOLNSEARCHRESULTS="SolSearchResults";
	public static final String REQ_PARAM_SOLNSFORMVAL="solSearchFormValues";
	public static final String SOLNTITLE="title";
	public static final String CREATCASE_INVALID="invalid";
	public static final String CREATCASE_FORMVALUES="formValues";
	public static final String CREATCASE_ASSTGRP="assetGroup";
	public static final String CREATCASE_RECOMNOTES="recomNotes";
	public static final String CREATCASE_ESTRPRTIME="solEstRepairTime";
	public static final String CREATCASE_SOLNURGENCY="solUrgency";
	public static final String CREATCASE_SOLNID="solutionId";
	public static final String CREATCASE_RXDELSTATUS="RX_DELIVERY_STATUS";
	public static final String CREATCASE_URGOFREPAIR="Urgency of Repair";
	public static final String CREATCASE_ESTTIMEREPAIR="Estimated Time To Repair";
	public static final String CREATCASE_WSPARAM_URGENCY="urgency";
	public static final String CREATCASE_WSPARAM_ESTREPAIR="estRepair";
	public static final String CREATCASE_FIELDREQ="Field Request";
	public static final String CREATCASE_INFORMATIONAL="Informational";
	public static final String CREATCASE_WORK="Work";
	public static final String CREATCASE_HIGH="High";
	public static final String PRIVILEGE_COMPONENT="COMPONENT";
	public static final String RULE="Rule ";
	public static final String GET_COLUMNS_AND_MODEL="/getColumnsAndModel";

	
	/**
	 * Added For Exception Handling  -- Start
	 */	
	public static final String FATAL_ERROR = "FATAL_ERROR";
	public static final String MAJOR_ERROR = "MAJOR_ERROR";
	public static final String MINOR_ERROR = "MINOR_ERROR";
	public static final String EXCEPTION_JSONPARSING = "EXCEPTION_JSONPARSING";
	public static final String EXCEPTION_JSONMAPPING = "EXCEPTION_JSONMAPPING";
	public static final String EXCEPTION_GENERAL = "EXCEPTION_GENERAL";
	public static final String EXCEPTION_DATAPROCESSING = "EXCEPTION_DATAPROCESSING";
	public static final String EXCEPTION_ILLEGAL_ARGUMENT = "EXCEPTION_ILLEGAL_ARGUMENT";
	/**
	 * Added For Exception Handling  -- End
	 */		
	public static final String CREATE_CASE_PRIVILEGES="CREATE_CASE_PRIVILEGES";
	public static final String CREATE_CASE_SOLN_PRIVILEGE="createCaseSoln";
	public static final String CREATE_CASE_DEFAULTNOTE="asset.overview.composeNotes";
	public static final String CREATE_CASE_BLNDELVFLAG = "blnDelvFlag";
	public static final String LETTER_Y = "Y";
	public static final String NOTIFICATION_PRIVILEGES="NOTIFICATION_PRIVILEGES";
	public static final String NOTIFICATION_PRIVILEGES_VAR="notification";
	//Added as part of link customer to profile story
	public static final String USERPROFILE_NOINPUT="noInput";
	public static final String USERPROFILE_NOINPUTERR="userProfile.error.input.invalid";
	public static final String USERPROFILE_ROLECUSTCHNG="roleCustChange";
	public static final String USERPROFILE_ROLECUSTPWDCHNG="roleCustPswdChange";
			
	public static final String PROFILE_DROPDOWN_PRIVILEGES="USERPROFILE_CUSTOMER";

	
	public static final String PROFILE_DROPDOWN_PRIVILEGES_VAR="profileDropdown";
	public static final String PROFILE_PASSWORD_PRIVILEGES="USERPROFILE_PASSWORD";
	public static final String PROFILE_PASSWORD_PRIVILEGES_VAR="profilePassword";
	public static final String PREFERENCE_DROPDOWN_PRIVILEGES="USERPREFERENCE_CUSTOMER";
	public static final String PREFERENCE_DROPDOWN_PRIVILEGES_VAR="preferenceCustomer";
	public static final String ALL_CUSTOMERS = "All";
	public static final String GET_DROPDOWN="/getDropdown";
	public static final String NO_RULES="No Rules";
	public static final String RESULTMAP="resultMap";
	public static final String  RXDELIVERED="rxDelivered";
	public static final String  RX_CLOSEDBY_URGENCY="rxClosedByUrgency";
	public static final String  RX_CLOSEDBY_TYPE="rxClosedByType";
	public static final String  RX_ACCURACY="rxAccuracy";
	public static final String  NO_TROUBLE_FOUND="noTroubleFound";
	public static final String  RESPONSE_TIME="responseTime";
	public static final String  TAKEOWNERSHIP="/takeOwnership";
	public static final String REOPEN_CASE="/reopenCase";
	public static final String TECHCASESBEAN="techCasesBean";
	public static final String SOLUTION_EXECUTION="solutionExecution";
	public static final String  USERNAME="userName";
	public static final String TIME_ZONE_VAL="timezoneval";
	public static final String LISTOFGRAPH="listOfGraph";
	public static final String LISTOFDB="listOfDB";
	public static final String GRAPH="graph";
	public static final String FLEET_R="R";
	public static final String FLEET_W="W";
	public static final String FLEET_B="B";
	public static final String OPEN="open";
	public static final String NOTEMPTY="noteEmpty";
	public static final String  RXTITLE= "rxTitle";
	public static final String  ERR_CASE_TYPE= "errCaseType";
	public static final String  ERR_FLEET= "errFleet";
	public static final String  ERR_CASEID= "errCaseID";
	public static final String  ERR_ASSETNUM= "errAssetNum";
	public static final String FLEET_VIEW_RESPONSE="fleetViewResponse";
	public static final String RXCASE_ID="rxcaseId";
	public static final String NUMBER_OF_DAYS="numberofDays";
	public static final String STATUS_TRUE="true";
	public static final String STRLANG="strLang";
	public static final String DROPDOWN_JSON="dropdownJson";
	public static final String DROPDOWN_DAYS="dropdownDays";
	public static final String DATASET="dataset";
	public static final String OWNER="owner";
	public static final String ESTMREPAIR_TIME="estmRepairTime";
	public static final String LOCOMOTIVE_IMPACT="locomotiveImpact";
	public static final String DELVDATE="delvDate";
	public static final String AGE="age";
	public static final String GRAPH_PARAMETER="graphParameter";
	public static final String SORT_ORDER = "SORT_BY";
	public static final String FETCH_HC = "fetchHc";
	public static final String EQUIPMENT_TYPE = "EQUIPMENT_TYPE";
	
	//Added for Create case security validations
	public static final String STATUS = "status";
	public static final String URGENCY ="urgencyRepair";
	public static final String ESTIMATED_REPAIR ="estimatedRepair";
	public static final String ASSETNUMBER= "assetNumber";
	public static final String CUSTOMERID ="customerId";
	public static final String ASSETGRP ="assetGroup";		
	public static final String REQ_URI_GET_MODELS_FOR_FILTERS = "/getModelsForFilter";

	public static final String VIEW_MAP ="/Map";
	public static final String GET_MAP_ASSETS ="/getMapAssets";
	public static final String RET_STR_MAP="map";
	public static final String REQ_URI_GETSOLASSETNUMR="/getAssetNumber";
	public static final String REQ_URI_GET_PP_ASSETNUMR="/getPPAssetNumbers";
	public static final String REQ_URI_GETCONTRYANDSTATES="/getCountryStates";
	public static final String ASSETNUM="assetNum";

	public static final String MAP_TOOLTIP_ASSET="MAP_TOOLTIP_ASSET";
	public static final String MAP_TOOLTIP_OPENRX="MAP_TOOLTIP_OPENRX";
	public static final String MAP_TOOLTIPASSET="mapTooltipAsset";
	public static final String MAP_TOOLTIPRX="mapTooltipRx";
	public static final String LEGEND_MAP="LEGEND_MAP";
	public static final String MAP_LEGEND="MAP_LEGEND";
	public static final String PP_MAP_LEGEND="PP_MAP_LEGEND";
	
	//Added for KPI Misc Tasks
	public static final String KPI_DEFAULT_NO_OF_DAYS = "KPIs_DEFAULT_NO_OF_DAYS";
	public static final String GENERAL_PARAM_USER_FNAME = "userFirstName";
	public static final String GENERAL_PARAM_USER_LNAME = "userLastName";
	public static final String SYMBOL_OR ="|";
	public static final String SINGLE_QTE = "'";
	public static final String SEMI_QOUTE_SYMBOL=",'";
	public static final String  TEXT_HTML="text/html; charset=UTF-8";
	public static final String APPL_PDF="application/pdf;charset=UTF-8";
	public static final String CONTENT="Content-Disposition";
	public static final String ATTACH_FILENAME="attachment;filename=";
	public static final String KPISERVICE="kpiServiceImpl";
	public static final String SOLUTION_EXECUTION_SERVICEIMPL="solutionExecutionServiceImpl";
	public static final String CACHE_TAB_THRESHOLD_LIMIT="CACHE_TAB_THRESHOLD_LIMIT";
	public static final String SESSION_TIMED_OUT="SESSION_TIMED_OUT";
	public static final String SSO_LOGOutPage="SSO_LOGOutPage";
	public static final String ASSET_RESPONSE_LENGTH ="assetResponseLength";
	public static final String NUMPATTERN ="^[0-9]+$";
	public static final String ALPHA_NUMERICPATTERN="^[A-Za-z0-9]+$";
	public static final String ALPHA_NUMERIC_HYPHEN_PATTERN="^[A-Za-z0-9-\\s]+$";
	public static final String  ALPHA_NUMERIC_UNDERSCORE_PATTERN="^[A-Za-z0-9-_\\s]+$";
	public static final String CHECK_CASE_PATTERN="^[A-Z]+$";
	public static final String MAIL_CHECK_PATTERN="^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z-]+(\\.[A-Za-z]+)*(\\.[A-Za-z]{2,})$";
	public static final String DATE_PATTERN="MM/dd/yyyy HH:mm:ss";
	public static final String FIELD_TYPE_PATTERN="\\.";
	public static final String PDF="pdf";
	public static final String AND_LT="&lt;";
	public static final String AND_GT="&gt;";
	public static final String AND_AMP="&amp;";
	public static final String AND_QUOT="&quot;";
	public static final String FIELD_NAME_PATTERN="^[A-Za-z0-9_-]+$";
	public static final String ALPHA_PATTERN="^[a-zA-z]+$";
	public static final String FROM_DATE_PATTERN="MM/dd/yyyy HH:mm:ss";
	public static final String RULE_TITLE_PATTERN="^[0-9a-zA-Z#()+--/.\\s]+$";
	public static final String PADDING_00="00";
	public static final String PADDING_0= "0";
	public static final String AND_HASH="&#";
	public static final String SYMBOL_SEMICOLON=";";
	public static final String SYMBOL_COMMA=",";
	public static final String DOUBLE_HYPHEN_PATTERN="--";
	public static final String SET_CHILD= "setChild";
	public static final String SET_PARENT= "setParent";
	public static final String SYMBOL_NEXT="\n";
	public static final String TRACKING_STATUS="TRACKING_STATUS";
	public static final String REQUEST="/request";
	public static final String FORM_SUBMIT_MESSAGE="Form submitted successfully! Tracking Id is ";
	public static final String DELETE_FORM="deleteFrom";
	public static final String CUSTOMER="customer";
	public static final String AND_EQUALS="&=";
	public static final String SYMBOL_AND="&";
	public static final String SYMBOL_CUST_ID="?customerID=";
	public static final String GETTESTER_TRACKINGS= "/getTesterTrackings";
	public static final String ARL_TESTER_RESULTS="arlTesterResults";
	public static final String TESTERVO="testerVO";
	public static final String GET_TRACKINGS="/getTrackings";
	public static final String FORMVALUES= "formValues";
	public static final String RULETESTER_TAB="RuleTesterTab";
	public static final String LST_TESTER_DETAILS="lstTesterDetails";
	public static final String TRACKING="Tracking ";
	public static final String GET_TESTER_PATTERN_DETAILS= "/getTesterPatternDetails";
	public static final String OPTION="Option";
	public static final String TRACKING_ID="trackingId";
	public static final String RULE_TITLE="ruleTitle";
	public static final String GET_RULE_TILE_ITEST="/getRuleTileItest";
	public static final String CREATED_BY="createdBy";
	public static final String GET_TRACKINGID_CREATOR="/getTrackingIdCreator";
	public static final String GET_TESTER_TRACKING_IDS="/getTesterTrackingIds";
	public static final String STR_TRACKING="strTracking";
	public static final String GET_TESTER_TRACKING_DETAILS="/getTesterTrackingDetails";
	public static final String TESTER_RESULTS="TesterResults";
	public static final String FILENAME="filename";
	public static final String RXNOTES="rxNotes";
	public static final String MODEL="model";
	public static final String RX_TYPE="rxType";
	public static final String FLEET="fleet";
	public static final String MODEL_ID="modelId";
	public static final String FLEET_ID="fleetId";
	public static final String ASSET_ID = "assetId";
	public static final String  CONFIG="config";
	public static final String UNIT_NUMBER="unitNumber";
	public static final String SYMBOL_HYPEN="-";
	public static final String LINE_SEPARATOR="line.separator";
	public static final String RULE_TESTER_REQUEST_TYPE="RuleTesterRequestType";
	public static final String RULE_TESTER_REQUEST="RuleTesterRequest";
	public static final String GETASST_MODEL ="getAsstModel";	
	//Added for Map Overview story
	public static final String MAP_RESPONSE="mapResponse";
	public static final String PIPE_SEPERATOR="|";

	public static final String RXEX_LOCATION="RXEX_LOCATION";
	public static final String RXEX_PRIVILEGE="RXEX_PRIVILEGES";
	
	public static final String RX_LOCATION_DROPDOWN_PRIVILEGES_VAR="rxLocationDropdown";
	public static final String RXEX_SUBMITION_PRIVILEGE="rxEXSubmition";
	public static final String CASES_REFRESH_TIME="CASES_REFRESH_TIME";
	public static final String TECHNICIAN_REFRESH_TIME="techRefreshTm";
	public static final String ASSET_DATASCREEN="assetDataScreen";
	public static final String ASSET_DATASCREEN_NEW="assetDataScreenNew";
	public static final String ASSET_DATASCREEN_POPOUT="assetDataScreenPopout";
	public static final String FOOTER_PRIVACY_PATH="FOOTER_PRIVACY_PATH";
	public static final String FOOTER_TERMS_PATH="FOOTER_TERMS_PATH";
	public static final String DEFAULT_TIMEZONE_VALUE="DEFAULT_TIMEZONE";
	public static final String DEFAULT_TIMEZONE="defaultTimezone";
	// code added for Role Based Header Search
	public static final String HEADERSEARCH_ASSETS="HEADERSEARCH_ASSET_PRIVILEGES";
	public static final String HEADERSEARCH_ASSETS_COMP="headerSearchAsset";
	public static final String HEADERSEARCH_CASES="HEADERSEARCH_CASES_PRIVILEGES";
	public static final String HEADERSEARCH_CASES_COMP="headerSearchCases";
	public static final String HEADERSEARCH_ALL="HEADERSEARCH_ALL_PRIVILEGES";
	public static final String HEADERSEARCH_ALL_COMP="headerSearchAll";
	public static final String RESULTS_STICKYTAB ="RESULTS_STICKYTAB";
	public static final String SSO_ENV="SSO_ENV";	
	public static final String NORMAL_LOGOUT="login";
	public static final String LOGOUT_URL="LOGOUT_URL";	
	public static final boolean TRUE=true;
	public static final String PAGE_TO_REFRESH="PAGE_TO_REFRESH";
	public static final String TECHNICIAN_CASES_VAL="TECHNICIAN_CASES";
	public static final String TECH_CASE_ID="techCaseId";
	public static final String ASSET_PRIVILEGE="asset_Privilege";
	public static final String  CASES_PRIVILEGE="cases_Privilege";
	public static final String CASES_ASSET_PRIVILEGE="cases_Asset_Privilege";
	public static final String GET_LATEST_CASES="getLatestComp";
	public static final String SPECIFY = "Specify";
	public static final String URL_PATTERN="hostName:portName";
	public static final String BEAN_ASSET_STATUS_HISTORY="assetStatusHistoryBean";
	public static final String BEAN_FLEET_VIEW="fleetViewBean";
	public static final String BEAN_ASSET="assetBean";
	public static final String BEAN_FAULT_DATA="objAssetFault";
	public static final String BEAN_OPEN_CASES="openCaseBean";
	public static final String SESSION_TIMEOUT_UNAUTHORIZED="UNAUTHORIZED";
	public static final String LOGOUTURI = "logout";
	public static final String UNDEFINED = "undefined";
	/*For Visualization hardcodings*/
	public static final String FUEL_DEMAND = "Fuel Demand";
	public static final String FUEL_VALUE = "Fuel Value";
	public static final String FUEL_LIMIT = "Fuel Limit";
	public static final String TMB_PHASE_A_CURRENT = "TMB Phase A Current";
	public static final String TMB_PHASE_B_CURRENT = "TMB Phase B Current";
	public static final String TMB_PHASE_C_CURRENT= "TMB Phase C Current";
	public static final String ENGINE_GROSS_HORSEPOWER = "Engine Gross Horsepower";
	public static final String ENGINE_SPEED = "Engine Speed";
	public static final String HORSEPOWER_AVAILABLE = "Horsepower Available";
	public static final String AIR_COMPRESSOR_HORSEPOWER = "Air Compressor Horsepower";
	public static final String MAIN_RESERVOIR_1_PRESSURE = "Main Reservoir 1 Pressure";
	public static final String AUX_ALTERNATOR_VOLTS_PER_HERTZ = "Aux Alternator Volts Per Hertz";
	public static final String BATTERY_VOLTAGE = "Battery Voltage";
	public static final String WATER_PRESSURE = "Water Pressure";
	public static final String LUBE_OIL_PRESSURE = "Lube Oil Pressure";
	public static final String MANIFOLD_AIR_PRESSURE = "Manifold Air Pressure";
	public static final String FUEL_PRESSURE = "Fuel Pressure";
	public static final String CRANKCASE_AIR_PRESSURE = "Crankcase Air Pressure";
	public static final String EXHAUST_TEMPERATURE_LEFT = "Exhaust Temperature Left";
	public static final String EXHAUST_TEMPERATURE_RIGHT = "Exhaust Temperature Right";
	public static final String WATER_INLET_TEMP = "Water Inlet Temp";
	public static final String MAN_AIR_TEMP = "Man Air Temp";
	public static final String AMBIENT_TEMPERATURE = "Ambient Temperature";
	public static final String GRID_BLOWER_1_SPEED = "Grid Blower 1 Speed";
	public static final String GRID_BLOWER_2_SPEED = "Grid Blower 2 Speed";
	
	public static final String MP_2211 = "MP_2211";
	public static final String MP_1055 = "MP_1055";
	public static final String MP_1056 = "MP_1056";
	public static final String MP_1057 = "MP_1057";
	public static final String MP_8005 = "MP_8005";
	public static final String MP_8006 = "MP_8006";
	public static final String MP_8007 = "MP_8007";
	public static final String MP_1000 = "MP_1000";
	public static final String MP_1005 = "MP_1005";
	public static final String MP_1025 = "MP_1025";
	public static final String MP_2053 = "MP_2053";
	public static final String MP_3000 = "MP_3000";
	public static final String MP_2002 = "MP_2002";
	public static final String MP_2202 = "MP_2202";
	public static final String MP_1501 = "MP_1501";
	public static final String MP_1506 = "MP_1506";
	public static final String MP_1511 = "MP_1511";
	public static final String MP_1531 = "MP_1531";
	public static final String MP_1535 = "MP_1535";
	public static final String MP_1525 = "MP_1525";
	public static final String MP_1526 = "MP_1526";
	public static final String MP_1500 = "MP_1500";
	public static final String MP_1510 = "MP_1510";
	public static final String MP_0110 = "MP_0110";
	public static final String MP_6301 = "MP_6301";
	public static final String MP_6302 = "MP_6302";
	public static final String OCCUR_DATE = "OCCUR_DATE";
	
	//YJ Change Start: Added for Data Screen VVF for limited customer parameters
	public static final String DS_VVF_LIMITED_CUST_PARAM = "DATASCREEN_VVF_LIMITED_CUST_MP";
	public static final String DATASCREEN_VVF_HIDE_FSS = "DATASCREEN_VVF_HIDE_FSS";
	
	public static final String DATASCREEN_VVF_HIDE_L3_FAULTS = "DATASCREEN_VVF_HIDE_L3_FAULTS";
	
	public static final String DS_VVF_LIMITED_CUST_DEFAULT_DATASET =  "Loco";
	//YJ Change Start: Added for Data Screen VVF for limited customer parameters

	public static final String LEGEND_MAP_SCREEN="LEGEND_MAP_SCREEN";
	public static final String LEGENDS="listOfLegends";
	public static final String SEGMENT_WINDOW="segmentWindow";
	
	//added to make timezone dropdown in preferences as configurable
	public static final String USERPREFERENCE_TIMEZONE ="USERPREFERENCE_TIMEZONE";
	public static final String PREFERENCE_TIMEZONE_PRIVILEGES="preferenceTimezone";
	//added to have new icon for assets having no open rx - start
	public static final String URGENCY_G = "G";
	//added to have new icon for assets having no open rx - end
	
	public static final String REQ_URI_USERMANAGEMENT = "/userManagement";
	public static final String VIEW_USERMANAGEMENT = "userManagement";
	
	public static final String ACCOUNT_STATUS_ENABLED = "1";	
	public static final String REQ_URI_SAVE_EDIT_USER = "/saveEditUserDetails";
	
	public static final String USER_MGMNT_LIST = "userList";
	public static final String USER_MGMNT_COMPONENT_BEAN = "userMgmntCompPrivBean";
	public static final String FIRSTNAME = "firstName";
	public static final String MIDDLENAME = "middleName";
	public static final String LASTNAME = "lastName";
	public static final String USER_ROLE = "userRole";
	public static final String USER_SEQID = "userSeqId";
	public static final String REQ_URI_GET_ALL_USER_ROLES = "/getAllRoles";
	public static final String REQ_URI_GET_USER_TYPE = "/getUserTypes";
	public static final String USER_ROLES = "userRoles";
	public static final String USER_STATUS = "userStatus";
	public static final String ROLE_CHANGE_FLAG = "roleChanged";
	public static final String USER_DEAFULT_ROLE = "defaultRole";
	
	
	public static final String REQ_URI_FLEET_FILTER="/getFleetFilters";
	public static final String FILTER_PARAM_URGENCY="urgency";
	public static final String FILTER_PARAM_EST_REP_TIME="estRepairTime";
	public static final String FILTER_PARAM_RX_I="rxIds";
	
	public static final String RX_FILTER_URGENCY_PRIVILEGE="RX_FILTER_URGENCY_PRIVILEGE";
	public static final String RX_FILTER_ESTREPTIME_PRIVILEGE="RX_FILTER_ESTREPTIME_PRIVILEGE";
	public static final String RX_FILTER_URGENCY_MAP_PRIVILEGE="RX_FILTER_URGENCY_MAP_PRIVILEGE";
	public static final String RX_FILTER_ESTREPTIME_MAP_PRIVILEGE="RX_FILTER_ESTREPTIME_MAP_PRIVILEGE";
	public static final String RX_FILTER_RXTITLES_MAP_PRIVILEGE="RX_FILTER_TITLES_MAP_PRIVILEGE";
	public static final String RX_FILTER_FLEET_MAP_PRIVILEGE="RX_FILTER_FLEET_MAP_PRIVILEGE";
	public static final String RX_FILTER_MODEL_MAP_PRIVILEGE="RX_FILTER_MODEL_MAP_PRIVILEGE";
	public static final String RX_FILTER_URGENCY_FLEET_PRIVILEGE="RX_FILTER_URGENCY_FLEET_PRIVILEGE";
	public static final String RX_FILTER_ESTREPTIME_FLEET_PRIVILEGE="RX_FILTER_ESTREPTIME_FLEET_PRIVILEGE";
	public static final String RX_FILTER_RXTITLES_FLEET_PRIVILEGE="RX_FILTER_TITLES_FLEET_PRIVILEGE";
	public static final String RX_FILTER_FLEET_FLEET_PRIVILEGE="RX_FILTER_FLEET_FLEET_PRIVILEGE";
	public static final String RX_FILTER_MODEL_FLEET_PRIVILEGE="RX_FILTER_MODEL_FLEET_PRIVILEGE";
	
	public static final String RX_FILTER_URGENCY_TECHCASES_PRIVILEGE="RX_FILTER_URGENCY_TECHCASES_PRIVILEGE";
	public static final String RX_FILTER_ESTREPTIME_TECHCASES_PRIVILEGE="RX_FILTER_ESTREPTIME_TECHCASES_PRIVILEGE";
	public static final String RX_FILTER_FLEET_TECHCASES_PRIVILEGE="RX_FILTER_FLEET_TECHCASES_PRIVILEGE";
	public static final String RX_FILTER_MODEL_TECHCASES_PRIVILEGE="RX_FILTER_MODEL_TECHCASES_PRIVILEGE";

	public static final String RX_FILTER_TITLES_TECHNICIAN_PRIVILEGE="RX_FILTER_TITLES_TECHNICIAN_PRIVILEGE";
	public static final String FILTER_CASETYPE_TECHNICIAN_PRIVILEGE="FILTER_CASETYPE_TECHNICIAN_PRIVILEGE";
	public static final String FILTER_CASETYPE_FLEET_PRIVILEGE="FILTER_CASETYPE_FLEET_PRIVILEGE";
	public static final String FILTER_CASETYPE_MAP_PRIVILEGE="FILTER_CASETYPE_MAP_PRIVILEGE";
	public static final String RX_FILTER_URGENCY="isRxFilterUrgency";
	public static final String RX_FILTER_ESTREPTIME="isRxFilterEstRepTime";
	public static final String RX_FILTER_APPROVEDRXTITLES="isRxFilterApprovedRXTitles";
	public static final String RX_FILTER_FLEET="isRxFilterFleet";
	public static final String RX_FILTER_MODEL="isRxFilterModel";
	
	

	public static final String RX_FILTER_CASETYPE="isRxFilterCaseType";
	public static final String INVALID_URGENCY_ESTREPTIME="Ivalid Input for urgency or Estimated RepairTime or Rx Title";
	public static final String QUERY_PARAM_URGENCY="urgency";
	public static final String QUERY_PARAM_ESTREPTIME="estRepTime";
	public static final String QUERY_PARAM_RX_IDS="rxIds";
	public static final String QUERY_PARAM_TITLE="title";
	public static final String ID_CASE_TYPE="idCaseType";
	public static final String ID_MODEL="idModel";
	public static final String ID_FLEET="idFleet";
	public  static final String GET_TECHNICIAN_CASE_DETAILS="getTechnicianCaseDetails";
	public  static final String SPLIT_STRING_ARRAY_REGEX="\\s*,\\s*";
	public static final String REQ_URI_ASSETOVW_GETSERVICES="/getAssetService";
	
	public static final String APPROVED="Approved";
	
	public static final String FILTER_PARAM_RX_IDS="rxIds";
	
	public static final String APPLICTION_OCTET_STREAM="application/octet-stream";
	//Export To CSV
	public static final String DEGREE_SYMBOL="\u00B0";
    public static final String ENCODED_TYPE_ISO_8859_1="ISO-8859-1";
	public static final String ENCODED_TYPE_WINDOWS_1252="windows-1252";
	public static final String EXPORT_DATA_DATASCREEN="exportDataForDataScreen";
	public static final String RECAPTCHA="Recaptcha";
	public static final String RECAPTCHA_PRIVATE_KEY="6LfiANoSAAAAALf_iIZHvW756kUJYZ0Ex8jUYZgd";
	public static final String RECAPTCHA_CHALLENGE_FIELD="recaptcha_challenge_field";
	public static final String RECAPTCHA_RESPONSE_FIELD="recaptcha_response_field";
	public static final String CONTENT_TYPE="application/vnd.ms-excel";
	public static final String EXPORT_DATA_FLEETS="exportDataFleets";
	public static final String FLEETS_HEADER="FleetsHeader";
	//public static final String PROXY_HOST="3.87.248.6";
	//public static final String PROXY_PORTNUMBER="88";
	public static final String PROXY_HOST="PROXY_HOST";
    public static final String PROXY_PORTNUMBER="PROXY_PORTNUMBER";
	public static final String FLEETS_EXPORT_FILENAME="Fleets.csv";
	public static final String EXPORT_DATA_TECHNICIAN_CASES="exportDataTechnicianCases";
	public static final String TECHNICIAN_CASES_HEADER="TechnicianCasesHeader";
	public static final String TECHNICIAN_CLOSED_CASES_HEADER="TechnicianClosedCasesHeader";
	public static final String TECHNICIAN_OPEN_RX_EXPORT_FILENAME="TechnicianOpenRxs.csv";
	public static final String DATASCREEN_EXPORT_FILENAME="AssetDatas.csv";
	public static final String FRONT_SLASH="/";
	public static final String QUOTE = "\"";
	public static final String ESCAPED_QUOTE = "\"\"";
	private static final char[] CHARACTERS_THAT_MUST_BE_QUOTED = { ',', '"', '\n' };
	
	
	//added to make Language & role dropdown in preferences as configurable - Start
	public static final String USERPREFERENCE_LANGUAGE ="USERPREFERENCE_LANGUAGE";
	public static final String PREFERENCE_LANGUAGE_PRIVILEGES="preferenceLanguage";
	public static final String USERPREFERENCE_ROLE ="USERPREFERENCE_ROLE";
	public static final String PREFERENCE_ROLE_PRIVILEGES="preferenceRole";
	//added to make Language & role dropdown in preferences as configurable - end
	
	//Added for fav filter story starts
	public static final String QUERY_PARAM_FAV_FILTER="favFilter";
	public static final String QUERY_PARAM_FILTER_CHANGED="filterChanged";
	public static final String CASE_TYPE="caseType";
	public static final String STR_FALSE="false";
	public static final String STR_TRUE="true";
	public static final String TECHNICIAN="TECHNICIAN";
	public static final String URGENCY_FAV_FILTER="URGENCY";
	public static final String RX_TYPE_FAV_FILTER="RX_TYPE";
	public static final String TEXT="text";
	public static final String EST_REPAIR_TIME="EST_REPAIR_TIME";
	public static final String NUMBER="number";
	public static final String RX_TITLE="RX_TITLE";
	public static final String COMPONENT_CASE_TYPE="CASE_TYPE";
	public static final String COMPONENT_FLEET="FLEET";
	public static final String COMPONENT_MODEL="MODEL";
	public static final String MAP_OVERVIEW	="MAP_OVERVIEW";
	public static final String FLEETS="FLEETS";
	public static final String ASSETOVERVIEW_DATASCREEN="ASSETOVERVIEW_DATASCREEN";
	public static final String FILTER_NO_OF_DAYS = "NO_OF_DAYS";
	public static final String DEFAULT_FILTER_FLEET_PRIVILEGE="DEFAULT_FILTER_FLEET_PRIVILEGE";
	public static final String DEFAULT_FILTER_MAP_PRIVILEGE="DEFAULT_FILTER_MAP_PRIVILEGE";
	public static final String DEFAULT_FILTER_TECHNICIAN_PRIVILEGE="DEFAULT_FILTER_TECHNICIAN_PRIVILEGE";
	public static final String DEFAULT_FILTER_DATASCREEN_PRIVILEGE="DEFAULT_FILTER_DATASCREEN_PRIVILEGE";
	public static final String DEFAULT_FILTER="isDefaultFilter";
	public static final String STR_FILTER="_FILTER";
	public static final String FILTER_ID="filterId";	
	public static final String FAVORITE_FILTER="favoriteFilters";
	public static final String QUERY_PARAM_USR_ROLE_ID="usrRoleSeqId";
	public static final String SELECTED_TAB="selectedTab";
	public static final String KPI_NUM_DAYS="kpiNumDays";
	
	
	public static final String ALL_DATASET_DATASCREEN_PRIVILEGE="DATA_SCREEN_ALL_DATA_SETS";
	public static final String VEHICLE_DATASET_DATASCREEN_PRIVILEGE="DATA_SCREEN_VEHICLE_DATA_SET";
	public static final String DPEAB_DATASET_DATASCREEN_PRIVILEGE="DATA_SCREEN_DPEAB_DATA_SET";
	public static final String EQUIPMENT_DATASET_DATASCREEN_PRIVILEGE="DATA_SCREEN_EQUIPMENT_DATA_SET";
	public static final String DHMS_DATASET_DATASCREEN_PRIVILEGE="DATA_SCREEN_DHMS_DATA_SET";
	public static final String INCIDENT_DATASET_DATASCREEN_PRIVILEGE="DATA_SCREEN_INCIDENT_DATA_SET";
	public static final String RAPID_DATASET_DATASCREEN_PRIVILEGE="DATA_SCREEN_RAPID_DATA_SET";
	public static final String SCREEN_DROPDOWN_DATASCREEN = "screenDropDown";
	
	public static final String ALL_DATASET_DATASCREEN_REQ_ATTRIBUTE="allDataSetPrivilege";
	public static final String VEHICLE_DATASET_DATASCREEN_REQ_ATTRIBUTE="vehicleDataSetPrivilege";
	public static final String DPEAB_DATASET_DATASCREEN_REQ_ATTRIBUTE="dpeabDataSetPrivilege";
	public static final String EQUIP_DATASET_DATASCREEN_REQ_ATTRIBUTE="equipmentDataSetPrivilege";
	public static final String DHMS_DATASET_DATASCREEN_REQ_ATTRIBUTE="dhmsDataSetPrivilege";
	public static final String INCIDENT_DATASET_DATASCREEN_REQ_ATTRIBUTE="incidentDataSetPrivilege";
	public static final String RAPID_DATASET_DATASCREEN_REQ_ATTRIBUTE="rapidDataSetPrivilege";
	public static final String DPEAB_DATASET="dpeab";
	
	//Added for fav filter story ends	
	//Added for Actionable Rx
	public static final String RX_FILTER_ACTIONABLE_RXTYPE_FLEET_PRIVILEGE="RX_FILTER_ACTIONABLE_RXTYPE_FLEET_PRIVILEGE";
	public static final String RX_FILTER_ACTIONABLE_RXTYPE_MAP_PRIVILEGE="RX_FILTER_ACTIONABLE_RXTYPE_MAP_PRIVILEGE";
	public static final String RX_FILTER_ACTIONABLE_RXTYPE_TECHCASES_PRIVILEGE="RX_FILTER_ACTIONABLE_RXTYPE_TECHCASES_PRIVILEGE";
	public static final String RX_FILTER_ACTIONABLE_RXTYPE="isRxFilterActionableRxType";
	public static final String RX_GROUP_ID="rxGroupId";
	
	
	public static final String REQ_URI_GET_APPROVED_RX_TITLES="/getApprovedRXTitles";
	public static final String REQ_URI_GET_RX_TITLES_LITE="/getRxTitlesLite";
	public static final String COMPONENT_ACTIONABLE_TYPE="RX_ACTIONABLE_TYPE";
	public static final String RX_ACTIONABLE_TYPE="RX_TYPE";
	public static final String ID_ACTIONABLE_RXTYPE = "idActionableRxType";
	//adding for pagination
	public static final String IMINE_DEFAULT_RECORDS = "iMineDefaultRecords";
	public static final String IMINE_TABLE_DEFAULT_RECORDS = "IMINE_TABLE_DEFAULT_RECORDS";
	public static final String ITEST_DEFAULT_RECORDS = "iTestDefaultRecords";
	public static final String ITEST_TABLE_DEFAULT_RECORDS = "ITEST_TABLE_DEFAULT_RECORDS";
	public static final String FLEET_TABLE_DEFAULT_RECORDS = "FLEET_TABLE_DEFAULT_RECORDS";
	public static final String FLEET_DEFAULT_RECORDS = "fleetDefaultRecords";
	public static final String TECHNICIAN_TABLE_DEFAULT_RECORDS = "TECHNICIAN_TABLE_DEFAULT_RECORDS";
	public static final String TECHNICIAN_DEFAULT_RECORDS = "technicianDefaultRecords";
	public static final String CASELIST_TABLE_DEFAULT_RECORDS = "CASELIST_TABLE_DEFAULT_RECORDS";
	public static final String CASELIST_DEFAULT_RECORDS = "caseListDefaultRecords";
	public static final String ADMINISTRATOR_TABLE_DEFAULT_RECORDS = "ADMINISTRATOR_TABLE_DEFAULT_RECORDS";
	public static final String ADMINISTRATOR_DEFAULT_RECORDS = "adminDefaultRecords";
	public static final String ASSET_TABLE_DEFAULT_RECORDS = "ASSET_TABLE_DEFAULT_RECORDS";
	public static final String ASSET_DEFAULT_RECORDS = "assetDefaultRecords";
	public static final String CASES_TABLE_DEFAULT_RECORDS = "CASES_TABLE_DEFAULT_RECORDS";
	public static final String CASES_DEFAULT_RECORDS = "casesDefaultRecords";
	public static final String FIND_CASES_TABLE_DEFAULT_RECORDS = "FIND_CASES_TABLE_DEFAULT_RECORDS";
	public static final String ASSETCASES_TABLE_DEFAULT_RECORDS = "ASSETCASES_TABLE_DEFAULT_RECORDS";
	public static final String ASSETCASES_DEFAULT_RECORDS = "assetCasesDefaultRecords";
	public static final String CONTROLLER_CONFIG = "controllerConfig";
	public static final String AC6000 = "AC6000";
	public static final String ACCCA = "ACCCA";
	public static final String DCCCA = "DCCCA";
	public static final String AC = "AC";
	public static final String DC = "DC";
	public static final String PARAMETER_VALUES_HP = "NOTCH, ENG_SPEED, HP";
	public static final String HP = "Horse Power Graph";
	public static final String PARAMETER_VALUES_TEMPERATURE_GRAPH_AC_DC = "WATER_TEMP, OIL_TEMP, ENG_SPEED";
	public static final String NO_GRAPH_AVAILABLE = "No Graph Available";
	public static final String NOTCH = "NOTCH";
	public static final String NOTCH_VALUE = "Notch";
	public static final String ENG_SPEED = "ENG_SPEED";
	public static final String ENG_SPEED_VALUE = "Engine Speed";
	public static final String WATER_TEMP_VALUE = "Water Temperature";
	public static final String WATER_TEMP = "WATER_TEMP";
	public static final String OIL_TEMP_VALUE = "Oil Temperature";
	public static final String OIL_TEMP = "OIL_TEMP";
	public static final String HP_COLUMN = "HP";
	public static final String MAP_LAST_REFRESH_TIME = "MAP_LAST_REFRESH_TIME";
	public static final String MAP_LAST_REFRESH = "mapLastRefreshTime";
	public static final String DIESEL_DOCTOR = "Diesel Doctor";
	//MISC constants
	public static final String ASSETOVERVIEW_SERVICES = "ASSETOVERVIEW_SERVICES";
	public static final String ASSETOVERVIEW_CONFIGURATION = "ASSETOVERVIEW_CONFIGURATION";
	public static final String ASSETOVERVIEW_CONFIGURATION_PREV = "assetConfiguration";
	public static final String ASSETOVERVIEW_SERVICES_PREV = "assetServices";
	public static final String FLEET_REFRESH_TIME="FLEET_REFRESH_TIME";
	public static final String FLEET_REFRESH_TIME_VAL="fleetRefreshTime";
	public static final String AC_DC_VISUALIZATION_DATE_FORMAT = "MM/dd/yyyy hh:mm";
	public static final String CASE_FROM = "caseFrom";
	public static final String PAGE_NO = "pageNo";
	public static final String IS_HEALTH_CHECK = "isHealthCheck";
	public static final String CASE_CREATION = "Case Creation";
	public static final String APPENDED = "Appended";
	public static final String CASE_CREATION_TO_DATE = "Case Creation to date";
	public static final String CASE_CREATION_FLAG = "C";
	public static final String APPENDED_FLAG = "A";
	public static final String CASE_CREATION_TO_DATE_FLAG = "T";
	public static final String NOW_FLAG = "Y";
	public static final String UTILITY_MAP = "utilityMap";
	public static final String PRIVILEGE_UTILITY = "UTILITY";
	private static final String[] KM_RESOURCE_IDS={"NEWRULE_STICKYTAB","NEWRX_STICKYTAB","NEWIDISCOVER_STICKYTAB","NEWITEST_STICKYTAB","EDITRULE_STICKYTAB","EDITIDSCOVER_STICKYTAB","EDITITEST_STICKYTAB","EDITRX_STICKYTAB"};
	
	public static final String UTILITY="_UTILITY_";
	public static final String TIME_BASED_FILTER_MAP = "timeBasedFilterMap";
	public static final String DS_TIME_BASED_FILTER = "DS_TIME_BASED_FILTER";
	public static final String DATASCREEN_HEATMAP = "DATASCREEN_HEATMAP";
	public static final String STR_DAYS ="days";
	public static final String ROLE_NAME="roleName";
	public static final String CUST_ASSET_MAP="custAssets";
	
	public static final String  KPI_LABEL_COLOR_RED="kpi.label.color.red";
	public static final String  KPI_LABEL_COLOR_YELLOW="kpi.label.color.yellow";
	public static final String  KPI_LABEL_COLOR_WHITE="kpi.label.color.white";
	public static final String  KPI_LABEL_COLOR_BLUE="kpi.label.color.blue";
	public static final String  KPI_LABEL_REPAIRED="kpi.label.repaired";
	public static final String  KPI_LABEL_DEFFERED="kpi.label.deferred";
	public static final String  KPI_LABEL_NTF="kpi.label.ntf";
	public static final String  KPI_LABEL_COLOR_CONDITIONAL="kpi.label.color.conditional";
	public static final String  KPI_LABEL_COLOR_OIL="kpi.label.color.oil";
	
	public static final String  LETTER_R="R";
	public static final String  LETTER_B="B";
	public static final String  LETTER_W="W";
	public static final String  LETTER_C="C";
	public static final String  LETTER_O="O";
	public static final String  LETTER_G="G";
	
	public static final String  DEFFERED="Deferred";
	public static final String  REPAIRED="Repaired";
	public static final String  NTF="NTF";
	
	public static final String  TOAL_RX_DELIVERED_JSON="totalRxDeliveredJson";
	public static final String  TOTAL_CLOSED_URGENCY_JSON="totalClosedUrgencyJson";
	public static final String  TOTAL_CLOSED_TYPE_JSON="totalClosedTypeJson";
	public static final String  DELIVERED_RX_JSON="deliveredRxJson";
	public static final String  CLOSED_RX_JSON="closedRxJson";
	public static final String  TYPE_RX_JSON="typeRxJson";
	public static final String  KPIS="KPIS";
	
	public static final String  KPI_RX_DELIVERED="KPI_RX_DELIVERED";
	public static final String  KPI_RX_CLOSED_URGENCY="KPI_RX_CLOSED_URGENCY";
	public static final String  KPI_RX_CLOSED_TYPE="KPI_RX_CLOSED_TYPE";
	public static final String  KPI_RX_DELIVERED_ATTR="isRxDelivered";
	public static final String  KPI_RX_CLOSED_URGENCY_ATTR="isRXClosedUrgency";
	public static final String  KPI_RX_CLOSED_TYPE_ATTR="isRXClosedType";
	
	public static final String  KPI_RX_ACCURACY="KPI_RX_ACCURACY";
	public static final String  KPI_NTF="KPI_NTF";
	public static final String  KPI_RESPONSE_TIME="KPI_RESPONSE_TIME";
	public static final String  KPI_RX_ACCURACY_ATTR="isRxAccuracy";
	public static final String  KPI_NTF_ATTR="isNTF";
	public static final String  KPI_RESPONSE_TIME_ATTR="isResponseTime";
	
	public static final String  FOUR_WEEK_JSON="fourWeekJson";
	public static final String  PREVIOUS_QUARTER_JSON="previousQtrJson";
	public static final String  YEAR_TO_DATE_JSON="yearToDateJson";
	
	public static final String  RX_ACCURACY_JSON="rxAccuracyJson";
	public static final String  NTF_JSON="ntfJson";
	public static final String  RESPONSE_TIME_JSON="responseTimeJson";
		
	public static final String  KPI_LIST="kpiList";
	public static final String  KPI_CUSTOMER_INFO="kpiCustInfo";
	public static final String  KPI_RXACCURACY_NODATA="rxAccuracyNodata";
	public static final String  KPI_NTF_NODATA="ntfNodata";
	public static final String  KPI_RESPONSETIME_NODATA="responseTimeNodata";
	
	private static final Object[][] MONTHLY_RECORDS_ACC= {{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0}};
	private static final Object[][] MONTHLY_RECORDS_NTF= {{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0}};
	private static final Object[][] MONTHLY_RECORDS_RES= {{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0},{"",0}};
	
	
	public static final String DECIMAL_STRING="##.##";
	public static final String LAST_UPDATED_DATE_JSON = "lastUpdatedDateJson";
	public static final String VERSION_NUMBER = "VERSION_NUMBER";

	public static final String VIEW_PROXIMITY_PAGE = "/getPPProximityPage";
	public static final String VIEW_NOTIFICATIONS_PAGE = "/getPPNotificationsPage";
	public static final String VIEW_IDLEREPORT_PAGE = "/getPPIdleReportPage";
	public static final String PP_PROXIMITY = "ppProximity";
	public static final String PP_NOTIFICATIONS = "ppNotifications";
	public static final String PP_IDLE_REPORT = "ppIdleReport";
	public static final String COUNTRY_CODE = "countryCode";
	public static final String STATE_CODE = "stateCode";
	public static final String GET_PP_CITIES = "/getPPCities";
	public static final String GET_ALL_CUSTOMER = "/getAllCustomers";
	public static final String GET_PP_COUNTRYANDSTATES = "/getPPCountryStates";
	public static final String GET_PP_PROXIMITY_DETAILS = "/getPPProximityDetails";
	public static final String CITY_NAME = "cityName";
	public static final String GPS_LAT = "gpsLat";
	public static final String GPS_LON = "gpsLon";
	public static final String RANGE_IN_MILES = "rangeInMiles";
	public static final String CITY_ERROR = "cityError";
	public static final String RANGE_ERROR = "rangeError";
	public static final String CITY_COMBINATION_ERROR = "invalid Combination";
	public static final String SPECIAL_CHARACTER_FOUND = "invalid Character";
	public static final String ONLY_SPECIAL_CHARACTER_FOUND = "special Character";
	public static final String ERROR_LENGTH = "invalid Length";
	public static final String ERROR_REQUIRED = "required";
	public static final String RANGE_NON_INTEGER = "invalid Character";
	public static final String RANGE_EXCEED_MAX = "invalid Max Range";
	public static final String MAX_RANGE_TITLE = "CWC_PP_PROX_MAX_RANGE";
	public static final String MAX_RANGE = "MAX_RANGE";

	// for notification controller
	public static final String GET_ROAD_INITIALS = "/getRoadInitials";
	public static final String GET_ROAD_NUMBER = "/getRoadNumbers";
	public static final String ROAD_INITIAL = "roadInitial";
	public static final String GET_REGIONS = "/getRegions";
	public static final String GET_NOTIFICATION_LEVELS_NVALUES = "/notificationLevelsandValues";
	public static final String NOTIFICATION_LEVEL = "notificationLevel";
	public static final String NOTIFICATION_TYPE = "notificationType";
	public static final String GET_NOTIFICATION_SEARCH = "/getPPNotificationDetails";
	public static final String INACTIVE_NOTIFICATION = "includeInactiveNotification";
	public static final String REGION = "region";
	public static final String ROAD_NUMBER = "roadNumber";
	public static final String REQ_NOTIFICATION_LEVELS = "notificationLevels";
	public static final String PP_NOTIFICATIONBEAN = "notificationBean";
	public static final String PP_FROM_PREVOIUSDATE = "previousDate";
	public static final String PP_CURRENT_DATE = "currentDate";
	public static final String SERVICE_CODE = "serviceCode";
	public static final boolean SERVICE_CODE_VALUE = true;
	public static final boolean FALSE = false;
	public static final String TABLE_DISABLE_FLAG = "tableDisableFlag";
	public static final String ALL = "ALL";
	public static final String SELECT = "Select";
	
	public static final String GET_PP_IdLE_REGION = "/getPPIdleRegions";
	public static final String GET_PP_ELAPSEDTIME = "/getPPIdleElapsedTime";
	public static final String GET_PP_IDLEREPORT_TYPES = "/getPPIdleReportTypes";
	public static final String GET_PP_IDLEREPORT_SUMMARY = "/getPPIdleReportSummary";
	public static final String GET_PP_IDLEREPORT_DETAILS = "/getIdleReportDetails";
	public static final String IDLE_REPORT_LABEL_SUMMARY="Summary Report";
	public static final String IDLE_REPORT_LABEL_DETAILS="Detailed Report";
	public static final String PP_IDLE_TYPES = "PP_IDLE_TYPES";
	public static final String ELAPSEDTIME = "elapsedTime";
	public static final String ELAPSEDTIME_LIST_NAME ="Dwell_Idle_elapsed_time";

	public static final String REPORTTYPE = "reportType";
	public static final String ERROR_DATE_RANGE = "ERROR_DATE_RANGE";
	public static final String ERROR_DATE_RANGE_MSG = "Maximum lookback period for multiple road numbers is";
	public static final String ERROR_NEGATIVE_DATE_RANGE = "The From date is later than the To date";
	public static final String VALIDATION = "validation";
	public static final String ERROR_ASSET_NOT_INSTALLED = "ERROR_ASSET_NOT_INSTALLED";
	public static final String ERROR_ASSET_NOT_INSTALLED_MSG = "Asset is not intalled";
	public static final String ERROR_ASSET_SERVICE_DISABLED = "ERROR_ASSET_SERVICE_DISABLED";
	public static final String ERROR_ASSET_SERVICE_DISABLED_MSG = "Asset service disabeled";
	public static final String ERROR_TO_Date = "To date required";
	public static final String ERROR_TO_DATE = "To date should be a earlier date";
	public static final String ERROR_NOTIFICATION_LEVEL = "ERROR_NOTIFICATION_LEVEL";
	public static final String ERROR_NOTIFICATION_LEVEL_MSG = "Notification level is required";
	public static final String ERROR_ASSET_REQUIRED = "ERROR_ASSET_REQUIRED";
	public static final String ERROR_ASSET_REQUIRED_MSG = "Please enter a road number";
	public static final String ERROR_TO_DATE_FROM_DATE_MSG = "The From date is later than the To date";
	public static final Object PAGE_LOAD_FLAG = "N";
	public static final String SERVICE_ENABLED = "serviceEnabled";
	public static final String ENABLED = "Enabled";
	public static final String DISABLED = "Disabled";
	public static final Object DISPLAY_TABLE_FLAG = "Y";
	public static final String EMPTY_SPACE = " ";
	public static final String TILDA = "~";
	public static final String ERROR_ROAD_NUMBER = "ERROR_ROAD_NUMBER";
	public static final String ERROR_ROAD_NUMBER_MSG = "Road number only integers are allowed";
	public static final String LIST_NAME_VALUE = "PP_NOTIFICATION_LEVELS";
	public static final String ERROR_FROM_DATE = "From date required";
	public static final String ERROR_CUSTOMER_MSG = "Customer required";
	public static final String ERROR_CUSTOMER = "ERROR_CUSTOMER";
	public static final String ERROR_ROAD_NUMBER_PATTERN = "[^a-zA-Z0-9 ]";
    public static final String ERROR_ROAD_NUMBER_PATTERN_MSG = "Road Number no special characters";
	public static final String VIEW_ASSET_NOTIFICATION_PAGE = "/ppAssetNotificationHistory";
	public static final String PP_ASSET_NOTIFICATION = "ppAssetNotification";
	public static final String NULL_STRING = "NULL";
	public static final String MINUS_ONE_STRING = "-1";
	public static final String PP_OVERVIEW_LOOKBACK_DAYS ="PP_OVERVIEW_LOOKBACK_DAYS";
	public static final String GET_LOOKUP_VALUES ="/getSolutionLookUps";
	public static final String SELECT_MODEL_TYPE = "SELECT_MODEL_TYPE";
	public static final String SELECT_BY_OPTIONS = "SELECT_BY_OPTIONS";
	public static final String SEARCH_CONDITIONS = "SEARCH_CONDITIONS";
	public static final String REPAIR_TIME_MAP = "repairTimeMap";
	public static final String URGENCY_OF_REP_MAP = "urgencyOfRepMap";
	public static final String MODEL_TYPE_MAP = "modelTypeMap";
	public static final String SELECT_BY_MAP = "selectByMap";
	public static final String CONDITION_MAP = "conditionMap";
	public static final String CREATCASE_WSPARAM_CONDITION = "condition";
	public static final String CREATCASE_WSPARAM_SELECTBY = "selectBy";
	public static final String CREATCASE_WSPARAM_MODELTYPE ="model";
	public static final String CREATCASE_WSPARAM_SOLUTIONTYPE = "solutionType";
	public static final String CREATCASE_WSPARAM_VALUE = "solutionValue";
	public static final String CREATCASE_WSPARAM_TYPE = "solutionType";
	public static final String VALUE = "value";
	public static final String CASE_LIST_PRIVILEGE = "CASES";
	public static final String ASSET_CASES_PRIVILEGE = "SUB_TAB_ASSET_CASES";
	public static final String REQ_URI_GETCASETYPE="/getCaseTypeValues";
	public static final String CREATCASE_CASE_TYPE = "caseType";
	public static final String EOA_PROBLEM = "EOA Problem";
	public static final String ESTP_PROBLEM = "ESTP Problem";
	public static final String MANUVAL_SHUTDOWN = "Manual Shutdown";
	public static final String OIL_ANOMALY = "Oil Anomaly";
	public static final String CASETYPE_LIST = "RMDEquipment QNXEquipment LococamEquipment PinPointProblem SMPP";
	public static final String CHAR_C = "C";
	public static final String CHAR_0 = "O";
	public static final String CHAR_B = "B";
	public static final String CHAR_G = "G";
	public static final String CREATECASE_ERR_LIST = "EOA_3022 EOA_3023 EOA_3024 EOA_3025";
	public static final String COMMISSION = "Commission";
	public static final String URGENCY_WRYC = "W R Y C";
	public static final String URGENCY_WRY = "W R Y";
	public static final String ERR_FLAG = "E";
	public static final String SUCCESS_FLAG = "S";
	public static final String URGENCY_BG = "B G";
	public static final String CASE_TYPE_REQ = "CASE_TYPE_REQ";
	public static final String EOA_PROBLEM_ERR = "EOA_PROBLEM_ERR";
	public static final String ESTP_PROBLEM_ERR = "ESTP_PROBLEM_ERR";
	public static final String MANUVAL_SHUTDOWN_ERR = "MANUVAL_SHUTDOWN_ERR";
	public static final String OIL_ANOMALY_ERR = "OIL_ANOMALY_ERR";
	public static final String CASETYPE_LIST_ERR = "CASETYPE_LIST_ERR";
	public static final String COMMISSION_ERR="COMMISSION_ERR";
	public static final String SOLUTION_ID_REQ_ERR = "SOLUTION_ID_REQ_ERR";
	public static final String 	CASE_TYPE_REQ_ERR = "CASE_TYPE_REQ_ERR";
	public static final String CASETYPE_VALIDATION = "CASETYPE_VALIDATION";
	public static final String HYPHEN = "-";
	public static final String MP_PARMS="graphParmVal";
	public static final String MP_VALUE_HEADER="MP_VALUE_HEADER";
	public static final String NEGOTION_SYMBOL="~";
	public static final String ASSET_CASES_ADD_NOTES = "ASSET_CASES_ADD_NOTES";
	public static final String ASSET_CASES_NOTES = "isAssetCasesNotes";
	public static final String URGENCY_B = "B";
	//add RX
	public static final String ADDRX_SOLN_TITLE = "solutionTitle";
	public static final String ADDRX_SOLN_USER = "solutionUser";
	public static final String ADD_RX_TO_CASE = "/addRXToCase";
	public static final String ADDRX_CASE_ID = "caseId";
	public static final String DELIVER_RX_TO_CASE = "/deliverRXToCase";
	public static final String EXCEPTION_EOA_3027 = "EOA_3027";
	public static final String EXCEPTION_EOA_3031 = "EOA_3031";
	public static final String ASSETOVERVIEW_LASTSHOPDOWNLOAD = "ASSETOVERVIEW_LASTSHOPDOWNLOAD";
	public static final String ASSET_OVW_SHOP_LAST_DWNLD = "asstOvwShopLastDownld";
	public static final String RMD_NOTES="rmdNotesRX";
	public static final String FAULT_CODE="FAULT_CODE";
	public static final String KPI_RXDELIVERED_URGENCY_DEFAULT_LOOKBACK_DAYS = "KPI_RXDELIVERED_URGENCY_DEFAULT_LOOKBACK_DAYS";
	public static final String KPI_RXCLOSED_TYPE_DEFAULT_LOOKBACK_DAYS = "KPI_RXCLOSED_TYPE_DEFAULT_LOOKBACK_DAYS";
	public static final String KPI_RXCLOSED_URGENCY_DEFAULT_LOOKBACK_DAYS = "KPI_RXCLOSED_URGENCY_DEFAULT_LOOKBACK_DAYS";
	public static final String KPI_RX_ACCURACY_DEFAULT_LOOKBACK_DAYS = "KPI_RX_ACCURACY_DEFAULT_LOOKBACK_DAYS";
	public static final String KPI_NTF_DEFAULT_LOOKBACK_DAYS = "KPI_NTF_DEFAULT_LOOKBACK_DAYS";
	public static final String KPI_RESPONSE_TIME_DEFAULT_LOOKBACK_DAYS = "KPI_RESPONSE_TIME_DEFAULT_LOOKBACK_DAYS";
	public static final String KPI_RXDELIVERED_URGENCY_LOOKBACK_DAYS = "KPI_RXDELIVERED_URGENCY_LOOKBACK_DAYS";
	public static final String KPI_RXCLOSED_TYPE_LOOKBACK_DAYS = "KPI_RXCLOSED_TYPE_LOOKBACK_DAYS";
	public static final String KPI_RXCLOSED_URGENCY_LOOKBACK_DAYS = "KPI_RXCLOSED_URGENCY_LOOKBACK_DAYS";
	public static final String KPI_DEFAULT_LOOKBACK_DAYS = "KPI_DEFAULT_LOOKBACK_DAYS";
	public static final String KPI_NAME = "kpiName";
	public static final String GET_KPI_VALUES = "/getKpiValues";
	public static final String LAST_FAULT_FLAG = "isLastFault";
	public static final String KPI_LOOKBACK_DAYS = "KPI_LOOKBACK_DAYS";
	public static final String DEFAULT_NO_OF_DAYS_VISUALIZATION="DEFAULT_NO_OF_DAYS_VISUALIZATION";
	public static final String DATE_DIFF_GREATER="DATE_DIFF_GREATER";
	public static final String DATE_DIFF_LESSER="DATE_DIFF_LESSER";
	public static final String FROM_DATE_GREATER="FROM_DATE_GREATER";
	public static final String FROM_DATE_EMPTY="FROM_DATE_EMPTY";
	public static final String TO_DATE_EMPTY="TO_DATE_EMPTY";
	public static final String DATA_SCREEN_NO_OF_DAYS = "DATA_SCREEN_NO_OF_DAYS";
	public static final String DATA_SCREEN_NO_OF_DAYS_DROPDOWN = "noOfDaysDropdownValues";
	public static final String ROLE_MANAGEMENT="roleManagement";
	public static final String ADMINISTRATOR_ROLES_TABLE_DEFAULT_RECORDS="ADMINISTRATOR_ROLES_TABLE_DEFAULT_RECORDS";
	public static final String ADMINISTRATOR_ROLE_DEFAULT_RECORDS = "adminRoleDefaultRecords";
	public static final String GET_ALL_PRIVILEGES = "getAllPrivileges";
	public static final String ADD_ROLE = "addRole";
	public static final String ADD_COPY_ROLE = "addOrCopyRole";
	public static final String EDIT_ROLE = "editRole";
	public static final String ROLE_DESC = "roleDesc";
	public static final String PRIVILEGES = "privileges";
	public static final String LEVEL_1 = "1";
	public static final String IS_ROLE_CHANGED = "isRoleNameChanged";
	public static final String ROLE_TREE_DRAG_AND_DROP_PRIVILEGE = "ROLE_TREE_DRAG_AND_DROP_PRIVILEGE";
	public static final String ROLEMANAGEMENT_ADDROLE="ROLEMANAGEMENT_ADDROLE";
	public static final String ROLEMANAGEMENT_EDITROLE="ROLEMANAGEMENT_EDITROLE";
	public static final String ROLEMANAGEMENT_COPYROLE="ROLEMANAGEMENT_COPYROLE";
	public static final String IS_ROLEDESC_CHANGED = "isRoleDescChanged";
	
	public static final String COMPONENT_ADDROLE="addRoleComponent";
	public static final String COMPONENT_EDITROLE="editRoleComponent";
	public static final String COMPONENT_COPYROLE="copyRoleComponent";
	public static final String LIST_OF_ROLES="arlRolesVO";
	
	public static final String STR_Y = "Y";
	public static final String STR_N = "N";
	public static final String STICKY_TAB_TYPE = "stickytab";
	public static final String IS_LIMITED_PARAM = "isLimitedParam";
	public static final String IS_HIDE_L3 = "IS_HIDE_L3";
	public static final String DATA_SCREEN = "DATA_SCREEN";
	public static final String ALL_RECORDS = "ALL_RECORDS";
	public static final String ROLE_PRIVILEGE_CACHE = "RMDRolePrivilegeCache";
	public static final String DEFAULT_LANGUAGE = "defaultLanguage";
	public static final String USER_ID="userId";
	public static final String NEW_NOTIFICATION_TYPE="newNotificationType";
	public static final String DUPLICATE_ALERT_TYPE="duplicateAlertType";
	public static final String DEFAULT_CUSTOMER="defaultCustomer";
	public static final String REQ_URI_GETASSETDETAIL="/getAssetDetails";
	public static final String REQ_PARAM_ASSETFORMVAL="assetSearchFormValues";
	public static final String ASSTNUMFROM = "fromAssetNumber";
	public static final String ASSTNUMTO = "toAssetNumber";
	public static final String INVALID_SPECIAL_CHARACTER ="invalid Character";
	public static final String INVALID_LENGTH ="invalid length";
	public static final String CLOSE_CASE_LOOKBACK_DAYS = "90";
	public static final String ASSET_CASE_LOOKBACK_DAYS = "ASSET_CASE_LOOKBACK_DAYS";
    public static final String MASS_APPLY_RX_ASSET_LIMIT="MASS_APPLY_RX_ASSET_LIMIT";
	public static final String MASS_APPLY_RX_LIMIT="massApplyRxLimit";
	public static final String ASSET_NUMBER_LIMIT_ERR = "ASSET_NUMBER_LIMIT_ERR";
	public static final String CLOSE_CASE = "/closeCase";
	public static final String SCORERX_CLOSE_CASE = "/scoreCloseCase";
	public static final String SCORE_RX = "/scoreRx";
	public static final String GET_SCORING_LOOKUP = "/getlookupForRxScoring";
	public static final String MANUAL_FDBK_SCORE_RX_CODES = "MANUAL_FDBK_RX_SCORING_CODES";
	
	public static final String RX_FEEDBACK = "rxFeedBack";
	public static final String RX_FEEDBACK_CODE = "feedBackCode";
	public static final String EXCEPTION_RMD_205 = "RMD_205";
	public static final String EXCEPTION_RMD_206 = "RMD_206";
	public static final String EXCEPTION_RMD_209 = "RMD_209";
	public static final String FETCH_CURRENT_OWNERSHIP = "/fetchCurrentOwnership";
	public static final String EXCEPTION_RMD_203 = "RMD_203";
	public static final String SCORE_RX_FLAG = "scoreRx";
	public static final String NOTE_REQUIRED = "noteRequired";
	public static final String DWQ_CASES_REFRESH_TIME = "DWQ_CASES_REFRESH_TIME";
	public static final String MY_CASES_REFRESH_TIME = "MY_CASES_REFRESH_TIME";
	public static final String OPENCASE_REFRESH_TIME="dwqRefreshTm";
	public static final String REFRESH_TIME="refreshTime";
	public static final String TAKE_OWNERSHIP_RTU_FAILED_CODE = "RMD_208";
	//constants for save manual feedback
	public static final String SAVE_MANUAL_FEEDBACK ="/saveManualFeedback";
	public static final String EXCEPTION_RMD_204 = "RMD_204";
	public static final String EXCEPTION_RMD_207 = "RMD_207";
	public static final String EXCEPTION_RMD_211 = "RMD_211";
	public static final String EXCEPTION_RMD_212 = "RMD_212";
	public static final String NAME = "name";
	public static final String CLEAR_CACHE = "clearCache";
	public static final String CLEARED_CACHE = "Cleared Cache";
	public static final String CLEARING_FAILED = "Clearing Cache failed";
    public static final String EXCEPTION_SAVING_FEEDBACK = "EXCEPTION_SAVING_FEEDBACK";
    public static final int ONE_THOUSAND =1000;
    public static final int TWO_THOUSAND =2000;
    public static final String VALIDATION_ERROR = "VALIDATION_ERROR";
    
	public static final String EXT_URL_CHECK = "EXT_URL_CHECK";
	public static final String EXT_URL = "EXT_URL";
	public static final String EXT_TEXT = "EXT_TEXT";
	
	public static final String INT_URL_CHECK = "INT_URL_CHECK";
	public static final String INT_URL = "INT_URL";
	public static final String INT_TEXT = "INT_TEXT";
	/**
	 * Added as part of HealthCheck Requirement
	 */
	public static final String REQ_URI_HC_REQUEST_TYPE = "/getHCRequestType";
	public static final String REQ_URI_HC_MP_GROUPS = "/getAssetHCMPGroups";
	public static final String REQ_URI_HC_AVAILBABLE = "/IsHCAvailable";
	public static final String REQ_URI_HC_ASSET_TYPE = "/getHCAssetType";
	public static final String REQ_URI_HC_SUBMIT_REQUEST = "/submitHCRequest";
	public static final String HEALTHCHECK_REQUEST_TYPE_LIST = "OMD_MESSAGE_REQUEST_TYPE";
	public static final String SAMPLE_RATE = "sampleRate";
	public static final String NO_OF_POST_SAMPLES = "noOfPostSamples";	
	public static final String MP_NUMBERS = "mpNumbers";
	public static final String ASSET_TYPE = "assetType";
	public static final String HEALH_CHECK_SEND_MESSAGE_SERVICE_URL = "HC_MCS_SENDMESSAGE_URL";
	public static final String HC_CSX_SEND_MESSAGE_SERVICE_URL = "HC_CSX_MCS_SENDMESSAGE_URL";
	public static final String HEALH_CHECK_SEND_MESSAGE_SERVICE_USERNAME = "HC_MCS_SENDMESSAGE_USERNAME";
	public static final String HEALH_CHECK_SEND_MESSAGE_SERVICE_PASSWORD = "HC_MCS_SENDMESSAGE_PASSWORD";
	public static final String MP_NAME = "mpGroupName";
	public static final String PLATFORM = "platform";
	public static final String DEFAULT_PLATFORM="defaultPlatform";
	public static final String IS_HEALTH_CHECK_VO="healthCheck";
	public static final String MESSAGE_ID="messageId";
	
	/**
	 * Added as part of Unit Renumbering
	 */
	public static final String REQ_URI_UNIT_RENUMBER = "/getUnitRenumberingPage";
	public static final String VIEW_UNIT_RENUMBER = "unitRenumbering";
	public static final String UPDATE_UNIT_NUMBER = "/changeUnitNumber";
	public static final String UPDATE_UNIT_HEADER = "/updateUnitHeader";
	public static final String FROM_UNIT = "fromUnit";
	public static final String TO_UNIT = "toUnit";
	public static final String UNIT_CUSTOMER_ID = "customerId";
	public static final String UNIT_VEHICLE_HEADER = "vehicleHeader";
		/**
	 * Added as part of View Request History
	 */
	public static final String REQ_URI_VIEW_HC_REQUEST_HISTORY = "/viewHCRequestHistory";
	public static final String LOOKBACK_DAYS  = "lookbackDays";
	public static final String HEALH_CHECK_GET_MESSAGE_HISTORY_URL = "HC_MCS_GET_MESSAGE_HISTORY_URL";
	public static final String CSX_VALID_HOSTS = "CSX_VALID_HOSTS";
	public static final String MESSAGE_HISTORY_LIST = "messageHistList";
	public static final String VIEW_REQUEST_HISTORY = "viewHCRequestHistory";
	public static final String DEFAULT_REQUEST_HISTORY_LOOKBACK_DAYS = "DEFAULT_REQUEST_HISTORY_LOOKBACK_DAYS";
	public static final String GMT_TIMEZONE = "GMT";
	public static final String MP_MESSAGE_ID_03 = "03";
	public static final String MCS_NO_RECORD_FOUND ="MCS00003";
	public static final String IS_HC_ENABLED = "isHCEnabled";
	public static final String EXCEPTION_RMD_208 = "RMD_208";
	public static final String MODIFY = "modify";
	public static final String DELIVER = "deliver";
	public static final String REPLACE = "replace";
	public static final String REISSUE = "reissue";
	public static final String CM_ALIAS_NAME = "cmAliasName";
	public static final String NO_RECORD_FOUND="NO_RECORD_FOUND_EXCEPTION";
	
	public static final String EXCEPTION_RMD_210 = "RMD_210";
	public static final String EXCEPTION_RMD_213 = "RMD_213";
	public static final String EXCEPTION_RMD_214 = "RMD_214";
	//Added for GeofenceReport
	public static final String GEOFENCE_LOOKBACK_DAYS = "GEOZONE_LOOKBACK_DAYS";
	public static final String GEOFENCE_FROM_ROAD_NUMBER = "fromRoadNo";
	public static final String GEOFENCE_TO_ROAD_NUMBER = "toRoadNo";
	public static final String GEOFENCE_ROAD_RANGE = "roadRange";
	public static final String GEOFENCE_ROAD_RANGE_VALUES = "roadRangeValues";
	public static final String GEOFENCE_ROAD_RANGE_TABLE_DISABLE_FLAG= "roadRangeTableDisableFlag";
	public static final String ERROR_FROM_ROAD_NUMBER = "ERROR_FROM_ROAD_NUMBER";
	public static final String ERROR_FROM_ROAD_NUMBER_MSG = "FromRN input error";
	public static final String ERROR_TO_ROAD_NUMBER = "ERROR_FROM_ROAD_NUMBER";
	public static final String ERROR_TO_ROAD_NUMBER_MSG = "ToRN input error";	
	public static final String ERROR_TO_RN_REQUIRED = "ERROR_TO_RN_REQUIRED";
	public static final String ERROR_FROM_RN_REQUIRED = "ERROR_FROM_RN_REQUIRED";
	public static final String ERROR_TO_RN_REQUIRED_MSG = "To RoadNumber is required";
	public static final String ERROR_FROM_RN_REQUIRED_MSG = "From RoadNumber is required";	
	public static final String ERROR_TO_RN_FROM_RN = "ERROR_TO_RN_FROM_RN";
	public static final String ERROR_TO_RN_FROM_RN_MSG = "ToRN greater than FromRN";
	public static final String ERROR_ROAD_RANGE_REQUIRED = "ERROR_ROAD_RANGE_REQUIRED";
	public static final String ERROR_ROAD_RANGE_REQUIRED_MSG = "RoadRange required";
	public static final String VIEW_GEOFENCE_REPORT = "/getGeofenceReport";
	public static final String GEOFENCE_REPORT = "geofenceReport";
	public static final String GET_GEOFENCE_REPORT_DETAILS = "/getGeofenceReportDetails";
	public static final String FROM_ROAD_NUMBER = "fromRoadNumber";
	public static final String TO_ROAD_NUMBER = "toRoadNumber";
	public static final String EXPORT_GEOFENCE_REPORT="exportGeofenceReport";
	public static final String GEOFENCE_REPORT_HEADER="GeofenceReportHeader";
	public static final String GEOFENCE_REPORT_EXPORT_FILENAME="ATS_Geozone_Report";
	public static final String GEOFENCE_REPORT_EXPORT_FILE_EXTENTION=".csv";
	public static final String GEOFENCE_EXPORT_DATE_FORMAT ="MM-dd-yy";
	public static final String GEOFENCE ="GEOFENCE";
	public static final String GEOFENCE_ROAD_RANGE_FAV_FILTER="GEOFENCE_ROAD_RANGE";
	public static final String GEOFENCE_FROM_DATE_FAV_FILTER="GEOFENCE_FROM_DATE";
	public static final String GEOFENCE_TO_DATE_FAV_FILTER="GEOFENCE_TO_DATE";
	public static final String DEFAULT_FILTER_ATS_GEOFENCEREPORT_PRIVILEGE="DEFAULT_FILTER_ATS_GEOZONEREPORT_PRIVILEGE";
	public static final String GEOFENCE_ROAD_RANGE_LIST="GeofenceRoadRange";
	public static final String DATE_TIME="datetime";
	public static final String FLOWER_BRACKET="{}";
	
	public static final String REQ_URI_MANAGE_GEOFENCE = "/manageGeofence";
	public static final String MANAGE_GEOFENCE = "manageGeofence";
	public static final String GEOFENCE_MGMNT_LIST = "geofenceList";
	public static final String REQ_URI_SAVE_UPDATE_GEOFENCE = "/saveUpdateGeofenceDetails";
	public static final String REQ_URI_DELETE_GEOFENCE = "/deleteGeofenceDetails";
	public static final String GEOFENCE_NAME = "geofenceName";
	public static final String GEOFENCE_PROXIMITY_EVENT = "proxEvent";
	public static final String GEOFENCE_UPPER_LEFT_LAT = "leftLat";
	public static final String GEOFENCE_UPPER_LEFT_LONG = "leftLong";
	public static final String GEOFENCE_LOWER_RIGHT_LAT = "rightLat";
	public static final String GEOFENCE_LOWER_RIGHT_LONG = "rightLong";
	public static final String GEOFENCE_NOTES = "geofenceNotes";
	public static final String GEOFENCE_SEQ_ID = "geofenceSeqId";
	public static final String GEOFENCE_ACTION_TYPE = "actionType";
	public static final String GEOFENCE_GET_PROXIMITY_EVENTS = "/getPromimityEvents";
	public static final String GEOFENCE_PROXIMITY_EVENTS_LOOKBACK_LIST_NAME = "GEOZONE_PROXIMITY_EVENTS";
	public static final String ERROR_GEOFENCE_NAME_REQUIRED = "ERROR_GEOFENCE_NAME_REQUIRED";
	public static final String ERROR_GEOFENCE_NAME_INPUT = "ERROR_GEOFENCE_NAME_INPUT";
	public static final String ERROR_PROXIMITY_EVENT_REQUIRED = "ERROR_PROXIMITY_EVENT_REQUIRED";	
	public static final String ERROR_GPS_LEFT_LAT_REQUIRED = "ERROR_GPS_LEFT_LAT_REQUIRED";
	public static final String ERROR_GPS_LEFT_LONG_REQUIRED = "ERROR_GPS_LEFT_LONG_REQUIRED";
	public static final String ERROR_GPS_RIGHT_LAT_REQUIRED = "ERROR_GPS_RIGHT_LAT_REQUIRED";
	public static final String ERROR_GPS_RIGHT_LONG_REQUIRED = "ERROR_GPS_RIGHT_LONG_REQUIRED";	
	public static final String ERROR_GPS_LEFT_LAT = "ERROR_GPS_LEFT_LAT";
	public static final String ERROR_GPS_LEFT_LONG = "ERROR_GPS_LEFT_LONG";
	public static final String ERROR_GPS_RIGHT_LAT = "ERROR_GPS_RIGHT_LAT";
	public static final String ERROR_GPS_RIGHT_LONG = "ERROR_GPS_RIGHT_LONG";
	public static final String ERROR_GEOFENCE_NOTES_INPUT = "ERROR_GEOFENCE_NOTES_INPUT";
	public static final String ERROR_GEOFENCE_NOTES_INPUT_MSG = "notes special chars not allowed";	
	public static final String ERROR_GEOFENCE_NAME_REQUIRED_MSG = "Please enter a geozoneName";
	public static final String ERROR_PROXIMITY_EVENT_REQUIRED_MSG = "Please enter a proxEvent";
	public static final String ERROR_GPS_LEFT_LAT_REQUIRED_MSG = "Please enter a leftLat";
	public static final String ERROR_GPS_LEFT_LONG_REQUIRED_MSG = "Please enter a leftLong";
	public static final String ERROR_GPS_RIGHT_LAT_REQUIRED_MSG = "Please enter a rightLat";
	public static final String ERROR_GPS_RIGHT_LONG_REQUIRED_MSG= "Please enter a rightLong";	
	public static final String ERROR_GPS_LEFT_LAT_MSG = "leftLat input error";
	public static final String ERROR_GPS_LEFT_LONG_MSG = "leftLong input error";
	public static final String ERROR_GPS_RIGHT_LAT_MSG = "rightLat input error";
	public static final String ERROR_GPS_RIGHT_LONG_MSG = "rightLong input error";	
	public static final String ERROR_INVALID_GEOFENCE = "ERROR_INVALID_GEOFENCE";
	public static final String ERROR_INVALID_GEOFENCE_MSG = "invalid geozone";	
	public static final String ERROR_GEOFENCE_NAME_INPUT_MSG = "invalid character";
	public static final String EXPORT_GEOFENCE_DETAILS = "exportGeofenceDetails";
	public static final String MANAGE_GEOFENCE_HEADER="manageGeofenceHeader";
	public static final String MANAGE_GEOFENCE_DETAILS_EXPORT_FILENAME="ATS_Geozones.csv";
	public static final String GEOFENCE_PROXIMITY_CACHE = "geofence_master_proximityCache";
	public static final String REQ_URI_GEOFENCE_CUSTOMERS="/getGeofenceCustomers";
	
	public static final String RECOM_ID = "recomId";
	public static final String GET_CLOSE_OUT_REPAIR_CODE = "/getCloseOutRepairCodes";
	public static final String GET_CLOSE_OUT_REPAIRCODE = "GET_CLOSE_OUT_REPAIRCODE";
	public static final String GET_CASE_REPAIRCODE = "GET_CASE_REPAIRCODE";
	public static final String GET_CASE_REPAIR_CODE = "/getCaseRepairCodes";
	public static final String GET_REPAIR_CODE = "/getRepairCodes";
	public static final String MAXLENGTH = "maxlength";
	public static final String TRUE_STRING ="true";
	public static final String FALSE_STRING ="false";
	public static final String SEARCH_BY = "searchBy";
	public static final String GET_REPAIRCODE = "GET_REPAIRCODE";
	public static final String GET_SELECT_BY_LOOKUP = "/getlookupForSelectBy";
	public static final String REPAIR_CODE_SELECT_BY = "REP_CODE_SEARCH_TYPE";
	public static final String CURRENT_OWNER = "currentOwner";
	public static final String ADD_CASE_REPAIR_CODE = "/addRepairCode";
	public static final String REPAIRCODE_LIST = "repaircodeList";
	public static final String REMOVE_CASE_REPAIR_CODE = "/removeRepairCode";
	public static final String EXCEPTION_RMD_215 = "RMD_215";
	public static final String SCORE_RX_RTU_ERROR_MSG = "There was an error scoring the case. Please try again later";
	public static final String OMD_VISUALIZATION_SOURCE="OMD_VISUALIZATION_SOURCE";
	public static final String OMD_VISUALIZATION_SOURCE_TYPE="OMD_VISUALIZATION_SOURCE_TYPE";
	public static final String OMD_VISUALIZATION_LOOKBACK_DAYS="OMD_VISUALIZATION_LOOKBACK_DAYS";
	public static final String OMD_VISUALIZATION_SOURCE_TYPE_DEFAULT="OMD_VISUALIZATION_SOURCE_TYPE_DEFAULT";
	public static final String OMD_VISUALIZATION_SOURCE_DEFAULT="OMD_VISUALIZATION_SOURCE_DEFAULT";
	public static final String VISUALIZATION_SOURCE_DEFAULT="sourceDefault";
	public static final String VISUALIZATION_SOURCE_TYPE_DEFAULT="sourceTypeDefault";
	public static final String VISUALIZATION_SOURCE="source";
	public static final String VISUALIZATION_SOURCE_TYPE="sourceType";
	public static final String DATASOURCE = "dataSource";
	public static final String REQ_URI_GET_VISUALIZATION_GRAPHNAMES = "getGraphNames";
	public static final String VISUALIZATION_DEFAULT_NO_OF_DAYS="noOfDays";
	public static final String GRAPH_INVALID="GRAPH_INVALID";
		
	public static final String REQ_URI_GET_VISUALIZATION_SOURCE="/getVisualizationSource";
	public static final String REQ_URI_GET_VISUALIZATION_SOURCETYPE="/getVisualizationSourceType";
	public static final String OMD_VISUALIZATION_CONTROLLER_TYPE="OMD_VISUALIZATION_CONTROLLER_TYPE";
	public static final String REQ_URI_GET_VISUALIZATION_CONTROLLER_TYPE="/getControllerType";
	public static final String OMD_VISUALIZATION_CONTROLLER_TYPE_DEFAULT="OMD_VISUALIZATION_CONTROLLER_TYPE_DEFAULT";
	public static final String CONTROLLER_TYPE="controllerType";
	public static final String CONTROLLER_TYPE_DEFAULT="controllerTypeDefault";
	public static final String OMD_VISUALIZATION_LOOKBACK_DAYS_VALIDATION="OMD_VISUALIZATION_LOOKBACK_DAYS_VALIDATION";
	public static final String VISUALIZATION_DATE_DIFF_VALIDATION_DAYS="dateDiffValidation";
	public static final String IS_INTERNAL="isInternal";
	public static final String REQ_URI_VISUALIZATION_MPPARMNUM="/visualization/getMPParmNum";
	public static final String REQ_URI_VISUALIZATION_ROAD_INITIALS="/visualization/getRoadInitials";
	public static final String REQ_URI_VISUALIZATION_ROAD_NUMBERS="/visualization/getRoadNumbers";
	public static final String REQ_URI_GET_NOTCH_LOGICAL_OPERATOR="/visualization/getNotchLogicalOperator";
	public static final String OMD_LOGICAL_OPERATORS="OMD_LOGICAL_OPERATORS";
	public static final String SIMPLE_OPERATORS="SIMPLE OPERATORS";
	public static final String COMPLEX_OPERATORS="COMPLEX OPERATORS";
	public static final String OMD_VISUALIZATION_NOTCH_LIST="OMD_VISUALIZATION_NOTCH_LIST";
	public static final String REQ_URI_GET_VISUALIZATION_NOTCH_LIST="/visualization/getNotchList";
	public static final String REQ_URI_GET_LOGICAL_OPERATOR="/visualization/getLogicalOperators";
	public static final String REQ_URI_GET_LOCO_STATE="/visualization/getLocoState";
	public static final String OMD_VISUALIZATION_LOCO_STATE_LIST="OMD_VISUALIZATION_LOCO_STATE_LIST";
	
	
	public static final String OMD_VISUALIZATION_LOCO_STATE="locoState";
	public static final String OMD_VISUALIZATION_FAULT_CODE="faultCode";
	public static final String OMD_VISUALIZATION_HIDDEN_FAULT_CODE="hidddenfaultCode";
	public static final String OMD_VISUALIZATION_NOTCH_OP="notchOp";
	public static final String OMD_VISUALIZATION_NOTCH_VALUE="notchVal";
	public static final String OMD_VISUALIZATION_AMBIENT_TEMP_OP="ambientTmpOp";
	public static final String OMD_VISUALIZATION_AMBIENT_TEMP_VALUE1="ambientTmpVal1";
	public static final String OMD_VISUALIZATION_AMBIENT_TEMP_VALUE2="ambientTmpVal2";
	public static final String OMD_VISUALIZATION_ENGINE_GHP_VALUE1="engGHPVal1";
	public static final String OMD_VISUALIZATION_ENGINE_GHP_VALUE2="engGHPVal2";
	public static final String OMD_VISUALIZATION_ENGINE_GHP_OP="engGHPOp";
	public static final String OMD_VISUALIZATION_ENGINE_SPEED_VALUE1="engSpeedVal1";
	public static final String OMD_VISUALIZATION_ENGINE_SPEED_VALUE2="engSpeedVal2";
	public static final String OMD_VISUALIZATION_ENGINE_SPEED_OP="engSpeedOp";
	public static final String CCA="CCA";
	public static final String ECU="ECU";
	public static final String ENGINE_RECORDER="ENGINE_RECORDER";
	public static final String REQ_URI_GET_FAULT_CODES="visualization/getFaultCodes";
	public static final String SNAPSHOT="SNAPSHOT";
	public static final String ENGINERECORDER="ENGINE RECORDER";
	public static final String REQ_URI_GET_COMP_LOGICAL_OPERATOR="/visualization/getComplexLogicalOperators";
	public static final String AMB_TEMP_VALUE1_INVALID="AMB_TEMP_VALUE1_INVALID";
	public static final String AMB_TEMP_VALUE2_INVALID="AMB_TEMP_VALUE2_INVALID";
	public static final String ENG_GHP_VALUE1_INVALID="ENG_GHP_VALUE1_INVALID";
	public static final String ENG_GHP_VALUE2_INVALID="ENG_GHP_VALUE2_INVALID";
	public static final String ENG_SPEED_VALUE1_INVALID="ENG_SPEED_VALUE1_INVALID";
	public static final String ENG_SPEED_VALUE2_INVALID="ENG_SPEED_VALUE2_INVALID";
	public static final String NOTCH_VALUE_INVALID="NOTCH_VALUE_INVALID";
	public static final String OMD_VISUALIZATION_NOTCH_VAL="notchValue";
	public static final String OMD_VISUALIZATION_LOCOSTATE_VAL="locostateValue";
	public static final String HEALTHCHECK_PRIVILEGE = "REQUEST_HEALTH_CHECK_INTERNAL";
	public static final String NO_OF_SAMPLES = "noOfSamples";
	public static final String HEALH_CHECK_SAMPLE_RATE_LOOKUP = "OMD_HC_REQUEST_EXT_SAMPLERATE";
	public static final String HEALH_CHECK_NO_OF_SAMPLES_LOOKUP = "OMD_HC_REQUEST_EXT_POSTSAMPLES";
	public static final String GET_HC_LOOKUP="/getHCLookup";
	public static final String REQUEST_TYPE_HC = "requestTypeHC";
	public static final String REQ_PARAM_REQTYPE_HC="requestTypeHC";
	public static final String REQ_PARAM_ASSET_TYPE = "assetType";
	public static final String DEVICE_NAME = "deviceName";
	public static final String REQ_PARAM_DEVICE_NAME = "deviceName";
	public static final String ASSETOVERVIEW_REPLACE_NOTES = "ASSETOVERVIEW_REPLACE_NOTES";
	public static final String ASSET_OVERVIEW_NOTES_REPLACE_PRIV= "assetOverviewNotesReplace";
	public static final String REQ_PARAM_INPTYPE = "insertType";
	public static final String FLEET_NOTES_ERR_SPL_CHAR = "menu.label.fleet.notes";
    public static final String OMD_VISUALIZATION_RANGE_SELECTOR="OMD_VISUALIZATION_RANGE_SELECTOR";
	public static final String VISUALIZATION_RANGESELECTOR="rangeSelector";
	public static final String REQ_URI_GET_VISUALIZATION_RANGE_SELECTOR="/visualization/rangeSelector";
	public static final String CANNED_LABEL = "Canned";
	public static final String CUSTOM_LABEL = "Custom";
	public static final String CANNED_NOT_AVAILABLE = "Canned not available";
	public static final String FLEET_NOTES_ERR_SPL_MESG = "specialCharacter.error.msg";
	public static final String AMB_TEMP_VALUE1_INVALID_NON_INTEGER="AMB_TEMP_VALUE1_INVALID_NON_INTEGER";
	public static final String AMB_TEMP_VALUE2_INVALID_NON_INTEGER="AMB_TEMP_VALUE2_INVALID_NON_INTEGER";
	public static final String ENG_GHP_VALUE1_INVALID_NON_INTEGER="ENG_GHP_VALUE1_INVALID_NON_INTEGER";
	public static final String ENG_GHP_VALUE2_INVALID_NON_INTEGER="ENG_GHP_VALUE2_INVALID_NON_INTEGER";
	public static final String ENG_SPEED_VALUE1_INVALID_NON_INTEGER="ENG_SPEED_VALUE1_INVALID_NON_INTEGER";
	public static final String ENG_SPEED_VALUE2_INVALID_NON_INTEGER="ENG_SPEED_VALUE2_INVALID_NON_INTEGER";
	public static final String REQ_URI_VISUALIZATION_EVENT_DATA="/visualization/getVisualizationEventData";
	public static final String VISUALIZATION_EVENT_TYPES="VISUALIZATION_EVENT_TYPES";
	public static final String REQ_URI_VIEW_HC_REQUEST_HISTORY_DETAILS = "/viewHCRequestHistoryDetails";
	public static final String FUNCTION_SUCCESS="Success";
	public static final String FUNCTION_ERROR="Error";
	public static final String GET_MAP_REFRESH_DATE = "/getMapRefreshDate";
	public static final String REQ_URI_GET_VISUALIZATION_SOURCE_TYPE_CD="/getSourceTypeCode";
	public static final String OMD_VISUALIZATION_SOURCE_TYPE_CD="OMD_VISUALIZATION_SOURCE_TYPE_CD";
	public static final String OMD_VISUALIZATION_SOURCE_TYPE_CD_DEFAULT="OMD_VISUALIZATION_SOURCE_TYPE_CD_DEFAULT";
	public static final String SOURCE_TYPE_CD_DEFAULT="sourceTypeCodeDefault";
	public static final String SOURCE_TYPE_CD="sourceTypeCode";
	public static final String SOURCE_TYPE_CD_INVALID="SOURCE_TYPE_CD_INVALID";
	public static final String CONTROLLER_TYPE_CD_INVALID="CONTROLLER_TYPE_CD_INVALID";
	public static final String FAMILY="family";
	public static final String REQ_URI_VISUALIZATION_VIRTUAL_PARM_NUM="/visualization/getVizVirtualParameters";
	public static final String DATABASE = "database";
	public static final String OMD_VISUALIZATION_FAULT_CODE_DEFAULT="OMD_VISUALIZATION_FAULT_CODE_DEFAULT";
	public static final String OMD_VISUALIZATION_NOTCH_DEFAULT="OMD_VISUALIZATION_NOTCH_DEFAULT";
	public static final String OMD_VISUALIZATION_ENGINE_GHP_DEFAULT_SELECT="OMD_VISUALIZATION_ENGINE_GHP_DEFAULT_SELECT";
	public static final String OMD_VISUALIZATION_ENGINE_GHP_DEFAULT_VALUE1="OMD_VISUALIZATION_ENGINE_GHP_DEFAULT_VALUE1";	
	public static final String FAULT_CODE_DEFAULT="faultCodeDefault";
	public static final String NOTCH_DEFAULT="notchDefault";
	public static final String ENGINE_GHP_DEFAULT_SELECT="engineGHPDefaultSelect";
	public static final String ENGINE_GHP_DEFAULT_VALUE1="engineGHPDefaultVal1";
	public static final String SEARCH_TYPE_HEADER = "headerSearch";
	public static final String SEARCH_TYPE_HEADER_ALL = "headerSearchAll";
	public static final String REQ_URI_LIFE_STATISTICS = "/lifeStatistics";
	public static final String MAX_ASSET_LIFESTATISTICS_LOOKBACK_DAYS = "MAX_ASSET_LIFESTATISTICS_LOOKBACK_DAYS";
	public static final String DEFAULT_ASSET_LIFESTATISTICS_LOOKBACK_DAYS = "DEFAULT_ASSET_LIFESTATISTICS_LOOKBACK_DAYS";
	public static final String RESULT_LIFE_STATISTICS = "assetLifeStatisticsVO";
	public static final String LIFE_STATISTICS = "lifeStatistics";
	public static final String LIFE_STATISTICS_DEFAULT_RECORDS = "lifeStatisticsDefaultRecord";
	public static final String REQ_URI_LIFE_STATISTICS_DATA = "/assetlifeStatistics";
	public static final String LOOKBACK_DAYS_VALIDATION = "LOOKBACK_DAYS_VALIDATION";
	public static final String ERROR_DATE_RANGE_TO = "ERROR_DATE_RANGE_TO";
	public static final String ERROR_TO_DATE_EMPTY = "ERROR_TO_DATE_EMPTY";
	public static final String ERROR_FROM_DATE_EMPTY = "ERROR_FROM_DATE_EMPTY";
	public static final String LOOKBACK_DAYS_VALIDATION_MSG = "Maximum lookback period is ";
	public static final String DAYS = " days";
	public static final String EXPORT_ASSET_lIFE_STAT = "/exportAssetLifeStatistic";
	public static final String EXPORT_MY_CASE = "/exportMyCases";
	public static final String EXPORT_OPEN_CASE = "/exportOpenCases";
	public static final String LIFE_STAT_HEADER = "lifeStaistics";
	public static final String ASSET_LIFESTATISTICS_EXPORT_FILENAME = "assetLifeStatistics.csv";
	public static final String OPEN_CASES_HEADER = "openCasesHeader";
	public static final String MY_CASES_HEADER = "myCasesHeader";
	public static final String MY_CASES_EXPORT_FILENAME = "myCases.csv";
	public static final String OPEN_CASES_EXPORT_FILENAME = "openCases.csv";	
	public static final String EXPORT_ASSET_HISTORY = "/exportAssetHistory";
	public static final String ASSET_HISTORY_HEADER = "assetHistoryHeader";
	public static final String ASSET_HISTORY_HEADER_ARZN = "assetHistoryHeaderarzn";
	public static final String CUSTOMER_VALUE = "ARZN";
	public static final String ASSET_HISTORY_EXPORT_FILENAME = "assetHistory.csv";
	public static final String TIMEZONE_EASTERN ="US/Eastern";
	public static final String REQ_URI_VIZ_GET_ASSETS="/getVizAssets";
	public static final String CUSTOMER_NAME="customerName";
	public static final String USER_MANAGEMENT_EXPORT_FILENAME = "Users.csv";
	public static final String EXPORT_USERS = "/exportUsers";
	public static final String USER_MANAGEMENT_HEADER = "UserManagementHeader";
	public static final String ROLE_MANAGEMENT_EXPORT_FILENAME = "Roles.csv";
	public static final String EXPORT_ROLES = "/exportRoles";
	public static final String ROLE_MANAGEMENT_HEADER = "RoleManagementHeader";
	public static final String AT_IDLE_REPORT_EXPORT_FILENAME = "IdleReport.csv";
	public static final String EXPORT_IDLE_REPORT = "/exportIdleReport";
	public static final String AT_IDLE_REPORT_SUMMARY_TOTAL = "IdleReportSummaryTotalUnits";
	public static final String AT_IDLE_REPORT_SUMMARY_HEADER = "IdleReportSummaryHeader";
	public static final String AT_IDLE_REPORT_DETAILS_HEADER = "IdleReportDetailsHeader";
	public static final String AT_NOTIFICATION_EXPORT_FILENAME = "ATNotification.csv";
	public static final String EXPORT_AT_NOTIFICATION = "/exportATNotification";
	public static final String AT_NOTIFICATION_HEADER = "ATNotificationHeader";
	public static final String AT_PROXIMITY_EXPORT_FILENAME = "ATProximity.csv";
	public static final String EXPORT_AT_PROXIMITY = "/exportATProximity";
	public static final String AT_PROXIMITY_HEADER = "ATProximityHeader";
	public static final String AT_OVERVIEW_EXPORT_FILENAME = "ATOverview.csv";
	public static final String EXPORT_AT_OVERVIEW = "/exportATOverview";
	public static final String AT_OVERVIEW_HEADER_GALLONS = "ATOverviewHeaderGallons";
	public static final String AT_OVERVIEW_HEADER_LITRES = "ATOverviewHeaderLitres";
	
	// Asset Cases.
	public static final String ASSET_OV_BEAN = "assetOvBean";
	public static final String ASSET_CASE_LOOKBACK_DAYS_30 = "ASSET_CASE_LOOKBACK_DAYS_30";
	public static final String ASSET_CASE_LOOKBACK_DAYS_60 = "ASSET_CASE_LOOKBACK_DAYS_60";
	public static final String ASSET_CASE_LOOKBACK_DAYS_90 = "90";
	public static final String ASSET_CASE_LOOKBACK_DAYS_LIST = "assetCaseLookBackDaysList";
	public static final String CASE_LOOKBACK_DAYS = "CASE_LOOKBACK_DAYS";
	public static final String ASSET_LASTFAULT_BEAN = "lastFaultStatus";
	public static final String ASSET_CASE_DEFAULT_LOOKBACK_DAYS = "defaultNoOfDays";
	public static final String ASSET_CASES_ASSET_DETAILS = "ASSET_CASES_ASSET_DETAILS";
	public static final String ASSET_CASES_COMM_SECTION = "ASSET_CASES_COMM_SECTION";
	public static final String IS_ASSET_CASES_ASSET_DETAILS = "isAssetCasesAssetDetails";
	public static final String IS_ASSET_CASES_COMM_SECTION = "isAssetCasesCommSection";
	public static final String ASSET_COMM_BEAN = "assetCommBean";
	public static final String ASSET_INSTALLED_PROD = "assetInstalledProd";
	public static final String ASSET_CASE_TYPE_LIST = "assetCaseTypeList";

	//CP Ops alerts.
	public static final String CP_CUSTOMER = "CP";
	public static final String ASSET_HISTORY_LOOKBACK_DAYS = "ASSET_HISTORY_LOOKBACK_DAYS";
	public static final String ASSET_HISTORY_DEFAULT_LOOKBACK = "ASSET_HISTORY_DEFAULT_LOOKBACK";
	public static final String FETCH_CASE_RX_HISTORY = "/getCaseRxHistory";
	public static final String REQ_URI_ATS_SUBMIT_REQUEST = "/submitATSRequest";
	public static final String GET_CUSTOMER_FLEETS = "/getCustFleets";
	public static final String REQ_URI_MANAGE_CUSTOMER_GEOFENCE = "/manageCustomerGeofence";
	public static final String CUSTOMER_GEOFENCE = "customerGeofence";
	public static final String REQ_ASSET_HDR_NUM="roadHdrNumber";
	public static final String GEOFENCE_GEOFENCE_NAME_FAV_FILTER = "GEOFENCE_GEOFENCE_NAME"; 
	public static final String GEOFENCE_FLEET_FAV_FILTER = "GEOFENCE_FLEET"; 
	public static final String GEOFENCE_CUSTOMER_FAV_FILTER = "GEOFENCE_CUSTOMER";
	public static final String LONG_LOCO_L = "L";
	public static final String SHORT_LOCO_S = "S"; 
	public static final String ARZN = "ARZN"; 
	
	// Alert Subscription
	public static final String ALERT_SUBSCRIPTION_PAGE="getAlertSubscription";
	public static final String ALERT_SUBSCRIPTION_VIEW = "AlertSubscription";
	public static final String DEFAULT_CUST="DEFAULT_CUST";
	public static final String LIST_OF_CUSTOMER="LIST_OF_CUSTOMER";
	public static final String REQ_URI_GETASSETFORCUSTOMERS="/getAssetForCustomer";
	public static final String REQ_URI_GETALERTFORCUSTOMERS="/getAlertForCustomer";
	public static final String REQ_URI_GETALERTSUBSCRIPTIONDETAILS="/getAlertSubscriptionDetails";
	public static final String REQ_URI_ADDALERTSUBSCRIPTIONDATA="/addAlertSubscriptionData";
	//public static final String GET_CUSTOMER_FLEETS = "/getCustFleets";
	public static final String GET_FLEET_FOR_CUSTOMER = "/getFleetsForCustomer";
	public static final String GET_REGION_FOR_CUSTOMER = "/getRegionsForCustomer";
	public static final String GET_ALERTS_FOR_SHOP = "/getRestrictedAlertShop";
	public static final String GET_SUBDIVISION_FOR_REGION = "/getSubDivisionForRegion";
	public static final String REQ_URI_EDIT_ALERT = "/editAlert";
	public static final String REQ_URI_ACTIVATE_DEACTIVATE_ALERT = "/activateOrDeactivateAlert";
	public static final String REQ_URI_DELETE_ALERT = "/deleteAlert";
	public static final String SERVICE = "SERVICE";
	
	public static final String SERVICE_TYPE = "serviceType";
	public static final String ALERTS = "alerts";
	public static final String ALERT_TYPE = "alertType";
	public static final String ASSET = "asset";
	public static final String REGION_TYPE = "ALERT_TYPE_REGION";
	public static final String FLEET_TYPE = "ALERT_TYPE_FLEET";
	public static final String ALERT_TYPE_ASSET = "ALERT_TYPE_ASSET";
	public static final String ALERT_TYPE_RX_TITLES = "TITLE";
	public static final String SHOP_TYPE = "ALERT_TYPE_SHOP";
	public static final String ALERT_TYPE_CUSTOMER = "ALERT_TYPE_CUSTOMER";
	public static final String MAIL_FORMAT = "mailFormat"; 
	
	public static final String ERROR_SERVICE = "ERROR_SERVICE";
	public static final String ALERT_SUB = "AlertSub";
	public static final String ERROR_SERVICE_MSG = "Service is required";
	public static final String ERROR_ALERT_SUBSCRIBED = "ERROR_ALERT_SUBSCRIBED";
	public static final String ERROR_MAX__ASSET_SUBSCRIBED = "ERROR_MAX__ASSET_SUBSCRIBED";
	public static final String SUCCESS_ALERT_SUBSCRIBED = "SUCCESS_ALERT_SUBSCRIBED";
	public static final String ERROR_MAX__TITLES_SUBSCRIBED = "ERROR_MAX__TITLES_SUBSCRIBED";
	
	public static final String ALERT_SUBSCRIPTION_ATS = "ALERT_SUBSCRIPTION_ATS";
	public static final String ALERT_SUBSCRIPTION_ATS_COMPONENT = "alertSubscriptionATSComponent";
	public static final String ALERT_SUBSCRIPTION_EOA = "ALERT_SUBSCRIPTION_EOA";
	public static final String ALERT_SUBSCRIPTION_EOA_COMPONENT = "alertSubscriptionEOAComponent";
	public static final String ALERT_SUBSCRIPTION_CONFIG_ALERT = "ALERT_SUBSCRIPTION_CONFIG_ALERT";
	public static final String ALERT_SUBSCRIPTION_CONFIG_ALERT_COMPONENT = "alertSubscriptionConfigAlertComponent";
	public static final String SM_MAIL = "SM_MAIL";
	public static final String USER_MAIL_ID = "userEmailId";
	public static final String ATS_CUSTOEMRS = "atsCustomers";
	public static final String EOA_CUSTOMERS = "eoaCustomers";
	public static final String CONFIG_ALERT_CUSTOMERS = "configAlertCustomers";
	public static final String CUSTOMER_TYPE = "ALERT_TYPE_CUSTOMER";
	public static final int MAX_ASSET_ALERT_SUB_COUNT = 99;
	public static final int MAX_RXTITLES_ALERT_COUNT = 20;
	// Added by Raj.S(212687474) for Remote Data Response Revamped UI feature
	public static final String SHOW_REMOTE_DATA_RESPONSE_REVAMPED = "SHOW_REMOTE_DATA_RESPONSE_REVAMPED";
	public static final String GET_HC_FAULTS = "/getHCFaults";
	public static final String RDR_DATASCREEN_FLAG = "RDR_DATASCREEN_FLAG";
	public static final String IS_FOR_RDR = "isForRDR";
    // getFaults Params
    public static final String HC_PARAM_ASSETNUM = "assetNumber";
    public static final String HC_PARAM_ASSETGRPNAME = "assetGrpName";
    public static final String HC_PARAM_CUSTID = "customerId";
    public static final String HC_PARAM_SORTOPT = "sortOptions";
    public static final String HC_PARAM_FROMDATE= "fromDate";
    public static final String HC_PARAM_STATUS= "status";
    public static final String HC_PARAM_USERID= "userId";
    public static final String HC_PARAM_TODATE= "toDate";
    public static final String HC_PARAM_ISDATEABS = "isDateAbsolute";
    public static final String HC_PARAM_ISLIMITEDPARAM= "isLimitedParam";
    public static final String HC_PARAM_DATA_SCREEN= "DATA_SCREEN";
    public static final String HC_PARAM_ALL_RECORDS= "ALL_RECORDS";
    public static final String HC_PARAM_ISMOBILEREQUEST= "isMobileRequest";
    // Added by Raj.S(212687474) for Remote Data Response Notification feature 	  
    public static final String NOTIFICATION_RDR = "NOTIFICATION_RDR";
    public static final String IS_NOTIFICATION_RDR = "isNotificationRDR";
    public static final String GET_RDR_NOTIFICATIONS = "/getRDRNotifications";
    public static final String SUBMIT_RDR_NOTIFICATIONS = "/submitRDRNotification";
    public static final String UPDATE_RDR_NOTIFICATIONS = "/updateRDRNotification";
    // getRDRNotifications Params
    public static final String RDR_NOTIF_PARAM_USERID = "userId";
	// Added by Sriram.B(212601214) for SMS feature
	public static final String OTP = "otp";
	public static final String OTPValidationVO = "OTPValidationVO";
	public static final String SEND_OTP="/sendOTP";
	public static final String TO_SMS = "To";
    public static final String BODY_SMS = "Body";
    public static final String RETRY_ATTEMPTS_SMS = "RetryAttempts";
    public static final String GET_OTP_PARAMETERS="/getOTPparameters";
    public static final String TWILIO_ENDPOINT_URL="TWILIO_ENDPOINT_URL";
    public static final String TWILIO_AUTH_HEADER="TWILIO_AUTH_HEADER";
    public static final String PROXY_HOST_TWILIO="PROXY_HOST_TWILIO";
    public static final String PROXY_PORT_TWILIO="PROXY_PORT_TWILIO";
    public static final String TWILIO_SERVICE_SID="TWILIO_SERVICE_SID";
    
	//Added by vamshi for Dispatch case functionality
	
	public static final String GET_QUEUE_NAMES ="/getQueueNames";
	
	public static final String DISPATCH_CASE_TO_QUEUE="/dispatchCaseToQueue";
	
	public static final String QUEUE_ID="queueId";
	
	
	//Added by Vamshi for AddNOTES Functionality
	
	public static final String ADD_NOTES_TO_CASE="/addNotesToCase";
	public static final String ADD_NOTES_CASE_ID="caseId";
	public static final String NOTE_DESCRIPTION="noteDescription";
	public static final String APPLY_LEVEL="applyLevel";
	public static final String STICKY="sticky";
	
	
	public static final String FETCH_UNIT_STICKY_DETAILS="/fetchUnitStickyDetails";
	public static final String FETCH_CASE_STICKY_DETAILS="/fetchCaseStickyDetails";
	
	//assign case to users
	
	public static final String FIRST_NAME="firstName";
	public static final String LAST_NAME="lastName";
	public static final String ASSIGN_TO_USER="/assignCaseToUser";
	public static final String GET_OWNER_FOR_CASE="/getCaseCurrentOwnerDetails";
	public static final String CASE_Id="caseId";
	public static final String CASE_HISTORY="/getCaseHistory";
	public static final String ACCEPT="/accept";
	public static final String YANK="/yank";
	//View sticky notes
	
	public static final String REMOVE_STICKY_NOTES="/removeStickyNotes";
	public static final String REMOVE_STICKY_CASEOBJID="caseObjId";
	public static final String CASE_OBJID="caseObjId";
	public static final String UPDATE_CASE_DETAILS="/updateCaseDetails";
	public static final String CASETYPE= "caseType";
	public static final String CASE_TITLE = "caseTitle";
	public static final String GET_CASE_TYPES = "/getCaseTypes";
	public static final String GET_CASE_MGMT_USER_NAMES="/getCaseMgmtUsersDetails";
	public static final String ASSET_OBJID="assetObjid";
	public static final String ESERVICES_URL="ESERVICES_URL";
	public static final String STR_ESERVICES_URL="eServicesUrl";
	public static final String NON_CRITICAL_ACTIVITIES="NON_CRITICAL_ACTIVITIES";
	public static final String REQ_NON_CRITICAL_ACTIVITIES="nonCriticalActivities";
	public static final String ESERVICES_LOCO_ID="locoId";
	public static final String YANK_CASE="/yankCase";
	public static final String NON_CRITICAL_ACTIVITIES_USERS="NON_CRITICAL_ACTIVITIES_USERS";
	public static final String REQ_NON_CRITICAL_ACTIVITIES_USERS="nonCriticalActivitiesUsers";
    public static final String GET_CM_PRIVILEGE_ROLES="/getCaseMgmtRoles";
	public static final String GET_EOA_USERID="/getEoaUserName";
	public static final String DOLLAR_SIGN="$";
	public static final String CASE_MANAGEMENT_PRIVILEGE="CASE_MANAGEMENT_PRIVILEGE";
	public static final String IS_CASE_MGMT_PRIVILEGE="isCMPrivilege";
	public static final String GET_SOLUTION_SELECTBY="/getSolSelectBy";
	public static final String GET_SOLUTION_CONDITION="/getSolCondition";
	public static final String NO_EOA_USER="NO_EOA_USER";
	public static final String GET_SOLUTIONS_FOR_CASE="/getSolutionsForCase";
	public static final String SUB_SYSTEM="SUBSYSTEM";
	public static final String GET_SUBSYSTEM="/getSubSystemDetails";
	public static final String GET_SOLUTIONS="/getSolutionSearchResults";
	public static final String GET_SUB_SYSTEM="subSystem";
	public static final String GET_RX_SUB_SYSTEM="subsystem";
	public static final String ADD_RX_FOR_CASE="/addRxForCase";
	public static final String DELETE_RX_FOR_CASE="/deleteRxForCase";
	public static final String RX_OBJ_ID="rxObjId";
	public static final String URGENCY_REPAIR="urgencyRepair";
	public static final String REVISION_NO="revisionNo";
	public static final String GET_CASE_INFO="/getCaseInfo";
	public static final String REMOVE_COMMA_REGEXPRESSION=",$";
	public static final String ROLE_ID="roleId";
    public static final String GET_PARAMETER_STRING="parameterString";
	public static final String RE_OPEN_CASE="/reOpenCase";
	public static final String CASE_OBJ_ID="caseObjid";
	public static final String DELIVER_RX="/deliverRx";
	public static final String MODIFY_RX_TO_CASE="/modifiyRxToCase";
	public static final String REPLACE_RX_TO_CASE="/replaceRxToCase";
	public static final String NO_EOA_USER_VALIDATION="acces.noeoauser";
	//View Closure
	public static final String VIEW_CLOSURE_CASE_ID="caseId";
	public static final String GET_RX_STATUS_HISTORY="/getRxstatusHistory";
	public static final String GET_CLOSEOUT_REPAIR_CODE="/getCloseOutRepairCode";
	public static final String GET_RX_HISTORY="/getRxHistory";
	public static final String GET_ATTACHED_DETAILS="/getAttachedDetails";
	public static final String GET_RX_NOTE="/getRxNote";
	public static final String GET_SERVICE_REQ_ID="/getServiceReqId";
	public static final String getClosureFdbk="/getClosureFdbk";
	public static final String VIEW_CLOSURE_CASEOBJID="caseObjId";
	public static final String SERVICE_REQ_ID="serviceReqId";
	public static final String CUST_FDBK_OBJ_ID="custFdbkObjId";
	public static final String FDBK_OBJID="fdbkObjId";
	public static final String HASH_SYMBLE="#";	
	public static final String DELIVERY_MECHANISM_NOT_PRESENT="DELIVERY_MECHANISM_NOT_PRESENT";
	public static final String GET_UNIT_SHIP_DETAILS="/getUnitShipDetails";
	public static final String TRANSACTION_NOT_ALLOWED="TRANSACTION_NOT_ALLOWED";
	public static final String CASE_IS_NOT_SCORED="CASE_IS_NOT_SCORED";
	public static final String SERVICE_STATUS_IS_OPEN="SERVICE_STATUS_IS_OPEN";
	public static final String RX_IS_NOT_READY_TO_DELV="RX_IS_NOT_READY_TO_DELV";
	public static final String ESTIMATED_REPAIR_TIME="estRepairTime";
	public static final String VALIDATE_DELIVER_RX="/validateDeliverRx";
	public static final String GET_MSDC_NOTES="/getMsdcNotes";
	public static final String RX_NOT_SCORED="RX_NOT_SCORED";
	public static final String SERVICE_SHEET_IS_OPEN="SERVICE_SHEET_IS_OPEN";
	public static final String HAS_MORE_THAN_TWO_RX_WITH_PENDING_FDBK = "HAS_MORE_THAN_TWO_RX_WITH_PENDING_FDBK";
	//Manual Feedback
	public static final String RX_FEEDBACK1="rxfeedback";
	public static final String RX_FEEDBACK_CODE1="feedBackCode";
	public static final String RX_CASE_ID1="rxcaseId";
	public static final String CASE_ID1="mnlcaseId";
	public static final String RX_NOTES="rxnote";
	public static final String RE_ISSUE="reIssue";
	public static final String DO_ESERVICE_VALIDATION="/doEserviceValidation";
		
	public static final String REPAIR_CODE_REQUIRED="REPAIR_CODE_REQUIRED";
	//Case Closure
	public static final String RX_NOTE="rxNote";
	public static final String FDBK_TYPE="fdbkType";
	public static final String IS_CASE_CLOSURE="isCaseClosure";
	//Closure
	public static final String GET_CLOSURE_DETAILS="/getClosureDetails";
	public static final String VIEW_CLOSURE_CASE_OBJ_ID="caseObjid";
	public static final String ADD_AND_CLOSE="/addAndClose";
	public static final String MANUAL_FEEDBACK_EMPTY_MSG="MANUAL_FEEDBACK_EMPTY_MSG";
	public static final String MANUAL_FEEDBACK_MAXLIMIT="MANUAL_FEEDBACK_MAXLIMIT";
	public static final String MANUAL_FEEDBACK_SPECIAL_CHAR="MANUAL_FEEDBACK_SPECIAL_CHAR";
	public static final String MANUAL_FEEDBACK_CODE_ERRORMSG="MANUAL_FEEDBACK_CODE_ERRORMSG";
	public static final String MANUAL_FEEDBACK_ERROR="MANUAL_FEEDBACK_ERROR";
	
	public static final String CHECK_FOR_CONTOLLER_CONFIG ="/checkForContollerConfig";
	//Find Queue
	public static final String REQ_URI_QUEUELIST = "/queues";
	public static final String REQ_URI_QUEUECASE = "/queueCases";
	public static final String QUEUE_OBJ_ID = "queueObjId";
	public static final String VIEW_QUEUECASES = "queueCases";
	public static final String QUEUE_VO_LST = "queueVOLst";
	public static final String QUEUE_VO_CASES = "queueVOCaseLst";
	public static final String QUEUE_CASES_EXPORT_FILENAME = "queueCases.csv";
	public static final String EXPORT_QUEUE_CASES = "/exportQueueCases";
	public static final String QUEUE_CASES_HEADER="queueCasesHeader";
	
	//MassApply
	public static final String GET_ALL_MODELS="getAllModels";
	public static final String GET_MAX_MASS_APPLY_UNITS="/getMaxLimitForMassApply";
	public static final String GET_CASE_TYPE_VALUES="/getCaseTypeValues";
	public static final String MASS_APPLY_CASE_TYPES="MASS_APPLY_CASE_TYPES_";
	public static final String GET_MASS_APPLY_SOLUTION_SEARCH_RESULTS="/getMassApplySolSearchResults";
	public static final String MASS_APPLY_SELECT_BY_OPTIONS="MASS_APPLY_SELECT_BY_OPTIONS";
	public static final String GET_MASS_APPLY_SELECT_BY_OPTIONS="/getMassApplySolSelectBy";
	public static final String GET_FLEET_VALUES="/getFleetValues";
	public static final String GET_ROAD_NUMBER_HEADERS="/getRoadNumberHeaders";
	public static final String GET_ASSET_LIST="/getAssetList";
	public static final String GET_ASSET_MODEL_LIST="/getAssetModelList";
	public static final String MASS_APPLY_RX_CREATE_CASE="/massApplyCreateCase";
	public static final String GET_MASS_APPLY_URGENCY_REPAIR="/getMassApplyUrgencyofRepair";
	public static final String GET_SOLUTION_STATUS="/getSolutionStatus";
	public static final String GET_SOLUTION_TYPE="/getSolutionType";
	
	public static final String MASS_APPLY_URGENCY_REPAIR = "MASS_APPLY_URGENCY_REPAIR";
	public static final String DEFAULT_MASS_APPLY_SOLUTION_STATUS = "DEFAULT_MASS_APPLY_SOLUTION_STATUS";
	public static final String DEFAULT_MASS_APPLY_SOLUTION_TYPE = "DEFAULT_MASS_APPLY_SOLUTION_TYPE";
	public static final String GET_ASSET_INFO="/getAssetInfo";
	public static final String CUSTOMER_ID_NOT_PROVIDED="CUSTOMER_ID_NOT_PROVIDED";
	public static final String CASE_TYPE_NOT_PROVIDED="CASE_TYPE_NOT_PROVIDED";
	public static final String ASSET_LIST_NOT_PROVIDED="ASSET_LIST_NOT_PROVIDED";
	public static final String RX_OBJID_NOT_PROVIDED="RX_OBJID_NOT_PROVIDED";
	//Append/Split/Close
	public static final String APPEND_TO_CASE_ID ="appendToCaseId";
	public static final String VEH_ID = "vehicleId";
	public static final String RX_ID = "rxId";
	public static final String MERGED_TO="mergedTo";
	//Tooloutput
	public static final String Lms_Id = "lmsId";
	public static final String DELIVER_TOOL_OUTPUT = "/deliverToolOutput";	
	public static final String GET_TOOL_OUTPUT = "/getToolOutputDetails";
	public static final String GET_OPEN_FL_COUNT = "/getOpenFLCount";
	public static final String VIEW_TOOLOUTPUT = "tooloutput";
	public static final String TOOLOUTPUT_RESPONSE = "tooloutputList";
	public static final String TOOLOUTPUT_MAP = "tooloutputMap";
	
	public static final String TOOLOUTPUT_CREATE_CASE="/createCaseToolOuptut";
	public static final String TOOLOUTPUT_CLOSE_CASE = "closeCaseToolOutput";
	public static final String RX_LIST_FOR_CLOSE = "rxListForClose";
	public static final String FC_LIST_FOR_CLOSE = "fcListForClose";
	public static final String GET_CASE_TITLE = "GET_CASE_TITLE";
	public static final String IS_RX_DELIVERY = "isRxDelv";
	public static final String CLOSE_REASON = "closeReason";
	public static final String NO_SUPP_DATA = "noSuppData";
	public static final String NO_SUPP_DATA_CODE = "9015";
	public static final String IN_SHOP = "inShop";
	public static final String IN_SHOP_CODE = "9012";
	public static final String TOOL_ID = "toolId";
	public static final String TOOLOUTPUT_SUBMIT="/submitToolOutput";
	public static final String VIEW_TOSUMMARY="toSummary";
	public static final String TO_CASE_ID = "toCaseId";
	public static final String DELIVER_VO_LST = "deliverVOLst";	
	public static final String APPEND_VO_LST = "appendVOLst";
	public static final String CLOSE_VO_LST = "closeVOLst";
	public static final String RX_DELV = "rxDelv";
	public static final String CC="CC";
    public static final String NC="NC";
    public static final String CURRENT_CASE="Current Case";
    public static final String NEW_CASE="New Case";
    public static final String GET_OPEN_CASES="/getOpenCases";
    public static final String SKIP_COUNT_CLOSE = "skipCount";
	
	public static final String GET_DIAGNOSTIC_WEIGHT="/getDiagnosticWeight";
	public static final String GET_SUBSYS_WEIGHT="/getSubSysWeight";
	public static final String GET_MODE_RESTRICTION="/getModeRestriction";
	public static final String GET_FAULT_CLASSIFICATION="/getFaultClassification";
	public static final String GET_CRITICAL_FLAG="/getCriticalFlag";
	public static final String GET_FAULT_STRATEGY_DETAILS="/getFaultStrategyDetails";
	public static final String FAULT_STRATEGY_OBJID="fsObjId";
	public static final String FAULT_CODE_ID="faultCode";
	public static final String GET_RULE_DESC="/getRuleDesc";
	public static final String UPDATE_FAULT_SERVICE_STRATEGY="/updateFaultServiceStrategy";
	
	
	public static final String FLTSTART2FLTCODE="fltStart2FltCode";
	public static final String DIAGNOSTIC_WEIGHT ="diagnosticWeight";
	public static final String SUBSYS_WEIGHT ="subSysWeight";
	public static final String MODE_RESTRICTION="modeRestriction";
	public static final String FAULT_CLASSIFICATION="faultClassification";
	public static final String CRITICAL_FLAG="criticalFlag";
	public static final String FAULTNOTES="fssrxnote";
	public static final String FAULTLAGTIME="lagTime";
	public static final String FLTDESCRIPTION="description";
	
	public static final String CREATCASE_DIAGNOSTIC_WEIGHT="Diagnostic weight";
	public static final String CREATCASE_SUBSYS_WEIGHT="Sub Sys Weight";
	public static final String CREATCASE_MODE_RESTRICTION="Modification Restriction";
	public static final String CREATCASE_FAULT_CLASSIFICATION="Fault Classification";
	public static final String CREATCASE_CRITICAL_FLAG="Critical Flag";
	
	public static final String GET_TO_COLOR_CODING_VALUES = "getTOColorCodingValues";
	public static final String ToolProbGreen = "ToolProbGreen";
	public static final String ToolProbYellow = "ToolProbYellow";
	public static final String ToolFalseAlarmYellow = "ToolFalseAlarmYellow";
	public static final String ToolFalseAlarmGreen = "ToolFalseAlarmGreen";
	public static final String ToolCoverageGreen = "ToolCoverageGreen";
	public static final String ToolCoverageYellow = "ToolCoverageYellow";
	public static final String MDSCPerformanceGreen = "MDSCPerformanceGreen";
	public static final String MDSCPerformanceYellow = "MDSCPerformanceYellow";
	
	public static final String FAULT_ANALYSIS_MANUAL_URL = "FAULT_ANALYSIS_MANUAL_URL";
	public static final String STR_FAULT_ANALYSIS_MANUAL_URL="faultAnalysisManualUrl";
	public static final String GET_MY_CASES="/getMyCases";
	public static final String HEADER_CASE_SEARCH_STRING_LENGTH="SEARCH_CASE_LENGTH";
	public static final String LOCO_ID="LocoId";
	
	public static final String ENABLED_UNIT_DELIVER_RX = "/getEnabledUnitRxsDeliver";
	public static final String ACTIVE_RX_EXISTS_IN_CASE = "/activeRxExistsInCase";
	public static final String ACTIVE_RX_FLAG="activeRxFlag";
	public static final String QUEUES_DEFAULT_RECORDS = "queuesDefaultRecords";
	public static final String QUEUES_TABLE_DEFAULT_RECORDS = "QUEUES_TABLE_DEFAULT_RECORDS";
	public static final String CUST_VERSION_NOT_EXIST="CUST_VERSION_NOT_EXIST";
	
	public static final String GET_CLOSE_OPTION = "/getCloseOption";
	public static final String CLOSE_OPTION_LIST = "Tooloutput Close Option List";	
	public static final String IS_MASS_APPLY_RX="isMassApplyRx";
	public static final String ADD_RX_APPLY="addRxApply";
	public static final String GET_RX_DETAILS="/getRecommDetails";
	public static final String VEHICLE_OBJID="vehicleObjId";
	public static final String APPEND_FLAG="appendFlag";
	public static final String USER_TYPE = "ADMIN_USER_TYPE";

	public static final String MISS4F="Miss-4F";
	public static final String MISS4B="Miss-4B";
	public static final String MISS_4F_REPAIR_CODE="MISS_4F_REPAIR_CODE";
	public static final String MISS_4B_REPAIR_CODE="MISS_4B_REPAIR_CODE";
	public static final String UNIT_CONFIG="/getUnitConfigDetails";
	public static final String UNIT_CONFIG_Model="Model";
	public static final String REQ_URI_NOTIFICATIONMANAGEMENT = "/notificationManagement";
	public static final String VIEW_NOTIFICATIONMANAGEMENT = "notificationManagement";
	public static final String REQ_URI_USER_EMAIL = "/getUserEmail";
	public static final String REQ_URI_USER_COMPONENT = "/getUserComponent";
	public static final String REQ_URI_POST_MAIL = "/postMail";
	public static final String ADMIN_MAILID = "adminEmailId";
	public static final String REQ_URI_RX_FILTER = "/getRxFilterValues";
	public static final String REQ_URI_RX_SHOPS = "/getShopForCustomer";
	public static final String REQ_URI_ALERT_MODELS ="/getModelDetails";
	public static final String REQ_URI_MULTI_USERS ="/getMultiUsers";
	
	//adding for alert related email.
	public static final String MAIL_SERVER_NAME = "mail.smtp.host";
	public static final String SMTP_SERVER_NAME = "SMTP_ADDRESS";
	public static final String ADMIN_LDAP_CONNECTION_FACTORY = "LDAP_CONNECTION_FACTORY";
	public static final String ADMIN_LDAP_CONNECTION_URL="LDAP_CONNECTION_URL";
	public static final String ADMIN_LDAP_CONNECTION_PSWD="LDAP_CONNECTION_PSWD";
	public static final String ADMIN_SECURITY_AUTHENTICATION="SECURITY_AUTHENTICATION";
	public static final String ADMIN_MAIL_SERVER="MAIL_SERVER";
	public static final String ADMIN_LDAP_SECURITY_PRINCIPLE="LDAP_SECURITY_PRINCIPLE";
	public static final String ADMIN_BASE_DN="Base_Dn";
	public static final String ADMIN_UID_MAP="Uid=";
	public static final String MAIL_CONTENT_TYPE="text/html";
	public static final String MAIL="mail";
	public static final String SSO_STATUS="gessostatus";
	public static final String LETTER_A="A";
	public static final String LETTER_E="E";
	public static final String ADMIN_NOTIFICATION_DEFAULT_RECORDS="5";
	
	public static final String ALERT_VALUE = "alertValue";
	public static final String MESSAGE_BODY = "message";
	public static final String TO = "to";
	public static final String TO_NAME = "toName";
	public static final String FROM = "from";
	public static final String ADMIN_ALERTSUB_HI="ADMIN_ALERTSUB_HI"; 
	public static final String ADMIN_ALERTSUB_MSGPART1="ADMIN_ALERTSUB_MSGPART1";
	public static final String ADMIN_ALERTSUB_MSGPART2="<br/>You can view, edit or delete your subscription by logging on to the OMD portal(https://www.getransro.com/RMDWeb/login) and accessing 'Alert Subscription' tab.<br/><br/>If you do not want to receive the above mentioned alert notification in your mailbox or think that it has been subscribed incorrectly, please forward this email and get in touch with :<br/>1.DL<br/>2.DL<br/><br/>Regards,<br/>GE OMD Team";

	public static final String ADMIN_ADD_ALERTSUB_SUBJECT="ADMIN_ADD_ALERTSUB_SUBJECT";
	public static final String ADMIN_ADD_ALERTSUB_MSGPART="ADMIN_ADD_ALERTSUB_MSGPART"; 
	
	public static final String ADMIN_ACTIVATE_ALERTSUB_SUBJECT="ADMIN_ACTIVATE_ALERTSUB_SUBJECT"; 
	public static final String ADMIN_ACTIVATE_ALERTSUB_MSGPART="ADMIN_ACTIVATE_ALERTSUB_MSGPART";  
	
	public static final String ADMIN_DEACTIVATE_ALERTSUB_SUBJECT="ADMIN_DEACTIVATE_ALERTSUB_SUBJECT"; 
	public static final String ADMIN_DEACTIVATE_ALERTSUB_MSGPART="ADMIN_DEACTIVATE_ALERTSUB_MSGPART"; 
	public static final String ADMIN_DEACTIVATE_ALERTSUB_MSGPART2="<br/>You can view, edit or delete your subscription by logging on to the OMD portal(https://www.getransro.com/RMDWeb/login) and accessing 'Alert Subscription' tab.<br/><br/>If you want to receive the above mentioned alert notification in your mailbox or think that it has been de-activated incorrectly, please forward this email and get in touch with :<br/>1.DL<br/>2.DL<br/><br/>Regards,<br/>GE OMD Team";
	
	public static final String ADMIN_DELETE_ALERTSUB_SUBJECT="ADMIN_DELETE_ALERTSUB_SUBJECT"; 
	public static final String ADMIN_DELETE_ALERTSUB_MSGPART="ADMIN_DELETE_ALERTSUB_MSGPART"; 
	public static final String ADMIN_DELETE_ALERTSUB_MSGPART2="<br/>You can view, edit or delete your subscription by logging on to the OMD portal(https://www.getransro.com/RMDWeb/login) and accessing 'Alert Subscription' tab.<br/><br/>If you want to receive the above mentioned alert notification in your mailbox or think that it has been deleted incorrectly, please forward this email and get in touch with :<br/>1.DL<br/>2.DL<br/><br/>Regards,<br/>GE OMD Team";
	
	public static final String ADMIN_EDIT_ALERTSUB_SUBJECT="ADMIN_EDIT_ALERTSUB_SUBJECT"; 
	public static final String ADMIN_EDIT_ALERTSUB_MSGPART="ADMIN_EDIT_ALERTSUB_MSGPART";
	public static final String ADMIN_EDIT_ALERTSUB_MSGPART2="<br/>You can view, edit or delete your subscription by logging on to the OMD portal(https://www.getransro.com/RMDWeb/login) and accessing 'Alert Subscription' tab.<br/><br/>If you think that it has been edited incorrectly, please forward this email and get in touch with :<br/>1.DL<br/>2.DL<br/><br/>Regards,<br/>GE OMD Team";
	
	public static final String ALERT_TEXT = "alertText";
	public static final String ASSET_TEXT = "assetText";
	public static final String REGION_TEXT = "regionText";
	public static final String FLEET_TEXT = "fleetText";
	public static final String EMAIL_NOT_VALID = "Email Id not valid";
	public static final String TOOL_OBJID="toolObjId";
	public static final String FALSE_ALARM_DETAILS="/getFalseAlarmDetails";
	public static final String RX_FALSE_ALARM_DETAILS="/getRXFalseAlarmDetails";
	public static final String MDSC_ACCURATE_DETAILS="/getMDSCAccurateDetails";
	public static final String MDSC_ACCURATE_GET_CASE_DETAILS="/getCaseDetails";
	public static final String REP_OBJ_ID="repObjId";
	public static final String MDSC_ACCURATE_GET_RX_DETAILS="/getMDSCRxDetails";
	public static final String EDIT_RX_URL="EDIT_RX_URL";
	public static final String STR_EDIT_RX_URL="editRxUrl";
	public static final String RX_FILTER_VALUES="ALERT_RX_FILTER";
	public static final String ATS="ATS";
	public static final String EOA="EOA";
	public static final String SUBSCRIBED_ALERT = "subscribedAlert";
	public static final String RX_ALERT_VALUE = "alertValue";
	public static final String SUB_DIVISION = "subdivision";
	public static final String SHOP = "shop";
	public static final String ACTIVE = "Active";
	public static final String DEFAULT = "Default";
	public static final String REQ_URI_GET_SUB_SYSTEM_WITH_OBJID="/getSubSystemWithObjid";
	public static final String REQ_URI_GET_LOCOMOTIVE_IMPACT_WITH_OBJID="/getLocomotiveImpactWithObjid";
	public static final String REQ_URI_GET_URGENCY_REPAIR_WITH_OBJID="/getUrgencyOfRepairWithObjid";
	public static final String EXPORT_ALERT_SUBSCRIPTION="/exportAlertSubscriptionDetails";
	public static final String ALERT_SUBSCRIPTION_EXPORT_FILENAME = "AlertSubscription.csv";
	public static final String ALERT_SUBSCRIPTION_HEADER = "AlertSubscriptionHeader";
	public static final String ALERT_SUBSCRIPTION_HEADER_SMS = "AlertSubscriptionHeaderSMS";
	public static final String ALERT_SUBSCRIPTION_HEADER_WITHOUT_MODEL = "AlertSubscriptionHeaderWithoutModel";
	public static final String ROW_SELECTED ="rowSelected";
	public static final String RX_SUBSCRIPTION_DELIVERY_EMAIL_FLAG ="RX_SUBSCRIPTION_DELIVERY_EMAIL_FLAG";
	public static final String RX_FLAG ="rxFlag";
	public static final String ADMIN_ALERTSUB_Rx_Filter="ADMIN_ALERTSUB_RX_FILTER";
	public static final String ADMIN_ALERTSUB_Urgency_Type="ADMIN_ALERTSUB_URGENCY_TYPE";
	public static final String ADMIN_ALERTSUB_SUBSYSTEM_Type="ADMIN_ALERTSUB_SUBSYSTEM_TYPE";
	public static final String ADMIN_ALERTSUB_LOCOIMPACT_Type="ADMIN_ALERTSUB_LOCOIMPACT_TYPE";
	public static final String ADMIN_ALERTSUB_TITLE_Type="ADMIN_ALERTSUB_TITLE_TYPE";
	public static final String ADMIN_ALERTSUB_REGION="ADMIN_ALERTSUB_REGION";
	public static final String ADMIN_ALERTSUB_SUBDIVISION_BASED="ADMIN_ALERTSUB_SUBDIVISION_BASED";
	public static final String ADMIN_ALERTSUB_FLEET_BASED="ADMIN_ALERTSUB_FLEET_BASED";
	public static final String ADMIN_ALERTSUB_ASSET_BASED="ADMIN_ALERTSUB_ASSET_BASED";
	public static final String ADMIN_ALERTSUB_SHOP_BASED="ADMIN_ALERTSUB_SHOP_BASED";
	public static final String ADMIN_ALERTSUB_RX_SUBJECT="ADMIN_ALERTSUB_RX_SUBJECT";
	public static final String ADMIN_ALERTSUB_CUSTOMER="ADMIN_ALERTSUB_CUSTOMER";	
	public static final String TITLES="Title";
	public static final String RX_URGENCY="Urgency";
	public static final String LOCO_IMPACT="LOCO IMPACT";
	public static final String NOT_APLICABLE="NA";
	public static final String REQ_URI_VIEW_FSS="/viewFaultService";
	public static final String VIEW_FAULT_SERVICE="viewFaultService";
	public static final String GET_FAULT_ORIGIN="/getFaultOrigin";
	public static final String GET_FAULT_CODE_SUBID="/getFaultCodeSubId";
	public static final String GET_VIEW_FSS_FAULT_CODE="/getViewFSSFaultCode";
	public static final String GET_FAULT_STRATEGY_OBJID="/getFaultStrategyObjId";
	public static final String FAULT_ORIGIN="faultOrigin";
	public static final String FAULT_CODE_SUBID="faultCodeSubId";
	public static final String BOLD_TAG_START="<b>";
	public static final String BOLD_TAG_END="</b>";
	public static final String VIEW_PPHISTORY_PAGE = "/ppAssetHistory";
	public static final String VIEW_CASE_PPHISTORY_PAGE = "/ppCaseAssetHistory";
	public static final String PP_ASSET_HISTORY = "ppAssetHistory";
	public static final String PP_CASE_ASSET_HISTORY = "ppCaseAssetHistory";
	public static final String GET_ALL_Status="/getAllStatus";
	public static final String GET_NO_DAYS="/getNoDays";
	public static final String GET_ASSET_HISTORY="/getAssetHistory";
	public static final String CHANGE_STATUS="/changeStatus";
	public static final String GET_STATUS_VALUE="/getStatusValue";
	public static final String GET_PPASSET_MODEL_VALUE="/getPPAssetModel";
	public static final String RNH_ID="rnhId";
	public static final String RN_SEARCH_STRING="rnSearchString";
	public static final String RN_ID="rnId";
	public static final String PP_STATUS="pp_vehicle_conditions";
	public static final String PP_NO_OF_DAYS="PP_NO_OF_DAYS";
	public static final String CASE_PPASSET_FLAG="CASE_PPASSET_FLAG";
	public static final String ASSET_PPASSET_FLAG="ASSET_PPASSET_FLAG";
	public static final String PP_ASSETHISTORY_RADIO="ppAssetHistoryRadio";
	public static final String FROM_TO="FROM_TO";
	public static final String ERROR_TO_DATE_FROM_DATE_MSG_90 = "The Date range is larger than 90 days";
	public static final String ERROR_TO_DATE_EARLIER="To Date should be a earlier date";
	public static final String EXCEPTION_RMD_216 = "RMD_216";
	public static final String EXPORT_PPASSETHISTORY = "/exportPPAssetHistoryReport";
	public static final String PP_ASSETHISTORY_REPORT_HEADER="PPAssetHistoryReportHeader";
	public static final String PP_ASSETHISTORY_EXPORT_FILENAME = "PPAssetHistory.csv";
	public static final String GET_PPCUSTOMER_NAME="/getPPCustomerName";
	public static final String ERROR_CUSTOMER_NAME_REQUIRED_MSG = "Customer Name: is required";
	public static final String ERROR_ROAD_NUMBER_HEADER_REQUIRED_MSG = "Road Number Header: is required";
	public static final String ERROR_ROAD_NUMBER_REQUIRED_MSG = "Road Number: is required";
	public static final String PP_LOOKBACK_DAYS="PP_LOOKBACK_DAYS";
	public static final String SYMBOL_MINUS = "-";
	public static final String PP_DEFAULT_NO_OF_DAYS="PP_DEFAULT_NO_OF_DAYS";
	public static final String DEFAULT_NO_OF_DAYS="defaultNoOfDays";
	public static final String REQ_FAULT_ANALYSIS_MANUAL_URL="faultAnalysisManualUrl";
	public static final String CASE_ASSET_HISTORY="CASE_ASSET_HISTORY";
	public static final String CHECK_FOR_UNIT_SHIP_DETAILS = "/checkForUnitShipDetails";
	public static final String UNIT_STICKY_OBJID="unitStickyObjId";
	public static final String CASE_STICKY_OBJID="caseStickyObjId";
	//RuleDef Url Changes
	public static final String RULE_DEF_URL="RULE_DEF_URL";
	public static final String STR_RULE_DEF_URL="ruleDefUrl";
	public static final String VISUALIZATION_ANOMALY_PARAMETERS="VISUALIZATION_ANOMALY_PARAMETERS";
	public static final String OIL_INLET_VALUE1_INVALID="ENG_SPEED_VALUE1_INVALID";
	public static final String BAROMETRIC_VALUE1_INVALID="ENG_SPEED_VALUE1_INVALID";
	public static final String HP_AVAILABLE_VALUE1_INVALID="ENG_SPEED_VALUE1_INVALID";
	public static final String OIL_INLET_VALUE1_INVALID_NON_INTEGER="OIL_INLET_VALUE1_INVALID_NON_INTEGER";
	public static final String BAROMETRIC_VALUE1_INVALID_NON_INTEGER="BAROMETRIC_VALUE1_INVALID_NON_INTEGER";
	public static final String HP_AVAILABLE_VALUE1_INVALID_NON_INTEGER="HP_AVAILABLE_VALUE1_INVALID_NON_INTEGER";
	public static final String OIL_INLET_VALUE2_INVALID="OIL_INLET_VALUE2_INVALID";
	public static final String HP_AVAILABLE_VALUE2_INVALID="HP_AVAILABLE_VALUE2_INVALID";
	public static final String BAROMETRIC_VALUE2_INVALID="BAROMETRIC_VALUE2_INVALID";
	public static final String OIL_INLET_VALUE2_INVALID_NON_INTEGER="ENG_SPEED_VALUE2_INVALID_NON_INTEGER";
	public static final String HP_AVAILABLE_VALUE2_INVALID_NON_INTEGER="ENG_SPEED_VALUE2_INVALID_NON_INTEGER";
	public static final String BAROMETRIC_VALUE2_INVALID_NON_INTEGER="ENG_SPEED_VALUE2_INVALID_NON_INTEGER";
	
	public static final String OMD_VISUALIZATION_OIL_INLET_DEFAULT_SELECT="OMD_VISUALIZATION_OIL_INLET_DEFAULT_SELECT";
	public static final String OMD_VISUALIZATION_OIL_INLET_DEFAULT_VALUE1="OMD_VISUALIZATION_OIL_INLET_DEFAULT_VALUE1";	
	public static final String OMD_VISUALIZATION_OIL_INLET_DEFAULT_VALUE2="OMD_VISUALIZATION_OIL_INLET_DEFAULT_VALUE2";	
	public static final String OMD_VISUALIZATION_HP_AVAILABLE_DEFAULT_VALUE1="OMD_VISUALIZATION_HP_AVAILABLE_DEFAULT_VALUE1";	
	public static final String OMD_VISUALIZATION_HP_AVAILABLE_DEFAULT_SELECT="OMD_VISUALIZATION_HP_AVAILABLE_DEFAULT_SELECT";
	public static final String OMD_VISUALIZATION_HP_AVAILABLE_DEFAULT_VALUE2="OMD_VISUALIZATION_HP_AVAILABLE_DEFAULT_VALUE2";	
	public static final String OMD_VISUALIZATION_BAROMETRIC_DEFAULT_VALUE1="OMD_VISUALIZATION_BAROMETRIC_DEFAULT_VALUE1";	
	public static final String OMD_VISUALIZATION_BAROMETRIC_DEFAULT_SELECT="OMD_VISUALIZATION_BAROMETRIC_DEFAULT_SELECT";
	public static final String OMD_VISUALIZATION_BAROMETRIC_DEFAULT_VALUE2="OMD_VISUALIZATION_BAROMETRIC_DEFAULT_VALUE2";	
	
	public static final String OIL_INLET_DEFAULT_SELECT="oilInletDefaultSelect";
	public static final String OIL_INLET_DEFAULT_VALUE1="oilInletDefaultVal1";
	public static final String OIL_INLET_DEFAULT_VALUE2="oilInletDefaultVal2";
	
	public static final String HP_AVAILABLE_DEFAULT_SELECT="hpAvailableDefaultSelect";
	public static final String HP_AVAILABLE_DEFAULT_VALUE1="hpAvailableDefaultVal1";
	public static final String HP_AVAILABLE_DEFAULT_VALUE2="hpAvailableDefaultVal2";
	
	public static final String BAROMETRIC_DEFAULT_SELECT="barometricDefaultSelect";
	public static final String BAROMETRIC_DEFAULT_VALUE1="barometricDefaultVal1";
	public static final String BAROMETRIC_DEFAULT_VALUE2="barometricDefaultVal2";
	public static final String ERROR_TO_FROM_EARLIER="From Date should be a earlier date";
	
	//Call log notes
	public static final String REQ_URI_CALLLOG="/callLog";
	public static final String REQ_SEARCH_CALLLOG="/getCallLogNotes";
	public static final String DEFAULT_CALLLOG="/getDefaultDays";
	public static final String VIEW_CALLLOG = "callLog";
	public static final String CALL_LOG_NOTES_VO = "callLogNotesLst";
	public static final String EXPORT_CALLLOG_NOTES = "/exportCallLogNotes";
	public static final String CALL_LOG_ID = "callLogId";
	public static final String CALL_LOG_DATE_FORMAT = "dd-MMM-yy";
	public static final String CALL_LOG_DEFAULT_DATE = "OMD_CALL_LOG_DEFAULT_DATE";
	public static final String CALL_LOG_LOOKUP_DAYS = "defaultLookupDays";
	public static final String GET_CONTROLLER_CONFIG="/getControllerConfig";
	public static final String CALL_LOG_EXPORT_FILENAME = "calllognotes.csv";
	public static final String CALL_LOG_HEADER="CallLogHeader";
	public static final String GET_CURR_USER_PREF_TIME="/getCurrentUserPrefTime";
	
	public static final String TOOL_UNEXPECTED_ERR = "An Unexpected Error Occured in one or more operations.Please try again.";
	
	public static final String GET_DEVICE_INFO = "getDeviceInfo";
	public static final String INVALID_PARAMETERS = "Invalid parameters";
	public static final String TYPE_OF_USER = "typeOfUser";
	public static final String DEVICE = "device";
	public static final String DEVICE_EGA="EGA";
	public static final String HC_INTERNAL_USERS="HC_INTERNAL_USERS";
	public static final String HC_EXTERNAL_USERS="HC_EXTERNAL_USERS";
	public static final String INVALID_USER_CLASSIFICATION="Invalid user";
	public static final String REQ_URI_VIEW_FIND_CASE="/viewFindCase";
	public static final String VIEW_FIND_CASE="viewFindCase";
	public static final String GET_SEARCH_OPTIONS="/getfindCaseSearchOptions";
	public static final String GET_FILTER_OPTIONS="/getfindCaseFilterOptions";
	public static final String GET_RN_FILTER_OPTIONS="/getRNFilterOptions";
	public static final String GET_CASE_TYPE="/getfindCaseCaseType";
	public static final String EXPORT_FINDCASES = "/exportFindCasesReport";
	public static final String FINDCASE_CASE_TYPES="PreviousCaseTypes";
	public static final String FINDCASE_SEARCH_OPTIONS="FINDCASE_SEARCH_OPTIONS";
	public static final String FINDCASE_FILTER_OPTIONS="FINDCASE_FILTER_OPTIONS";
	public static final String RN_FILTER_OPTIONS="RN_FILTER_OPTIONS";
	public static final String FINDCASES_LOOKBACK_DAYS="FINDCASES_LOOKBACK_DAYS";
	public static final String FINDCASES_PREVOIUSDATE = "previousDate";
	public static final String GET_FIND_CASES="/getFindCases";
	public static final String FINDCASE_CUSTOMER="findCaseCustomer";
	public static final String RN_FILTER="rnFilter";
	public static final String FINDCASE_RNH="findCaseRNH";
	public static final String FINDCASE_RN="findCaseRN";
	public static final String FINDCASE_SEARCH="findCaseSearchOptions";
	public static final String FINDCASE_FILTER="findCaseFilterOptions";
	public static final String FINDCASE_CASETYPE="findCaseCaseType";
	public static final String FINDCASE_FILELD_VALUE="findCaseSearchFiledVale";
	public static final String FINDCASE_START_DATE="startDate";
	public static final String FINDCASE_END_DATE="endDate";
	public static final String FINDCASE_RN_FILTER_SELECTED="findCaseRNFilter";
	public static final String FINDCASES_REPORT_HEADER="FindCasesReportHeader";
	public static final String FINDCASES_EXPORT_FILENAME = "FindCases.csv";
	public static final String FINDCASES_START_DATE_REQUIRED = "FINDCASES_START_DATE_REQUIRED";
	public static final String FINDCASES_START_END_DATE = "FINDCASES_START_END_DATE";
	public static final String FINDCASES_START_FUTURE_DATE = "FINDCASES_START_FUTURE_DATE";
	//Shippers
	public static final String REQ_URI_SHIPPERS="/showShippersPage";
	public static final String REQ_URI_SHIPPED_UNITS="/showShippedUnitsPage";
	public static final String SHIPPERS="shippers";
	public static final String SHIPPED_UNITS="shippedUnits";
	public static final String GET_UNIT_TO_BE_SHIPPED="/getUnitsToBeShipped";
	public static final String UPDATE_UNITS_TO_BE_SHIPPED="/updateUnitsToBeShipped ";
	public static final String GET_LAST_SHIPPED_UNITS="/getLastShippedUnits";
	public static final String IS_DEFAULT_LOAD="isDefaultLoad";
	public static final String CUSTOMER_LIST="customerList";
	public static final String INVALID_DATE="INVALID_DATE";
	public static final String UTC_DATE_FORMAT="E, dd MMM yyyy HH:mm:ss Z";
	public static final String UTC_DATE_FORMAT_WITHOUT_TIME="E, dd MMM yyyy";
	public static final String GET_PP_ASSET_HST_BTN_DETAILS="/getPPAssetHstBtnDetails";
	public static final String PP_ASSET_HST_BTN_DISPLAY="ppBtnResult";
	public static final String INVALID_SHIP_DATE="INVALID_SHIP_DATE";
	public static final String GET_CUSTOMER_RNH="/getAllCustRNH";
	public static final String GET_ROAD_NUM="/getRoadNumber";
	public static final String GET_ROAD_NUM_WITH_FILTER="/getRoadNumberWithFilter";
	public static final String HIDE_ASSETOVERVIEW_NOTES_CREATED_BY_ROLE_ID = "HIDE_ASSETOVERVIEW_NOTES_CREATED_BY_ROLE_ID";
	public static final String IS_NON_GPOC_USER = "isNonGPOCUser";
	
	//Material Usage Screen - Added by mohamed
	public static final String GET_MATERIAL_USAGE = "/getMaterialUsage";
	public static final String MATERIAL_USAGE_LOOKBACK_DAYS = "MATERIAL_USAGE_LOOKBACK_DAYS";
	public static final String MATERIAL_USAGE_LOOKBACK_DAYS_LIST = "materialUsageLookBackDaysList";
	public static final String MATERIAL_USAGE_DEFAULT_LOOKBACK_DAYS = "defaultNoOfDaysMaterialUsage";
	public static final String MATERIAL_USAGE_LOOKUP_DAYS = "lookUpDays";
	
	//ATS url 
	public static final String ATS_HEALH_CHECK_SEND_MESSAGE_SERVICE_URL="ATS_HC_MCS_SENDMESSAGE_URL";
	//hc 
	public static final String FUNCTION_ERROR_VALIDATION="Validation error";
	public static final String VALIDATE_EGA_HC="/validateEGAHC";
	public static final String VALIDATE_NT_HC="/validateNTHC";
	public static final String MODEL_VALUE = "modelVal";
	public static final String MODEL_TYPE = "ALERT_TYPE_MODEL";
	public static final String ALERT_SUBSCRIPTION_MODEL = "ALERT_SUBSCRIPTION_MODEL";
	public static final String ALERT_SUBSCRIPTION_MODEL_COMPONENT = "alertSubscriptionModelComponent";
	public static final String ALERT_SUBSCRIPTION_FLAG= "AlertSubscription";
	public static final String ADMIN_ALERTSUB_MODEL_BASED="ADMIN_ALERTSUB_MODEL_BASED";
	public static final String ALL_SUBSCRIPTION= "ALL_SUBSCRIPTION";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION = "ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_COMPONENT = "alertSubscriptionMultiSubComponent";
	//Ship Units - by Mohamed
	public static final String GET_ASSET_NUMBERS_FOR_SHIP_UNITS="/getAssetNumbersForShipUnits";

	//Add Notes Tab
	public static final String REQ_URI_ADD_NOTES = "/addNotes";
	public static final String ADD_NOTES = "addNotes";
	public static final String GET_ALL_CONTROLLERS = "/getAllControllers";
	public static final String GET_ALL_CREATORS = "/getNotesCreatersList";
	public static final String FETCH_VEHICLE_STICKY_DETAILS = "/fetchVehStickyDetails";
	public static final String FROM_RN = "fromRN" ;
	public static final String TO_RN = "toRN" ;
	public static final String ADD_NOTES_TO_VEHICLE = "/addNotesToVehicle";
	public static final String CONTROLLER_ID = "ctrlId";
	public static final String OVERWRITE_FLAG = "overWriteFlag";
	public static final String STICKY_EXIST_OBJID = "objId";
	public static final String GET_NOTE_TYPES="/getNoteTypes";
	public static final String NOTE_TYPE_LIST = "NOTE_TYPE_LIST";
	public static final String REQ_URI_FIND_NOTES = "/findNotes";
	public static final String FIND_NOTES = "findNotes";
	public static final String FIND_NOTES_PREVOIUSDATE = "previousDate";
	public static final String FINDNOTES_LOOKBACK_DAYS="FINDNOTES_LOOKBACK_DAYS";
	public static final String GET_FIND_NOTES = "/getFindNotes";
	public static final String FINDNOTES_START_DATE = "startDate";
	public static final String FINDNOTES_END_DATE = "endDate";
	public static final String NOTE_TYPE = "notesType";
	public static final String FINDNOTES_KEYWORD = "searchKeyWord";
	public static final String FIND_NOTES_REMOVE_STICKY="/removeSticky";
	public static final String FINDNOTES_END_DATE_ERROR = "FINDNOTES_END_DATE_ERROR";
	public static final String FINDNOTES_START_FUTURE_DATE = "FINDNOTES_START_FUTURE_DATE";
	public static final String EXPORT_FINDNOTES = "/exportFindNotesReport";
	public static final String FINDNOTES_EXPORT_FILENAME = "FindNotes.csv";
	public static final String FINDNOTES_REPORT_HEADER="FindNotesReportHeader";
	public static final String NOTES_DEFAULT_RECORDS = "notesDefaultRecords";
	public static final String FIND_NOTES_TABLE_DEFAULT_RECORDS = "FIND_NOTES_TABLE_DEFAULT_RECORDS";


	//Vehicle Config
	public static final String REQ_URI_VEHICLE_CONFIG = "/viewEditVehicleCfg";
	public static final String REQ_URI_CASE_VEHICLE_CONFIG = "/getCaseVehicleCfgScreen";
	public static final String VEHICLE_CONFIG = "vehicleConfig";
	public static final String DELETE_VEHICLE_CFG_TEMPLATE="/deleteVehicleCfgTemplate";
	public static final String GET_CONFIG_FILES="/getConfigFiles";
	public static final String DELETE_CONFIG_TYPE="Delete Config type";
	public static final String REQ_URI_GET_VEHICLE_BOM_CONFIG = "/getVehicleBOMConfigs";
	public static final String REQ_URI_GET_MDSC_STARTUP_CONTROLLERS = "/getMDSCStartUpControllers";
	public static final String REQ_URI_GET_MDSC_STARTUP_CONTROLLERS_INFO = "/getMDSCStartUpControllersInfo";
	public static final String REQ_URI_SAVE_VEHICLE_BOM_CONFIGS = "/saveVehicleBOMConfigs";
	public static final String REQ_URI_GET_VEHICLE_CFG_TEMPLATES = "/getVehicleCfgTemplates";
	public static final String RNH="rnh";
	public static final String GET_MSDC_START_UP_CONTROLLERS="GET_MSDC_START_UP_CONTROLLERS";
	public static final String CASE_VEHICLE_CONFIG_SCREEN="CASE_VEHICLE_CONFIG_SCREEN";
	public static final String CASE_CONDITION="caseCondition";
	public static final String CASE_DETAILS_STR="caseDetailsString";
	public static final String IS_CASE_VEH_CONFIG="isCaseVehicleConfig";
	public static final String DELETE_CFG_NOT_ALLOWED="DELETE_CFG_NOT_ALLOWED";
		//message history
	public static final String AUTO_HC="autoHC";
	
	public static final String MP_MESSAGE_ID_03_GE="03_GE";
	
	public static final String AUTO_HC_REQUESTOR="AUTO HC REQUESTOR";
	
	public static final String MESSAGE_ID_LIST="messageIdList";
	public static final String MSG_TITLE="msgTitle";
	public static final String INTERNAL_EXTERNAL_USERS="Internal and External";
	public static final String EXTERNAL_USERS="External";
	public static final String SAMPLE_MSG_ID_LIST="215637,214680,214670,214607,214596,214585,214574,214561,214551,214541,214531,214520,214508,214499,214490,214477,214466,214451,214441,214431,214418,214408,214396,214388,214375,214317,214306,214293,214281,214271,214260,214251,214240,214228,214218,214208,214196,214186,214177,214167,214155,214146,214132,214122,214109,214100,214089,214077,214065,214053,214041,214032,214019,214007,213998,213984,213972,213963,213949,213939,213927,213916,213905,213896,213884,213867,213857,213847,213838,213825,213811,213800,213787,213771,213761,213745,213732,213720,213702,213635,213623,213612,213600,213585,213577,213568,213554,213543,213536,213526,213513,213500,213440,213428,213419,213407,213396,213350,213342,213330,213320,213302,213291,213282,213271,213196,213185,213176,213164,213107,213097,213088,213079,213004,213000,212996,212991,212987,212984,212917,212910,212906,212904,212899,212895,212885,212877,212872,212869,212864,212825,212821,212815,212811,212808,212804,212801,212798,212790,212788,212785,212781,212777,212772,212767,212762,212760,212754,212724,212720,212717,212712,212708,212701,212693,212666,212636,212632,212628,212625,212621,212616,212613,212610,212516,212508,212491,212488,212484,212477,212473,212468,212464,212422,212419,212417,212413,212408,212404,212401,212396,212393,212387,212385,212382,212378,212375,212369,212365,212363,212358,212344,212340,212335,212331,212328,212323,212320,212307,212303,212298,212292,212285,212277,212270,212263,212257,212247,212242,212234,212229,212223,212215,212210,212204,212191,212185,212178,212171,212166,212159,212155,212150,212141,212136,212127,212122,212115,212108,212103,212098,212091,212085,212078,212073,212068,212059,212053,212047,212043,212039,212030,212024,212019,212013,212005,212000,211994,211988,211982,211975,211970,211964,211958,211951,211945,211938,211932,211926,211920,211914,211909,211902,211893,211888,211883,211876,211872,211865,211859,211852,211843,211837,211832,211825,211820,211813,211806,211799,211793,211789,211784,211777,211772,211766,211757,211750,211744,211739,211734,211726,211720,211715,211709,211704,211696,211683,211678,211634,211590,211586,211577,211574,211561,211554,211549,211544,211540,211533,211528,211525,211521,211516,211511,211508,211503,211500,211493,211490,211487,211483,211481,211474,211470,211465,211460,211454,211446,211441,211437,211432,211427,211424,211420,211416,211408,211400,211398,211392,211387,211382,211379,211375,211372,211365,211362,211358,211355,211350,211343,211340,211335,211331,211329,211325,211320,211316,211312,211309,211306,211303,211298,211295,211289,211284,211279,211274,211271,211266,211264,211258,211254,211251,211247,211241,211237,211231,211172,211165,211153,211148,211136,211125,211119,211098,211085,211072,211065,211061,211056,211054,211049,211041,211031,211027,211019,211014,211009,211006,211000,210997,210991,210988,210981,210973,210969,210961,210950,210944,210939,210900,210847,210837,210831,210814,210789,210783,210779,210723,2311512,210717,210715,210712,210707,210706,210702,210698,210694,210690,210687,210682,210676,210671,210666,210657,210635,210629,210620,210614,210609,210587,210574,210566,210552,210539,210527,210493,210442,210427,210415,210401,210366,210329,210292";


	//REclose
	public static final String RX_CLOSED="rxClosedFlag";
	public static final String RX_OPEN_COUNT="rxOpenCount";
	public static final String RECLOSE_CASE="/reCloseCase";
	public static final String SUPER_CLOSE="superClose";
	public static final String NO_ACTION = "No Action";
	public static final String ENABLED_RECLOSE_BUTTON = "/getEnableRecloseButton";
	
	public static final String SUBMENU_ADMINISTRATION_NOTIFICATIONS_ALERT_SUBSCRIPTION_MODEL = "SUBMENU_ADMINISTRATION_NOTIFICATIONS_ALERT_SUBSCRIPTION_MODEL";
	public static final String ADMIN_ALERT_SUBSCRIPTION_MODEL_COMPONENT = "adminalertSubscriptionModelComponent";
	public static final String PAGE_FLAG = "pageflag";
	
	//Custom Rx
	public static final String RX_TYPE_STANDARD="Standard";
	//Message History

	public static final String DEFAULT_DEVICE = "device";
	public static final String DEVICES_LIST="allDevices";
	public static final String GE_USER="-GE";
	public static final String EXTERNAL_USER="-Customer";
	
	//PPHeaderSerach
	public static final String REQ_URI_PPHEADERSEARCH="/getPPSearchData";
	public static final String TAB_NAME="tab";
	public static final String STICKY_TAB_NAME="stickyTab";
	public static final String PP_ASSET_RESPONSE_LENGTH ="ppassetResponseLength";
	
	//Urgency of Repair details
	public static final String REQ_URI_GET_URGENCY_REPAIR_LIST="/getUrgencyList";
	public static final String REQ_URI_GET_EST_REPAIR_TIME="/getEstimationRxTime";
	public static final String URGENCY_OF_REPAIR_DETAILS="URGENCY_OF_REPAIR_DETAILS";
	public static final String ESTIMATED_TIME_TO_REPAIR_DETAILS="ESTIMATED_TIME_TO_REPAIR_DETAILS";
	
	//Mass Apply Rx feature - Added by Mohamed
    public static final String FETCH_NOT_SHIPPED_ASSET_DETAILS="/fetchNotShippedeAssetDetails";


	//message history changes
    public static final String INTERNAL_AUTO_REQUESTS="Internal and Auto";
    public static final String INTERNAL_REQUESTS="Internal";
    public static final String EXTERNAL_AUTO_REQUESTS="External and Auto";
    public static final String FAILURE_GE="failure-GE";
    public static final String FAILURE_CUSTOMER="failure-Customer";

	// Config Geofence
	public static final String REQ_URI_CFG_GEOFENCE = "/configGeofence";
	public static final String REQ_URI_DELETE_PROXIMITY = "/deleteProximity";
	public static final String CONFIG_GEOFENCE = "configGeofence";
	public static final String GET_CFG_STATUS_TYPES = "/getCfgStatusList";
	public static final String CFG_GEOFENCE_STATUS_TYPE_LIST = "CFG_GEOZONE_STATUS_TYPE_LIST";
	public static final String REQ_URI_GET_PROXIMITY_DETAILS = "/getProximityDetails";
	public static final String PROXMITY_STATUS = "proxStatus";
	public static final String MILEPOST_STATUS = "milePostStatus";
	public static final String REQ_URI_UPDATE_PROXIMITY = "/updateProximity";
	public static final String REQ_URI_ADD_NEW_PROXIMITY = "/addNewProximity";
	public static final String UPPPER_LEFT_LAT = "upperLeftLat";
	public static final String UPPPER_LEFT_LON = "upperLeftLon";
	public static final String LOWER_RIGHT_LAT = "lowerRightLat";
	public static final String LOWER_RIGHT_LON = "lowerRightLon";
	public static final String PROX_DESC = "proxDesc";
	public static final String PROX_TYPE = "proxType";
	public static final String PROX_PARENT = "proxParent";
	public static final String ARRIVAL_FLAG = "arrivalFlag";
	public static final String DEPARTURE_FLAG = "departureFlag";
	public static final String CONSIST_FLAG = "consistFlag";
	public static final String DWEL_FLAG = "dwelFlag";
	public static final String INTERCHANGE_FLAG = "interChangeFlag";
	public static final String SMPP_PROX_ID = "smmppProxId";
	public static final String PROX_OBJ_ID = "proxObjId";
	public static final String ACTIVE_FLAG = "activeFlag";
	public static final String CUST_PROX_ID = "custProxId";
	public static final String REQ_URI_GET_MILEPOST_DETAILS = "/getMilePostDetails";
	public static final String REQ_URI_UPDATE_MILEPOST = "/updateMilePost";
	public static final String MILEPOST_ID = "milePostId";
	public static final String MILEPOST_DESC = "milePostDesc";
	public static final String STATE_PROVINCE = "stateProvince";
	public static final String SUB_REGION = "subRegion";
	public static final String REQ_URI_ADD_NEW_MILEPOST = "/addNewMilePost";
	public static final String REQ_URI_DELETE_MILEPOST = "/deleteMilePost";
	public static final String MILEPOST_OBJ_ID = "milePostObjId";
	public static final String GET_STATE_PROVINCE = "/getStateProvince";
	public static final String GET_PROXIMITY_TYPES = "/getProximityTypes";
	public static final String CFG_GEOFENCE_PROXIMITY_TYPE_LIST = "CFG_GEOZONE_PROXIMITY_TYPE_LIST";
	public static final String GET_PROXIMITY_PARENT = "/getProximityParent";
	public static final String ADD_REGION_SUB_REGION = "/addRegionSubregion";
	public static final String EXPORT_PROXIMITY_DETAILS = "/exportProximityConfigs";
	public static final String PROXIMITY_LIST = "proximityVOList";
	public static final String PROXIMITY_EXPORT_FILENAME = "ProximityList.csv";
	public static final String PROXIMITY_REPORT_HEADER = "proximityReportHeader";
	public static final String EXPORT_MILEPOST_DETAILS = "/exportMilePostConfigs";
	public static final String GET_SUB_REGION = "/getSubRegion";
	public static final String GET_REGION = "/getRegion";
	public static final String MILEPOST_LIST = "milePostVOList";
	public static final String MILEPOST_EXPORT_FILENAME = "MilePostList.csv";
	public static final String MILEPOST_REPORT_HEADER = "milePostReportHeader";
	
	// Added by Vamshi For Notify Config Screen

	public static final String GET_NOTIFY_CONFIGS = "/getNotifyConfigs";
	public static final String ADD_NOTIFY_CONFIG = "/addNotifyConfig";
	public static final String UPDATE_NOTIFY_CONFIG = "/updateNotifyConfig";
	public static final String GET_THRESHOLDS = "/getThresholds";
	public static final String GET_NOTIFY_FLAGS = "/getNotifyFlags";
	public static final String GET_CUSTOMER_MODELS="/getCustomerModels";
	public static final String NOTIFY_CFG_VO_LIST = "notifyCfgVOList";
	public static final String NOTIFY_CFG_FILE_NAME = "NotifyConfigs.csv";
	public static final String EXPORT_NOTIFY_CONFIGS = "/exportNotifyConfigs";
	public static final String NOTIFY_CFG_HEADER="notifyCfgHeader";
	public static final String THRESHOLD="THRESHOLD";
	public static final String INVALID_THRESHOLD="INVALID_THRESHOLD";
	public static final String MODEL_NOT_PROVIDED="MODEL_NOT_PROVIDED";
	public static final String THRESHOLD_NAME_NOT_PROVIDED="THRESHOLD_NAME_NOT_PROVIDED";
	public static final String THRESHOLD_VALUE_NOT_PROVIDED="THRESHOLD_VALUE_NOT_PROVIDED";
	public static final String FLAG_NAME_NOT_PROVIDED="FLAG_NAME_NOT_PROVIDED";
	public static final String FLAG_VALUE_NOT_PROVIDED="FLAG_VALUE_NOT_PROVIDED";
	public static final String SELECT_FLAG_OR_THRESHOLD="SELECT_FLAG_OR_THRESHOLD";
	
	//pop up list admin screen
	public static final String ADD_POPUP_LIST_VALUES = "/savePopupList";
	public static final String GET_POPUP_LIST_VALUES = "/getPopupListValues";
	public static final String ADD_POPUP_LOOK_VALUES = "/savePopupListlookvalue";
	public static final String UPDATE_POPUP_LIST = "/updatePopupList";
	public static final String DELETE_POPUP_LIST = "/deletePopUpList";
	public static final String REMOVE_POPUP_LOOK_VALUES ="/removePopupListlookvalue";
	public static final String DELETE_POPUP_LIST_VALUES = "/deletePopUpListValues";
	public static final String UPDATE_POPUP_LIST_VALUE = "/updatePopupListValues";
	public static final String POUP_SEARCHBY = "searchBy";
	public static final String POUP_CONDITION = "Condition";
	public static final String POUP_VALUE = "value";
	public static final String POUP_LIST_NAME = "listName";
	public static final String POUP_LIST_DESCRIPTION = "listDescription";
	public static final String REQ_URI_POP_UP_LIST_ADMIN="/popUpListAdmin";
	public static final String POP_UP_LIST_ADMIN="popUpListAdmin";
	public static final String GET_SEARCH_BY_OPTIONS="/getpopupListAdminSearchByOptions";
	public static final String POPUPLISTADMIN_SEARCH_OPTIONS="POPUPLISTADMIN_SEARCH_OPTIONS";
	public static final String GET_CONDITION_OPTIONS="/getpopupListAdminConditionOptions";
	public static final String POPUPLISTADMIN_CONDITION_OPTIONS="POPUPLISTADMIN_CONDITION_OPTIONS";
	public static final String GET_SHOW_ALL="/getShowAll";
	public static final String GET_LIST="/getList";
	public static final String POPUP_SEQ_ID="getSysLookupSeqId";
	public static final String POPUP_LISTNAME="listName";
	public static final String POPUP_DES="listDescription";
	public static final String POPUP_SORTORDER="sortOrder";
	public static final String POPUP_LOOKVALUE="lookValue";
	public static final String POPUP_LOOKSTATE="lookState";
	public static final String POPUPLISTADMIN_SEARCHBY="popupSearchBy";
	public static final String POPUPLISTADMIN_CONDITION="popupCondition";
	public static final String POPUPLISTADMIN_VALUE="popupvalue";
	public static final String OLD_LIST_NAME = "oldListName";
	public static final String REQ_PARAM_LOOKUPVAL="popuplistValues";
	// Find/Add notes changes
	public static final String ADD_NOTES_TO_UNIT="/addNotesToUnit";
	public static final String FETCH_UNIT_LEVEL_STICKY_DETAILS="/fetchStickyUnitLevelNotes";
	public static final String NO_OF_UNITS="noOfUnits";
	
	//aurizon metrics conversion
    public static final String EMPTY_DECIMAL =".000";
	public static final String COLUMN_NAME ="columnName";
	public static final String SCREEN_NAME ="screenName";
	public static final String COLUMN_VELOCITY ="Velocity";
	public static final String COLUMN_DISTANCE ="Distance";
	public static final String COLUMN_FUEL_LEVEL ="Fuel_level";
	public static final String HISTORY_SCREEN ="History";
	public static final String OVERVIEW_SCREEN ="Overview";
	public static final String GEOFENCE_SCREEN ="Geofence";
	public static final String ATSOVERVIEW_SCREEN ="ATSOverview";
	public static final String ATSHISTORY_SCREEN ="ATSHistory";
	public static final String PROXIMITY_SCREEN ="Proximity";
	public static final String IDLEREPORT_SCREEN ="IdleReport";
	public static final String NOTIFICATION_SCREEN ="Notification";
	public static final String VELOCITY ="mph";
	public static final String FUEL_LEVEL ="gals";
	public static final String MILEPOST_DEFAULT_RECORDS = "mpDefaultRecords";
	public static final String MILEPOST_TABLE_DEFAULT_RECORDS = "MILEPOST_TABLE_DEFAULT_RECORDS";
	public static final String KEP_MODELS = "KEP_MODELS";
	public static final String STR_LEVEL = "level";
	public static final String EMETRICS_URL="EMETRICS_URL";
	public static final String OIL_FAULTS_URL="OIL_FAULTS_URL";   
	public static final String STR_OIL_FAULT_URL="oilFaultsUrl";
	public static final String STR_EMETRICS_URL="emetricsUrl";
	public static final String ALL_RULE_TYPE_PRIVILEGE = "ALL_RULE_TYPE_PRIVILEGE";
	public static final String IS_GE_ROLE = "isGERole";
	public static final String STR_MULTILINGUAL_URL="multilingualRxUrl";
	public static final String MULTILINGUAL_RX_URL="MULTILINGUAL_RX_URL";
	
	//GPOC Smart Shops
	public static final String GPOC_SMART_SHOP_VOTES = "GPOC_SMART_SHOP_VOTES";
	public static final String GET_GPOC_SMART_SHOP_VOTES="/getGPOCSmartShopVotes";
	public static final String CAST_GPOC_VOTE="/castGPOCVote";
	public static final String GET_PREVIOUS_VOTE="/getPreviousVote";
	public static final String REPAIR_CODE="repairCode";
	// added by sonal as the part of DE38547
    public static final String PP_DEFAULT_RECORDS = "ppDefaultRecords";
    public static final String PP_ASET_HDR_TABLE_DEFAULT_RECORDS = "PP_ASET_HDR_TABLE_DEFAULT_RECORDS";
    //Repair Facility Maintenance
	public static final String REQ_URI_REPAIR_FACILITY="/repairFacilityMaintenance";
	public static final String REPAIR_FACILITY = "repairFacilityMaintenance";
	public static final String GET_CUST_SITES = "/getCustomerSites";
	public static final String GET_REPAIR_FACILITY_STATUS = "/getRepairFacilityStatus";
	public static final String REQ_URI_GET_REPAIR_FACILITY_DETAILS = "/getRepairFacilityDetails";
	public static final String REQ_URI_INSERT_REPAIR_SITE_LOCATION = "/insertRepairSiteLoc";
	public static final String REQ_URI_UPDATE_REPAIR_SITE_DETAILS = "/updateRepairSiteLoc";		
	public static final String SITE = "site";		
	public static final String RAILWAY_DESIG_CODE = "railWayDesigCode";
	public static final String REPAIR_LOCATION = "repairLocation";
	public static final String LOCATION_CODE = "locationCode";
	public static final String REPAIR_FACILITY_STATUS_TYPE_LIST = "REPAIR_FACILITY_STATUS_TYPE_LIST";
	//Customer Date Changes
	public static final String CUSTOMER_DATE_FORMAT="customerDateFormat";

	//Added for EMAIL Changes
	public static final String EMAIL_ID="emailId";
	
	//repair code maintenance.
	public static final String REQ_URI_REPAIRCODE_MAINTENANCE = "/repairCodeMaintenance";
	public static final String REPAIRCODE_MAINTENANCE = "repairCodeMaintenance";
	public static final String GET_REPAIRCODE_SELECT_BY_OPTIONS="/getRepairCodesSelectBy";
	public static final String REPAIRCODE_SELECT_BY_OPTIONS="REPAIRCODE_SELECT_BY_OPTIONS";
	public static final String GET_REPAIRCODE_STATUS_OPTIONS="/getRepairCodesStatus";
	public static final String REPAIRCODE_STATUS_OPTIONS="REPAIRCODE_STATUS_OPTIONS";
	public static final String GET_REPAIRCODE_LIST="/getRepairCodesList";
	public static final String REPAIRCODE_VALIDATIONS="/repairCodeValidations";
	public static final String REPAIR_CODE_DESC="repairCodeDesc";
	public static final String ADD_REPAIR_CODES="/addRepairCodes";
	public static final String UPDATE_REPAIR_CODES="/updateRepairCodes";
	public static final String GET_REPAIRCODE_CONDITION_OPTIONS="/getRepairCodesConditions";
	public static final String REPAIRCODE_CONDITION_OPTIONS="REPAIRCODE_CONDITION_OPTIONS";
	
	
	//healthcheck changes
	public static final String REQ_URI_VIEW_HC = "/healthcheck";
	public static final String VIEW_HC="healthcheck";
	public static final String INTERNAL_HC="internalHC";
	public static final String EXTERNAL_HC="externalHC";
	public static final String GET_CUSTOMER_RNH_VALUES="/getCustNameRNHValues";
		
	//BOM Maintenance
	public static final String REQ_URI_VIEW_BOM_MAINTENANCE = "/viewBOMMaintanence";
	public static final String BOM_MAINTENANCE = "bomMaintenance";
	public static final String REQ_URI_GET_BOM_CONFIG_LIST = "/getConfigList";
	public static final String EST_TIMEZONE = "Canada/Eastern";
	public static final String POPULATE_CONFIG_DETAILS = "/populateConfigDetails";
	public static final String CONFIG_ID="configId";
	public static final String REQ_URI_GET_BOM_CONFIG_ITEMS="getConfigItemsList";
	public static final String CONFIGURATION_ITEM="Configuration Item";
	public static final String REQ_URI_GET_PARAMETER_LIST="getParameterList";
	public static final String REQ_URI_SAVE_BOM_DETAILS="/saveBOMDetails";
	public static final String REQ_URI_WELCOME_PAGE="/welcomeOMD";
	public static final String WELCOME_PAGE = "welcomePage";
	//config maintenance
	public static final String REQ_URI_CONFIG_MAINTENANCE = "/configMaintenance";
	public static final String CONFIG_MAINTENANCE = "configMaintenance";
	public static final String REQ_URI_GET_CONTROLLER_CONFIGS = "/getCtrlCfgs";
	public static final String REQ_URI_GET_CONTROLLER_CONFIG_FILES = "/getCtrlCfgFiles";
	public static final String REQ_URI_GET_CONFIG_TEMPLATE_DETAILS = "/getCfgTempalteDetails";
	public static final String CTRL_CFG_OBJ_ID = "ctrlCfgObjId";
	public static final String CFG_FILE_NAME = "cfgFileName";
	public static final String CTRL_CFG_FILE_NAMES_LIST = "CTRL_CFG_FILE_NAMES_LIST";
	public static final String REQ_URI_CREATE_EFI = "/showCreateEFIPage";
	public static final String CREATE_EFI = "createEFI";
	public static final String REQ_URI_GET_EFI_DETAILS = "/getEFIDetails";
	public static final String REQ_URI_VIEW_FFD_TEMPLATE_PAGE = "/viewFFDTemplatePage";
	public static final String REQ_URI_VIEW_FRD_TEMPLATE_PAGE = "/viewFRDTemplatePage";
	public static final String GET_MAXIMUM_TEMPLATE = "/getMaximumTemplete";
	public static final String GET_CURRENT_TEMPLATE = "/getCurrentTemplete";
	public static final String FAULT_RANGE_DEF = "faultRangeDef";
	public static final String FAULT_FILTER_DEF = "faultFilterDef";
	public static final String CONFIG_OPERTORS = "Config_Operators";
	public static final String CONFIG_CONJUNCTION = "Config_Conjunction";
	public static final String TEMPLATE_ID="templateId";
	public static final String VERSION_ID="versionId";
	public static final String CONFIG_VALUE="configValue";
	public static final String POPULATE_FFD_DETAILS="/populateFFDDetails";
	public static final String POPULATE_FRD_DETAILS="/populateFRDDetails";
	public static final String SAVE_FFD_TEMPLATE="/saveFFDTemplate";
	public static final String SAVE_FRD_TEMPLATE="/saveFRDTemplate";
	public static final String REMOVE_FRD_TEMPLATE="/removeFRDTemplate";
	public static final String REMOVE_FFD_TEMPLATE="/removeFFDTemplate";
	public static final String OBJID="objId";
	public static final String GET_PARAMETER_TITLE="/getParameterTitle";
	public static final String GET_OPERATOR_LIST="/getOperatorList";
	public static final String GET_CONJUNCTION_LIST="/getConjunctionList";
	public static final String GET_EDP_TEMPLATE="/getEDPTemplate";
	public static final String GET_FAULT_SOURCE="/getFaultSource";
	public static final String GET_DEFAULT_VALUES_RANGE="/getDefaultValuesRange";
	public static final String GET_MAX_VERSION="/getMaxVersion";
	public static final String CONFIG_FILE="configFile";
	public static final String TITLE="title";
	public static final String GET_CURRENT_STATUS="/getCurrentStatus";
	public static final String GET_TITLE="/getTitle";
	public static final String DOT=".";
	public static final String GET_STATUS_DETAILS="/getStatusDetails";
	public static final String CHECK_FAULT_RANGE="/checkFaultRange";
	public static final String GET_MAX_PARAMETER_COUNT="/getMaxParameterCount";
	//config maintenance
	public static final String CREATE_NEW_EFI = "/createNewEFI";
	public static final String REQ_URI_GET_CTRL_CFG_STATUS = "/getCtrlCfgStatus";
	public static final String REQ_URI_GET_EDP_SEARCH_BY_LIST = "/getEDPSearchByList";
	public static final String REQ_URI_GET_EDP_CONDITION_LIST = "/getEDPConditionList";
	public static final String CTRL_CFG_STATUS_LIST = "CONTROLLER_CONFIG_STATUS_LIST";
	public static final String CTRL_CFG_SEARCH_BY_LIST="CONTROLLER_CONFIG_EDP_SEARCH_BY_LIST";
	public static final String CTRL_CFG_CONDITION_LIST="CONTROLLER_CONFIG_EDP_CONDITION_LIST";
	public static final String REQ_URI_GET_MAX_TEMPLATE_NUMBER = "/getMaxTemplateNumber";
	public static final String REQ_URI_GET_TEMPLATE_MAX_VER_NUMBER = "/getTempMaxVerNumber";
	public static final String TEMPLATE_NO = "templateNo";
	public static final String CONDITION = "condition";
	public static final String SEARCH_VAL = "searchVal";
	public static final String REQ_URI_GET_ADDED_EDP_PARAMS = "/getAddedEDPParams";
	public static final String TEMP_OBJ_ID = "tempObjId";
	public static final String ADD_UPDATE_EDP_TEMPLATE = "/addUpdateEDPTemplate";
	public static final String PARAM_OBJ_ID = "paramObjId";
	public static final String VERSION_NO = "versionNo";
	public static final String WHAT_NEW = "whatNew";
	public static final String REQ_URI_OPEN_EDP_TEMPLATE = "/openEDPTemplate";
	public static final String REQ_URI_ADD_UPADTE_EDP_TEMPLATE = "/addUpdateEDPTemplate";
	public static final String ADD_UPDATE_EDP = "addUpdateEDP";
	public static final int INT_ONE = 1;
	public static final String CTRL_CFG_NAME = "ctrlCfgName";
	public static final String REQ_URI_GET_EDP_PARAM_DETAILS = "/getEDPParamDetails";
	public static final String IS_OPEN_TEMPLATE = "IS_OPEN_TEMPLATE";
	public static final String MAX_VERSION = "maxVersion";
	public static final String GET_PRE_NEXT_EDP_DETAILS = "/getPreNextEDPDetails";
	public static final String EDP_MAX_PARAMS = "edpMaxParams";
	public static final String MAX_CONFIG_FILE_PARAMS_ALLOWED = "MAX_CONFIG_FILE_PARAMS_ALLOWED";
	public static final String ADDED_PARAM_OBJ_ID = "addedObjIdList";
	public static final String REMOVED_PARAM_OBJ_ID = "removedObjIdList";
	public static final String TEMPLATE_LIST = "templateList";
	public static final String CFG_TEMPLATE_EXPORT_FILENAME = "CtrlCfgTemplates.csv";
	public static final String CTRL_CFG_TEMPLATES_REPORT_HEADER = "ctrlCfgTemplatesHeader";
	public static final String EXPORT_CFG_TEMPLATES = "/exportCfgTemplates";
	//Delete configuartion
	public static final String GET_DELETE_CONFIG_PAGE="/deleteConfig";
	public static final String DELETE_CONFIG="deleteConfig";
	public static final String GET_CONTROLLER_CONFIGURATIONS="/getControllerConfigs";
	public static final String GET_CONTROLLER_CONFIGURATION_TEMPLATES="/getControllerConfigTemplates";
	public static final String CONTROLLER_CONFIGURATION="cntrlCnfg";
	public static final String CONFIGURATION_FILE="cnfgFile";
	public static final String DELETE_VEHICLE_CFG="/deleteVehicleCfg";
	
	// Added for LocoVision Aurizon Project
	public static final String REQ_URI_GET_LDVR_REQUEST = "/getLDVRRequestPage";
	public static final String REQ_URI_SUBMIT_LDVR_REQUEST = "/submitLDVRRequest";
	public static final String REQ_URI_GET_LDVR_CAMERA_DETAILS = "/getLDVRCameraDetails";
	public static final String REQ_URI_GET_ACTIVE_PRESERVATION_DATA = "/getActivePreservationData";
	public static final String REQ_URI_CHECK_ACTIVE_LDVR_PRESERVATION_REQUESTS = "/checkActiveLDVRPreservationRequests";
	public static final String REQ_URI_REMOVE_TEMPLATE = "/removeTemplate";
	public static final String VIEW_LDVR_REQUESTS = "ldvrRequests";
	public static final String LDVR_INTERNAL_MEMORY = "internalMemory";
	public static final String LDVR_NETWORK_MEMORY = "networkMemory";
	public static final String LDVR_REQ_URI_LDVR_DATA_REQUEST = "ldvrDataRequest";
	public static final String LDVR_REQ_URI_LDVR_MEDIA_REQUEST = "ldvrMediaRequest";
	public static final String LDVR_CAMERAS = "cameras";
	public static final String LDVR_SELECTED_CAMERAS = "selectedCameras";
	public static final String REQ_URI_LDVR_PRESERVATION_REQUEST = "/ldvrPreservationRequest";
	public static final String LDVR_REQUEST_TITLE = "requestTitle";
	public static final String LDVR_REQUEST_START_TIME = "requestStartTime";
	public static final String LDVR_REQUEST_END_TIME = "requestEndTime";
	public static final String REQ_URI_GET_LDVR_GEOFENCE = "/getLDVRGeofencePage";
	public static final String VIEW_LDVR_GEOFENCE = "ldvrGeofence";
	public static final String REQ_URI_GET_LDVR_GEOFENCE_LIST = "/getLDVRGeofenceList";
	public static final String REQ_URI_SAVE_UPDATE_LDVR_GEOFENCE = "/saveUpdateLDVRGeofence";
	public static final String REQ_URI_UPDATE_GEOFENCE_STATUS = "updateGeofenceStatus";
	public static final String REQ_URI_GET_LDVR_STATUS_LIST = "/getLDVRStatusList";
    public static final String REQ_URI_GET_MANAGE_LDVR_REQUEST ="/getManageLDVRRequestPage";
    public static final String VIEW_MANAGE_LDVR_REQUEST =  "manageLDVRRequest";
    public static final String REQ_URI_GET_LDVR_STATUS_PAGE ="/getLDVRStatusPage";
    public static final String REQ_URI_GET_LDVR_STATUS ="/getLDVRStatus";
    public static final String VIEW_LDVR_STATUS =  "ldvrStatus";
    public static final String REQ_URI_IMPORT_GEOFENCE= "/importGeofence";
    public static final int ONE =  1;				

	public static final String LDVR_SEND_MESSAGE_SERVICE_URL ="LDVR_MCS_SENDMESSAGE_URL";	
	public static final String LDVR_GET_NUM_CAMERAS_URL = "LDVR_MCS_CAMERA_DETAILS_URL";
	public static final String LDVR_MCS_GET_ACTIVE_PRESERVATION_DATA_URL = "LDVR_MCS_GET_ACTIVE_PRESERVATION_DATA_URL";
	public static final String LDVR_MCS_REMOVE_TEMPLATE_URL = "LDVR_MCS_REMOVE_TEMPLATE_URL";
	public static final String LDVR_MCS_CHECK_ACTIVE_LDVR_PRESERVATION_REQUEST_URL = "LDVR_MCS_CHECK_ACTIVE_LDVR_PRESERVATION_REQUEST_URL";
	
	public static final String LDVR_MCS_GET_GEOZONES_URL = "LDVR_MCS_GET_GEOZONES_URL";
	public static final String LDVR_MCS_SAVEUPDATE_GEOZONES_URL = "LDVR_MCS_SAVEUPDATE_GEOZONES_URL";
	
	public static final String LDVR_ASSET_OWNERID = "assetOwnerId";
	public static final String LDVR_ROAD_INITIAL = "roadInitial";
	public static final String LDVR_ROAD_NUMBER = "roadNumber";
	public static final String LDVR_DEVICE = "device";
	
	public static final String REQ_URI_GET_LDVR_MSG_HISTORY = "/getLDVRMessageHistoryPage";
	public static final String VIEW_LDVR_MSG_HISTORY = "ldvrMessageHistory";
	
	public static final String GET_LDVR_MESSAGE_ID="/getLDVRMessageID";
	
	public static final String LDVR_IMPORTANCE = "importance";
	public static final String LDVR_DELETION_TYPE = "deletionType";
	public static final String GEOFENCE_ACTIVE_FLG = "activeFlag";
	public static final String GEOFENCE_ACTIVE = "active";
	

	public static final String GEOFENCE_OBJID = "geozoneObjId";
	public static final String GEOFENCE_ID = "geozoneId";
	public static final String LATITUDE1 = "lattitude1";
	public static final String LONGITUDE1 = "longitude1";
	public static final String LATITUDE3 = "lattitude3";
	public static final String LONGITUDE3 = "lattitude3";	
	public static final String ACTION_TYPE= "actionType";
	public static final String GEOFENCELIST = "geofenceList";

	public static final String REQ_URI_GET_LDVR_MSG_HISTORY_DETAILS = "/getLDVRMessageHistory";	
	public static final String LDVR_MESSAGETYPE = "messageType";
	public static final String LDVR_DIRECTION = "direction";
	public static final String LDVR_STATUS = "status";
	public static final String LDVR_TIMERANGE = "timeRange";
	public static final String LDVR_MCS_GET_MESSAGE_HISTORY = "LDVR_MCS_GET_MESSAGE_HISTORY";
	public static final String LDVR_TIMERANGE_DEFAULT = "3";
	public static final String LDVR_MESSAGE_HISTORY_LIST = "ldvrmessageHistList";
	public static final String LOCO_VISION_PRIVILEGE = "LOCO_VISION_PRIVILEGE";
	public static final String IS_LOCO_VISION_PRIVILEGE = "isLocoVisionPrivilege";
	public static final String EXPORT_LDVR_MESSAGE_HISTORY = "/exportLDVRMessageHistory";	
	public static final String LDVR_MESSAGE_HISTORY_HEADER="LDVRMsgHistoryHeader";
	public static final String LDVR_MESSAGE_HISTORY_EXPORT_FILENAME = "ldvrMessageHistory.csv";
	public static final String EXPORT_LDVR_GEOFENCE = "/exportLDVRGeofence";
	public static final String LDVR_GEOFENCE_HEADER="LDVRGeofenceHeader";
	public static final String LDVR_GEOFENCE_EXPORT_FILENAME = "ldvrGeozone.csv";

	public static final String REQ_URI_GET_LDVR_TEMPLATE_LIST = "/getLDVRTemplateList";
	public static final String LDVR_TEMPLATE_NUMBER = "templateNumber";
	public static final String LDVR_TEMPLATE_VERSION = "templateVersion";
	public static final String LDVR_TEMPLATE_DESCRIPTION = "templateDescription";
	public static final String LDVR_TEMPLATE_STATUS = "templateStatus";
	
	public static final String LDVR_GET_TEMPLATE_URL = "LDVR_GET_TEMPLATE_URL";	
	public static final String LDVR_TEMPLATE_REQUEST_TYPE = "ldvr_preserv_download";
	public static final String EXPORT_LDVR_REQUEST = "/exportLDVRRequest";	
	public static final String LDVR_REQUEST_HEADER="LDVRRequestHeader";
	public static final String LDVR_REQUEST_EXPORT_FILENAME = "ldvrRequest.csv";
	public static final String GEOFORMAT = "###.######";
	public static final String REQ_URI_CHECK_LCV_LDVR_REQUEST = "/checkLCVLDVRStatus";	
	public static final String CHECK_LCV_LDVR_REQUEST_TYPE = "SNAPSHOT";	
	public static final String LDVR_MCS_GET_ASSET_SNAPSHOT_URL = "LDVR_MCS_GET_ASSET_SNAPSHOT_URL";
	public static final String LCV_DEVICE_TYPE = "LCV";
	public static final String LDVR_SAVE_TEMPLATE_URL = "LDVR_SAVE_TEMPLATE_URL";
	public static final String LDVR_MCS_GET_ASSET_STATUS_URL= "LDVR_MCS_GET_ASSET_STATUS_URL";
	public static final String LOCOVISION_TABS= "LOCO_VISION_TABS";
	public static final String REQ_URI_GET_LDVR_APPLY_TEMPLATE_PAGE ="/getLDVRApplyTemplatePage";
	public static final String VIEW_LDVR_APPLY_TEMPLATE =  "ldvrApplyTemplate";
	public static final String REQ_URI_GET_LDVR_MASTER_DATA = "/getMasterData"; // below lines added on 6th Sep 16
	public static final String REQ_PARAM_MASTER_DATA_SET = "masterDataSet";
	public static final String LDVR_GET_MASTER_DATA_URL = "LDVR_GET_MASTER_DATA_URL";
	public static final String REQ_URI_GET_LDVR_SAVE_UPDATE_TEMPLATE = "/saveUpdateLDVRTemplate"; // below lines added on 6th Sep 16		
	public static final String LDVR_MCS_APPLY_TEMPLATE_URL = "LDVR_MCS_APPLY_TEMPLATE_URL";
    public static final String REQ_URI_GET_ASSET_GROUP_APPLY_TEMPLATE ="/ldvrAssetGroupApplyTemplate";
    public static final String LOCOVISION_DATE_FORMAT ="locoDateFormat";
	public static final String MESSAGE_PRIORITY ="messagePriority";
	public static final String LCV_DEVICE = "CMU";
	public static final String REQ_URI_GET_LDVR_TIME ="/getLDVRTime";
	public static final String LDVR_TEMPLATE_OBJID ="templateObjId";
	public static final String INACTIVE ="Inactive";
	public static final String REQ_URI_GET_LDVR_ASSET_TEMPLATE_LIST ="/getAssetTemplateList";
	public static final String TEMPLATE_REQUEST_TYPE ="TEMPLATE";
	public static final String REQ_URI_GET_LDVR_ASSET_APPLY_TEMPLATE_PAGE ="/getLDVRAssetApplyTemplatePage";
	public static final String VIEW_LDVR_ASSET_APPLY_TEMPLATE =  "ldvrAssetApplyTemplate";
	public static final String LDVR_MCS_GET_ASSET_TEMPLATE_LIST_URL="LDVR_MCS_GET_ASSET_TEMPLATE_LIST_URL";	
	public static final String REQ_URI_REAPPLY_REMOVE_ASSET_TEMPLATE ="/ldvrReApplyRemoveAssetTemplate";
	public static final String LDVR_MCS_REAPPLY_REMOVE_ASSET_TEMPLATE_URL= "LDVR_MCS_REAPPLY_REMOVE_ASSET_TEMPLATE_URL";
	public static final String REAPPLY_TEMPIDS ="lstReApplyTemplateIDs"; 
	public static final String REMOVE_TEMPIDS ="lstRemoveTemplateIDs";
	public static final String LDVR_STATUS_HEADER = "LDVRStatusHeader";
	public static final String EXPORT_LDVR_STATUS = "/exportLDVRStatus";
	public static final String LDVR_STATUS_EXPORT_FILENAME = "ldvrStatus.csv";
	public static final String MANAGE_LDVR_REQUESTS_HEADER = "ManageLDVRHeader";
	public static final String EXPORT_MANAGE_LDVR_REQUESTS = "/exportManageLDVRRequests";
	public static final String MANAGE_LDVR_REQUESTS_EXPORT_FILENAME = "LDVRTemplateList.csv";
	public static final String LDVR_MESSAGE_TYPE_VALUES = "ldvr_data,ldvr_data_response,ldvr_delete_template,ldvr_media,ldvr_media_response,ldvr_preserv_download";
	public static final String MCS_ERROR_MCS00002 = "MCS00002";
	public static final String TEMPLATE_IDS = "templateIds";
	
	public static final String MULTIUSERSVAL ="multiUsersVal";
	public static final String MULTIUSERSEMAIL ="multiUsersEmail";
	public static final String CONFIG_ALERT ="Config Alerts";
	public static final String CONFIG_ALERT_MODEL_VAL ="configAlertModelVal";
	public static final int MAX_MULTI_USER_SUB_COUNT = 99;
	public static final String ERROR_MAX_MULTI_USER_SUBSCRIBED = "ERROR_MAX_MULTI_USER_SUBSCRIBED";
	public static final String ALERT_ADMIN_SUBSCRIPTION_FLAG= "AdminAlertSubscription";
	

	public static final String ALERT_SUBSCRIPTION_HEADER_WITH_MULTISUB_MODEL = "AlertSubscriptionHeaderMultiSubModel";
	public static final String ALERT_SUBSCRIPTION_HEADER_WITH_MULTISUB_CONFIG_ALERT = "AlertSubscriptionHeaderMultiSubConfigAlert";
	public static final String ALERT_SUBSCRIPTION_HEADER_MULTISUB = "AlertSubscriptionHeaderMultiSub";
	public static final String ALERT_SUBSCRIPTION_HEADER_WITH_MODEL = "AlertSubscriptionHeaderModel";
	public static final String ALERT_SUBSCRIPTION_HEADER_WITH_CONFIG_ALERT = "AlertSubscriptionHeaderSubConfigAlert";
	public static final String ALERT_SUBSCRIPTION_HEADER_WITH_MULTISUB_MODEL_SMS = "AlertSubscriptionHeaderMultiSubModelSMS";
	public static final String ALERT_SUBSCRIPTION_HEADER_WITH_MULTISUB_CONFIG_ALERT_SMS = "AlertSubscriptionHeaderMultiSubConfigAlertSMS";
	public static final String ALERT_SUBSCRIPTION_HEADER_MULTISUB_SMS = "AlertSubscriptionHeaderMultiSubSMS";
	public static final String ALERT_SUBSCRIPTION_HEADER_WITH_MODEL_SMS = "AlertSubscriptionHeaderModelSMS";
	public static final String ALERT_SUBSCRIPTION_HEADER_WITH_CONFIG_ALERT_SMS = "AlertSubscriptionHeaderSubConfigAlertSMS";
	
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SUBJECT_ATS="GE ATS Alert Subscription Addition Notification";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SUBJECT_EOA="GE RX Alert Subscription Addition Notification";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SUBJECT_CONFIGALERT="GE Configurable Alert Subscription Addition Notification";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE="<br/><br/>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE="<br/>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_BOLD_Next_LINE="</b><br/>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART="<br/>You can View/Edit/Delete your subscription by logging on to the OMD portal(";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART_URL=") and accessing 'Alert Subscription' tab.";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RULETITLE="<b>Rule Title: </b>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_ALERTTYPE="<b>Alert Type: </b>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_ASSET="<b>Asset: </b>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_CUSTOMER="<b>Customer: </b>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXFILTER="<b>Rx-Filter: </b>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXURGENCY_TYPE="<b>Urgency Type: </b>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTITLE_TYPE="<b>Title Type: </b>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXLOCO_TYPE="<b>Loco impact Type: </b>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXSUBSYSTEM_TYPE="<b>Subsystem Type: </b>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXFLEET="<b>Fleet: </b>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXASSET="<b>Asset: </b>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXREGION="<b>Region: </b>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXSUBDIVISION="<b>Subdivision: </b>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXSHOP="<b>Shop: </b>";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXMODEL="<b>Model: </b>";
	public static final String CUSTMAILER_DEFAULT_EMAIL_ID="CUSTMAILER_DEFAULT_EMAIL_ID"; 
	public static final String CUSTMAILER_EMAIL_FOOTER="CUSTMAILER_EMAIL_FOOTER"; 
	public static final String ALERT_SUBSCRIPTION_MAILSUBJECT_GE = "GE ";
	public static final String ALERT_SUBSCRIPTION_MAILSUBJECT_ALERT = " Alert Subscription ";
	public static final String ALERT_SUBSCRIPTION_MAILSUBJECT_NOTIFICATION = " Notification";
	public static final String ALERT_SUBSCRIPTION_MAILSUBJECT_RX = "Rx";
	public static final String ALERT_SUBSCRIPTION_MAILSUBJECT_CONFIG = "Configurable";
	public static final String ALERT_SUBSCRIPTION_MAILSUBJECT_ADD = "Addition";
	public static final String ALERT_SUBSCRIPTION_MAILSUBJECT_DELETE = "Deletion";
	public static final String ALERT_SUBSCRIPTION_MAILSUBJECT_ACTIVE = "Activation";
	public static final String ALERT_SUBSCRIPTION_MAILSUBJECT_DEACTIVE = "De-Activation";
	public static final String ALERT_SUBSCRIPTION_MAILSUBJECT_EDIT = "Edit";
	public static final String ALERT_SUBSCRIPTION_MAILSUBJECT_RXLOCOIMPACT = "Loco Impact";
	public static final String ALERT_SUBSCRIPTION_MAILSUBJECT_RXSUB_SYSTEM = "Subsystem";
	public static final String ALERT_SUBSCRIPTION_MAIL_EDIT = "Edit";
	public static final String ALERT_SUBSCRIPTION_MAIL_ADD = "Add";
	public static final String ALERT_SUBSCRIPTION_SERVICE = "service";
	public static final String ALERT_SUBSCRIPTION_USER_EMAIL = "userEmail";
	public static final String ALERT_SUBSCRIPTION_REGIONID = "regionId";
	public static final String ALERT_SUBSCRIPTION_SHOPID = "shopId";
	public static final String ALERT_SUBSCRIPTION_ASSETNUMID = "assetNumId";
	public static final String ALERT_SUBSCRIPTION_CUSTOMER_ALERTOBJID = "customerAlertObjId";
	public static final String ALERT_SUBSCRIPTION_DELIVERY_FRMT = "delivryfrmt";
	public static final String ALERT_SUBSCRIPTION_DELETE = "Delete";
	public static final String ALERT_SUBSCRIPTION_DEACTIVATE = "De activate";
	public static final String ALERT_SUBSCRIPTION_ACTIVATE = "Activate";
	public static final String ALERT_SUBSCRIPTION_FOR = "' For '";
	public static final String SYMBOL_COMMA_SPACE=", ";
	//MassApply Config
	public static final String REQ_URI_MASS_APPLY_CONFIG = "/massApplyCfg";
	public static final String REQ_URI_CASE_MASS_APPLY_CONFIG ="/caseMassApplyCfg";
	public static final String MASS_APPLY_CFG="massApplycfg";
	public static final String GET_CTRL_CONFIG="/getMassApplyControllerConfigs";
	public static final String CTRL_CFG_OBJID="ctrlCfgObjId";
	public static final String IS_CASE_MASS_APPLY_CFG="isCaseMassApplyCfg";
	public static final String GET_FFD_CONFIGS="/getFFDConfigs";
	public static final String GET_FRD_CONFIGS="/getFRDConfigs";
	public static final String GET_EDP_CONFIGS="/getEDPConfigs";
	public static final String GET_RCI_CONFIGS="/getRCIConfigs";
	public static final String GET_MASS_APPLY_CFG_LIST="/getMassApplyCfgList";
	public static final String MASS_APPLY_CFG_LIST="MASS_APPLY_CFG_LIST";
	public static final String isMassApplyCfgUser="isMassApplyCfgUser";
	public static final String CASE_MASS_APPLY_CFG_SCREEN="CASE_MASS_APPLY_CFG_SCREEN";
	public static final String MassApplyCfg_Owners="MassApplyCfg_Owners";
	public static final String EDP_OBJID="edpObjId";
	public static final String FFD_OBJID="ffdObjId";
	public static final String FRD_OBJID="frdObjId";
	public static final String CFG_FILE="cfgFile";
	public static final String TEMPLATE_OBJID="templateObjId";
	public static final String VERIFY_CONFIG_TEMPLATES="/verifyConfigTemplates";
	public static final String GET_ON_BOARD_SOFTWARE_VERSION="/getOnboardSoftwareVersion";
	public static final String GET_CFG_TEMPLATE_VERSIONS="/getCfgTemplateVersions";
	public static final String GET_SPECIFIC_ASSET_NUMBERS="/getSpecificAssetNumbers";
	
	//Apply Config Screen
	public static final String REQ_URI_APPLY_CONFIG="/applyConfig";
	public static final String REQ_URI_CASE_APPLY_CONFIG="/caseApplyConfig";
	public static final String IS_CASE_APPLY_CONFIG="IS_CASE_APPLY_CONFIG";
	public static final String APPLY_CONFIG="applyCfg";
	public static final String APPLY_CONFIG_TEMPLATES="/applyCfgTemplates";
	public static final String MASSAPPLY_CFG_PREVILIGE_IS_NOT_PRESENT="MASSAPPLY_CFG_PREVILIGE_IS_NOT_PRESENT";
	public static final String CTRL_CFG_OBJID_NOT_PROVIDED="CTRL_CFG_OBJID_NOT_PROVIDED";
	public static final String ASSET_GROUP_NAME_NOT_PROVIDED="ASSET_GROUP_NAME_NOT_PROVIDED";
	public static final String ITEMS_ARE_NOT_SELECTED_FOR_APPLYING="ITEMS_ARE_NOT_SELECTED_FOR_APPLYING";
	public static final String CFG_TEMPALTES_NOT_PROVIDED="CFG_TEMPALTES_NOT_PROVIDED";
	public static final String TEMPLATE="template";
	public static final String IS_CONFIG_MAINTAINENCE_SCREEN="isConfigMaintainenceScreen";
	public static final String EFI_OBJID="efiObjId";
	public static final String IS_EFI_APPLY="isEFIApply";
	public static final String FROM_ASSET_NUMBER_NOT_PROVIDED="FROM_ASSET_NUMBER_NOT_PROVIDED";
	public static final String TO_ASSET_NUMBER_NOT_PROVIDED="TO_ASSET_NUMBER_NOT_PROVIDED";
	public static final String FROM_VERSION_NOT_PROVIDED="FROM_VERSION_NOT_PROVIDED";
	public static final String TO_VERSION_NOT_PROVIDED="TO_VERSION_NOT_PROVIDED";
	public static final String ERROR="ERROR";

	//EFI Apply
	public static final String  APPLY_EFI_CFG="/applyEFICfg";
	public static final String  REQ_URI_APPLY_EFI_CFG="/showApplyEFICfg";
	public static final String  EFI_APPLY="efiApplyCfg";
	public static final String LDVR_STATUS_DAYS = "ldvrstatusdays";
	
	public static final String EXPORT_CONIFG_TEMPLATES="/exportConfigfgTemplateDetails";
	public static final String CTRL_CONFIG_TEMPLATES_REPORT_HEADER = "ctrlConfigTemplatesHeader";
	public static final String IS_GE_RULE_AUTHOR = "isGERuleAuthor";
	public static final String REQ_URI_GET_UOM= "getUnitOfMeasure";
	public static final String MEASUREMENT_SYSYTEM = "Measurement System";
	public static final String UOM = "uom";
	public static final String USERPREFERENCE_UOM ="USERPREFERENCE_UOM";
	public static final String PREFERENCE_UOM="preferenceUom";
	public static final String US = "US";
	public static final String LDVR_STATUS_DATE_CHECK="/checkStatusDate";
	public static final String EXCEPTION_IN_LDVR_GEOZONE_METHOD=" Exception occured in  LDVRGeofenceServiceImpl in getLDVRGeoZones Method ";
	public static final String EXCEPTION_IN_LDVR_GEOZONE_METHOD_WHILE_IMPORTING="Invalid values in the import file , please check the file !! ";
	public static final String VIEW_CELSIUS ="Celcius";
	public static final String EXPORT_ASSET_LDVR_APPLY_TEMPLATE="/exportLDVRAssetApplyTemplate";
	public static final String LDVR_ASSET_APPLY_TEMPLATE_EXPORT_FILENAME = "ldvrassetApplyTemplate.csv";
	public static final String LDVR_ASSET_TEMPLATE_HEADER = "LDVRAssetTemplateHeader";
	//History Screen
	public static final String EMAILER ="EMAILER";
	public static final String TRAC_EFF_FDBK_TOT_5579 ="TRAC_EFF_FDBK_TOT_5579";
	public static final String GROSS_HP_1000 ="GROSS_HP_1000";
	public static final String CRANKCASE_PRESS_1535 ="CRANKCASE_PRESS_1535";
	public static final String MEAS_FUEL_LEVEL_0452 ="MEAS_FUEL_LEVEL_0452";
	
	public static final String LBS_UNIT ="lbs";
	public static final String PSIG ="psig";
	public static final String AUX_MR1_PSI="AUX_MR1_PSI";
	public static final String CONFIGID="config_id";
	public static final String ACTIVE_TACHS="Active Tachs";
	public static final String BASIC_DIR_CALL="BASIC_DIR_CALL";
	public static final String BASIC_LOCO_STATE="BASIC_LOCO_STATE";
	public static final String BATT_VOLTS="Batt Volts";
	public static final String DIR_CALL="Dir Call";
	public static final String ENGINE_HP_AVAILABLE="ENGINE_HP_AVAILABLE";
	public static final String HP_AVAILABLE="HP Available";
	public static final String LOCO_SPEED="Loco Speed";
	public static final String LOCO_STATE="Loco State";
	public static final String NOTCH_WITH_SPACE="N o t c h";
	public static final String OIL_TMP="Oil Tmp";
	public static final String PROP_ACTIVE_TACHS="PROP_ACTIVE_TACHS";
	public static final String WAT_TMP="Wat Tmp";
	public static final String EXCEPTION_IN_GETLIFESTATISTICSDATA="Exception occured in getLifeStatisticsData method ";
	public static final String EXCEPTION_IN_GETCASEREPAIRCODES="Exception occured in getCaseRepairCodes  method ";
	public static final String EXCEPTION_IN_GETTOOLOUTPUTDETAILS="Exception occured in getToolOutputDetails  method ";
	public static final String GET_MODEL_BY_FILTER = "/getModelByFilter";
	public static final String ASSET_LIST="assetList";
	//for MDSC admin
	public static final String REQ_URI_GET_CM_ML_PRIVILIGES = "/getCMorMLDetails";
	public static final String EOA_CM_FLAG = "eoaCMFlag";
	public static final String EOA_ML_FLAG = "eoaMLFlag";
	public static final String EOA_ALIAS = "eoaAlias";
	public static final String EOA_ML_VAL = "eoaMLVal";
	public static final String UPDATE_EOA_USER = "updateEOAUser";
	public static final String OMD_CM_FLAG = "omdCMFlag";
	public static final String OMD_ML_FLAG = "omdMLFlag";
	public static final String REMOVED_ROLE_ID = "removedRoleId";
	public static final String OMD_CM_ML_PREV_REMOVED = "omdCmMlPrevRemoved";
	public static final String EOA_ALIAS_EXISTS = "EOA_ALIAS_EXISTS";
	public static final String MULTILINGUAL = "multilingual";
	public static final String OMD_ML_ALONE_REMOVED = "omdMlAloneRemoved";
	public static final String NUMBERS_FOUND = "NUMBERS_FOUND";
	public static final String MDSC_ADMIN_PRIVILEGE = "MDSC_ADMIN_PRIVILEGE";
	public static final String CM_ML_USERID_INVALID = "CM_ML_USERID_INVALID";
	public static final String CM_ML_USERID_LENGTH_INVALID = "CM_ML_USERID_LENGTH_INVALID";
	//dashboard button changes
	public static final String DASHBOARD_URL="DASHBOARD_URL";
	public static final String STR_DASHBOARD_URL="dashboardUrl";
	public static final String DASHBOARD_BUTTON_ROLES="Dashboard_button_roles";
	public static final String DASHBOARD_BUTTON="Dashboard_button";
	public static final String REQ_URI_GET_LDVR_ROAD_INITIALS ="/getRoadInitialHDR";
	public static final String FLAG_MP_DATA="flagMPData";
	//Email Changes
	public static final String EMAIL_REGEX="EMAIL_REGEX";
	public static final String AT_IDLE_REPORT_DETAILS_HEADER_WITHOUT_TIMEZONE = "IdleReportDetailsHeaderWithoutTimezone";
	
	public static final String DOWNLOAD_GEOZONE_IMPORT_FILE ="/downloadGeozoneImportFile";				
	public static final String LDVR_GEOZONE_DOWNLOAD_FILENAME="importLDVRGeozone.xls";
	
	public static final String GET_DELIVER_RX_URL="/getDeliverRxURL";
	
	//added for delete button
	public static final String DELETE_ROLE = "deleteRole";
	public static final String ROLEMANAGEMENT_DELETEROLE="ROLEMANAGEMENT_DELETEROLE";
	public static final String COMPONENT_DELETEROLE="deleteRoleComponent";
	//added for BOM Maintenance - Cache Issue
	public static final String LOOKUPVALUE_CACHE = "RMDlookUpCache";
	public static final String REQ_URI_ASSETCASES_COMM_SECTION ="/getAssetCasesCommSection";
	public static final String LDVR_DATA = "LDVR Data";
	public static final String LDVR_DATA_STATUS = "LDVR Status";
	public static final String MCS_ERROR_MCS00007 = "MCS00007";
	public static final String MCS_ERROR_MCS00011 = "MCS00011";
	
	public static final String EOA_EMETRICS_FLAG="eoaEmetricsFlag";
	public static final String OMD_EMETRICS_FLAG="omdEmetricsFlag";
	public static final String EOA_EMETRICS_VAL="eoaEmetricsVal";
	public static final String OMD_EMETRICS_FLAG_ALONE_REMOVED="omdEmetricsAloneRemoved";
	public static final String RX_SCREEN_UPDATE_PRIVILEGE="RX_SCREEN_UPDATE_PRIVILEGE";
	public static final String IS_CLONE_PRIVILEGE="isClonePrivilege";
	public static final String DATE_FORMAT_DDMMYYY="dd/MM/yyyy HH:mm:ss";
	public static final String HOME_PAGE="home";
	
	public static final String OMD_CONNECTION_PATH = "CONNECTION_URL";
	//Added for contact Screen
	public static final String REQ_URI_VIEW_CONTACT_SCREEN = "/getContactPage";
	public static final String ADD_EDIT_CONTACT = "addEditContact";
	public static final String SITE_ID = "siteId";
	public static final String SITE_NAME = "siteName";
	public static final String PH_NO = "phNo";
	public static final String CONTACT_STATUS = "contactStatus";
	public static final String REQ_URI_GET_CONTACTS = "/getContacts";
	public static final String CONTACT_OBJID = "contactObjId";
	public static final String REQ_URI_VIEW_CONTACT_DETAILS = "/viewContactDetails";
	public static final String REQ_URI_GET_CONTACT_STATUS = "/getContactStatus";
	public static final String REQ_URI_GET_CONTACT_ISD_CODE = "/getISDCode";
	public static final String CONTACT_STATUS_LIST = "CONTACT_STATUS_LIST";
	public static final String REQ_URI_GET_CONTACT_ROLES = "/getContactRoles";
	public static final String CONTACT_ROLE_LIST = "CONTACT_ROLE_LIST";
	public static final String REQ_URI_GET_CONTACT_SECONDARY_SITES = "/getContactSecondarySites";
	public static final String SITE_OBJID = "siteObjId";
	public static final String CONTACT_ROLE = "contactRole";
	public static final String REQ_URI_ADD_CONTACT_SECONDARY_SITE = "/addContactSecondarySite";
	public static final String MISSING_SOME_INPUT_PARAMS = "MISSING_SOME_INPUT_PARAMS";
	public static final String REQ_URI_REMOVE_CONTACT_SECONDARY_SITE = "/removeContactSecondarySite";
	public static final String NO_SECONDARY_SITES_SELECTED = "NO_SECONDARY_SITES_SELECTED";
	public static final String REQ_URI_ADD_OR_UPDATE_CONTACT = "/addOrUpdateContact";
	public static final String REQ_URI_OPEN_SECONDARY_SITE_WINDOW ="/viewSecondarySitePage";
	public static final String SECONDARY_SITE_PAGE = "secondarySites";
	
	public static final String REQ_URI_GET_SITE_PAGE ="/getSitePage";
	public static final String REQ_URI_GET_CONTACT_PAGE ="/getContactPage";
	public static final String VIEW_SITE_PAGE =  "viewSitePage";
	public static final String VIEW_CONTACT_PAGE =  "viewContactPage";
	public static final String GET_SITE_TYPES="/getSiteTypes";
	public static final String SITE_TYPES="SITE_TYPES";
	public static final String GET_SITES="/getSites";
	public static final String SITE_TTPES="siteTypes";
	public static final String SITE_ADDRESS="siteAddress";
	public static final String SITE_CITY="siteCity";
	public static final String SITE_STATE="siteState";
	public static final String SITE_ACCOUNT_ID="siteAccountId";
	public static final String SITE_ACCOUNT_NAME="siteAccountName";
	public static final String SITE_INACTIVE_FLAG="inactiveSitesFlag";
	public static final String VIEW_SITE_DETAILS="/viewSiteDetails";
	public static final String GET_SITE_SHIPPING="/getSiteShipping";
	public static final String GET_SITE_EDIT_TYPES="/getSiteEditTypes";
	public static final String GET_SITE_STATUS="/getSiteStatus";
	public static final String SITE_EDIT_NEW_TYPES="SITE_EDIT_NEW_TYPES";
	public static final String SITE_SHIPPING_DETAILS="SITE_SHIPPING_DETAILS";
	public static final String SITE_STATUS="SITE_STATUS";				
	public static final String SITE_EDITNEW_TYPE="siteEditNewType";
	public static final String SITE_EDITNEW_STATUS="siteEditNewStatus";
	public static final String SITE_EDITNEW_SHIPPING="siteEditNewShipping";
	public static final String SITE_EDITNEW_CUSTOMER="siteEditNewCustomer";
	public static final String SITE_EDITNEW_SITEID="siteEditNewSiteID";
	public static final String SITE_EDITNEW_SITENAME="siteEditNewSiteName";
	public static final String SITE_EDITNEW_ADDRESS="siteEditNewAddress";
	public static final String SITE_EDITNEW_SHIPTO="siteEditNewShipTo";
	public static final String SITE_EDITNEW_BILLTO="siteEditNewBillTo";
	public static final String SITE_EDITNEW_PHONE="siteEditNewPhone";
	public static final String SITE_EDITNEW_FAX="siteEditNewFax";
	public static final String UPDATE_SITE="/updateSite";
	public static final String CREATE_SITE="/createSite";
	public static final String GET_POPULATE_DATA="/getPopulateData";
	public static final String EXPORT_CONTACTS = "/exportContacts";
	public static final String CONTACTS_REPORT_HEADER = "contactsHeader";
	public static final String CONTACT_DETAILS_LIST = "contactDetailsList";
	public static final String CONTACT_EXPORT_FILENAME = "ContactDetails.csv";
	public static final String EXPORT_SITESCREEN = "/exportSiteScreenReport";
	public static final String SITESCREEN_EXPORT_FILENAME = "SiteScreen.csv";
	public static final String SITESCREEN_EXPORT_HEADER = "SiteScreenExportHeader";
	public static final String REQ_URI_VIEW_ADDRESS_SCREEN = "/getAddressPage";
	public static final String ADD_EDIT_ADDRESS = "addEditAddress";
	public static final String REQ_URI_GET_ADDRESS_FILTER_OPTIONS = "/getAddressFilterOptions";
	public static final String ADDRESS_FILTER_LIST = "ADDRESS_FILTER_LIST";
	public static final String REQ_URI_GET_ADDRESS = "/getAddress";
	public static final String ADDRESS = "address";
	public static final String CITY = "city";
	public static final String STATE = "state";
	public static final String ZIP_CODE = "zipCode";
	public static final String ADDRESS_FILTER = "addrFilter";
	public static final String CITY_FILTER = "cityFilter";
	public static final String STATE_FILTER = "stateFilter";
	public static final String ZIPCODE_FILTER = "zipCodeFilter";
	public static final String REQ_URI_VIEW_ADDRESS_DETAILS = "/viewAddressDetails";
	public static final String ADDRESS_OBJID = "addrObjId";
	public static final String REQ_URI_COUNTRY_LIST = "/getCountryList";
	public static final String REQ_URI_GET_COUNTRY_STATES = "/getCountryStateList";
	public static final String COUNTRY = "country";
	public static final String REQ_URI_GET_COUNTRY_TIMEZONES = "/getCountryTimeZones";
	public static final String REQ_URI_ADD_OR_UPDATE_ADDRESS = "/addOrUpdateAddress";
	public static final String EXPORT_ADDRESS = "/exportAddress";
	public static final String ADDRESS_DETAILS_LIST = "addrDetailsList";
	public static final String ADDRESS_EXPORT_FILENAME = "AddressDetails.csv";
	public static final String ADDRESS_REPORT_HEADER = "addressHeader";
	
	public static final String REQ_URI_GET_DELETE_ROLE_LIST = "/getDeleteRoleUsersList";
	public static final String REQ_URI_GET_DELETE_ROLE_UPDATE = "/deleteRoleUpdate";
	public static final String REQ_PARAM_ROLEID="roleId";
	public static final String DELETE_ROLE_UPDATE="updateData";

	public static final String REQ_URI_RUN_TURNOVER = "/RunTurnover";
	public static final String RUN_TURNOVER = "runTurnover";
	public static final String REQ_URI_GET_TURNOVER_REPORT = "/getRunTurnoverReports";
	
	//added for GPOC turnover report for general and comm notes
	public static final String REQ_URI_GENERAL_NOTES="/generalNotes";
	public static final String REQ_URI_COMM_NOTES="/commNotes";
	public static final String GENERAL_NOTES="generalNotes";
	public static final String NOTES_DESC = "notesdesc";
	public static final String ENTERED_BY = "enteredby";
	public static final String ENTERED_DATE = "enteredDate";
	public static final String ADD_GENERAL_NOTES = "/addGeneralNotes";
	public static final String DELETE_GENERAL_NOTES = "/deleteGeneralNotes";
	public static final String EXPORT_AT_GENERAL_NOTES = "/exportGeneralNotes";
	public static final String GENERAL_NOTES_HEADER = "GeneralNotesHeader";
	public static final String GENERAL_NOES_EXPORT_FILENAME = "Generalnotes.csv";
	public static final String GENERALNOTES_SHOW_ALL="/showAllGeneralNotes";
	public static final String REMOVE_GENERAL_NOTES ="/removeGeneralNotes";
	public static final String GENERALNOTES_SEQID="getnotesSeqId";
	public static final String GENERALNOTES_DATE_FORMAT = "MM/dd/yyyy HH:mm:ss";
	public static final String GET_GNSEQIDS_STRING="gnseqids";
	public static final String REQ_URI_COMML_NOTES="/commNotes";
	public static final String COMM_NOTES="commNotes";
	public static final String ADD_COMM_NOTES = "/addCommNotes";
	public static final String REMOVE_COMML_NOTES ="/removeCommNotes";
	public static final String COMMNOTES_SHOW_ALL="/showAllCommNotes";
	public static final String EXPORT_AT_COMM_NOTES = "/exportCommNotes";
	public static final String COMM_NOTES_HEADER = "CommNotesHeader";
	public static final String GET_COMMSEQIDS_STRING="commnotesseqids";
	public static final String COMM_NOES_EXPORT_FILENAME = "CommNotes.csv";
	
	public static final String REQ_URI_GET_ALERT_HISTORY_PAGE ="getAlertHistoryPage";
	public static final String ALERT_HISTORY_VIEW = "AlertHistory";
	public static final String GET_ALERT_HISTORY_NO_OF_DAYS="/getAlertHistoryNoofDays";
	public static final String GET_ALERT_HISTORY_SERVICE_TYPES="/getServiceTypes";
	public static final String SERVICE_TYPES="NOTIFICATION_TYPE";
	public static final String ALERTHISTORY_NO_OF_DAYS="ALERTHISTORY_NO_OF_DAYS";
	public static final String METHOD_FLAG="methodFlag";
	public static final String REQ_URI_GET_ALERTHISTORYDETAILS="/getAlertHistoryDetails";
	public static final String ALERT_HISTORY_CUSTOMER="strCustomer";
	public static final String ALERT_HISTORY_TYPE="strType";
	public static final String ALERT_HISTORY_ALERT="strAlert";
	public static final String ALERT_HISTORY_RXFILTER="strRxFilter";
	public static final String ALERT_HISTORY_RULE="strRule";
	public static final String ALERT_HISTORY_REGION="strRegion";
	public static final String ALERT_HISTORY_SUBDIVISION="strSubDivision";
	public static final String ALERT_HISTORY_FLEET="strFleet";
	public static final String ALERT_HISTORY_ASSET="strAsset";
	public static final String ALERT_HISTORY_SHOP="strShop";
	public static final String ALERT_HISTORY_MODEL="strModel";
	public static final String ALERT_HISTORY_NUMBEROFDAYS="strNumberOfDays";
	public static final String ALERT_HISTORY_MULTIUSER="strMultiUsers";
	public static final String ALERT_HISTORY_FROMDATE="strFromDate";
	public static final String ALERT_HISTORY_TODATE="strToDate";
	public static final String ALERT_HISTORY_SEARCHVALUE="strSearchValue";
	public static final String ALERT_HISTORY_LOOKBACK_DAYS="ALERT_HISTORY_LOOKBACK_DAYS";
				public static final String ALERT_HISTORY_MULTI_SUCSCRIPTION = "ALERT_HISTORY_MULTI_SUBSCRIPTION";
	public static final String ALERT_HISTORY_MULTI_SUCSCRIPTION_COMPONENT = "alertHistoryMultiSubComponent";
	public static final String ALERT_HISTORY_CONFIG_ALERT = "ALERT_HISTORY_CONFIG_ALERT";
	public static final String ALERT_HISTORY_CONFIG_ALERT_COMPONENT = "alertHistoryConfigAlertComponent";
	public static final String SUBMENU_ITOOLS_RULE = "SUBMENU_ITOOLS_RULE";
	public static final String ALERT_HISTORY_ITOOL_COMPONENT = "alertHistoryiToolComponent";
	public static final String ALERT_HISTORY_DEFAULT_NO_OF_DAYS = "ALERT_HISTORY_DEFAULT_NO_OF_DAYS";
	public static final String ALERT_HISTORY_DEFAULT_NOOFDAYS = "alertHistoryDefaultNoOfDays";
	public static final String EXPORT_ALERTHISTORY_SCREEN = "/exportAlertHistoryReport";
	public static final String ALERTHISTORY_EXPORT_FILENAME = "AlertHistory.csv";
	public static final String ALERTHISTORY_EXPORT_HEADER_MULTIUSER = "AlertHistoryExportHeaderWithMultiUser";
	public static final String ALERTHISTORY_EXPORT_HEADER = "AlertHistoryExportHeaderWithOutMultiUser";
	public static final String REQ_URI_ALERT_HISTORY_ASSETS = "/getAltHstAssets";
	public static final String CONV_PREFERENCE = "conversionPreference";
	public static final String LOAD_MODEL_FOR_CONFIG = "loadModelForConfig";
	public static final String ALL_CUSTOMER="ALLCUSTOMER";
	public static final String NOMODEL = "NoModel";
	public static final String SORT_BY="sortBy";
	public static final String GET_ALERT_HST_POPULATE_DATA= "/getAlertHisotryPopulateData";
	public static final String ALERT_HST_MODEL="ALERT_HST_MODEL";
	public static final String ALERT_HST_FLEET="ALERT_HST_FLEET";
	public static final String ALERT_HST_ASSET="ALERT_HST_ASSET";
	public static final String ALERT_HST_CONFIG="Configurable";
	public static final String ALERT_HST_RX = "Rx";
	public static final String ALERT_HST_DOWNLOAD_PDF = "Download PDF";
	public static final String ALERT_HST_VIEW = "View";
	public static final String ALERT_HST_VIEW_EMAIL_TEXT = "View Email Text";
	public static final String ALERT_HISTORY_PAGE_NO="pagenum";
	public static final String ALERT_HISTORY_RECORDS_PERPAGE="pagesize";
	public static final String ALERT_HISTORY_START_ROW="recordstartindex";
	public static final String ALERT_HISTORY_IAUTHOR = "SUBMENU_ITOOLS_RULE";
	public static final String ALERT_HISTORY_HITS = "SUBMENU_ITOOLS_HITS";
	public static final String ALERT_HISTORY_HITS_COMPONENT = "alertHistoryHitsComponent";
	public static final String ALERT_HISTORY_IAUTHOR_COMPONENT = "alertHistoryIAuthorComponent";
	public static final String ALERT_HST_METHOD_FLAG = "strMethodFlag";
	public static final String REQ_URI_RUNTURNOVER="/RunTurnover";
	public static final String CASE_TREND = "caseTrend";
	public static final String REQ_URI_GET_OPEN_RX_COUNT="/getOpenRXCount";
	public static final String REQ_URI_GET_CASE_TREND = "/getCaseTrend";
	public static final String REQ_URI_GET_CASE_TREND_STAT ="/getCaseTrendStatistics";
	public static final String CASE_TREND_GRAPH_CASE_TYPES = "CASE_TREND_GRAPH_CASE_TYPES";
	public static final String GET_OPEN_COMM_RX = "/getOpenCommRXDetails";
	public static final String GET_CASE_CONVERTION_DETAILS= "/getCaseConversionDetails";
	public static final String REQ_URI_GET_CASE_CONVERSION_DETAILS ="/getCaseConversionDetails";
	public static final String CASE_CONVERSION = "caseConversion";
	public static final String REQ_URI_COMMNOTES ="/CommNotes";
	public static final String GET_CASE_CONVERTION_PERCENTAGE= "/getCaseConversionPercentage";
	public static final String GET_TOP_NO_ACTION_RX_DETAILS= "/getTopNoActionRXDetails";
	public static final String GET_COMM_NOTES_DETAILS= "/getCommNotesDetails";
	public static final String OPEN_COMM ="openComm";
	public static final String TOP_NO_ACTION_RX_ALLOWED_VALUE ="TOP_NO_ACTION_RX_ALLOWED_VALUE";
	public static final String GET_SHIP_UNIT_DETAILS= "/getShipUnitDetails";
	public static final String GET_INFANCY_FAILURE_UNITS= "/getInfancyFailureDetails";
	public static final String SHIP_UNIT_REPORT= "shipUnitReport";
	public static final String REQ_URI_OPEN_COMM_REPORT ="/showOpenCommPage";
	public static final String GET_GENERAL_NOTES_DETAILS= "/getGeneralNotesDetails";
	public static final String WS_LAST_LOGIN_FROM = "lastLoginFrom";
	public static final String LAST_LOGIN_FROM = "Web";
	
	public static final String EXPORT_DELETE_ROLES = "/exportDeleteRoles";
	public static final String ROLE_MANAGEMENT_DELETE_HEADER = "RoleManagementDeleteHeader";
	public static final String ROLE_MANAGEMENT_DELETE_EXPORT_FILENAME = "DeleteRoles.csv";
	public static final String VIEW_LDVR_ASSET_PQ =  "ldvrAssetPQ";
	public static final String REQ_URI_GET_LDVR_ASSET_PQ ="/getLDVRManageAssetPQPage";
	public static final String GET_LCV_REQUEST_TYPE="/getLcvRequestData";
	public static final String LCV_REQUEST_TYPE_DROPDOWN="LCV_REQUEST_TYPE_DROPDOWN";
	public static final String GET_LCV_MESSATE_HISTORY_DROPDOWN="/getLcvMsgHistoryData";
	public static final String LDVR_MESSAGE_TYPE_VALUES_DROPDOWN = "LCV_MESSAGE_HISTORY_DROPDOWN";
	
	//Added by Murali Medicherla for Rally Id : US226051	
	public static final String MOBILE_ACCESS_PRIVILEGE_ROLES = "MOBILE_ACCESS_PRIVILEGE_ROLES";
	public static final String MOBILE_ACCESS = "mobileAccess";
				
	//Added for LocoVision for Rally Id - US225688:Aurizon - LCV - Validation for MP's to be fixed both at MCS and OMD
	public static final String LDVR_PRESERVATION_DOWNLOAD_TEMPLATE = "LDVR: Preservation/Download Template";
	public static final String PRESERVE_VIDEO_AUDIO_TEMPLATE = "Preserve Video/Audio Template";
    public static final String REQ_URI_EXPORT_REPORT = "/exportReports";
    public static final String TURNOVER_REPORTS_EXPORT_FILENAME = "turnOverReports.csv";
    public static final String INBOUND_REVIEW_DETAILS = "Inbound Review Details";
    public static final String INBOUND_REVIEW_DETAILS_HEADER = "inboundReviewTableColumns";
    public static final String REPEATERS_TABLE_COLUMNS = "repeatersTableColumns";
    public static final String REPEATERS_TABLE = "Repeaters 02 and higher";
    public static final String SHIPPED_UNITS_TABLE = "List of units Shipped in the last 24 hours";
    public static final String SHIPPED_UNITS_TABLE_COLUMNS = "shippedUnitsTableColumns";
    public static final String INFANCY_FAILURE_TABLE = "Infancy Failure Units";
    public static final String INFANCY_FAILURE_TABLE_COLUMNS = "infancyFailureTableColumns";
    public static final String COMM_RX_TABLE = "Open Comm RX's by Customer";
    public static final String COMM_RX_TABLE_COLUMNS = "openCommRXTableColumns";
    
    public static final String GET_ADD_REP_CODE_DETAILS = "/getRepCodeDetails";
    public static final String GET_LOOKUP_ADD_REP_CODE_DETAILS = "/getLookUpRepCodeDetails";
    //Added for US225214 - Heat Map Feature
    public static final String REQ_URI_HEATMAP = "HeatMapPage";
    public static final String VIEW_HEATMAP = "HeatMap";
    public static final String REQ_URI_HEATMAP_MODEL="/getHeatMapModels";
    public static final String REQ_URI_HEATMAP_ASSETSNUMBERS="/getHeatMapAssetNumbers";
    public static final String REQ_URI_HEATMAP_ASSETSHEADERS="/getHeatMapAssetHeaders";
    public static final String REQ_URI_HEATMAP_FAULTS="/getHeatMapFaults";
    public static final String REQ_URI_HEATMAP_FILTER_RESULTS="/getHeatMapFilterResults";
    public static final String HEATMAP_RED_COLOR_VALUE="HEATMAP_RED_COLOR_VALUE";
    public static final String HEATMAP_BLUE_COLOR_VALUE="HEATMAP_BLUE_COLOR_VALUE";
    public static final String HEATMAP_YELLOW_COLOR_VALUE="HEATMAP_YELLOW_COLOR_VALUE";
    public static final String HEATMAP_DB_DATE_FORMAT = "dd-MM-yyyy HH:mm:ss";
    //Date Handling
    public static final String EXCEPTION_INVALID_DATE="EXCEPTION_INVALID_DATE";
    public static final String VALIDATE_URL = "/validateURL";
    public static final String DATA_SCREEN_SHOW_AUTO_HC ="DATA_SCREEN_SHOW_AUTO_HC";
    public static final String SHOW_AUTO_HC = "showAutoHC";
	public static final String RECORDSTARTINDEX = "recordstartindex";
    public static final String GET_PP_HISTORY_HEADERS="/getPPAssetHistoryHeaders";
    public static final String REQ_PAGINATION ="pagination";
    public static final String TASK_ID ="taskId";
    public static final String DATA_SCREEN_NEW_SHOW_AUTO_HC ="DATA_SCREEN_NEW_SHOW_AUTO_HC";
    public static final String SUBMENU_OHV_MINE_GE_LEVEL_REPORTS = "SUBMENU_OHV_MINE_GE_LEVEL_REPORTS";
    public static final String URGENCY_OF_REPAIR_DETAILS_HINDI="URGENCY_OF_REPAIR_DETAILS_7";
    //Added for US236246: IT Task - Product Mapping Implementation for locovision    
    public static final String REQ_URI_GETSOLASSETNUMPRODUCT="/getAssetsProducts";
    public static final String GET_ASSET_LIS_PRODUCTS="/getAssetListProducts";
    public static final String LCV_PRODUCT_MAPPING_ERROR_CD="OMD0001_LCVError";
    public static final String LCV_LDVR_CHECK_ERROR_CD="OMD0002_LCVError";
    
	public static final String ALERT_SUBSCRIPTION_RX_CHANGE = "ALERT_SUBSCRIPTION_RX_CHANGE_REQUEST";
	public static final String ALERT_SUBSCRIPTION_RX_CHANGE_COMPONENT = "alertSubscriptionRxChangeComponent";

    // Added by Sriram.B(212601214) for SMS feature
    public static final String PHONE_NUMBER = "phoneNumber";
    public static final String PARAM_STRING="paramString";
    public static final String GENERATE_OTP="/generateOTP";
    public static final String STORE_OTP="/storeOTP";
    public static final String UPDATE_NOTIFICATION_TYPE = "/updateNotificationType";
    public static final String VALIDATE_OTP="/validateOTP";
    public static final String REQ_URI_UPDATE_PHONE = "/updatephone";
    public static final String ALERT_SUBSCRIPTION_SMS = "ALERT_SUBSCRIPTION_SMS";
    public static final String ALERT_SUBSCRIPTION_SMS_COMPONENT = "alertSubscriptionSmsComponent";
    public static final String USER_PHONE_NO = "userPhoneNo";
    public static final String USER_PHONE_COUNTRY_CODE = "userPhoneCountryCode";
    public static final String AT_OVERVIEW_HEADER_GALLONS_CP = "ATOverviewHeaderGallonsForCP";
	public static final String AT_OVERVIEW_HEADER_LITRES_CP = "ATOverviewHeaderLitresForCP";
    
    public static final String CREATE_VIRTUAL_ACCESS="createVirtualAccess";
    public static final String VIRTUAL_UPDATE_PRIVILEGE = "VIRTUAL_UPDATE_PRIVILEGE";
    public static final String HAS_FIND_NOTES_ACCESS = "hasFindNotesAccess";
    public static final String AUTO_HC_TEMPLATE = "autoHCTemplate";
    public static final String REQ_URI_AUTO_HC_TEMPLATE = "/autoHCTemplate";
    
    public static final String MESSAGE_HISTORY_VO = "messageHistVO";
    

    public static final String DATA_SCREEN_VEHICLE ="DATA_SCREEN_VEHICLE"; 
    public static final String VEHICLE_FAULTS = "vehicleFaults";
    public static final String DATA_SCREEN_NEW_VEHICLE ="DATA_SCREEN_NEW_VEHICLE";
	public static final String GET_CASESCORE_REPAIR_CODE="/getCaseScoreRepairCodes";
	public static final String SCHEDULE_RUN_DATE = "scheduleRunDate"; 
    public static final String DIAGNOSTIC_SERVICE="diagnosticService";
    public static final String RUN_TOOLS_NOW = "RUN_TOOLS_NOW"; 
    public static final String IS_RUN_TOOLS_NOW = "isRunToolsNow";
    public static final String SCHEDULE_RUN_TOOLS_NOW = "SCHEDULE_RUN_TOOLS_NOW"; 
    public static final String TECHNICIAN_FLAG ="technicianFlag";
    public static final String MISS4A="Miss-4A";
    public static final String REPAIRCODE_ID="repairCodeId";
    public static final String END_SCORING_FLAG="endScoringFlag";
                                                 
	// Added by Murali C
    public static final String UPDATE_GEN_OR_COMM_NOTES = "/updateGenOrCommNotes";
    public static final String NO_INPUT_SELECTED = "NO_INPUT_SELECTED";
    public static final String INCLUDE_SHOP_DATA = "includeShopData"; 
    
    /*Added by Koushik B for OHV reports*/
    public static final String OHV_REPORTS_GET_RX = "/getReportsRx";
    public static final String OHV_REPORTS_TRUCK_EVENTS = "/getTruckEvents";
    public static final String OHV_REPORTS_TRUCK_INFO = "/getTruckInfo";
    public static final String OHV_REPORTS_COM_STATUS = "/getComStatus";
    public static final String REPORTS_CUSTOMER_ID = "customerId";
    public static final String REPORTS_MINE_ID = "mineId";
    public static final String REPORTS_TRUCK_ID = "truckId";
    public static final String REPORTS_RX_TYPE = "rxType";
    public static final String REPORTS_RX_URGENCY = "urgency";
    public static final String REPORTS_RX_VO_LIST = "rxList";
    public static final String REQ_URI_TRUCK = "truckReport";
    public static final String REQ_URI_MINE = "mineReport";
    public static final String MINE_REPORT = "mineReport";
    public static final String TRUCK_REPORT = "truckReport";
    public static final String REPORT_DEFAULT_CUST_ERROR = "NO_CUST";
    public static final String REPORT_NO_TRUCK_ERROR = "NO_TRUCK";
    public static final String OHV_REPORTS_TOP_EVENTS = "/getTopEvents";
    public static final String OHV_REPORTS_TRUCK_DATA = "/getTruckData";
    public static final String OHV_REPORTS_GRAPH_DATA = "/getTruckGraphData";
    public static final String REPORTS_FROM_DATE = "fromDate";
    public static final String REPORTS_TO_DATE = "toDate";
    public static final String REPORTS_RX_OPEN = "Open";
    public static final String REPORTS_RX_CLOSED = "Closed";
    public static final String REPORTS_RX_ALL = "All";
    public static final String REPORTS_TRUCK_INFO = "truckInfo";
    public static final String REPORTS_TRUCK_COMM = "comStatus";
    public static final String REPORTS_TRUCK_OPEN_RX = "openRx";
    public static final String REPORTS_TRUCK_CLOSED_RX = "closedRx";
    public static final String REPORTS_TRUCK_ALL_RX = "allRx";
    public static final String REPORTS_TRUCK_EVENTS = "events";
    public static final String OHV_REPORTS_TRUCK_VARIABLES_PARAM = "/getTruckVariablesParam";
    public static final Integer REPORTS_NUM_DAYS = 1;
    public static final String REPORTS_LAST_MONTH ="1";
    public static final Integer REPORTS_THIRTY_DAYS = 30;
    public static final String REPORTS_MIN_DATE ="01/01/2017 00:00:00";
    public static final String PARAM_NAME = "Control Power On,Engine Hours - (Meter),Engine Operating Hours,Engine Idle Time,Truck Parked,Propel Time,Retard Time,Warm Up Mode,No Retard,No Propel,Speed Limit,Inverter 1 Disable,Inverter 2 Disable,Retard Engine Speed Incr 1,Retard Engine Speed Incr 2,Distance Traveled,Body Up,Loads,Dispatch Messages,RP1 Pickup,RP2 Pickup,RP3 Pickup,GF Contactor,Parking Brake,Eng/Alternator Revolutions,Alternator MW-Hrs,Overloads,Pre-Shift Brake Tests,Healthcheck Failed, Healthcheck Success, Faultcheck Success, Faultcheck Failed, HC Files Received, Fuel Saver 2 Enabled, Continuous Retard";
	public static final String UNIT_NAME = "Hrs,Hrs,Hrs,Hrs,Hrs,Hrs,Hrs,Hrs,Hrs,Hrs,Hrs,Hrs,Hrs,Times,Times,Miles,Miles,Number,Number,Times,Times,Times,Times,Times,Number,MWh,Number,Hours,Number,Number,Number,Number,Number,Hrs,Hrs";
	public static final String TRUCK_EVENT_EXPORT_FILENAME = "truckEventsExport.csv";
	public static final String TRUCK_EVENT_HEADER = "truckEventsHeader";
	public static final String EXPORT_TRUCK_EVENTS = "/exportTruckEvents";
	public static final String TRUCK_RX_EXPORT_FILENAME = "truckRxExport.csv";
	public static final String TRUCK_RX_HEADER = "truckRxHeader";
	public static final String EXPORT_TRUCK_RX = "/exportTruckRx";
	public static final String TRUCK_VARIABLES_EXPORT_FILENAME = "truckVariablesExport.csv";
	public static final String TRUCK_VARIABLES_HEADER = "truckVariablesHeader";
	public static final String EXPORT_TRUCK_VARIABLES = "/exportTruckVariables";
    public static final String TICKER_SECTION_DISPLAY_PRIVILEGE = "TICKER_SECTION_DISPLAY";
    public static final String IS_TICKER_SECTION_DISPLAY = "isTickerSectionDisplay";
    
    //Added by Murali Ch for US117241
    public static final String FROM_SCREEN = "fromScreen";
    public static final String CHECK_TOOL_OUTPUT_DELV_MACHANISM = "/checkToolOutputDelvMachanism";
    public static final String EOA_ONSITE_MANAGEMENT="eoaOnsiteManagement";
    public static final String REQ_URI_EOA_ONSITE_MANAGEMENT = "/eoaOnsiteManagement";
    public static final String USERMANAGEMENT_EOA_ONSITE_EDITUSER="USERMANAGEMENT_EOA_ONSITE_EDITUSER";
    public static final String USERMANAGEMENT_EOA_ONSITE_ADDUSER="USERMANAGEMENT_EOA_ONSITE_ADDUSER";
    public static final String CM_ENABLED_ROLES="CM_ENABLED_ROLES";
    public static final String USER_MGMNT_DEFAULT_ROLES="USER_MGMNT_DEFAULT_ROLES";
    public static final String IS_ALL_CUSTOMER="IS_ALL_CUSTOMER";
    public static final String EXPORT_EOAONSITE_USERS = "/exportEOAOnsiteUsers";
    public static final String GET_UNIT_CONVERSION_DATA="/getUnitConversionData";
    public static final String WS_MEASUREMENT = "measurementSystem";
    public static final String WS_PARAMID = "paramId";
    public static final String WS_CONVERT_VALUE = "value";
    public static final String CALL_REPORT_MIN_CALL_COUNT = "3";
    public static final String CALL_REPORT_MIN_CALL_COUNT_VALUE = "CALL_REPORT_MIN_CALL_COUNT_VALUE";
	public  static final String RX_VISUALIZATION_WIN    = "/getRxVisualizationWin";
    public  static final String RX_VISUALIZATION_SCREEN_WIN="rxVisualizationWin";
    public static final String REQ_URI_RX_VISUALIZATION_DATA="/visualization/getRxVizPlotData";
    public static final String REQ_URI_RX_VISUALIZATION_PLOT_INFO="/visualization/getRxVizPlotInfo";
    public static final String EOA_ONSITE_TECH="EOA_ONSITE_TECH";
    public static final String ALERTHISTORY_EXPORT_HEADER_MULTIUSER_SMS = "AlertHistoryExportHeaderWithMultiUserAndSMS";
	public static final String ALERTHISTORY_EXPORT_HEADER_SMS = "AlertHistoryExportHeaderWithSMS";
    
    //Added for AHC template requirement
    public static final String GET_AHC_CONFIGS="/getAHCConfigs";
    public static final String AHC_OBJID = "ahcObjId";
    
    //added by venkatesh for auto_hc_template
    public static final String TEMPLATE_DATA = "/getHCTemplateData";
    public static final String FAULT_CODE_REC_TYPE_DATA = "/getHCFaultCodeRecTypeData";
    public static final String CTRL_CONFIG_HC = "ctrlConfig";
    public static final String CONFIG_FILE_HC = "configFile";
    public static final String MSG_DEF_ID_DATA = "/getMessageDefIds";
    public static final String AHC_MAX_PARAMS = "ahcMaxParams";
    public static final String REQ_URI_POST_NEW_TEMPLATE_DETAILS = "/autoHCNewTemplate";
    public static final String AH_TEMPLATE_OBJ_ID = "tempObjId";
    public static final String AH_SAMPLE_RATE = "sampleRate";
    public static final String AH_POST_SAMPLES = "postSamples";
    public static final String AH_FREQUENCY = "frequency";
    public static final String AH_FCRT_OBJID = "fcrtObjid";
    public static final String AH_TEMPLATE_NO = "templateNo";
    public static final String AH_VERSION_NO = "versionNo";
    public static final String AH_TITLE = "title";
    public static final String AH_STATUS = "status";
    public static final String AH_CTRL_CONFIG_OBJID = "configCtrlObjid";
    public static final String AH_EDP_TEMP_OBJID = "edpTempObjid";
    public static final String REQ_URI_AHC_NEW_TEMPLATE ="/viewAHCTemplatePage";
    public static final String GET_COMPLETE_AHC_DATA = "/getComAHCDetails";
    public static final String VALIDATE_VEH_BOMS = "validateVehBoms";
    
    public static final String REQ_URI_RXCHANGE_MODELS ="/getRxChangeModels";
    public static final String REQ_URI_RXCHANGE_CUSTOMERS = "/getRxChangeCustomers";
    public static final String REQ_URI_RXCHANGE_REQUESTORS = "/getRxChangeRequestors";
    public static final String REQ_URI_RXCHANGE_LOOKUP ="/getRxChangeLookUp";
    public static final String REQ_URI_RXCHANGE_RXTITLE = "/getRxChangeRxTitle";
    public static final String REQ_URI_RXCHANGE_ROADNUMBERS = "/getRxChangeRoadNumbers";
    public static final String REQ_URI_RXCHANGE_CASEID = "/getRxChangeCaseId";
    public static final String REQ_URI_SAVE_EDIT_RXCHANGE = "/saveEditRxChangeDetails";
    
    public static final String REQUESTOR = "requestor";
    public static final String REVISIONTYPE = "revisionType";
    public static final String SPECIFICRXTITLE = "specificRxTitle";
    public static final String GENERALRXTITLE= "genealRxTitle";
    public static final String CHANGES_SUGGESTED = "changesSuggested";
    public static final String ATTACHMENT = "attachment";
    public static final String CASE_SEARCH_STR = "caseSearchString";
    public static final String LOOKUP_NAME = "lookupName";
    public static final String LOOKUP_RXCHANGE_NAME = "RxChangeType";
    public static final String RX_CHANGE_REQ_FILTER_VAL = "RX_CHANGE_REQ_FILTER_VAL";
    public static final String TYPE_OF_RX_CHANGE = "typeOfRxChange";
    
    //Added as part of US251801:Rx Update Workflow - Migrate this process within EoA/OMD - Ryan & Todd
    public static final String REQ_URI_RXCHANGE = "/getRxChangePage";
    public static final String VIEW_RX_CHANGE_OVERVIEW = "rxChangeOverview";
    public static final String REQ_URI_RXCHANGE_REQUEST = "/getRxChangeRequestPage";
    public static final String VIEW_RX_CHANGE_REQUEST="rxChangeRequest";
    public static final String VIEW_RX_CHANGE_ADMIN="rxChangeAdmin";
    public static final String REQ_URI_RXCHANGE_OVERVIEW_DATA="/getRxChangeOverviewData";
	public static final String RX_CHANGE_ADMIN_PRIVILEGE="RX_CHANGE_ADMIN_PRIVILEGE";
	public static final String IS_RX_CHANGE_ADMIN_PRIVILEGE="isRxChangeAdminPrivilege";
	public static final String GET_RX_DELIVERY_ATTACHMENTS="/getRxDeliveryAttachments";
	public static final String RX_CHANGE_OVERVIEW_LIST="rxChangeOverviewList";
	public static final String REQ_URI_RXCHANGE_MODEL_RXTITLE = "/getModelForRxTitle";
	public static final String REQ_URI_RXCHANGE_ADMIN_DATA = "/getRxChangeAdminData";
	public static final String REQ_URI_RXCHANGE_SAVE_UPDATE_ADMIN = "/saveUpdateRxChangeAdminDetails";
	public static final String REQ_URI_RXCHANGE_CUSTOMER_MODEL = "/getCustomerForModel";
	public static final String EXPORT_RX_CHANGE_OVERVIEW_DATA = "/exportRxChangeOverviewData";
	public static final String RX_CHANGE_OVERVIEW_EXPORT_FILENAME = "RxChangeRequestOverview.csv";
	public static final String RX_CHANGE_OVERVIEW_HEADER="RxChangeOverviewHeader";
	public static final String RX_CHANGE_OVERVIEW_STATUS = "RX_CHANGE_OVERVIEW_STATUS";
	public static final String IS_EOA_ONSITE_USER = "eoaAdmin";
	public static final String PENDING = "Pending";
    public static final String INVALID_FILE_NAME = "INAVLID_FILE_NAME";
    public static final String DOWNLOAD_RX_CHANGE_ATTACHMENT ="/downloadRxChangeAttachment";
    public static final String RX_CHANGE_ATTACHMENT_FILE_PATH ="attachmentFilePath";
    public static final String RX_CHANGE_ATTACHMENT_FILE_NAME ="attachmentFileName";
    public static final String FILE_CONTENT_DISPOSITION = "Content-Disposition";
    public static final String RX_CHANGE_ATTACHMENT_TITLE = "attachmentTitle";
    public static final String RX_CHANGE_ATTACHMENT_DATA  = "attachmentData";
    public static final String RX_CHANGE_REVIEWER_LIST_NAME="";    
    public static final String RX_CHANGE_PROC_OBJ_ID="rxChangeProcObjId";
	public static final String RX_CHANGE_REQ_OBJ_ID="rxChangeReqObjId";
	public static final String ASSET_PANEL_BUTTON="SUB_TAB_ASSET_CASES_UTILITY_ASSET_PANEL_BUTTON";
	public static final String IS_ASSET_PANEL_PRIVILEGE="isAssetPanelPrivilege";
	public static final String ASSET_PANEL_PAGE="getAssetPanel";
	public static final String ASSET_PANEL_FILE_NAME="getAssetPanelFileName";
	public static final String ASSET_PANEL_VIEW="AssetPanel";
	public static final String ASSET_PANEL_IMAGES_PATH="ASSET_PANEL_IMAGES_PATH";
	public static final String GET_ASSET_PANEL_PARAMETERS="getAssetPanelParameters";
	public static final String ASSET_PANEL_FOLDER="remote_control";
	public static final String ASSET_PANEL_POPOUT_PAGE="getAssetPanelPopout";
	public static final String ASSET_PANEL_FILE_NAME_PER_IMAGE="getAssetPanelFileNamePerImage";
	public static final String ASSET_PANEL_POPOUT_VIEW="AssetPanelPopout";
	public static final String REQUEST_OWNER = "requestOwner";
	public static final String ACTION_TYPE_TAKE_OWNERSHIP= "TAKE_OWNERSHIP";
	public static final String ACTION_TYPE_YANK= "YANK";
	public static final String ACTION_TYPE_PENDING_REQUESTOR= "PENDING_REQUESTOR";
	public static final String ACTION_TYPE_REQUEST_ADDITIONAL_INFORMATION= "REQUEST_ADDITIONAL_INFORMATION";
	public static final String ACTION_TYPE_REJECTED= "REJECTED";
	public static final String ACTION_TYPE_APPROVED= "APPROVED";
	public static final String ACTION_TYPE_REVIEW= "Under Review";
	public static final String STATUS_PENDING_REQUESTOR = "Pending Requestor";
	public static final String GET_RXCHANGE_ADMIN_USERS = "/getRxChangeAdminUsers";
	public static final String ACTION_TYPE_SAVE_AS_DRAFT_ADMIN= "ADMIN_SAVE_DRAFT";
	
	public static final String VIEW_CMH2O="cmH2O";
	public static final String VIEW_INH2O="inH2O";
	public static final String SHOP_ADVICER="Shop Advisor";
	public static final String RX_TYPE_VALUE="rxTypeValue";
	public static final String ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTYPE="<b>Rx Type: </b>";
	public static final String REQ_URI_RX_TYPE = "/getRXTypeLookupValue";
	public static final String ALERT_RX_TYPE_HOVER_TEXT = "ALERT_RX_TYPE_HOVER_TEXT";
	public static final String SUBMITTED = "Submitted";
    public static final String UNDERREVIEW = "Under Review";
    public static final String GET_EOA_ONSITE_ROLES="/getEoaOnsiteRoles";
    public static final String EOA_ONSITE_ENABLED_ROLE_IDS="EOA_ONSITE_ENABLED_ROLE_IDS";
    public static final String EOA_ONSITE_ENABLED_ROLE_NAMES="EOA_ONSITE_ENABLED_ROLE_NAMES";
    
  //For OHV mine and Truck PDF functinality
	
  	public static final String GE_TRANSPORTATION="GE Transportation";
  	public static final String TITLE_ONE="Global Performance Optimization Center";
  	public static final String TITLE_TWO="Remote Monitoring & Diagnostics";
  	public static final String TITLE_THREE_MINE="Mine Fleet Report";
  	public static final String TITLE_THREE_TRUCK="Mine Truck Report";
  	public static final String MINE="Mine: ";
  	public static final String FLEET_FIELD="Fleet: ";
  	public static final String SOFTWARE="Software: ";
  	public static final String GE_MODEL="GE Model: ";
  	public static final String EOA_EQUIPPED="EOA Equipped: ";
  	public static final String CONTROLLER_CFG="Controller Cfg: ";
  	public static final String MINE_STATUS="Mine Status: ";
  	public static final String CUSTOMER_MODEL="Customer Model: ";
  	public static final String COMMUNICATION_STATUS="Communication Status: ";
  	public static final String MESSAGE_RECEIVED="Message Received: ";
  	public static final String HEALTH_REPORTS="Health Reports: ";
  	
  	public static final String TRUCK_NUMBER="Truck Number";
  	public static final String RX_NUMBER="RX Number";
  	public static final String OHV_RX_TITLE="RX Title";
  	public static final String DELIVERED_DATE="Delivered Date";
  	public static final String OPEN_TIME="Open Time";
  	
  	public static final String TOPEVENTS="Top Events";
  	public static final String EVENT_NUMBER="Event Number";
  	public static final String SUB_ID="Sub ID";
  	public static final String DESCRIPTION="Description";
  	public static final String TOTAL_OCCURANCES="Total Occurrences";
  	public static final String TRUCKSPERDAY="Trucks/Day";
  	
  	public static final String OHV_MODEL="Model  ";
  	public static final String LOADS="Loads  ";
  	public static final String ACTIVE_TIME="Active time  ";
  	public static final String OPEN_RXS="Open RX's  ";
	public static final String CLOSED_RXS="Closed RX's  ";
  	public static final String ALL_RXS="All RX's  ";
  	public static final String RED_RXS="Red RX's  ";
  	public static final String WHITE_RXS="White RX's  ";
  	
  	public static final String CONTENT_STREAM="contentStream";
  	public static final String PAGE_HEIGHT="page_height";
  	public static final String PD_DOCUMENT="pd_document";
  	public static final String PD_PAGE="pd_page";
  	public static final String MINE_SMALL="mine";
  	public static final String OHV_HEALTH_REPORT="healthReport";
  	public static final String RX_DELIVERDATE="rxDeliverDate";
  	public static final String RX_CLOSEDDATE="rxClosedDate";
  	public static final String RX_OPENTIME="rxOpenTime";
  	public static final String NO_DATA_AVAILABLE="No data available in table";
	public static final String NO_DATA_AVAILABLE_GRAPH="No data available for graph";
  	public static final String EVENTS_REPORT="eventsReport";
  	public static final String TRUCK="truck";
  	public static final String TRUCK_FIELD="Truck: ";
  	public static final String CUSTOMERMODEL="customerModel";
  	public static final String TRUCK_LOADS="loads";
  	public static final String ACTIVETIME="activeTime";
  	public static final String TRUCKS="trucks";
  	public static final String MINESTATUS="mineStatus";
  	public static final String COMMSTATUS="commStatus";
  	public static final String MESSAGERECEIVED="messageReceived";
  	
  	public static final String EXPORT_PDF="/exportPdf";
  	public static final String TRUCK_BLUE="img/app/urgency_Truck_Blue.png";
  	public static final String TRUCK_RED="img/app/urgency_Truck_Red.png";
  	public static final String TRUCK_YELLOW="img/app/urgency_Truck_Yellow.png";
  	public static final String TRUCK_GREEN="img/app/urgency_Truck_Green.png";
  	public static final String TRUCK_BLACK="img/app/urgency_Truck_Black.png";
  	public static final String GPOC_LOGO="img/app/gpoc_logo.png";
  	public static final String GE_LOGO="img/app/ge_logo.jpg";
  	public static final String LINE_GRAPH="img/app/line_graph.png";
	public static final String PLOT_GRAPH="img/app/plot_graph.png";
	public static final String STATUS_BLUE="img/app/status_BLUE.png";
  	public static final String STATUS_RED="img/app/status_red.png";
  	public static final String STATUS_YELLOW="img/app/status_yellow.png";
  	public static final String STATUS_GREEN="img/app/status_green.png";
  	public static final String WEBINF="/WEB-INF/classes/";
  	public static final String PARAM_VARIABLES="paramVariables";
  	public static final String GRAPHDATA="graphData";
  	public static final String GEMODEL="geModel";
  	public static final String HEALTHREPORTS="healthReports";
  	public static final String EOAEQUIP="eoaEquip";
  	public static final String CLOSED_DATE="Closed Date";
  	public static final String STATS="Stats";
  	public static final String STATS_CONTINUE="Stats Continue";
  	public static final String OPENRX_CONTINUE="Open RX's Continue";
  	public static final String REDRX_CONTINUE="Red RX's Continue";
  	public static final String WHITERX_CONTINUE="White RX's Continue";
	public static final String EVENTS_CONTINUE="Events Continue";
  	public static final String RESET_TIME="Reset Time";
  	public static final String OCCUR_TIME_TRUCK="Occur Time";
  	public static final String LIFETIMEVALUE="lifeTimeValue";
  	public static final String LASTQTRVALUE="lastQtrValue";
  	public static final String LASTMONTHVALUE="lastMonthValue";
  	public static final String THIRTYDAYAVGVALUE="thirtyDayAvgValue";
  	public static final String ONEDAYVALUE="oneDayValue";
  	public static final String PARAMNAME="paramName";
  	public static final String PARAMUNIT="paramUnit";
  	public static final String LIFE_TIME="Life time";
  	public static final String LAST_QTR="Last Qtr";
  	public static final String LAST_MONTH="Last Month";
  	public static final String THIRTY_DAYS="30 Day Avg";
  	public static final String DAY="Day";
	public static final String UNITS="Units";
	public static final String PARAMETER="Parameter";
	public static final String RESETTIME="resetTime";
	public static final String OCCURTIME="occurTime";
	public static final String SUBID="subId";
	public static final String EVENTNUMBER="eventNumber";
	public static final String EVENTS="Events";
	public static final String SOFTWARE_VERSION="software";
	public static final String HEADER="header";
	public static final String HEADER_FIELD="Header: ";
	public static final String REQ_URI_WELCOME="/getWelcome";
	public static final String VIEW_WELCOME = "welcome";
	public static final String REQ_URI_NEWS="/getNews";
	public static final String VIEW_NEWS = "news";
	public static final String GET_CASE_RX_DELV_DETAILS="/getCaseRxDelvDetails";
	public static final String GET_NO_CM_ROLES = "/getNoCMRoles";  	
    public static final String USER_CUSTOMER = "userCustomer";
	public static final String USER_TIMEZONE = "userTimeZone";
	public static final String USER_TIMEZONE_CODE = "userTimeZoneCode";
	public static final String DEFAULT_EST_TIMEZONE = "EST"; 
	public static final String GET_LOOKUP_VALUE_TOOLTIP ="/getLookupValueTooltip";
	public static final String TOOLTIP="toolTip";
	public static final String SORTORDER="sortOrder";
	public static final String REQ_URI_SAVE_NEWS="/saveNews";
	
	//Added for RCI Apply and Delete
    public static final String RCI_OBJID = "rciObjId";
    public static final String RE_APPLY_TEMPLATE = "/reApplyTemplate";
	public static final String DOWNLOAD_TEMPLATE_REPORT = "/downloadTemplateReport";
	public static final String TEMPLATE_REPORT_FILENAME = "TemplatesReport.csv";
	public static final String TEMPLATES_REPORT_HEADER = "TemplatesReportHeader";
	public static final String REQ_URI_TEMPLATE_REPORT = "/templateReport";
	public static final String REQ_URI_GET_TEMPLATE_REPORT = "/getTemplateReport";
	public static final String TEMPLATE_REPORT = "templateReport";
	public static final String GET_RX_CHANGE_HISTORY = "/getRxChangeAuditTrailInfo";
	public static final String SEND_RX_CHANGE_ESCALATION = "/sendRxChangeEscalation";
    public static final String RX_CHANGE_ESCALATION_DATA = "escalationData";
	public static final String ONLOAD="ONLOAD";
	
	public static final String REQ_URI_SOFTWARE_HISTORY="/softwareHistory";
	public static final String VIEW_SOFTWARE_HISTORY="softwareHistory";
	public static final String REQ_URI_VIEW_SOFTWARE_HISTORY_DETAILS = "/softwareHistoryDetails";
	public static final String SOFTWARE_HISTORY_VO = "softwareHistVO";
	public static final String SOFTWARE_HISTORY_EXPORT_FILENAME = "SoftwareHistory.csv";
	public static final String EXPORT_SOFTWARE_HISTORY = "/exportSoftwareHistory";
	public static final String SOFTWARE_HISTORY_MANAGEMENT_HEADER = "SoftwareHistoryManagementHeader";
	public static final String SOFTWARE_HISTORY = "exportSoftwareHistory";
	public static final String EXPORTTYPE = "exportType";
	public static final String ENABLE_CUSTOM_COLUMNS = "enableCustomColumns";
	public static final String REQ_URI_WELCOME_NEWS="/welcomeNews";
	public static final String REQ_URI_DELETE_NEWS="/deleteNews";
	public static final String REQ_URI_ASSET_COMM_REPORT = "/commReport";
	public static final String COMM_REPORT = "commReport";
	public static final String DEFAULT_TEMPLATE_RECORDS="defaultTemplateRecords";
	public static final String TO_DATE_FORMAT_NEWS = "MM/dd/yyyy";
	public static final String REQ_RX_RESEARCH_PAGE = "/getRXResearchPage";
    public static final String RX_RESEARCH = "rxResearch";
    public static final String REQ_RX_RESEARCH_SEARCH_SOLUTION = "/getSearchSolution";
    public static final String REQ_RX_RESEARCH_GET_GRAPH_DATA = "/getGraphicalData";
    public static final String POPULATE_REPAIR_CODE_DETAILS ="/populateRepairCodeDetails";
    //Added for AGT
    public static final String CATEGORY = "category";
    public static final String FROM_AGT = "fromAGT";
    public static final String ASSET_VEH_HDR_NO = "assetVehHdrNo";
    public static final String GET_AGT_TEMPLATES = "/getAGTTemplates";
    public static final String TEMPLATE_STATUS = "templateStatus";
    public static final String REQUEST_TYPE = "requestType";
    public static final String TEMPLATE_VIEW = "templateView";
    public static final String AGT_DEVICE_LIST = "AGT_DEVICE_LIST";
    public static final String GET_AGT_DEVICE_LIST = "/getAGTDeviceList";
    public static final String AGT_OBJID = "agtObjId";
    public static final String SHOW_DEVICE = "SHOW_DEVICE";
    
    public static final String REPORTS_OHV_MINE_STATUS_TOOLTIP_RED="10% of mine fleet has red truck status OR 2 or more trucks have a red Rx repeating 3 times within a 7 day period";
	public static final String REPORTS_OHV_MINE_STATUS_TOOLTIP_YELLOW="10% of mine fleet has yellow truck status OR 5% of fleet has red truck status OR a single truck has a red Rx repeating 3 times within a 7 day period";
	public static final String REPORTS_OHV_MINE_STATUS_TOOLTIP_GREEN="No open red Rx\u2019s. No truck restrictions or operational faults";
	public static final String REPORTS_OHV_MINE_COM_TOOLTIP_RED="Level 2: 25% of mine fleet has blue truck status";
	public static final String REPORTS_OHV_MINE_COM_TOOLTIP_YELLOW="Level 1: 10% of mine fleet has blue truck status";
	public static final String REPORTS_OHV_MINE_COM_TOOLTIP_BLUE="Level 0: Less than 10% of mine fleet has blue truck status";
    public static final String REQ_URI_TECHNICIAN_RX_CHANGE_MODELS = "/getModelForTechnicianScreen";
    public static final String DATA_SCREEN_SHOW_ESERVICE_HISTORY_LINK = "DATA_SCREEN_SHOW_ESERVICE_HISTORY_LINK";
    public static final String ISGOODFDBK = "isGoodFdbk";
    public static final String DATA_SCREEN_NEW_SHOW_ESERVICE_HISTORY_LINK ="DATA_SCREEN_NEW_SHOW_ESERVICE_HISTORY_LINK";
    
    /*
     * US248552: Customers: Incident View - Data Screen Page for all customers - Salana/Chip
     */
    public static final String REQ_URI_FLEET_DATASCREEN="/getFleetDataScreenPage";
    public static final String VIEW_FLEET_DATASCREEN = "fleetDataScreen";
	public static final String VEH_STATUS_OBJID = "vehStatusObjId";
	public static final String RE_NOTIFY_TEMPLATE_ASSOCIATION = "/reNotifyTemplateAssociation";
    public static final String REQ_URI_CREATE_RCI_TEMPLATE = "/createRCITemplate";
    public static final String ADD_UPDATE_RCI = "addUpdateRCI";
    public static final String REQ_URI_OPEN_RCI_TEMPLATE = "/openRCITemplate";
    public static final String UPDATE_RCI_TEMPLATE = "/updateRCITemplate";
    public static final String REQ_URI_GET_RCI_APPLIED_ASSETS = "/getRCIAppliedAssets";
    public static final String FILE_CONTENT = "fileContent";
    public static final String BACKGROUND_IMAGE_URL = "BACKGROUND_IMAGE_URL";
    
  //remove deactive users-Murali D
    public static final String USERDETAILS="userDetails";
    public static final String DELETE_USERDETAILS = "/deleteUserDetails";
    public static final String EXPORT_DELETE_USERS = "/exportDeleteUsers";
    public static final String USER_MANAGEMENT_DELETE_EXPORT_FILENAME = "DeleteUsers.csv";
    public static final String USER_MANAGEMENT_DELETE_HEADER = "UserManagementDeleteHeader";
    public static final String IS_ADMIN_PAGE = "isAdminPage";
    public static final String deleteUserNews = "/deleteUserNews";
    public static final String REQ_URI_UPDATE_READ_FLAG = "/updateReadFlag";
	public static String[] getKmResourceIds() {
        return KM_RESOURCE_IDS;
    }
    

    public static char[] getCharactersThatMustBeQuoted() {
        return CHARACTERS_THAT_MUST_BE_QUOTED;
    }
    

    public static Object[][] getMonthlyRecordsAcc() {
        return MONTHLY_RECORDS_ACC;
    }
    public static Object[][] getMonthlyRecordsNtf() {
        return MONTHLY_RECORDS_NTF;
    }
    public static Object[][] getMonthlyRecordsRes() {
        return MONTHLY_RECORDS_RES;
    }
  	
  	
}
