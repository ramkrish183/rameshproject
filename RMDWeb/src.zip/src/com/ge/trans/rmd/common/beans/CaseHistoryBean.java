package com.ge.trans.rmd.common.beans;

import java.util.List;

public class CaseHistoryBean extends RMDBaseBean{
	String caseID;
	String caseSolutionStatus;
	String caseCondition;
	String currentRxStatus;
	String currentRxCaseId;
	String model;
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	private Long currentSolutionId;
	private String currentRecomNotes;
	
	public String getCurrentRecomNotes() {
		return currentRecomNotes;
	}
	public void setCurrentRecomNotes(String currentRecomNotes) {
		this.currentRecomNotes =currentRecomNotes;
	}
	public Long getCurrentSolutionId() {
		return currentSolutionId;
	}
	public void setCurrentSolutionId(Long currentSolutionId) {
		this.currentSolutionId = currentSolutionId;
	}
	public String getCurrentRxCaseId() {
		return currentRxCaseId;
	}
	public void setCurrentRxCaseId(String currentRxCaseId) {
		this.currentRxCaseId = currentRxCaseId;
	}
	List<NotesBean> notesList;
	
	public String getCaseCondition() {
		return caseCondition;
	}
	public void setCaseCondition(String caseCondition) {
		this.caseCondition = caseCondition;
	}
	public String getCaseID() {
		return caseID;
	}
	public void setCaseID(String caseID) {
		this.caseID = caseID;
	}
	public List<NotesBean> getNotesList() {
		return notesList;
	}
	public void setNotesList(List<NotesBean> notesList) {
		this.notesList = notesList;
	}
	public String getCaseSolutionStatus() {
		return caseSolutionStatus;
	}
	public void setCaseSolutionStatus(String caseSolutionStatus) {
		this.caseSolutionStatus = caseSolutionStatus;
	}
	public String getCurrentRxStatus() {
		return currentRxStatus;
	}
	public void setCurrentRxStatus(String currentRxStatus) {
		this.currentRxStatus = currentRxStatus;
	}
	
	
}
