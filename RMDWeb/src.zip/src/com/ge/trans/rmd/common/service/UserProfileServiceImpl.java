package com.ge.trans.rmd.common.service;




import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Map;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.common.beans.UserProfileBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.services.admin.valueobjects.PersonalDetailType;
import com.ge.trans.rmd.services.admin.valueobjects.UserDetailType;
import com.ge.trans.rmd.services.admin.valueobjects.UserRequestType;
/**
 * *****************************************************************************
 *
 * @Author 		:iGATE Patni 
 * @Version 	: 1.0
 * @Date Created: Nov 15, 2011
 * @Date Modified : 
 * @Modified By : 
 * @Contact 	:
 * @Description : Service invoker class for password change.
 * @History		:
 *
 *****************************************************************************
 */
@Service
public class UserProfileServiceImpl extends RMDBaseServiceImpl implements UserProfileService {
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
	.getLogger(getClass());
	@Autowired
	private WebServiceInvoker rsInvoker;

	@Override
	/**
	 * @Author:iGATE Patni 
	 * @Param userVO - Basic user object to be sent for reset password service
	 * @Param userProfile - Form Bean items to be send the new password
	 * @return Success if its getting positive response, Failed if its getting negative response
	 * @Description : Reset password Service Calling method
	 *  
	 */
	public String resetPassword(final UserVO userVO,final UserProfileBean userProfileBean) throws RMDWebException,Exception {
		rmdWebLogger.debug("resetPassword():START ");
		try
		{

			final Map<String,String> headerParams = getHeaderMap(userProfileBean);	

			final UserDetailType userDetailType = new UserDetailType();
			final PersonalDetailType personalDetailType = new PersonalDetailType();
			DatatypeFactory df = null;
			df = DatatypeFactory.newInstance();
			final GregorianCalendar gc = new GregorianCalendar();
			gc.setTimeInMillis(new Date().getTime());
			final XMLGregorianCalendar lastLoginDate = df.newXMLGregorianCalendar(gc);
			final String timeZone = userVO.getStrTimeZone();
			final String role = userVO.getStrRole();
			final String language = userVO.getStrLanguage();
			userDetailType.setHomePage(userVO.getHomePage());
			userDetailType.setPassword(userProfileBean.getNewPassword());
			userDetailType.setStatus(userVO.getStatus().toString());
			userDetailType.setUserId(userVO.getUserId());
			userDetailType.setUserName(userVO.getStrUserName());
			userDetailType.setUserSeqId(userVO.getUsrUsersSeqId());

			personalDetailType.setFirstName(userVO.getStrFirstName());
			personalDetailType.setHomePhone(AppConstants.EMPTYSTRING);
			personalDetailType.setLastName(userVO.getStrLastName());
			personalDetailType.setUserContactSeqId(userVO.getUsrContactSeqId());

			//Service invoking starts for reset password; 

			final UserRequestType userRequestType=new UserRequestType();
			userRequestType.setLanguage(language);
			userRequestType.setLastLoginDate(lastLoginDate);
			userRequestType.setPersonalDetail(personalDetailType);
			userRequestType.setRole(role);
			userRequestType.setTimeZone(timeZone);
			userRequestType.setUserDetail(userDetailType);
			rsInvoker.put(ServiceConstants.RESET_PASSWORD,userRequestType,headerParams);
			rmdWebLogger.debug("resetPassword():END");
			return AppConstants.SUCCESS;
		}
		catch (Exception e) {
			rmdWebLogger.error("Exception occured in resetPassword() method ", e);
			throw e;
		}

	}



}