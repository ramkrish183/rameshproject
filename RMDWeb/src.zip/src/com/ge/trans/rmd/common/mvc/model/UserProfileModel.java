package com.ge.trans.rmd.common.mvc.model;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

import org.springframework.stereotype.Component;



/**
 * *****************************************************************************
 *
 * @Author 		:iGATE Patni 
 * @Version 	: 1.0
 * @Date Created: Nov 15, 2011
 * @Date Modified : 
 * @Modified By : 
 * @Contact 	:
 * @Description : Simple pojo class for user profile form.
 * @History		:
 *
 *****************************************************************************
 */
@Component
public class UserProfileModel implements Serializable{
	private static final long serialVersionUID = 1L;
	private String userId;
	private Long profileRole;
	@NotNull
	private String oldPassword;
	@NotNull
	private String newPassword;
	@NotNull
	private String confirmPassword;
	private String passwordIndicator;
	private String submitVal;
	private String profileRoles;
	private String customerId;
	
	
	
	


	public String getCustomerId() {
		return customerId;
	}



	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}



	public Long getProfileRole() {
		return profileRole;
	}



	public void setProfileRole(final Long profileRole) {
		this.profileRole = profileRole;
	}



	public String getProfileRoles() {
		return profileRoles;
	}


	
	public void setProfileRoles(final String profileRoles) {
		this.profileRoles = profileRoles;
	}


	public String getSubmitVal() {
		return submitVal;
	}

	
	public void setSubmitVal(final String submitVal) {
		this.submitVal = submitVal;
	}

	public String getPasswordIndicator() {
		return passwordIndicator;
	}
	public void setPasswordIndicator(final String passwordIndicator) {
		this.passwordIndicator = passwordIndicator;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(final String userId) {
		this.userId =userId;
	}
	public String getOldPassword() {
		return oldPassword;
	}
	public void setOldPassword(final String oldPassword) {
		this.oldPassword = oldPassword;
	}
	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(final String newPassword) {
		this.newPassword = newPassword;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(final String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}
	
	
}
