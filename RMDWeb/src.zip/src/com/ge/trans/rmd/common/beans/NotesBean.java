
/*******************************************************************************
 * 
 * @Author : Igate Patni
 * @Version : 1.0
 * @Date Created: Feb 01, 2012
 * @Date Modified :
 * @Modified By :
 * @Contact :
 * @Description : Notes Detail
 * @History :
 * 
 ******************************************************************************/

package com.ge.trans.rmd.common.beans;

import java.util.List;

@SuppressWarnings("serial")
public class NotesBean extends RMDBaseBean {

	String assetNumber;
	String creationDate;
	String createdBy;
	String noteDescription;
	String customerId;
	String assetGroup;
	String caseID;
	String notesType;
	String queueType;
	String descriptionURL;
	String sticky;//Added by Vamsee for addNotesToCase Method
	String userId;//Added by Vamsee for addNotesToCase Method
	String applyLevel;//Added by Vamsee for addNotesToCase Method
	/* Added by Murali for Add Notes to Vehicle (addNotes) screen */
	String fromRN; 
	String toRN;
	String modelId;
	String ctrlId;
	String fleetId;
	String overWriteFlag;
	String stickyObjId;
	String startDate;
	String endDate;
	String searchKeyWord;
	List<String> assetNumbersList;
	/* End of Add Notes to Vehicle */
	
	/**
	 * 
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	
	

	public List<String> getAssetNumbersList() {
		return assetNumbersList;
	}

	public void setAssetNumbersList(List<String> assetNumbersList) {
		this.assetNumbersList = assetNumbersList;
	}

	/**
	 * 
	 * @param setUserId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * 
	 * @return the sticky
	 */
	public String getSticky() {
		return sticky;
	}
	
	
	/**
	 * 
	 * @param setSticky the sticky to set
	 */
	public void setSticky(String sticky) {
		this.sticky = sticky;
	}
	/**
	 * 
	 * @return the applyLevel
	 */
	public String getApplyLevel() {
		return applyLevel;
	}
	
	
	/**
	 * 
	 * @param  setApplyLevel the ApplyLevel to set
	 */
	
	public void setApplyLevel(String applyLevel) {
		this.applyLevel = applyLevel;
	}
	
	

	

	
	public String getDescriptionURL() {
		return descriptionURL;
	}
	public void setDescriptionURL(String descriptionURL) {
		this.descriptionURL = descriptionURL;
	}
	public String getQueueType() {
		return queueType;
	}
	public void setQueueType(String queueType) {
		this.queueType = queueType;
	}
	/**
	 * 
	 * @return the notesType
	 */
	public String getNotesType() {
		return notesType;
	}
	/**
	 * 
	 * @param notesType the notesType to set
	 */
	public void setNotesType(final String notesType) {
		this.notesType = notesType;
	}
	/**
	 * 
	 * @return the caseID
	 */
	public String getCaseID() {
		return caseID;
	}
	/**
	 * 
	 * @param caseID the caseID to set
	 */
	public void setCaseID(final String caseID) {
		this.caseID = caseID;
	}
	/**
	 * 
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}
	/**
	 * 
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(final String customerId) {
		this.customerId = customerId;
	}
	/**
	 * 
	 * @return the assetGroup
	 */
	public String getAssetGroup() {
		return assetGroup;
	}

	public void setAssetGroup(final String assetGroup) {
		this.assetGroup = assetGroup;
	}

	/**
	 * 
	 * @return the assetNumber
	 */
	public String getAssetNumber() {
		return assetNumber;
	}

	/**
	 * 
	 * @param assetNumber
	 *            the assetNumber to set
	 */
	public void setAssetNumber(final String assetNumber) {
		this.assetNumber = assetNumber;
	}

	/**
	 * 
	 * @return the creationDate
	 */
	public String getCreationDate() {
		return creationDate;
	}
	/**
	 * 
	 * @param creationDate the creationDate to set
	 */
	public void setCreationDate(final String creationDate) {
		this.creationDate = creationDate;
	}
	/**
	 * 
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}
	/**
	 * 
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(final String createdBy) {
		this.createdBy = createdBy;
	}
	/**
	 * 
	 * @return the noteDescription
	 */
	public String getNoteDescription() {
		return noteDescription;
	}
	/**
	 * 
	 * @param noteDescription the noteDescription to set
	 */
	public void setNoteDescription(final String noteDescription) {
		this.noteDescription = noteDescription;
	}
	/**
	 * @return the fromRN
	 */
	public String getFromRN() {
		return fromRN;
	}

	/**
	 * @param fromRN the fromRN to set
	 */
	public void setFromRN(String fromRN) {
		this.fromRN = fromRN;
	}

	/**
	 * @return the toRN
	 */
	public String getToRN() {
		return toRN;
	}

	/**
	 * @param toRN the toRN to set
	 */
	public void setToRN(String toRN) {
		this.toRN = toRN;
	}

	/**
	 * @return the modelId
	 */
	public String getModelId() {
		return modelId;
	}

	/**
	 * @param modelId the modelId to set
	 */
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}

	/**
	 * @return the ctrlId
	 */
	public String getCtrlId() {
		return ctrlId;
	}

	/**
	 * @param ctrlId the ctrlId to set
	 */
	public void setCtrlId(String ctrlId) {
		this.ctrlId = ctrlId;
	}

	/**
	 * @return the fleetId
	 */
	public String getFleetId() {
		return fleetId;
	}

	/**
	 * @param fleetId the fleetId to set
	 */
	public void setFleetId(String fleetId) {
		this.fleetId = fleetId;
	}

	/**
	 * @return the overWriteFlag
	 */
	public String getOverWriteFlag() {
		return overWriteFlag;
	}

	/**
	 * @param overWriteFlag the overWriteFlag to set
	 */
	public void setOverWriteFlag(String overWriteFlag) {
		this.overWriteFlag = overWriteFlag;
	}
	

	/**
	 * @return the stickyObjId
	 */
	public String getStickyObjId() {
		return stickyObjId;
	}

	/**
	 * @param stickyObjId the stickyObjId to set
	 */
	public void setStickyObjId(String stickyObjId) {
		this.stickyObjId = stickyObjId;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the searchKeyWord
	 */
	public String getSearchKeyWord() {
		return searchKeyWord;
	}

	/**
	 * @param searchKeyWord the searchKeyWord to set
	 */
	public void setSearchKeyWord(String searchKeyWord) {
		this.searchKeyWord = searchKeyWord;
	}
	
	/**
	 * return the values of class fields
	 */
@Override	public String toString() {
		return "CreatedBy:" + createdBy + ", CreatedDate:" + creationDate
				+ ", NoteDescription:" + noteDescription;
	}

}
