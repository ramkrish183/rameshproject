/**
 * ============================================================
 * File : UserManagementServiceImpl.java
 * Description : Web layer service implementation class for user management
 * 
 * Package : com.ge.trans.rmd.common.service
 * Author : iGATE
 * Last Edited By :
 * Version : 1.0
 * Created on : November 19, 2012
 * History :
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2012 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.UserEOADetailsVO;
import com.ge.trans.rmd.common.beans.UserManagementBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.vo.RolesVO;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.admin.valueobjects.PersonalDetailType;
import com.ge.trans.rmd.services.admin.valueobjects.RolesType;
import com.ge.trans.rmd.services.admin.valueobjects.UserDeleteRequestType;
import com.ge.trans.rmd.services.admin.valueobjects.UserDetailType;
import com.ge.trans.rmd.services.admin.valueobjects.UserRequestType;
import com.ge.trans.rmd.services.admin.valueobjects.UsersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.UserEOADetailsResponseType;
import com.ge.trans.rmd.services.authorization.valueobjects.PrivilegeDetailsType;
import com.ge.trans.rmd.services.authorization.valueobjects.RolesResponseType;
import com.ge.trans.rmd.utilities.AppSecUtil;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class UserManagementServiceImpl extends RMDBaseServiceImpl implements
		UserManagementService {

	@Autowired
	private WebServiceInvoker rsInvoker;

	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	@Autowired
	private CachedService cachedService;
	/**
	 * @Author:
	 * @param
	 * @return UserManagementVO
	 * @Description: This method will return List of users from Database
	 */
	@Override
	public List<UserManagementBean> getUsers(
			final UserManagementBean userManagementBean) throws RMDWebException,
			Exception {
		logger.debug("UserManagementServiceImpl : getUsers() method Starts");
		UsersResponseType[] arUserRespType = null;
		final List<UserManagementBean> userMgmntBeanList = new ArrayList<UserManagementBean>();
		final LinkedHashMap<String, String> queryParams = new LinkedHashMap<String, String>();

		final Map<String, String> headerParams = getHeaderMap(userManagementBean);
		UserManagementBean userMgmntBean = null;
		String userRoles=null;
		StringBuilder builder = new StringBuilder();

		try {
			if(userManagementBean.getCustomerIdList()!=null && !userManagementBean.getCustomerIdList().isEmpty()){
			for(String customer : userManagementBean.getCustomerIdList())
			{
				builder.append(customer+
						",");
				
			}
			String queryResult = builder.toString();
			queryParams.put(AppConstants.CUSTOMER_ID,
					queryResult);
			}
			queryParams.put(AppConstants.DEFAULT_CUSTOMER,
					userManagementBean.getDefaultCustomer());
			if(userManagementBean.getUserType()!= null && !userManagementBean.getUserType().equals(AppConstants.EMPTY_STRING)){
				queryParams.put(AppConstants.USERTYPE,
						userManagementBean.getUserType());
			}

			arUserRespType = (UsersResponseType[]) rsInvoker.get(
					ServiceConstants.ADMIN_GET_USER_DETAILS, null, queryParams,
					headerParams, UsersResponseType[].class);

			if (arUserRespType != null && arUserRespType.length > 0) {
				for (UsersResponseType userRespType : arUserRespType) {

					userMgmntBean = new UserManagementBean();

					userMgmntBean.setCustomerId(userRespType.getCustomerId());
					List<String> customerList=userRespType.getUserDetail().getListCustomerIds();
					if (null != customerList && !customerList.isEmpty()) {

						String userCutomers = AppConstants.EMPTY_STRING;
						for (String customer : customerList) {
							userCutomers = userCutomers + customer
									+ AppConstants.COMMA
									+ AppConstants.EMPTY_SPACE;
						}
						userCutomers = userCutomers.substring(0,
								userCutomers.length() - 2);
						userMgmntBean.setUserCustomers(userCutomers);
					}
					
					userMgmntBean.setStrFirstName(EsapiUtil.escapeSpecialChars(AppSecUtil.decodeString(userRespType
							.getPersonalDetail().getFirstName())));
					userMgmntBean.setStrLastName(EsapiUtil.escapeSpecialChars(AppSecUtil.decodeString(userRespType
							.getPersonalDetail().getLastName())));
					/*Changed by Vamshi For replacing middle name with email Id*/
					userMgmntBean.setEmailId(userRespType
							.getPersonalDetail().getEmail());
					userMgmntBean.setUserId(EsapiUtil.escapeSpecialChars(AppSecUtil.decodeString(userRespType.getUserDetail()
							.getUserId())));
					userMgmntBean.setUserType(userRespType.getUserDetail()
							.getUserType());
					//newly added code
					userMgmntBean.setLastUpdatedBy(userRespType.getUserDetail()
							.getLastUpdatedBy());
					userMgmntBean.setLastUpdatedTime(userRespType.getUserDetail()
							.getLastUpdatedTime());
					
					userMgmntBean.setStrUserName(userRespType.getUserDetail()
							.getUserName());
					userMgmntBean.setUserSeqId(RMDCommonUtility
							.convertObjectToString(userRespType.getUserDetail()
									.getUserSeqId()));
					userMgmntBean.setLanguage(userRespType.getUserDetail()
							.getStrLanguage());
					userMgmntBean.setUom(userRespType.getUom());
					//Added by Murali Medicherla for Rally Id : US226051
					userMgmntBean.setMobileAccess(userRespType.getUserDetail().getMobileAccess());
					userMgmntBean.setEndUserScoring(userRespType.getUserDetail().getEndUserScoring());
					userRoles=""; 
					//MultiRole changes
					if (null != userRespType.getRolesDetail()
							&& RMDCommonUtility
									.isCollectionNotEmpty(userRespType
											.getRolesDetail())) {
						Map<String,String> roles=new LinkedHashMap<String, String>();
						for (RolesType role : userRespType.getRolesDetail()) {
							if(role.getUserRolesSeqId()!=0){
							roles.put(role.getUserRolesSeqId()+"",role.getRoleName());
							if(userRoles.length()>0){
								userRoles=userRoles+",";
							}
							userRoles=userRoles+role.getUserRolesSeqId();
							}
						}
						userMgmntBean.setRoles(roles);
						userMgmntBean.setUserRoleIds(userRoles);
					}
					if (null != userRespType.getDefaultRole()) {
						userMgmntBean.setStrRole(userRespType.getDefaultRole());
					}
					userMgmntBean.setStatus(userRespType.getUserDetail()
							.getStatus());

					userMgmntBeanList.add(userMgmntBean);
				}
				arUserRespType=null;
			}
		} catch (Exception ex) {
			logger.error(
					"Exception occured in UserManagementServiceImpl() method getUsers",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("UserManagementServiceImpl : getUsers() method Ends");
		return userMgmntBeanList;
	}
	
	/**
	 * @Author:
	 * @return: Customer Map
	 * @Description: Fetching customer
	 */
	@Override
	public Map<String, String> getCustomers() throws RMDWebException {

		Map<String, String> sortedCustomerMap = null;
		try {

			sortedCustomerMap = new LinkedHashMap<String, String>(
					cachedService.getCustomers());

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				logger.error("UserManagementServiceImpl :: No records found for getCustomers() service "
						+ e.getMessage());
			} else {
				logger.error("UserManagementServiceImpl :: Exception occured in getCustomers() method "
						+ e.getMessage());
				throw e;
			}
		} catch (Exception ex) {
			logger.error("Exception occured in getCustomers method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return sortedCustomerMap;

	}

	/**
	 * @Author:iGATE
	 * @param UserManagementBean
	 * @return void
	 * @Description: This method will return List of users from Database
	 */
	@Override
	public void saveEditUserDetails(final UserManagementBean userManagementBean)
			throws RMDWebException, Exception {
		logger.debug("UserManagementServiceImpl : saveEditUserDetails() method Starts");

		final Map<String, String> headerParams = getHeaderMap(userManagementBean);
		final UserRequestType userRequestType = new UserRequestType();

		try {

			userRequestType.setRole(userManagementBean.getStrRole());
			if(userManagementBean.getEoaOnsiteUser()!=null && !userManagementBean.getEoaOnsiteUser().equals(AppConstants.EMPTYSTRING)){
				userRequestType.setEoaOnsiteUser(userManagementBean.getEoaOnsiteUser());
			}
			else
			{
				userRequestType.setEoaOnsiteUser(AppConstants.NO_EOA_USER);
			}

			final PersonalDetailType objPersonalDetailType = new PersonalDetailType();
			final UserDetailType objUserDetailType = new UserDetailType();
			objUserDetailType.setCustomerId(userManagementBean.getCustomerId());
			if(null !=userManagementBean.getCustomerIdList() && !userManagementBean.getCustomerIdList().isEmpty()){
				objUserDetailType.getListCustomerIds().addAll(userManagementBean.getCustomerIdList());
			}
			
			objPersonalDetailType.setFirstName(ESAPI.encoder().encodeForXML(EsapiUtil.resumeSpecialChars(userManagementBean
					.getStrFirstName())));
			objPersonalDetailType.setLastName(ESAPI.encoder().encodeForXML(EsapiUtil.resumeSpecialChars(userManagementBean
					.getStrLastName())));
			objPersonalDetailType.setEmail(ESAPI.encoder().encodeForXML(userManagementBean
					.getEmailId()));
			objUserDetailType.setUserSeqId(RMDCommonUtility
					.convertObjectToLong(userManagementBean.getUserSeqId()));
			objUserDetailType.setUserId(ESAPI.encoder().encodeForXML(EsapiUtil.resumeSpecialChars(userManagementBean.getUserId())));
			objUserDetailType.setUserType(userManagementBean.getUserType());
			objUserDetailType.setNewUserIdEntered(ESAPI.encoder().encodeForXML(userManagementBean
					.getNewUserIdEntered()));
			/*if (null != userManagementBean.getStrRole()
					&& !(RMDCommonConstants.ZERO_STRING)
							.equals(userManagementBean.getStrRole())) {
				objUserDetailType.setStatus(RMDCommonConstants.ONE_STRING);
			} else {
				objUserDetailType.setStatus(RMDCommonConstants.ZERO_STRING);
			}*/
			objUserDetailType.setStatus(userManagementBean.getStatus());
			//Added by Murali Medicherla for Rally Id : US226051
			objUserDetailType.setMobileAccess(userManagementBean.getMobileAccess());
			objUserDetailType.setEndUserScoring(userManagementBean.getEndUserScoring());
			userRequestType.setUserDetail(objUserDetailType);
			userRequestType.setPersonalDetail(objPersonalDetailType);
			userRequestType.setDefaultRole(userManagementBean.getStrRole());
			userRequestType.setRolesChangeFlag(userManagementBean.getRoleChangeFlag());
			userRequestType.setLanguage(userManagementBean.getLanguage());
			userRequestType.setOldUserId(userManagementBean.getOldUserId());
			userRequestType.setUom(userManagementBean.getUom());
			RolesType roleType=null;
			if(null!=userManagementBean.getRoles() && userManagementBean.getRoles().size()>0){
				for(String role:userManagementBean.getRoles().keySet()){
					roleType=new RolesType();
					roleType.setUserRolesSeqId(Long.parseLong(role));
					userRequestType.getRolesDetail().add(roleType);
				}
			}
			
			/* Added for MDSC Admin */
			if (RMDCommonConstants.Y_LETTER_UPPER
							.equalsIgnoreCase(userManagementBean
									.getUpdateEOAUser()) &&
					(RMDCommonConstants.Y_LETTER_UPPER
							.equalsIgnoreCase(userManagementBean.getOmdCMFlag()) || RMDCommonConstants.Y_LETTER_UPPER
							.equalsIgnoreCase(userManagementBean.getOmdMLFlag()) || RMDCommonConstants.Y_LETTER_UPPER
							.equalsIgnoreCase(userManagementBean.getOmdCmMmPrevRemoved()))){
				userRequestType.setUpdateEOAUser(userManagementBean
						.getUpdateEOAUser());
				userRequestType.setEoaCMFlag(userManagementBean.getEoaCMFlag());
				userRequestType.setEoaMLFlag(userManagementBean.getEoaMLFlag());
				userRequestType.setEoaAlias(userManagementBean.getEoaAlias());
				userRequestType.setEoaMLVal(userManagementBean.getEoaMLVal());
				userRequestType.setOmdCMFlag(userManagementBean.getOmdCMFlag());
				userRequestType.setOmdMLFlag(userManagementBean.getOmdMLFlag());
				userRequestType.setOmdCmMlPrevRemoved(userManagementBean.getOmdCmMmPrevRemoved());
				userRequestType.setOmdMlAloneRemoved(userManagementBean.getOmdMlAloneRemoved());
				userRequestType.setEoaEmetricsFlag(userManagementBean.getEoaEmetricsFlag());
				userRequestType.setEoaEmetricsVal(userManagementBean.getEoaEmetricsVal());
				userRequestType.setOmdEmetricsFlag(userManagementBean.getOmdEmetricsFlag());
				userRequestType.setOmdEmetricsAloneRemoved(userManagementBean.getOmdEmetricsAloneRemoved());

			}
			/* End of MDSC Admin */
			
			rsInvoker.put(ServiceConstants.ADMIN_SAVE_EDIT_USER_DETAILS,
					userRequestType, headerParams);

		} catch (Exception ex) {
			logger.error("Exception occured in saveEditUserDetails method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		logger.debug("UserManagementServiceImpl : saveEditUserDetails() method Ends");
	}

	
	/**
	 * @Author:iGATE
	 * @param UserManagementBean
	 * @return void
	 * @Description: This method will return all roles from database
	 */
	@Override
	public List<RolesVO> getAllRoles(final UserManagementBean userManagementBean)
			throws RMDWebException, Exception {
		logger.debug("UserManagementServiceImpl : getAllRoles() method Starts");
		RolesResponseType[] arRoleRespType = null;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		final Map<String, String> headerParams = getHeaderMap(userManagementBean);
		final List<RolesVO> rolesVOLst = new ArrayList<RolesVO>();
		RolesVO roleVO = null;

		try {

			arRoleRespType = (RolesResponseType[]) rsInvoker.get(
					ServiceConstants.ADMIN_SERVICE_GET_ALL_ROLES, null, queryParams,
					headerParams, RolesResponseType[].class); 
					
			if (arRoleRespType != null && arRoleRespType.length > 0) {
				for (RolesResponseType roleRespType : arRoleRespType) {
					roleVO = new RolesVO();
					roleVO.setGetUsrRolesSeqId(roleRespType.getRoleSeqId());
					roleVO.setRoleName(roleRespType.getRoleName());
					roleVO.setStatus(roleRespType.getStatus());
					roleVO.setRoleDesc(roleRespType.getRoleDescription());
					rolesVOLst.add(roleVO);
				}
			}
		} catch (Exception ex) {
			logger.error("Exception occured in getAllRoles method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		logger.debug("UserManagementServiceImpl : getAllRoles() method Ends");
		return rolesVOLst;
	}

	/**
	 * @Author:
	 * @param :
	 * @param :
	 * @return:List<RolesVO>
	 * @throws:RMDWebException
	 * @Description:This method returns the list of roles which have Case
	 *                   Management Privilege by calling the RESTful Web
	 *                   Services.
	 */
	@Override
	public List<RolesVO> getCaseMgmtRoles() throws RMDWebException {

		List<RolesVO> rolesList = new ArrayList<RolesVO>();
		try {

			RolesResponseType[] objRolesResponseTypesList = (RolesResponseType[]) rsInvoker
					.get(ServiceConstants.GET_CM_PRIVILEGE_ROLES, null, null,
							null, RolesResponseType[].class);
				for (RolesResponseType objResponseType : objRolesResponseTypesList) {
					RolesVO objRolesVO = new RolesVO();
					objRolesVO.setRoleName(objResponseType.getRoleName());
					objRolesVO.setGetUsrRolesSeqId(objResponseType
							.getRoleSeqId());
					rolesList.add(objRolesVO);

				}
			
		} catch (Exception e) {
			logger.error("Exception occured in getCaseMgmtRoles method of UserManagementServiceImpl"
					+ e);
			RMDWebErrorHandler.handleException(e);

		}
		return rolesList;
	}

	/**
	 * @Author:
	 * @param :
	 * @param :userId
	 * @return:String
	 * @throws:RMDWebException
	 * @Description:This method is used for fetching the EOA UserId by calling
	 *                   the by calling the RESTful Web Services.
	 */

	@Override
	public String getEoaUserName(String userId) throws RMDWebException, Exception {

		String eoaUserName = null;
		UserRequestType userRequestType=new UserRequestType();
		try{
			userRequestType.setUserId(userId);
			eoaUserName =(String) rsInvoker
			.post(ServiceConstants.GET_EOA_USERID, userRequestType, String.class);

			if(RMDCommonConstants.NO_EOA_USER.equalsIgnoreCase(eoaUserName)){
				eoaUserName=null;
			}
		} catch (Exception e) {
			logger.error("Excepiton occured in getEoaUserId method of UserManagementServiceImpl" + e);
			RMDWebErrorHandler.handleException(e);

		}

		return eoaUserName;
	}
	/**
	 * @Author : IgatePatni
	 * @param :
	 * @return : AssetLocatorResponseVO
	 * @throws RMDWebException
	 * 
	 * @Description: This method will fetch the lookup value for last download
	 *               status of the asset
	 */
	@Override
	public Map<String, String> getAdminLookUp(String listName)
			throws RMDWebException, Exception {
		Map<String, String> listNameMap = null;
		Map<String, String> resultMap = new LinkedHashMap<String, String>();;
		try {
			listNameMap = new LinkedHashMap<String, String>();
			listNameMap.put(AppConstants.LIST_NAME, listName);

			ApplicationParametersResponseType[] applParamResponseType = getLookupValue(listNameMap);
			if(null!=applParamResponseType){
			for (int i = 0; i < applParamResponseType.length; i++) {
				resultMap.put(applParamResponseType[i]
						.getLookupValue(),applParamResponseType[i].getLookupValue());
			}
			}
		} catch (Exception ex) {
			throw ex;
		}
		return resultMap;

	}
	
	/**
	 * @Author:iGATE
	 * @param UserManagementBean
	 * @return List<UserManagementBean>
	 * @Description: This method will return List of enabled users who has alert
	 *               subscription privilege from Database
	 */
	@Override
	public List<UserManagementBean> getAlertUsers(
			final UserManagementBean userManagementBean)
			throws RMDWebException, Exception {
		logger.debug("UserManagementServiceImpl : getAlertUsers() method Starts");
		UsersResponseType[] arUserRespType = null;
		final List<UserManagementBean> userMgmntBeanList = new ArrayList<UserManagementBean>();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();

		final Map<String, String> headerParams = getHeaderMap(userManagementBean);
		UserManagementBean userMgmntBean = null;
		String userRoles = null;

		try {

			arUserRespType = (UsersResponseType[]) rsInvoker.get(
					ServiceConstants.GET_ADMIN_NOTIFICATION_USERS_DETAILS,
					null, queryParams, headerParams, UsersResponseType[].class);

			if (arUserRespType != null && arUserRespType.length > 0) {
				for (UsersResponseType userRespType : arUserRespType) {

					userMgmntBean = new UserManagementBean();

					userMgmntBean.setCustomerId(userRespType.getCustomerId());
					List<String> customerList = userRespType.getUserDetail()
							.getListCustomerIds();
					if (null != customerList && !customerList.isEmpty()) {

						String userCutomers = AppConstants.EMPTY_STRING;
						for (String customer : customerList) {
							userCutomers = userCutomers + customer
									+ AppConstants.COMMA
									+ AppConstants.EMPTY_SPACE;
						}
						userCutomers = userCutomers.substring(0,
								userCutomers.length() - 2);
						userMgmntBean.setUserCustomers(userCutomers);
					}

					userMgmntBean.setStrFirstName(userRespType
							.getPersonalDetail().getFirstName());
					userMgmntBean.setStrLastName(userRespType
							.getPersonalDetail().getLastName());
					userMgmntBean.setEmailId(userRespType
							.getPersonalDetail().getEmail());
					userMgmntBean.setUserId(userRespType.getUserDetail()
							.getUserId());
					userMgmntBean.setStrUserName(userRespType.getUserDetail()
							.getUserName());
					userMgmntBean.setUserSeqId(RMDCommonUtility
							.convertObjectToString(userRespType.getUserDetail()
									.getUserSeqId()));
					userMgmntBean.setLanguage(userRespType.getUserDetail()
							.getStrLanguage());

					userRoles = "";
					// MultiRole changes
					if (null != userRespType.getRolesDetail()
							&& RMDCommonUtility
									.isCollectionNotEmpty(userRespType
											.getRolesDetail())) {
						Map<String, String> roles = new LinkedHashMap<String, String>();
						for (RolesType role : userRespType.getRolesDetail()) {
							if (role.getUserRolesSeqId() != 0) {
								roles.put(role.getUserRolesSeqId() + "",
										role.getRoleName());
								if (userRoles.length() > 0) {
									userRoles = userRoles + ",";
								}
								userRoles = userRoles
										+ role.getUserRolesSeqId();
							}
						}
						userMgmntBean.setRoles(roles);
						userMgmntBean.setUserRoleIds(userRoles);
					}
					if (null != userRespType.getDefaultRole()) {
						userMgmntBean.setStrRole(userRespType.getDefaultRole());
					}
					userMgmntBean.setStatus(userRespType.getUserDetail()
							.getStatus());

					userMgmntBeanList.add(userMgmntBean);
				}
				arUserRespType = null; 
			}
		} catch (Exception ex) {
			logger.error(
					"Exception occured in UserManagementServiceImpl() method getAlertUsers",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("UserManagementServiceImpl : getAlertUsers() method Ends");
		return userMgmntBeanList;
	}
	
	public List<String> getUserComponentList(String userId)
			throws RMDWebException {
		PrivilegeDetailsType[] privilegeDetailsResponse = null;
		List<String> userComponentList = new ArrayList<String>();
		String privilageName = null;
		try {
			privilegeDetailsResponse = (PrivilegeDetailsType[]) rsInvoker
					.post(ServiceConstants.GET_USER_COMPONENT_LIST, userId,
							PrivilegeDetailsType[].class);
			if (privilegeDetailsResponse != null
					&& privilegeDetailsResponse.length > 0) {
				for (PrivilegeDetailsType privRespType : privilegeDetailsResponse) {
					privilageName = privRespType.getDisplayName();
					userComponentList.add(privilageName);
				}
			}
		} catch (Exception ex) {
			logger
					.error("Exception occured in AlertSubscriptionServiceImpl() method getUserComponentList",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return userComponentList;
	}

	/**
	 * @Author:
	 * @param :roleId,userId
	 * @return:UserEOADetailsVO
	 * @throws:RMDWebException
	 * @Description: This method is used to check whether the selected role is
	 *               having CM / Multilingual/emetrics privilege
	 */
	@Override
	public UserEOADetailsVO getCMorMLDetails(String roleId,String userId,String removedRoleId) throws RMDWebException {
		Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		UserEOADetailsVO objUserDetailsVO=null;
		UserEOADetailsResponseType objUserEOADetailsResponseType=null;
		try {
			queryParamMap.put(AppConstants.ROLE_ID, roleId);
			queryParamMap.put(AppConstants.USER_ID, userId);
			queryParamMap.put(AppConstants.REMOVED_ROLE_ID, removedRoleId);
			objUserEOADetailsResponseType = (UserEOADetailsResponseType) rsInvoker
					.get(ServiceConstants.GET_CM_ML_PRIVILIGES, null,
							queryParamMap, null,
							UserEOADetailsResponseType.class);	
			if (null != objUserEOADetailsResponseType) {
				objUserDetailsVO = new UserEOADetailsVO();
				objUserDetailsVO.setUserId(objUserEOADetailsResponseType.getUserId());
				objUserDetailsVO.setFirstName(objUserEOADetailsResponseType.getFirstName());
				objUserDetailsVO.setLastName(objUserEOADetailsResponseType.getLastName());
				objUserDetailsVO.setAliasName(objUserEOADetailsResponseType.getAliasName());
				objUserDetailsVO.setEmailId(objUserEOADetailsResponseType.getEmailId());
				objUserDetailsVO.setEoaMLVal(objUserEOADetailsResponseType.getEoaMLVal());
				objUserDetailsVO.setOmdCMPrevFlag(objUserEOADetailsResponseType.isOmdCMPrevFlag());
				objUserDetailsVO.setOmdMLPrevFlag(objUserEOADetailsResponseType.isOmdMLPrevFlag());								
				objUserDetailsVO.setEoaCMPrevFlag(objUserEOADetailsResponseType.isEoaCMPrevFlag());
				objUserDetailsVO.setEoaMLPrevFlag(objUserEOADetailsResponseType.isEoaMLPrevFlag());
				objUserDetailsVO.setBlnOMDCmMlPreRemoved(objUserEOADetailsResponseType.isBlnOMDCmMlPreRemoved());
				objUserDetailsVO.setBlnOMDMlAloneRemoved(objUserEOADetailsResponseType.isBlnOMDMlAloneRemoved());
				objUserDetailsVO.setEoaEmetricsPrevFlag(objUserEOADetailsResponseType.isEoaEmetricsPrevFlag());
				objUserDetailsVO.setEoaEmetricsVal(objUserEOADetailsResponseType.getEoaEmetricsVal());
				objUserDetailsVO.setBlnOMDEmetricsAloneRemoved(objUserEOADetailsResponseType.isBlnOMDEmetricsAloneRemoved());
				objUserDetailsVO.setOmdEmetricsPrevFlag(objUserEOADetailsResponseType.isOmdEmetricsPrevFlag());
				objUserDetailsVO.setBlnOMDCmMlEmetricsPreRemoved(objUserEOADetailsResponseType.isBlnOMDCmMlEmetricsPreRemoved());
				objUserDetailsVO.setErrorMsg(objUserEOADetailsResponseType.getErrorMsg());
				objUserDetailsVO.setEndScoringFlag(objUserEOADetailsResponseType.getEndUserScoring());
			}
		} catch (Exception ex) {
			logger
					.error("Exception occured in getCMorMLDetails() method of UserManagementServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}finally{
			queryParamMap=null;
			objUserEOADetailsResponseType=null;
		}
		return objUserDetailsVO;
	}

	/**
	 * @Author:
	 * @param :
	 * @param :aliasName
	 * @return:String
	 * @throws:RMDWebException
	 * @Description:This method is used for checking whether the entered aliasName is exist or not
	 */
	@Override
	public String checkUserAlias(String aliasName) throws RMDWebException {
		String result = RMDCommonConstants.NO;
		Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		try{
			queryParamMap.put(AppConstants.EOA_ALIAS, aliasName);
			result =(String) rsInvoker
			.get(ServiceConstants.CHECK_EOA_ALIAS_EXIST, null,
					queryParamMap, null,
					String.class);

		} catch (Exception e) {
			logger.error("Excepiton occured in checkUserAlias method of UserManagementServiceImpl" + e);
			RMDWebErrorHandler.handleException(e);

		}
		return result;
	}
	@Override
	public List<RolesVO> getEoaOnsiteRoles() throws RMDWebException {

		List<RolesVO> rolesList = new ArrayList<RolesVO>();
		try {

			RolesResponseType[] objRolesResponseTypesList = (RolesResponseType[]) rsInvoker
					.get(ServiceConstants.GET_EOA_ONSITE_ROLES, null, null,
							null, RolesResponseType[].class);
				for (RolesResponseType objResponseType : objRolesResponseTypesList) {
					RolesVO objRolesVO = new RolesVO();
					objRolesVO.setRoleName(objResponseType.getRoleName());
					objRolesVO.setGetUsrRolesSeqId(objResponseType
							.getRoleSeqId());
					rolesList.add(objRolesVO);

				}
				objRolesResponseTypesList = null;
		} catch (Exception e) {
			logger.error("Exception occured in getEoaOnsiteRoles method of UserManagementServiceImpl"
					+ e);
			RMDWebErrorHandler.handleException(e);

		}
		return rolesList;
	}

	
    @Override
    public List<RolesVO> getNoCMRoles() throws RMDWebException {
        List<RolesVO> arListRoles=null;  
        RolesVO objRolesVO =null;
        RolesResponseType[] objRolesResponseTypesList =null;
        try{        
            objRolesResponseTypesList = (RolesResponseType[]) rsInvoker
                    .get(ServiceConstants.GET_NO_CM_ROLES, null, null,
                            null, RolesResponseType[].class);
            if(null!=objRolesResponseTypesList && objRolesResponseTypesList.length>0){
                arListRoles=new ArrayList<RolesVO>(objRolesResponseTypesList.length);
                for (RolesResponseType objResponseType : objRolesResponseTypesList) {
                    objRolesVO = new RolesVO();
                    objRolesVO.setRoleName(objResponseType.getRoleName());
                    objRolesVO.setGetUsrRolesSeqId(objResponseType
                            .getRoleSeqId());
                    arListRoles.add(objRolesVO);

                }
            }
        }catch (Exception e) {
            logger.error("Exception occured in getNoCMRoles method of UserManagementServiceImpl"
                    + e);
            RMDWebErrorHandler.handleException(e);

        }
        return arListRoles;
    }

	@Override
	public String deleteUserDetails(List<String> userdetails) throws RMDWebException, Exception {
		// TODO Auto-generated method stub
		final UserDeleteRequestType userRequestType = new UserDeleteRequestType();
		userRequestType.setUserIds(userdetails);
		String responce = null;
		try{
		responce = (String)rsInvoker.post(ServiceConstants.ADMIN_DELETE_USER_DETAILS, userRequestType, String.class);
		}catch (Exception e) {
			// TODO: handle exception
			logger.error("Exception occured in getNoCMRoles method of UserManagementServiceImpl"
                    + e);
            RMDWebErrorHandler.handleException(e);
		}
		
		return responce;
	}
}