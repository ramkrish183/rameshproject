/**
 * ============================================================
 * File : UserManagementController.java
 * Description : Web layer controller class for user management
 * 
 * Package : com.ge.trans.rmd.common.mvc.controller
 * Author : iGATE
 * Last Edited By :
 * Version : 1.0
 * Created on : November 19, 2012
 * History :
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2012 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.trans.rmd.cm.valueobjects.UserEOADetailsVO;
import com.ge.trans.rmd.common.beans.UserManagementBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.service.UserManagementService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.AppSecUtil;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.CustomerVO;
import com.ge.trans.rmd.common.vo.DeleteRolesExportVO;
import com.ge.trans.rmd.common.vo.DeleteRolesUpdateVO;
import com.ge.trans.rmd.common.vo.RolesVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
public class UserManagementController extends RMDBaseController {

	@Autowired
	private UserManagementService userManagementService;

	@Autowired
	private AuthorizationService authService;
	
	@Autowired
	private ApplicationContext appContext;

	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	/**
	 * @Author:iGATE
	 * @param request
	 * @return String
	 * @Description: method to get user management page
	 */
	@RequestMapping(value = AppConstants.REQ_URI_USERMANAGEMENT, method = RequestMethod.GET)
	public String getuserManagementPage(final HttpServletRequest request)
			throws Exception {
		logger.debug("UserManagementController Controller : getuserManagementPage() method Starts");
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		List<UserManagementBean> userMgmntBeanList = new ArrayList<UserManagementBean>();
		final UserManagementBean userMgmntBean = new UserManagementBean();
		final UserManagementBean userMgmntCompPrivBean = new UserManagementBean();
		String addUserCompName = null;
		String editUserCompName = null;
		String deleteUserCompName = null;
		boolean addComp = false;
		boolean editComp = false;
		boolean deleteComp = false;
		String addEditEOAAliasMlCompName=AppConstants.EMPTY_STRING;
		boolean blnAddEditEOAAliasMl = false;
		List<RolesVO> cmPriveilegeRoles = null;
		List<RolesVO> eoaOnsitePrivilegeRoles = null;
		List<Long> lstCMEnabledRoles = new ArrayList<Long>();
		List<Long> lstEOAOnsiteEnabledRoleIds = new ArrayList<Long>();
		List<String> lstEOAOnsiteEnabledRoleNames = new ArrayList<String>();
		try {
						
			userMgmntBeanList = userManagementService.getUsers(userMgmntBean);
			addUserCompName = authService
					.getLookUpValueForName(AppConstants.USERMANAGEMENT_ADDUSER);
			editUserCompName = authService
					.getLookUpValueForName(AppConstants.USERMANAGEMENT_EDITUSER);
			deleteUserCompName = authService
					.getLookUpValueForName(AppConstants.USERMANAGEMENT_DELETEUSER);
			addComp = RMDCommonUtil.componentValue(userVO.getComponentList(),
					addUserCompName);
			editComp = RMDCommonUtil.componentValue(userVO.getComponentList(),
					editUserCompName);
			deleteComp = RMDCommonUtil.componentValue(userVO.getComponentList(),
					deleteUserCompName);

			userMgmntCompPrivBean.setAddUserComponent(addComp);
			userMgmntCompPrivBean.setEditUserComponent(editComp);
			userMgmntCompPrivBean.setDeleteUserComponent(editComp);

			/* Added by Mural for MDSC Admin changes*/
			addEditEOAAliasMlCompName = authService
					.getLookUpValueForName(AppConstants.MDSC_ADMIN_PRIVILEGE);
			blnAddEditEOAAliasMl = RMDCommonUtil.componentValue(userVO.getComponentList(),
					addEditEOAAliasMlCompName);
			userMgmntCompPrivBean.setBlnMDSCUser(blnAddEditEOAAliasMl);
			/*End of MDSC Admin*/
			
			/*Added by Murali Medicherla for Rally Id : US226051 */
			//If we want to support multiple roles add values in comma separated format and split here
			String roleName = authService.getLookUpValueForName(AppConstants.MOBILE_ACCESS_PRIVILEGE_ROLES);
			if(roleName != null && !roleName.trim().equals("")){
				for(RolesVO roleVO : userVO.getRolesVOLst()){
					if(roleVO.getGetUsrRolesSeqId().intValue() == userVO.getRoleId().intValue() && (roleName.equalsIgnoreCase(roleVO.getRoleName()) 
							|| roleName.equalsIgnoreCase(roleVO.getRoleDesc()) )){
						userMgmntCompPrivBean.setMobileAccessPrivilege(true);
						break;
					}
				}
			}
			/*Added by Murali Medicherla for Mobile Authentication */
			cmPriveilegeRoles = userManagementService.getCaseMgmtRoles();
			eoaOnsitePrivilegeRoles = userManagementService.getEoaOnsiteRoles();
			for(RolesVO roles : cmPriveilegeRoles ){
				lstCMEnabledRoles.add(roles.getGetUsrRolesSeqId());
			}
			for(RolesVO eoaOnsiteroles : eoaOnsitePrivilegeRoles ){
				lstEOAOnsiteEnabledRoleIds.add(eoaOnsiteroles.getGetUsrRolesSeqId());
				lstEOAOnsiteEnabledRoleNames.add(eoaOnsiteroles.getRoleName());
			}
			
			request.setAttribute(AppConstants.USER_MGMNT_LIST,
					userMgmntBeanList);
			request.setAttribute(AppConstants.USER_MGMNT_COMPONENT_BEAN,
					userMgmntCompPrivBean);
			request.setAttribute(AppConstants.CM_ENABLED_ROLES,
					lstCMEnabledRoles);
			request.setAttribute(AppConstants.EOA_ONSITE_ENABLED_ROLE_IDS,
					lstEOAOnsiteEnabledRoleIds);
			request.setAttribute(AppConstants.EOA_ONSITE_ENABLED_ROLE_NAMES,
					lstEOAOnsiteEnabledRoleNames);
			//adding for pagination
			request.setAttribute(
					AppConstants.ADMINISTRATOR_DEFAULT_RECORDS,
					findNumberOfRecords(AppConstants.ADMINISTRATOR_TABLE_DEFAULT_RECORDS));
			
		} catch (Exception ex) {
			logger.error("Exception occured in getuserManagementPage method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("UserManagementController Controller : getuserManagementPage() method Ends");
		return AppConstants.VIEW_USERMANAGEMENT;
	}

	/**
	 * 
	 * @return This controller method will return the list of customers
	 */
	@RequestMapping(value = AppConstants.GET_ALL_CUSTOMER, method = RequestMethod.GET)
	public @ResponseBody
	Map<String, String> getCustomers(final Model model,
			final HttpServletRequest request) throws RMDWebException {

		logger.debug("Inside UserManagementController  in getCustomers Method");
		Map<String, String> customerMap = new LinkedHashMap<String, String>();
		String userType = request.getParameter("userType");
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {

			if(userType!= null && userType.equals("EOA")){
				for(CustomerVO customer:userVO.getCustomerList()){
					customerMap.put(customer.getCustomerID(),customer.getCustomerName());
				}
			}
			else
			{
			customerMap = userManagementService.getCustomers();
			}

		} catch (Exception ex) {
			logger.error("Exception occured in getCustomers method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return customerMap;
	}
	
	/**
	 * @Author:iGATE
	 * @param request
	 * @return List<UserManagementBean>
	 * @Description: This method will return List of UserManagementBean if any
	 *               validation error occurs if the save/edit is success then it
	 *               will return empty list
	 */
	@RequestMapping(value = AppConstants.REQ_URI_SAVE_EDIT_USER, method = RequestMethod.POST)
	public @ResponseBody
	java.util.List<UserManagementBean> saveEditUserDetails(
			final HttpServletRequest request) throws Exception {
		logger.debug("UserManagementController Controller : saveEditUserDetails() method Starts");

		final List<UserManagementBean> userMgmntBeanList = new ArrayList<UserManagementBean>();
		final UserManagementBean userMgmntBean = new UserManagementBean();
		final HttpSession session = request.getSession(false);
		final String userSeqId = request.getParameter(AppConstants.USER_SEQID);
		String userId = request.getParameter(AppConstants.USERID);
		String userType = request.getParameter(AppConstants.USERTYPE);
		final String firstName = request.getParameter(AppConstants.FIRSTNAME);
		final String emailId = request.getParameter(AppConstants.EMAIL_ID);
		final String lastName = request.getParameter(AppConstants.LASTNAME);
		final String roleIds = request.getParameter(AppConstants.USER_ROLE);
		final String defaultRole = request.getParameter(AppConstants.USER_DEAFULT_ROLE);
		final String customerId = request.getParameter(AppConstants.CUSTOMERID);
		final String status = request.getParameter(AppConstants.USER_STATUS);
		final String roleChangeFlag = request.getParameter(AppConstants.ROLE_CHANGE_FLAG);
		final String defaultLanguage = request.getParameter(AppConstants.DEFAULT_LANGUAGE);
		final String defaultCustomer = request.getParameter(AppConstants.DEFAULT_CUSTOMER);
		final String oldUserId = request.getParameter(AppConstants.OLDUSERID);
		final String uom = request.getParameter(AppConstants.UOM);
		/*Added for MDSC Admin*/
		final String eoaCMFlag = request.getParameter(AppConstants.EOA_CM_FLAG);
		final String eoaMLFlag = request.getParameter(AppConstants.EOA_ML_FLAG);
		final String omdCMFlag = request.getParameter(AppConstants.OMD_CM_FLAG);
		final String omdMLFlag = request.getParameter(AppConstants.OMD_ML_FLAG);
		final String eoaAlias = request.getParameter(AppConstants.EOA_ALIAS);
		final String eoaMLVal = request.getParameter(AppConstants.EOA_ML_VAL);
		final String updateEOAUser = request.getParameter(AppConstants.UPDATE_EOA_USER);
		final String omdCmMlPrevRemoved = request.getParameter(AppConstants.OMD_CM_ML_PREV_REMOVED);
		final String omdMlAloneRemoved =request.getParameter(AppConstants.OMD_ML_ALONE_REMOVED);
		final String eoaEmetricsFlag=request.getParameter(AppConstants.EOA_EMETRICS_FLAG);
		final String omdEmetricsFlag=request.getParameter(AppConstants.OMD_EMETRICS_FLAG);
		final String eoaEmetricsVal=request.getParameter(AppConstants.EOA_EMETRICS_VAL);
		final String omdEmetricsAloneRemoved =request.getParameter(AppConstants.OMD_EMETRICS_FLAG_ALONE_REMOVED);
		/*End of MDSC Admin*/
		//Added by Murali Medicherla for Rally Id : US226051
		final String mobileAccessVal=request.getParameter(AppConstants.MOBILE_ACCESS);
		final String endUserScoring=request.getParameter(AppConstants.END_SCORING_FLAG);
		final String isEoaAdmin = request.getParameter(AppConstants.IS_EOA_ONSITE_USER);
		try {
			if (null != userId) {
				userId = userId.trim();
			}
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			userMgmntBean.setOldUserId(oldUserId);			
			userMgmntBean.setUserSeqId(userSeqId);
			userMgmntBean.setUserId(userVO.getUserId());
			userMgmntBean.setUserType(userType);
			userMgmntBean.setStrFirstName(firstName);
			userMgmntBean.setEmailId(emailId);
			userMgmntBean.setStrLastName(lastName);
			userMgmntBean.setStrRole(defaultRole);
			userMgmntBean.setStatus(status);
			userMgmntBean.setRoleChangeFlag(roleChangeFlag);
			userMgmntBean.setLanguage(defaultLanguage);
			userMgmntBean.setNewUserIdEntered(userId);
			userMgmntBean.setUom(uom);
			//Added by Murali Medicherla for Rally Id : US226051
			userMgmntBean.setMobileAccess(mobileAccessVal);
			userMgmntBean.setEndUserScoring(endUserScoring);
			userMgmntBean.setEoaOnsiteUser(isEoaAdmin);
			if (null != customerId
					&& !customerId.equals(RMDCommonConstants.ALL_CUSTOMER)
					&& !customerId.equals(RMDCommonConstants.NULL_STRING)) {
				String customerIdArr[] = customerId
						.split(AppConstants.SYMBOL_COMMA);
				List<String> customerIds = new ArrayList<String>();
				for (String currentCustomerId : customerIdArr) {
					customerIds.add(currentCustomerId);
				}
				if (null != customerIds && customerIds.size() > 1) {
					customerIds.remove(RMDCommonConstants.ALL_CUSTOMER);
				}
				userMgmntBean.setCustomerIdList(customerIds);
			}
				userMgmntBean.setCustomerId(defaultCustomer);	
			if (null !=roleIds && !roleIds.equals(AppConstants.EMPTY_STRING)) {
				String rolesIdArr[] = roleIds.split(AppConstants.SYMBOL_COMMA);
				Map<String,String> roleMap=new HashMap<String,String>();
				for (String roleId : rolesIdArr) {
					roleMap.put(roleId, roleId);
				}
				userMgmntBean.setRoles(roleMap);
			}
			
			/* Added for MDSC Admin changes */
			if (RMDCommonConstants.Y_LETTER_UPPER
							.equalsIgnoreCase(updateEOAUser) &&
				(RMDCommonConstants.Y_LETTER_UPPER
							.equalsIgnoreCase(omdCMFlag) || RMDCommonConstants.Y_LETTER_UPPER
							.equalsIgnoreCase(omdMLFlag)||RMDCommonConstants.Y_LETTER_UPPER
							.equalsIgnoreCase(omdCmMlPrevRemoved) || RMDCommonConstants.Y_LETTER_UPPER
							.equalsIgnoreCase(omdEmetricsFlag))) {
				userMgmntBean.setUpdateEOAUser(updateEOAUser);
				userMgmntBean.setEoaCMFlag(eoaCMFlag);
				userMgmntBean.setEoaMLFlag(eoaMLFlag);
				userMgmntBean.setEoaAlias(eoaAlias);
				userMgmntBean.setEoaMLVal(eoaMLVal);
				userMgmntBean.setOmdCMFlag(omdCMFlag);
				userMgmntBean.setOmdMLFlag(omdMLFlag);
				userMgmntBean.setOmdCmMmPrevRemoved(omdCmMlPrevRemoved);
				userMgmntBean.setOmdMlAloneRemoved(omdMlAloneRemoved);
				userMgmntBean.setEoaEmetricsFlag(eoaEmetricsFlag);
				userMgmntBean.setEoaEmetricsVal(eoaEmetricsVal);
				userMgmntBean.setOmdEmetricsFlag(omdEmetricsFlag);
				userMgmntBean.setOmdEmetricsAloneRemoved(omdEmetricsAloneRemoved);
			}
			/* ENd of MDSC Admin */
			
			final Map<String, String> result = validateUserInput(userMgmntBean);
			if (!result.isEmpty() && null != result) {
				final UserManagementBean usrMgmntBean = new UserManagementBean();
				usrMgmntBean.setErrorMsg(result);
				userMgmntBeanList.add(usrMgmntBean);

			} else {
				userManagementService.saveEditUserDetails(userMgmntBean);
				if (null != userId) {
				if(userVO.getUserId().equalsIgnoreCase(userId)){
				userVO.setEndUserScoring(endUserScoring);
				session.setAttribute(AppConstants.ATTR_USER_OBJECT,userVO);
				}
			}
		}
		} catch (Exception ex) {
			logger.error("Exception occured in getuserManagementPage method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("UserManagementController Controller : saveEditUserDetails() method Ends");
		return userMgmntBeanList;
	}
	
	
	/**
	 * GE Transportation
	 * @param request
	 * @return List<UserManagementBean>
	 * @Description: This method will return List of UserManagementBean if any
	 *               validation error occurs if the save/edit is success then it
	 *               will return empty list
	 */
	@RequestMapping(value = AppConstants.DELETE_USERDETAILS, method = RequestMethod.POST)
	@ResponseBody
	public String deleteUserDetails(@RequestParam(AppConstants.USERDETAILS) String userDetails) throws Exception {
		logger.debug("UserManagementController Controller : deleteUserDetails() method Starts");
		logger.debug("User details: "+userDetails);
		final ObjectMapper mapper = new ObjectMapper();
		String responce = null;
		String[] delRolUpdTempList = mapper.readValue(
				EsapiUtil.stripXSSCharacters(userDetails), String[].class);
		
		List<String> userIds = Arrays.asList(delRolUpdTempList);
		
		/*String[] array = userDetails.split(",\\s*");
		logger.debug("User details List: "+array);
		ArrayList<String> userIds = new ArrayList<String>(Arrays.asList(array));*/
		
		//List<String> userIds = Arrays.asList(userDetails.split(","));
		logger.debug("User details List: "+userIds);
		try{
			if(userIds.size() > 0){
				responce = userManagementService.deleteUserDetails(userIds);
				logger.debug("responce........ "+responce);
			}
			
		}catch (Exception ex) {
			// TODO: handle exception
			logger.error("Exception occured in deleteUserDetails method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		
		logger.debug("UserManagementController Controller : deleteUserDetails() method End");
		return responce;
	}
	
	@RequestMapping(value = AppConstants.EXPORT_DELETE_USERS, method = RequestMethod.POST)
	public void exportDeleteUserManagementPage(@RequestParam(AppConstants.GET_PARAMETER_STRING) String paramString,final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws IOException, GenericAjaxException, RMDWebException {
		
		List<UserManagementBean> tempList = new ArrayList<UserManagementBean>();
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		
		logger.debug("parameterString ############ "+paramString);
		final ObjectMapper mapper = new ObjectMapper();
		logger.debug("Inside exportDeleteUserManagementPage method");
		try {
			UserManagementBean[] delRolUpdTempList = mapper.readValue(
					EsapiUtil.stripXSSCharacters(paramString), UserManagementBean[].class);
			tempList = Arrays.asList(delRolUpdTempList);
			csvContent = convertToCSVDeleteUsers(tempList, locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.USER_MANAGEMENT_DELETE_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);

			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);

			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (Exception ex) {
			logger.error("Exception occured in exportDeleteUserManagementPage method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}
	
	private String convertToCSVDeleteUsers(List<UserManagementBean> tempList, Locale locale) {
		String csvContent = null;
		StringBuffer strBufferAssetHeader = new StringBuffer();
		try {
			strBufferAssetHeader.append(appContext.getMessage(
					AppConstants.USER_MANAGEMENT_DELETE_HEADER, null, locale));
			strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			for (UserManagementBean rolesList : tempList) {
				if (null != rolesList.getUserId()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getUserId() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != rolesList.getStrFirstName()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getStrFirstName() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != rolesList.getStrLastName()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getStrLastName() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != rolesList.getCustomerId()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getCustomerId() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != rolesList.getEmailId()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getEmailId() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				
				strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBufferAssetHeader.toString();
		} catch (Exception exception) {
			logger.error("Export to CSV delete Role Management"
					+ exception.getMessage());
		}
		return csvContent;
	}

	/**
	 * @Author:iGATE
	 * @param UserManagementBean
	 * @return Map<String,String>
	 * @throws
	 * @Description * This method is used for Validating user input for add/edit
	 *              user.
	 */

	public Map<String, String> validateUserInput(
			final UserManagementBean usrMgmntBean) {
		final Map<String, String> result = new HashMap<String, String>();
		String emailRegex=null;
		try {
			// title validations
			/*Added by Vamshi for Email Validation Changes*/
			emailRegex=getLookUpValueForName(AppConstants.EMAIL_REGEX);
			
			if (null == usrMgmntBean.getNewUserIdEntered()
					|| usrMgmntBean.getNewUserIdEntered().isEmpty()) {
				result.put(AppConstants.USERID, AppConstants.INVALID);
			}
			if(RMDCommonUtility.isSpecialCharactersFound(usrMgmntBean
					.getNewUserIdEntered())){
				result.put(AppConstants.USERID, AppConstants.SPECIAL_CHARACTER_FOUND);
				
			}
			if (null == usrMgmntBean.getUserType()
					|| usrMgmntBean.getUserType().isEmpty()) {
				result.put(AppConstants.USERTYPE, AppConstants.INVALID);
			}
			if (null == usrMgmntBean.getUserId()
					|| usrMgmntBean.getStrFirstName().isEmpty()
					) {
				result.put(AppConstants.FIRSTNAME, AppConstants.INVALID);
			}
			if (RMDCommonUtility.isSpecialCharactersFound(usrMgmntBean
							.getStrFirstName())) {
				result.put(AppConstants.FIRSTNAME, AppConstants.SPECIAL_CHARACTER_FOUND);
			}

			if (null == usrMgmntBean.getStrLastName()
					|| usrMgmntBean.getStrLastName().isEmpty()) {
				result.put(AppConstants.LASTNAME, AppConstants.INVALID);
			}

			if ( RMDCommonUtility.isSpecialCharactersFound(usrMgmntBean
							.getStrLastName())) {
				result.put(AppConstants.LASTNAME, AppConstants.SPECIAL_CHARACTER_FOUND);
			}
			
			/*Added by Vamshi for Email Field*/
			if (RMDCommonUtility.isNullOrEmpty(usrMgmntBean.getEmailId())) {
				result.put(AppConstants.EMAIL_ID, AppConstants.INVALID);
			}
			if (!RMDCommonUtility.isNullOrEmpty(usrMgmntBean.getEmailId())
					&& !AppSecUtil.validateEmailAddress(usrMgmntBean
							.getEmailId(),emailRegex)) {
				result.put(AppConstants.EMAIL_ID, AppConstants.SPECIAL_CHARACTER_FOUND);
			}
			/*End of Changes*/

			if (null== usrMgmntBean
					.getStrRole() || usrMgmntBean
					.getStrRole().isEmpty()) {
				result.put(AppConstants.USER_ROLE, AppConstants.INVALID );
			}
			if (RMDCommonUtility.isSpecialCharactersFound(usrMgmntBean
					.getStrRole())) {
				result.put(AppConstants.USER_ROLE, AppConstants.SPECIAL_CHARACTER_FOUND );
			}
			if (null != usrMgmntBean.getRoles()
					&& !(usrMgmntBean.getRoles()).isEmpty()
					&& null != usrMgmntBean.getNewUserIdEntered()) {
				
				String matchedRoles = AppConstants.EMPTY_STRING;
				List<Long> selectedRoleList=new ArrayList<Long>();
				String cmRoleStatus = AppConstants.FAILURE;

				for (String role : usrMgmntBean.getRoles().keySet()) {
					selectedRoleList.add(Long.parseLong(role));
				}
				/*Modified for MDSC Admin Changes*/
				if(!RMDCommonConstants.Y_LETTER_UPPER.equalsIgnoreCase(usrMgmntBean.getUpdateEOAUser())){
					List<RolesVO> roleList = userManagementService
							.getCaseMgmtRoles();
				
					for (RolesVO role : roleList) {
						if(selectedRoleList.contains(role.getGetUsrRolesSeqId())){
							matchedRoles += role.getRoleName()+ AppConstants.COMMA;
							cmRoleStatus = AppConstants.SUCCESS;
						}					
						
					}
					if (AppConstants.SUCCESS.equalsIgnoreCase(cmRoleStatus)) {
						String eoaUserId = userManagementService
								.getEoaUserName(usrMgmntBean.getNewUserIdEntered());
						if (null == eoaUserId && null != matchedRoles) {
							matchedRoles = matchedRoles.replaceAll(
									AppConstants.REMOVE_COMMA_REGEXPRESSION,
									AppConstants.EMPTY_STRING);
							result.put(AppConstants.CM_MATCHED_ROLES, matchedRoles);
						}
	
					}
				} else if (RMDCommonConstants.Y_LETTER_UPPER
						.equalsIgnoreCase(usrMgmntBean.getOmdCMFlag())
						|| RMDCommonConstants.Y_LETTER_UPPER
								.equalsIgnoreCase(usrMgmntBean.getOmdMLFlag())) {
					if (RMDCommonUtility.isNullOrEmpty(usrMgmntBean
							.getEoaAlias())) {
						result.put(AppConstants.EOA_ALIAS, AppConstants.INVALID);
					}else if(RMDCommonUtility.isOnlySpecialCharactersFound(usrMgmntBean
							.getEoaAlias())){
						result.put(AppConstants.EOA_ALIAS, AppConstants.ONLY_SPECIAL_CHARACTER_FOUND);	
                    } else if (!RMDCommonConstants.Y_LETTER_UPPER
                            .equalsIgnoreCase(usrMgmntBean.getEoaCMFlag())
                            && (null != usrMgmntBean.getUserSeqId()
                            && AppConstants.ZERO.equalsIgnoreCase(usrMgmntBean
                                    .getUserSeqId()))) {
                        String aliasExist = userManagementService
                                .checkUserAlias(usrMgmntBean.getEoaAlias());
                        if (RMDCommonConstants.YES.equalsIgnoreCase(aliasExist)) {
                            result.put(AppConstants.EOA_ALIAS,
                                    AppConstants.EOA_ALIAS_EXISTS);
                        }
                    }
					if(null == result.get(AppConstants.USERID)){
    					if (!RMDCommonUtility.isNumbersOnly(usrMgmntBean.getNewUserIdEntered())) {
    						result.put(AppConstants.USERID, AppConstants.CM_ML_USERID_INVALID);
    					}else if(usrMgmntBean.getNewUserIdEntered().length() != RMDCommonConstants.ALPHA_BRACKET){
    						result.put(AppConstants.USERID, AppConstants.CM_ML_USERID_LENGTH_INVALID);
    					}
					}
					if(RMDCommonConstants.Y_LETTER_UPPER
							.equalsIgnoreCase(usrMgmntBean.getOmdMLFlag()) && RMDCommonConstants.ONE_STRING
							.equalsIgnoreCase(usrMgmntBean.getStatus()) && (null==usrMgmntBean.getEoaMLVal() || usrMgmntBean.getEoaMLVal().isEmpty())){
						result.put(AppConstants.MULTILINGUAL, AppConstants.INVALID);
					}
					/*End of MDSC Admin Changes*/
				}
				if(RMDCommonUtility.isOnlySpecialCharactersFound(usrMgmntBean
						.getEoaAlias())){
					result.put(AppConstants.EOA_ALIAS, AppConstants.ONLY_SPECIAL_CHARACTER_FOUND);	
				}
			}
			
			if (null == usrMgmntBean.getCustomerId()
					|| usrMgmntBean.getCustomerId().equals(
							RMDCommonConstants.NULL_STRING)
					|| usrMgmntBean.getCustomerId().isEmpty()
					|| RMDCommonConstants.ZERO_STRING.equals(usrMgmntBean.getCustomerId())) {
				result.put(AppConstants.CUSTOMERID, AppConstants.INVALID );

			} else if (RMDCommonUtility.isSpecialCharactersFound(usrMgmntBean
					.getCustomerId())) {
				result.put(AppConstants.CUSTOMERID, AppConstants.SPECIAL_CHARACTER_FOUND);
			}

		} catch (Exception exception) {
			logger.error("Error occured in validateUserInput"
					+ exception.getMessage());
		}
		return result;
	}
	
	/**
	 * @Author:iGATE
	 * @param request
	 * @return String
	 * @Description: method to get all roles
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_ALL_USER_ROLES, method = RequestMethod.GET)
	public @ResponseBody List<RolesVO> getAllRoles(final HttpServletRequest request)
			throws Exception {
		logger.debug("UserManagementController Controller : getAllRoles() method Starts");
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final UserManagementBean userMgmntBean = new UserManagementBean();
		String userType = request.getParameter("userType");
		List<RolesVO> rolesVOLst = new ArrayList<RolesVO>();

		try {
			userMgmntBean.setCustomerId(userVO.getCustomerId());
			userMgmntBean.setCustomerName(userVO.getCustomerName());
			if(userType!= null && userType.equals("EOA")){
				rolesVOLst = userVO.getRolesVOLst();
			}
			else
			{
			rolesVOLst = userManagementService.getAllRoles(userMgmntBean);
			}
			
		} catch (Exception ex) {
			logger.error("Exception occured in getAllUserRoles() method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("UserManagementController Controller : getAllUserRoles() method Ends");
		return rolesVOLst;
	}
	
	/**
	 * @Description:This method is used to  export the user list from the user Management page
	 * @return: void
	 * @param:HttpServletRequest request,HttpServletResponse response,Locale
	 *                           locale
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 */
	@RequestMapping(value = AppConstants.EXPORT_USERS, method = RequestMethod.POST)
	public void exportUserManagementPage(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws IOException, GenericAjaxException, RMDWebException {
		List<UserManagementBean> userMgmntBeanList = new ArrayList<UserManagementBean>();
		final UserManagementBean userMgmntBean = new UserManagementBean();

		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;

		try {
			userMgmntBeanList = userManagementService.getUsers(userMgmntBean);
			csvContent = convertToCSVUsers(userMgmntBeanList, locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.USER_MANAGEMENT_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);

			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);

			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (Exception ex) {
			logger.error("Exception occured in getLifeStatisticsData method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}
		}
	}

	/**
	 * @Description:This method is used convert User management List into csv format
	 * @return: String
	 * @param:List<UserManagementBean> userMgmntBeanList, Locale locale
	 */
	private String convertToCSVUsers(
			List<UserManagementBean> userMgmntBeanList, Locale locale) {
		String csvContent = null;
		StringBuffer strBufferAssetHeader = new StringBuffer();
		try {
			strBufferAssetHeader.append(appContext.getMessage(
					AppConstants.USER_MANAGEMENT_HEADER, null, locale));
			strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			for (UserManagementBean userMgmntList : userMgmntBeanList) {
				strBufferAssetHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE + userMgmntList.getUserId()
						+ AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR);
				if (null != userMgmntList.getStrFirstName()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ userMgmntList.getStrFirstName()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != userMgmntList.getStrLastName()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ userMgmntList.getStrLastName()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != userMgmntList.getEmailId()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ userMgmntList.getEmailId()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != userMgmntList.getLastUpdatedBy()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ userMgmntList.getLastUpdatedBy()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != userMgmntList.getLastUpdatedTime()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ userMgmntList.getLastUpdatedTime()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				strBufferAssetHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE);
				if (null != userMgmntList.getRoles()) {
					Map<String, String> roles = userMgmntList.getRoles();
					String roles2 = "";
					if (null != userMgmntList.getStrRole()) {
						roles2 = userMgmntList.getStrRole()
								+ RMDCommonConstants.COMMMA_SEPARATOR;
					}
						for (String role : roles.values()) {
							if(null !=role && !role.equals(userMgmntList.getStrRole()) ) {
								roles2 = roles2 + role
										+ RMDCommonConstants.COMMMA_SEPARATOR;
							}
						}
						if(roles2.length()>0){
							strBufferAssetHeader.append(roles2.substring(0,
									roles2.length() - 1));
						}
						
					
				}
				strBufferAssetHeader.append(AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR);
				if (null != userMgmntList.getUserCustomers() && userMgmntList
						.getUserCustomers().length() != 0
						&& !userMgmntList.getUserCustomers().equalsIgnoreCase(
								RMDCommonConstants.ALL_CUSTOMER)) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ userMgmntList.getUserCustomers()
							+ AppConstants.QUOTE);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ AppConstants.ALL_CUSTOMERS + AppConstants.QUOTE);
				}
				if (userMgmntList.getStatus().equalsIgnoreCase(
						AppConstants.ACCOUNT_STATUS_ENABLED)) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.ENABLED + AppConstants.QUOTE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.DISABLED
									+ AppConstants.QUOTE);
				}
				if (null != userMgmntList.getUserType() && userMgmntList
						.getUserType().length() != 0) {
					strBufferAssetHeader.append(RMDCommonConstants.COMMMA_SEPARATOR
							+ AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ userMgmntList.getUserType()
							+ AppConstants.QUOTE);
				} else {
					strBufferAssetHeader.append(RMDCommonConstants.COMMMA_SEPARATOR
							+ AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE);
				}
				strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBufferAssetHeader.toString();
		} catch (Exception exception) {
			logger.error("Export to CSV User Mangement"
					+ exception.getMessage());
		}
		return csvContent;
	}
	
		/**
	 * @Author:
	 * @param :
	 * @param :
	 * @return:List<RolesVO>
	 * @throws:Exception
	 * @Description:This method returns the list of roles which have Case
	 *                   Management Privilege by calling the Service Layers
	 *                   getCaseMgmtRoles() method.
	 */
	@RequestMapping(value = AppConstants.GET_CM_PRIVILEGE_ROLES, method = RequestMethod.GET)
	public @ResponseBody
	List<RolesVO> getCaseMgmtRoles() throws Exception {
		List<RolesVO> rolesVOList = new ArrayList<RolesVO>();
		try {
			rolesVOList = userManagementService.getCaseMgmtRoles();
		} catch (Exception ex) {
			logger.error(
					"Exception occured in getCaseMgmtRoles() method of UserManagementController ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return rolesVOList;
	}

	/**
	 * @Author:
	 * @param :
	 * @param :userId
	 * @return:String
	 * @throws:Exception
	 * @Description:This method is used for fetching the EOA UserId by calling
	 *                   the by calling the Service Layer getEoaUserId() method.
	 */
	@RequestMapping(value = AppConstants.GET_EOA_USERID, method = RequestMethod.GET)
	public @ResponseBody
	String getEoaUserId(
			@RequestParam(value = AppConstants.USER_ID) final String userId)
			throws Exception {
		String eoaUserName = null;

		try {
			
				if (AppSecUtil.checkAlphaNumeric(userId)) {
					eoaUserName = userManagementService.getEoaUserName(EsapiUtil.stripXSSCharacters(userId));
				}

		} catch (Exception ex) {
			logger.error(
					"Exception occured in getEoaUserId() method of UserManagementController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return eoaUserName;

	}
	
	
	
	/**
	 * @Author:iGATE
	 * @param request
	 * @return Map<String, String>
	 * @Description: method to get all UserType from the lookup
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_USER_TYPE, method = RequestMethod.GET)
	public @ResponseBody Map<String, String> getUserTypes(final HttpServletRequest request)
			throws Exception {
		logger.debug("UserManagementController Controller : getUserTypes() method Starts");
		Map<String, String> userTypeMap = null;

		try {
			userTypeMap = userManagementService.getAdminLookUp(AppConstants.USER_TYPE);
			
		} catch (Exception ex) {
			logger.error("Exception occured in getUserTypes() method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("UserManagementController Controller : getUserTypes() method Ends");
		return userTypeMap;
	}
	
	/**
	 * @Author:iGATE
	 * @param request
	 * @return Map<String, String>
	 * @Description: method to get all UserType from the lookup
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_UOM, method = RequestMethod.GET)
	public @ResponseBody Map<String, String> getUnitOfMeasure(final HttpServletRequest request)
			throws Exception {
		logger.debug("UserManagementController Controller : getUnitOfMeasure() method Starts");
		Map<String, String> uomMap = null;

		try {
			uomMap = userManagementService.getAdminLookUp(AppConstants.MEASUREMENT_SYSYTEM);
			
		} catch (Exception ex) {
			logger.error("Exception occured in getUnitOfMeasure() method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("UserManagementController Controller : getUnitOfMeasure() method Ends");
		return uomMap;
	}

	/**
	 * @Author:
	 * @param :roleId,SSOId,removedRoleId
	 * @return:UserEOADetailsVO
	 * @throws:RMDWebException
	 * @Description: This method is used to check whether the selected role is
	 *               having CM / Multilingual privilege
	 */

	@RequestMapping(value = AppConstants.REQ_URI_GET_CM_ML_PRIVILIGES)
	public @ResponseBody UserEOADetailsVO getCMorMLDetails(
			@RequestParam(value = AppConstants.ROLE_ID) final String roleId,
			@RequestParam(value = AppConstants.USER_ID) final String userId,
			@RequestParam(value = AppConstants.REMOVED_ROLE_ID) final String removedRoleId)
			throws RMDWebException {

		UserEOADetailsVO objUserEOADetailsVO = null;
		try {
			if ((!RMDCommonUtility.isNullOrEmpty(roleId) || !RMDCommonUtility
					.isNullOrEmpty(removedRoleId))
					&& !RMDCommonUtility.isNullOrEmpty(userId)) {
			objUserEOADetailsVO = userManagementService.getCMorMLDetails(
						EsapiUtil.stripXSSCharacters(roleId), EsapiUtil.stripXSSCharacters(userId), EsapiUtil.stripXSSCharacters(removedRoleId));
			}
		} catch (Exception ex) {
			logger.error(
					"Exception occured in getCMorMLDetails method in UserManagementController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		
		return objUserEOADetailsVO;
	}
	/**
	 * @Author:
	 * @param :
	 * @param :
	 * @return:List<RolesVO>
	 * @throws:Exception
	 * @Description:This method returns the list of roles which have EOA Onsite
	 *                   Management Privilege by calling the Service Layers
	 *                   getEoaOnsiteRoles() method.
	 */
	@RequestMapping(value = AppConstants.GET_EOA_ONSITE_ROLES, method = RequestMethod.GET)
	@ResponseBody public 
	List<RolesVO> getEoaOnsiteRoles() throws Exception {
		List<RolesVO> rolesVOList = new ArrayList<RolesVO>();
		try {
			rolesVOList = userManagementService.getEoaOnsiteRoles();
		} catch (Exception ex) {
			logger.error(
					"Exception occured in getEoaOnsiteRoles() method of UserManagementController ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return rolesVOList;
	}
	
	/**
     * @Author:
     * @param :
     * @param :
     * @return:List<RolesVO>
     * @throws:RMDWebException
     * @Description:This method returns the list of roles which are note having Case
     *                   Management Privilege
     */
	@RequestMapping(value=AppConstants.GET_NO_CM_ROLES, method = RequestMethod.GET)
	@ResponseBody
	public List<RolesVO> getNoCMRoles() throws Exception{
	    List<RolesVO> arListRoles=null;
	    try{
	        arListRoles=userManagementService.getNoCMRoles();
	    } catch (Exception ex) {
            logger.error(
                    "Exception occured in getNoCMRoles() method of UserManagementController ",
                    ex);
            RMDWebErrorHandler.handleException(ex);
        }
	    
        return arListRoles;
	    
	}
}
