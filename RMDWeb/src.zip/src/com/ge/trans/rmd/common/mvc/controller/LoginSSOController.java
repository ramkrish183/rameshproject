/**
 * ============================================================
 * File : LoginController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.mvc.controller
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Nov 17, 2011
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.mvc.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedSet;
import java.util.StringTokenizer;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ge.trans.rmd.common.beans.CustomerAssetBean;
import com.ge.trans.rmd.common.beans.FavoriteFilterBean;
import com.ge.trans.rmd.common.beans.UserLoginBean;
import com.ge.trans.rmd.common.beans.UserPreferenceBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.AuthenticationException;
import com.ge.trans.rmd.common.exception.AuthorizationException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.model.LoginModel;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.service.FavoriteFilterService;
import com.ge.trans.rmd.common.service.LoginService;
import com.ge.trans.rmd.common.service.UserPreferenceService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.MenuListResourceVO;
import com.ge.trans.rmd.common.vo.ResourceVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

/*******************************************************************************
 *
 * @Author 		: iGATE Patni
 * @Version 	: 1.0
 * @Date Created: Nov 17, 2011
 * @Date Modified : 
 * @Modified By : 
 * @Contact 	:
 * @Description : This class act as a controller to authenticate the user and store 
 *                the authenticated user info like first name,last name,email, roles
 *                that are mapped to the user and user preferences into the session.
 * @History		:
 *
 ******************************************************************************/
@Controller
public class LoginSSOController extends RMDBaseController {

	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	private LoginService loginService;
	@Autowired
	private AuthorizationService authorizationService;
	@Autowired
	private UserPreferenceService userPreferenceService;

	@Autowired
	private ServletContext context;
	
	@Autowired
	private FavoriteFilterService favFilterService;
	@Value("${" + AppConstants.DASHBOARD_URL + "}")
	String dashboardUrl;
	/**
	 * @Author: 
	 * @return
	 * @Description: Displays the index page(login page) of the RMD application
	*/
	@RequestMapping(method = RequestMethod.GET, value = AppConstants.REQ_URI_SSOLOGIN)
	public String showloginPage(final HttpServletRequest request) throws RMDWebException, Exception {
		// Clear existing session if any, before loading the landing page of the Application.
		final HttpSession session = request.getSession(false);
		if (session != null) {
			session.invalidate();
		}

		//SSO Enable - Changes Start
		final String uid = request.getHeader(AppConstants.SSO_UID); 
		rmdWebLogger.debug("uid is"+uid);
		final String returnPage = AppConstants.VIEW_SSOINDEX;
		request.setAttribute(AppConstants.SSO_FLAG, AppConstants.SSO_URL);
		return returnPage;
		
		//SSO Enable - Changes End
		 
	}

	

	/**
	 * @Author: 
	 * @param loginModel
	 * @param result
	 * @param model
	 * @param request
	 * @return
	 * @throws RMDWebException 
	  * @Description: authenticates the user, in case of successful authentication
	 *               
	 *               1) retrieve the user information like roles,preferences etc
	 *                  and set this user information in session.
	 *                  
	 *               2) Authorizes the user
	 *               
	 *               3) Redirects the user to the page where the navigation is rendered
	 *                  based on the users default role(and privileges)       
	 * 
	 *  
	*/
	@RequestMapping(method = RequestMethod.POST, value = AppConstants.REQ_URI_SSOLOGIN)
	@SuppressWarnings(AppConstants.UNCHECKED)
	public String login(
			@ModelAttribute(AppConstants.ATTR_LOGIN_MODEL) final LoginModel loginModel,
			final HttpServletRequest request) throws RMDWebException, Exception {
		rmdWebLogger.debug("login():START ");
		String result = null;
				
		//Invalidate existing session if any, before user login 
		HttpSession session = request.getSession(false);
		if (null != session) {
			session.invalidate();
		}
		//set SSO Flag
		request.setAttribute(AppConstants.SSO_FLAG, AppConstants.SSO_URL);
		try {
			result = performLogin(loginModel, request);
		
		}
		catch (AuthenticationException authEx) {
			rmdWebLogger
					.error("Exception occured in login() method "
							, authEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.LOGIN_FAILURE);
			result = AppConstants.VIEW_INDEX;
		}
		catch (AuthorizationException authorEx) {
			rmdWebLogger
					.error("Exception occured in login() method "
							, authorEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.ACCESS_DENIED_FOR_ROLE);
			if (AppConstants.USER_INACTIVE.equalsIgnoreCase(authorEx
					.getMessage())) {
				request.setAttribute(AppConstants.ERRORMSG,
						AppConstants.USER_INACTIVE);
			}
			result = AppConstants.VIEW_ACCESS_DENIED;
		}
		catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("Exception occured in login() method "
							, rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		}
		catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in login() method "
							, ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		}
		
		rmdWebLogger.debug("login():END ");
		return result;
	}

	/**
	 * @Author: To render the user's common default authentication method   
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description:
	*/

	//SSO Enable - Changes Start
	private String performLogin(final LoginModel loginModel,
			final HttpServletRequest request
			)
			throws RMDWebException, Exception, AuthorizationException {
		String result;
		MenuListResourceVO menuListResourceVO;
		HttpSession session;
		Map<String, ResourceVO> authorizedPriMapForARole = new HashMap<String, ResourceVO>();
		Map<String, List<ResourceVO>> authorizedSecMapForRole = new HashMap<String, List<ResourceVO>>();
		Map<String, List<ResourceVO>> stickyTabSubTabMap = new HashMap<String, List<ResourceVO>>();
		Map<String, List<String>> utilityMap=new HashMap<String,List<String>>(); 
		ObjectMapper jsonMapper = new ObjectMapper();
		String jsonUtilityMap = "";
		// 1. Authenticate the user

		final UserLoginBean userLoginBean = new UserLoginBean();
		
		userLoginBean.setUserName(loginModel.getUserName());
		userLoginBean.setPassword(loginModel.getPassword());
		
		loginService.authenticate(userLoginBean);
		
		result = userLoginBean.getResult();
		rmdWebLogger.debug("Flag is ---> "+result);
		final UserVO userVO = userLoginBean.getUserVO();
		if (AppConstants.LOGIN_SUCCESS.equals(result)) {

			rmdWebLogger.debug(loginModel.getUserName()+ " is Authenticated successfully");

			//2. User is authenticated, Create Fresh  Session
			session = request.getSession(true);

			//3. Authorize the user

			//a. Get the Navigation(tab info) detail information from context
			final Map<String, ResourceVO> primaryNavigationDetails = (Map<String, ResourceVO>) context
					.getAttribute(AppConstants.PRI_NAV_MAP);
			final Map<String, List<ResourceVO>> navigationDetails = (Map<String, List<ResourceVO>>) context
					.getAttribute(AppConstants.TAB_DETAIL_MAP);

			//b. authorize the user and retrieve privileges for user's default role
			menuListResourceVO = authorizationService.getMenuListForARole(
					primaryNavigationDetails, navigationDetails, userLoginBean);

			//set value in UserVO
			if (AppConstants.MENU_ACCESS_LEVEL_SHOW
					.equals(menuListResourceVO.getProfile())) {
				userVO.setProfile(menuListResourceVO.getProfile());
			} else {
				userVO.setProfile(AppConstants.MENU_ACCESS_LEVEL_HIDE);
			}
			if (AppConstants.MENU_ACCESS_LEVEL_SHOW
					.equals(menuListResourceVO.getPreferences())) {
				userVO.setPreferences(menuListResourceVO.getPreferences());
			} else {
				userVO.setPreferences(AppConstants.MENU_ACCESS_LEVEL_HIDE);
			}
			if (AppConstants.MENU_ACCESS_LEVEL_SHOW
					.equals(menuListResourceVO.getHeader())) {
				userVO.setHeader(menuListResourceVO.getHeader());
			} else {
				userVO.setHeader(AppConstants.MENU_ACCESS_LEVEL_HIDE);
			}

			if (userVO.getHeader() == null) {
				userVO.setHeader(AppConstants.MENU_ACCESS_LEVEL_HIDE);
			}

			
			if (menuListResourceVO != null) {
				authorizedPriMapForARole = menuListResourceVO
						.getPriNavMapUdtedForARole();
				authorizedSecMapForRole = menuListResourceVO
						.getSecNavMapUdtedForARole();
				stickyTabSubTabMap = menuListResourceVO
				.getSticySubNavigationList();
				if(RMDCommonUtility.isCollectionNotEmpty(menuListResourceVO.getUtilityList())){
					utilityMap=authorizationService.collectUtilities(authorizedPriMapForARole,authorizedSecMapForRole,stickyTabSubTabMap,menuListResourceVO.getUtilityList());
					jsonUtilityMap = jsonMapper.writeValueAsString(utilityMap);
				}
			}
			if (authorizedPriMapForARole == null
					|| authorizedPriMapForARole.isEmpty()) {
				throw new AuthorizationException(400,
						AppConstants.ACCESS_DENIED_FOR_ROLE);
			}
			final String strPageZeroIndx = authorizedPriMapForARole
					.keySet().iterator().next();
			final String subPageIdxforHome = authorizationService
					.getSubPageIndexForHome(strPageZeroIndx,
							navigationDetails);

			//4. set the values required in session to render on JSPs.
			session.setAttribute(AppConstants.TAB_DETAIL_MAP,
					navigationDetails);

			//5. get users default preferences 
			final UserPreferenceBean userPreferenceBean = userPreferenceService.getDefaultUserPreferences(userVO);
			
			setUserPreferencesToSession(userPreferenceBean, session);
			
			final SortedSet<Entry<String, String>> timeZoneMap;

			//6. Check Timezone data  available in the context,if available fetch
			// otherwise hit the web service and get 
			if (null != context
					.getAttribute(AppConstants.ATTR_TIMEZONE_MAP)) {
				timeZoneMap = (SortedSet<Entry<String, String>>) context
						.getAttribute(AppConstants.ATTR_TIMEZONE_MAP);
			}
			else {
				timeZoneMap = userPreferenceService.getTimezone(userVO);
				context.setAttribute(AppConstants.ATTR_TIMEZONE_MAP,
						timeZoneMap);
			} 
			
				
			final SortedSet<Entry<String, String>> languageMap;
			
			if (null != context
					.getAttribute(AppConstants.ATTR_LANGUAGES_MAP)) {
				languageMap = (SortedSet<Entry<String, String>>) context
						.getAttribute(AppConstants.ATTR_LANGUAGES_MAP);
			}
			else {
				languageMap = getLanguage();
				context.setAttribute(AppConstants.ATTR_LANGUAGES_MAP,
						languageMap);
			}
		 
			/*
			 * Favorite Filter Service call to fetch all screen's favorite filter criteria.
			 */
			FavoriteFilterBean favoriteFilterBean=new FavoriteFilterBean();
			Long linkUserRoleSeqId=getLinkUsrRoleSeqId(userVO.getRolesVOLst(), userVO.getRoleId());
			favoriteFilterBean.setLinkUserRoleSeqId(linkUserRoleSeqId);
			userVO.setFilterDetail(favFilterService.fetchFavoriteFilter(favoriteFilterBean));
			/*
			 * Favorite Filter Service call to fetch all screen's favorite filter criteria.
			 */
			/*
			 * Product WS call for customerAssets
			 */
			CustomerAssetBean custAssetBean=new CustomerAssetBean();
			custAssetBean.setRoleName(RMDCommonUtil.getRoleName(userVO));
			custAssetBean.setLanguage(userVO.getStrLanguage());
			custAssetBean.setUserFirstName(userVO.getStrFirstName());
			custAssetBean.setUserId(userVO.getUserId());
			custAssetBean.setUserLastName(userVO.getStrLastName());
			custAssetBean.setUserLanguage(userVO.getStrUserLanguage());	
			custAssetBean.setCustomerId(userVO.getCustomerId());
			List<String> products =loginService.getProductsForRole(custAssetBean);
			userVO.setProducts(products);
			/*
			 * Product WS call for customerAssets
			 */
			/*
			 * Added for dashboard button functionality starts
			 */
			boolean dashboarFlag = loginService.dashboardRoleFlagValue(userVO);
			if(dashboarFlag){
				session.setAttribute(AppConstants.DASHBOARD_BUTTON,RMDCommonConstants.STRING_TRUE);
			}
			else{
				session.setAttribute(AppConstants.DASHBOARD_BUTTON,RMDCommonConstants.STRING_FALSE);
			}
			session.setAttribute(AppConstants.STR_DASHBOARD_URL, dashboardUrl);
			/*
			 * Added for dashboard button functionality ends
			 */
			session.setAttribute(AppConstants.ATTR_PRI_MAP,
					authorizedPriMapForARole);
			session.setAttribute(AppConstants.ATTR_SEC_MAP,
					authorizedSecMapForRole);
			session.setAttribute(AppConstants.ATTR_HOME_PAGE,
					strPageZeroIndx);
			session.setAttribute(AppConstants.ATTR_SUB_PAGE,
					subPageIdxforHome);
			session.setAttribute(AppConstants.ATTR_IMAGE_NAME,
					loginService.getBrandingImageName(userVO));
			session.setAttribute(AppConstants.ATTR_USER_OBJECT, userVO);
			session.setAttribute(AppConstants.STICKYTAB_SUBTAB, stickyTabSubTabMap);
			session.setAttribute(AppConstants.UTILITY_MAP,
					jsonUtilityMap);
			
			result = AppConstants.REDIRECT + AppConstants.LOGIN_SUCCESS;
			
		}
		return result;
	}
	//SSO Enable - Changes End


	/**
	 * @Author: This method will set user preferences to session
	 * @param userPreferenceBean
	 * @param session
	 * @Description:
	*/
	private void setUserPreferencesToSession(
			final UserPreferenceBean userPreferenceBean,
			final HttpSession session) {

		session.setAttribute(AppConstants.ATTR_USER_PREFERENCE_MAP_LIST,
				userPreferenceBean.getUserPrefMap());

		session.setAttribute(AppConstants.ROLE_STRING,
				userPreferenceBean.getRole());
	}
	
	
	/**
	 * @Author: 
	 * @return
	 * @throws Exception
	 * @Description:
	*/
	
	@Value("${"+AppConstants.OMD_SUPPORTED_LANGUAGES+"}") private String language;  
	
	public SortedSet<Entry<String, String>> getLanguage() throws Exception {
		try {
			
			final HashMap<String, String> mapLanguage1 = new HashMap<String, String>();
			final StringTokenizer st = new StringTokenizer(language,
					AppConstants.ATTR_COLON);
			while (st.hasMoreTokens()) {
				final String key = st.nextToken();
				final String value = st.nextToken();
				mapLanguage1.put(key, value);
			}
			final SortedSet<Entry<String, String>> mapLanguage = RMDCommonUtil
					.entriesSortedByValues(mapLanguage1);
			return mapLanguage;
		}
		catch (Exception ex) {
			throw ex;
		}
	}
}
