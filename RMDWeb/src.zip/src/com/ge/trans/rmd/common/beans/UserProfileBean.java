package com.ge.trans.rmd.common.beans;

import javax.validation.constraints.NotNull;

public class UserProfileBean extends RMDBaseBean {
	
	@NotNull
	private String newPassword;

	public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(final String newPassword) {
		this.newPassword = newPassword;
	}
}
