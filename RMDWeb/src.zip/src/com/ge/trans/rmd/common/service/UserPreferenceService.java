package com.ge.trans.rmd.common.service;

import java.util.Map.Entry;
import java.util.SortedSet;

import com.ge.trans.rmd.common.beans.UserPreferenceBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.UserVO;

public interface UserPreferenceService {

	public SortedSet<Entry<String, String>> getTimezone(UserVO userVO) throws RMDWebException,
			Exception;

	public UserPreferenceBean getDefaultUserPreferences(UserVO userVO)
			throws RMDWebException, Exception;

	public UserPreferenceBean saveUserPreference(UserPreferenceBean userPreferenceBean)
			throws RMDWebException, Exception;
}
