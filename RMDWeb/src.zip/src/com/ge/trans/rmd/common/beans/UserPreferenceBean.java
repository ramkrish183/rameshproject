/**
 * ============================================================
 * File : UserPreferenceBean.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.beans
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Dec 18, 2011
 * History
 * Modified By : Initial Release
 * Classification : iGATE Patni Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.beans;

import java.util.List;
import java.util.Map;

/*******************************************************************************
 *
 * @Author 		: 
 * @Version 	: 1.0
 * @Date Created: Dec 18, 2011
 * @Date Modified : 
 * @Modified By : 
 * @Contact 	:
 * @Description : 
 * @History		:
 *
 ******************************************************************************/

public class UserPreferenceBean extends RMDBaseBean{

	private String language;
	private String timeZone;
	private String role;
	private String result;
	private String message;
	private List<Long> userIdLst;
	private List<Long> seqIdLst;
	private List<String> prefTypeLst;
	private Map<Long,String> userPrefMap;
	private String customerId;
	private Long usrUsersSeqId;
	private String customerChange;
	private String uom;	

	public String getUom() {
		return uom;
	}


	public void setUom(String uom) {
		this.uom = uom;
	}


	public Long getUsrUsersSeqId() {
		return usrUsersSeqId;
	}


	public void setUsrUsersSeqId(final Long usrUsersSeqId) {
		this.usrUsersSeqId = usrUsersSeqId;
	}


	public String getCustomerId() {
		return customerId;
	}


	public void setCustomerId(final String customerId) {
		this.customerId = customerId;
	}


	/**
	 * @return the userPrefMap
	 */
	public Map<Long, String> getUserPrefMap() {
		return userPrefMap;
	}

	
	/**
	 * @param userPrefMap the userPrefMap to set
	 */
	public void setUserPrefMap(final Map<Long, String> userPrefMap) {
		this.userPrefMap = userPrefMap;
	}

	/**
	 * @return the language
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param language the language to set
	 */
	public void setLanguage(final String language) {
		this.language = language;
	}

	/**
	 * @return the timeZone
	 */
	public String getTimeZone() {
		return timeZone;
	}

	/**
	 * @param timeZone the timeZone to set
	 */
	public void setTimeZone(final String timeZone) {
		this.timeZone = timeZone;
	}

	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(final String role) {
		this.role = role;
	}

	/**
	 * @return the result
	 */
	public String getResult() {
		return result;
	}

	/**
	 * @param result the result to set
	 */
	public void setResult(final String result) {
		this.result = result;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(final String message) {
		this.message = message;
	}

	/**
	 * @return the userIdLst
	 */
	public List<Long> getUserIdLst() {
		return userIdLst;
	}

	/**
	 * @param userIdLst the userIdLst to set
	 */
	public void setUserIdLst(final List<Long> userIdLst) {
		this.userIdLst = userIdLst;
	}

	/**
	 * @return the seqIdLst
	 */
	public List<Long> getSeqIdLst() {
		return seqIdLst;
	}

	/**
	 * @param seqIdLst the seqIdLst to set
	 */
	public void setSeqIdLst(final List<Long> seqIdLst) {
		this.seqIdLst = seqIdLst;
	}

	/**
	 * @return the prefTypeLst
	 */
	public List<String> getPrefTypeLst() {
		return prefTypeLst;
	}

	/**
	 * @param prefTypeLst the prefTypeLst to set
	 */
	public void setPrefTypeLst(final List<String> prefTypeLst) {
		this.prefTypeLst = prefTypeLst;
	}


	public String getCustomerChange() {
		return customerChange;
	}


	public void setCustomerChange(String customerChange) {
		this.customerChange = customerChange;
	}
}
