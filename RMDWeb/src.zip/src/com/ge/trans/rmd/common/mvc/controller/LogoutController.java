package com.ge.trans.rmd.common.mvc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import org.springframework.beans.factory.annotation.Value;

@Controller
@SessionAttributes
public class LogoutController extends RMDBaseController {
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Value("${" + AppConstants.SSO_LOGOutPage + "}")
	String ssoLogOutPage;
	@Value("${" + AppConstants.SSO_ENV + "}")
	String SSO_ENV;

	@RequestMapping(AppConstants.REQ_URI_LOGOUT)
	public ModelAndView renderLayout(final HttpServletRequest request) {

		rmdWebLogger.debug("renderLayout():START ");
		final HttpSession session = request.getSession(false);
		ModelAndView modelAndView = null;
		if (null != session
				&& session.getAttribute(AppConstants.ATTR_USER_OBJECT) != null) {
			if (SSO_ENV != null && SSO_ENV.equals(AppConstants.STATUS_TRUE)) {
				final String SSOURLLogout = AppConstants.HTTPS
						+ AppConstants.FORWARD_SLASH + request.getServerName()
						+ ssoLogOutPage + AppConstants.HTTPS
						+ AppConstants.FORWARD_SLASH + request.getServerName()
						+ request.getContextPath();
				modelAndView = new ModelAndView(AppConstants.REDIRECT
						+ SSOURLLogout);
				rmdWebLogger.debug("SSOURLLogout>>>> in if>>>>>>>>>>>>>>>>>>>>>>>>>>>"+SSOURLLogout);
			} else {
				modelAndView = new ModelAndView(AppConstants.VIEW_INDEX);

				modelAndView.addObject(AppConstants.ATTR_LOGOUT_MSG,
						AppConstants.LABEL_LOGOUT_MSG);
			}
			if (null != session) {
				session.invalidate();

			}
		} else {
			if (SSO_ENV != null && SSO_ENV.equals(AppConstants.STATUS_TRUE)) {
				final String SSOURLLogout = AppConstants.HTTPS
						+ AppConstants.FORWARD_SLASH + request.getServerName()
						+ ssoLogOutPage + AppConstants.HTTPS
						+ AppConstants.FORWARD_SLASH + request.getServerName()
						+ request.getContextPath();
				request.setAttribute(AppConstants.LOGOUT_URL, SSOURLLogout);
				modelAndView = new ModelAndView(AppConstants.REDIRECT
						+ SSOURLLogout);
				
				rmdWebLogger.debug("SSOURLLogout>>>> in else>>>>>>>>>>>>>>>>>>>>>>>>>>>"+SSOURLLogout);
			} else {
				modelAndView = new ModelAndView(AppConstants.VIEW_INDEX);
			}
		}
		rmdWebLogger.debug("renderLayout():END");
		return modelAndView;
	}
}
