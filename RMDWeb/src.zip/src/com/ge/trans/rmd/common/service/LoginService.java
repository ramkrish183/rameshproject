package com.ge.trans.rmd.common.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.common.beans.CustomerAssetBean;
import com.ge.trans.rmd.common.beans.UserLoginBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.UserVO;

public interface LoginService {

	/**
	 * @Author: 
	 * @param loginForrm
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description:
	*/
	public void authenticate(final UserLoginBean loginBean)
			throws RMDWebException, Exception;
	 
	/**
	 * @Author: 
	 * @param userVO
	 * @return
	 * @throws Exception
	 * @Description:
	*/
	public String getBrandingImageName(final UserVO userVO) throws Exception;
	
	/**
	 * @Author: 
	 * @param userVO
	 * @return
	 * @throws Exception
	 * @Description:
	*/
	public List<String> getProductsForRole(final CustomerAssetBean custAssetBean) throws Exception;
	
	/**
	 * @Author: 
	 * @param String userID
	 * @return List<String>
	 * @throws Exception
	 * @Description: method to get the CM privilege details
	*/
	public void hasCMPrivilege(final UserVO userVO) throws Exception;
	/**
	 * @Author: 
	 * @param String userID
	 * @return List<String>
	 * @throws Exception
	 * @Description: method to get the list of customers associated
	*/
	public void getCustomerList(UserVO userVO) throws Exception;
	
	/**
	 * @Author: 
	 * @param userVO object
	 * @return boolean
	 * @throws Exception
	 * @Description: method to get the flag for dashboard button
	*/
	public boolean dashboardRoleFlagValue(UserVO userVO) throws Exception;
	/**
	 * @Author: 
	 * @param userId
	 * @return String
	 * @throws Exception
	 * @Description: method to update last login date and time in user table. 
	*/
	public String updateLastLoginDetails(String userId) throws Exception;
	
}
