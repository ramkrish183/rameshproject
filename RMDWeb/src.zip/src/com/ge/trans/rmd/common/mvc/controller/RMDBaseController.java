package com.ge.trans.rmd.common.mvc.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.datatype.XMLGregorianCalendar;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.common.beans.FavoriteFilterBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.service.FavoriteFilterService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.CustomerVO;
import com.ge.trans.rmd.common.vo.ErrorVO;
import com.ge.trans.rmd.common.vo.FavoriteFilterDetailVO;
import com.ge.trans.rmd.common.vo.FilterDetailVO;
import com.ge.trans.rmd.common.vo.ResourceVO;
import com.ge.trans.rmd.common.vo.RolesVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
public class RMDBaseController {

	private final RMDWebLogger log = RMDWebLogger.getLogger(getClass());
	@Autowired
	private AuthorizationService authService;
	@Autowired
	private FavoriteFilterService favFilterService;

	@ExceptionHandler
	protected ModelAndView handleRequestException(final RMDWebException rmdWebEx)
			throws RMDWebException {
		log.error("RMDWebException ::: ", rmdWebEx);
		return new ModelAndView(AppConstants.VIEW_GLOBAL_EXCEPTION_PAGE);
	}

	@ExceptionHandler
	protected ModelAndView handleRequestException(final Exception excep)
			throws Exception {
		log.error("Exception ::: ", excep);
		return new ModelAndView(AppConstants.VIEW_GLOBAL_EXCEPTION_PAGE);
	}

	/**
	 * 
	 * @param GenericAjaxException
	 *            ,HttpServletResponse
	 * @Description: Exception handler method for handling the generic exception
	 */

	@ExceptionHandler(GenericAjaxException.class)
	@ResponseStatus(value = HttpStatus.INTERNAL_SERVER_ERROR)
	@ResponseBody
	public ErrorVO handleAjaxException(GenericAjaxException ex,HttpServletResponse response) throws IOException {
		final ErrorVO errorVO = new ErrorVO();
		errorVO.setStatusCode(ex.getStatus());
		errorVO.setType(ex.getExcpType());
		return errorVO;

	}
	
	/**
	 * 
	 * @param Map<String,String>,UserVO
	 *            ,HttpServletRequest
	 * @Description: Generic method to get the enabled components for logged in user
	 */
	public void getComponentPrivilege(Map<String,String> compList, UserVO userVO,
			final HttpServletRequest request) throws RMDWebException, Exception {
		boolean privilege = false;
		
		if (null != compList && !compList.isEmpty()) {
			Set<Map.Entry<String,String>> entries = compList.entrySet();
			for(Map.Entry<String, String> component: entries){
				String componentName;
				componentName = authService.getLookUpValueForName(component.getKey());
				privilege = RMDCommonUtil.componentValue(
						userVO.getComponentList(), componentName);
				request.setAttribute(component.getValue(), privilege);
			}
		}

	}

	/**
	 * 
	 * @param filterBean
	 * @Description: Generic method to call the favorite filter service methods
	 */
	public void callFavoriteFilter(final FavoriteFilterBean filterBean)
			throws RMDWebException, Exception {

		if (null != filterBean) {
			// Calling add favorite filter service method if favorite filter
			// check-box is enabled
			if (filterBean.getFavFilterFlag().equals(AppConstants.STR_TRUE)
					&& (null != filterBean.getColumnType() && !filterBean
							.getColumnType().isEmpty())) {
				favFilterService.addFavoriteFilter(filterBean);
			}
			// Calling delete favorite filter service method if favorite filter
			// check-box is not enabled
			if (filterBean.getFavFilterFlag().equals(AppConstants.STR_FALSE)
					&& null != filterBean.getFilterId()
					&& !filterBean.getFilterId().equals(
							AppConstants.EMPTY_STRING)) {
				favFilterService.deleteFavoriteFilter(filterBean);
			}

		}

	}

	/**
	 * 
	 * @param rolesVOLst
	 * @param roleId
	 * @Description: Generic method to get the sequence id of UserRole Link 
	 */
	protected Long getLinkUsrRoleSeqId(final List<RolesVO> rolesVOLst,
			final Long roleId) throws RMDWebException {
		Long linkUsrRoleSeqId = null;
		if (null!=rolesVOLst && rolesVOLst.size() > 0) {
			Iterator<RolesVO> roleVOIterator = rolesVOLst.iterator();
			RolesVO rolesVO = null;
			while (roleVOIterator.hasNext()) {
				rolesVO = (RolesVO) roleVOIterator.next();
				if (rolesVO.getGetUsrRolesSeqId().equals(roleId)) {
					linkUsrRoleSeqId = rolesVO.getLinkUsrRoleSeqId();
					break;
				}

			}

		}
		return linkUsrRoleSeqId;
	}
	
	protected void setFavoriteFiltersToUserVO(String screenName, UserVO userVO,FavoriteFilterBean favFilterBean, String favFilter) throws RMDWebException{
		Long linkUserRoleSeqId = getLinkUsrRoleSeqId(userVO.getRolesVOLst(),
				userVO.getRoleId());
		String filterName = linkUserRoleSeqId + "_" + screenName
				+ AppConstants.STR_FILTER;
		List<FavoriteFilterDetailVO> filterDetails = userVO
				.getFilterDetail();
		boolean filterFound = false;
		for (FavoriteFilterDetailVO favFilterDetailType : filterDetails) {
			if (null != favFilterDetailType.getFilterName()
					&& favFilterDetailType.getFilterName().equals(
							filterName)
					&& null != favFilterDetailType.getFilterDetails()) {
				
				//Remove old filters
				filterFound = true;
				favFilterDetailType.setFilterDetails(new ArrayList<FilterDetailVO>());
				
				if (favFilter.equals(AppConstants.STR_FALSE)){
					break;
				}
				
				for(Entry<String, String> columnDetail  :favFilterBean.getColumnValue().entrySet()){
					String columnName = columnDetail.getKey();
					String columnValues = columnDetail.getValue();
					String columnType = favFilterBean.getColumnType().get(columnName);
					
					for(String filterValue:columnValues.split(",")){
						FilterDetailVO filterDetail = new FilterDetailVO();
						filterDetail.setColumnName(columnName);
						filterDetail.setColumnType(columnType);
						filterDetail.setFromFilterValue(filterValue);
						favFilterDetailType.getFilterDetails().add(filterDetail);
					}
					
				}
			}
		}
		
		if(!filterFound && favFilter.equals(AppConstants.STR_TRUE)){
			FavoriteFilterDetailVO favFilterDetailType= new FavoriteFilterDetailVO();
			favFilterDetailType.setFilterDetails(new ArrayList<FilterDetailVO>());
			favFilterDetailType.setFilterName(filterName);
			if(favFilterBean.getColumnValue()!=null && !favFilterBean.getColumnValue().equals(AppConstants.EMPTY_STRING)){
			for(Entry<String, String> columnDetail  :favFilterBean.getColumnValue().entrySet()){
				String columnName = columnDetail.getKey();
				String columnValues = columnDetail.getValue();
				String columnType = favFilterBean.getColumnType().get(columnName);
				
				for(String filterValue:columnValues.split(",")){
					FilterDetailVO filterDetail = new FilterDetailVO();
					filterDetail.setColumnName(columnName);
					filterDetail.setColumnType(columnType);
					filterDetail.setFromFilterValue(filterValue);
					favFilterDetailType.getFilterDetails().add(filterDetail);
				}
				
			}
			}
			filterDetails.add(favFilterDetailType);
		}
			
	}

	/**
	 * 
	 * @param screenName
	 * @param userVO
	 * @throws Exception 
	 * @Description Method used to Getting favorite filters for the particular screen by input screen name.
	 * 
	 */
	protected String getFavoriteFilters(String screenName, UserVO userVO,
			final Map<String,Object> componentMap) throws Exception {
		Long linkUserRoleSeqId = null;
		String filterName = "", columnName = "";
		Map<String, List<String>> columnDetails = new HashMap<String, List<String>>();
		ObjectMapper jsonMapper = new ObjectMapper();
		String convertedJsonString = "";
		final SimpleDateFormat dateFormat = new SimpleDateFormat(
				AppConstants.DATE_FORMAT_24HRS);
		try {
			if (null != userVO.getFilterDetail()
					&& userVO.getFilterDetail().size() != 0) {
				List<FavoriteFilterDetailVO> filterDetails = userVO
						.getFilterDetail();
				linkUserRoleSeqId = getLinkUsrRoleSeqId(userVO.getRolesVOLst(),
						userVO.getRoleId());
				filterName = linkUserRoleSeqId + "_" + screenName
				+ AppConstants.STR_FILTER;
				for (FavoriteFilterDetailVO favFilterDetailType : filterDetails) {
					if (null != favFilterDetailType.getFilterName()
							&& favFilterDetailType.getFilterName().equals(
									filterName)
							&& null != favFilterDetailType.getFilterDetails()) {

						for (FilterDetailVO filterDetail : favFilterDetailType
								.getFilterDetails()) {
							columnName = filterDetail.getColumnName();
							
							//Check the component visibility before adding it's filter value
							/*if ((columnName
									.equals(AppConstants.URGENCY_FAV_FILTER) && (Boolean) request
									.getAttribute(AppConstants.RX_FILTER_URGENCY))
									|| (columnName
											.equals(AppConstants.EST_REPAIR_TIME) && (Boolean) request
											.getAttribute(AppConstants.RX_FILTER_ESTREPTIME))
									|| (columnName
											.equals(AppConstants.RX_TITLE) && (Boolean) request
											.getAttribute(AppConstants.RX_FILTER_APPROVEDRXTITLES))
									|| (columnName
											.equals(AppConstants.FILTER_NO_OF_DAYS) && (Boolean) request
											.getAttribute(AppConstants.DD_FILTER))
									|| (columnName
											.equals(AppConstants.COMPONENT_CASE_TYPE) && (Boolean) request
											.getAttribute(AppConstants.RX_FILTER_CASETYPE)))*/ 
							if (componentMap.containsKey(columnName)
									&& (Boolean) componentMap.get(columnName)) {
								List<String> columnValue = new ArrayList<String>();								
								
								String valuetoList = getFromFilterValue(filterDetail.getFromFilterValue(), 
										filterDetail.getColumnType(),dateFormat);
								if (columnDetails.containsKey(columnName)
										&& null != filterDetail
												.getFromFilterValue()
										&& !filterDetail
												.getFromFilterValue()
												.equals(AppConstants.EMPTY_STRING)) {									
									columnDetails.get(columnName).add(
											valuetoList);
								} else {

									columnValue.add(valuetoList);
									columnDetails.put(columnName, columnValue);
								}

							}
						}
					}

				}
			}
			//Convert map object to json string for browser operation
			if (null != columnDetails && !columnDetails.isEmpty()) {

				convertedJsonString = jsonMapper
						.writeValueAsString(columnDetails);
			}
		} catch (Exception e) {
			throw e;
		}

		return convertedJsonString;
	}
	
	private String getFromFilterValue(Object fromFilterValue, String columnType, SimpleDateFormat dateFormat){
		String filterValue=null;		
		if(columnType!=null && AppConstants.DATE_TIME.equals(columnType)){
			XMLGregorianCalendar gregorianFilterValue = (XMLGregorianCalendar)fromFilterValue;			
			filterValue = RMDCommonUtility
					.convertObjectToString(dateFormat.format(gregorianFilterValue.toGregorianCalendar().getTime()));
		}else{
			filterValue = RMDCommonUtility
			.convertObjectToString(fromFilterValue);
		}
		return filterValue;
	}
	/**
	 * 
	 * @param screenName
	 * @param userVO
	 * @Description Method used to get filter id of given screen name.
	 */
	protected String getFilterId(String screenName, UserVO userVO)
			throws RMDWebException {
		Long linkUserRoleSeqId = getLinkUsrRoleSeqId(userVO.getRolesVOLst(),
				userVO.getRoleId());
		String filterName = "";
		String filterId="";
		if (null != userVO.getFilterDetail()
				&& userVO.getFilterDetail().size() != 0) {
			List<FavoriteFilterDetailVO> filterDetails = userVO.getFilterDetail();
			for (FavoriteFilterDetailVO favFilterDetailType : filterDetails) {
				filterName = linkUserRoleSeqId +"_"+ screenName
						+ AppConstants.STR_FILTER;
				if (null != favFilterDetailType.getFilterName()
						&& favFilterDetailType.getFilterName().equals(
								filterName)
						&& null != favFilterDetailType.getFilterDetails()) {
					filterId=favFilterDetailType.getFilterId()+"";
				}
			}
		}
		return filterId;
	}
	
	public String findNumberOfRecords(String screenName) {
		String numberOfRecords = AppConstants.EMPTYSTRING;
		try {
			numberOfRecords = authService.getLookUpValueForName(screenName);
			if(null == numberOfRecords||RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(numberOfRecords)){
				numberOfRecords = "10";
			}
		} catch (RMDWebException rmdEx) {
			log.error("RMDWebException occured in findNumberOfDays() method ",
					rmdEx);
		} catch (Exception ex) {
			log.error("Exception occured in findNumberOfDays() method ", ex);
		}
		return numberOfRecords;
	}
	
	
	public String getLookUpValueForName(String listName) {
		String lookUpValues = AppConstants.EMPTYSTRING;
		try {
			lookUpValues = authService.getLookUpValueForName(listName);
			
		} catch (RMDWebException rmdEx) {
			log.error("RMDWebException occured in getLookUpValueForName() method ",
					rmdEx);
		} catch (Exception ex) {
			log.error("Exception occured in getLookUpValueForName() method ", ex);
		}
		return lookUpValues;
	}
	
	

	/*
	 * method accepts hashmap as input and sorts it based on the 
	 * values of hashmap
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<String,String> SortMapValues(Map map){
		
		List<Entry<String, String>> entries = new ArrayList<Entry<String, String>>(map.entrySet());
		Collections.sort(entries, new Comparator<Entry<String, String>>() {
		    public int compare(Entry<String, String> e1, Entry<String, String> e2) {
		        return e1.getValue().compareTo(e2.getValue());
		    }
		});
		
		Map<String, String> sortedMap = new LinkedHashMap<String, String>();
		for (Entry<String, String> entry : entries) {
			sortedMap.put(entry.getKey(), entry.getValue());
		}
		
		return sortedMap;
	}
	/**
	 * Filter the unavailable kpi from order list  
	 * @param request
	 * @param lstKPI
	 */
	public void filterResourceByKPIPrivilege(HttpServletRequest request, List<ResourceVO> lstKPI){
	
	if(RMDCommonUtility.isCollectionNotEmpty(lstKPI)){
		Iterator<ResourceVO> it = lstKPI.listIterator();
		boolean removeFlag=false;
		while(it.hasNext()){
			removeFlag=false;
			ResourceVO resourceVO=it.next();
				if (resourceVO.getResourceId().equals(AppConstants.KPI_RX_DELIVERED)
						&& !(Boolean) request
								.getAttribute(AppConstants.KPI_RX_DELIVERED_ATTR)){
					removeFlag=true;
				}
				else if(resourceVO.getResourceId().equals(
								AppConstants.KPI_RX_CLOSED_URGENCY)
						&& !(Boolean) request
								.getAttribute(AppConstants.KPI_RX_CLOSED_URGENCY_ATTR)){
					removeFlag=true;
				}
				else if(resourceVO.getResourceId().equals(
								AppConstants.KPI_RX_CLOSED_TYPE)
						&& !(Boolean) request
								.getAttribute(AppConstants.KPI_RX_CLOSED_TYPE_ATTR)){
					removeFlag=true;
				}
				else if(resourceVO.getResourceId().equals(
								AppConstants.KPI_RX_ACCURACY)
						&& !(Boolean) request
								.getAttribute(AppConstants.KPI_RX_ACCURACY_ATTR)){
					removeFlag=true;
				}
				else if(resourceVO.getResourceId().equals(AppConstants.KPI_NTF)
						&& !(Boolean) request
								.getAttribute(AppConstants.KPI_NTF_ATTR)){
					removeFlag=true;
				}
				else if(resourceVO.getResourceId().equals(
								AppConstants.KPI_RESPONSE_TIME)
						&& !(Boolean) request
								.getAttribute(AppConstants.KPI_RESPONSE_TIME_ATTR)){
					removeFlag=true;
					
				}
				if(removeFlag){
					it.remove();
				}
		}
	}
}	

	public String getCustomerList(List<CustomerVO> customerVOList) {
		String customerList = "";
		for (CustomerVO customer : customerVOList) {
			customerList = customerList + customer.getCustomerID() + ",";
		}
		customerList = customerList.substring(0, customerList.length() - 1);
		return customerList;
	}
	/*
	 * method accepts hashmap as input and sorts it based on the 
	 * values of hashmap
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map<String,String> SortMapKey(Map map){
		
		List<Entry<String, String>> entries = new ArrayList<Entry<String, String>>(map.entrySet());
		Collections.sort(entries, new Comparator<Entry<String, String>>() {
		    public int compare(Entry<String, String> e1, Entry<String, String> e2) {
		        return e1.getKey().compareTo(e2.getKey());
		    }
		});
		
		Map<String, String> sortedMap = new LinkedHashMap<String, String>();
		for (Entry<String, String> entry : entries) {
			sortedMap.put(entry.getKey(), entry.getValue());
		}
		
		return sortedMap;
	}
	
	/**
	 * Added by Murali M for US242936 Changes
	 * @param userId
	 * @param screenName
	 * @param businessKeys
	 * @param exception
	 */
	protected void persistException(String userId, String screenName, String businessKeys, Exception exception){
		ErrorVO errorVO = new ErrorVO();
        errorVO.setUserId(userId);
        errorVO.setScreenName(screenName);
        errorVO.setBusinessKeys(businessKeys);
        if(exception != null){
        	if(exception.getCause() != null){
        		errorVO.setExceptionType(exception.getCause().toString());
        	}
	 		errorVO.setExceptionDesc(exception.getMessage());
	 		errorVO.setTraceLog(Arrays.toString(exception.getStackTrace()));
        }
 		authService.persistException(errorVO);
	}
	

public long getLookUpObjidForName(String listName) {
        long lookUpValueObjId = 0;
        try {
            lookUpValueObjId = authService.getLookUpObjidForName(listName);
            
        } catch (RMDWebException rmdEx) {
            log.error("RMDWebException occured in getLookUpObjidForName() method ",
                    rmdEx);
        } catch (Exception ex) {
            log.error("Exception occured in getLookUpObjidForName() method ", ex);
        }
        return lookUpValueObjId;
    }
}