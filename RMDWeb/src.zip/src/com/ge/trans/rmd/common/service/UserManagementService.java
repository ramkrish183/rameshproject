/**
 * ============================================================
 * File : UserManagementService.java
 * Description : Web layer service interface class for user management
 * 
 * Package : com.ge.trans.rmd.common.service
 * Author : iGATE
 * Last Edited By :
 * Version : 1.0
 * Created on : November 19, 2012
 * History :
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2012 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.service;


import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.valueobjects.UserEOADetailsVO;
import com.ge.trans.rmd.common.beans.UserManagementBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.RolesVO;


public interface UserManagementService {
	public List<UserManagementBean> getUsers(UserManagementBean userManagementBean) throws RMDWebException, Exception;
	public void saveEditUserDetails(UserManagementBean userManagementBean) throws RMDWebException, Exception;
	public List<RolesVO> getAllRoles(UserManagementBean userManagementBean) throws RMDWebException, Exception;
	Map<String, String> getCustomers() throws RMDWebException;
	
	
	/**
	 * @Author:
	 * @param :
	 * @param :
	 * @return:List<RolesVO>
	 * @throws:RMDWebException
	 * @Description:This method is returns the list of roles which have Case
	 *                   Management Privilege by calling the RESTful
	 *                   Web Services.
	 */
	public List<RolesVO> getCaseMgmtRoles()throws RMDWebException;

	/**
	 * @Author:
	 * @param :
	 * @param :userId
	 * @return:String
	 * @throws:RMDWebException
	 * @Description:This method is used for fetching the EOA UserId by calling
	 *                   the by calling the RESTful Web Services.
	 */
	public String getEoaUserName(String userId)throws RMDWebException,
	Exception;
	
	public Map<String, String> getAdminLookUp(String listName) throws RMDWebException,
			Exception;
	
	
	public List<UserManagementBean> getAlertUsers(
			final UserManagementBean userManagementBean)
			throws RMDWebException, Exception;

	public List<String> getUserComponentList(String userId)
			throws RMDWebException;
	/**
	 * 
	 * @param removedRoleId 
	 * @Author:
	 * @param :roleId,userId
	 * @return:UserEOADetailsVO
	 * @throws:RMDWebException
	 * @Description: This method is used to check whether the selected role is
	 *               having CM / Multilingual/emetrics privilege
	 */
	public UserEOADetailsVO getCMorMLDetails(String roleId, String userId, String removedRoleId) throws RMDWebException;
	/**
	 * @Author:
	 * @param :
	 * @param :aliasName
	 * @return:String
	 * @throws:RMDWebException
	 * @Description:This method is used for checking whether the entered aliasName is exist or not
	 */
	public String checkUserAlias(String aliasName) throws RMDWebException;
	/**
	 * @Author:
	 * @param :
	 * @param :
	 * @return:List<RolesVO>
	 * @throws:RMDWebException
	 * @Description:This method is returns the list of roles which have Case
	 *                   Management Privilege by calling the RESTful
	 *                   Web Services.
	 */
	public List<RolesVO> getEoaOnsiteRoles()throws RMDWebException;
	
	/**
     * @Author:
     * @param :
     * @param :
     * @return:List<RolesVO>
     * @throws:RMDWebException
     * @Description:This method returns the list of roles which are note having Case
     *                   Management Privilege
     */
    public List<RolesVO> getNoCMRoles() throws RMDWebException;;
    
    public String deleteUserDetails(List<String> userdetails) throws RMDWebException, Exception;
}
