package com.ge.trans.rmd.common.service;

import com.ge.trans.rmd.common.beans.UserProfileBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.UserVO;



/**
 * *****************************************************************************
 *
 * @Author 		:iGATE Patni 
 * @Version 	: 1.0
 * @Date Created: Nov 15, 2011
 * @Date Modified : Nov 15, 2011
 * @Modified By : 
 * @Contact 	:
 * @Description : Interface will  be get the required object and call the service for reset the password.
 * @History		:
 *
 *****************************************************************************
 */

public interface UserProfileService {
	
	public String resetPassword(final UserVO userVO,final UserProfileBean userProfileBean) throws RMDWebException, Exception;
	
	
	
}
