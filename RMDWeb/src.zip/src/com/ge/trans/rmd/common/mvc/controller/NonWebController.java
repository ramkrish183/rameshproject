/**
 * ============================================================
 * File : NonWebController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.mvc.controller
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Aug 09, 2013
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.km.mvc.model.LookUpVO;
import com.ge.trans.rmd.km.service.RuleSearchResultService;
import com.ge.trans.rmd.km.service.RxService;
import com.ge.trans.rmd.km.valueobjects.ElementVO;

/*******************************************************************************
 * 
 * @Author : iGATE Patni
 * @Version : 1.0
 * @Date Created: Aug 09, 2013
 * @Date Modified :
 * @Modified By :
 * @Contact :
 * @Description : This class act as a controller for non spring mvc screens. it
 *              acts like a proxy.
 * @History :
 * 
 ******************************************************************************/
@Controller
public class NonWebController extends RMDBaseController {

	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	WebServiceInvoker webServiceInvoker;
	@Autowired
	private RxService objRxService;
	@Autowired
	private RuleSearchResultService objRuleSearchResultService;

	@RequestMapping(value = { "/nonweb/**" }, method = RequestMethod.GET)
	public void callServices(final HttpServletRequest request,
			final HttpServletResponse response) throws RMDWebException,
			Exception {
		rmdWebLogger.debug("get invoked");
		StringBuffer requestURL = request.getRequestURL();
		if (request.getQueryString() != null) {
			requestURL.append("?").append(request.getQueryString());
		}
		String completeURL = requestURL.toString();
		completeURL = completeURL.substring(completeURL.indexOf("/nonweb/"));
		completeURL = completeURL.replace("/nonweb/", "");
		rmdWebLogger.debug("completeURL url" + completeURL);

		webServiceInvoker.asisGet(completeURL, request, response);
	}

	@RequestMapping(value = { "/nonweb/**" }, method = RequestMethod.POST)
	public void callServicesPOST(final HttpServletRequest request,
			final HttpServletResponse response) throws RMDWebException,
			Exception {
		rmdWebLogger.debug("post invoked");
		String completeURL = request.getRequestURL().toString();
		completeURL = completeURL.substring(completeURL.indexOf("/nonweb/"));
		completeURL = completeURL.replace("/nonweb/", "");
		rmdWebLogger.debug("completeURL url" + completeURL);
		webServiceInvoker.asisPost(completeURL, request, response);

	}
	@RequestMapping(value = { "/stream/**" }, method = RequestMethod.GET)
	public void callStreamServices(final HttpServletRequest request,
			final HttpServletResponse response) throws RMDWebException,
			Exception {
		rmdWebLogger.debug("stream get invoked");
		StringBuffer requestURL = request.getRequestURL();
		if (request.getQueryString() != null) {
			requestURL.append("?").append(request.getQueryString());
		}
		String completeURL = requestURL.toString();
		completeURL = completeURL.substring(completeURL.indexOf("/stream/"));
		completeURL = completeURL.replace("/stream/", "");
		rmdWebLogger.debug("completeURL url" + completeURL);

		webServiceInvoker.asStreamGet(completeURL, request, response);
	}

	@RequestMapping(value = { "/stream/**" }, method = RequestMethod.POST)
	public void callStreamServicesPOST(final HttpServletRequest request,
			final HttpServletResponse response) throws RMDWebException,
			Exception {
		rmdWebLogger.debug("stream post invoked");
		String completeURL = request.getRequestURL().toString();
		completeURL = completeURL.substring(completeURL.indexOf("/stream/"));
		completeURL = completeURL.replace("/stream/", "");
		rmdWebLogger.debug("completeURL url" + completeURL);
		webServiceInvoker.asStreamPost(completeURL, request, response);

	}
	
}