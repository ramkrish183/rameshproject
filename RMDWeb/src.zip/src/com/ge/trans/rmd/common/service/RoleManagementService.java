/**
 * ============================================================
 * File : RoleManagementService.java
 * Description : ServiceImpl layer class for Role management
 * 
 * Package : com.ge.trans.rmd.common.mvc.controller
 * Author : iGATE
 * Last Edited By :
 * Version : 1.0
 * Created on : November 19, 2012
 * History :
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2012 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.service;

import java.util.List;

import com.ge.trans.rmd.common.beans.RoleManagementBean;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.DeleteRolesResponseVO;
import com.ge.trans.rmd.common.vo.DeleteRolesUpdateVO;
import com.ge.trans.rmd.common.vo.PrivilegeVO;
import com.ge.trans.rmd.common.vo.RolesVO;
/*******************************************************************************
 * 
 * @Author : iGATE
 * @Version : 1.0
 * @Date Created:
 * @Date Modified :
 * @Modified By :
 * @Contact :
 * @Description : This is the service interface layer class which is used for
 *              RoleManagement
 * @History :
 * 
 ******************************************************************************/
public interface RoleManagementService {
	
	/**
	 * @Author:iGATE
	 * @param UserManagementBean
	 * @return void
	 * @Description: This method will return all roles from database
	 */
	public List<RolesVO> getAllRoles(RoleManagementBean objRoleManagementBean)
			throws RMDWebException, Exception;
	/**
	 * @Author:iGATE
	 * @param roleId
	 * @return List<PrivilegeVO>
	 * @Description: method to get all the privileges in a tree structure with
	 *               child inside parent structure.
	 */
	public List<PrivilegeVO> getAllPrivileges(String roleId)
			throws GenericAjaxException, RMDWebException;
	/**
	 * @Author:iGATE
	 * @param roleManagementBean
	 * @return void
	 * @Description: method to edit the roles
	 */
	public void editRole(RoleManagementBean roleManagementBean)
			throws GenericAjaxException, RMDWebException;
	/**
	 * @Author:iGATE
	 * @param roleManagementBean
	 * @return void
	 * @Description: method to add the roles
	 */
	public void addOrCopyRole(RoleManagementBean roleManagementBean)
			throws GenericAjaxException, RMDWebException;
	
	/**
	 * @Author:ge
	 * @param roleManagementBean
	 * @return void
	 * @Description: method to delete the roles
	 */
	public void deleteRole(RoleManagementBean objRoleManagementBean)
			throws GenericAjaxException, RMDWebException;
	
	public List<DeleteRolesResponseVO> getDeleteRoleList(RoleManagementBean objRoleManagementBean)
			throws GenericAjaxException, RMDWebException;
	
	public void deleteRoleUpdateList(List<DeleteRolesUpdateVO> tempList, String userId)
			throws GenericAjaxException, RMDWebException;
}
