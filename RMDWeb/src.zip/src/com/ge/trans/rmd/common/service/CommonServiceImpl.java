package com.ge.trans.rmd.common.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;

@Service
public class CommonServiceImpl extends RMDBaseServiceImpl implements CommonService {

	@Autowired
	WebServiceInvoker webServiceInvoker;
	
	@Override
	public String getAssetPanelParameters() throws RMDWebException {
		String assetPanelParams = (String) webServiceInvoker.get(
				ServiceConstants.GET_ASSET_PANEL_PARAMETERS, null, null,
				null, String.class);
		return assetPanelParams;
	}
}
