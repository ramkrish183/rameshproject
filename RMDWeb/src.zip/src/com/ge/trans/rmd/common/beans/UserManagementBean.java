package com.ge.trans.rmd.common.beans;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.common.beans.RMDBaseBean;


/*******************************************************************************
*
* @Author 		: iGATE
* @Version 	: 1.0
* @Date Created: Nov 19, 2013
* @Date Modified : 
* @Modified By : 
* @Contact 	:
* @Description : userManagement bean
* @History		:
*
******************************************************************************/
public class UserManagementBean extends RMDBaseBean{
	
	private static final long serialVersionUID = 1234L;
	
	private String strUserName;
	private String status;
	private String userId;
	private String strFirstName;
	private String strLastName;
	private String strRole;
	private Long roleId;
	private String customerName;
	private String customerId;
	private String userSeqId;
	private boolean addUserComponent;
	private boolean editUserComponent;
	private boolean deleteUserComponent;
	private Map<String,String> roles;
	private List<String> customerIdList;
	private String roleChangeFlag;
	private String userRoleIds;
	private String userCustomers;
	private String defaultCustomer;
	private String language;
	private String newUserIdEntered;
	private String oldUserId;
	private String userType;
	private String emailId;
	private String uom;
	private boolean blnMDSCUser;
	private boolean blnMLEnabled;
	private String eoaCMFlag;
	private String eoaMLFlag;
	private String eoaAlias;
	private String eoaMLVal;
	private String updateEOAUser;
	private String omdCMFlag;
	private String omdMLFlag;
	private String omdCmMmPrevRemoved;
	private String omdMlAloneRemoved;
	//newly added
	private String lastUpdatedBy;
	private String lastUpdatedTime;
	private boolean blnEmetricsEnabled;
	
	private String eoaEmetricsVal;
	private String eoaEmetricsFlag;
	private String omdEmetricsAloneRemoved;
	private String omdEmetricsFlag;
	
	//Added by Murali Medicherla for Rally Id : US226051
	private boolean mobileAccessPrivilege;
	private String mobileAccess;
	private String endUserScoring;
	private String eoaOnsiteUser;
	
	public String getEoaEmetricsVal() {
		return eoaEmetricsVal;
	}

	public void setEoaEmetricsVal(String eoaEmetricsVal) {
		this.eoaEmetricsVal = eoaEmetricsVal;
	}
	public String getEoaEmetricsFlag() {
		return eoaEmetricsFlag;
	}

	public void setEoaEmetricsFlag(String eoaEmetricsFlag) {
		this.eoaEmetricsFlag = eoaEmetricsFlag;
	}
	
	public String getOmdEmetricsAloneRemoved() {
		return omdEmetricsAloneRemoved;
	}

	public void setOmdEmetricsAloneRemoved(String omdEmetricsAloneRemoved) {
		this.omdEmetricsAloneRemoved = omdEmetricsAloneRemoved;
	}

	public String getOmdEmetricsFlag() {
		return omdEmetricsFlag;
	}

	public void setOmdEmetricsFlag(String omdEmetricsFlag) {
		this.omdEmetricsFlag = omdEmetricsFlag;
	}

	public boolean isBlnEmetricsEnabled() {
		return blnEmetricsEnabled;
	}

	public void setBlnEmetricsEnabled(boolean blnEmetricsEnabled) {
		this.blnEmetricsEnabled = blnEmetricsEnabled;
	}

	public String getUom() {
		return uom;
	}

	public void setUom(String uom) {
		this.uom = uom;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getNewUserIdEntered() {
		return newUserIdEntered;
	}

	public void setNewUserIdEntered(String newUserIdEntered) {
		this.newUserIdEntered = newUserIdEntered;
	}

	public String getOldUserId() {
		return oldUserId;
	}

	public void setOldUserId(String oldUserId) {
		this.oldUserId = oldUserId;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public String getUserRoleIds() {
		return userRoleIds;
	}

	public void setUserRoleIds(String userRoleIds) {
		this.userRoleIds = userRoleIds;
	}

	public String getRoleChangeFlag() {
		return roleChangeFlag;
	}

	public void setRoleChangeFlag(String roleChangeFlag) {
		this.roleChangeFlag = roleChangeFlag;
	}

	public Map<String, String> getRoles() {
		return roles;
	}

	public void setRoles(Map<String, String> roles) {
		this.roles = roles;
	}

	private Map<String, String> errorMsg;
	
	public String getUserSeqId() {
		return userSeqId;
	}

	public void setUserSeqId(String userSeqId) {
		this.userSeqId = userSeqId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public String getEoaOnsiteUser() {
		return eoaOnsiteUser;
	}

	public void setEoaOnsiteUser(String eoaOnsiteUser) {
		this.eoaOnsiteUser = eoaOnsiteUser;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
		
	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(final String customerId) {
		this.customerId = customerId;
	}

	public String getStrUserName() {
		return strUserName;
	}

	public void setStrUserName(final String strUserName) {
		this.strUserName = strUserName;
	}

	public String getStrFirstName() {
		return strFirstName;
	}

	public void setStrFirstName(final String strFirstName) {
		this.strFirstName = strFirstName;
	}

	
	public String getStrLastName() {
		return strLastName;
	}

	public void setStrLastName(final String strLastName) {
		this.strLastName = strLastName;
	}



	public String getStatus() {
		return status;
	}

	public void setStatus(final String status) {
		this.status = status;
	}


	public String getUserId() {
		return userId;
	}

	public void setUserId(final String userId) {
		this.userId = userId;
	}


	public String getStrRole() {
		return strRole;
	}

	public void setStrRole(final String strRole) {
		this.strRole = strRole;
	}
	
	
	/**
	 * @return the roleId
	 */
	public Long getRoleId() {
		return roleId;
	}

	/**
	 * @param roleId the roleId to set
	 */
	public void setRoleId(final Long roleId) {
		this.roleId = roleId;
	}
	
	public Map<String, String> getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(Map<String, String> errorMsg) {
		this.errorMsg = errorMsg;
	}
	
	public boolean isAddUserComponent() {
		return addUserComponent;
	}

	public void setAddUserComponent(boolean addUserComponent) {
		this.addUserComponent = addUserComponent;
	}

	public boolean isEditUserComponent() {
		return editUserComponent;
	}

	public void setEditUserComponent(boolean editUserComponent) {
		this.editUserComponent = editUserComponent;
	}
	
	

	public boolean isDeleteUserComponent() {
		return deleteUserComponent;
	}

	public void setDeleteUserComponent(boolean deleteUserComponent) {
		this.deleteUserComponent = deleteUserComponent;
	}

	@Override
	public String toString() {
		return "UserManagementVO [strUserName=" + strUserName + ", status="
				+ status + ", userId=" + userId + ", strFirstName="
				+ strFirstName + ", strLastName=" + strLastName + ", strRole="
				+ strRole + ", roleId=" + roleId + ", customerName="
				+ customerName + ", customerId=" + customerId + ", userSeqId="
				+ userSeqId +", lastUpdatedBy=" + lastUpdatedBy + ",lastUpdatedTime="
				+ lastUpdatedTime +",blnEmetricsEnabled="+blnEmetricsEnabled+"]";
	}

	public List<String> getCustomerIdList() {
		return customerIdList;
	}

	public void setCustomerIdList(List<String> customerIdList) {
		this.customerIdList = customerIdList;
	}

	public String getUserCustomers() {
		return userCustomers;
	}

	public void setUserCustomers(String userCustomers) {
		this.userCustomers = userCustomers;
	}

	public String getDefaultCustomer() {
		return defaultCustomer;
	}

	public void setDefaultCustomer(String defaultCustomer) {
		this.defaultCustomer = defaultCustomer;
	}

	public String getEoaCMFlag() {
		return eoaCMFlag;
	}

	public void setEoaCMFlag(String eoaCMFlag) {
		this.eoaCMFlag = eoaCMFlag;
	}

	public String getEoaMLFlag() {
		return eoaMLFlag;
	}

	public void setEoaMLFlag(String eoaMLFlag) {
		this.eoaMLFlag = eoaMLFlag;
	}

	public String getEoaAlias() {
		return eoaAlias;
	}

	public void setEoaAlias(String eoaAlias) {
		this.eoaAlias = eoaAlias;
	}

	public String getEoaMLVal() {
		return eoaMLVal;
	}

	public void setEoaMLVal(String eoaMLVal) {
		this.eoaMLVal = eoaMLVal;
	}

	public String getUpdateEOAUser() {
		return updateEOAUser;
	}

	public void setUpdateEOAUser(String updateEOAUser) {
		this.updateEOAUser = updateEOAUser;
	}

	public String getOmdCMFlag() {
		return omdCMFlag;
	}

	public void setOmdCMFlag(String omdCMFlag) {
		this.omdCMFlag = omdCMFlag;
	}

	public String getOmdMLFlag() {
		return omdMLFlag;
	}

	public void setOmdMLFlag(String omdMLFlag) {
		this.omdMLFlag = omdMLFlag;
	}

	public String getOmdCmMmPrevRemoved() {
		return omdCmMmPrevRemoved;
	}

	public void setOmdCmMmPrevRemoved(String omdCmMmPrevRemoved) {
		this.omdCmMmPrevRemoved = omdCmMmPrevRemoved;
	}

	public String getOmdMlAloneRemoved() {
		return omdMlAloneRemoved;
	}

	public void setOmdMlAloneRemoved(String omdMlAloneRemoved) {
		this.omdMlAloneRemoved = omdMlAloneRemoved;
	}

	public boolean isBlnMDSCUser() {
		return blnMDSCUser;
	}

	public void setBlnMDSCUser(boolean blnMDSCUser) {
		this.blnMDSCUser = blnMDSCUser;
	}

	public boolean isBlnMLEnabled() {
		return blnMLEnabled;
	}

	public void setBlnMLEnabled(boolean blnMLEnabled) {
		this.blnMLEnabled = blnMLEnabled;
	}
	//newly added code
	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getLastUpdatedTime() {
		return lastUpdatedTime;
	}

	public void setLastUpdatedTime(String lastUpdatedTime) {
		this.lastUpdatedTime = lastUpdatedTime;
	}

	public boolean isMobileAccessPrivilege() {
		return mobileAccessPrivilege;
	}

	public void setMobileAccessPrivilege(boolean mobileAccessPrivilege) {
		this.mobileAccessPrivilege = mobileAccessPrivilege;
	}

	public String getMobileAccess() {
		return mobileAccess;
	}

	public void setMobileAccess(String mobileAccess) {
		this.mobileAccess = mobileAccess;
	}

	public String getEndUserScoring() {
		return endUserScoring;
	}

	public void setEndUserScoring(String endUserScoring) {
		this.endUserScoring = endUserScoring;
	}

	
	
	

		
}
