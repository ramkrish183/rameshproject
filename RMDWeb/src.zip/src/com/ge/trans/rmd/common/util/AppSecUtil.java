package com.ge.trans.rmd.common.util;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;


public final class AppSecUtil{
	
		/**
		 * @param string
		 * @return
		 * @Description Method validates, String contains only numbers
		 */
		public static boolean checkIntNumber(final String string){
			boolean isNumber = false;
			if(null != string && !string.isEmpty()){
			final Pattern numberPattern = Pattern.compile(AppConstants.NUMPATTERN);
			isNumber = numberPattern.matcher(string).matches();
			}
			return isNumber;
		}
		
	
		/**
		 * @param string
		 * @return
		 * @Description Method validates, string is a combination alphabets and numbers 
		 */
		public static boolean checkAlphaNumeric(final String string){
			boolean isAlphaNumericString = false;
			if(null != string && !string.isEmpty()){
			final Pattern alphaNumericPattern = Pattern.compile(AppConstants.ALPHA_NUMERICPATTERN);
			isAlphaNumericString = alphaNumericPattern.matcher(string).matches();
			}
			return isAlphaNumericString;
		}
		
		/**
		 * @param string
		 * @return
		 * @Description Method validates, string is a combination alphabets, numbers and hypen
		 * white space allowed
		 */
		public static boolean checkAlphaNumericHypen(final String string){
			boolean isAlphaNumericHypenString = false;
			if(null != string && !string.isEmpty()){
			final Pattern alphaNumericHypenPattern = Pattern.compile(AppConstants.ALPHA_NUMERIC_HYPHEN_PATTERN);
			isAlphaNumericHypenString = alphaNumericHypenPattern.matcher(string).matches();
			}
			return isAlphaNumericHypenString;
		}
		
		/**
		 * @param string
		 * @return
		 * @Description Method validates, string is a combination alphabets, numbers and hypen
		 * underscore and white space allowed
		 */
		public static boolean checkAlphaNumericUnderscore(final String string){
			boolean isAlphaNumericUnderScore = false;
			if(null != string && !string.isEmpty()){
			final Pattern alphaNumericUnderScorePattern = Pattern.compile(AppConstants.ALPHA_NUMERIC_UNDERSCORE_PATTERN);
			isAlphaNumericUnderScore = alphaNumericUnderScorePattern.matcher(string).matches();
			}
			return isAlphaNumericUnderScore;
		}
		/**
		 * @param string
		 * @return
		 * @Description Method returns true for upper case, vice versa for lower case
		 */
		public static boolean checkCase(final String string){
			boolean isUpperCase = false;
			if(null != string && !string.isEmpty()){
			final Pattern casePattern = Pattern.compile(AppConstants.CHECK_CASE_PATTERN);
			isUpperCase = casePattern.matcher(string).matches();
			}
			return isUpperCase;
		}
		
		
		/**
		 * @param string
		 * @return
		 * @Description Method validates, string has a proper email format
		 */
		public static boolean validateEmailAddress(final String string,
			final String emailRegex) {
		boolean isValidEmail = false;
		if (null != string && !string.isEmpty() && null != emailRegex
				&& !emailRegex.isEmpty()) {
			final Pattern emailPattern = Pattern.compile(emailRegex);
			isValidEmail = emailPattern.matcher(string).matches();
			}
		return isValidEmail;
		}
		
		/**
		 * @param string
		 * @return
		 * @Description Method validates, string has a proper date format 
		 */
		public static boolean validateDate(final String string) {
			final boolean isValidDate = false;
			if (null != string && !string.isEmpty()) {
				try {
final	SimpleDateFormat dateFormat = new SimpleDateFormat(AppConstants.DATE_PATTERN);
					dateFormat.parse(string);
					return true;
				} catch (Exception exception) {
					return  false;
				}
			}
			return isValidDate;
		}
		
		public static boolean validFileType(final String fileName) {
			if (null != fileName && !fileName.isEmpty()) {
				final	String del = AppConstants.FIELD_TYPE_PATTERN;
				final	String[] temp = fileName.split(del);
				if (temp[1].equals(AppConstants.PDF)) {
					return true;
				} else {
					return false;
				}
			}
			return false;
		}
		
		public boolean checkFileSize(final File file,final double size) {
			final	long fileSize = file.length();
			final double len = (double) fileSize / 1024;
			if (len <= size) {
				return true;
			} else {
				return false;
			}
		}
		
		public static String htmlEscaping(final String fieldValue) {
			final	StringBuffer result = new StringBuffer();
			for (int i = 0; i < fieldValue.length(); i++) {
         final	char character = fieldValue.charAt(i);
				 if (character == '<') {
			         result.append(AppConstants.AND_LT);
			       }
			       else if (character == '>') {
			         result.append(AppConstants.AND_GT);
			       }
			       else if (character == '&') {
			         result.append(AppConstants.AND_AMP);
			      }
			       else if (character == '\"') {
			         result.append(AppConstants.AND_QUOT);
			       }
			       else if (character == '\t') {
			         addCharEntity(9, result);
			       }
			       else if (character == '!') {
			         addCharEntity(33, result);
			       }
			       else if (character == '#') {
			         addCharEntity(35, result);
			       }
			       else if (character == '$') {
			         addCharEntity(36, result);
			       }
			       else if (character == '%') {
			         addCharEntity(37, result);
			       }
			       else if (character == '\'') {
			         addCharEntity(39, result);
			       }
			       else if (character == '(') {
			         addCharEntity(40, result);
			       }
			       else if (character == ')') {
			         addCharEntity(41, result);
			       }
			       else if (character == '*') {
			         addCharEntity(42, result);
			       }
			       else if (character == '+') {
			         addCharEntity(43, result);
			       }
			       else if (character == ',') {
			         addCharEntity(44, result);
			       }
			       else if (character == '-') {
			         addCharEntity(45, result);
			       }
			       else if (character == '.') {
			         addCharEntity(46, result);
			       }
			       else if (character == '/') {
			         addCharEntity(47, result);
			       }
			       else if (character == ':') {
			         addCharEntity(58, result);
			       }
			       else if (character == ';') {
			         addCharEntity(59, result);
			       }
			       else if (character == '=') {
			         addCharEntity(61, result);
			       }
			       else if (character == '?') {
			         addCharEntity(63, result);
			       }
			       else if (character == '@') {
			         addCharEntity(64, result);
			       }
			       else if (character == '[') {
			         addCharEntity(91, result);
			       }
			       else if (character == '\\') {
			         addCharEntity(92, result);
			       }
			       else if (character == ']') {
			         addCharEntity(93, result);
			       }
			       else if (character == '^') {
			         addCharEntity(94, result);
			       }
			       else if (character == '_') {
			         addCharEntity(95, result);
			       }
			       else if (character == '`') {
			         addCharEntity(96, result);
			       }
			       else if (character == '{') {
			         addCharEntity(123, result);
			       }
			       else if (character == '|') {
			         addCharEntity(124, result);
			       }
			       else if (character == '}') {
			         addCharEntity(125, result);
			       }
			       else if (character == '~') {
			         addCharEntity(126, result);
			       }
			       else {
			         //the char is not a special one
			         //add it to the result as is
			         result.append(character);
			       }
			     }
			return result.toString();
			}
		
		/**
		 * @param fileName
		 * @return
		 * @Description Method validates, filename contains valid characters or not
		 */
		public static boolean validateFileName(final String fileName){
			boolean isValidFileName = false;
			if(null !=fileName && !fileName.isEmpty()){
				final	Pattern filePattern = Pattern.compile(AppConstants.FIELD_NAME_PATTERN);
				isValidFileName = filePattern.matcher(fileName).matches();
			}
			return isValidFileName;
		}
	
		/**
		 * @param string
		 * @return
		 * @Description Method validates, string contains only alphabets
		 */
		public static boolean checkAlphabets(final String string){
			boolean isAlphabet = false;
			if(null != string && !string.isEmpty()){
			final Pattern numberPattern = Pattern.compile(AppConstants.ALPHA_PATTERN);
			isAlphabet = numberPattern.matcher(string).matches();
			}
			return isAlphabet;
		}
		
		public static boolean validateFromDate(final String fromDateStr,final String toDateStr) {
			boolean isValidDate = false;
    final DateFormat formatter = new SimpleDateFormat(AppConstants.FROM_DATE_PATTERN);
			try { 
				final	Date fromDate =(Date)formatter.parse(fromDateStr); 
				final	Date toDate =(Date)formatter.parse(toDateStr); 
			if(fromDate.compareTo(toDate) > 0)  
			isValidDate=false;
			else if(fromDate.compareTo(toDate) < 0)
			isValidDate=true;
			else
				isValidDate = false;
		} catch (Exception e) {
			isValidDate = false;
		}
		return isValidDate;
	}
	
	public static boolean compareLists(final List<String> actualList,
			final	List<String> userInputList) {
		if ((null != actualList && !actualList.isEmpty())
				&& (null != userInputList && !userInputList.isEmpty())) {
			final int listSize = userInputList.size();
			// compare 2 lists
			for (int i = 0; i < listSize; i++) {
				if (!actualList.contains(userInputList.get(i))) {
					return false;
				}
			}
			return true;
		} else {
			return false;
		}
	}
	public static boolean isListContainsValue(final String userInput,
			final List<String> actualList) {
			if ((null != actualList && !actualList.isEmpty())
					&& (null != userInput)) {
					if (!actualList.contains(userInput)) {
						return false;
					}
				
				return true;
			} else {
				return false;
			}
		}
		

	/**
	 * @param string
	 * @return Method validates the rule title values in km related screen
	 */
	public static boolean checkRuleTitleValues(final String string) {
		boolean isValidTitle = false;
		if (null != string && !string.isEmpty()) {
			final Pattern numberPattern = Pattern
					.compile(AppConstants.RULE_TITLE_PATTERN);
			isValidTitle = numberPattern.matcher(string).matches();
		}
		return isValidTitle;
	}
	
	private static void addCharEntity(final Integer aIdx, final StringBuffer aBuilder){
	    String padding = AppConstants.EMPTY_STRING;
	    if( aIdx <= 9 ){
	       padding = AppConstants.PADDING_00;
	    }
	    else if( aIdx <= 99 ){
	      padding =AppConstants.PADDING_0;
	    }
	    final  String number = padding + aIdx.toString();
	    aBuilder.append(AppConstants.AND_HASH + number + AppConstants.SYMBOL_SEMICOLON);
	  }
	
	
	/**
	 * @param string
	 * @return
	 * Method validates, string must not contains 2 consecutive hyphen
	 * used for rule title and note fields in km screen
	 */
	public static boolean checkDoubleHyphen(final String string) {
		boolean isValidInput = false;
		if(null != string && !string.isEmpty()){
			final String pattern = AppConstants.DOUBLE_HYPHEN_PATTERN;
			final int a = string.indexOf(pattern);
			if (a != -1) {
				isValidInput = false;
			} else {
				isValidInput = true;
			}
		}
		return isValidInput;
	}
	
}
