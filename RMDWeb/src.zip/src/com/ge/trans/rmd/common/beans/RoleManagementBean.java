package com.ge.trans.rmd.common.beans;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.common.beans.RMDBaseBean;


public class RoleManagementBean extends RMDBaseBean {

	
	private static final long serialVersionUID = 1L;
	private String roleId;
	private String roleName;
	private String roleDescription;
	private String sortOrder;
	private List<PrivilegeBean> privileges;
	private Map<String, String> errorMsg;
	public Map<String, String> getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(Map<String, String> errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getRoleDescription() {
		return roleDescription;
	}
	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public List<PrivilegeBean> getPrivileges() {
		return privileges;
	}
	public void setPrivileges(List<PrivilegeBean> privileges) {
		this.privileges = privileges;
	}

}
