package com.ge.trans.rmd.common.exception;

public class GenericAjaxException extends RuntimeException {
	
	
	private String customMsg;
	private String excpType;
	private int code;
	private String status;
	

	public int getCode() {
		return code;
	}



	public void setCode(final int code) {
		this.code = code;
	}



	public String getStatus() {
		return status;
	}



	public void setStatus(final String status) {
		this.status = status;
	}



	public String getCustomMsg() {
		return customMsg;
	}



	public void setCustomMsg(final String customMsg) {
		this.customMsg = customMsg;
	}

	public GenericAjaxException(final String customMsg) {
		this.customMsg = customMsg;
	}
/*	public GenericAjaxException(String customMsg,String ExcpType) {
		this.customMsg = customMsg;
		this.excpType = ExcpType;
	}*/

	public GenericAjaxException(final String status,final String customMsg,final String ExcpType) {
		this.customMsg = customMsg;
		this.excpType = ExcpType;
		this.status = status;
		
			}
	
	public GenericAjaxException(final String status,final String ExcpType) {
		this.status = status;
		this.excpType = ExcpType;
		
			}


	public String getExcpType() {
		return excpType;
	}



	public void setExcpType(final String excpType) {
		this.excpType = excpType;
	}
}
