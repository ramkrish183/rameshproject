package com.ge.trans.rmd.common.service;

import static com.ge.trans.rmd.common.util.ServiceConstants.ADMIN_SERVICE_GET_SYSTEM_TIME_ZONES;
import static com.ge.trans.rmd.common.util.ServiceConstants.SAVE_USER_PREFERENCE;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;
import java.util.SortedSet;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.common.beans.UserPreferenceBean;
import com.ge.trans.rmd.common.exception.AuthenticationException;
import com.ge.trans.rmd.common.exception.AuthorizationException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.vo.UserPreferenceVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.services.admin.valueobjects.PreferencesRequestType;
import com.ge.trans.rmd.services.admin.valueobjects.PreferencesType;
import com.ge.trans.rmd.services.admin.valueobjects.SystemTimeZoneResponseType;

@Service
public class UserPreferenceServiceImpl extends RMDBaseServiceImpl implements UserPreferenceService {

	private final RMDWebLogger rmdWebLogger = RMDWebLogger.getLogger(getClass());

	@Autowired
	private WebServiceInvoker rsInvoker;
	
	@Autowired
	private CachedService cachedService;

	/**
	 * @Author: 
	 * @param 
	 * @return System Time Zone
	 * @Description: This method will return System Time Zone from Database
	 */
	@Override
	public SortedSet<Entry<String, String>> getTimezone(UserVO userVO)
			throws RMDWebException, Exception {
		rmdWebLogger.debug("getTimezone():START ");
		SystemTimeZoneResponseType[] systemTimezones = null;
		
		SortedSet<Entry<String, String>> timeZone = null;		
		SortedSet<Entry<String, String>> timeZoneReturn = null;

		final Map<String, String> timeZone1 = new HashMap<String, String>();
		final Map<String, String> casheServtimeZoneLst = new HashMap<String, String>();		
		final Map<String, String> timeZone2 = new LinkedHashMap<String, String>();
		
		try {
			Map<String, SystemTimeZoneResponseType> timeZoneCachedMap = cachedService
					.getAllTimeZones();
			
			Set<String> timeZoneSet = timeZoneCachedMap.keySet();
			Iterator<String> timeZoneIt = timeZoneSet.iterator();
			
			
			while (timeZoneIt.hasNext()) {
				String timeZoneName = timeZoneIt.next();
				SystemTimeZoneResponseType systemTimeZone = timeZoneCachedMap
						.get(timeZoneName);
				
				if (null != systemTimeZone && null != systemTimeZone.getName()
						&& null != systemTimeZone.getTimeZoneId()) {

					timeZone1.put(systemTimeZone.getName(), systemTimeZone.getTimeZoneId());
					casheServtimeZoneLst.put(systemTimeZone.getName(), systemTimeZone.getFullName());

					if (null != userVO.getTimeZone()
							&& userVO.getTimeZone().equalsIgnoreCase(
									systemTimeZone.getName()))
						userVO.setTimeZone(systemTimeZone.getTimeZoneId());
				} 
			}
			
			timeZone = RMDCommonUtil.tzentriesSortedByValues(timeZone1);

			for (final Iterator it = timeZone.iterator(); it.hasNext();) {
				Map.Entry me = (Map.Entry) it.next();				

				timeZone2.put(
						me.getKey().toString(),
						displayTimeZone(TimeZone.getTimeZone(me.getValue()
								.toString()))
								+ AppConstants.ATTR_EMPTY
								+ AppConstants.ATTR_EMPTY
								+ me.getKey()
								+ AppConstants.ATTR_EMPTY
								+ AppConstants.SYMBOL_HYPEN
								+ AppConstants.ATTR_EMPTY
								+ casheServtimeZoneLst.get(me.getKey().toString()));
			}
			
			timeZoneReturn = RMDCommonUtil.sortedByValues(timeZone2);

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getTimezone() method ", rmdEx);
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(rmdEx
					.getMessage())) {
				throw new AuthenticationException(rmdEx.getCode(),
						rmdEx.getMessage());
			} else if (AppConstants.EXCEPTION_EOA_109.equalsIgnoreCase(rmdEx
					.getMessage())) {
				throw new AuthorizationException(rmdEx.getCode(),
						rmdEx.getMessage());
			} else {

				throw rmdEx;
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getTimezone() method ", ex);
			throw ex;
		}
		rmdWebLogger.debug("getTimezone():END");

		return timeZoneReturn;
	}

	private static String displayTimeZone(TimeZone tz) {
		String result;
		long hours = TimeUnit.MILLISECONDS.toHours(tz.getRawOffset());
		long minutes = TimeUnit.MILLISECONDS.toMinutes(tz.getRawOffset())
				- TimeUnit.HOURS.toMinutes(hours);
		// avoid -4:-30 issue
		minutes = Math.abs(minutes);

		if (hours > 0) {
			result = String.format("(GMT +%d:%02d)", hours, minutes);
		} else if (hours == 0) {
			result = AppConstants.ATTR_EMPTY;
		}
		else {
			result = String.format("(GMT %d:%02d)", hours, minutes);
		}
		return result;
	}

	/**
	 * @Author:
	 * @param
	 * @return System Time Zone
	 * @Description: This method will set User preferences type in session 
	 */
	@Override
	public UserPreferenceBean getDefaultUserPreferences(final UserVO userVO)
	throws RMDWebException, Exception {
		final UserPreferenceBean userPreferenceBean = new UserPreferenceBean();
		rmdWebLogger.debug("getDefaultUserPreferences():START");
		try {
			if(userVO.getTimeZone()== null)
			{
				userVO.setTimeZone(AppConstants.ESTTIME);
			}
			if(userVO.getStrLanguage()== null)
			{
				userVO.setStrLanguage(AppConstants.LANG);
			}
			if (userVO.getUserPreferenceVOLst() != null) {

				final Map<Long, String> userPreferenceMapLst=new HashMap<Long, String>();
				String defaultRole=null;
				for (UserPreferenceVO userPreferenceVO : userVO.getUserPreferenceVOLst()) {


					userPreferenceMapLst.put(userPreferenceVO.getGetUsrUserPreferenceSeqId(),userPreferenceVO.getUserPreferenceType());

					if(userPreferenceVO.getUserPreferenceType().equalsIgnoreCase(AppConstants.ROLE))
						defaultRole=userPreferenceVO.getUserPreferenceValue();
				}

				userPreferenceBean.setUserPrefMap(userPreferenceMapLst);
				userPreferenceBean.setRole(defaultRole);
			}
			
			if(userVO.getDefaultUOM()== null)
			{
				userVO.setDefaultUOM(AppConstants.US);
			}
		}
		catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getDefaultUserPreferences() method ", ex);
			throw ex;
		}
		rmdWebLogger.debug("getDefaultUserPreferences():END");
		return userPreferenceBean;
	}

	/**
	 * @Author:
	 * @param
	 * @return
	 * @throws RMDWebException,Exception 
	 * @Description: This method will update User preference Table in Database
	 */
	@Override
	public UserPreferenceBean saveUserPreference(
			final UserPreferenceBean userPreferenceBean) throws RMDWebException,
			Exception {
		rmdWebLogger.debug("saveUserPreference():START");
		try {

			final Map<Long, String> userPreferenceMapLst=userPreferenceBean.getUserPrefMap();
			final List<PreferencesType> preferenceTypeLst = new ArrayList<PreferencesType>();
			PreferencesType preferencesType = null;	
			if (userPreferenceMapLst != null) {
				for (Map.Entry<Long, String> entry : userPreferenceMapLst.entrySet()) {

					preferencesType = new PreferencesType();
					preferencesType.setUserId(userPreferenceBean.getUsrUsersSeqId());
					preferencesType.setCustomerId(userPreferenceBean.getCustomerId());
					preferencesType.setUserPreferenceSeqId(entry.getKey());
					preferencesType.setUserPreferernceType(entry.getValue());
					if (entry.getValue().equalsIgnoreCase(AppConstants.LANGUAGE)) {
						preferencesType.setUserPreferenceValue(userPreferenceBean.getLanguage());
					}
					else if (entry.getValue().equalsIgnoreCase(AppConstants.TIMEZONE)) {
						preferencesType.setUserPreferenceValue(userPreferenceBean.getTimeZone());
					}else if (entry.getValue().equalsIgnoreCase(AppConstants.MEASUREMENT_SYSYTEM)) {
						preferencesType.setUserPreferenceValue(userPreferenceBean.getUom());
					}
					else {
						preferencesType.setUserPreferenceValue(userPreferenceBean.getRole());
					}
					preferenceTypeLst.add(preferencesType);
				}
			}

			final	Map<String,String> headerParams = getHeaderMap(userPreferenceBean);

			final	PreferencesRequestType preferencesRequestType = new PreferencesRequestType();
			preferencesRequestType.getPreferencesType().addAll(preferenceTypeLst);
				preferencesRequestType.setCustomerChangeFlag(userPreferenceBean.getCustomerChange());
				preferencesRequestType.setCustomerId(userPreferenceBean.getCustomerId());
				preferencesRequestType.setUserSeqId(userPreferenceBean.getUsrUsersSeqId());
			
			//Invoking the web service to save user preferences
			rsInvoker.post(SAVE_USER_PREFERENCE, preferencesRequestType,headerParams);

			userPreferenceBean.setMessage(AppConstants.USER_PREFERENCE_UPDATE);
			userPreferenceBean.setResult(AppConstants.SUCCESS);

			userPreferenceBean.setResult(AppConstants.SUCCESS);
			if(null!=userPreferenceBean.getCustomerChange()&& !userPreferenceBean.getCustomerChange().isEmpty()){
				userPreferenceBean.setResult(AppConstants.DEFAULT_CUSTOMER);
			}

		}catch (Exception ex) {
			rmdWebLogger.error("Exception occured in saveUserPreference method ", ex);
			RMDWebErrorHandler.handleException(ex);
			
		}
		rmdWebLogger.debug("saveUserPreference():END");
		return userPreferenceBean;
	}

}