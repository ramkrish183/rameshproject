/**
 * 
 */
package com.ge.trans.rmd.common.service;

import java.util.List;
import java.util.concurrent.Future;

import com.ge.trans.rmd.cm.valueobjects.CallLogReportBean;
import com.ge.trans.rmd.cm.valueobjects.InboundTurnoverBean;
import com.ge.trans.rmd.common.exception.RMDWebException;


/**
 * @author 212576702
 *
 */
public interface RunTurnoverService {

		public Future<List<InboundTurnoverBean>> getInboundReportData() throws RMDWebException, Exception; 
		public Future<CallLogReportBean> getCallCountByLocation() throws RMDWebException;
        public Future<CallLogReportBean> getCustBrkDownByMins() throws RMDWebException;
        public Future<CallLogReportBean> getCallCntByBusnsArea() throws RMDWebException;
        public Future<CallLogReportBean> getWeeklyCallCntByBusnsArea() throws RMDWebException;
        public Future<CallLogReportBean> getVehCallCntByBusnsArea() throws RMDWebException;
        public String getManualCallCount() throws RMDWebException;
        public String getMinCallCountOfAsset(String listName) throws RMDWebException;
		
		
}
