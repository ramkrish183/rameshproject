/**
 * ============================================================
 * Classification: GE Confidential
 * File : AuthorizationServI.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.service;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on : November 14, 2011
 * History
 * Modified By : iGATE
 *
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.common.beans.UserLoginBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.ErrorVO;
import com.ge.trans.rmd.common.vo.MenuListResourceVO;
import com.ge.trans.rmd.common.vo.ResourceVO;
import com.ge.trans.rmd.services.authorization.valueobjects.RolePrivilegesType;

/*******************************************************************************
 * 
 * @Author : iGATE
 * @Version : 1.0
 * @Date Created: November 14, 2011
 * @Date Modified : November 14, 2011
 * @Modified By :
 * @Contact :
 * @Description : This Interface act as AuthorizationServI and provide the
 *              Authorization related funtionalities
 * @History :
 * 
 ******************************************************************************/
public interface AuthorizationService {

	List<RolePrivilegesType> authorize(final UserLoginBean userBean) throws RMDWebException,
			Exception;
	String getLookUpValueForName(final String lookupName) throws RMDWebException,
	Exception;

	/**
	 * @Author: iGATE Patni
	 * @param lookupName
	 * @return List<ResourceVO>
	 * @Description: This method is used to populate lookup details for the
	 *               particular list name
	 * 
	 */
	List<ResourceVO> getLegendsForMap(final String lookupName)
			throws RMDWebException, Exception;

	List<ResourceVO> getKPIsForRole(final String lookupName)
	throws RMDWebException, Exception;

	MenuListResourceVO getMenuListForARole(
			final Map<String, ResourceVO> primaryNavMap,
			final Map<String, List<ResourceVO>> secondaryNAvMap, final UserLoginBean userBean)
			throws RMDWebException, Exception;

	String getSubPageIndexForHome(final String homePage,
			final Map<String, List<ResourceVO>> secondaryMap);

	public MenuListResourceVO getPrivileges(
			final Map<String, ResourceVO> primaryNavMap,
			final Map<String, List<ResourceVO>> secondaryNAvMap, final UserLoginBean userBean)
			throws RMDWebException, Exception;
	
	Map<String, List<String>> collectUtilities(
			Map<String, ResourceVO> authorizedPriMapForARole,
			Map<String, List<ResourceVO>> authorizedSecMapForRole,
			Map<String, List<ResourceVO>> stickyTabSubTabMap,
			List<ResourceVO> utilityList)
			throws RMDWebException, Exception;
	
	void persistException(ErrorVO errorVO);
	
	public long getLookUpObjidForName(String lookupName) throws RMDWebException, Exception;
	
}
