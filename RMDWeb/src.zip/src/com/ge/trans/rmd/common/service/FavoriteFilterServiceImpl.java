/**
 * ============================================================
 * Classification: GE Confidential
 * File : AuthorizationServI.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.service;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on : November 14, 2011
 * History
 * Modified By : iGATE
 *
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.common.beans.FavoriteFilterBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.vo.FavoriteFilterDetailVO;
import com.ge.trans.rmd.common.vo.FilterDetailVO;
import com.ge.trans.rmd.services.admin.valueobjects.ColumnInfoType;
import com.ge.trans.rmd.services.admin.valueobjects.DataInfoType;
import com.ge.trans.rmd.services.admin.valueobjects.FavFilterDetailType;
import com.ge.trans.rmd.services.admin.valueobjects.FetchFavFilterResponseType;
import com.ge.trans.rmd.services.admin.valueobjects.FilterDetailType;
import com.ge.trans.rmd.services.admin.valueobjects.SaveFavFilterType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class FavoriteFilterServiceImpl extends RMDBaseServiceImpl implements
		FavoriteFilterService {

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	private WebServiceInvoker rsInvoker;

	/**
	 * Method to call add favorite filter web service for chosen criteria by
	 * User
	 */
	@Override
	public void addFavoriteFilter(FavoriteFilterBean favoriteFilterBean)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("FavoriteFilterServiceImpl - addFavoriteFilter method ::Starts");
		SaveFavFilterType saveFavFilterType = new SaveFavFilterType();
		ColumnInfoType columnInfo = new ColumnInfoType();
		DataInfoType dataInfo = new DataInfoType();
		List<String> columnName = new ArrayList<String>();
		List<String> columnType = new ArrayList<String>();
		List<String> dataValue = new ArrayList<String>();
		try {
			final Map<String, String> headerParams = getHeaderMap(favoriteFilterBean);
			Map<String, String> columnTypeMap = favoriteFilterBean
					.getColumnType();
			// Adding column entries
			for (Map.Entry<String, String> columnEntry : columnTypeMap
					.entrySet()) {

				columnName.add(columnEntry.getKey());
				columnType.add(columnEntry.getValue());
				dataValue.add(favoriteFilterBean.getColumnValue().get(
						columnEntry.getKey()));
			}

			columnInfo.setColumnName(columnName);
			columnInfo.setColumnType(columnType);
			dataInfo.setDataValue(dataValue);
			saveFavFilterType.setColumnInfo(columnInfo);
			saveFavFilterType.setDataInfo(dataInfo);
			saveFavFilterType.setLinkUsrRoleSeqId(favoriteFilterBean
					.getLinkUserRoleSeqId() + "");
			saveFavFilterType.setScreenName(favoriteFilterBean.getScreenName());
			saveFavFilterType.setFilterId(favoriteFilterBean.getFilterId());
			rsInvoker.put(ServiceConstants.PUT_ADD_FAV_FILTER,
					saveFavFilterType, headerParams);

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in addFavoriteFilter method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		rmdWebLogger
				.debug("FavoriteFilterServiceImpl - addFavoriteFilter method ::Ends");

	}

	/**
	 * Method to call delete favorite filter web service
	 */
	@Override
	public void deleteFavoriteFilter(FavoriteFilterBean favoriteFilterBean)
			throws RMDWebException, Exception {
		final Map<String, String> queryParamsMap = new HashMap<String, String>();
		final Map<String, String> headerParams = getHeaderMap(favoriteFilterBean);
		try{
			if(null!=favoriteFilterBean.getFilterId() && !favoriteFilterBean.getFilterId().equals(AppConstants.EMPTY_STRING)){
			queryParamsMap.put(AppConstants.FILTER_ID, favoriteFilterBean.getFilterId());
			queryParamsMap.put(RMDCommonConstants.FILTER_NAME, favoriteFilterBean.getScreenName());
			queryParamsMap.put("usrRoleSeqId", favoriteFilterBean.getLinkUserRoleSeqId().toString());
			}
			rsInvoker.delete(ServiceConstants.DELETE__FAV_FILTER, null, queryParamsMap, headerParams);
		}
		catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getAssetFaultDetails method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}

	}
	/**
	 * Method to call fetch favorite filter web service for role id
	 */
	@Override
	public List<FavoriteFilterDetailVO> fetchFavoriteFilter(FavoriteFilterBean favoriteFilterBean)
			throws RMDWebException, Exception {
		
		final Map<String, String> queryParamsMap = new HashMap<String, String>();
		final Map<String, String> headerParams = getHeaderMap(favoriteFilterBean);
		FetchFavFilterResponseType resultObj=null;
		List<FavoriteFilterDetailVO> lsFavoriteFilterDetails=new ArrayList<FavoriteFilterDetailVO>();
		List<FilterDetailVO> lsFilterDetails = null;
		List<FavFilterDetailType> favoriteFiltersResponse=new ArrayList<FavFilterDetailType>();
		List<FilterDetailType> lsFilterResponse=null;
		FilterDetailType objFilterResponse=null;
		FavoriteFilterDetailVO objFavFilterDetailVO = null;
		FilterDetailVO objFilterDetailVO = null;
		
		try{
			if(null!=favoriteFilterBean.getLinkUserRoleSeqId()){
			queryParamsMap.put(AppConstants.QUERY_PARAM_USR_ROLE_ID, favoriteFilterBean.getLinkUserRoleSeqId()+"");
			}
			resultObj = (FetchFavFilterResponseType)rsInvoker.get(
					ServiceConstants.GET_FETCH_FAV_FILTER,
					null,
					queryParamsMap,headerParams,
					FetchFavFilterResponseType.class				
					);
			
			favoriteFiltersResponse=resultObj.getFilterDetail();
			
			if(RMDCommonUtility.isCollectionNotEmpty(favoriteFiltersResponse)){
				for(FavFilterDetailType responseObj : favoriteFiltersResponse){
					objFavFilterDetailVO = new FavoriteFilterDetailVO();					
					objFavFilterDetailVO.setFilterId(responseObj.getFilterId());
					objFavFilterDetailVO.setFilterName(responseObj.getFilterName());
					
					
					lsFilterResponse = responseObj.getFilterDetails();					
					lsFilterDetails = new ArrayList<FilterDetailVO>();
					
					if(RMDCommonUtility.isCollectionNotEmpty(lsFilterResponse)){
						for(FilterDetailType filterDetailObj : lsFilterResponse){
							objFilterDetailVO = new FilterDetailVO();
														
					    	objFilterDetailVO.setColumnName(filterDetailObj.getColumnName());
					    	objFilterDetailVO.setColumnType(filterDetailObj.getColumnType());
					    	objFilterDetailVO.setUsrFilterId(filterDetailObj.getUsrFilterId());
					    	objFilterDetailVO.setUsrFilterDetailId(filterDetailObj.getUsrFilterDetailId());
					    	objFilterDetailVO.setFromFilterValue(filterDetailObj.getFromFilterValue());
					    	objFilterDetailVO.setToFilterValue(filterDetailObj.getToFilterValue());
					    	objFilterDetailVO.setCreatedBy(filterDetailObj.getCreatedBy());
					    	objFilterDetailVO.setResourceId(filterDetailObj.getResourceId());
					    	objFilterDetailVO.setResourceName(filterDetailObj.getResourceName());					    	
					    	objFilterDetailVO.setLastUpdatedBy(filterDetailObj.getLastUpdatedBy());
							
							lsFilterDetails.add(objFilterDetailVO);
						}
						
					}
					
					objFavFilterDetailVO.setFilterDetails(lsFilterDetails);
					lsFavoriteFilterDetails.add(objFavFilterDetailVO);
					
				}
			}			
			
		}
		catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getAssetFaultDetails method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		
		
		return lsFavoriteFilterDetails;
	}

}