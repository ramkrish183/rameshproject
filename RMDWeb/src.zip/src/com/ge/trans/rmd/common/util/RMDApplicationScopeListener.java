package com.ge.trans.rmd.common.util;

import static com.ge.trans.rmd.common.util.AppConstants.RESOURCE_FILE;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContextEvent;

import org.springframework.web.context.ContextLoaderListener;

import com.ge.trans.rmd.common.vo.ResourceVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

public class RMDApplicationScopeListener extends ContextLoaderListener {

	final private RMDWebLogger rmdWebLogger = new RMDWebLogger(getClass());
	
       
	@Override
	public void contextInitialized(final ServletContextEvent event) {
		try {
			Map<String, ResourceVO> primaryNavigationDetails; //holds Primary Nav Info
			Map<String, List<ResourceVO>> navigationDetails; //holds primary Menu Name(Key), Sub Menu info 
			final ResourceVO resourcesItem = ResourceDigester
					.getResources(RESOURCE_FILE);
			primaryNavigationDetails = getPrimaryNavigationDetails(resourcesItem);
			navigationDetails = getSecondaryNavigationDetails(resourcesItem);
			event.getServletContext().setAttribute(AppConstants.PRI_NAV_MAP,
					primaryNavigationDetails);
			event.getServletContext().setAttribute(AppConstants.TAB_DETAIL_MAP,
					navigationDetails);
			
			rmdWebLogger.debug("RMDWeb Application started successfully...");
		}
		catch (Exception e) {
			rmdWebLogger.error("In RMDApplicationScopeListener : Exception occurred in contextInitialized (RMDWeb Application) "+e.getMessage());
		}
	}


	public Map<String, ResourceVO> getPrimaryNavigationDetails(final 
			ResourceVO resourcesItem) {
		final Map<String, ResourceVO> primaryNavMap = new LinkedHashMap<String, ResourceVO>();
		final List<ResourceVO> resourceItems = resourcesItem.getChildren();
		if (RMDCommonUtility.isCollectionNotEmpty(resourceItems)) {
			for (ResourceVO resourceItem : resourceItems) {
				primaryNavMap.put(resourceItem.getResourceId(), resourceItem);
			}
		}
		return primaryNavMap;
	}

	public Map<String, List<ResourceVO>> getSecondaryNavigationDetails(
			final ResourceVO resourcesItem) {
		final Map<String, List<ResourceVO>> secondaryNavMap = new LinkedHashMap<String, List<ResourceVO>>();
		final List<ResourceVO> resourceItems = resourcesItem.getChildren();
		if (RMDCommonUtility.isCollectionNotEmpty(resourceItems)) {
			for (ResourceVO resourceItem : resourceItems) {
				secondaryNavMap.put(resourceItem.getResourceId(),
						resourceItem.getChildren());
			}
		}
		return secondaryNavMap;
	}
}
