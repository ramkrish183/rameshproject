/**
 * ============================================================
 * Classification: GE Confidential
 * File : AuthorizationServI.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.service;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on : November 14, 2011
 * History
 * Modified By : iGATE
 *
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.service;

import java.util.List;

import com.ge.trans.rmd.common.beans.FavoriteFilterBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.FavoriteFilterDetailVO;


/*******************************************************************************
 * 
 * @Author : iGATE
 * @Version : 1.0
 * @Date Created: November 14, 2011
 * @Date Modified : November 14, 2011
 * @Modified By :
 * @Contact :
 * @Description : This Interface act as AuthorizationServI and provide the
 *              Authorization related funtionalities
 * @History :
 * 
 ******************************************************************************/
public interface FavoriteFilterService {

	
	void addFavoriteFilter(final FavoriteFilterBean favoriteFilterBean) throws RMDWebException,Exception;
	void deleteFavoriteFilter(final FavoriteFilterBean favoriteFilterBean) throws RMDWebException,Exception;
	List<FavoriteFilterDetailVO> fetchFavoriteFilter(FavoriteFilterBean favoriteFilterBean) throws RMDWebException,Exception;
}
