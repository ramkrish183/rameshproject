package com.ge.trans.rmd.common.service;

import com.ge.trans.rmd.common.exception.RMDWebException;

public interface CommonService {

	public String getAssetPanelParameters() throws RMDWebException;

}
