package com.ge.trans.rmd.common.mvc.model;

import java.io.Serializable;


public class UserPreferencesModel implements Serializable{
	private static final long serialVersionUID = 1L;
	private String language;
	private String timezone;
	private String rolePreference;
	private String passwordIndicator;
	private String customerId;
	private String uom;
	
	public String getUom() {
		return uom;
	}
	public void setUom(String uom) {
		this.uom = uom;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(final String customerId) {
		this.customerId = customerId;
	}
	public String getPasswordIndicator() {
		return passwordIndicator;
	}
	public void setPasswordIndicator(final String passwordIndicator) {
		this.passwordIndicator = passwordIndicator;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(final String language) {
		this.language = language;
	}
	public String getTimezone() {
		return timezone;
	}
	public void setTimezone(final String timezone) {
		this.timezone = timezone;
	}
	public String getRolePreference() {
		return rolePreference;
	}
	public void setRolePreference(final String rolePreference) {
		this.rolePreference = rolePreference;
	}
	
}
