/**
 * ============================================================
 * File : HeaderSearchController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.mvc.controller
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Mar 01, 2011
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.mvc.controller;

import java.util.Map.Entry;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedSet;
import java.util.List;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.OpenCasesService;
import com.ge.trans.rmd.common.beans.HeaderSearchBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.service.HeaderSearchService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.HeaderSearchRespVO;
import com.ge.trans.rmd.common.vo.HeaderSearchResponseVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.common.vo.CustomerVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
public class HeaderSearchController extends RMDBaseController {

	@Autowired
	private HeaderSearchService searchService;
	@Autowired
	private AuthorizationService authService;

	@Autowired
	private OpenCasesService openCasesService;

	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	/**
	 * @Author:
	 * @param
	 * @return HeaderSearchResponseVO
	 * @Description: This method will return header search result from Database
	 */

	@SuppressWarnings(AppConstants.UNCHECKED)
	@RequestMapping(value = AppConstants.REQ_URI_HEADERSEARCH, method = RequestMethod.GET)
	public @ResponseBody
	HeaderSearchRespVO getSearchData(final HttpServletRequest request)
			throws RMDWebException, Exception {
		final HttpSession session = request.getSession(false);
		String headerSearch_All = null;
		boolean isHeaderSearchAll = false;
		String headerSearch_Asset = null;
		boolean isAssetPrivilege = false;
		String headerSearch_Cases = null;
		boolean isCasesPrivilege = false;
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String searchString = request
				.getParameter(AppConstants.HEADERSEARCH_SEARCH_STRING);
		final HeaderSearchRespVO searchResponse = new HeaderSearchRespVO();
		HeaderSearchRespVO tempResponse = null;
		final HeaderSearchBean headerSearchBean = new HeaderSearchBean();
		String customerList="";
		try {
			headerSearch_All = authService
					.getLookUpValueForName(AppConstants.HEADERSEARCH_ALL);
			isHeaderSearchAll = RMDCommonUtil.componentValue(
					userVO.getComponentList(), headerSearch_All);
			headerSearch_Asset = authService
					.getLookUpValueForName(AppConstants.HEADERSEARCH_ASSETS);
			isAssetPrivilege = RMDCommonUtil.componentValue(
					userVO.getComponentList(), headerSearch_Asset);
			headerSearch_Cases = authService
					.getLookUpValueForName(AppConstants.HEADERSEARCH_CASES);

			isCasesPrivilege = RMDCommonUtil.componentValue(
					userVO.getComponentList(), headerSearch_Cases);
			headerSearchBean.setUserLanguage(userVO.getStrUserLanguage());
			headerSearchBean.setTimeZone(userVO.getTimeZone());
			headerSearchBean.setStrCustomerId(userVO.getCustomerId());
			if (userVO.getIsCMPrivilege()
					&& null != userVO.getCmAliasName()
					&&!RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(userVO
							.getCmAliasName())) {
			if (!RMDCommonUtility.isNullOrEmpty(userVO.getCustomerId())) {
				customerList = getCustomerList(userVO.getCustomerList());
				headerSearchBean.setStrCustomerId(customerList);
			}
			headerSearchBean.setGPOCUser(true);
			}
			headerSearchBean.setSearchString(searchString);
			headerSearchBean.setRequestURI(AppConstants.REQ_URI_HEADERSEARCH);
			headerSearchBean.setSearchTypeFlag(AppConstants.SEARCH_TYPE_HEADER);
			if (null != userVO.getProducts() && !userVO.getProducts().isEmpty()) {
				headerSearchBean.setProducts(userVO.getProducts());
			}
			if (isAssetPrivilege) {
				if (null != userVO.getProducts()
						&& !userVO.getProducts().isEmpty()) {
					if (RMDCommonUtility.isAlphaNumeric(searchString)) {
						tempResponse = searchService
								.getAssetsData(headerSearchBean);
					} else {
						tempResponse = new HeaderSearchRespVO();
					}
				} else if (null == userVO.getProducts()
						|| userVO.getProducts().isEmpty()) {
					searchResponse.setAssetSearchPrivilege(isAssetPrivilege);
				}
				if (tempResponse != null) {
					searchResponse.setAssetSearchPrivilege(isAssetPrivilege);
					searchResponse.setAssets(tempResponse.getAssets());
					searchResponse.setResponseLength(tempResponse
							.getResponseLength());
				}
			}
			if (isCasesPrivilege) {
				if (null != userVO.getProducts()
						&& !userVO.getProducts().isEmpty()) {
					String length=authService.getLookUpValueForName(AppConstants.HEADER_CASE_SEARCH_STRING_LENGTH);
					if (!RMDCommonUtility
							.isSpecialCharactersFound(searchString)
							&& null != searchString
							&& searchString.trim().length()==Integer.parseInt(length)) {
						tempResponse = searchService.getCasesData(headerSearchBean);
					} else {
						tempResponse = new HeaderSearchRespVO();
					}
				} else if (null == userVO.getProducts()
						|| userVO.getProducts().isEmpty()) {
					searchResponse.setAssetSearchPrivilege(isCasesPrivilege);
				}
				if (tempResponse != null) {
					searchResponse.setCaseSearchPrivilege(isCasesPrivilege);
					searchResponse.setCases(tempResponse.getCases());
					searchResponse.getResponseLength().put(
							AppConstants.CASE_RESPONSE,
							tempResponse.getResponseLength().get(
									AppConstants.CASE_RESPONSE_LENGTH));
				}
			}
			request.setAttribute(AppConstants.HEADERSEARCH_ASSETS_COMP,
					isAssetPrivilege);
			request.setAttribute(AppConstants.HEADERSEARCH_CASES_COMP,
					isCasesPrivilege);
			request.setAttribute(AppConstants.HEADERSEARCH_ALL_COMP,
					isHeaderSearchAll);
			searchResponse.setAllSearchPrivilege((Boolean) request
					.getAttribute(AppConstants.HEADERSEARCH_ALL_COMP));
		tempResponse=null;
		} catch (Exception ex) {
			logger.error("Exception occured in getSearchData method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return searchResponse;
	}

	/**
	 * @Author:
	 * @param
	 * @return HeaderSearchResponseVO
	 * @Description: This method will return header search result from Database
	 */

	@RequestMapping(value = AppConstants.REQ_URI_HEADERSEARCH_ALL, method = RequestMethod.GET)
	public ModelAndView getSearchAllData(final HttpServletRequest request)
			throws RMDWebException, Exception {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String searchString = request
				.getParameter(AppConstants.HEADERSEARCH_SEARCH_STRING);
		HeaderSearchResponseVO searchResponseVO = null;
		String headerSearch_All = null;
		boolean isHeaderSearchAll = false;
		String headerSearch_Asset = null;
		boolean isAssetPrivilege = false;
		String headerSearch_Cases = null;
		boolean isCasesPrivilege = false;
		String customerList = "";
		final HeaderSearchBean headerSearchBean = new HeaderSearchBean();

		try {
			headerSearch_All = authService
					.getLookUpValueForName(AppConstants.HEADERSEARCH_ALL);
			isHeaderSearchAll = RMDCommonUtil.componentValue(
					userVO.getComponentList(), headerSearch_All);
			headerSearch_Asset = authService
					.getLookUpValueForName(AppConstants.HEADERSEARCH_ASSETS);
			isAssetPrivilege = RMDCommonUtil.componentValue(
					userVO.getComponentList(), headerSearch_Asset);
			headerSearch_Cases = authService
					.getLookUpValueForName(AppConstants.HEADERSEARCH_CASES);

			isCasesPrivilege = RMDCommonUtil.componentValue(
					userVO.getComponentList(), headerSearch_Cases);
			headerSearchBean.setUserLanguage(userVO.getStrUserLanguage());
			headerSearchBean.setTimeZone(userVO.getTimeZone());
			headerSearchBean.setSearchString(searchString);
			headerSearchBean.setStrCustomerId(userVO.getCustomerId());
			headerSearchBean
					.setSearchTypeFlag(AppConstants.SEARCH_TYPE_HEADER_ALL);
			headerSearchBean
					.setRequestURI(AppConstants.REQ_URI_HEADERSEARCH_ALL);
			request.setAttribute(AppConstants.HEADERSEARCH_SEARCH_STRING,
					searchString);
			if (userVO.getIsCMPrivilege()
					&& null != userVO.getCmAliasName()
					&&!RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(userVO
							.getCmAliasName())) {
			if (!RMDCommonUtility.isNullOrEmpty(userVO.getCustomerId())) {
				customerList = getCustomerList(userVO.getCustomerList());
				headerSearchBean.setStrCustomerId(customerList);
			}
			/*Added by Vamshi For GPOC User Changes*/
			headerSearchBean.setGPOCUser(true);
			/*End of Changes*/
			}
			if (null != userVO.getProducts() && !userVO.getProducts().isEmpty()) {
				headerSearchBean.setProducts(userVO.getProducts());
			}
			if (isHeaderSearchAll) {
				if (null != userVO.getProducts()
						&& !userVO.getProducts().isEmpty()) {
					if (RMDCommonUtility.isAlphaNumeric(searchString)) {
						searchResponseVO = searchService
								.getAssets(headerSearchBean);
					} else {
						searchResponseVO = new HeaderSearchResponseVO();
					}

				}
				if (null != searchResponseVO) {
					request.setAttribute(AppConstants.HEADERSEARCH_VO_LST,
							searchResponseVO.getAssets());
					if (request
							.getParameter(AppConstants.HEADER_SEARCH_ASSET_LENGTH) != null
							&& !request.getParameter(
									AppConstants.HEADER_SEARCH_ASSET_LENGTH)
									.equals(AppConstants.EMPTY_STRING)) {
						request.setAttribute(
								AppConstants.HEADER_SEARCH_ASSET_LENGTH,
								request.getParameter(AppConstants.HEADER_SEARCH_ASSET_LENGTH));
					} else {
						request.setAttribute(
								AppConstants.HEADER_SEARCH_ASSET_LENGTH,
								searchResponseVO.getResponseLength().get(
										AppConstants.ASSET_RESPONSE_LENGTH));
					}
				}
				if (null != searchResponseVO) {
					if (null != userVO.getProducts()
							&& !userVO.getProducts().isEmpty()) {
						if (!RMDCommonUtility
								.isSpecialCharactersFound(searchString)
								&& null != searchString
								&& searchString.trim().length() > 0) {
							searchResponseVO = searchService
									.getCases(headerSearchBean);
						} else {
							searchResponseVO = new HeaderSearchResponseVO();
						}

					}
					request.setAttribute(AppConstants.OPENCASES_VO_LST,
							searchResponseVO.getCases());
					if (request
							.getParameter(AppConstants.HEADER_SEARCH_CASE_LENGTH) != null
							&& !request.getParameter(
									AppConstants.HEADER_SEARCH_CASE_LENGTH)
									.equals(AppConstants.EMPTY_STRING)) {
						request.setAttribute(
								AppConstants.HEADER_SEARCH_CASE_LENGTH,
								request.getParameter(AppConstants.HEADER_SEARCH_CASE_LENGTH));
					} else {
						request.setAttribute(
								AppConstants.HEADER_SEARCH_CASE_LENGTH,
								searchResponseVO.getResponseLength().get(
										AppConstants.CASE_RESPONSE_LENGTH));
					}
				}
			}

			final SortedSet<Entry<String, String>> mapDropdown = openCasesService
					.getDropDownValues();

			if (null != mapDropdown) {
				request.setAttribute(AppConstants.OPENCASES_DROPDOWN,
						mapDropdown);
			}
			request.setAttribute(AppConstants.HEADERSEARCH_ASSETS_COMP,
					isAssetPrivilege);
			request.setAttribute(AppConstants.HEADERSEARCH_CASES_COMP,
					isCasesPrivilege);
			request.setAttribute(AppConstants.HEADERSEARCH_ALL_COMP,
					isHeaderSearchAll);
			// adding for pagination - Start
			request.setAttribute(
					AppConstants.CASELIST_DEFAULT_RECORDS,
					findNumberOfRecords(AppConstants.CASELIST_TABLE_DEFAULT_RECORDS));

			request.setAttribute(
					AppConstants.ASSET_DEFAULT_RECORDS,
					findNumberOfRecords(AppConstants.ASSET_TABLE_DEFAULT_RECORDS));
			// adding for pagination - End

		} catch (Exception ex) {
			logger.error("Exception occured in getSearchAllData() method ", ex);
		}

		return new ModelAndView(AppConstants.VIEW_ALLRESULT);
	}

	
	// Added for Role based header search Ends
}