/**
 * ============================================================
 * File : RoleManagementController.java
 * Description : Web layer controller class for Role management
 * 
 * Package : com.ge.trans.rmd.common.mvc.controller
 * Author : iGATE
 * Last Edited By :
 * Version : 1.0
 * Created on : November 19, 2012
 * History :
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2012 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.trans.rmd.common.beans.PrivilegeBean;
import com.ge.trans.rmd.common.beans.RoleManagementBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.service.RoleManagementService;
import com.ge.trans.rmd.common.service.UserManagementService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.DeleteRolesExportVO;
import com.ge.trans.rmd.common.vo.DeleteRolesResponseVO;
import com.ge.trans.rmd.common.vo.DeleteRolesUpdateVO;
import com.ge.trans.rmd.common.vo.PrivilegeVO;
import com.ge.trans.rmd.common.vo.RolesVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.AppSecUtil;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

/*******************************************************************************
 * 
 * @Author : iGATE
 * @Version : 1.0
 * @Date Created:
 * @Date Modified :
 * @Modified By :
 * @Contact :
 * @Description : This is the controller class which is used for RoleManagement
 *              screen
 * @History :
 * 
 ******************************************************************************/
@Controller
public class RoleManagementController extends RMDBaseController {

	@Autowired
	private RoleManagementService roleManagementService;
	@Autowired
	private AuthorizationService authService;
	@Autowired
    private org.springframework.cache.CacheManager cacheManager;
	@Autowired
	private ApplicationContext appContext;
	@Autowired
    private UserManagementService userManagementService;

	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	/**
	 * @Author:iGATE
	 * @param request
	 * @return String
	 * @Description: method to get Role management page
	 */
	@RequestMapping(value = AppConstants.ROLE_MANAGEMENT, method = RequestMethod.GET)
	public String getRoleManagementPage(final HttpServletRequest request
			) throws Exception {
		logger.debug("role Controller : getRoleManagementPage() method Starts");
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final RoleManagementBean objRoleManagementBean = new RoleManagementBean();
		List<RolesVO> arlRolesVO = new ArrayList<RolesVO>();

		String addRoleCompName = null;
		String editRoleCompName = null;
		String copyRoleCompName = null;
		String deleteRoleCompName = null;
		boolean addComponent = false;
		boolean editComponent = false;
		boolean copyComponent = false;
		boolean deleteComponent = false;
		try {
			objRoleManagementBean.setLanguage(userVO.getStrLanguage());
			arlRolesVO = roleManagementService
					.getAllRoles(objRoleManagementBean);
			addRoleCompName = authService
					.getLookUpValueForName(AppConstants.ROLEMANAGEMENT_ADDROLE);
			editRoleCompName = authService
					.getLookUpValueForName(AppConstants.ROLEMANAGEMENT_EDITROLE);
			copyRoleCompName = authService
					.getLookUpValueForName(AppConstants.ROLEMANAGEMENT_COPYROLE);
			deleteRoleCompName = authService
					.getLookUpValueForName(AppConstants.ROLEMANAGEMENT_DELETEROLE);
			addComponent = RMDCommonUtil.componentValue(
					userVO.getComponentList(), addRoleCompName);
			editComponent = RMDCommonUtil.componentValue(
					userVO.getComponentList(), editRoleCompName);
			copyComponent = RMDCommonUtil.componentValue(
					userVO.getComponentList(), copyRoleCompName);
			deleteComponent = RMDCommonUtil.componentValue(
					userVO.getComponentList(), AppConstants.ROLEMANAGEMENT_DELETEROLE);

			request.setAttribute(AppConstants.COMPONENT_ADDROLE, addComponent);
			request.setAttribute(AppConstants.COMPONENT_EDITROLE, editComponent);
			request.setAttribute(AppConstants.COMPONENT_COPYROLE, copyComponent);
			request.setAttribute(AppConstants.COMPONENT_DELETEROLE, deleteComponent);
			request.setAttribute(AppConstants.LIST_OF_ROLES, arlRolesVO);
			request.setAttribute(
					AppConstants.ADMINISTRATOR_ROLE_DEFAULT_RECORDS,
					findNumberOfRecords(AppConstants.ADMINISTRATOR_ROLES_TABLE_DEFAULT_RECORDS));
		} catch (Exception ex) {
			logger.error("Exception occured in getRoleManagementPage method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return AppConstants.ROLE_MANAGEMENT;

	}

	/**
	 * @Author:iGATE
	 * @param roleId
	 * @return List<PrivilegeVO>
	 * @Description: method to get all the privileges.
	 */
	@RequestMapping(value = AppConstants.GET_ALL_PRIVILEGES, method = RequestMethod.GET)
	public @ResponseBody
	List<PrivilegeVO> getAllPrivileges(
			@RequestParam(value = AppConstants.ROLE_ID, required = true) final String roleId)
			throws Exception {
		logger.debug("role Controller : getAllPrivileges() method Starts");
		List<PrivilegeVO> arlPrivilegeVO = new ArrayList<PrivilegeVO>();
		try {

			arlPrivilegeVO = roleManagementService
					.getAllPrivileges(roleId);

		} catch (Exception ex) {
			logger.error("Exception occured in getAllPrivileges method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return arlPrivilegeVO;

	}

	/**
	 * @Author:iGATE
	 * @param roleId
	 *            ,roleName,roleDesc,privileges,isRoleNameChanged
	 * @return List<RoleManagementBean>
	 * @Description: method to edit the roles
	 */
	@RequestMapping(value = AppConstants.EDIT_ROLE, method = RequestMethod.POST)
	public @ResponseBody
	java.util.List<RoleManagementBean> editRole(
			@RequestParam(value = AppConstants.ROLE_ID) final String roleId,
			@RequestParam(value = AppConstants.ROLE_NAME) final String roleName,
			@RequestParam(value = AppConstants.ROLE_DESC) final String roleDesc,
			@RequestParam(value = AppConstants.PRIVILEGES, required = true) final String privileges,
			@RequestParam(value = AppConstants.IS_ROLE_CHANGED, required = true) final String isRoleNameChanged,
			@RequestParam(value = AppConstants.IS_ROLEDESC_CHANGED, required = true) final String isRoleDescChanged,
			final HttpServletRequest request) throws Exception {
		logger.debug("role Controller : editRole() method Starts");
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		List<RoleManagementBean> arlRoleManagementBean = new ArrayList<RoleManagementBean>();
		try {

			RoleManagementBean objRoleManagementBean = new RoleManagementBean();
			List<PrivilegeBean> arlPrivilegeBean = new ArrayList<PrivilegeBean>();
			objRoleManagementBean.setRoleDescription(EsapiUtil.stripXSSCharacters(roleDesc));
			objRoleManagementBean.setRoleName(EsapiUtil.stripXSSCharacters(roleName));
			objRoleManagementBean.setRoleId(EsapiUtil.stripXSSCharacters(roleId));
			objRoleManagementBean.setUserId(EsapiUtil.stripXSSCharacters(userVO.getUserId()));
			final Map<String, String> validateUserInput = validateUserInput(
					objRoleManagementBean, EsapiUtil.stripXSSCharacters(privileges));
			if (null != validateUserInput && !validateUserInput.isEmpty()) {

				final RoleManagementBean roleManagementBean = new RoleManagementBean();
				roleManagementBean.setErrorMsg(validateUserInput);
				arlRoleManagementBean.add(roleManagementBean);

			} else {
				if (!isRoleNameChanged.equalsIgnoreCase(AppConstants.STR_TRUE)) {
					
					objRoleManagementBean
							.setRoleName(AppConstants.EMPTY_STRING);
				}
				
               if (!isRoleDescChanged.equalsIgnoreCase(AppConstants.STR_TRUE)) {
					
					objRoleManagementBean
							.setRoleDescription(AppConstants.EMPTY_STRING);
				}
				arlPrivilegeBean = getPrivilegeDetails(privileges);
				objRoleManagementBean.setPrivileges(arlPrivilegeBean);
				roleManagementService.editRole(objRoleManagementBean);
				cacheManager.getCache(AppConstants.ROLE_PRIVILEGE_CACHE).clear();
			}

		} catch (Exception ex) {
			logger.error("Exception occured in editRole method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		logger.debug("role Controller : editRole() method Starts");
		return arlRoleManagementBean;

	}
	/* added by venkatesh*/
	
	@RequestMapping(value = AppConstants.DELETE_ROLE, method = RequestMethod.POST)
	public @ResponseBody
	Boolean deleteRole(@RequestParam(value = AppConstants.ROLE_ID) final String roleId,final HttpServletRequest request) throws Exception {
		logger.debug("role Controller : deleteRole() method Starts");
		//System.out.println(roleId);
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		//List<RoleManagementBean> arlRoleManagementBean = new ArrayList<RoleManagementBean>();
		try {

			RoleManagementBean objRoleManagementBean = new RoleManagementBean();
			objRoleManagementBean.setRoleId(EsapiUtil.stripXSSCharacters(roleId));
			objRoleManagementBean.setUserId(EsapiUtil.stripXSSCharacters(userVO.getUserId()));
			roleManagementService.deleteRole(objRoleManagementBean);
			
		} catch (Exception ex) {
			logger.error("Exception occured in deleteRole method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("role Controller : deleteRole() method ends");
		
	return true;}
	
	
	/*
	 * @Description: Function to clear ehcache
	 */
	@RequestMapping(value = AppConstants.CLEAR_CACHE, method = RequestMethod.GET)
	public @ResponseBody String clearCache(@RequestParam(value = AppConstants.NAME, required = true) final String cacheName) throws GenericAjaxException, RMDWebException{
		try{
			cacheManager.getCache(cacheName).clear();
		}catch (Exception ex) {
			logger.error("Exception occured in clearCache method ", ex);
			return AppConstants.CLEARING_FAILED;
		}
		return AppConstants.CLEARED_CACHE;
	}
	
	
	
	/**
	 * @Author:iGATE
	 * @param roleName
	 *            ,roleDesc,privileges
	 * @return List<RoleManagementBean>
	 * @Description: method to add new roles
	 */
	@RequestMapping(value = AppConstants.ADD_COPY_ROLE, method = RequestMethod.POST)
	public @ResponseBody
	java.util.List<RoleManagementBean> addOrCopyRole(
			@RequestParam(value = AppConstants.ROLE_NAME, required = true) final String roleName,
			@RequestParam(value = AppConstants.ROLE_DESC, required = true) final String roleDesc,
			@RequestParam(value = AppConstants.PRIVILEGES, required = true) final String privileges,
			final HttpServletRequest request) throws Exception {
		logger.debug("role Controller : addRole() method Starts");
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		List<RoleManagementBean> arlRoleManagementBean = new ArrayList<RoleManagementBean>();
		try {

			RoleManagementBean objRoleManagementBean = new RoleManagementBean();
			List<PrivilegeBean> arlPrivilegeBean = new ArrayList<PrivilegeBean>();
			objRoleManagementBean.setRoleDescription(EsapiUtil.stripXSSCharacters(roleDesc));
			objRoleManagementBean.setRoleName(EsapiUtil.stripXSSCharacters(roleName));
			objRoleManagementBean.setUserId(EsapiUtil.stripXSSCharacters(userVO.getUserId()));
			final Map<String, String> validateUserInput = validateUserInput(
					objRoleManagementBean, EsapiUtil.stripXSSCharacters(privileges));
			if (null != validateUserInput && !validateUserInput.isEmpty()) {

				final RoleManagementBean roleManagementBean = new RoleManagementBean();
				roleManagementBean.setErrorMsg(validateUserInput);
				arlRoleManagementBean.add(roleManagementBean);

			} else {
				arlPrivilegeBean = getPrivilegeDetails(EsapiUtil.stripXSSCharacters(privileges));
				objRoleManagementBean.setPrivileges(arlPrivilegeBean);
				roleManagementService.addOrCopyRole(objRoleManagementBean);
			}

		} catch (Exception ex) {
			logger.error("Exception occured in addRole method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		logger.debug("role Controller : addRole() method Starts");
		return arlRoleManagementBean;

	}

	/**
	 * @Author:iGATE
	 * @param privileges
	 * @return List<RoleManagementBean>
	 * @Description: This method is used for converting the
	 *               PrivilegeDetails(PrivilegeId and SortOrder) to list which
	 *               is sent as string from front end with delimiter as '~'
	 *               symbol.
	 * 
	 */

	public List<PrivilegeBean> getPrivilegeDetails(String privileges)
			throws Exception {
		logger.debug("role Controller : getPrivilegeDetails() method Starts");
		PrivilegeBean objBean = null;
		Map<String, Integer> hmlevel = new HashMap<String, Integer>();
		List<PrivilegeBean> arlPrivilegeBean = new ArrayList<PrivilegeBean>();
		try {
			String[] strPrivilege = privileges.split(AppConstants.COMMA);
			for (int i = 0; i < strPrivilege.length; i++) {
				String privilegeAndSortOrder = strPrivilege[i];
				String[] arr = privilegeAndSortOrder
						.split(AppConstants.NEGOTION_SYMBOL);
				for (int j = 0; j < arr.length; j = j + 3) {
					objBean = new PrivilegeBean();
					if (hmlevel.containsKey(arr[j])) {
						if (arr[j].equalsIgnoreCase(AppConstants.LEVEL_1)) {
							int level = hmlevel.get(arr[j]);
							hmlevel.clear();
							hmlevel.put(arr[j], ++level);
							objBean.setPrivilegeId(arr[j + 1]);
							objBean.setSortOrder(String.valueOf(level));

						} else {
							int level = hmlevel.get(arr[j]);
							hmlevel.put(arr[j], ++level);
							objBean.setPrivilegeId(arr[j + 1]);
							objBean.setSortOrder(String.valueOf(level));
						}
					} else {
						hmlevel.put(arr[j], 1);
						objBean.setPrivilegeId(arr[j + 1]);
						objBean.setSortOrder(RMDCommonConstants.ONE_STRING);
					}
					arlPrivilegeBean.add(objBean);
				}
			}
		} catch (Exception e) {
			logger.error("Exception occured in getPrivilegeDetails method ", e);
			throw e;
		}
		return arlPrivilegeBean;
	}

	/**
	 * @Author:iGATE
	 * @param objRoleManagementBean
	 *            ,privileges
	 * @return Map<String,String>
	 * @throws
	 * @Description * This method is used for Validating user input for add/edit
	 *              roles.
	 */

	public Map<String, String> validateUserInput(
			final RoleManagementBean objRoleManagementBean,
			final String privilges) {
		final Map<String, String> result = new HashMap<String, String>();

		try {

			if (null == objRoleManagementBean.getRoleDescription()
					|| objRoleManagementBean.getRoleDescription().isEmpty()) {
				result.put(AppConstants.ROLE_DESC, AppConstants.INVALID);
			}
			if (RMDCommonUtility.isSpecialCharactersFound(objRoleManagementBean
					.getRoleDescription())) {
				result.put(AppConstants.ROLE_DESC,
						AppConstants.SPECIAL_CHARACTER_FOUND);
			}
			if (objRoleManagementBean.getRoleName().isEmpty()) {
				result.put(AppConstants.ROLE_NAME, AppConstants.INVALID);
			} else if(!AppSecUtil
					.checkAlphaNumericUnderscore(objRoleManagementBean
							.getRoleName())){
				result.put(AppConstants.ROLE_NAME, AppConstants.INVALID_SPECIAL_CHARACTER);
			}

			if (privilges.isEmpty()) {
				result.put(AppConstants.PRIVILEGES, AppConstants.INVALID);
			}

		} catch (Exception exception) {
			logger.error("Error occured in validateUserInput"
					+ exception.getMessage());
		}
		return result;
	}

	/**
	 * @Description:This method is used to  export the Roles list from the Roles page
	 * @return: void
	 * @param:HttpServletRequest request,HttpServletResponse response,Locale
	 *                           locale
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 */
	@RequestMapping(value = AppConstants.EXPORT_ROLES, method = RequestMethod.POST)
	public void exportRoleManagementPage(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws IOException, GenericAjaxException, RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final RoleManagementBean objRoleManagementBean = new RoleManagementBean();
		List<RolesVO> arlRolesVO = new ArrayList<RolesVO>();

		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;

		try {
			objRoleManagementBean.setLanguage(userVO.getStrLanguage());
			arlRolesVO = roleManagementService
					.getAllRoles(objRoleManagementBean);
			csvContent = convertToCSVRoles(arlRolesVO, locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.ROLE_MANAGEMENT_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);

			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);

			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (Exception ex) {
			logger.error("Exception occured in getLifeStatisticsData method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}

	/**
	 * @Description:This method is used convert Role management List into csv format
	 * @return: String
	 * @param:List<RolesVO> arlRolesVO, Locale locale
	 */
	private String convertToCSVRoles(List<RolesVO> arlRolesVO, Locale locale) {
		String csvContent = null;
		StringBuffer strBufferAssetHeader = new StringBuffer();
		try {
			strBufferAssetHeader.append(appContext.getMessage(
					AppConstants.ROLE_MANAGEMENT_HEADER, null, locale));
			strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			for (RolesVO rolesList : arlRolesVO) {
				if (null != rolesList.getRoleName()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getRoleName() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != rolesList.getRoleDesc()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getRoleDesc() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != rolesList.getLastUpdatedBy()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getLastUpdatedBy() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != rolesList.getLastUpdatedTime()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getLastUpdatedTime() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				strBufferAssetHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE + rolesList.getStatus()
						+ AppConstants.QUOTE);

				strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBufferAssetHeader.toString();
		} catch (Exception exception) {
			logger.error("Export to CSV Role Management"
					+ exception.getMessage());
		}
		return csvContent;
	}
	

@RequestMapping(value = AppConstants.REQ_URI_GET_DELETE_ROLE_LIST, method = RequestMethod.GET)
	public @ResponseBody List<DeleteRolesResponseVO> getDeleteRoleList(@RequestParam(value = AppConstants.ROLE_ID) final String roleId,final HttpServletRequest request) throws RMDWebException {
		
		logger.debug("Inside getDeleteRoleList method");

		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		List<DeleteRolesResponseVO> DeleteRolesResponseVO = new ArrayList<DeleteRolesResponseVO>();
		try{
		RoleManagementBean objRoleManagementBean = new RoleManagementBean();
		objRoleManagementBean.setRoleId(EsapiUtil.stripXSSCharacters(roleId));
		objRoleManagementBean.setUserId(EsapiUtil.stripXSSCharacters(userVO.getUserId()));
		DeleteRolesResponseVO = roleManagementService.getDeleteRoleList(objRoleManagementBean);
		
		logger.debug("Inputis : "+roleId);
		} catch (RMDWebException ex) {
			logger.debug(
					"RMDWebException occured in getDeleteRoleList  method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			logger.debug(
					"Exception occured in getDeleteRoleList  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return DeleteRolesResponseVO;
	}
	
	@RequestMapping(value = AppConstants.REQ_URI_GET_DELETE_ROLE_UPDATE, method = RequestMethod.POST)
	public @ResponseBody String deleteRoleUpdateList(@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString, 
			final HttpServletRequest request) throws RMDWebException {
		
		final ObjectMapper mapper = new ObjectMapper();
		logger.debug("Inside deleteRoleUpdateList method");
		//Boolean result = true;
		Map<String,String> rolesMap=null;
		String result=RMDCommonConstants.EMPTY_STRING;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try{
			
			DeleteRolesUpdateVO[] delRolUpdTempList = mapper.readValue(
					EsapiUtil.stripXSSCharacters(parameterString), DeleteRolesUpdateVO[].class);
			List<DeleteRolesUpdateVO> tempList = Arrays.asList(delRolUpdTempList);
			
			if(RMDCommonUtility.isCollectionNotEmpty(tempList)){
			    rolesMap=new LinkedHashMap<String, String>(tempList.size());
			    for(DeleteRolesUpdateVO rolesVO : tempList){
			        if(rolesMap.get(rolesVO.getChangedRoleId())==null)
			            rolesMap.put(rolesVO.getChangedRoleId(), rolesVO.getChangedRoleName());
	            }
			}
			
			List<RolesVO> roleList = userManagementService.getCaseMgmtRoles();
        
            for (RolesVO role : roleList) {
                if(rolesMap.containsKey(role.getGetUsrRolesSeqId().toString())){
                    result=result+RMDCommonConstants.DOUBLE_QTE+role.getRoleName()+RMDCommonConstants.DOUBLE_QTE+RMDCommonConstants.COMMMA_SEPARATOR;
                }                   
            }
            if(RMDCommonUtility.isNullOrEmpty(result)){
                roleManagementService.deleteRoleUpdateList(tempList, userVO.getUserId());
                result=RMDCommonConstants.SUCCESS;
            }else{
                result=result.substring(0, result.length()-1);
            }
			
		} catch (RMDWebException ex) {
		 	result = RMDCommonConstants.FAILURE;
			logger.error("RMDWebException occured in deleteRoleUpdateList  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			result = RMDCommonConstants.FAILURE;;
			logger.error("Exception occured in deleteRoleUpdateList  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}
		
	
	
@RequestMapping(value = AppConstants.EXPORT_DELETE_ROLES, method = RequestMethod.POST)
	public void exportDeleteRoleManagementPage(@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString,final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws IOException, GenericAjaxException, RMDWebException {
		
		List<DeleteRolesExportVO> tempList = new ArrayList<DeleteRolesExportVO>();
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		
		final ObjectMapper mapper = new ObjectMapper();
		logger.debug("Inside exportDeleteRoleManagementPage method");
		try {
			DeleteRolesExportVO[] delRolUpdTempList = mapper.readValue(
					EsapiUtil.stripXSSCharacters(parameterString), DeleteRolesExportVO[].class);
			tempList = Arrays.asList(delRolUpdTempList);
			csvContent = convertToCSVDeleteRoles(tempList, locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.ROLE_MANAGEMENT_DELETE_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);

			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);

			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (Exception ex) {
			logger.error("Exception occured in exportDeleteRoleManagementPage method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}
	
	private String convertToCSVDeleteRoles(List<DeleteRolesExportVO> tempList, Locale locale) {
		String csvContent = null;
		StringBuffer strBufferAssetHeader = new StringBuffer();
		try {
			strBufferAssetHeader.append(appContext.getMessage(
					AppConstants.ROLE_MANAGEMENT_DELETE_HEADER, null, locale));
			strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			for (DeleteRolesExportVO rolesList : tempList) {
				if (null != rolesList.getUserId()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getUserId() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != rolesList.getFirstName()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getFirstName() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != rolesList.getLastName()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getLastName() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != rolesList.getUserCustomers()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getUserCustomers() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != rolesList.getCurrentRole()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getCurrentRole() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != rolesList.getChangeRoleTo()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rolesList.getChangeRoleTo() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				
				strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBufferAssetHeader.toString();
		} catch (Exception exception) {
			logger.error("Export to CSV delete Role Management"
					+ exception.getMessage());
		}
		return csvContent;
	}




}
