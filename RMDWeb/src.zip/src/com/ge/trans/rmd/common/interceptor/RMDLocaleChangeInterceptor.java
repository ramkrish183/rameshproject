/**
 * ============================================================
 * File : RMDLocaleChangeInterceptor.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.interceptor
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Dec 02, 2011
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.interceptor;

import static com.ge.trans.rmd.common.util.AppConstants.ATTR_USER_OBJECT;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.util.StringUtils;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.i18n.LocaleChangeInterceptor;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.vo.UserVO;

/*******************************************************************************
 *
 * @Author 		: iGATE Patni
 * @Version 	: 1.0
 * @Date Created: Dec 02, 2011
 * @Date Modified : 
 * @Modified By : 
 * @Contact 	:
 * @Description : This class get the user preferred language for the logged in user
 *                from the session and changes the locale based on the user preferred 
 *                language.
 *
 * @History		:
 *
 ******************************************************************************/
public class RMDLocaleChangeInterceptor extends LocaleChangeInterceptor {

	/**
	 * Default name of the locale specification attribute: "userPreferredLanguage".
	 */
	public static final String DEFUALT_USER_PREFFERED_LANG = "userPreferredLanguage";
	private String attributeName = DEFUALT_USER_PREFFERED_LANG;
	
	/**
	 * Return the name of the attribute that contains a locale specification
	 * in a locale change session.
	 */
	public String getAttributeName() {
		return attributeName;
	}

	/**
	 * Set the name of the attribute that contains a locale specification
	 * in a locale change session. Default is "locale".
	 */
	public void setAttributeName(final String attributeName) {
		this.attributeName = attributeName;
	}

	@Override
	public void postHandle(final HttpServletRequest request,
			final HttpServletResponse response, final Object handler,
			final ModelAndView modelAndView)
			throws ServletException,Exception {
		final HttpSession session = request.getSession(false);

		if (session != null) {
			final UserVO userVO = (UserVO) session
					.getAttribute(ATTR_USER_OBJECT);
	
			if (userVO != null) {
				 String newLocale = userVO.getStrUserLanguage();
	
				final LocaleResolver localeResolver = RequestContextUtils
						.getLocaleResolver(request);
				if (localeResolver == null) {
					throw new IllegalStateException(
							"No LocaleResolver found: not in a DispatcherServlet request?");
				}
		        if(newLocale==null)
		        		newLocale=AppConstants.LANG;
				localeResolver.setLocale(request, response,
						StringUtils.parseLocaleString(newLocale));
			}
			super.postHandle(request, response, handler, modelAndView);
		}
		// Proceed in any case.
	}
}
