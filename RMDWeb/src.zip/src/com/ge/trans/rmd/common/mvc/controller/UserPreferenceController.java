/**
 * ============================================================
 * File : UserPreferenceController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.mvc.controller
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Nov 30, 2011
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.mvc.controller;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedSet;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ge.trans.rmd.common.beans.UserPreferenceBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.model.UserPreferencesModel;
import com.ge.trans.rmd.common.service.UserPreferenceService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.RolesVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.AppSecUtil;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;

@Controller
@SessionAttributes({AppConstants.ATTR_LANGUAGES_MAP,
	AppConstants.ATTR_TIMEZONE_MAP, AppConstants.ATTR_ROLE_LIST})
	@RequestMapping(AppConstants.REQ_URI_MYPREFERENCES)
	public class UserPreferenceController extends RMDBaseController {

	@Autowired
	private UserPreferenceService userPreferenceService;


	@Autowired
	private ServletContext context;

	final private RMDWebLogger rmdWebLogger = RMDWebLogger.getLogger(getClass());

	@SuppressWarnings(AppConstants.UNCHECKED)
	@RequestMapping(method = RequestMethod.POST)
	public @ResponseBody
	Map<String,String> saveUser(@ModelAttribute(AppConstants.ATTR_PREFERENCE_MODEL) final  UserPreferencesModel preferenceModel,final HttpServletRequest request)
			throws RMDWebException, Exception {
		    rmdWebLogger.debug("saveUser():START ");
	        Map<String,String> resultStr=null;
		try {
			
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO)session.getAttribute(AppConstants.ATTR_USER_OBJECT);

			final UserPreferenceBean userPreferenceBean  = new UserPreferenceBean();
			userPreferenceBean.setUsrUsersSeqId(userVO.getUsrUsersSeqId());
			if (null != preferenceModel.getLanguage()
					&& !preferenceModel.getLanguage().isEmpty()) {
				userPreferenceBean.setLanguage(preferenceModel.getLanguage());
			}else{
				userPreferenceBean.setLanguage(userVO.getStrLanguage());
			}
			if (null != preferenceModel.getTimezone()
					&& !preferenceModel.getTimezone().isEmpty()) {
				userPreferenceBean.setTimeZone(preferenceModel.getTimezone());
			}else{
				userPreferenceBean.setTimeZone(userVO.getTimeZoneCode());
			}
			if (null != preferenceModel.getRolePreference()
					&& !preferenceModel.getRolePreference().isEmpty()) {
				userPreferenceBean.setRole(preferenceModel.getRolePreference());				
			}else{
				userPreferenceBean.setRole(userVO.getRoleId().toString());
			}
			
			if (null != preferenceModel.getUom()
					&& !preferenceModel.getUom().isEmpty()) {
				userPreferenceBean.setUom(preferenceModel.getUom());
			}else{
				userPreferenceBean.setUom(userVO.getDefaultUOM());
			}

			userPreferenceBean.setUserPrefMap((Map<Long, String>)session.getAttribute(AppConstants.ATTR_USER_PREFERENCE_MAP_LIST));
			if(null != preferenceModel.getCustomerId() && preferenceModel.getCustomerId().equals(RMDCommonConstants.ALL_CUSTOMER)){
				userPreferenceBean.setCustomerId(null);
			}else if(null == preferenceModel.getCustomerId()){
				userPreferenceBean.setCustomerId(userVO.getCustomerId());
			}else{
				userPreferenceBean.setCustomerId(preferenceModel.getCustomerId());
				userVO.setDefaultCustomer(preferenceModel.getCustomerId());
			}			

			final	Map<String,String> result = validateUserPreferenceBean(userPreferenceBean,session);
			if(!result.isEmpty() && null != result){
				return result;
			}else{
				resultStr = new HashMap<String, String>(); 
				final UserPreferenceBean resultUserPreferenceBean = userPreferenceService.saveUserPreference(userPreferenceBean);

				//------------ For setting default values in dropdown ------------
				if (preferenceModel.getLanguage() != null) {
					request.setAttribute(AppConstants.LANGUAGE_STRING, preferenceModel.getLanguage());
				}
				if (preferenceModel.getTimezone() != null) {
					request.setAttribute(AppConstants.TIMEZONE_STRING, preferenceModel.getTimezone());
				}
				if (preferenceModel.getRolePreference() != null) {
					request.setAttribute(AppConstants.ROLE_STRING, preferenceModel.getRolePreference() );
					userVO.setDefaultRoleId(Long.valueOf(preferenceModel.getRolePreference()));
				}

				request.setAttribute(AppConstants.ATTR_DISPLAY_MSG,userPreferenceBean.getMessage());
				resultStr.put(AppConstants.MESSAGE,  resultUserPreferenceBean.getResult());				
				rmdWebLogger.debug("saveUser():END"+resultUserPreferenceBean.getResult());
				return resultStr;
			}
		}catch (Exception ex) {
			rmdWebLogger.error("Exception occured in saveUser method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return resultStr;
		 
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private Map<String, String> validateUserPreferenceBean(
			final UserPreferenceBean userPreferenceBean,
			final HttpSession session) {
		final Map<String, String> result = new HashMap<String, String>();

		// for default Language
		final SortedSet<Entry<String, String>> langMap = (SortedSet<Entry<String, String>>) context
				.getAttribute(AppConstants.ATTR_LANGUAGES_MAP);

		final	List langList = new ArrayList();
		final	List selectedLang = new ArrayList();
		final	List timeZineLst = new ArrayList();
		final	List selectedZone = new ArrayList();
		final	List roleList = new ArrayList();
		
		//for language validation
		if (null != userPreferenceBean.getLanguage()
				&& !userPreferenceBean.getLanguage().isEmpty()){
			selectedLang.add(userPreferenceBean.getLanguage());

			final Iterator it = langMap.iterator();
			while(it.hasNext()){
				Map.Entry me = (Map.Entry)it.next(); 
				langList.add(me.getKey());
			}

			if(!AppSecUtil.compareLists(langList,selectedLang)){
				result.put(AppConstants.STRLANG, AppConstants.INVALID);
			}
		}
		

		// for timezone validation
		if(null != userPreferenceBean.getTimeZone()){
			final SortedSet<Entry<String, String>> timeZoneMap = (SortedSet<Entry<String, String>>) context
					.getAttribute(AppConstants.ATTR_TIMEZONE_MAP);
			final Iterator time = timeZoneMap.iterator();
			while(time.hasNext()){
				Map.Entry me = (Map.Entry)time.next(); 
				timeZineLst.add(me.getKey());
			}
			selectedZone.add(userPreferenceBean.getTimeZone());

			if(!AppSecUtil.compareLists(timeZineLst,selectedZone)){
				result.put(AppConstants.ATTR_TIME_ZONE, AppConstants.INVALID);
			}
		}
		

		// for role validation
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final List<RolesVO> rolesVOLst = userVO.getRolesVOLst();

		for(RolesVO role:rolesVOLst){
			roleList.add(String.valueOf(role.getGetUsrRolesSeqId()));
		}
		if (null != userPreferenceBean.getRole()
				&& !userPreferenceBean.getRole().isEmpty()) {
			final String selectedRole = userPreferenceBean.getRole();

			if (!roleList.contains(selectedRole)) {
				result.put(AppConstants.ROLE_ID, AppConstants.INVALID);
			}
		}
		
		// for customerId validation
		if (null != userPreferenceBean.getCustomerId()
				&& !userPreferenceBean.getCustomerId().isEmpty()) {
			if(!AppSecUtil.checkAlphaNumeric(userPreferenceBean.getCustomerId())){
				result.put(AppConstants.CUSTOMER_ID, AppConstants.INVALID);
			}
		}
		return result;
	}
}