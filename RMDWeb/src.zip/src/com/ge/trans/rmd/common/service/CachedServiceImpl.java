package com.ge.trans.rmd.common.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.ge.trans.pp.services.assets.valueobjects.MetricsResponseType;
import com.ge.trans.pp.services.manageGeofence.valueobjects.NotifyFlagsResponseType;
import com.ge.trans.pp.services.manageGeofence.valueobjects.StateProvinceResponseType;
import com.ge.trans.pp.services.manageGeofence.valueobjects.ThresholdResponseType;
import com.ge.trans.pp.services.notification.valueobjects.RoadInitialType;
import com.ge.trans.pp.services.proximity.valueobjects.CityType;
import com.ge.trans.pp.services.proximity.valueobjects.CountryType;
import com.ge.trans.pp.services.proximity.valueobjects.StateType;
import com.ge.trans.rmd.alert.valueobjects.ModelVO;
import com.ge.trans.rmd.alert.valueobjects.RestrictedAlertShopVO;
import com.ge.trans.rmd.alert.valueobjects.ShopsVO;
import com.ge.trans.rmd.common.beans.RMDBaseBean;
import com.ge.trans.rmd.common.beans.UserLoginBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.AuthenticationException;
import com.ge.trans.rmd.common.exception.AuthorizationException;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.pp.beans.MetricsBean;
import com.ge.trans.rmd.pp.valueobjects.CityRequestVO;
import com.ge.trans.rmd.pp.valueobjects.CityVO;
import com.ge.trans.rmd.pp.valueobjects.CustLookupVO;
import com.ge.trans.rmd.pp.valueobjects.FleetVO;
import com.ge.trans.rmd.pp.valueobjects.RegionVO;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.admin.valueobjects.SystemParamResponseType;
import com.ge.trans.rmd.services.admin.valueobjects.SystemTimeZoneResponseType;
import com.ge.trans.rmd.services.alert.valueobjects.ModelsResponseType;
import com.ge.trans.rmd.services.alert.valueobjects.RestrictedAlertShopRespType;
import com.ge.trans.rmd.services.alert.valueobjects.ShopsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ControllerResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.CreatorResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.CtrlCfgResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.Customer;
import com.ge.trans.rmd.services.assets.valueobjects.FleetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.RegionResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ReportsListWrapper;
import com.ge.trans.rmd.services.assets.valueobjects.ReportsRxRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.ReportsTruckParamListResponseType;
import com.ge.trans.rmd.services.authorization.valueobjects.RolePrivilegesType;
import com.ge.trans.rmd.services.faultstrategy.valueobjects.FaultCodesResponseType;
import com.ge.trans.rmd.services.solutions.valueobjects.CustLookupResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class CachedServiceImpl implements CachedService {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private WebServiceInvoker rsInvoker;

	@Cacheable(value = { "RMDRoleSecNavCache" }, key = "#userBean.userVO.roleId")
	public List<RolePrivilegesType> authorizeSecNav(UserLoginBean userBean)
			throws RMDWebException, Exception {
		rmdWebLogger.info("Cache: RMDRoleSecNavCache");
		RolePrivilegesType[] rolePrivList = null;
		final List<RolePrivilegesType> rolePrevTypeSec = new ArrayList<RolePrivilegesType>();
		try {
			final Map<String, String> qParamLogin = new LinkedHashMap<String, String>();
			qParamLogin.put(AppConstants.ROLE_ID,
					String.valueOf(userBean.getUserVO().getRoleId()));

			final Map<String, String> headerParams = getHeaderMap(userBean);

			rolePrivList = (RolePrivilegesType[]) rsInvoker
					.get(ServiceConstants.SECURITY_SERVICE_GET_ROLE_SEC_NAV_PRIVILAGES,
							qParamLogin, null, headerParams,
							RolePrivilegesType[].class);

			if (rolePrivList != null && rolePrivList.length > 0) {
				for (RolePrivilegesType rPL : rolePrivList) {
					rolePrevTypeSec.add(rPL);
				}
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in authorizeSecNav() method ",
					rmdEx);
			if (!AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(rmdEx
					.getStatus())) {
				throw rmdEx;
			}
		} catch (Exception exp) {
			rmdWebLogger.error(
					"Exception occured in authorizeSecNav() method ", exp);
			throw exp;
		}
		return rolePrevTypeSec;
	}

	@Cacheable({ "RMDlookUpCache" })
	public Map<String, List<ApplicationParametersResponseType>> getAllLookupValues()
			throws GenericAjaxException, RMDWebException {
		rmdWebLogger.info("Cache: RMDlookUpCache");
		Map<String, List<ApplicationParametersResponseType>> lookupValueMap = new HashMap<String, List<ApplicationParametersResponseType>>();
		try {
			ApplicationParametersResponseType[] applParamResponseType = (ApplicationParametersResponseType[]) rsInvoker
					.get(ServiceConstants.GET_LOOKUP_VALUES_SERVICE, null, null, null, ApplicationParametersResponseType[].class);

			for (int i = 0; i < applParamResponseType.length; i++) {
				List<ApplicationParametersResponseType> lookupList = null;
				if (lookupValueMap.get(applParamResponseType[i].getListName()) != null)
					lookupList = (List) lookupValueMap.get(applParamResponseType[i].getListName());
				else {
					lookupList = new ArrayList<ApplicationParametersResponseType>();
				}
				lookupList.add(applParamResponseType[i]);
				lookupValueMap.put(applParamResponseType[i].getListName(), lookupList);
			}
		} catch (Exception ex) {
			this.rmdWebLogger.error("Exception occured in getLookUpValueForName method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lookupValueMap;
	}
	
	@Cacheable({ "UrgencyOfRepairCache" })
	public Map<String, List<ApplicationParametersResponseType>> getCustomerBasedLookupValues(String customerId)
			throws GenericAjaxException, RMDWebException {
		rmdWebLogger.info("Cache: RMDUrgencyOfRepairCache");
		Map<String, List<ApplicationParametersResponseType>> lookupValueMap = new HashMap<String, List<ApplicationParametersResponseType>>();
		final Map<String, String> queryParamsMap = new HashMap<String, String>();
		try {
			queryParamsMap.put(AppConstants.CUSTOMER_ID, customerId);
			ApplicationParametersResponseType[] applParamResponseType = (ApplicationParametersResponseType[]) rsInvoker
					.get(ServiceConstants.GET_CUSTOMER_BASED_LOOKUP_VALUES_SERVICE, null,
							queryParamsMap, null,
							ApplicationParametersResponseType[].class);

			for (int i = 0; i < applParamResponseType.length; i++) {
				List<ApplicationParametersResponseType> lookupList = null;
				if (lookupValueMap.get(applParamResponseType[i].getUrgency()) != null)
				{
					lookupList = (List) lookupValueMap
							.get(applParamResponseType[i].getUrgency());
				}
				else {
					lookupList = new ArrayList<ApplicationParametersResponseType>();
				}
				
				
				lookupList.add(applParamResponseType[i]);
				lookupValueMap.put(applParamResponseType[i].getUrgency(),
						lookupList);
			}
		} catch (Exception ex) {
			this.rmdWebLogger.error(
					"Exception occured in getLookUpValueForName method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lookupValueMap;
	}

	@Cacheable({ "RMDTimeZoneCache" })
	public Map<String, SystemTimeZoneResponseType> getAllTimeZones()
			throws RMDWebException, Exception {
		rmdWebLogger.info("Cache: RMDTimeZoneCache");
		SystemTimeZoneResponseType[] systemTimezones = null;
		Map<String, SystemTimeZoneResponseType> timeZone = new HashMap<String, SystemTimeZoneResponseType>();
		try {
			systemTimezones = (SystemTimeZoneResponseType[]) this.rsInvoker
					.get(ServiceConstants.ADMIN_SERVICE_GET_SYSTEM_TIME_ZONES,
							null, null, null,
							SystemTimeZoneResponseType[].class);

			for (int i = 0; i < systemTimezones.length; i++) {
				//Added for Aurizon - AEDT Option is not there in user preferences dropdown - James Starts
				/*timeZone.put(systemTimezones[i].getTimeZoneId(),
						systemTimezones[i]);*/
				timeZone.put(systemTimezones[i].getName(),
						systemTimezones[i]);
				//Added for Aurizon - AEDT Option is not there in user preferences dropdown - James Ends
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getTimezone() method ", rmdEx);
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(rmdEx
					.getMessage())) {
				throw new AuthenticationException(rmdEx.getCode(),
						rmdEx.getMessage());
			} else if (AppConstants.EXCEPTION_EOA_109.equalsIgnoreCase(rmdEx
					.getMessage())) {
				throw new AuthorizationException(rmdEx.getCode(),
						rmdEx.getMessage());
			} else {
				throw rmdEx;
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getTimezone() method ", ex);
			throw ex;
		}
		return timeZone;
	}

	/* Method for Fetching all the customers from the system */
	@Cacheable(value = { "RMDCustomerCache" })
	public Map<String, String> getCustomers() throws RMDWebException, Exception {
		rmdWebLogger.info("Cache: getCustomers");
		final Map<String, String> customerMap = new LinkedHashMap<String, String>();

		try {
			Customer[] customer = (Customer[]) rsInvoker.get(
					ServiceConstants.GET_CUSTOMERS, null, null, null,
					Customer[].class);

			for (int i = 0; i < customer.length; i++) {
				customerMap.put(customer[i].getCustomerID(),
						customer[i].getCustomerName());
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getCustomers() method ", rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error("Exception occured in getCustomers() method ",
					exp);
			throw exp;
		}
		return customerMap;
	}

	@Cacheable(value = { "RMDRolePrivilegeCache" }, key = "#userBean.userVO.roleId")
	public List<RolePrivilegesType> getRolePrivileges(UserLoginBean userBean)
			throws RMDWebException, Exception {
		rmdWebLogger.info("Cache: RMDRolePrivilegeCache");
		RolePrivilegesType[] rolePrivList = null;
		List<RolePrivilegesType> rolePrevType = new ArrayList<RolePrivilegesType>();
		try {
			Map<String, String> qParamLogin = new LinkedHashMap<String, String>();
			qParamLogin.put("roleId",
					String.valueOf(userBean.getUserVO().getRoleId()));

			Map<String, String> headerParams = getHeaderMap(userBean);

			rolePrivList = (RolePrivilegesType[]) this.rsInvoker
					.get(ServiceConstants.SECURITY_SERVICE_GET_ROLE_PRIVILAGES,
							qParamLogin, null, headerParams,
							RolePrivilegesType[].class);

			if ((rolePrivList != null) && (rolePrivList.length > 0)) {
				for (RolePrivilegesType rPL : rolePrivList)
					rolePrevType.add(rPL);
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in authorize() method ", rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error("Exception occured in authorize() method ", exp);
			throw exp;
		}
		return rolePrevType;
	}

	/* Method for Fetching all the country and state for pinpoint users */
	@Cacheable(value = { "PPCountryStateCache" })
	public Map<String, List<String>> getPPCountryStates()
			throws RMDWebException, Exception {
		rmdWebLogger.info("Cache: getPPCountryStates");
		CountryType[] countryType = null;
		Map<String, List<String>> stateContryMap = new HashMap<String, List<String>>();

		String countryName = null;

		List<StateType> stateInfo;
		try {

			countryType = (CountryType[]) rsInvoker.get(
					ServiceConstants.GET_PP_COUNTRY_STATE, null, null, null,
					CountryType[].class);
			if (null != countryType) {
			for (int i = 0; i < countryType.length; i++) {
				countryName = countryType[i].getCountryCode();
				stateInfo = countryType[i].getState();
				List<String> states = new ArrayList<String>();
				Iterator<StateType> it = stateInfo.iterator();
				while (it.hasNext()) {
					states.add(it.next().getStateCode());
				}

					stateContryMap.put(countryName, states);
				}
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getPPCountryStates() method ",
					rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error(
					"Exception occured in getPPCountryStates() method ", exp);
			throw exp;
		}
		return stateContryMap;
	}

	/* Method for Fetching all the system parameters from the system */
	@Cacheable(value = { "RMDSystemParamCache" })
	public Map<String, String> getAllSystemParameters() throws RMDWebException,
			Exception {
		rmdWebLogger.info("Cache: getCustomers");
		Map<String, String> sysParamMap = new HashMap<String, String>();
		try {
			SystemParamResponseType[] systemParamResponseType = (SystemParamResponseType[]) rsInvoker
					.get(ServiceConstants.GET_SYSTEM_PARAMETER_SERVICE, null,
							null, null, SystemParamResponseType[].class);

			for (int i = 0; i < systemParamResponseType.length; i++) {

				sysParamMap.put(systemParamResponseType[i].getTitle(),
						systemParamResponseType[i].getValue());
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getCustomers() method ", rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error("Exception occured in getCustomers() method ",
					exp);
			throw exp;
		}
		return sysParamMap;
	}

	/* Method for fetching City details by passing country and statecode */
	@Cacheable(value = { "PPCityCache" }, key = "#cityRequestVO.countryCode+#cityRequestVO.stateCode")
	public  List<CityVO> getCityList(CityRequestVO cityRequestVO)
			throws RMDWebException, Exception {
		final Map<String, String> pathParamMap = new LinkedHashMap<String, String>();
		CityType[] cityType = null;
		Map<String, List<CityVO>> cityMap = new HashMap<String, List<CityVO>>();
		List<CityVO> cityList = null;
		CityVO cityVO = null;
		try {

			pathParamMap.put(AppConstants.COUNTRY_CODE,
					cityRequestVO.getCountryCode());
			pathParamMap.put(AppConstants.STATE_CODE,
					cityRequestVO.getStateCode());

			cityType = (CityType[]) rsInvoker.get(
					ServiceConstants.GET_PP_CITYLIST, pathParamMap, null, null,
					CityType[].class);
			if (null != cityType && cityType.length > 0) {
				cityList = new ArrayList<CityVO>();
				for (int i = 0; i < cityType.length; i++) {

					cityVO = new CityVO();
					cityVO.setCity(cityType[i].getCityName());
					cityVO.setGpsLat(String.valueOf(cityType[i]
							.getLatitude()));
					cityVO.setGpsLon(String.valueOf(cityType[i]
							.getLongitude()));
					cityList.add(cityVO);
					cityMap.put(cityType[i].getCityName(), cityList);

				}
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getCityMap() method ", rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger
					.error("Exception occured in getCityMap() method ", exp);
			throw exp;
		}
		return cityList;
	}

	/* Method for Fetching all the Road Initials for a customer */
	@Cacheable(value = { "PPCustRoadInitialCache" }, key = "#customerId")
	public List<String> getRoadInitials(String customerId)
			throws RMDWebException, Exception {
		rmdWebLogger.info("Cache: getRoadInitials");
		final Map<String, String> pathParamsMap = new HashMap<String, String>();
		List<String> roadInitials = new ArrayList<String>();

		try {
			pathParamsMap.put(AppConstants.CUSTOMER_ID, customerId);
			RoadInitialType[] roadInitialsResponse = (RoadInitialType[]) rsInvoker
					.get(ServiceConstants.GET_NOTIFICATION_ROAD_INITIALS,
							pathParamsMap, null, null, RoadInitialType[].class);
			if (!RMDCommonUtility.checkNull(roadInitialsResponse)) {

				for (RoadInitialType notificationLevelValue : roadInitialsResponse) {

					roadInitials.add(notificationLevelValue
							.getRoadInitialName());
				}
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getRoadInitials() method ",
					rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error(
					"Exception occured in getRoadInitials() method ", exp);
			throw exp;
		}
		return roadInitials;
	}

	private Map<String, String> getHeaderMap(final RMDBaseBean baseBean) {
		final Map<String, String> headerMap = new HashMap<String, String>();

		if (null != baseBean.getLanguage()) {
			headerMap.put(AppConstants.LANGUAGE, baseBean.getLanguage());
		}
		if (null != baseBean.getUserLanguage()) {
			headerMap.put(AppConstants.USER_LANGUAGE,
					baseBean.getUserLanguage());
		}
		if (null != baseBean.getUserId()) {
			headerMap.put(AppConstants.GENERAL_PARAM_USER_ID,
					baseBean.getUserId());
		}
		if (null != baseBean.getUserFirstName()) {
			headerMap.put(AppConstants.GENERAL_PARAM_USER_FNAME,
					baseBean.getUserFirstName());
		}
		if (null != baseBean.getUserLastName()) {
			headerMap.put(AppConstants.GENERAL_PARAM_USER_LNAME,
					baseBean.getUserLastName());
		}
		return headerMap;
	}
	
	
	/* Method for Fetching all the Fleets from the system */
	@Cacheable(value = { "RMDAllFleetsCache" })
	public Map<String, ArrayList<FleetVO>> getAllFleets() throws RMDWebException, Exception {
		rmdWebLogger.info("Cache: getAllFleets");
		FleetVO fleetVo = null;
		ArrayList<FleetVO> fleetAryList = null;
		Map<String, ArrayList<FleetVO>> fleetmap = new HashMap<String, ArrayList<FleetVO>>();
		try {
			FleetResponseType[] fleetList = (FleetResponseType[]) rsInvoker.get(
					ServiceConstants.GET_ALL_FLEETS, null, null, null,
					FleetResponseType[].class);
			
			if(fleetList != null && fleetList.length > 0){
				for (int i = 0; i < fleetList.length; i++) {
					fleetVo = new FleetVO();
					fleetVo.setFleetId(fleetList[i].getFleetId());
					fleetVo.setFleetNo(fleetList[i].getFleetNo());
					if(fleetmap.containsKey(fleetList[i].getCustomerId())){
						
						fleetmap.get(fleetList[i].getCustomerId()).add(fleetVo);
					}else{
						fleetAryList = new ArrayList<FleetVO>();
						fleetAryList.add(fleetVo);
						fleetmap.put(fleetList[i].getCustomerId(), fleetAryList);
					}
				}
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getCustomers() method ", rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error("Exception occured in getCustomers() method ",
					exp);
			throw exp;
		}
		return fleetmap;
	}
	
	/* Method for Fetching all the Regions from the system */
	@Cacheable(value = { "RMDAllRegionsCache" })
	public Map<String, ArrayList<RegionVO>> getAllRegions() throws RMDWebException, Exception {
		rmdWebLogger.info("Cache: getAllFleets");
		RegionVO regionVo = null;
		ArrayList<RegionVO> regionAryList = null;
		Map<String, ArrayList<RegionVO>> regionMap = new HashMap<String, ArrayList<RegionVO>>();
		try {
			RegionResponseType[] regionList = (RegionResponseType[]) rsInvoker.get(
					ServiceConstants.GET_ALL_REGIONS, null, null, null,
					RegionResponseType[].class);
			if(regionList != null && regionList.length > 0){
				for (int i = 0; i < regionList.length; i++) {
					regionVo = new RegionVO();
					regionVo.setRegionId(regionList[i].getRegionId());
					regionVo.setRegionName(regionList[i].getRegionName());
					if(regionMap.containsKey(regionList[i].getCustomerId())){
						
						regionMap.get(regionList[i].getCustomerId()).add(regionVo);
					}else{
						regionAryList = new ArrayList<RegionVO>();
						regionAryList.add(regionVo);
						regionMap.put(regionList[i].getCustomerId(), regionAryList);
					}
				}
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getCustomers() method ", rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error("Exception occured in getCustomers() method ",
					exp);
			throw exp;
		}
		return regionMap;
	}
	
	
	/* Method for Fetching all the Regions from the system */
	@Cacheable(value = { "RestrictedAlertShopCache" })
	public Map<String, ArrayList<RestrictedAlertShopVO>> getRestrictedAlertShop() throws RMDWebException, Exception {
		rmdWebLogger.info("Cache: getAllFleets");
		RestrictedAlertShopVO restrictedAlertShopVO = null;
		ArrayList<RestrictedAlertShopVO> alertShopChkAryList = null;
		Map<String, ArrayList<RestrictedAlertShopVO>> regionMap = new HashMap<String, ArrayList<RestrictedAlertShopVO>>();
		try {
			RestrictedAlertShopRespType[] regionList = (RestrictedAlertShopRespType[]) rsInvoker.get(
					ServiceConstants.GET_ALL_SHOP_CHECK, null, null, null,
					RestrictedAlertShopRespType[].class);
			if(regionList != null && regionList.length > 0){
				for (int i = 0; i < regionList.length; i++) {
					restrictedAlertShopVO = new RestrictedAlertShopVO();
					restrictedAlertShopVO.setAlertId(regionList[i].getAlertId());
					restrictedAlertShopVO.setAlertName(regionList[i].getAlertName());
					restrictedAlertShopVO.setProximityCheckFlag(regionList[i].getProximityCheckFlag());
					restrictedAlertShopVO.setCustomerId(regionList[i].getCustomerId());
					if(regionMap.containsKey(regionList[i].getCustomerId())){
						
						regionMap.get(regionList[i].getCustomerId()).add(restrictedAlertShopVO);
					}else{
						alertShopChkAryList = new ArrayList<RestrictedAlertShopVO>();
						alertShopChkAryList.add(restrictedAlertShopVO);
						regionMap.put(regionList[i].getCustomerId(), alertShopChkAryList);
					}
				}
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getCustomers() method ", rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error("Exception occured in getCustomers() method ",
					exp);
			throw exp;
		}
		return regionMap;
	}
	
	/* Method for Fetching all the values in sd cust lookup from the system */
	@Cacheable(value = { "CustLookupCache" })
	public Map<String, CustLookupVO> getSDCustLookup() throws RMDWebException,
			Exception {
		rmdWebLogger.info("Cache: CustLookupCache");
		CustLookupVO custLookupVO = null;
		Map<String, CustLookupVO> custLookupMap = new HashMap<String, CustLookupVO>();
		try {
			CustLookupResponseType[] custList = (CustLookupResponseType[]) rsInvoker
					.get(ServiceConstants.GET_SD_CUST_LOOKUP, null, null, null,
							CustLookupResponseType[].class);
			if (custList != null && custList.length > 0) {
				for (int i = 0; i < custList.length; i++) {
					custLookupVO = new CustLookupVO();
					custLookupVO.setFamPrivilege(custList[i].getFamPrivilege());
					custLookupVO.setMetricsPrivilege(custList[i]
							.getMetricsPrivilege());
					custLookupVO.setCustomerId(custList[i].getCustomerId());
					custLookupVO.setRxEmailCheck(custList[i].getRxEmailCheck());
					custLookupVO.setDateFormat(custList[i].getDateFormat());
					custLookupVO.setConfigAlertFlg(custList[i].getConfigAlertFlg());
					custLookupVO.setFlagMPData(custList[i].getFlagMPData());
					custLookupMap
							.put(custList[i].getCustomerId(), custLookupVO);
				}
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getCustomers() method ", rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error("Exception occured in getCustomers() method ",
					exp);
			throw exp;
		}
		return custLookupMap;
	}
	
	
	/* Method for Fetching all the values in sd cust lookup from the system */
	@Cacheable(value = { "ShopDetailsCache" })
	public Map<String, ArrayList<ShopsVO>> getAllShops() throws RMDWebException,
			Exception {
		ShopsVO shopsVO=null;
		List<ShopsVO> shopLst=new ArrayList<ShopsVO>();
		rmdWebLogger.info("Cache: CustLookupCache");
/*		CustLookupVO custLookupVO = null;
		List<String> shopList=new ArrayList<String>();*/
		Map<String, ArrayList<ShopsVO>> ShopListMap = new HashMap<String,ArrayList<ShopsVO>>();
		ArrayList<ShopsVO> shopAryList = null;
		try {

			ShopsResponseType[] shopList = (ShopsResponseType[]) rsInvoker.get(
					ServiceConstants.GET_ALL_SHOPS, null, null, null,
					ShopsResponseType[].class);
			if(shopList != null && shopList.length > 0){
				for (int i = 0; i < shopList.length; i++) {
					shopsVO = new ShopsVO();
					shopsVO.setShopId(shopList[i].getShopId());
					shopsVO.setShopName(shopList[i].getShopName());
					if(ShopListMap.containsKey(shopList[i].getCustomerId())){
						ShopListMap.get(shopList[i].getCustomerId()).add(shopsVO);
					}else{
						shopAryList = new ArrayList<ShopsVO>();
						shopAryList.add(shopsVO);
						ShopListMap.put(shopList[i].getCustomerId(),shopAryList);;

					}
				}
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getCustomers() method ", rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error("Exception occured in getCustomers() method ",
					exp);
			throw exp;
		}
		return ShopListMap;
	}
	
	/* Method for Fetching all the Fault Origin Values from the system */
	@Cacheable(value = { "FaultOriginCache" })
	public Map<String, String> getFaultOrigin() throws RMDWebException {
		rmdWebLogger.info("Cache: getFaultOrigin");
		Map<String, String> faultOriginMap = new LinkedHashMap<String, String>();
		try {
			FaultCodesResponseType[] arrfaulCodesResponseType = (FaultCodesResponseType[]) rsInvoker
					.get(ServiceConstants.GET_FAULT_ORIGIN, null, null, null,
							FaultCodesResponseType[].class);
			for (FaultCodesResponseType objFaultCodesResponseType : arrfaulCodesResponseType) {
				faultOriginMap.put(objFaultCodesResponseType.getFaultOrigin(),
						objFaultCodesResponseType.getFaultOrigin());
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getFaultOrigin method  of CachedServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return faultOriginMap;
	}
	
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, ArrayList<ModelVO>>
	 * @throws:RMDWebException,Exception
	 * @Description: This method is used for fetching the All Model values.
	 */
	@Cacheable(value = { "ModelDetailsCache" })
	public Map<String, ArrayList<ModelVO>> getAllModels()
			throws RMDWebException, Exception {
		ModelVO objModelVO = null;
		ArrayList<ModelVO> modelAryList = null;
		Map<String, ArrayList<ModelVO>> modelMap = new HashMap<String, ArrayList<ModelVO>>();
		try {
			ModelsResponseType[] objModelsResponseType = (ModelsResponseType[]) rsInvoker
					.get(ServiceConstants.GET_ALL_MODELS, null, null, null,
							ModelsResponseType[].class);
			if (objModelsResponseType != null
					&& objModelsResponseType.length > 0) {
				for (int i = 0; i < objModelsResponseType.length; i++) {
					objModelVO = new ModelVO();
					objModelVO.setModelObjId(objModelsResponseType[i]
							.getModelObjId());
					objModelVO.setModelName(objModelsResponseType[i]
							.getModelName());
					objModelVO.setModelFamily(objModelsResponseType[i]
							.getModelFamily());
					objModelVO.setModelGeneral(objModelsResponseType[i]
                            .getModelGeneral());
					if (modelMap.containsKey(objModelsResponseType[i]
							.getCustomerId())) {

						modelMap.get(objModelsResponseType[i].getCustomerId())
								.add(objModelVO);
					} else {
						modelAryList = new ArrayList<ModelVO>();
						modelAryList.add(objModelVO);
						modelMap.put(objModelsResponseType[i].getCustomerId(),
								modelAryList);
					}
				}
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getAllModels() method ",
					rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error(
					"Exception occured in getAllModels() method ", exp);
			throw exp;
		}
		return modelMap;
	}
	
	@Override
	@Cacheable(value = { "RMDControllerCache" })
	public Map<String, String> getAllControllers() throws GenericAjaxException,
			RMDWebException, Exception {
		rmdWebLogger.info("Cache: getAllControllers");
		final Map<String, String> controllerMap = new LinkedHashMap<String, String>();

		try {
			ControllerResponseType[] controller = (ControllerResponseType[]) rsInvoker
					.get(ServiceConstants.GET_ALL_CONTROLLERS, null, null,
							null, ControllerResponseType[].class);

			for (int i = 0; i < controller.length; i++) {
				controllerMap.put(controller[i].getControllerId(),
						controller[i].getControllerName());
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getAllControllers() method ",
					rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error(
					"Exception occured in getAllControllers() method ", exp);
			throw exp;
		}
		return controllerMap;
	}

	/**
	 * @Author :
	 * @return :Map<String, String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This controller method will fetch the list of Notes
	 *               Creators.
	 * 
	 */

	@Override
	@Cacheable(value = { "RMDCreatorCache" })
	public Map<String, String> getNotesCreatersList()
			throws GenericAjaxException, RMDWebException, Exception {
		rmdWebLogger.info("Cache: getNotesCreatersList");
		final Map<String, String> creatorMap = new LinkedHashMap<String, String>();
		List<String> creatorList = null;

		try {
			CreatorResponseType objCreatorResponse = (CreatorResponseType) rsInvoker
					.get(ServiceConstants.GET_ALL_CREATORS, null, null, null,
							CreatorResponseType.class);
			if (null != objCreatorResponse) {
				creatorList = objCreatorResponse.getCreatorList();
				for (String creator : creatorList) {
					creatorMap.put(creator, creator);
				}
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getNotesCreatersList() method ",
							rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error(
					"Exception occured in getNotesCreatersList() method ", exp);
			throw exp;
		}
		return creatorMap;
	}
	
	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param :
	 * @throws Exception
	 * @throws :RMDWebException
	 * @Description: This method is used for fetching notify flags.
	 * 
	 */

	@Cacheable(value = { "RMDNotifyFlagsCache" })
	public Map<String, String> getNotifyFlags() throws Exception {
		final Map<String, String> notifyFlagsMap = new LinkedHashMap<String, String>();

		try {
			NotifyFlagsResponseType objNotifyFlagsResponseType = (NotifyFlagsResponseType) rsInvoker
					.get(ServiceConstants.GET_NOTIFY_FLAGS, null, null, null,
							NotifyFlagsResponseType.class);
			if (null != objNotifyFlagsResponseType) {
				List<String> notifyFlagList = objNotifyFlagsResponseType
						.getNotifyFlagsList();
				for (String notifyFlag : notifyFlagList) {
					notifyFlagsMap.put(notifyFlag, notifyFlag);
				}
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getNotifyFlags() method ",
					rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error("Exception occured in getNotifyFlags() method ",
					exp);
			throw exp;
		}
		return notifyFlagsMap;
	}

	/**
	 * @Author :
	 * @return :String
	 * @param :AddNotifyConfigVO objAddNotifyConfigVO
	 * @throws Exception
	 * @throws :RMDWebException
	 * @Description:This method is used for fetching Threshold values.
	 * 
	 */

	@Cacheable(value = { "RMDThresholdCache" })
	public Map<String, String> getThreshold() throws Exception {
		final Map<String, String> thresholdMap = new LinkedHashMap<String, String>();
		try {
			ThresholdResponseType objThresholdResponseType = (ThresholdResponseType) rsInvoker
					.get(ServiceConstants.GET_THRESHOLDS, null, null, null,
							ThresholdResponseType.class);
			if (null != objThresholdResponseType
					&& null != objThresholdResponseType.getThresholdList()) {
				for (String creator : objThresholdResponseType
						.getThresholdList()) {
					thresholdMap.put(creator, creator);
				}
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getThreshold() method ", rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error("Exception occured in getThreshold() method ",
					exp);
			throw exp;
		}
		return thresholdMap;
	}
	
	
	/**
	 * @Author :
	 * @return :Map<String, String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method will fetch list of state province.
	 * 
	 */
	
	@Cacheable(value = { "RMDStateProvinceCache" })
	public Map<String, String> getStateProvince() throws GenericAjaxException,
			RMDWebException, Exception {
		rmdWebLogger.info("Cache: getStateProvince");
		final Map<String, String> stateProvinceMap = new LinkedHashMap<String, String>();
		List<String> stateProvinceList = null;

		try {
			StateProvinceResponseType objstateProvinceResponse = (StateProvinceResponseType) rsInvoker
					.get(ServiceConstants.GET_STATE_PROVINCE, null, null, null,
							StateProvinceResponseType.class);
			if (null != objstateProvinceResponse) {
				stateProvinceList = objstateProvinceResponse
						.getStateProvinceList();
				for (String stateProvince : stateProvinceList) {
					stateProvinceMap.put(stateProvince, stateProvince);
				}
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getStateProvince() method ",
					rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error(
					"Exception occured in getStateProvince() method ", exp);
			throw exp;
		}
		return stateProvinceMap;
	}	
	
	
	@Override
	@Cacheable(value = { "RMDAurizonCache" })
	public List<MetricsBean> getMetricsConversion()
			throws GenericAjaxException, RMDWebException, Exception {
		rmdWebLogger.info("Cache: getAurizonMetrics");
		MetricsBean objAssetStatusHistoryBean=null;
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		List<MetricsBean> aurizan = new ArrayList<MetricsBean>();
		try {
			
			
			HashSet<String> customerId=new HashSet<String>();
			MetricsResponseType[] objPpAssetStatusHstryResponseType = (MetricsResponseType[]) rsInvoker
					.get(ServiceConstants.GET_CONVERSION_UNITS, null,queryParamsMap,null,
							MetricsResponseType[].class);
			if (null != objPpAssetStatusHstryResponseType) {
				for(MetricsResponseType responseType:objPpAssetStatusHstryResponseType)
				{
				objAssetStatusHistoryBean =new MetricsBean();
				objAssetStatusHistoryBean.setCustomerName(responseType.getCustomerID());
				objAssetStatusHistoryBean.setColumnName(responseType.getColumnName());
				objAssetStatusHistoryBean.setScreenName(responseType.getScreenName());
				objAssetStatusHistoryBean.setToUnit(responseType.getToUnit());
				objAssetStatusHistoryBean.setConvReq(responseType.getConvReq());
				objAssetStatusHistoryBean.setFromUnit(responseType.getFromUnit());
				aurizan.add(objAssetStatusHistoryBean);
				}
				
				}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getAurizonMetrics() method ",
							rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error(
					"Exception occured in getAurizonMetrics() method ", exp);
			throw exp;
		}
		return aurizan;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, List<String>>
	 * @throws:RMDWebException,Exception
	 * @Description: This method is used for fetching the Customer Name and Road
	 *               Number Headers.
	 */
	@Override
	@Cacheable(value = { "RMDCustNameRNH" })
	public Map<String, List<String>> getCustNameRNH() throws RMDWebException,
			Exception {
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		final Map<String, List<String>> custNameRNHMap = new LinkedHashMap<String, List<String>>();
		List<String> lstString = null;
		String customerName = null;
		String strRNH = null;
		AssetResponseType objAssetResponseType[] = null;
		try {
			objAssetResponseType = (AssetResponseType[]) rsInvoker.get(
					ServiceConstants.GET_CUSTOMER_RNH, null, queryParamMap,
					null, AssetResponseType[].class);
			if (null != objAssetResponseType) {
				for (AssetResponseType objAssetRespType : objAssetResponseType) {
					customerName = objAssetRespType.getCustomerName();
					strRNH = objAssetRespType.getAssetGroupName();
					if (custNameRNHMap.containsKey(customerName)) {
						lstString = new ArrayList<String>();
						lstString = custNameRNHMap.get(customerName);
						lstString.add(strRNH);
						custNameRNHMap.put(customerName, lstString);
					} else {
						lstString = new ArrayList<String>();
						lstString.add(strRNH);
						custNameRNHMap.put(customerName, lstString);
					}
				}
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getCustNameRNH() method - cachedserviceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return custNameRNHMap;
	}
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the all controller configs
	 */
	@Cacheable(value = { "RMDControllerConfigsCache" })
	public Map<String, String> getControllerConfigs() throws RMDWebException,
			Exception {
		final Map<String, String> ctrlCfgMap = new LinkedHashMap<String, String>();
		try {
			CtrlCfgResponseType[] objCtrlCfgResponseType = (CtrlCfgResponseType[]) rsInvoker
					.get(ServiceConstants.GET_CTRL_CFGS, null, null, null,
							CtrlCfgResponseType[].class);
			if (null != objCtrlCfgResponseType) {
				for (int i = 0; i < objCtrlCfgResponseType.length; i++) {
					ctrlCfgMap.put(objCtrlCfgResponseType[i].getCtrlCfgName(),
							objCtrlCfgResponseType[i].getCtrlCfgObjId());
				}
			}
			objCtrlCfgResponseType = null;
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getControllerConfigs() method ",
							rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error(
					"Exception occured in getControllerConfigs() method ", exp);
			throw exp;
		}
		return ctrlCfgMap;
	}

	/**
	 * 
	 * @param
	 * @return List<String>
	 * @throws RMDWebException
	 * @Description This method is used to get the all country List
	 * 
	 */
	@Override
	@Cacheable(value = { "RMDCountryListCache" })
	public List<String> getCountryList() throws RMDWebException,Exception{
		List<String> countryList = null;
		String countryString = RMDCommonConstants.EMPTY_STRING;
		try {
			countryString = (String) rsInvoker.get(
					ServiceConstants.GET_COUNTRY_LIST, null, null, null,
					String.class);
			if (!RMDCommonUtility.isNullOrEmpty(countryString)) {
				countryList = Arrays.asList(countryString
						.split(RMDCommonConstants.COMMMA_SEPARATOR));
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getCountryList() method ",
							rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error(
					"Exception occured in getCountryList() method ", exp);
			throw exp;
		}
		return countryList;
	}
	
	/**
	 * 
	 * @param String country
	 * @return List<String>
	 * @throws RMDWebException
	 * @Description This method is used to get the states for the selected Country
	 * 
	 */
	@Override
	@Cacheable(value = { "RMDCountryStatesCache" }, key = "#country")
	public List<String> getCountryStates(String country)
			throws RMDWebException, Exception {
		rmdWebLogger.info("Cache: getCountryStates");
		List<String> stateList = null;
		Map<String, String> queryParamMap = null;
		String stateString = RMDCommonConstants.EMPTY_STRING;
		try {
			queryParamMap = new LinkedHashMap<String, String>();
			queryParamMap.put(AppConstants.COUNTRY, country);
			stateString = (String) rsInvoker.get(
					ServiceConstants.GET_COUNTRY_STATES, null, queryParamMap,
					null, String.class);
			if (!RMDCommonUtility.isNullOrEmpty(stateString)) {
				stateList = Arrays.asList(stateString
						.split(RMDCommonConstants.COMMMA_SEPARATOR));
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getCountryList() method ",
					rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error(
					"Exception occured in getCountryList() method ", exp);
			throw exp;
		}
		return stateList;
	}
	
	/**
	 * 
	 * @param String country
	 * @return List<String>
	 * @throws RMDWebException
	 * @Description This method is used to get the time zones for the selected Country
	 * 
	 */
	@Override
	@Cacheable(value = { "RMDCountryTimezonesCache" }, key = "#country")
	public List<String> getCountryTimeZones(String country)
			throws RMDWebException, Exception {
		rmdWebLogger.info("Cache: getCountryTimeZones");
		List<String> timeZoneList = null;
		Map<String, String> queryParamMap = null;
		String timeZoneString = RMDCommonConstants.EMPTY_STRING;
		try {
			queryParamMap = new LinkedHashMap<String, String>();
			queryParamMap.put(AppConstants.COUNTRY, country);
			timeZoneString = (String) rsInvoker.get(
					ServiceConstants.GET_COUNTRY_TIMEZONES, null, queryParamMap,
					null, String.class);
			if (!RMDCommonUtility.isNullOrEmpty(timeZoneString)) {
				timeZoneList = Arrays.asList(timeZoneString
						.split(RMDCommonConstants.COMMMA_SEPARATOR));
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getCountryTimeZones() method ",
					rmdEx);
			throw rmdEx;
		} catch (Exception exp) {
			rmdWebLogger.error(
					"Exception occured in getCountryTimeZones() method ", exp);
			throw exp;
		}
		return timeZoneList;
	}

	@Override
	@Cacheable(value = { "OHVMonthlyAndQuarterListCache" }, key = "#mineId+#truckId")
	public Map<String, List<String>> getTruckVariablesParamList(String mineId,
			String truckId, boolean isAvgCalc) throws RMDWebException {
		ReportsRxRequestType reportsRequest = new ReportsRxRequestType( mineId, truckId, null, null, null, isAvgCalc );
		Map<String, List<String>> truckVariableParams = new HashMap<String, List<String>>();
       try{
    	   ReportsTruckParamListResponseType truckParamList = (ReportsTruckParamListResponseType) rsInvoker.post(
                           ServiceConstants.GET_REPORTS_TRUCK_PARAM_LIST, reportsRequest,
                           ReportsTruckParamListResponseType.class);
       	
       	if(truckParamList != null){
            Map<String, ReportsListWrapper> params = truckParamList.getTruckParamsList();
		    for (Map.Entry<String, ReportsListWrapper> pair : params.entrySet()) {
		        ReportsListWrapper wrapperList = pair.getValue();
		        List<String> listValues = null;
		        if(wrapperList != null){
		        	listValues = wrapperList.getList();
		        }
		        truckVariableParams.put(pair.getKey(), listValues);
		    }
       	}
       } catch (RMDWebException exp) {
    	   rmdWebLogger.error("Exception occured in getTruckInfo in ReportsServiceImpl:",exp);
    	   throw exp;
       }
       return truckVariableParams;
	}
	
}
