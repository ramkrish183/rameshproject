package com.ge.trans.rmd.common.service;


import com.ge.trans.rmd.common.beans.HeaderSearchBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.HeaderSearchRespVO;
import com.ge.trans.rmd.common.vo.HeaderSearchResponseVO;


public interface HeaderSearchService {

	public HeaderSearchResponseVO getCases(HeaderSearchBean headerSearchBean) throws RMDWebException, Exception;
	public HeaderSearchResponseVO getAssets(HeaderSearchBean headerSearchBean) throws RMDWebException, Exception;
	public HeaderSearchRespVO getAssetsData(HeaderSearchBean headerSearchBean) throws RMDWebException, Exception;
	public HeaderSearchRespVO getCasesData(HeaderSearchBean headerSearchBean) throws RMDWebException, Exception;
}
