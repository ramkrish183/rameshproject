package com.ge.trans.rmd.common.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.CallLogDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.CallLogReportBean;
import com.ge.trans.rmd.cm.valueobjects.InboundTurnoverBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CallLogDetailsResponse;
import com.ge.trans.rmd.services.turnover.valueobjects.TurnoverInboundResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class RunTurnoverServiceImpl extends RMDBaseServiceImpl implements
		RunTurnoverService {

	@Autowired
	private WebServiceInvoker rsInvoker;

	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	@Override
	public Future<List<InboundTurnoverBean>> getInboundReportData()
			throws RMDWebException, Exception {
		InboundTurnoverBean inboundbeanVo = null;
		TurnoverInboundResponseType[] responseType = null;
		List<InboundTurnoverBean> beanResponse = new ArrayList<InboundTurnoverBean>();
		try {
			responseType = (TurnoverInboundResponseType[]) rsInvoker.get(
					ServiceConstants.TURNOVER_INBOUND_SERVICE, null, null,
					null, TurnoverInboundResponseType[].class);

			if (responseType != null && responseType.length > 0) {
				for (TurnoverInboundResponseType turnoverInboundResponseType : responseType) {
					inboundbeanVo = new InboundTurnoverBean();
					if (turnoverInboundResponseType.getRoadNumberHeader() != null) {
						inboundbeanVo
								.setRoadNumberHeader(turnoverInboundResponseType
										.getRoadNumberHeader());
					}
					if (turnoverInboundResponseType.getGpocComments() != null) {
						inboundbeanVo
								.setGpocComments(turnoverInboundResponseType
										.getGpocComments());
					}
					if (turnoverInboundResponseType.getCount() != null) {
						inboundbeanVo.setCount(turnoverInboundResponseType
								.getCount());
					}
					beanResponse.add(inboundbeanVo);
				}
			}
		} catch (Exception ex) {
			logger.error("Exception occured ingetInboundReportData method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return new AsyncResult<List<InboundTurnoverBean>>(beanResponse);
	}
	
	@Override
    public Future<CallLogReportBean> getCallCountByLocation() throws RMDWebException {
        CallLogDetailsResponse[] callLogReportResponse = null;
        List<CallLogDetailsVO> callLogReportsVO = null;
        CallLogDetailsVO callLogReports = null;
        CallLogReportBean callLogReportBean =null;
        try {
            callLogReportResponse = (CallLogDetailsResponse[]) rsInvoker.get(
                    ServiceConstants.GET_CALL_COUNT_BY_LOCATION, null, null, null, CallLogDetailsResponse[].class);
            if (null != callLogReportResponse && callLogReportResponse.length > 0) {
                callLogReportsVO = new ArrayList<CallLogDetailsVO>(callLogReportResponse.length);
                callLogReportBean = new CallLogReportBean();
                for (CallLogDetailsResponse objCallLogReportResponse : callLogReportResponse) {
                    callLogReports = new CallLogDetailsVO();
                    callLogReports.setLocation(objCallLogReportResponse.getLocation());
                    callLogReports.setCount(objCallLogReportResponse.getCount());
                    callLogReportsVO.add(callLogReports);
                    
                }
                callLogReportBean.setCallLogReport(callLogReportsVO);
            }
            
        } catch (Exception ex) {
            logger.error("Exception occured in getCallCountByLocation() method of RunTurnoverServiceImpl.java", ex);
            RMDWebErrorHandler.handleException(ex);
        }finally{
            callLogReportResponse = null;
        }
        return new AsyncResult<CallLogReportBean>(callLogReportBean);
    }
	
	@Override
    public Future<CallLogReportBean> getCustBrkDownByMins() throws RMDWebException {
	    CallLogDetailsResponse[] callLogReportResponse = null;
        List<CallLogDetailsVO> callLogReportsVO = null;
        CallLogDetailsVO callLogReports = null;
        CallLogReportBean callLogReportBean =null;
        try {
            callLogReportResponse = (CallLogDetailsResponse[]) rsInvoker.get(
                    ServiceConstants.GET_CUST_BREAK_DOWN_MINS, null, null, null, CallLogDetailsResponse[].class);
            if (null != callLogReportResponse && callLogReportResponse.length > 0) {
                callLogReportsVO = new ArrayList<CallLogDetailsVO>(callLogReportResponse.length);
                callLogReportBean = new CallLogReportBean();
                for (CallLogDetailsResponse objCallLogReportResponse : callLogReportResponse) {
                    callLogReports = new CallLogDetailsVO();
                    callLogReports.setCustomer(objCallLogReportResponse.getCustomer());
                    callLogReports.setCount(objCallLogReportResponse.getCount());
                    callLogReportsVO.add(callLogReports);
                    
                }
                callLogReportBean.setCallLogReport(callLogReportsVO);
            }
            
        } catch (Exception ex) {
            logger.error("Exception occured in getCustBrkDownByMins() method of RunTurnoverServiceImpl.java", ex);
            RMDWebErrorHandler.handleException(ex);
        }finally{
            callLogReportResponse = null;
            callLogReportsVO=null;
            callLogReports=null;
        }
        return new AsyncResult<CallLogReportBean>(callLogReportBean);
    }
	
	@Override
    public Future<CallLogReportBean> getCallCntByBusnsArea() throws RMDWebException {
        CallLogDetailsResponse[] callLogReportResponse = null;
        CallLogReportBean callLogReportBean =null;
        HashMap<String,Map<String,String>> custCallCountByArea = null;
        Map<String,String> callCountByArea = null;
        try {
            callLogReportResponse = (CallLogDetailsResponse[]) rsInvoker.get(
                    ServiceConstants.GET_CALL_COUNT_BY_BUSS_AREA, null, null, null, CallLogDetailsResponse[].class);
            if (null != callLogReportResponse && callLogReportResponse.length > 0) {
                callLogReportBean = new CallLogReportBean();
                custCallCountByArea = new LinkedHashMap<String, Map<String,String>>();
                for (CallLogDetailsResponse objCallLogReportResponse : callLogReportResponse) {
                    if(custCallCountByArea.containsKey(objCallLogReportResponse.getCustomer())){
                        callCountByArea = custCallCountByArea.get(objCallLogReportResponse.getCustomer());
                        callCountByArea.put(objCallLogReportResponse.getBussinessType(), objCallLogReportResponse.getCount());
                    }else{
                        callCountByArea = new LinkedHashMap<String, String>();
                        callCountByArea.put(objCallLogReportResponse.getBussinessType(), objCallLogReportResponse.getCount());
                    }
                    custCallCountByArea.put(objCallLogReportResponse.getCustomer(), callCountByArea);
                    
                }
                callLogReportBean.setCallCntByBsnArea(custCallCountByArea);
            }
            
        } catch (Exception ex) {
            logger.error("Exception occured in getCallCntByBusnsArea() method of RunTurnoverServiceImpl.java", ex);
            RMDWebErrorHandler.handleException(ex);
        }finally{
            callLogReportResponse = null;
            custCallCountByArea=null;
            callCountByArea=null;
        }
        return new AsyncResult<CallLogReportBean>(callLogReportBean);
    }
	
	@Override
    public Future<CallLogReportBean> getWeeklyCallCntByBusnsArea() throws RMDWebException {
        CallLogDetailsResponse[] callLogReportResponse = null;
        CallLogReportBean callLogReportBean =null;
        HashMap<String,Map<String,String>> weeklyCallCountByArea = null;
        Map<String,String> callCountByArea = null;
        try {
            callLogReportResponse = (CallLogDetailsResponse[]) rsInvoker.get(
                    ServiceConstants.GET_WEEKLY_CALL_COUNT_BY_BUSS_AREA, null, null, null, CallLogDetailsResponse[].class);
            if (null != callLogReportResponse && callLogReportResponse.length > 0) {
                callLogReportBean = new CallLogReportBean();
                weeklyCallCountByArea = new LinkedHashMap<String, Map<String,String>>();
                for (CallLogDetailsResponse objCallLogReportResponse : callLogReportResponse) {
                    if(weeklyCallCountByArea.containsKey(objCallLogReportResponse.getDate())){
                        callCountByArea = weeklyCallCountByArea.get(objCallLogReportResponse.getDate());
                        callCountByArea.put(objCallLogReportResponse.getBussinessType(), objCallLogReportResponse.getCount());
                    }else{
                        callCountByArea = new LinkedHashMap<String, String>();
                        callCountByArea.put(objCallLogReportResponse.getBussinessType(), objCallLogReportResponse.getCount());
                    }
                    weeklyCallCountByArea.put(objCallLogReportResponse.getDate(), callCountByArea);
                    
                }
                callLogReportBean.setWeeklyCallCntByBsnArea(weeklyCallCountByArea);
            }
            
        } catch (Exception ex) {
            logger.error("Exception occured in getCallCntByBusnsArea() method of RunTurnoverServiceImpl.java", ex);
            RMDWebErrorHandler.handleException(ex);
        }finally{
            callLogReportResponse = null;
            weeklyCallCountByArea=null;
            callCountByArea=null;
        }
        return new AsyncResult<CallLogReportBean>(callLogReportBean);
    }
	
	@Override
    public Future<CallLogReportBean> getVehCallCntByBusnsArea() throws RMDWebException {
        CallLogDetailsResponse[] callLogReportResponse = null;
        CallLogReportBean callLogReportBean =null;
        HashMap<String,Map<String,String>> vehCallCountByArea = null;
        Map<String,String> callCountByArea = null;
        try {
            callLogReportResponse = (CallLogDetailsResponse[]) rsInvoker.get(
                    ServiceConstants.GET_VEH_CALL_COUNT_BY_BUSS_AREA, null, null, null, CallLogDetailsResponse[].class);
            if (null != callLogReportResponse && callLogReportResponse.length > 0) {
                callLogReportBean = new CallLogReportBean();
                vehCallCountByArea = new LinkedHashMap<String, Map<String,String>>();
                for (CallLogDetailsResponse objCallLogReportResponse : callLogReportResponse) {
                    if(vehCallCountByArea.containsKey(objCallLogReportResponse.getAsset())){
                        callCountByArea = vehCallCountByArea.get(objCallLogReportResponse.getAsset());
                        callCountByArea.put(objCallLogReportResponse.getBussinessType(), objCallLogReportResponse.getCount());
                    }else{
                        callCountByArea = new LinkedHashMap<String, String>();
                        callCountByArea.put(objCallLogReportResponse.getBussinessType(), objCallLogReportResponse.getCount());
                    }
                    vehCallCountByArea.put(objCallLogReportResponse.getAsset(), callCountByArea);
                    
                }
                callLogReportBean.setVehCallCntByBsnArea(vehCallCountByArea);
            }
            
        } catch (Exception ex) {
            logger.error("Exception occured in getCallCntByBusnsArea() method of RunTurnoverServiceImpl.java", ex);
            RMDWebErrorHandler.handleException(ex);
        }finally{
            callLogReportResponse = null;
            vehCallCountByArea=null;
            callCountByArea=null;
        }
        return new AsyncResult<CallLogReportBean>(callLogReportBean);
    }
	
	 @Override
	 public String getManualCallCount() throws RMDWebException {
         String manualCallCount = null;
         try {
             manualCallCount = (String) rsInvoker.get(ServiceConstants.GET_MANUAL_CALL_COUNT, null,
                     null, null, String.class);
             if(RMDCommonUtility.isNullOrEmpty(manualCallCount)){
                 manualCallCount=RMDCommonConstants.ZERO_STRING;
             }
         } catch (Exception ex) {
             logger.error("Exception occured in getManualCallCount() method of RunTurnoverServiceImpl.java", ex);
             RMDWebErrorHandler.handleException(ex);
         }
         return manualCallCount;
     }
	 
	 @Override
	 public String getMinCallCountOfAsset(String listName) throws RMDWebException {
	        String minCount = null;
	        try{
	            final Map<String, String> pathParams = new LinkedHashMap<String, String>();
	            pathParams.put(AppConstants.LIST_NAME, listName);
	            final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
	            if(null!=applParamResponseType && applParamResponseType.length>0){
	                minCount=applParamResponseType[0].getLookupValue();
	            }else{
	                minCount=AppConstants.CALL_REPORT_MIN_CALL_COUNT;
	            }
	        }catch (Exception ex) {
	             logger.error("Exception occured in getMinCallCountOfAsset() method of RunTurnoverServiceImpl.java", ex);
	             RMDWebErrorHandler.handleException(ex);
	         }	     
	        return minCount;
	    }
	
}
