package com.ge.trans.rmd.common.beans;
@SuppressWarnings("serial")
public class CustomerAssetBean extends RMDBaseBean {
private String roleName;
private String customerId;

public String getCustomerId() {
	return customerId;
}

public void setCustomerId(String customerId) {
	this.customerId = customerId;
}

public String getRoleName() {
	return roleName;
}

public void setRoleName(String roleName) {
	this.roleName = roleName;
}



}
