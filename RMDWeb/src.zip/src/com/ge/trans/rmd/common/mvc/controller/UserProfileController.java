package com.ge.trans.rmd.common.mvc.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.CreateCasesService;
import com.ge.trans.rmd.common.beans.CustomerAssetBean;
import com.ge.trans.rmd.common.beans.FavoriteFilterBean;
import com.ge.trans.rmd.common.beans.UserLoginBean;
import com.ge.trans.rmd.common.beans.UserProfileBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.AuthorizationException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.model.UserProfileModel;
import com.ge.trans.rmd.common.mvc.validator.UserProfileValidator;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.FavoriteFilterService;
import com.ge.trans.rmd.common.service.LoginService;
import com.ge.trans.rmd.common.service.UserManagementService;
import com.ge.trans.rmd.common.service.UserProfileService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.MenuListResourceVO;
import com.ge.trans.rmd.common.vo.ResourceVO;
import com.ge.trans.rmd.common.vo.RolesVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
/**
 * *****************************************************************************
 * 
 * @Author :iGATE Patni
 * @Version : 1.0
 * @Date Created: Nov 15, 2011
 * @Date Modified : Nov 30, 2011
 * @Modified By :
 * @Contact :
 * @Description : This class will be used as a controller for deal with the
 *              requests from userProfile.jsp
 * @History :
 * 
 ***************************************************************************** 
 */
@Controller
@SessionAttributes({ AppConstants.ATTR_USER_OBJECT })
public class UserProfileController extends RMDBaseController {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
	.getLogger(getClass());

	@Autowired
	private AuthorizationService authorizationService;
	@Autowired
	private ApplicationContext appContext;
	@Autowired
	private ServletContext servletContext;
	@Autowired
	private UserProfileService userProfileService;
	@Autowired
	private CreateCasesService createCasesService;
	@Autowired
	private FavoriteFilterService favFilterService;
	@Autowired
	private LoginService loginService;
	@Autowired
	private UserManagementService userManagementService;
	
	@Autowired
	private CachedService cachedService;
	@Value("${" + AppConstants.DASHBOARD_URL + "}")
	String dashboardUrl;
	
	@RequestMapping(value = AppConstants.USERPROFILE_REQ_RESETPASS, method = RequestMethod.GET)
	public @ResponseBody
	Map<String, String> resetPassword(
			@RequestParam(value = AppConstants.USERPROFILE_FORMVALUES, required = true) final String formValues,
			final Locale locale, final HttpServletRequest request)
			throws RMDWebException, Exception {
 		rmdWebLogger.debug("resetPassword():START ");
		UserProfileModel userProfile = null;
		try {
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
			.getAttribute(AppConstants.ATTR_USER_OBJECT);

			final ObjectMapper mapper = new ObjectMapper();

			userProfile = mapper.readValue(EsapiUtil.stripXSSCharacters(formValues), UserProfileModel.class);
			
			Map<String, String> customers = createCasesService.getCustomers();
			 
			
			final Map<String, String> failures = new UserProfileValidator()
					.validate(userVO, userProfile, appContext, locale, request,customers);

			if (!failures.isEmpty()
					&& !failures
					.containsKey(AppConstants.USERPROFILE_ROLECUSTCHNG)
					&& !failures
					.containsKey(AppConstants.USERPROFILE_ROLECUSTPWDCHNG)
					&& !failures.containsKey(AppConstants.USERPROFILE_NOINPUT)) {
				rmdWebLogger.debug("resetPassword():Found Failures");
				return failures;
			} else if (failures
					.containsKey(AppConstants.USERPROFILE_ROLECUSTCHNG)
					|| failures.containsKey(AppConstants.USERPROFILE_NOINPUT)) {
				return failures;
			} else {

				final UserProfileBean userProfileBean = new UserProfileBean();

				RMDCommonUtil.copyProperties(userProfileBean, userProfile);
				userProfileBean.setLanguage(userVO.getStrLanguage());
				userProfileBean.setUserId(userVO.getUserId());

				if (userProfileService.resetPassword(userVO, userProfileBean)
						.equals(AppConstants.SUCCESS)) {
					return Collections.singletonMap(AppConstants.SUCCESS,
							AppConstants.SUCCESS);

				} else

				{
					rmdWebLogger.debug("resetPassword():END ");
					return Collections.singletonMap(
							AppConstants.USERPROFILE_PASSWORDIND,
							appContext.getMessage(
									AppConstants.INDICATOR4_USERPROFILE, null,
									locale));
				}

			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error("RMDWebException:resetPassword()", rmdEx);
			return Collections.singletonMap(
					AppConstants.USERPROFILE_PASSWORDIND, appContext
					.getMessage(AppConstants.INDICATOR4_USERPROFILE,
							null, locale));

		} catch (Exception ex) {
			rmdWebLogger.error("Exception:resetPassword()", ex);
			return Collections.singletonMap(
					AppConstants.USERPROFILE_PASSWORDIND, appContext
					.getMessage(AppConstants.INDICATOR4_USERPROFILE,
							null, locale));
		}

	}

	@SuppressWarnings(AppConstants.UNCHECKED)
	@RequestMapping(value = AppConstants.USERPROFILE_REQ_CHGROLE, method = RequestMethod.GET)
	public ModelAndView changeRole(final HttpServletRequest request)
	throws RMDWebException, Exception {
		rmdWebLogger.debug("changeRole():START");
		
		final HttpSession session = request.getSession(false);
		ModelAndView modelAndView = null;
		
		Map<String, String> componentList = new HashMap<String, String>();
		componentList.put(AppConstants.USERPREFERENCE_TIMEZONE,
				AppConstants.PREFERENCE_TIMEZONE_PRIVILEGES);
		componentList.put(AppConstants.PREFERENCE_DROPDOWN_PRIVILEGES,
				AppConstants.PREFERENCE_DROPDOWN_PRIVILEGES_VAR);
		componentList.put(AppConstants.CREATE_CASE_PRIVILEGES,
				AppConstants.CREATE_CASE_SOLN_PRIVILEGE);
		componentList.put(AppConstants.PROFILE_DROPDOWN_PRIVILEGES,
				AppConstants.PROFILE_DROPDOWN_PRIVILEGES_VAR);
		componentList.put(AppConstants.NOTIFICATION_PRIVILEGES,
				AppConstants.NOTIFICATION_PRIVILEGES_VAR);
		//Added as part of MISC Story -Start
		componentList.put(AppConstants.USERPREFERENCE_LANGUAGE,
				AppConstants.PREFERENCE_LANGUAGE_PRIVILEGES);
		componentList.put(AppConstants.USERPREFERENCE_ROLE,
				AppConstants.PREFERENCE_ROLE_PRIVILEGES);
		componentList.put(AppConstants.USERPREFERENCE_UOM,
				AppConstants.PREFERENCE_UOM);
		//Added as part of MISC Story -End
		componentList.put(AppConstants.CASE_MANAGEMENT_PRIVILEGE,AppConstants.IS_CASE_MGMT_PRIVILEGE);		
		
		//Added as part of Locovision Aurizon project 
		componentList.put(AppConstants.LOCO_VISION_PRIVILEGE,AppConstants.IS_LOCO_VISION_PRIVILEGE);	
		
		componentList.put(AppConstants.ASSET_PANEL_BUTTON,AppConstants.IS_ASSET_PANEL_PRIVILEGE);
		
		// Added to display ticker section
		componentList.put(AppConstants.TICKER_SECTION_DISPLAY_PRIVILEGE,AppConstants.IS_TICKER_SECTION_DISPLAY);	
		
		//Added as part of US251801:Rx Update Workflow - Migrate this process within EoA/OMD - Ryan & Todd
		componentList.put(AppConstants.RX_CHANGE_ADMIN_PRIVILEGE,AppConstants.IS_RX_CHANGE_ADMIN_PRIVILEGE);
		
		//Added as part of US248553: Customers: Leverage Mobile App simplification for Health Check on Portal by Raj.S(212687474)
		componentList.put(AppConstants.NOTIFICATION_RDR,AppConstants.IS_NOTIFICATION_RDR);
				
		final UserVO userVO = (UserVO) session
		.getAttribute(AppConstants.ATTR_USER_OBJECT);

		try {
			modelAndView = new ModelAndView(AppConstants.VIEW_HOME);
			if (userVO.getRolesVOLst() != null) {
				rmdWebLogger
				.debug("UserProfileController changeRole(): Roles ");
				final List<RolesVO> roles = userVO.getRolesVOLst();
				modelAndView.addObject(AppConstants.USERPROFILE_ROLES, roles);
				modelAndView.addObject(AppConstants.USERPROFILE_DEFAULTROLE,
						userVO.getRoleId());

			} else {
				rmdWebLogger
				.debug("UserProfileController changeRole(): No Roles");
				modelAndView = new ModelAndView(AppConstants.VIEW_HOME);
			}


			/*
			 * ************* Privilege Part Starts
			 * *************************************
			 */
			// Invoke authorizationServI service to get mENU based on User
			// RoleID :START
			final Map<String, ResourceVO> primaryNavMap = (Map<String, ResourceVO>) servletContext
			.getAttribute(AppConstants.PRI_NAV_MAP);
			final Map<String, List<ResourceVO>> secondaryNAvMap = (Map<String, List<ResourceVO>>) servletContext
			.getAttribute(AppConstants.TAB_DETAIL_MAP);

			Map<String, ResourceVO> priNavMapUdtedForARole = new LinkedHashMap<String, ResourceVO>();
			Map<String, List<ResourceVO>> secNavMapUdtedForARole = new LinkedHashMap<String, List<ResourceVO>>();
			Map<String, List<ResourceVO>> stickyTabSubTabMap = new LinkedHashMap<String, List<ResourceVO>>();
			Map<String, List<String>> utilityMap=new HashMap<String,List<String>>(); 
			ObjectMapper jsonMapper = new ObjectMapper();
			String jsonUtilityMap = "{}";
			MenuListResourceVO menuListResourceVO;
			boolean createCaseSolutionPrivilege = false;
			DateFormat  zoneFormater = null,zoneFormatDate=null;
			UserLoginBean userBean = new UserLoginBean();
			userBean.setUserVO(userVO);

			menuListResourceVO = getMenuListForARole(primaryNavMap,
					secondaryNAvMap, userBean);

			// set value in UserVO
			if (menuListResourceVO != null) {
				userVO.setSecNavLinks(menuListResourceVO
						.getSecNavigationLinks());
			}
			if (menuListResourceVO.getComponentList().size() != 0) {
				userVO.setComponentList(menuListResourceVO.getComponentList());
			} else {
				userVO.setComponentList(menuListResourceVO.getComponentList());
			}

			if (AppConstants.MENU_ACCESS_LEVEL_SHOW.equals(menuListResourceVO
					.getProfile())) {
				userVO.setProfile(menuListResourceVO.getProfile());
			} else {
				userVO.setProfile(AppConstants.MENU_ACCESS_LEVEL_HIDE);
			}
			if (AppConstants.MENU_ACCESS_LEVEL_SHOW.equals(menuListResourceVO
					.getPreferences())) {
				userVO.setPreferences(menuListResourceVO.getPreferences());
			} else {
				userVO.setPreferences(AppConstants.MENU_ACCESS_LEVEL_HIDE);
			}
			if (AppConstants.MENU_ACCESS_LEVEL_SHOW.equals(menuListResourceVO
					.getHeader())) {
				userVO.setHeader(menuListResourceVO.getHeader());
			} else {
				userVO.setHeader(AppConstants.MENU_ACCESS_LEVEL_HIDE);
			}

			if (userVO.getHeader() == null) {
				userVO.setHeader(AppConstants.MENU_ACCESS_LEVEL_HIDE);
			}

			if (null != menuListResourceVO) {
				priNavMapUdtedForARole = menuListResourceVO
				.getPriNavMapUdtedForARole();
				if(priNavMapUdtedForARole.containsKey("WELCOME")){
					Map<String, ResourceVO> newMapAuthorizedPriMapForARole = new LinkedHashMap<String, ResourceVO>(priNavMapUdtedForARole.size());
					ResourceVO valueIWantToBeFirst= priNavMapUdtedForARole.remove("WELCOME");
					newMapAuthorizedPriMapForARole.put("WELCOME", valueIWantToBeFirst);
					newMapAuthorizedPriMapForARole.putAll(priNavMapUdtedForARole); 
					priNavMapUdtedForARole.clear();
					priNavMapUdtedForARole.putAll(newMapAuthorizedPriMapForARole);
				}
				secNavMapUdtedForARole = menuListResourceVO
				.getSecNavMapUdtedForARole();
				stickyTabSubTabMap = menuListResourceVO
				.getSticySubNavigationList();
				if(RMDCommonUtility.isCollectionNotEmpty(menuListResourceVO.getUtilityList())){
					utilityMap=authorizationService.collectUtilities(priNavMapUdtedForARole,secNavMapUdtedForARole,stickyTabSubTabMap,menuListResourceVO.getUtilityList());
					jsonUtilityMap = jsonMapper.writeValueAsString(utilityMap);
				}
			}

			if (priNavMapUdtedForARole == null
					|| priNavMapUdtedForARole.isEmpty()) {
				request.setAttribute(AppConstants.ERRORMSG,
						AppConstants.ACCESS_DENIED_FOR_PRIVILEGES);
				rmdWebLogger
				.debug("UserProfileController changeRole(): No Privileges For Role");
				return new ModelAndView(AppConstants.VIEW_ACCESS_DENIED_PROFILE);
			}

			final String strPageZeroIndx = priNavMapUdtedForARole.keySet()
			.iterator().next();
			final String subPageIdxforHome = authorizationService
			.getSubPageIndexForHome(strPageZeroIndx, secondaryNAvMap);

			// method call to get the enabled components for logged in user
			getComponentPrivilege(componentList,userVO,request);
			String eoaUserName = userManagementService.getEoaUserName(userVO
					.getUserId());
			if (null != eoaUserName
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(eoaUserName)) {
				userVO.setCmAliasName(eoaUserName);
			}
			userVO.setCMPrivilege((Boolean) request
					.getAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE));
			if (userVO.getIsCMPrivilege()
					&& null == userVO.getCmAliasName()
					|| RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(userVO
							.getCmAliasName())) {
				throw new AuthorizationException(400,
						AppConstants.NO_EOA_USER_VALIDATION);
			}
			
			//Added as part of US248553: Customers: Leverage Mobile App simplification for Health Check on Portal
			//SOC Raj.S(212687474)
			userVO.setNotificationRDR((Boolean) request
					.getAttribute(AppConstants.IS_NOTIFICATION_RDR));
			//EOC
			
			//Added as part of Locovision Aurizon project 
			userVO.setLocoVisionPrivilege((Boolean) request
					.getAttribute(AppConstants.IS_LOCO_VISION_PRIVILEGE));	
			userVO.setAssetPanelPrivilege((Boolean) request
					.getAttribute(AppConstants.IS_ASSET_PANEL_PRIVILEGE));
			
			//Added to diaplay ticker section 
			userVO.setTickerSectionDisplay((Boolean) request
					.getAttribute(AppConstants.IS_TICKER_SECTION_DISPLAY));
			//Added as part of  US251801:Rx Update Workflow - Migrate this process within EoA/OMD - Ryan & Todd
			userVO.setRxChangeAdminPrivilege((Boolean) request
					.getAttribute(AppConstants.IS_RX_CHANGE_ADMIN_PRIVILEGE));
			/*
			 * Favorite Filter Service call to fetch all screen's favorite filter criteria.
			 */
			FavoriteFilterBean favoriteFilterBean=new FavoriteFilterBean();
			Long linkUserRoleSeqId=getLinkUsrRoleSeqId(userVO.getRolesVOLst(), userVO.getRoleId());
			favoriteFilterBean.setLinkUserRoleSeqId(linkUserRoleSeqId);
			userVO.setFilterDetail(favFilterService.fetchFavoriteFilter(favoriteFilterBean));
			/*
			 * Favorite Filter Service call to fetch all screen's favorite filter criteria.
			 */
			/*
			 * Product WS call for customerAssets
			 */
			CustomerAssetBean custAssetBean=new CustomerAssetBean();
			custAssetBean.setRoleName(RMDCommonUtil.getRoleName(userVO));
			userVO.setStrRole(custAssetBean.getRoleName());
			custAssetBean.setLanguage(userVO.getStrLanguage());
			custAssetBean.setUserFirstName(userVO.getStrFirstName());
			custAssetBean.setUserId(userVO.getUserId());
			custAssetBean.setUserLastName(userVO.getStrLastName());
			custAssetBean.setUserLanguage(userVO.getStrUserLanguage());	
			custAssetBean.setCustomerId(userVO.getCustomerId());
			List<String> products =loginService.getProductsForRole(custAssetBean);
			userVO.setProducts(products);
			/*
			 * Product WS call for customerAssets
			 */
			/*
			 * Added for dashboard button functionality starts
			 */
			boolean dashboarFlag = loginService.dashboardRoleFlagValue(userVO);
			if(dashboarFlag){
				session.setAttribute(AppConstants.DASHBOARD_BUTTON,RMDCommonConstants.STRING_TRUE);
			}
			else{
				session.setAttribute(AppConstants.DASHBOARD_BUTTON,RMDCommonConstants.STRING_FALSE);
			}
			session.setAttribute(AppConstants.STR_DASHBOARD_URL, dashboardUrl);
			/*
			 * Added for dashboard button functionality ends
			 */
			// Set variables to session
			session.setAttribute(AppConstants.ATTR_PRI_MAP,
					priNavMapUdtedForARole);
			session.setAttribute(AppConstants.ATTR_SEC_MAP,
					secNavMapUdtedForARole);
			session.setAttribute(AppConstants.STICKYTAB_SUBTAB,
					stickyTabSubTabMap);
			session.setAttribute(AppConstants.UTILITY_MAP,
					jsonUtilityMap);
			session.setAttribute(AppConstants.ATTR_HOME_PAGE, strPageZeroIndx);
			session.setAttribute(AppConstants.ATTR_SUB_PAGE, subPageIdxforHome);
			session.setAttribute(AppConstants.ATTR_USER_OBJECT, userVO);
			
			/* Begin of Changes for fetching customer Date format */
			zoneFormater = new SimpleDateFormat(AppConstants.TO_DATE_FORMAT, Locale.ENGLISH);
			if (cachedService.getSDCustLookup().get(userVO.getCustomerId()) != null
					&& cachedService.getSDCustLookup()
							.get(userVO.getCustomerId()).getDateFormat() != null
					&& !cachedService.getSDCustLookup()
							.get(userVO.getCustomerId()).getDateFormat().trim()
							.equals("")) {
				session.setAttribute(
						AppConstants.CUSTOMER_DATE_FORMAT,
						cachedService.getSDCustLookup()
								.get(userVO.getCustomerId()).getDateFormat()
								.replaceAll("HH", "hh"));
				zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat());
			} else {
				session.setAttribute(AppConstants.CUSTOMER_DATE_FORMAT,
						AppConstants.TO_DATE_FORMAT.replaceAll("HH", "hh"));
			}
			zoneFormatDate = new SimpleDateFormat(userVO.getLastLoginDateTimeFormat(), Locale.ENGLISH);
			Date dateFormat=zoneFormatDate.parse(userVO.getLastLoginDateTime());
			final String date = zoneFormater.format(dateFormat.getTime());
			userVO.setLastLoginDateTimeFormat(String.valueOf(session.getAttribute(AppConstants.CUSTOMER_DATE_FORMAT)));
			userVO.setLastLoginDateTime(date);
			/* End of Changes */

			modelAndView = new ModelAndView(AppConstants.LOGIN_SUCCESS);
			/*
			 * ************* Privilege Part Ends
			 * *************************************
			 */
			rmdWebLogger.debug("changeRole(): End");
			return modelAndView;
		} catch (AuthorizationException authEx) {
			rmdWebLogger.error(
					"AuthorizationException occured in changeRole() method ",
					authEx);

			if (AppConstants.NO_EOA_USER_VALIDATION.equalsIgnoreCase(authEx
					.getMessage())) {
				request.setAttribute(AppConstants.ERRORMSG,
						AppConstants.NO_EOA_USER_VALIDATION);
				return new ModelAndView(AppConstants.VIEW_ACCESS_DENIED);
			}else if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(authEx
					.getStatus())
					|| AppConstants.EXCEPTION_EOA_109.equalsIgnoreCase(authEx
							.getStatus())) {
				request.setAttribute(AppConstants.ERRORMSG,
						AppConstants.ACCESS_DENIED_FOR_PRIVILEGES);
				return new ModelAndView(AppConstants.VIEW_ACCESS_DENIED_PROFILE);
			} 		
			else {

				throw authEx;
			}
		} catch (RMDWebException rmdEx) {

			rmdWebLogger.error(
					"RMDWebException occured in changeRole() method ", rmdEx);
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(rmdEx
					.getStatus())
					|| AppConstants.EXCEPTION_EOA_109.equalsIgnoreCase(rmdEx
							.getMessage())
							|| AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(rmdEx
									.getErrorCode())) {
				request.setAttribute(AppConstants.ERRORMSG,
						AppConstants.ACCESS_DENIED_FOR_PRIVILEGES);
				return new ModelAndView(AppConstants.VIEW_ACCESS_DENIED_PROFILE);
			} else {
				throw rmdEx;
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in changeRole() method ", ex);
			throw ex;
		}
		

	}


	/**
	 * 
	 * @Author:
	 * @param primaryNavMap
	 * @param secondaryNAvMap
	 * @param userVO
	 * @return
	 * @throws Exception
	 * @throws RMDWebException
	 * @Description: return the list of menus available for the user role which
	 *               is in userVO object
	 */
	public MenuListResourceVO getMenuListForARole(
			final Map<String, ResourceVO> primaryNavMap,
			final Map<String, List<ResourceVO>> secondaryNAvMap,
			final UserLoginBean userBean) throws RMDWebException, Exception {

		final MenuListResourceVO menuListResourceVO = authorizationService
		.getPrivileges(primaryNavMap, secondaryNAvMap, userBean);
		return menuListResourceVO;
	}
}
