package com.ge.trans.rmd.common.exception;

public class RMDWebException extends Exception
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 
	 */
	//private static final long serialVersionUID = 1L;
	private int code;
 	private String message;
 	private String errorMessageOnUI;
 	private String errorType;
 	private String errorCode;
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(final String errorCode) {
		this.errorCode = errorCode;
	}
	private String language;
	private String status;
	public String getStatus() {
		return status;
	}
	public void setStatus(final String status) {
		this.status = status;
	}
	public String getErrorType() {
		return errorType;
	}
	public void setErrorType(final String errorType) {
		this.errorType = errorType;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(final String language) {
		this.language = language;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getErrorMessageOnUI() {
		return errorMessageOnUI;
	}
	public void setErrorMessageOnUI(final String errorMessageOnUI) {
		this.errorMessageOnUI = errorMessageOnUI;
	}
	public RMDWebException(final int status, final String errorMessage) {
		super(errorMessage);
		// TODO Auto-generated constructor stub
		this.code=status;
		this.message=errorMessage;
	}

	
	public RMDWebException(final String errorCode,final String errorMessage,final String errorType) {
        super(errorMessage);
        // TODO Auto-generated constructor stub
        
        this.errorCode = errorCode;
        this.message = errorMessage;
        this.errorType = errorType;
        this.status = errorCode;
  }
  

	
	public RMDWebException(final String errorCode,final String errorType) {
		// TODO Auto-generated constructor stub
		this.errorCode = errorCode; 
		this.errorType=errorType;
	}
	
	public int getCode() {
		return code;
	}
	public void setCode(final int code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(final String message) {
		this.message = message;
	}
	public RMDWebException()
	{
		super();
	}
	
	public RMDWebException(Exception e)
	{
		super(e);
	}
}
