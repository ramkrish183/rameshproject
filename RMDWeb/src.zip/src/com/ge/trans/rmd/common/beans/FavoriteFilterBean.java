package com.ge.trans.rmd.common.beans;

import java.util.HashMap;
import java.util.List;

import com.ge.trans.rmd.cm.valueobjects.CreateCasesVO;

/*******************************************************************************
 * 
 * @Author : Igate Patni
 * @Version : 1.0
 * @Date Created: Mar 12, 2012
 * @Date Modified :
 * @Modified By :
 * @Contact :
 * @Description :
 * @History :
 * 
 ******************************************************************************/

@SuppressWarnings("serial")
public class FavoriteFilterBean extends RMDBaseBean {

private String screenName;
private HashMap<String,String> columnType;
private HashMap<String,String> columnValue;
private Long linkUserRoleSeqId;
private String favFilterFlag;
private String filterId;

public String getFilterId() {
	return filterId;
}
public void setFilterId(String filterId) {
	this.filterId = filterId;
}
public String getFavFilterFlag() {
	return favFilterFlag;
}
public void setFavFilterFlag(String favFilterFlag) {
	this.favFilterFlag = favFilterFlag;
}
public String getScreenName() {
	return screenName;
}
public void setScreenName(String screenName) {
	this.screenName = screenName;
}
public HashMap<String, String> getColumnType() {
	return columnType;
}
public void setColumnType(HashMap<String, String> columnType) {
	this.columnType = columnType;
}
public HashMap<String, String> getColumnValue() {
	return columnValue;
}
public void setColumnValue(HashMap<String, String> columnValue) {
	this.columnValue = columnValue;
}
public Long getLinkUserRoleSeqId() {
	return linkUserRoleSeqId;
}
public void setLinkUserRoleSeqId(Long linkUserRoleSeqId) {
	this.linkUserRoleSeqId = linkUserRoleSeqId;
}

}
