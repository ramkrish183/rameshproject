package com.ge.trans.rmd.common.util;

import static com.ge.trans.rmd.common.util.AppConstants.ACCESS_LEVELS;
import static com.ge.trans.rmd.common.util.AppConstants.FIELD_TYPE;
import static com.ge.trans.rmd.common.util.AppConstants.FILTERFLAG;
import static com.ge.trans.rmd.common.util.AppConstants.LEVEL;
import static com.ge.trans.rmd.common.util.AppConstants.LEVEL_SEPERATOR;
import static com.ge.trans.rmd.common.util.AppConstants.MAX_RESOURCE_LEVELS;
import static com.ge.trans.rmd.common.util.AppConstants.RESOURCE_ID;
import static com.ge.trans.rmd.common.util.AppConstants.TYPE;
import static com.ge.trans.rmd.common.util.AppConstants.URL;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;

import org.apache.commons.digester.Digester;

import com.ge.trans.rmd.common.vo.ResourceVO;
import com.ge.trans.rmd.exception.RMDRunTimeException;
import com.ge.trans.rmd.logging.RMDLogger;
public class ResourceDigester {
	public static final RMDLogger LOG = RMDLogger
			.getLogger(ResourceDigester.class);
@SuppressWarnings("rawtypes")
private static Digester getConfiguredDigester(final Class clazz) {
		
		final Digester digester = new Digester();
		digester.setValidating(false);
		digester.setUseContextClassLoader(true);
	
		String levelString = AppConstants.EMPTY_STRING;
		final int maxMenulevels = MAX_RESOURCE_LEVELS;

		for (int i = 0; i < maxMenulevels; i++) { // NO_OF_LEVELS
			levelString = levelString + LEVEL + i;
			digester.addObjectCreate(levelString, clazz);
			digester.addSetProperties(levelString, RESOURCE_ID, RESOURCE_ID);
			digester.addSetProperties(levelString, TYPE, TYPE);
			digester.addSetProperties(levelString, FIELD_TYPE, FIELD_TYPE);
			digester.addSetProperties(levelString, ACCESS_LEVELS, ACCESS_LEVELS);
			digester.addSetProperties(levelString, URL, URL);
			digester.addSetProperties(levelString, FILTERFLAG, FILTERFLAG);
			if (i != 0) {
				digester.addSetNext(levelString,AppConstants.SET_CHILD);
				digester.addSetTop(levelString,AppConstants.SET_PARENT);
			}
			levelString = levelString + LEVEL_SEPERATOR;
		}

		return digester;
	}
	@SuppressWarnings("rawtypes")
	public static Object parse(final Object input, final Class clazz)   {
		Object object = null;
		InputStream xml = null;
		try {
			final Digester digester = getConfiguredDigester(clazz);
			if (input instanceof String) {
				xml = Thread.currentThread()
						.getContextClassLoader().getResourceAsStream((String) input);
				object = digester.parse(xml);
			} else if (input instanceof StringBuffer) {
				final Reader xmlReader = new StringReader(input.toString());
				object = digester.parse(xmlReader);
			}
		} catch (Exception t) {
			throw new RMDRunTimeException(t);
		}
		finally{
			try {
				xml.close();
			} catch (IOException e) {
				LOG.error("error in closing the stream "+e);
			}
		}
		return object;
	}
	
	public static ResourceVO getResources(final String resourceFile) {
		return (ResourceVO) parse(resourceFile,ResourceVO.class);
	}
}
