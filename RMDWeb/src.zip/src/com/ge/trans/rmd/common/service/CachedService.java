package com.ge.trans.rmd.common.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.alert.valueobjects.ModelVO;
import com.ge.trans.rmd.alert.valueobjects.RestrictedAlertShopVO;
import com.ge.trans.rmd.alert.valueobjects.ShopsVO;
import com.ge.trans.rmd.common.beans.UserLoginBean;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.pp.beans.MetricsBean;
import com.ge.trans.rmd.pp.valueobjects.CityRequestVO;
import com.ge.trans.rmd.pp.valueobjects.CityVO;
import com.ge.trans.rmd.pp.valueobjects.CustLookupVO;
import com.ge.trans.rmd.pp.valueobjects.FleetVO;
import com.ge.trans.rmd.pp.valueobjects.RegionVO;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.admin.valueobjects.SystemTimeZoneResponseType;
import com.ge.trans.rmd.services.authorization.valueobjects.RolePrivilegesType;

public interface CachedService {
	public abstract Map<String, SystemTimeZoneResponseType> getAllTimeZones()
			throws RMDWebException, Exception;

	public abstract List<RolePrivilegesType> getRolePrivileges(
			UserLoginBean paramUserLoginBean) throws RMDWebException, Exception;

	public abstract List<RolePrivilegesType> authorizeSecNav(
			UserLoginBean paramUserLoginBean) throws RMDWebException, Exception;

	public abstract Map<String, List<ApplicationParametersResponseType>> getAllLookupValues()
			throws GenericAjaxException, RMDWebException;

	public abstract Map<String, String> getCustomers()
			throws GenericAjaxException, RMDWebException, Exception;

	public abstract Map<String, List<String>> getPPCountryStates()
			throws GenericAjaxException, RMDWebException, Exception;

	public abstract Map<String, String> getAllSystemParameters()
			throws GenericAjaxException, RMDWebException, Exception;

	public abstract List<CityVO> getCityList(CityRequestVO cityRequestVO)
			throws GenericAjaxException, RMDWebException, Exception;

	public abstract List<String> getRoadInitials(String customerId)
			throws GenericAjaxException, RMDWebException, Exception;
	
	public abstract Map<String, ArrayList<FleetVO>> getAllFleets()
			throws GenericAjaxException, RMDWebException, Exception;

	public abstract Map<String, ArrayList<RegionVO>> getAllRegions() throws GenericAjaxException, RMDWebException, Exception;
	public Map<String, ArrayList<RestrictedAlertShopVO>> getRestrictedAlertShop() throws RMDWebException, Exception;
	
	public abstract Map<String, CustLookupVO> getSDCustLookup() throws RMDWebException, Exception;
	
	public Map<String, ArrayList<ShopsVO>> getAllShops() throws RMDWebException,Exception;
	
	public Map<String, String> getFaultOrigin() throws RMDWebException,Exception;
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, ArrayList<ModelVO>>
	 * @throws:RMDWebException,Exception
	 * @Description: This method is used for fetching the Model values for
	 *               particular Customer.
	 */
	public Map<String, ArrayList<ModelVO>> getAllModels() throws RMDWebException,Exception;
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, ArrayList<ModelVO>>
	 * @throws:RMDWebException,Exception
	 * @Description: This method is used for fetching the List of all controllers.
	 */
	public  Map<String,String> getAllControllers()
			throws GenericAjaxException, RMDWebException, Exception;
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, ArrayList<ModelVO>>
	 * @throws:RMDWebException,Exception
	 * @Description: This method is used for fetching the list of users who can create the notes
	 */
	public  Map<String,String> getNotesCreatersList()
			throws GenericAjaxException, RMDWebException, Exception;

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, List<ApplicationParametersResponseType>>
	 * @throws:RMDWebException,Exception
	 * @Description: This method is used for fetching the list of users
	 *               specified urgency.
	 */
	public Map<String, List<ApplicationParametersResponseType>> getCustomerBasedLookupValues(
			String customerId) throws GenericAjaxException, RMDWebException;
	
	
	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param  :
	 * @throws Exception 
	 * @throws :RMDWebException
	 * @Description: This method is used for fetching notify flags.
	 * 
	 */
	public Map<String,String> getNotifyFlags() throws RMDWebException, Exception;
	
	/**
	 * @Author :
	 * @return :String
	 * @param :AddNotifyConfigVO objAddNotifyConfigVO
	 * @throws Exception 
	 * @throws :RMDWebException
	 * @Description:This method is used for fetching Threshold  values.
	 * 
	 */
	public Map<String,String> getThreshold() throws RMDWebException, Exception;
	
	
	/**
	 * @Author :
	 * @return :Map<String, String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method will fetch list of state province.
	 * 
	 */
	public Map<String, String> getStateProvince() throws GenericAjaxException,
			RMDWebException, Exception;
	
	public  List<MetricsBean> getMetricsConversion()
			throws GenericAjaxException, RMDWebException, Exception ;

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, List<String>>
	 * @throws:RMDWebException,Exception
	 * @Description: This method is used for fetching the Customer Name and Road
	 *               Number Headers.
	 */
	public Map<String, List<String>> getCustNameRNH() throws RMDWebException,
			Exception;
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws Exception 
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the all controller configs
	 */
	public Map<String, String> getControllerConfigs() throws RMDWebException, Exception;

	/**
	 * 
	 * @param
	 * @return List<String>
	 * @throws RMDWebException
	 * @throws Exception 
	 * @Description This method is used to get the all country List
	 * 
	 */
	public List<String> getCountryList() throws RMDWebException, Exception;

	/**
	 * 
	 * @param String
	 *            country
	 * @return List<String>
	 * @throws RMDWebException
	 * @Description This method is used to get the states for the selected
	 *              Country
	 * 
	 */
	public List<String> getCountryStates(String country)
			throws RMDWebException, Exception;

	/**
	 * 
	 * @param String
	 *            country
	 * @return List<String>
	 * @throws RMDWebException
	 * @Description This method is used to get the time zones for the selected
	 *              Country
	 * 
	 */
	public abstract List<String> getCountryTimeZones(String country)
			throws RMDWebException, Exception;
	
	public Map<String, List<String>> getTruckVariablesParamList(String mineId, String truckId, boolean isAvgCalc) 
    		throws RMDWebException;

}
