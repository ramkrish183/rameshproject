package com.ge.trans.rmd.common.beans;
import com.ge.trans.rmd.common.beans.RMDBaseBean;

@SuppressWarnings("serial")
public class HeaderSearchBean extends RMDBaseBean {
	
	private String timeZone;
	private String searchString;
	private String requestURI;
	private String strCustomerId;
	private String searchTypeFlag;
	private boolean isGPOCUser;
	
	

	public boolean isGPOCUser() {
		return isGPOCUser;
	}

	public void setGPOCUser(boolean isGPOCUser) {
		this.isGPOCUser = isGPOCUser;
	}

	public String getStrCustomerId() {
		return strCustomerId;
	}

	public void setStrCustomerId(String strCustomerId) {
		this.strCustomerId = strCustomerId;
	}

	public String getRequestURI() {
		return requestURI;
	}

	public void setRequestURI(final String requestURI) {
		this.requestURI = requestURI;
	}

	public String getSearchString() {
		return searchString;
	}

	public void setSearchString(final String searchString) {
		this.searchString = searchString;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(final String timeZone) {
		this.timeZone = timeZone;
	}

	public String getSearchTypeFlag() {
		return searchTypeFlag;
	}

	public void setSearchTypeFlag(String searchTypeFlag) {
		this.searchTypeFlag = searchTypeFlag;
	}

}




