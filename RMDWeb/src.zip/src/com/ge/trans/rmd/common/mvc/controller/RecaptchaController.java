/**
 /**
 * ============================================================
 * Classification: GE Confidential
 * File : RecaptchaController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.mvc.controller;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on : February 14, 2012
 * History
 * Modified By : iGATE
 *
 * Copyright (C) 2012 General Electric Company. All rights reserved
 *
 * ============================================================
 */

package com.ge.trans.rmd.common.mvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.trans.rmd.common.util.AppConstants;

@Controller
public class RecaptchaController {

	/**
	 * @Description:This method is used to call the Recaptcha api webservices to
	 *                   check the answer.
	 * @return:Boolean
	 * @param:HttpServletRequest request
	 */

	@Value("${" +AppConstants.PROXY_HOST  + "}")
	String PROXY_HOST;
	@Value("${" + AppConstants.PROXY_PORTNUMBER + "}")
	String PROXY_PORTNUMBER;

	@RequestMapping(value = AppConstants.RECAPTCHA, method = RequestMethod.POST)
	public @ResponseBody
	Boolean checkRecaptcha(HttpServletRequest request) {

		//System.getProperties().put("http.proxyHost", PROXY_HOST);
		//System.getProperties().put("http.proxyPort",PROXY_PORTNUMBER);
		/*String remoteAddress = request.getRemoteAddr();
		ReCaptchaImpl reCaptchaImpl = new ReCaptchaImpl();
		reCaptchaImpl.setPrivateKey(AppConstants.RECAPTCHA_PRIVATE_KEY);
		String strRecaptchaChallenge = request
				.getParameter(AppConstants.RECAPTCHA_CHALLENGE_FIELD);
		String strRecaptchaResponse = request
				.getParameter(AppConstants.RECAPTCHA_RESPONSE_FIELD);

		ReCaptchaResponse reCaptchaResponse = reCaptchaImpl.checkAnswer(
				remoteAddress, strRecaptchaChallenge, strRecaptchaResponse);
		if (reCaptchaResponse.isValid()) {
			return true;
		} else {
			return false;
		}*/
		return false;

	}

}