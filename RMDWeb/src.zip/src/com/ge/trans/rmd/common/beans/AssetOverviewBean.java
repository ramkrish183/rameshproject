package com.ge.trans.rmd.common.beans;

import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/*******************************************************************************
 * 
 * @Author : Igate Patni
 * @Version : 1.0
 * @Date Created: Feb 01, 2012
 * @Date Modified :
 * @Modified By :
 * @Contact :
 * @Description :
 * @History :
 * 
 ******************************************************************************/
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
@SuppressWarnings("serial")
public class AssetOverviewBean extends RMDBaseBean {
	private String asset;
	private String roadIntial;
	private String customer;
	private String fleet;
	private String model;
	private String controllerConfig;
	private String antennaModel;
	private String softwareVersion;
	private String lCWarrentyEnd;
	private String services;
	private List<CaseBean> caselist;
	private String lastFaultResetTime;	
	private String lastFaultReceived;
	private String lastHealthCheckResponse;
	private String lastKeepAliveMsgReceived;
	private String lstFltRstTme;
	private String lstFltRecvd;
	private String lstHlthChkRes;
	private String lastMsgRecvd;
	private List<NotesBean> notesList;
	private String urgencyCode;
	private String userTimeZone;
	private String assetGroup;
	private String notesType;
	private String noDays;
	private String dsControllerConfig;
	private XMLGregorianCalendar fromDate;
	private XMLGregorianCalendar toDate;
	private String fleetId;
	private String modelId;	
	private boolean isLastFault;
	private String assetObjid;	
	private String lmsLocoId;
	private String timeZoneCode;
	private String badActor;
	private String vehicleObjId;
	private String isNonGPOCUser;
	private String defaultTimeZone;
	private boolean hideL3Fault;
	private long assetGrpHdrNo;
	
	public String getDefaultTimeZone() {
		return defaultTimeZone;
	}
	public void setDefaultTimeZone(String defaultTimeZone) {
		this.defaultTimeZone = defaultTimeZone;
	}
	public String getTimeZoneCode() {
		return timeZoneCode;
	}
	public void setTimeZoneCode(String timeZoneCode) {
		this.timeZoneCode = timeZoneCode;
	}
	
	public String getLmsLocoId() {
		return lmsLocoId;
	}
	public void setLmsLocoId(String lmsLocoId) {
		this.lmsLocoId = lmsLocoId;
	}
	public String getAssetObjid() {
		return assetObjid;
	}
	public void setAssetObjid(String assetObjid) {
		this.assetObjid = assetObjid;
	}
	public boolean isLastFault() {
		return isLastFault;
	}
	public void setLastFault(boolean isLastFault) {
		this.isLastFault = isLastFault;
	}
	public XMLGregorianCalendar getFromDate() {
		return fromDate;
	}
	public void setFromDate(XMLGregorianCalendar fromDate) {
		this.fromDate = fromDate;
	}
	public XMLGregorianCalendar getToDate() {
		return toDate;
	}
	public void setToDate(XMLGregorianCalendar toDate) {
		this.toDate = toDate;
	}
	public String getModelId() {
		return modelId;
	}
	public void setModelId(String modelId) {
		this.modelId = modelId;
	}
	public String getFleetId() {
		return fleetId;
	}
	public void setFleetId(String fleetId) {
		this.fleetId = fleetId;
	}
	public String getDsControllerConfig() {
		return dsControllerConfig;
	}
	public void setDsControllerConfig(String dsControllerConfig) {
		this.dsControllerConfig = dsControllerConfig;
	}
	public String getNoDays() {
		return noDays;
	}
	public void setNoDays(final String noDays) {
		this.noDays = noDays;
	}
	/**
	 * 
	 * @return the asset group name
	 */
	public String getAssetGroup() {
		return assetGroup;
	}
	/**
	 * 
	 * @param assetGroup
	 *            the assetGroup to set
	 */
	public void setAssetGroup(final String assetGroup) {
		this.assetGroup = assetGroup;
	}

	public String getUserTimeZone() {
		return userTimeZone;
	}

	public void setUserTimeZone(final String userTimeZone) {
		this.userTimeZone = userTimeZone;
	}

	/**
	 * 
	 * @return the asset number
	 */
	public String getAsset() {
		return asset;
	}

	public boolean isHideL3Fault() {
		return hideL3Fault;
	}
	public void setHideL3Fault(boolean hideL3Fault) {
		this.hideL3Fault = hideL3Fault;
	}
	/**
	 * 
	 * @param asset
	 *            the asset to set
	 */
	public void setAsset(final String asset) {
		this.asset = asset;
	}

	/**
	 * 
	 * @return the roadIntial
	 */
	public String getRoadIntial() {
		return roadIntial;
	}

	/**
	 * 
	 * @param roadIntial
	 *            the roadIntial to set
	 */
	public void setRoadIntial(final String roadIntial) {
		this.roadIntial = roadIntial;
	}

	/**
	 * 
	 * @return the customer
	 */
	public String getCustomer() {
		return customer;
	}

	/**
	 * 
	 * @param customer
	 *            the customer to set
	 */
	public void setCustomer(final String customer) {
		this.customer = customer;
	}

	/**
	 * 
	 * @return the fleet
	 */
	public String getFleet() {
		return fleet;
	}

	/**
	 * 
	 * @param fleet
	 *            the fleet to set
	 */
	public void setFleet(final String fleet) {
		this.fleet = fleet;
	}

	/**
	 * 
	 * @return the model
	 */
	public String getModel() {
		return model;
	}

	/**
	 * 
	 * @param model
	 *            the model to set
	 */
	public void setModel(final String model) {
		this.model = model;
	}

	/**
	 * 
	 * @return the controllerConfig
	 */
	public String getControllerConfig() {
		return controllerConfig;
	}

	/**
	 * 
	 * @param controllerConfig
	 *            the controllerConfig to set
	 */
	public void setControllerConfig(final String controllerConfig) {
		this.controllerConfig = controllerConfig;
	}

	/**
	 * 
	 * @return the antennaModel
	 */
	public String getAntennaModel() {
		return antennaModel;
	}

	/**
	 * 
	 * @param antennaModel
	 *            the antennaModel to set
	 */
	public void setAntennaModel(final String antennaModel) {
		this.antennaModel = antennaModel;
	}

	/**
	 * 
	 * @return the softwareVersion
	 */
	public String getSoftwareVersion() {
		return softwareVersion;
	}

	/**
	 * 
	 * @param softwareVersion
	 *            the softwareVersion to set
	 */
	public void setSoftwareVersion(final String softwareVersion) {
		this.softwareVersion = softwareVersion;
	}

	/**
	 * 
	 * @return the lcWarrentyEnd
	 */
	public String getlCWarrentyEnd() {
		return lCWarrentyEnd;
	}

	/**
	 * 
	 * @param lCWarrentyEnd
	 *            the lcWarrenty to set
	 */
	public void setlCWarrentyEnd(final String lCWarrentyEnd) {
		this.lCWarrentyEnd = lCWarrentyEnd;
	}

	/**
	 * 
	 * @return the services
	 */
	public String getServices() {
		return services;
	}

	/**
	 * 
	 * @param services
	 *            the services to set
	 */
	public void setServices(final String services) {
		this.services = services;
	}

	/**
	 * 
	 * @return the caseList
	 */
	public List<CaseBean> getCaselist() {
		return caselist;
	}

	/**
	 * 
	 * @param caselist
	 *            the caseList to set
	 */
	public void setCaselist(final List<CaseBean> caselist) {
		this.caselist = caselist;
	}

	/**
	 * 
	 * @return the lastFaultResetTime
	 */
	public String getLastFaultResetTime() {
		return lastFaultResetTime;
	}

	/**
	 * 
	 * @param lastFaultResetTime
	 *            the lastFaultResetTime to set
	 */
	public void setLastFaultResetTime(final String lstFltRstTme) {
		this.lastFaultResetTime = lstFltRstTme;
	}

	/**
	 * 
	 * @return the lastFaultReceived
	 */
	public String getLastFaultReceived() {
		return lastFaultReceived;
	}

	/**
	 * 
	 * @param lastFaultReceived
	 *            the lastFaultReceived to set
	 */
	public void setLastFaultReceived(final String lstFltRecvd) {
		this.lastFaultReceived = lstFltRecvd;
	}

/*	*//**
	 * 
	 * @return the lastHealthCheckResponse
	 *//*
	public String getLastHealthCheckResponse() {
		return lastHealthCheckResponse;
	}

	*//**
	 * 
	 * @param lastHealthCheckResponse
	 *            the lastHealthCheckResponse to set
	 *//*
	public void setLastHealthCheckResponse(final String lstHlthChkRes) {
		this.lastHealthCheckResponse = lstHlthChkRes;
	}*/
	
	/**
	 * 
	 * @return lastHealthCheckResponse
	 */
	public String getLastHealthCheckResponse() {
		return lastHealthCheckResponse;
	}
	
	/**
	 * 
	 * @param lastHealthCheckResponse
	 */
	public void setLastHealthCheckResponse(String lastHealthCheckResponse) {
		this.lastHealthCheckResponse = lastHealthCheckResponse;
	}

	/**
	 * 
	 * @return the lastKeepAliveMsgReceived
	 */
	public String getLastKeepAliveMsgReceived() {
		return lastKeepAliveMsgReceived;
	}

	/**
	 * 
	 * @param lastKeepAliveMsgReceived
	 *            the lastKeepAliveMsgReceived to set
	 */
	public void setLastKeepAliveMsgReceived(final String lastMsgRecvd) {
		this.lastKeepAliveMsgReceived = lastMsgRecvd;
	}

	/**
	 * 
	 * @return the notesList
	 */
	public List<NotesBean> getNotesList() {
		return notesList;
	}

	/**
	 * 
	 * @param notesList
	 *            the notesList to set
	 */
	public void setNotesList(final List<NotesBean> notesList) {
		this.notesList = notesList;
	}

	/**
	 * 
	 * @return the urgencyCode
	 */
	public String getUrgencyCode() {
		return urgencyCode;
	}

	/**
	 * 
	 * @param urgencyCode
	 *            the urgencyCode to set
	 */
	public void setUrgencyCode(final String urgencyCode) {
		this.urgencyCode = urgencyCode;
	}
	public String getNotesType() {
		return notesType;
	}
	public void setNotesType(String notesType) {
		this.notesType = notesType;
	}
	/**
	 * return the values class fields.
	 */
	@Override
	public String toString() {

		return "Asset:" + asset + ", roadIntial:" + roadIntial + ", Customer:"
				+ customer + ", Fleet:" + fleet + ", Model:" + model + ", "
				+ "ContollerConfig:" + controllerConfig + ", Antenna Model:"
				+ antennaModel + ", SoftwareVersion:" + softwareVersion + ", "
				+ "LCWarrentyEnd:" + lCWarrentyEnd + ", Services:" + services
				+ ", LastFaultResetTime:"
				+ lastFaultResetTime + ", " + "LastFaultReceivedTime:" + lastFaultReceived
				+ ", LastHealthCheckResponse:" + lastHealthCheckResponse
				+ ", LastKeepAliveMsgReceived" + lastKeepAliveMsgReceived + ", "
				+ "Urgency Code:"
				+ urgencyCode;
	}
	public String getLstFltRstTme() {
		return lstFltRstTme;
	}
	public void setLstFltRstTme(String lstFltRstTme) {
		this.lstFltRstTme = lstFltRstTme;
	}
	public String getLstFltRecvd() {
		return lstFltRecvd;
	}
	public void setLstFltRecvd(String lstFltRecvd) {
		this.lstFltRecvd = lstFltRecvd;
	}
	public String getLstHlthChkRes() {
		return lstHlthChkRes;
	}
	public void setLstHlthChkRes(String lstHlthChkRes) {
		this.lstHlthChkRes = lstHlthChkRes;
	}
	public String getLastMsgRecvd() {
		return lastMsgRecvd;
	}
	public void setLastMsgRecvd(String lastMsgRecvd) {
		this.lastMsgRecvd = lastMsgRecvd;
	}
	public String getBadActor() {
		return badActor;
	}
	public void setBadActor(String badActor) {
		this.badActor = badActor;
	}
	public String getVehicleObjId() {
		return vehicleObjId;
	}
	public void setVehicleObjId(String vehicleObjId) {
		this.vehicleObjId = vehicleObjId;
	}
	public String getIsNonGPOCUser() {
		return isNonGPOCUser;
	}
	public void setIsNonGPOCUser(String isNonGPOCUser) {
		this.isNonGPOCUser = isNonGPOCUser;
	}
    public long getAssetGrpHdrNo() {
        return assetGrpHdrNo;
    }
    public void setAssetGrpHdrNo(long assetGrpHdrNo) {
        this.assetGrpHdrNo = assetGrpHdrNo;
    }
    
	
	
	
	
	
}
