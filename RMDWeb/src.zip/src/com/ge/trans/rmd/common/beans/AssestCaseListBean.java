package com.ge.trans.rmd.common.beans;

import java.util.List;

public class AssestCaseListBean   extends RMDBaseBean {
	
	private List <CaseBean> openCaseList;
	
	private List <CaseBean> deliveredCaseList;
	
	private List <CaseBean> closeCaseList;

	public List<CaseBean> getOpenCaseList() {
		return openCaseList;
	}

	public void setOpenCaseList(List<CaseBean> openCaseList) {
		this.openCaseList = openCaseList;
	}

	public List<CaseBean> getDeliveredCaseList() {
		return deliveredCaseList;
	}

	public void setDeliveredCaseList(List<CaseBean> deliveredCaseList) {
		this.deliveredCaseList = deliveredCaseList;
	}

	public List<CaseBean> getCloseCaseList() {
		return closeCaseList;
	}

	public void setCloseCaseList(List<CaseBean> closeCaseList) {
		this.closeCaseList = closeCaseList;
	}

}
