package com.ge.trans.rmd.common.beans;

public class MassApplyRxVO {

}
