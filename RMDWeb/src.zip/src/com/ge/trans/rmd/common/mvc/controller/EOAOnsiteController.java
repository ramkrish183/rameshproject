package com.ge.trans.rmd.common.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ge.trans.rmd.common.beans.UserManagementBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.service.UserManagementService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.CustomerVO;
import com.ge.trans.rmd.common.vo.RolesVO;
import com.ge.trans.rmd.common.vo.UserVO;

@Controller
public class EOAOnsiteController extends RMDBaseController{
	@Autowired
	private UserManagementService userManagementService;

	@Autowired
	private AuthorizationService authService;
	
	@Autowired
	private ApplicationContext appContext;

	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	/**
	 * @Author:iGATE
	 * @param request
	 * @return String
	 * @Description: method to get user management page
	 */
	@RequestMapping(value = AppConstants.REQ_URI_EOA_ONSITE_MANAGEMENT, method = RequestMethod.GET)
	public String getuserManagementPage(final HttpServletRequest request)
			throws Exception {
		logger.debug("EOAOnsiteController Controller : getuserManagementPage() method Starts");
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		List<UserManagementBean> userMgmntBeanList = new ArrayList<UserManagementBean>();
		final UserManagementBean userMgmntBean = new UserManagementBean();
		final UserManagementBean userMgmntCompPrivBean = new UserManagementBean();
		String addUserCompName = null;
		String editUserCompName = null;
		boolean addComp = false;
		boolean editComp = false;
		String addEditEOAAliasMlCompName=AppConstants.EMPTY_STRING;
		boolean blnAddEditEOAAliasMl = false;
		List<String> customerList =  new ArrayList<String>();
		try {
			if((userVO.getCustomerList() != null && !(userVO.getCustomerList().size()< 0)) && !userVO.isAllCustomer()){
				for(CustomerVO customer: userVO.getCustomerList()){
					customerList.add(customer.getCustomerID());
					}
				userMgmntBean.setCustomerIdList(customerList);
			}
			userMgmntBean.setUserType(AppConstants.CUSTOMER);
			userMgmntBeanList = userManagementService.getUsers(userMgmntBean);
			addUserCompName = authService
					.getLookUpValueForName(AppConstants.USERMANAGEMENT_EOA_ONSITE_ADDUSER);
			editUserCompName = authService
					.getLookUpValueForName(AppConstants.USERMANAGEMENT_EOA_ONSITE_EDITUSER);

			addComp = RMDCommonUtil.componentValue(userVO.getComponentList(),
					addUserCompName);
			editComp = RMDCommonUtil.componentValue(userVO.getComponentList(),
					editUserCompName);

			userMgmntCompPrivBean.setAddUserComponent(addComp);
			userMgmntCompPrivBean.setEditUserComponent(editComp);

			/* Added by Mural for MDSC Admin changes*/
			addEditEOAAliasMlCompName = authService
					.getLookUpValueForName(AppConstants.MDSC_ADMIN_PRIVILEGE);
			blnAddEditEOAAliasMl = RMDCommonUtil.componentValue(userVO.getComponentList(),
					addEditEOAAliasMlCompName);
			userMgmntCompPrivBean.setBlnMDSCUser(blnAddEditEOAAliasMl);
			/*End of MDSC Admin*/
			
			/*Added by Murali Medicherla for Rally Id : US226051 */
			//If we want to support multiple roles add values in comma separated format and split here
			String roleName = authService.getLookUpValueForName(AppConstants.MOBILE_ACCESS_PRIVILEGE_ROLES);
			if(roleName != null && !roleName.trim().equals("")){
				for(RolesVO roleVO : userVO.getRolesVOLst()){
					if(roleVO.getGetUsrRolesSeqId().intValue() == userVO.getRoleId().intValue() && (roleName.equalsIgnoreCase(roleVO.getRoleName()) 
							|| roleName.equalsIgnoreCase(roleVO.getRoleDesc()) )){
						userMgmntCompPrivBean.setMobileAccessPrivilege(true);
						break;
					}
				}
			}
			/*Added by Murali Medicherla for Mobile Authentication */
			request.setAttribute(AppConstants.USER_MGMNT_LIST,
					userMgmntBeanList);
			request.setAttribute(AppConstants.USER_MGMNT_COMPONENT_BEAN,
					userMgmntCompPrivBean);
			request.setAttribute(AppConstants.USER_MGMNT_DEFAULT_ROLES,
					userVO.getRolesVOLst());
			request.setAttribute(AppConstants.IS_ALL_CUSTOMER,
					userVO.isAllCustomer());
			//adding for pagination
			request.setAttribute(
					AppConstants.ADMINISTRATOR_DEFAULT_RECORDS,
					findNumberOfRecords(AppConstants.ADMINISTRATOR_TABLE_DEFAULT_RECORDS));
		} catch (Exception ex) {
			logger.error("Exception occured in EOA Onsite getuserManagementPage method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("EOAOnsiteController Controller : getuserManagementPage() method Ends");
		return AppConstants.EOA_ONSITE_MANAGEMENT;
	}


	/**
	 * @Description:This method is used to  export the user list from the user Management page
	 * @return: void
	 * @param:HttpServletRequest request,HttpServletResponse response,Locale
	 *                           locale
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 */
	@RequestMapping(value = AppConstants.EXPORT_EOAONSITE_USERS, method = RequestMethod.POST)
	public void exportUserManagementPage(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws IOException, GenericAjaxException, RMDWebException {
		List<UserManagementBean> userMgmntBeanList = new ArrayList<UserManagementBean>();
		final UserManagementBean userMgmntBean = new UserManagementBean();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		List<String> customerList =  new ArrayList<String>();

		try {
			if((userVO.getCustomerList() != null && !(userVO.getCustomerList().size()< 0)) && !userVO.isAllCustomer()){
				for(CustomerVO customer: userVO.getCustomerList()){
					customerList.add(customer.getCustomerID());
					}
				userMgmntBean.setCustomerIdList(customerList);
			}
			userMgmntBean.setUserType(AppConstants.CUSTOMER);
			userMgmntBeanList = userManagementService.getUsers(userMgmntBean);
			csvContent = convertToCSVUsers(userMgmntBeanList, locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.USER_MANAGEMENT_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);

			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);

			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (Exception ex) {
			logger.error("Exception occured in getLifeStatisticsData method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}
		}
	}

	/**
	 * @Description:This method is used convert User management List into csv format
	 * @return: String
	 * @param:List<UserManagementBean> userMgmntBeanList, Locale locale
	 */
	private String convertToCSVUsers(
			List<UserManagementBean> userMgmntBeanList, Locale locale) {
		String csvContent = null;
		StringBuffer strBufferAssetHeader = new StringBuffer();
		try {
			strBufferAssetHeader.append(appContext.getMessage(
					AppConstants.USER_MANAGEMENT_HEADER, null, locale));
			strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			for (UserManagementBean userMgmntList : userMgmntBeanList) {
				strBufferAssetHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE + userMgmntList.getUserId()
						+ AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR);
				if (null != userMgmntList.getStrFirstName()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ userMgmntList.getStrFirstName()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != userMgmntList.getStrLastName()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ userMgmntList.getStrLastName()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != userMgmntList.getEmailId()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ userMgmntList.getEmailId()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != userMgmntList.getLastUpdatedBy()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ userMgmntList.getLastUpdatedBy()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != userMgmntList.getLastUpdatedTime()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ userMgmntList.getLastUpdatedTime()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				strBufferAssetHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE);
				if (null != userMgmntList.getRoles()) {
					Map<String, String> roles = userMgmntList.getRoles();
					String roles2 = "";
					if (null != userMgmntList.getStrRole()) {
						roles2 = userMgmntList.getStrRole()
								+ RMDCommonConstants.COMMMA_SEPARATOR;
					}
						for (String role : roles.values()) {
							if(null !=role && !role.equals(userMgmntList.getStrRole()) ) {
								roles2 = roles2 + role
										+ RMDCommonConstants.COMMMA_SEPARATOR;
							}
						}
						if(roles2.length()>0){
							strBufferAssetHeader.append(roles2.substring(0,
									roles2.length() - 1));
						}
						
					
				}
				strBufferAssetHeader.append(AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR);
				if (null != userMgmntList.getUserCustomers() && userMgmntList
						.getUserCustomers().length() != 0
						&& !userMgmntList.getUserCustomers().equalsIgnoreCase(
								RMDCommonConstants.ALL_CUSTOMER)) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ userMgmntList.getUserCustomers()
							+ AppConstants.QUOTE);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ AppConstants.ALL_CUSTOMERS + AppConstants.QUOTE);
				}
				if (userMgmntList.getStatus().equalsIgnoreCase(
						AppConstants.ACCOUNT_STATUS_ENABLED)) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.ENABLED + AppConstants.QUOTE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.DISABLED
									+ AppConstants.QUOTE);
				}
				if (null != userMgmntList.getUserType() && userMgmntList
						.getUserType().length() != 0) {
					strBufferAssetHeader.append(RMDCommonConstants.COMMMA_SEPARATOR
							+ AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ userMgmntList.getUserType()
							+ AppConstants.QUOTE);
				} else {
					strBufferAssetHeader.append(RMDCommonConstants.COMMMA_SEPARATOR
							+ AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE);
				}
				strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBufferAssetHeader.toString();
		} catch (Exception exception) {
			logger.error("Export to CSV User Mangement"
					+ exception.getMessage());
		}
		return csvContent;
	}
}
