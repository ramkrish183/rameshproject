/**
 * 
 */
package com.ge.trans.rmd.common.beans;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

/**
 * @author 501872812
 *
 */
public class RMDBaseBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String language;
	private String userId;
	private String userFirstName;
	private String userLastName;
	private String userLanguage;
	private String cmAliasName;
	private List<String> products;
	private String usrTimeZone;
	
	
	
	public String getUsrTimeZone() {
		return usrTimeZone;
	}
	public void setUsrTimeZone(String usrTimeZone) {
		this.usrTimeZone = usrTimeZone;
	}
	/**
	 * @return the cmAliasName
	 */
	public String getCmAliasName() {
		return cmAliasName;
	}
	/**
	 * @param cmAliasName the cmAliasName to set
	 */
	public void setCmAliasName(String cmAliasName) {
		this.cmAliasName = cmAliasName;
	}
	public List<String> getProducts() {
		return products;
	}
	public void setProducts(List<String> products) {
		this.products = products;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(final String language) {
		this.language = language;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(final String userId) {
		this.userId = userId;
	}
	public String getUserFirstName() {
		return userFirstName;
	}
	public void setUserFirstName(final String userFirstName) {
		this.userFirstName = userFirstName;
	}
	public String getUserLastName() {
		return userLastName;
	}
	public void setUserLastName(final String userLastName) {
		this.userLastName = userLastName;
	}
	public String getUserLanguage() {
		return userLanguage;
	}
	public void setUserLanguage(final String userLanguage) {
		this.userLanguage = userLanguage;
	}
	
	

}
