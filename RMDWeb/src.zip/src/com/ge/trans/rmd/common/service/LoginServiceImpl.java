/**
 * ============================================================
 * File : LoginServiceImpl.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.service
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Nov 17, 2011
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.common.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.FFDDetailsVO;
import com.ge.trans.rmd.common.beans.CustomerAssetBean;
import com.ge.trans.rmd.common.beans.UserLoginBean;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.AuthenticationException;
import com.ge.trans.rmd.common.exception.AuthorizationException;
import com.ge.trans.rmd.common.exception.OMDException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.vo.CustomerVO;
import com.ge.trans.rmd.common.vo.RolesVO;
import com.ge.trans.rmd.common.vo.UserPreferenceVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.admin.valueobjects.UserRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.ConfigRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.Customer;
import com.ge.trans.rmd.services.assets.valueobjects.ProductResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CmPrivilegeResponseType;
import com.ge.trans.rmd.services.security.valueobjects.LoginResponse;
import com.ge.trans.rmd.services.security.valueobjects.PreferencesType;
import com.ge.trans.rmd.services.security.valueobjects.RolesType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

/*******************************************************************************
 *
 * @Author 		: 
 * @Version 	: 1.0
 * @Date Created: Dec 20, 2011
 * @Date Modified : 
 * @Modified By : 
 * @Contact 	:
 * @Description : Service class which will invoke the web service to authenticate the user.
 *                Convert the web service response(JAXB) to UserVO which will contain the details
 *                about the authenticated user like roles,preferences etc.     
 * @History		:
 *
 ******************************************************************************/
@Service
public class LoginServiceImpl extends RMDBaseServiceImpl implements LoginService {

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
	.getLogger(getClass());

	@Autowired WebServiceInvoker webServiceInvoker;


	/**
	 * @Author: 
	 * @param loginForrm
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description:  This method  invokes the web service to authenticate the user.
	 *                Convert the web service response(JAXB) to UserVO which will contain the details
	 *                about the authenticated user like roles,preferences etc.
	 */
	@Override
	public void authenticate(final UserLoginBean loginBean)
	throws RMDWebException, Exception {
		rmdWebLogger.debug("authenticate():START ");
		UserVO userVO=null;

		try {
			final Map<String, String> qParamLogin = new LinkedHashMap<String, String>();
			qParamLogin.put(AppConstants.WS_PARAM_USER_ID,
					loginBean.getUserName());
			

			final Map<String,String> headerParams = getHeaderMap(loginBean);

			final LoginResponse loginResponse = (LoginResponse) webServiceInvoker.get(
					ServiceConstants.SECURITY_SERVICE_AUTHENTICATE_USER,
					qParamLogin, null,headerParams,LoginResponse.class);
			if (loginResponse != null) {

				userVO = new UserVO();
				copyProperties(loginResponse, userVO);

				if (AppConstants.ACTIVE_STATE.equals(userVO.getStatus())) {

					int noOfRoles = 0;

					final List<RolesVO> rolesList = userVO.getRolesVOLst();
					if (null != rolesList) {
						noOfRoles = rolesList.size();
					}
					if (noOfRoles > 0) {
						
						userVO.setStrUserName(loginBean.getUserName());
						loginBean.setResult(AppConstants.LOGIN_SUCCESS);
						qParamLogin.put(AppConstants.USER_SEQID,
						        userVO.getUsrUsersSeqId().toString());
						qParamLogin.put(AppConstants.WS_LAST_LOGIN_FROM,
								AppConstants.LAST_LOGIN_FROM);
						final String status = (String) webServiceInvoker.get(
								ServiceConstants.SECURITY_SERVICE_UPDATE_LOGIN_DETAILS_USER,
								qParamLogin, null,null,String.class);
						
						rmdWebLogger.debug("status :: "+status);
						
					}
					else {
						//Authorization error if No Privileges are mapped for Role with NO Data Error code(400)
						rmdWebLogger.error(loginBean.getUserName()+ " is NOT having role(s) mapped");
						throw new AuthorizationException(400,AppConstants.EXCEPTION_EOA_101);
					}
				}
				else {
					//Authorization error if the user is inactive with NO Data Error code(400)
					rmdWebLogger.error(loginBean.getUserName()+ " is INACTIVE");
					throw new AuthorizationException(400,AppConstants.USER_INACTIVE);
				}
				getCustomerList(userVO);
				
			}
		}
		catch (AuthorizationException authorEx) {
			rmdWebLogger.error("AuthorizationException occured in authenticate() method ", authorEx);
			throw authorEx;
		}
		catch (RMDWebException rmdEx) {
			rmdWebLogger.error("RMDWebException occured in authenticate() method ", rmdEx);
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(rmdEx
					.getStatus())) {
				rmdWebLogger.info("No record found in authenticate() method ");
				
			}
			else {
				throw rmdEx;
			}
		}
		catch(IllegalArgumentException illEx) {
			rmdWebLogger.error("Exception occured in authenticate() method : illegal arguments ", illEx);
			throw new AuthenticationException();
		}
		catch (Exception ex) {
			rmdWebLogger.error("Exception occured in authenticate() method ", ex);
			throw ex;
		}
		loginBean.setUserVO(userVO);

		rmdWebLogger.debug("authenticate():END");
	}

	/**
	 * @Author: 
	 * @param loginResponse
	 * @param userVO
	 * @throws Exception
	 * @Description: Method copies JAXB response to UserVO
	 */
	private void copyProperties(final LoginResponse loginResponse, final UserVO userVO)
	throws Exception {
		rmdWebLogger.debug("copyProperties():START ");
		try {
			if(loginResponse != null && null != loginResponse.getUserdetail()){
				userVO.setUsrUsersSeqId(loginResponse.getUserdetail().getUserSeqId());
				userVO.setStatus(Long.valueOf(loginResponse.getUserdetail().getStatus()));
				userVO.setUserId(loginResponse.getUserdetail().getUserId());
				userVO.setCustomerId(loginResponse.getUserdetail().getCustomerId());
				userVO.setEndUserScoring(loginResponse.getUserdetail().getEndUserScoring());
				//added CustomerName for Miscellaneous changes across the screens story
				userVO.setCustomerName(loginResponse.getUserdetail().getCustomerName());
				userVO.setUserType(loginResponse.getUserdetail().getUserType());
				userVO.setLastLoginDateTime(loginResponse.getUserdetail().getLastLoginDateTime());
				
				
			}
			if(loginResponse != null  && null != loginResponse.getPersonalDetailType()){
				userVO.setStrFirstName(loginResponse.getPersonalDetailType().getFirstName());
				userVO.setStrLastName(loginResponse.getPersonalDetailType().getLastName());


				userVO.setStrEmail(loginResponse.getPersonalDetailType().getEmail());
				userVO.setUsrContactSeqId(loginResponse.getPersonalDetailType().getUserContactSeqId());
			}
			
			if (loginResponse != null && loginResponse.getRolesType() != null) {
				final List<RolesType> rolesTypeLst = loginResponse.getRolesType();
				final List<RolesVO> rolesVOList = new ArrayList<RolesVO>();
				if(rolesTypeLst != null ){
					for (RolesType rolesType : rolesTypeLst) {
						final RolesVO rolesVO = new RolesVO();
						rolesVO.setGetUsrRolesSeqId(rolesType.getUserRolesSeqId());
						/*For getting usr role mapping table seq id */
						rolesVO.setLinkUsrRoleSeqId(rolesType.getLinkUsrRoleSeqId());
						/*For getting usr role mapping table seq id */
						rolesVO.setRoleName(rolesType.getRoleName());
						rolesVO.setRoleDesc(rolesType.getRoleDesc());
						rolesVOList.add(rolesVO);
						/* Sorting the Roles in roleVOList object by roleName field.*/
						Collections.sort(rolesVOList, ROLE_COMPARATOR);
					}
				}
				userVO.setRolesVOLst(rolesVOList);
			}
			if (loginResponse!=null && loginResponse.getPreferencesType() != null) {

				/*
				 * EOA doesn't have any preferences. With that as consideration
				 * we are checking for preferencesType length and if it is zero
				 * we consider as EOA request otherwise treat it as a OMD request
				 */
				if(loginResponse.getPreferencesType().size() == 0){
					rmdWebLogger.debug("Handling the request as a EOA request");
					final List<RolesVO> rolesLst = userVO.getRolesVOLst();
					if (rolesLst != null && rolesLst.size() > 0) {
						userVO.setRoleId(Long.valueOf(rolesLst.get(0).getGetUsrRolesSeqId()));
						userVO.setDefaultRoleId(Long.valueOf(rolesLst.get(0).getGetUsrRolesSeqId()));
						userVO.setStrRole(rolesLst.get(0).getRoleName());
					}
					userVO.setTimeZone(AppConstants.URGENCY_NONE);
				}else{
					rmdWebLogger.debug("Handling the request as a OMD request");
					final List<PreferencesType> preferenceTypeLst = loginResponse.getPreferencesType();
					final List<UserPreferenceVO> userPreferenceVOList = new ArrayList<UserPreferenceVO>();
					if(null != preferenceTypeLst){
						for (PreferencesType preferenceType : preferenceTypeLst) {
							final UserPreferenceVO userPreferenceVO = new UserPreferenceVO();
							userPreferenceVO.setGetUsrUserPreferenceSeqId(preferenceType.getUserPreferenceSeqId());
							userPreferenceVO.setUserId(preferenceType.getUserId());
							userPreferenceVO.setUserPreferenceType(preferenceType.getUserPreferernceType());
							userPreferenceVO.setUserPreferenceValue(preferenceType.getUserPreferenceValue());
							userPreferenceVOList.add(userPreferenceVO);
						}
					}
					boolean isTimezoneAvailable = false;
					for (UserPreferenceVO userPreferenceVO : userPreferenceVOList) {
						final 	String preferenceType = userPreferenceVO.getUserPreferenceType();
							String preferenceValue = userPreferenceVO.getUserPreferenceValue();
						if (preferenceType != null
								&& AppConstants.LANGUAGE.equalsIgnoreCase(preferenceType)) {
							userVO.setStrUserLanguage(preferenceValue);
						}
						else if (preferenceType != null
								&& AppConstants.TIMEZONE.equalsIgnoreCase(preferenceType)) {
							isTimezoneAvailable = true;
							if(null == preferenceValue || preferenceValue.isEmpty()){
								preferenceValue=AppConstants.URGENCY_NONE;
							}
							userVO.setTimeZone(preferenceValue);
							userVO.setTimeZoneCode(preferenceValue);
						}
						else if (preferenceType != null
								&& AppConstants.ROLE.equalsIgnoreCase(preferenceType)) {
							boolean isRoleIDExists = false;
							if (preferenceValue != null) {
								final 	List<RolesVO> rolesLst = userVO.getRolesVOLst();
								if (rolesLst != null && rolesLst.size() > 0) {
									String roleName = null;
									for (RolesVO roleVO : rolesLst) {
										if (preferenceValue.equals(roleVO.getGetUsrRolesSeqId().toString())) {
											isRoleIDExists = true;
											roleName = roleVO.getRoleName(); 
										}
									}
									if (!isRoleIDExists) {
										userVO.setRoleId(rolesLst.get(0).getGetUsrRolesSeqId());
										userVO.setDefaultRoleId(rolesLst.get(0).getGetUsrRolesSeqId());
										userVO.setStrRole(rolesLst.get(0).getRoleName());
									}
									else {
										userVO.setRoleId(Long.valueOf(preferenceValue));
										userVO.setDefaultRoleId(Long.valueOf(preferenceValue));
										userVO.setStrRole(roleName);
									}
								}
							}
						}else if (preferenceType != null
								&& AppConstants.MEASUREMENT_SYSYTEM.equalsIgnoreCase(preferenceType)) {
							
							if(null == preferenceValue || preferenceValue.isEmpty()){
								preferenceValue=AppConstants.US;
							}
							userVO.setDefaultUOM(preferenceValue);
							
						}
						userVO.setUserPreferenceVOLst(userPreferenceVOList);
					}	
					
					if(!isTimezoneAvailable){
						userVO.setTimeZone(AppConstants.URGENCY_NONE);
					}
					
				}
			}else{
				userVO.setTimeZone(AppConstants.URGENCY_NONE);
			}
		}
		catch (Exception ex) {
			rmdWebLogger.error("Exception occured in copyProperties() method ", ex);
			throw ex;
		}
		rmdWebLogger.debug("copyProperties():END ");
	}

	/**
	 * @Author: 
	 * @param userVO
	 * @return image name
	 * @throws Exception 
	 * @Description: This method will return header image based on deployed environment
	 */
	@Value("${"+AppConstants.RMD_ENV+"}") private String env;
	@Value("${"+AppConstants.DEPLOYMENT_LOCATION+"}") private String deployLocation;

	@Override
	public String getBrandingImageName(final UserVO userVO) throws Exception {
		rmdWebLogger.debug("getBrandingImageName():START ");
		final StringBuilder sbBrandingImageName = new StringBuilder();
		try {
			sbBrandingImageName.append(env);
			sbBrandingImageName.append(AppConstants.CHAR_UNDER_SCORE);
			sbBrandingImageName.append(deployLocation);
			sbBrandingImageName.append(AppConstants.CHAR_UNDER_SCORE);
			sbBrandingImageName.append(userVO.getStrUserLanguage() == null
					? "en"
					: userVO.getStrUserLanguage());
			sbBrandingImageName.append(AppConstants.IMG_END_NAME);
		}
		catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getBrandingImageName() method ", ex);
			throw ex;
		}
		rmdWebLogger.debug("Branding Image name inside the Header "
				+ sbBrandingImageName.toString());
		rmdWebLogger.debug("getBrandingImageName():END");
		return sbBrandingImageName.toString();
	}
	/*
	 * Comparator objNameComparator using to override compare method as check RolesVO object's roleName field
	 * Purpose:To sort the roles as it is required for sorted object in client side.  
	 */
	private static final Comparator<RolesVO> ROLE_COMPARATOR = new Comparator<RolesVO>() {

		/**
		 * @Author:
		 * @param objFirst
		 * @param objSecond
		 * @return
		 * @Description:
		 */
		public int compare(final RolesVO objFirst, final RolesVO objSecond) {
			final	String firstObject = objFirst.getRoleName();
			final	String secondObject = objSecond.getRoleName();
			if (firstObject == null) {
				return -1;
			}
			if (secondObject == null) {
				return +1;
			}
			return firstObject.compareTo(secondObject);
		}
	};


	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.ge.trans.rmd.common.service.LoginService#getProductsForRole(com.ge
	 * .trans.rmd.common.beans.CustomerAssetBean) This method is used to get the
	 * List of product name
	 */
	@Override
	public List<String> getProductsForRole(CustomerAssetBean custAssetBean)
			throws Exception {
		rmdWebLogger
				.debug("LoginServiceImpl : Inside getProductAssets() method::START");
		final Map<String, String> qParamAsset = new LinkedHashMap<String, String>();
		List<String> productList = new ArrayList<String>();

		try {

			qParamAsset.put(AppConstants.ROLE_NAME, RMDCommonUtility
					.convertObjectToString(custAssetBean.getRoleName()));
			qParamAsset.put(AppConstants.WS_PARAM_CUSTID, RMDCommonUtility
					.convertObjectToString(custAssetBean.getCustomerId()));

			final ProductResponseType[] prodResponseType = (ProductResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_PROD_AASETS, null, qParamAsset,
							null, ProductResponseType[].class);
			if (null != prodResponseType && prodResponseType.length > 0) {

				for (ProductResponseType assetResponse : prodResponseType) {

					if (null != assetResponse.getProductId()
							&& null != assetResponse.getProductName()) {
						productList.add(assetResponse.getProductName());
					}
				}
			}

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getProductAssets method ",
					ex);
			RMDWebErrorHandler.handleException(ex);

		}
		rmdWebLogger
				.debug("LoginServiceImpl : Inside getProductAssets() method::END");
		return productList;
	}

	public void hasCMPrivilege(final UserVO userVO) throws Exception {
		rmdWebLogger
				.debug("LoginServiceImpl : Inside getCMPrivilege() method::START");
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		UserRequestType userRequestType=new UserRequestType();
		try {
			userRequestType.setUserId(userVO.getUserId());
		   final String eoaUser = (String) webServiceInvoker
			.post(ServiceConstants.GET_EOA_USERID, userRequestType, String.class);
			if (null != eoaUser) {
					userVO.setCmAliasName(eoaUser);
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCMPrivilege method ",
					ex);
			RMDWebErrorHandler.handleException(ex);

		}
		rmdWebLogger
				.debug("LoginServiceImpl : Inside getCMPrivilege() method::END");
	}
	/**
	 * @Author: 
	 * @param userVO
	 * @return customer list
	 * @throws Exception 
	 * @Description: This method will return list of customers for the passed user id
	 */
	@Override
	public void getCustomerList(final UserVO userVO) throws Exception {
		final List<CustomerVO> customerList = new ArrayList<CustomerVO>();
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		boolean isAllcustomer=true;
		
		try {
			pathParams.put(AppConstants.WS_PARAM_USER_ID, userVO.getUserId());
			Customer[] customer = (Customer[]) webServiceInvoker.get(
					ServiceConstants.GET_USER_CUSTOMERS, pathParams, null, null,
					Customer[].class);

			for (Customer newCustomer : customer) {
				CustomerVO customerObj = new CustomerVO();
				customerObj.setCustomerID(newCustomer.getCustomerID());
				customerObj.setCustomerName(newCustomer.getCustomerName());
				customerObj.setDefault(newCustomer.isIsDefault());
				customerObj.setCustomerSeqId(newCustomer.getCustomerSeqId());
				customerList.add(customerObj);
				if (newCustomer.isIsDefault() || newCustomer.isIsAllCustomerdefault()) {
					userVO.setDefaultCustomer(newCustomer.getCustomerID());
				}
				if(!newCustomer.isIsAllCustomer()){
					isAllcustomer=false;
				}
			}	
			userVO.setCustomerList(customerList);
			userVO.setAllCustomer(isAllcustomer);
				
		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: No records found for getCustomers() service "
								+ e.getMessage());
			} else {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: Exception occured in getCustomers() method "
								+ e.getMessage());
				throw e;
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCustomers method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}

	}
	@Override
	public boolean dashboardRoleFlagValue(final UserVO userVO) throws Exception {
		//rmdWebLogger.debug("getBrandingImageName():START ");
			boolean roleFlag = false;
			long currentUserRoleId = userVO.getRoleId();
		try {

			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.DASHBOARD_BUTTON_ROLES);

			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType && applParamResponseType.length!=0) {
				// for (int i = 0; i < applParamResponseType.length; i++) {
				for (ApplicationParametersResponseType appResType : applParamResponseType) {
					if (!RMDCommonUtility.isNullOrEmpty(appResType
							.getLookupValue())
							&& Long.valueOf(appResType.getLookupValue()) == currentUserRoleId) {
						roleFlag = true;
					}
				}
			}

		}
		catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCriticalFlag method ",
					ex);
		}
		return roleFlag;
	}

	@Override
	public String updateLastLoginDetails(String userId) throws Exception {
		UserRequestType userRequestType=new UserRequestType();
		String status=null;
		try {
			userRequestType.setUserId(userId);
			userRequestType.setLastLoginFrom(AppConstants.LAST_LOGIN_FROM);
			status = (String) webServiceInvoker.post(
					ServiceConstants.UPDATE_LAST_LOGIN_DETAILS, userRequestType,
					String.class);
	}
		catch (Exception ex) {
			rmdWebLogger.error("Exception occured in updateLastLoginDetails method ",
					ex);
		}
		return status;
	}
}