package com.ge.trans.rmd.common.beans;

public class GpocNotesBean extends RMDBaseBean {
	private static final long serialVersionUID = 1L;
	private Long getUsrgeneralNotesSeqId;
	private String generalnotesId;
	private String commnotesId;
	private String notesdesc;
	private String enteredby;
	private String enteredDate;
	private String StringuserTimeZone;
	private String visibilityFlag;
	
	public Long getGetUsrgeneralNotesSeqId() {
		return getUsrgeneralNotesSeqId;
	}
	public void setGetUsrgeneralNotesSeqId(Long getUsrgeneralNotesSeqId) {
		this.getUsrgeneralNotesSeqId = getUsrgeneralNotesSeqId;
	}
	public String getGeneralnotesId() {
		return generalnotesId;
	}
	public void setGeneralnotesId(String generalnotesId) {
		this.generalnotesId = generalnotesId;
	}
	public String getCommnotesId() {
		return commnotesId;
	}
	public void setCommnotesId(String commnotesId) {
		this.commnotesId = commnotesId;
	}
	public String getNotesdesc() {
		return notesdesc;
	}
	public void setNotesdesc(String notesdesc) {
		this.notesdesc = notesdesc;
	}
	public String getEnteredby() {
		return enteredby;
	}
	public void setEnteredby(String enteredby) {
		this.enteredby = enteredby;
	}
	public String getEnteredDate() {
		return enteredDate;
	}
	public void setEnteredDate(String enteredDate) {
		this.enteredDate = enteredDate;
	}
	public String getStringuserTimeZone() {
		return StringuserTimeZone;
	}
	public void setStringuserTimeZone(String stringuserTimeZone) {
		StringuserTimeZone = stringuserTimeZone;
	}
    public String getVisibilityFlag() {
        return visibilityFlag;
    }
    public void setVisibilityFlag(String visibilityFlag) {
        this.visibilityFlag = visibilityFlag;
    }
	
	

}
