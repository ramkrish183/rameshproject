package com.ge.trans.rmd.alert.mvc.controller;


import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.TreeMap;

import javax.mail.MessagingException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ge.trans.rmd.alert.service.AlertSubscriptionService;
import com.ge.trans.rmd.alert.valueobjects.AlertRxTypeDetails;
import com.ge.trans.rmd.alert.valueobjects.AlertSubscriptionDetailsVO;
import com.ge.trans.rmd.alert.valueobjects.OTPValidationVO;
import com.ge.trans.rmd.common.beans.UserManagementBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.service.UserManagementService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.SMSResponseVO;
import com.ge.trans.rmd.common.vo.UpdatePhoneVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class AlertSubscriptionController extends RMDBaseController{
	
	@Autowired
	private AlertSubscriptionService alertSubscriptionService;
	@Autowired
	private UserManagementService userManagementService;
	@Autowired
	private AuthorizationService authService;
	@Autowired
	private ApplicationContext appContext;
	@Value("${" + AppConstants.OMD_CONNECTION_PATH + "}")
	private String omdConnection;
	 private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	
	@RequestMapping(value = AppConstants.ALERT_SUBSCRIPTION_PAGE,method =RequestMethod.GET)
	public String viewAlertSubscription(final HttpServletRequest request)  throws Exception
	{
		final HttpSession session = request.getSession(false);
		List<String> atsCustomers = new ArrayList<String>();
		List<String> eoaCustomers = new ArrayList<String>();
		List<String> configAlertCustomers = new ArrayList<String>();
		String userEmail=AppConstants.EMPTY_STRING;
		String userPhoneNo=AppConstants.EMPTY_STRING;
		String userPhoneCountryCode=AppConstants.EMPTY_STRING;
		String flag=null;
		boolean privilege = false;
		boolean multiSubscriptionPrivilege = false;
		boolean configAlertPrivilege = false;
		boolean smsPrivilege = false;
		boolean rxChangePrivilege = false;
		try {
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			
			Map<String, String> componentList = new HashMap<String, String>();
			
			componentList.put(AppConstants.ALERT_SUBSCRIPTION_ATS,
					AppConstants.ALERT_SUBSCRIPTION_ATS_COMPONENT);
			componentList.put(AppConstants.ALERT_SUBSCRIPTION_EOA,
					AppConstants.ALERT_SUBSCRIPTION_EOA_COMPONENT);
			componentList.put(AppConstants.ALERT_SUBSCRIPTION_CONFIG_ALERT,
					AppConstants.ALERT_SUBSCRIPTION_CONFIG_ALERT_COMPONENT);
			getComponentPrivilege(componentList,userVO,request);
			userEmail=getUserEmailId(userVO.getUserId());
			userVO.setStrEmail(userEmail);
			userPhoneNo=getUserPhoneNo(userVO.getUserId());
			userVO.setUserPhoneNo(userPhoneNo);
			userPhoneCountryCode=getUserPhoneCountryCode(userVO.getUserId());
			userVO.setUserPhoneCountryCode(userPhoneCountryCode);
			atsCustomers = alertSubscriptionService.getATSEnabledCustomers();
			String comaSepratedStr = RMDCommonUtility.getCommaSeperatedString(atsCustomers);
			request.setAttribute(AppConstants.ATS_CUSTOEMRS, comaSepratedStr);
			request.setAttribute(AppConstants.USER_MAIL_ID, userEmail);
			request.setAttribute(AppConstants.USER_PHONE_NO, userPhoneNo);
			request.setAttribute(AppConstants.USER_PHONE_COUNTRY_CODE, userPhoneCountryCode);
			eoaCustomers = alertSubscriptionService.getEOACustomerList();
			comaSepratedStr = RMDCommonUtility.getCommaSeperatedString(eoaCustomers);
			request.setAttribute(AppConstants.EOA_CUSTOMERS, comaSepratedStr);
			configAlertCustomers = alertSubscriptionService.getConfigAlertCustomerList();
			comaSepratedStr = RMDCommonUtility.getCommaSeperatedString(configAlertCustomers);
			request.setAttribute(AppConstants.CONFIG_ALERT_CUSTOMERS, comaSepratedStr);
			flag= alertSubscriptionService.getRXLookupFlag();
			request.setAttribute(AppConstants.RX_FLAG, flag);
			privilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.ALERT_SUBSCRIPTION_MODEL);
			request.setAttribute(AppConstants.ALERT_SUBSCRIPTION_MODEL_COMPONENT,privilege);
			multiSubscriptionPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION);
			request.setAttribute(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_COMPONENT,multiSubscriptionPrivilege);
			configAlertPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.ALERT_SUBSCRIPTION_CONFIG_ALERT);
			request.setAttribute(AppConstants.ALERT_SUBSCRIPTION_CONFIG_ALERT_COMPONENT,configAlertPrivilege);
			smsPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.ALERT_SUBSCRIPTION_SMS);
			if(smsPrivilege){
				request.setAttribute(AppConstants.ALERT_SUBSCRIPTION_SMS_COMPONENT, true);
			}
			else
			{
				request.setAttribute(AppConstants.ALERT_SUBSCRIPTION_SMS_COMPONENT, false);
			}
			rxChangePrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.ALERT_SUBSCRIPTION_RX_CHANGE);
			if(rxChangePrivilege){
				request.setAttribute(AppConstants.ALERT_SUBSCRIPTION_RX_CHANGE_COMPONENT, true);
			}
			else
			{
				request.setAttribute(AppConstants.ALERT_SUBSCRIPTION_RX_CHANGE_COMPONENT, false);
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in viewAlertSubscription method ", ex);
			RMDWebErrorHandler.handleException(ex);			
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		}
		finally {
			atsCustomers= null;
			eoaCustomers= null;
			configAlertCustomers= null;
		}
		return AppConstants.ALERT_SUBSCRIPTION_VIEW;
	}
	
	// Added by Sriram.B(212601214) for SMS feature
	// This method is used to fetch the constants needed for OTP from DB
	@RequestMapping(value = AppConstants.GET_OTP_PARAMETERS,method =RequestMethod.GET)
	@ResponseBody public String getOTPparameters()  throws Exception
	{
		String otp_parameters = alertSubscriptionService.getOTPParameters();
		return otp_parameters;
	}
	
	// Added by Sriram.B(212601214) for SMS feature
	// This method is used to generate a random 6 digit verification code
	@RequestMapping(value = AppConstants.GENERATE_OTP,method =RequestMethod.GET)
	@ResponseBody public String generateOTP(@RequestParam(value = AppConstants.USER_ID, required = true) final String userId)  throws Exception
	{
		String numbers = "0123456789";
		Random rndm_method = new Random();
		char[] otp = new char[6];
		for (int i = 0; i < 6; i++)
            otp[i] = numbers.charAt(rndm_method.nextInt(numbers.length()));	
		String otp_string = new String(otp);
		return otp_string;	
	}
	
	// Added by Sriram.B(212601214) for SMS feature
	// This method is used to make a web service call to send the verification code through SMS using Twilio
	@RequestMapping(value = AppConstants.SEND_OTP,method =RequestMethod.GET)
	@ResponseBody public String sendOTP(@RequestParam(value = AppConstants.TO_SMS, required = true) final String to,@RequestParam(value = AppConstants.BODY_SMS, required = true) final String body,@RequestParam(value = AppConstants.RETRY_ATTEMPTS_SMS, required = true) final String RetryAttempts)  throws Exception
	{
		SMSResponseVO smsresponsevo = new SMSResponseVO();
		smsresponsevo = alertSubscriptionService.sendOTP(to, body, RetryAttempts);
		if(smsresponsevo.getError_code() == null || smsresponsevo.getError_code().equals("null"))
			return AppConstants.SUCCESS;
		else
			return AppConstants.FAILURE;
	}
	
	// Added by Sriram.B(212601214) for SMS feature
	// This method is used to store the OTP in a VO along with the created time and user id
	@RequestMapping(value = AppConstants.STORE_OTP, method = RequestMethod.POST)
	public void storeOTP(final HttpServletRequest request) throws Exception 
	{
		final HttpSession session = request.getSession(false);
		String userId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID));
		String otp = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.OTP));
		OTPValidationVO otpvalidationvo = new OTPValidationVO();
		otpvalidationvo.setUserId(userId);
		otpvalidationvo.setOtp(otp);
		otpvalidationvo.setCreated_date(new Date());
		session.setAttribute(AppConstants.OTPValidationVO,otpvalidationvo);
	}
	
	// Added by Sriram.B(212601214) for SMS feature
	// This method is used to validate the OTP entered by the user with the value stored in the VO
	@RequestMapping(value = AppConstants.VALIDATE_OTP,method =RequestMethod.GET)
	@ResponseBody public Boolean validateOTP(@RequestParam(value = AppConstants.OTP, required = true) final String otp,final HttpServletRequest request)  throws Exception
	{
		final HttpSession session = request.getSession(false);
		final OTPValidationVO otpvalidationvo = (OTPValidationVO) session.getAttribute(AppConstants.OTPValidationVO);
		if(otp.equalsIgnoreCase(otpvalidationvo.getOtp()))
			return true;
		else
			return false;
	}
	
	@RequestMapping(value = AppConstants.REQ_URI_GETASSETFORCUSTOMERS, method = RequestMethod.GET)
	@ResponseBody public
	Map<String, String> getAssetForCustomer(
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId,
			@RequestParam(value = AppConstants.SERVICE, required = true) final String service)
			throws RMDWebException {

		Map<String, String> assetList = new TreeMap<String, String>();
		try {
			if (AppConstants.ATS.equalsIgnoreCase(service) || AppConstants.CONFIG_ALERT.equalsIgnoreCase(service)) {
				assetList = alertSubscriptionService.getAssetForCustomer(EsapiUtil.stripXSSCharacters(customerId));
			} else {
				assetList = alertSubscriptionService.getAssetEOAForCustomer(EsapiUtil.stripXSSCharacters(customerId));
			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAssetForCustomers method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return assetList;

	}
	
	@RequestMapping(value = AppConstants.REQ_URI_GETALERTFORCUSTOMERS, method = RequestMethod.GET)
	@ResponseBody
	public Map<String, String> getAlertForCustomer(
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId,
			@RequestParam(value = AppConstants.SERVICE, required = true) final String service,
			@RequestParam(value = AppConstants.MODEL_VALUE, required = true) final String modelVal)
			throws RMDWebException {
		Map<String, String> alertList = new TreeMap<String, String>();
		try {
			if (AppConstants.CONFIG_ALERT.equalsIgnoreCase(EsapiUtil.stripXSSCharacters(service))) {
				alertList = alertSubscriptionService.getConfigAlertForCustomer(
						EsapiUtil.stripXSSCharacters(customerId), EsapiUtil.stripXSSCharacters(modelVal));
			} else {
				alertList = alertSubscriptionService
						.getAlertForCustomer(EsapiUtil.stripXSSCharacters(customerId));

			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAlertForCustomers method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		
		return alertList;
	}
	
	@RequestMapping(value = AppConstants.REQ_URI_GETALERTSUBSCRIPTIONDETAILS)
	@ResponseBody public
	List<AlertSubscriptionDetailsVO> getAlertSubscriptionDetails(
			final HttpServletRequest request) throws RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String userId = null;
		String flag = null;
		String pageflag = null;
		String customerId = null;
		boolean smsFlag = false;
		boolean privilege = false;
		boolean configAlertPrivilege = false;
		boolean multiSubscriptionPrivilege = false;
		List<AlertSubscriptionDetailsVO> alertSubscriptionDtlsLst = new ArrayList<AlertSubscriptionDetailsVO>();
		AlertSubscriptionDetailsVO alertSubscriptionDtls = new AlertSubscriptionDetailsVO();
		String customerList = "";

		try {
			/*
			 * null condition is add to determine from where the function is
			 * called . if userId exist the call is from the admin notification
			 * page
			 */
			if (null != request.getParameter(AppConstants.USER_ID)
					&& !request.getParameter(AppConstants.USER_ID).trim()
							.isEmpty()) {
				userId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID));

			} else {
				userId = EsapiUtil.stripXSSCharacters(userVO.getUserId());
			}
			if (null != request.getParameter(AppConstants.FLAG)
					&& !request.getParameter(AppConstants.FLAG).trim()
							.isEmpty()) {
				flag = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG));
			}
			if (null != request.getParameter(AppConstants.PAGE_FLAG)
					&& !request.getParameter(AppConstants.PAGE_FLAG).trim()
							.isEmpty()) {
				pageflag = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.PAGE_FLAG));
			}
			if (null != request.getParameter(AppConstants.CUSTOMER)
					&& !request.getParameter(AppConstants.CUSTOMER).trim()
							.isEmpty()) {
				customerId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CUSTOMER));

				if (userVO.isAllCustomer()) {
					alertSubscriptionDtls
							.setCustomerId(AppConstants.EMPTY_STRING);
				} else {
					if (userVO.getCustomerList().size() > 1) {
						customerList = getCustomerList(userVO.getCustomerList());
						alertSubscriptionDtls.setCustomerList(customerList);
						alertSubscriptionDtls.setCustomerId(customerList);
					} else {
						alertSubscriptionDtls.setCustomerId(customerId);
					}
				}
			}
			if (AppConstants.ALERT_SUBSCRIPTION_FLAG.equalsIgnoreCase(pageflag)) {
				privilege = RMDCommonUtil.componentValue(
						userVO.getComponentList(),
						AppConstants.ALERT_SUBSCRIPTION_MODEL);
				multiSubscriptionPrivilege = RMDCommonUtil.componentValue(
						userVO.getComponentList(),
						AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION);
				configAlertPrivilege = RMDCommonUtil.componentValue(
						userVO.getComponentList(),
						AppConstants.ALERT_SUBSCRIPTION_CONFIG_ALERT);
				alertSubscriptionDtls.setAllCustomer(userVO.isAllCustomer());
				alertSubscriptionDtls.setUserType(userVO.getUserType());

			} else {
				privilege = RMDCommonUtil
						.componentValue(
								userVO.getComponentList(),
								AppConstants.SUBMENU_ADMINISTRATION_NOTIFICATIONS_ALERT_SUBSCRIPTION_MODEL);
			}
			smsFlag = RMDCommonUtil.componentValue(
					userVO.getComponentList(),
					AppConstants.ALERT_SUBSCRIPTION_SMS);
			alertSubscriptionDtls.setUserId(userId);
			alertSubscriptionDtls.setFlag(flag);
			alertSubscriptionDtls.setModelPrivilege(privilege);
			alertSubscriptionDtls.setConfigAlertPrivilege(configAlertPrivilege);
			alertSubscriptionDtls
					.setMultiSubscriptionPrivilege(multiSubscriptionPrivilege);
			alertSubscriptionDtls.setSmsFlag(smsFlag);
			alertSubscriptionDtlsLst = alertSubscriptionService
					.getAlertSubscriptionDetails(alertSubscriptionDtls);
			request.setAttribute("alertData", alertSubscriptionDtlsLst);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getAlertSubscriptionData method ",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return alertSubscriptionDtlsLst;
	}
	
	@RequestMapping(value = AppConstants.REQ_URI_ACTIVATE_DEACTIVATE_ALERT)
	@ResponseBody public
	String activateOrDeactivateAlert(HttpServletRequest request)
			throws RMDWebException {
		String pass = AppConstants.FAILURE;
		String userId=null;
		try {
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			String to = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TO));
			String from = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FROM));
			String toName = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TO_NAME));
			String pageflag =EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.PAGE_FLAG));
			boolean multiSubscriptionPrivilege;
			multiSubscriptionPrivilege = RMDCommonUtil.componentValue(
					userVO.getComponentList(),
					AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION);
			/*
			 * null condition is add to determine from where the function is
			 * called . if userId exist the call is from the admin notification
			 * page
			 */
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID))
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID)).trim()
							.isEmpty()) {
				userId = EsapiUtil.stripXSSCharacters(request
						.getParameter(AppConstants.USER_ID));

			} else {
				userId = EsapiUtil.stripXSSCharacters(userVO.getUserId());
			}

			AlertSubscriptionDetailsVO alertSubscriptionDetailsVO = null;
			List<AlertSubscriptionDetailsVO> alertSubscriptionDetailsVOList = new ArrayList<AlertSubscriptionDetailsVO>();

			List<String> selectedRow = Arrays.asList(EsapiUtil
					.stripXSSCharacters(request.getParameter("rowSelected"))
					.split(AppConstants.TILDA));

			for (String current : selectedRow) {

				alertSubscriptionDetailsVO = new AlertSubscriptionDetailsVO();
				String[] rowArr = current.split(AppConstants.SYMBOL_COMMA);
				alertSubscriptionDetailsVO.setCustomerAlertObjId(rowArr[0]);
				if (rowArr[1] != null && !rowArr[1].trim().isEmpty()) {
					alertSubscriptionDetailsVO.setRegionid(rowArr[1]);
				} else if (rowArr[2] != null && !rowArr[2].trim().isEmpty()) {
					alertSubscriptionDetailsVO.setFleetid(rowArr[2]);
				} else if (rowArr[3] != null && !rowArr[3].trim().isEmpty()) {
					alertSubscriptionDetailsVO.setVehicleObjId(rowArr[3]);
				} else if (rowArr[4] != null && !rowArr[4].trim().isEmpty()) {
					alertSubscriptionDetailsVO.setShopid(rowArr[4]);
				}else if (null != rowArr[5] && !rowArr[5].trim().isEmpty()) {
					alertSubscriptionDetailsVO.setModelId(rowArr[5]);
				}		
				if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID))
						&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID)).trim()
								.isEmpty()) {
					if (rowArr[7] != null && !rowArr[7].trim().isEmpty()) {
						alertSubscriptionDetailsVO
								.setAlertSubscribed(rowArr[7]);
					}
					if (rowArr[8] != null && !rowArr[8].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setFleet(rowArr[8]);
					} else if (rowArr[9] != null && !rowArr[9].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setRegion(rowArr[9]);
					} else if (rowArr[10] != null
							&& !rowArr[10].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setAsset(rowArr[10]);
					}
					if (rowArr[11] != null && !rowArr[11].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setCustomer(rowArr[11]);
					}
					if (rowArr[12] != null && !rowArr[12].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setValue(rowArr[12]);
					}
					if (rowArr[13] != null && !rowArr[13].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setShop(rowArr[13]);
					}
					if (rowArr[14] != null && !rowArr[14].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setService(rowArr[14]);
					}
					if (null != rowArr[15] && !rowArr[15].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setModel(rowArr[15]);
					}
					if (null != rowArr[16] && !rowArr[16].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setUserName(rowArr[16]);
					}
					if (null != rowArr[17] && !rowArr[17].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setUserEmail(rowArr[17]);
					}
					if (rowArr[18] != null && !rowArr[18].trim().isEmpty()) {
						alertSubscriptionDetailsVO
								.setRxSubscribedAlerts(rowArr[18]);
					}
					if(AppConstants.EOA.equals(rowArr[14]) ){
					if (rowArr[19] != null && !rowArr[19].trim().isEmpty()) {
						alertSubscriptionDetailsVO
								.setRxType(rowArr[19]);
					}
					}
				}
				alertSubscriptionDetailsVO.setStatus(EsapiUtil
						.stripXSSCharacters(request.getParameter("flag")));
				alertSubscriptionDetailsVO.setUserId(userId);
				alertSubscriptionDetailsVOList.add(alertSubscriptionDetailsVO);
			}

			pass = alertSubscriptionService
					.activateOrDeactivateAlert(alertSubscriptionDetailsVOList);
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID))
					&& null != to && !to.isEmpty()) {
				if (alertSubscriptionDetailsVO.getStatus().equalsIgnoreCase(
						AppConstants.STR_Y)) {
					prepareMailFormat(alertSubscriptionDetailsVOList, null,
							AppConstants.ALERT_SUBSCRIPTION_ACTIVATE, from, to, toName, userVO);
				} else {
					prepareMailFormat(alertSubscriptionDetailsVOList, null,
							AppConstants.ALERT_SUBSCRIPTION_DEACTIVATE, from, to, toName, userVO);
				}
			} else if (multiSubscriptionPrivilege
					&& pageflag
							.equalsIgnoreCase(AppConstants.ALERT_SUBSCRIPTION_FLAG)) {
				if (alertSubscriptionDetailsVO.getStatus().equalsIgnoreCase(
						AppConstants.STR_Y)) {
					prepareMultiSubMailFormat(alertSubscriptionDetailsVOList,
							null, AppConstants.ALERT_SUBSCRIPTION_ACTIVATE, from, to, toName, userVO);
				} else {
					prepareMultiSubMailFormat(alertSubscriptionDetailsVOList,
							null, AppConstants.ALERT_SUBSCRIPTION_DEACTIVATE, from, to, toName, userVO);
				}
			}
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID))
					&& (null == to || to.isEmpty())) {
				rmdWebLogger.error(AppConstants.EMAIL_NOT_VALID);
			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in activateOrDeactivateAlert method ",
					ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return pass;
	}

	@RequestMapping(value = AppConstants.REQ_URI_DELETE_ALERT)
	@ResponseBody public
	String deleteAlert(HttpServletRequest request) throws RMDWebException {
		String pass = AppConstants.FAILURE;
		try {
			AlertSubscriptionDetailsVO alertSubscriptionDetailsVO;
			List<AlertSubscriptionDetailsVO> alertSubscriptionDetailsVOList = new ArrayList<AlertSubscriptionDetailsVO>();
			final HttpSession session = request.getSession(false);
			String userId;
			List<String> selectedRow = Arrays.asList(EsapiUtil
					.stripXSSCharacters(request.getParameter("rowSelected"))
					.split(AppConstants.TILDA));
			String to = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TO));
			String from = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FROM));
			String toName = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TO_NAME));
			String pageflag = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.PAGE_FLAG));
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			boolean multiSubscriptionPrivilege;
			multiSubscriptionPrivilege = RMDCommonUtil.componentValue(
					userVO.getComponentList(),
					AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION);
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID))
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID)).trim()
							.isEmpty()) {
				userId = EsapiUtil.stripXSSCharacters(request
						.getParameter(AppConstants.USER_ID));
			} else {
				userId = EsapiUtil.stripXSSCharacters(userVO.getUserId());
			}
			for (String current : selectedRow) {
				alertSubscriptionDetailsVO = new AlertSubscriptionDetailsVO();
				String[] rowArr = current.split(AppConstants.SYMBOL_COMMA);
				alertSubscriptionDetailsVO.setCustomerAlertObjId(rowArr[0]);
				if (rowArr[1] != null && !rowArr[1].trim().isEmpty()) {
					alertSubscriptionDetailsVO.setRegionid(rowArr[1]);
				} else if (rowArr[2] != null && !rowArr[2].trim().isEmpty()) {
					alertSubscriptionDetailsVO.setFleetid(rowArr[2]);
				} else if (rowArr[3] != null && !rowArr[3].trim().isEmpty()) {
					alertSubscriptionDetailsVO.setVehicleObjId(rowArr[3]);
				}else if (rowArr[4] != null && !rowArr[4].trim().isEmpty()) {
					alertSubscriptionDetailsVO.setShopid(rowArr[4]);
				} else if (rowArr[5] != null && !rowArr[5].trim().isEmpty()) {
					alertSubscriptionDetailsVO.setModelId(rowArr[5]);
				}
				if (rowArr[6] != null && !rowArr[6].trim().isEmpty()) {
					alertSubscriptionDetailsVO.setUserEmail(rowArr[6]);
				}
				if (rowArr[7] != null && !rowArr[7].trim().isEmpty()) {
					alertSubscriptionDetailsVO.setUserName(rowArr[7]);
				}
				alertSubscriptionDetailsVO.setAlertConfSeqId(rowArr[8]);
				if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID))
						&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID)).trim()
								.isEmpty()) {
					if (rowArr[10] != null && !rowArr[10].trim().isEmpty()) {
						alertSubscriptionDetailsVO
								.setAlertSubscribed(rowArr[10]);
					}
					if (rowArr[11] != null && !rowArr[11].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setFleet(rowArr[11]);
					} else if (rowArr[12] != null
							&& !rowArr[12].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setRegion(rowArr[12]);
					} else if (rowArr[13] != null
							&& !rowArr[13].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setAsset(rowArr[13]);
					}
					if (rowArr[14] != null && !rowArr[14].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setCustomer(rowArr[14]);
					}
					if (rowArr[15] != null && !rowArr[15].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setValue(rowArr[15]);
					}
					if (rowArr[16] != null && !rowArr[16].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setShop(rowArr[16]);
					}
					if (null != rowArr[17] && !rowArr[17].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setModel(rowArr[17]);
					}
					if (rowArr[18] != null && !rowArr[18].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setService(rowArr[18]);
					}
					if (rowArr[19] != null && !rowArr[19].trim().isEmpty()) {
						alertSubscriptionDetailsVO.setRxType(rowArr[19]);
					}
				}
				alertSubscriptionDetailsVO.setUserId(userId);
				alertSubscriptionDetailsVOList.add(alertSubscriptionDetailsVO);
			}
			pass = alertSubscriptionService
					.deleteAlert(alertSubscriptionDetailsVOList);
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID))
					&& null != to && !to.isEmpty()) {

				prepareMailFormat(alertSubscriptionDetailsVOList, null,
						AppConstants.ALERT_SUBSCRIPTION_DELETE, from, to, toName, userVO);
			} else if (multiSubscriptionPrivilege
					&& pageflag
							.equalsIgnoreCase(AppConstants.ALERT_SUBSCRIPTION_FLAG)) {
				prepareMultiSubMailFormat(alertSubscriptionDetailsVOList, null,
						AppConstants.ALERT_SUBSCRIPTION_DELETE, from, to, toName, userVO);
			}
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID))
					&& (null == to || to.isEmpty())) {
				rmdWebLogger.error(AppConstants.EMAIL_NOT_VALID);
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in deleteAlert method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return pass;
	}
	
	// Added by Sriram.B(212601214) for SMS feature
	// This method is used to update the phone number of the user in the DB, after OTP validation is successful
	@RequestMapping(value = AppConstants.REQ_URI_UPDATE_PHONE)
	@ResponseBody public
	String updatephone(HttpServletRequest request) throws RMDWebException {
		String pass = AppConstants.FAILURE;
		final ObjectMapper mapper = new ObjectMapper();
		try {
				List<UpdatePhoneVO> tempList = new ArrayList<UpdatePhoneVO>();
				UpdatePhoneVO[] updatePhoneVO = mapper.readValue(EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.PARAM_STRING)),UpdatePhoneVO[].class);
				tempList = Arrays.asList(updatePhoneVO);						
				pass = alertSubscriptionService
						.updatephone(tempList);
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in updatephone method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return pass;
	}
	
	@RequestMapping(value = AppConstants.REQ_URI_EDIT_ALERT)
	@ResponseBody public
	String editAlert(HttpServletRequest request) throws RMDWebException {
		String pass = AppConstants.FAILURE;
		String userId=null;
		boolean multiSubscriptionPrivilege = false;
		try {

			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			String to = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TO));
			String from = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FROM));
			String toName = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TO_NAME));
			String pageflag = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.PAGE_FLAG));			
			multiSubscriptionPrivilege= RMDCommonUtil.componentValue(userVO.getComponentList(),AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION);
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID))
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID)).trim().isEmpty()) {
				userId = EsapiUtil.stripXSSCharacters(request
						.getParameter(AppConstants.USER_ID));				
			}else{
				userId=userVO.getUserId();
			}
			AlertSubscriptionDetailsVO alertSubscriptionDtl = new AlertSubscriptionDetailsVO();
			alertSubscriptionDtl.setUserId(userId);
			if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_SUBSCRIPTION_REGIONID)) != null
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_SUBSCRIPTION_REGIONID)).trim().isEmpty()) {
				alertSubscriptionDtl
						.setRegionid(EsapiUtil.stripXSSCharacters(request
								.getParameter(AppConstants.ALERT_SUBSCRIPTION_REGIONID)));
			}
			if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLEET_ID)) != null
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLEET_ID)).trim().isEmpty()) {
				alertSubscriptionDtl.setFleetid(EsapiUtil
						.stripXSSCharacters(request
								.getParameter(AppConstants.FLEET_ID)));
			}
			if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_SUBSCRIPTION_SHOPID)) != null
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_SUBSCRIPTION_SHOPID)).trim().isEmpty()) {
				alertSubscriptionDtl
						.setShopid(EsapiUtil.stripXSSCharacters(request
								.getParameter(AppConstants.ALERT_SUBSCRIPTION_SHOPID)));
			}
			if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_SUBSCRIPTION_ASSETNUMID)) != null
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_SUBSCRIPTION_ASSETNUMID)).trim().isEmpty()) {
				alertSubscriptionDtl
						.setVehicleObjId(EsapiUtil.stripXSSCharacters(request
								.getParameter(AppConstants.ALERT_SUBSCRIPTION_ASSETNUMID)));
			}
			if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_SUBSCRIPTION_CUSTOMER_ALERTOBJID)) != null
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_SUBSCRIPTION_CUSTOMER_ALERTOBJID)).trim()
							.isEmpty()) {
				alertSubscriptionDtl.setCustomerAlertObjId(EsapiUtil.stripXSSCharacters(request
						.getParameter(AppConstants.ALERT_SUBSCRIPTION_CUSTOMER_ALERTOBJID)));
			}
			if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_SUBSCRIPTION_DELIVERY_FRMT)) != null
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_SUBSCRIPTION_DELIVERY_FRMT)).trim().isEmpty()) {
				alertSubscriptionDtl
						.setEmailFormat(EsapiUtil.stripXSSCharacters(request
								.getParameter(AppConstants.ALERT_SUBSCRIPTION_DELIVERY_FRMT)));
			}
			if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERTS)) != null
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERTS)).trim().isEmpty()) {
				alertSubscriptionDtl.setAlertSubscribed(EsapiUtil
						.stripXSSCharacters(request
								.getParameter(AppConstants.ALERTS)));
			}
			if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLEET)) != null
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLEET)).trim().isEmpty()) {
				alertSubscriptionDtl.setFleet(EsapiUtil
						.stripXSSCharacters(request
								.getParameter(AppConstants.FLEET)));
			} else if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REGION)) != null
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REGION)).trim().isEmpty()) {
				alertSubscriptionDtl.setRegion(EsapiUtil
						.stripXSSCharacters(request
								.getParameter(AppConstants.REGION)));
			} else if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET)) != null
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET)).trim().isEmpty()) {
				alertSubscriptionDtl.setAsset(EsapiUtil
						.stripXSSCharacters(request
								.getParameter(AppConstants.ASSET)));
			}else if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.SHOP)) != null
						&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.SHOP)).trim().isEmpty()) {
				alertSubscriptionDtl.setShop(EsapiUtil
						.stripXSSCharacters(request
								.getParameter(AppConstants.SHOP)));
			}else if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MODEL)) != null
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MODEL)).trim().isEmpty()) {
				alertSubscriptionDtl.setModel(EsapiUtil
						.stripXSSCharacters(request
								.getParameter(AppConstants.MODEL)));
			}
			if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CUSTOMER)) != null
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CUSTOMER)).trim().isEmpty()) {
				alertSubscriptionDtl.setCustomer(EsapiUtil
						.stripXSSCharacters(request
								.getParameter(AppConstants.CUSTOMER)));
			}
			if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_SUBSCRIPTION_SERVICE)) != null
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_SUBSCRIPTION_SERVICE)).trim().isEmpty()) {
				alertSubscriptionDtl
						.setService(EsapiUtil.stripXSSCharacters(request
								.getParameter(AppConstants.ALERT_SUBSCRIPTION_SERVICE)));
			}
			if (EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.SUB_DIVISION)) != null
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.SUB_DIVISION)).trim().isEmpty()) {
				alertSubscriptionDtl.setSubDivision(EsapiUtil
						.stripXSSCharacters(request
								.getParameter(AppConstants.SUB_DIVISION)));
			}
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MODEL_ID))
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MODEL_ID)).trim().isEmpty()) {
				alertSubscriptionDtl.setModelId(EsapiUtil
						.stripXSSCharacters(request
								.getParameter(AppConstants.MODEL_ID)));
			}
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_SUBSCRIPTION_USER_EMAIL))
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_SUBSCRIPTION_USER_EMAIL)).trim().isEmpty()) {
				alertSubscriptionDtl
						.setUserEmail(EsapiUtil.stripXSSCharacters(request
								.getParameter(AppConstants.ALERT_SUBSCRIPTION_USER_EMAIL)));
			}
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USERNAME))
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USERNAME)).trim().isEmpty()) {
				alertSubscriptionDtl.setUserName(EsapiUtil
						.stripXSSCharacters(request
								.getParameter(AppConstants.USERNAME)));
			}
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.NOTIFICATION_TYPE))
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.NOTIFICATION_TYPE)).trim().isEmpty()) {
				alertSubscriptionDtl.setNotificationType(EsapiUtil
						.stripXSSCharacters(request
								.getParameter(AppConstants.NOTIFICATION_TYPE)));
			}
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.RX_TYPE))
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.RX_TYPE)).trim().isEmpty()) {
				alertSubscriptionDtl.setRxTypeValue(EsapiUtil
						.stripXSSCharacters(request
								.getParameter(AppConstants.RX_TYPE)));
			}
			System.out.println("1............."+request.getParameter(AppConstants.NOTIFICATION_TYPE));
			pass = alertSubscriptionService.editAlert(alertSubscriptionDtl);
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID))&& null!=to && !to.isEmpty() ) {

				prepareMailFormat(null, alertSubscriptionDtl, AppConstants.ALERT_SUBSCRIPTION_MAIL_EDIT, from, to,
						toName, userVO);

			}
			else if (multiSubscriptionPrivilege
					&& pageflag
							.equalsIgnoreCase(AppConstants.ALERT_SUBSCRIPTION_FLAG)) {
				toName = alertSubscriptionDtl.getUserName();
				to = alertSubscriptionDtl.getUserEmail();
				from = userVO.getStrEmail();
				if (!from.trim().equalsIgnoreCase(to.trim())) 
				{
				prepareMultiSubMailFormat(null, alertSubscriptionDtl, AppConstants.ALERT_SUBSCRIPTION_MAIL_EDIT,
						from, to, toName, userVO);
				}
			}
			if(null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID)) && (null==to || to.isEmpty())){
				rmdWebLogger.error(AppConstants.EMAIL_NOT_VALID);
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in editAlert method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return pass;

	}
	
	@RequestMapping(value = AppConstants.REQ_URI_ADDALERTSUBSCRIPTIONDATA, method = RequestMethod.POST)
	@ResponseBody
	 public AlertSubscriptionDetailsVO addAlertSubscriptionData(
			final HttpServletRequest request) throws RMDWebException {
		String returnStr = AppConstants.FAILURE.toUpperCase();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		AlertSubscriptionDetailsVO alertSubscriptionDtls = new AlertSubscriptionDetailsVO();
		String assetCount = null;
		String userId=null;
		String[] alertarr=null;
		String userSeqIdstr=null;
		boolean multiSubscriptionPrivilege = false;
		try {

			String serviceType = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.SERVICE_TYPE));
			String alerts=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERTS));
			String alertType=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_TYPE));
			String fleet=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLEET));
			String region=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REGION));
			String asset=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET));
			String customerId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CUSTOMER_ID));	
			String model = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MODEL));
			String mailFormat = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MAIL_FORMAT));
			String to = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TO));
			String from = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FROM));
			String toName =EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TO_NAME));
			String alertText=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_TEXT));
			String assetText=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_TEXT));
			String regionText=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REGION_TEXT));
			String fleetText=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLEET_TEXT));
			String notificationType=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.NOTIFICATION_TYPE));
			String phoneNumber=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.PHONE_NUMBER));
			String rxValueText=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.VALUE));
			String rxTypeText=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.RX_TYPE));
			String rxTypeValue=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.RX_TYPE_VALUE));
			//Rx-filter value
			String subscribedAlert= EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.SUBSCRIBED_ALERT));
			//values in urgency dropdown etc
			String rxAlertValue=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.RX_ALERT_VALUE));
			//subdivision
			String subDivision=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.SUB_DIVISION));
			String subRegionText =EsapiUtil.stripXSSCharacters(request.getParameter("subRegionText"));
			//shop
			String shop=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.SHOP));
			String shopText=EsapiUtil.stripXSSCharacters(request.getParameter("shopText"));
			//Model
			String modelVal=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MODEL_VALUE));
			String modelText=EsapiUtil.stripXSSCharacters(request.getParameter("modelText"));
			String multiUsersVal=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MULTIUSERSVAL));
			String multiUsersEmail=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MULTIUSERSEMAIL));
			String configAlertModelVal=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CONFIG_ALERT_MODEL_VAL));				
			alertSubscriptionDtls.setMultiUsers(multiUsersVal);
			alertSubscriptionDtls.setService(serviceType);
			alertSubscriptionDtls.setAlertSubscribed(alerts);
			alertSubscriptionDtls.setConfigAlertModelVal(configAlertModelVal);
			multiSubscriptionPrivilege = RMDCommonUtil.componentValue(
					userVO.getComponentList(),
					AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION);
			alertSubscriptionDtls.setMultiSubscriptionPrivilege(multiSubscriptionPrivilege);
			/*
			 * null condition is add to determine from where the function is
			 * called . if userId exist the call is from the admin notification
			 * page
			 */
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID))
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID)).trim().isEmpty()) {
				userId=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID));
				
			}else{
				userId=userVO.getUserId();
			}
			if(null!=alerts && !alerts.trim().isEmpty()){
			alertarr=alerts.split(AppConstants.COMMA);
			}
			/*if service is Eoa
			*/
			
			if (!RMDCommonUtility.isNullOrEmpty(subscribedAlert) && subscribedAlert.equalsIgnoreCase(AppConstants.ALERT_TYPE_RX_TITLES) && !RMDCommonUtility.isNullOrEmpty(rxAlertValue)) {
				String[] titlesArray = rxAlertValue.split(AppConstants.COMMA);
				int titlesCount = titlesArray.length;
				if (titlesCount > AppConstants.MAX_RXTITLES_ALERT_COUNT) {
					alertSubscriptionDtls = new AlertSubscriptionDetailsVO();
					Map <String, String>maxAssetReturnMap = new HashMap<String, String>();
					maxAssetReturnMap.put(
							AppConstants.ERROR_MAX__TITLES_SUBSCRIBED,
							AppConstants.ERROR_MAX__TITLES_SUBSCRIBED);
					alertSubscriptionDtls.setErrorMap(maxAssetReturnMap);

					return alertSubscriptionDtls;
				} else {
					alertarr=rxAlertValue.split(AppConstants.COMMA);
					alertSubscriptionDtls.setValue(rxAlertValue);
				}
			}
			if(null!=subscribedAlert && !subscribedAlert.trim().isEmpty()){
				alertSubscriptionDtls.setRxSubscribedAlerts(subscribedAlert);
			}
			if(null!=rxAlertValue && !rxAlertValue.trim().isEmpty()){
				alertarr=rxAlertValue.split(AppConstants.COMMA);
				alertSubscriptionDtls.setValue(rxAlertValue);
			}
				alertarr=rxTypeText.split(AppConstants.COMMA);
				alertSubscriptionDtls.setRxType(rxTypeText);
			if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_SEQID))
					&& !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_SEQID)).trim().isEmpty()) {
				userSeqIdstr=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_SEQID));
				
			}else{
				userSeqIdstr=userVO.getUsrUsersSeqId().toString();
			}
			
			if(alertType != null && !alertType.isEmpty()){
				if(alertType.equalsIgnoreCase(AppConstants.REGION_TYPE)){
					alertSubscriptionDtls.setRegion(region);
					if(alertType.equalsIgnoreCase(AppConstants.REGION_TYPE)){
						alertSubscriptionDtls.setSubDivision(subDivision);				
					}
				}else if(alertType.equalsIgnoreCase(AppConstants.FLEET_TYPE)){
					alertSubscriptionDtls.setFleet(fleet);				
				}else if(alertType.equalsIgnoreCase(AppConstants.ALERT_TYPE_ASSET)){
					
					assetCount = alertSubscriptionService.getAlertSubAssetCountForUser(userId);
					String[] assetArray = asset.split(AppConstants.COMMA);					
					int assetbasedCount=assetArray.length * alertarr.length;
					int assetSubCount = Integer.parseInt(assetCount) + assetbasedCount;
					if(assetSubCount > AppConstants.MAX_ASSET_ALERT_SUB_COUNT){
						alertSubscriptionDtls = new AlertSubscriptionDetailsVO();
						Map maxAssetReturnMap = new HashMap<String, String>();
						maxAssetReturnMap.put(AppConstants.ERROR_MAX__ASSET_SUBSCRIBED, AppConstants.ERROR_MAX__ASSET_SUBSCRIBED);
						alertSubscriptionDtls.setErrorMap(maxAssetReturnMap);
						
						return alertSubscriptionDtls;
					}else{
						alertSubscriptionDtls.setAsset(asset);
					}
				}else if(alertType.equalsIgnoreCase(AppConstants.SHOP_TYPE)){
					alertSubscriptionDtls.setShop(shop);				
				}else if(alertType.equalsIgnoreCase(AppConstants.MODEL_TYPE)){
					alertSubscriptionDtls.setModel(modelVal);					
				}
			}
			alertSubscriptionDtls.setAlertType(alertType);
			alertSubscriptionDtls.setCustomerId(customerId);
			alertSubscriptionDtls.setSubscriptionModel(model);
			alertSubscriptionDtls.setEmailFormat(mailFormat);
			alertSubscriptionDtls.setUserId(userId);
			alertSubscriptionDtls.setNotificationType(notificationType);
			alertSubscriptionDtls.setPhoneNumber(phoneNumber);
			Long userSeqId = Long.valueOf(userSeqIdstr);
			alertSubscriptionDtls.setUserSeqId(userSeqId.toString());
			
			if (validateAlertSubscriptionData(alertSubscriptionDtls)) {
				returnStr = alertSubscriptionService.addAlertSubscriptionData(alertSubscriptionDtls);
				if(returnStr.equalsIgnoreCase(AppConstants.SUCCESS)){
					alertSubscriptionDtls = new AlertSubscriptionDetailsVO();
					Map successReturnMap = new HashMap<String, String>();
					successReturnMap.put(AppConstants.SUCCESS_ALERT_SUBSCRIBED, AppConstants.SUCCESS_ALERT_SUBSCRIBED);
					alertSubscriptionDtls.setErrorMap(successReturnMap);
					if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID))
							&& null != to && !to.isEmpty()) {
						if (alertType != null && !alertType.isEmpty()) {
							if (alertType
									.equalsIgnoreCase(AppConstants.REGION_TYPE)) {
								alertSubscriptionDtls.setRegion(regionText);
								alertSubscriptionDtls
										.setSubDivision(subRegionText);
							} else if (alertType
									.equalsIgnoreCase(AppConstants.FLEET_TYPE)) {
								alertSubscriptionDtls.setFleet(fleetText);
							} else if (alertType
									.equalsIgnoreCase(AppConstants.ALERT_TYPE_ASSET)) {
								alertSubscriptionDtls.setAsset(assetText);
							} else if (alertType
									.equalsIgnoreCase(AppConstants.SHOP_TYPE)) {
								alertSubscriptionDtls.setShop(shopText);
							} else if (alertType
									.equalsIgnoreCase(AppConstants.MODEL_TYPE)) {
								alertSubscriptionDtls.setModel(modelText);
							}
						}
						alertSubscriptionDtls.setCustomer(customerId);
						alertSubscriptionDtls.setAlertSubscribed(alertText);
						alertSubscriptionDtls.setService(serviceType);
						alertSubscriptionDtls.setValue(rxValueText);
						alertSubscriptionDtls.setRxTypeValue(rxTypeValue);
						alertSubscriptionDtls
								.setRxSubscribedAlerts(subscribedAlert);
						prepareMailFormat(null, alertSubscriptionDtls, AppConstants.ALERT_SUBSCRIPTION_MAIL_ADD,
								from, to, toName, userVO);
					} else if (null != multiUsersEmail
							&& !multiUsersEmail.isEmpty()) {
						if (alertType != null && !alertType.isEmpty()) {
							if (alertType
									.equalsIgnoreCase(AppConstants.REGION_TYPE)) {
								alertSubscriptionDtls.setRegion(regionText);
								alertSubscriptionDtls
										.setSubDivision(subRegionText);
							} else if (alertType
									.equalsIgnoreCase(AppConstants.FLEET_TYPE)) {
								alertSubscriptionDtls.setFleet(fleetText);
							} else if (alertType
									.equalsIgnoreCase(AppConstants.ALERT_TYPE_ASSET)) {
								alertSubscriptionDtls.setAsset(assetText);
							} else if (alertType
									.equalsIgnoreCase(AppConstants.SHOP_TYPE)) {
								alertSubscriptionDtls.setShop(shopText);
							} else if (alertType
									.equalsIgnoreCase(AppConstants.MODEL_TYPE)) {
								alertSubscriptionDtls.setModel(modelText);
							}
						}
						alertSubscriptionDtls.setCustomer(customerId);
						alertSubscriptionDtls.setAlertSubscribed(alertText);
						alertSubscriptionDtls.setService(serviceType);
						alertSubscriptionDtls.setValue(rxValueText);
						alertSubscriptionDtls.setRxTypeValue(rxTypeValue);
						alertSubscriptionDtls
								.setRxSubscribedAlerts(subscribedAlert);
						from = userVO.getStrEmail();
						String[] multiUsersEmailArr = multiUsersEmail
								.split(AppConstants.TILDA);
						if (multiUsersEmailArr.length > 0) {
							for (String strMultiUsersEmail : multiUsersEmailArr) {
								String[] strArrMultiUsersEmail = strMultiUsersEmail
										.split("\\|");
								toName = strArrMultiUsersEmail[0];
								to = strArrMultiUsersEmail[1];
								if (!from.trim().equalsIgnoreCase(to.trim())) {
									prepareMultiSubMailFormat(null,
											alertSubscriptionDtls, AppConstants.ALERT_SUBSCRIPTION_MAIL_ADD, from,
											to, toName, userVO);
								}
							}
						}
					}						
					if(null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID)) && (null==to || to.isEmpty())&& (null == multiUsersEmail)){
						rmdWebLogger.error(AppConstants.EMAIL_NOT_VALID);
					}
				}
			}
			} catch (Exception ex) {
				rmdWebLogger.error("Exception occured in addAlertSubscriptionData method ", ex);
				RMDWebErrorHandler.handleException(ex);

			}
		

		return alertSubscriptionDtls;
	}
	
	@RequestMapping(value = AppConstants.GET_FLEET_FOR_CUSTOMER)
	@ResponseBody public
	Map<String, String> getFleetsForCustomer(
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId,@RequestParam(value = AppConstants.SERVICE, required = true) final String service)
					throws RMDWebException {
		
		Map<String, String> fleetsMap = null;
		try {
			if(AppConstants.ATS.equalsIgnoreCase(service)){
			fleetsMap = alertSubscriptionService.getFleetsForCustomer(EsapiUtil.stripXSSCharacters(customerId));
			}else{
				fleetsMap =	alertSubscriptionService.getFleetsForEOACustomer(EsapiUtil.stripXSSCharacters(customerId));
			}
			} catch (Exception ex) {
				rmdWebLogger.error("Exception occured in getFleetsForCustomer method ", ex);
				RMDWebErrorHandler.handleException(ex);

			}
		

		return fleetsMap;
	}
	
	@RequestMapping(value = AppConstants.GET_REGION_FOR_CUSTOMER)
	@ResponseBody public
	Map<String, String> getRegionsForCustomer(
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId)
					throws RMDWebException {
		
		Map<String, String> fleetsMap = null;
		try {
			
			fleetsMap = alertSubscriptionService.getRegionsForCustomer(EsapiUtil.stripXSSCharacters(customerId));
			} catch (Exception ex) {
				rmdWebLogger.error("Exception occured in getRegionsForCustomer method ", ex);
				RMDWebErrorHandler.handleException(ex);

			}
		

		return fleetsMap;
	}
	
	@RequestMapping(value = AppConstants.GET_SUBDIVISION_FOR_REGION)
	@ResponseBody public
	Map<String, String> getSubDivisionForRegion(
			@RequestParam(value = AppConstants.REGION, required = true) final String region, 
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId)
					throws RMDWebException {
		
		Map<String, String> mapSubDivisionMap = null;
		try {
			
			mapSubDivisionMap = alertSubscriptionService.getSubDivisionForRegion(EsapiUtil.stripXSSCharacters(region), EsapiUtil.stripXSSCharacters(customerId));

			} catch (Exception ex) {
				rmdWebLogger.error("Exception occured in getSubDivisionForRegion method ", ex);
				RMDWebErrorHandler.handleException(ex);

			}
		

		return mapSubDivisionMap;
	}
	
	private boolean validateAlertSubscriptionData(
			AlertSubscriptionDetailsVO alertSubscriptionDtls) {
		boolean result = true;
		Map<String, String> errorMap = new HashMap<String, String>();
		if (alertSubscriptionDtls.getCustomerId() == null
				|| alertSubscriptionDtls.getCustomerId().isEmpty()) {
			errorMap.put(AppConstants.ERROR_CUSTOMER,
					AppConstants.ERROR_CUSTOMER);
		}
		if (alertSubscriptionDtls.getService() == null
				|| alertSubscriptionDtls.getService().isEmpty()) {
			errorMap.put(AppConstants.ERROR_SERVICE, AppConstants.ERROR_SERVICE);
		}
		if (alertSubscriptionDtls.getAlertSubscribed() == null
				|| alertSubscriptionDtls.getAlertSubscribed().isEmpty()) {
			errorMap.put(AppConstants.ERROR_ALERT_SUBSCRIBED,
					AppConstants.ERROR_ALERT_SUBSCRIBED);
		}
		alertSubscriptionDtls.setErrorMap(errorMap);
		return result;
	}

	/**
	 * @Author:iGATE
	 * @param request
	 * @return String
	 * @Description: method to get user notification page
	 */
	@RequestMapping(value = AppConstants.REQ_URI_NOTIFICATIONMANAGEMENT, method = RequestMethod.GET)
	public String getNotificationManagementPage(final HttpServletRequest request)
			throws Exception {
		rmdWebLogger
				.debug("AlertSubscriptionController Controller : getnotificationManagementPage() method Starts");
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		List<UserManagementBean> userMgmntBeanList = new ArrayList<UserManagementBean>();
		final UserManagementBean userMgmntBean = new UserManagementBean();
		List<String> atsCustomers = new ArrayList<String>();
		List<String> eoaCustomers = new ArrayList<String>();
		String email = null;
		String flag=null;
		boolean privilege = false;
		try {

			privilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.SUBMENU_ADMINISTRATION_NOTIFICATIONS_ALERT_SUBSCRIPTION_MODEL);
			request.setAttribute(AppConstants.ADMIN_ALERT_SUBSCRIPTION_MODEL_COMPONENT,privilege);
			
			userMgmntBeanList = userManagementService
					.getAlertUsers(userMgmntBean);

			request.setAttribute(AppConstants.USER_MGMNT_LIST,
					userMgmntBeanList);

			// adding for pagination
			request.setAttribute(AppConstants.ADMINISTRATOR_DEFAULT_RECORDS,
					AppConstants.ADMIN_NOTIFICATION_DEFAULT_RECORDS);

			atsCustomers = alertSubscriptionService.getATSEnabledCustomers();
			String comaSepratedStr = RMDCommonUtility
					.getCommaSeperatedString(atsCustomers);
			request.setAttribute(AppConstants.ATS_CUSTOEMRS, comaSepratedStr);
			eoaCustomers = alertSubscriptionService.getEOACustomerList();
			comaSepratedStr = RMDCommonUtility.getCommaSeperatedString(eoaCustomers);
			request.setAttribute(AppConstants.EOA_CUSTOMERS, comaSepratedStr);
			flag= alertSubscriptionService.getRXLookupFlag();
			request.setAttribute(AppConstants.RX_FLAG, flag);
			if (null != userVO.getStrEmail()) {
				email = userVO.getStrEmail();
			} else {
				email = alertSubscriptionService
						.getUserEmail(AppConstants.ADMIN_UID_MAP
								+ userVO.getUserId());
			}
			request.setAttribute(AppConstants.ADMIN_MAILID, email);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getnotificationManagementPage() method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
				.debug("AlertSubscriptionController Controller : getnotificationManagementPage() method Ends");
		return AppConstants.VIEW_NOTIFICATIONMANAGEMENT;
	}

	/**
	 * @Author:iGATE
	 * @param userId
	 * @return String
	 * @Description: method to get user email of the user
	 */
	@RequestMapping(value = AppConstants.REQ_URI_USER_EMAIL)
	@ResponseBody public
	String getUserEmail(String userId) throws Exception {
		String email = AppConstants.EMPTY_STRING;
		try {
			email = alertSubscriptionService.getUserEmail(AppConstants.ADMIN_UID_MAP +EsapiUtil.stripXSSCharacters(userId));
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getUserEmail method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return email;
	}

	/**
	 * @Author:iGATE
	 * @param userId
	 * @return userId
	 * @Description: method used to get the alert subscription privilage of the
	 *               user
	 */
	@RequestMapping(value = AppConstants.REQ_URI_USER_COMPONENT)
	@ResponseBody public
	Map<String, Boolean> getUserComponent(String userId) throws Exception {
		boolean privilege = false;
		List<String> userComponentList = null;
		Map<String, String> componentList = new HashMap<String, String>();
		Map<String, Boolean> responseMap = new HashMap<String, Boolean>();
		
		try {
			userComponentList = userManagementService
					.getUserComponentList(EsapiUtil.stripXSSCharacters(userId));

			componentList.put(AppConstants.ALERT_SUBSCRIPTION_ATS,
					AppConstants.ALERT_SUBSCRIPTION_ATS_COMPONENT);
			componentList.put(AppConstants.ALERT_SUBSCRIPTION_EOA,
					AppConstants.ALERT_SUBSCRIPTION_EOA_COMPONENT);

			if (!componentList.isEmpty()) {
				Set<Map.Entry<String, String>> entries = componentList
						.entrySet();
				for (Map.Entry<String, String> component : entries) {
					String componentName;
					componentName = authService.getLookUpValueForName(component
							.getKey());
					privilege = alertSubscriptionService.getcomponentValue(
							userComponentList, componentName);
					responseMap.put(component.getValue(), privilege);
					
				}
			}

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getUserComponent method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return responseMap;
	}

	/**
	 * @Author:iGATE
	 * @param request
	 * @return void
	 * @Description: method used to prepare mail format and send mail to the
	 *               user
	 */	
	public void prepareMailFormat(
			List<AlertSubscriptionDetailsVO> alertSubscriptionDetailsVOList,
			AlertSubscriptionDetailsVO alertSubscriptionDtls, String task,
			String fromEmail, String toEmail, String toName, UserVO userVO)
			throws RMDWebException {
		
		String customer = "";
		String  value = "";
		String combinedValue = "";
		String subject = null;
		String finalSubject = null;
		String finalMsg;
		String message = null;
		StringBuilder strBuildValue = null;
		StringBuilder strFinalMsg = null;
		String fromName = userVO.getStrFirstName();
		try {			
			String commonMsg = getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_HI)
					+ toName
					+ getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_MSGPART1)
					+ fromName + " - " + fromEmail;

			if (AppConstants.ALERT_SUBSCRIPTION_MAIL_ADD.equalsIgnoreCase(task)) {
				subject = getMailTemplateLookupVal(AppConstants.ADMIN_ADD_ALERTSUB_SUBJECT);
				message = commonMsg
						+ getMailTemplateLookupVal(AppConstants.ADMIN_ADD_ALERTSUB_MSGPART);
			} else if (AppConstants.ALERT_SUBSCRIPTION_MAIL_EDIT.equalsIgnoreCase(task)) {
				subject = getMailTemplateLookupVal(AppConstants.ADMIN_EDIT_ALERTSUB_SUBJECT);
				message = commonMsg + getMailTemplateLookupVal(AppConstants.ADMIN_EDIT_ALERTSUB_MSGPART);
			} else if (AppConstants.ALERT_SUBSCRIPTION_DELETE.equalsIgnoreCase(task)) {
				subject = getMailTemplateLookupVal(AppConstants.ADMIN_DELETE_ALERTSUB_SUBJECT);
				message = commonMsg
						+ getMailTemplateLookupVal(AppConstants.ADMIN_DELETE_ALERTSUB_MSGPART);
			} else if (AppConstants.ALERT_SUBSCRIPTION_DEACTIVATE.equalsIgnoreCase(task)) {
				subject = getMailTemplateLookupVal(AppConstants.ADMIN_DEACTIVATE_ALERTSUB_SUBJECT);
				message = commonMsg
						+ getMailTemplateLookupVal(AppConstants.ADMIN_DEACTIVATE_ALERTSUB_MSGPART);
			} else if (AppConstants.ALERT_SUBSCRIPTION_ACTIVATE.equalsIgnoreCase(task)) {
				subject = getMailTemplateLookupVal(AppConstants.ADMIN_ACTIVATE_ALERTSUB_SUBJECT);
				message = commonMsg
						+ getMailTemplateLookupVal(AppConstants.ADMIN_ACTIVATE_ALERTSUB_MSGPART);
			}
			if (!AppConstants.ALERT_SUBSCRIPTION_MAIL_ADD.equalsIgnoreCase(task)
					&& null != alertSubscriptionDetailsVOList) {
				strBuildValue = new StringBuilder();
				for (AlertSubscriptionDetailsVO rows : alertSubscriptionDetailsVOList) {
					String alerts = rows.getAlertSubscribed();
					customer = rows.getCustomer();
					if (rows.getFleet() != null && !rows.getFleet().isEmpty()) {
						strBuildValue = strBuildValue.append(rows.getFleet());

					} else if (rows.getAsset() != null
							&& !rows.getAsset().isEmpty()) {
						strBuildValue = strBuildValue.append(rows.getAsset());
					} else if (rows.getRegion() != null
							&& !rows.getRegion().isEmpty()) {
						strBuildValue = strBuildValue.append(rows.getRegion());
						if (rows.getSubDivision() != null
								&& !rows.getSubDivision().isEmpty()) {
							strBuildValue = strBuildValue.append(','+rows.getSubDivision());
						}
					}else if (rows.getShop() != null
							&& !rows.getShop().isEmpty()) {
						strBuildValue = strBuildValue.append(rows.getShop());
						value = strBuildValue.toString();
						value=value.replace('|',','); 
						strBuildValue = strBuildValue.append(value);
					}else if (null !=rows.getModel()
							&& !rows.getModel().isEmpty()) {
						strBuildValue = strBuildValue.append(rows.getModel());
					}
					value = strBuildValue.toString();
					combinedValue = customer + " " + value;
										
					finalSubject = subject + combinedValue + AppConstants.SYMBOL_COMMA_SPACE + alerts;
					strFinalMsg = new StringBuilder();
					if(AppConstants.EOA.equalsIgnoreCase(rows.getService())){
						strFinalMsg = strFinalMsg.append(message + " '" + alerts +"' "+AppConstants.COMMA+AppConstants.SINGLE_QTE+rows.getValue()+ AppConstants.ALERT_SUBSCRIPTION_FOR + combinedValue+AppConstants.SINGLE_QTE +AppConstants.COMMA+"Rx Type :"+rows.getRxType());
					}else{
						strFinalMsg = strFinalMsg.append(message + " '" + alerts + AppConstants.ALERT_SUBSCRIPTION_FOR + combinedValue+AppConstants.SINGLE_QTE);
					}
					if (AppConstants.ALERT_SUBSCRIPTION_MAIL_EDIT.equalsIgnoreCase(task)) {
						strFinalMsg = strFinalMsg.append( AppConstants.ADMIN_EDIT_ALERTSUB_MSGPART2);
					} else if (AppConstants.ALERT_SUBSCRIPTION_DELETE.equalsIgnoreCase(task)) {
						strFinalMsg = strFinalMsg.append( AppConstants.ADMIN_DELETE_ALERTSUB_MSGPART2);
					} else if (AppConstants.ALERT_SUBSCRIPTION_DEACTIVATE.equalsIgnoreCase(task)) {
						strFinalMsg = strFinalMsg.append( AppConstants.ADMIN_DEACTIVATE_ALERTSUB_MSGPART2);
					} else if (AppConstants.ALERT_SUBSCRIPTION_ACTIVATE.equalsIgnoreCase(task)) {
						strFinalMsg = strFinalMsg.append( AppConstants.ADMIN_ALERTSUB_MSGPART2);
					}
					finalMsg = strFinalMsg.toString();
					int count = 0;
					while (count <= 0) {
						count = alertSubscriptionService.postMail(toEmail,
								finalSubject, finalMsg, fromEmail);
					}
					if (count > 0) {
						rmdWebLogger.info(AppConstants.SUCCESS);
					} else {
						rmdWebLogger.info(AppConstants.FAILURE);
					}
				}
			} else if (null != alertSubscriptionDtls) {

				String customerId = alertSubscriptionDtls.getCustomer();
				combinedValue = null;
				String service =alertSubscriptionDtls.getService();
				String[] alertsArr;
				String[] rxType;
				if (null != alertSubscriptionDtls.getAlertSubscribed()) {
					if(AppConstants.EOA.equalsIgnoreCase(service)){
						alertsArr=alertSubscriptionDtls.getValue().split(AppConstants.TILDA);
					}else{
					alertsArr = alertSubscriptionDtls
							.getAlertSubscribed().split(AppConstants.SYMBOL_COMMA);
					}
					if(alertSubscriptionDtls.getRxTypeValue()!=null && !alertSubscriptionDtls.getRxTypeValue().equals(AppConstants.EMPTY_SPACE)){
						rxType = alertSubscriptionDtls.getRxTypeValue().split(AppConstants.TILDA);
					}
					else
					{
						rxType = new String[0];
					}
					for (String alerts : alertsArr) {
						combinedValue = null;
						alerts=alerts.replace('~',',');
						if (null != alertSubscriptionDtls.getRegion()) {
							String[] regionArr = alertSubscriptionDtls
									.getRegion().split(AppConstants.SYMBOL_COMMA);
							strFinalMsg = new StringBuilder();
							if(regionArr.length==1 && !RMDCommonUtility.isNullOrEmpty(alertSubscriptionDtls.getSubDivision())){					
								 regionArr = alertSubscriptionDtls
										.getSubDivision().split(AppConstants.SYMBOL_COMMA);
							}
							if (regionArr.length > 0) {
								for (String region : regionArr) {
									for(String rxTypeValue : rxType)
									{
									if (AppConstants.EOA
											.equalsIgnoreCase(service)) {
										finalSubject = getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_RX_SUBJECT);
										strFinalMsg = strFinalMsg.append( prepareEoaMailFormat(
												alertSubscriptionDtls, alerts,
												message));
										if (null != rxTypeValue
												&& !rxTypeValue
														.isEmpty()) {
											strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTYPE);
											strFinalMsg = strFinalMsg.append(rxTypeValue);
										}
										strFinalMsg = strFinalMsg.append( getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_REGION)
												+ alertSubscriptionDtls
														.getRegion());
										if(null!=alertSubscriptionDtls
												.getSubDivision()&& !alertSubscriptionDtls.getSubDivision().isEmpty()){
											strFinalMsg = strFinalMsg.append(getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_SUBDIVISION_BASED)
												+ region );
										}
										strFinalMsg = strFinalMsg.append(AppConstants.BOLD_TAG_END);
									}else{
									combinedValue = customerId + " " + region;
									finalSubject = subject + combinedValue
											+ AppConstants.SYMBOL_COMMA_SPACE + alerts;
									strFinalMsg = strFinalMsg.append(  message
											+ AppConstants.SINGLE_QTE+alerts
											+ AppConstants.ALERT_SUBSCRIPTION_FOR
											+ combinedValue +AppConstants.SINGLE_QTE);
									}
									if (AppConstants.ALERT_SUBSCRIPTION_MAIL_ADD.equalsIgnoreCase(task)) {
										strFinalMsg = strFinalMsg.append(  AppConstants.ADMIN_ALERTSUB_MSGPART2);
									} else if (AppConstants.ALERT_SUBSCRIPTION_MAIL_EDIT.equalsIgnoreCase(task)) {
										strFinalMsg = strFinalMsg.append(  AppConstants.ADMIN_EDIT_ALERTSUB_MSGPART2);
									}
									finalMsg = strFinalMsg.toString();
									int count = 0;
									while (count <= 0) {
										count = alertSubscriptionService
												.postMail(toEmail,
														finalSubject, finalMsg,
														fromEmail);
									}
									if (count > 0) {
										rmdWebLogger.info(AppConstants.SUCCESS);
									} else {
										rmdWebLogger.info(AppConstants.FAILURE);
									}
								}
							}
							}
						}
						else if (null != alertSubscriptionDtls.getFleet()) {
							String[] fleetArr = alertSubscriptionDtls
									.getFleet().split(AppConstants.SYMBOL_COMMA);
							strFinalMsg = new StringBuilder();
							if (fleetArr.length > 0) {
								for (String fleet : fleetArr) {
									for(String rxTypeValue : rxType)
									{
									if (AppConstants.EOA
											.equalsIgnoreCase(service)) {
										finalSubject = getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_RX_SUBJECT);
										strFinalMsg = strFinalMsg.append(prepareEoaMailFormat(
												alertSubscriptionDtls, alerts,
												message));
										if (null != rxTypeValue
												&& !rxTypeValue
														.isEmpty()) {
											strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTYPE);
											strFinalMsg = strFinalMsg.append(rxTypeValue);
										}
										strFinalMsg = strFinalMsg.append(getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_FLEET_BASED)
												+ fleet + AppConstants.BOLD_TAG_END);
									}else{
									combinedValue = customerId + " " + fleet;
									finalSubject = subject + combinedValue
											+ AppConstants.SYMBOL_COMMA_SPACE + alerts;
									strFinalMsg = strFinalMsg.append(message
											+ AppConstants.SINGLE_QTE+alerts
											+ AppConstants.ALERT_SUBSCRIPTION_FOR
											+ combinedValue +AppConstants.SINGLE_QTE);
									}
									if (AppConstants.ALERT_SUBSCRIPTION_MAIL_ADD.equalsIgnoreCase(task)) {
										strFinalMsg = strFinalMsg.append(AppConstants.ADMIN_ALERTSUB_MSGPART2);
									} else if (AppConstants.ALERT_SUBSCRIPTION_MAIL_EDIT.equalsIgnoreCase(task)) {
										strFinalMsg = strFinalMsg.append(AppConstants.ADMIN_EDIT_ALERTSUB_MSGPART2);
									}
									finalMsg = strFinalMsg.toString();
									int count = 0;
									while (count <= 0) {
										count = alertSubscriptionService
												.postMail(toEmail,
														finalSubject, finalMsg,
														fromEmail);
									}
									if (count > 0) {
										rmdWebLogger.info(AppConstants.SUCCESS);
									} else {
										rmdWebLogger.info(AppConstants.FAILURE);
									}
								}
							}
							}
						}
						else if (null != alertSubscriptionDtls.getAsset()) {
							String[] assetArr = alertSubscriptionDtls
									.getAsset().split(AppConstants.SYMBOL_COMMA);
							strFinalMsg = new StringBuilder();
							if (assetArr.length > 0) {
								for (String asset : assetArr) {
									for(String rxTypeValue : rxType)
									{
									if (AppConstants.EOA
											.equalsIgnoreCase(service)) {
										finalSubject = getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_RX_SUBJECT);
										strFinalMsg = strFinalMsg.append(prepareEoaMailFormat(
												alertSubscriptionDtls, alerts,
												message));
										if (null != rxTypeValue
												&& !rxTypeValue
														.isEmpty()) {
											strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTYPE);
											strFinalMsg = strFinalMsg.append(rxTypeValue);
										}
										strFinalMsg = strFinalMsg.append(getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_ASSET_BASED)
												+ asset + AppConstants.BOLD_TAG_END);
									}else{
									combinedValue = customerId + " " + asset;
									finalSubject = subject + combinedValue
											+ AppConstants.SYMBOL_COMMA_SPACE + alerts;
									strFinalMsg = strFinalMsg.append(message
											+ AppConstants.SINGLE_QTE+alerts
											+ AppConstants.ALERT_SUBSCRIPTION_FOR
											+ combinedValue +AppConstants.SINGLE_QTE);
									}
									if (AppConstants.ALERT_SUBSCRIPTION_MAIL_ADD.equalsIgnoreCase(task)) {
										strFinalMsg = strFinalMsg.append(AppConstants.ADMIN_ALERTSUB_MSGPART2);
									} else if (AppConstants.ALERT_SUBSCRIPTION_MAIL_EDIT.equalsIgnoreCase(task)) {
										strFinalMsg = strFinalMsg.append(AppConstants.ADMIN_EDIT_ALERTSUB_MSGPART2);
									}
									finalMsg = strFinalMsg.toString();
									int count = 0;
									while (count <= 0) {
										count = alertSubscriptionService
												.postMail(toEmail,
														finalSubject, finalMsg,
														fromEmail);
									}
									if (count > 0) {
										rmdWebLogger.info(AppConstants.SUCCESS);
									} else {
										rmdWebLogger.info(AppConstants.FAILURE);
									}
								}
							}
							}
						}else if (null != alertSubscriptionDtls.getShop()) {
							String[] shopArr = alertSubscriptionDtls
									.getShop().split(AppConstants.TILDA);
							strFinalMsg = new StringBuilder();
							if (shopArr.length > 0) {
								for (String shop : shopArr) {
									for(String rxTypeValue : rxType)
									{
									if (AppConstants.EOA
											.equalsIgnoreCase(service)) {
										finalSubject = getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_RX_SUBJECT);
										strFinalMsg = strFinalMsg.append(prepareEoaMailFormat(
												alertSubscriptionDtls, alerts,
												message));
										if (null != rxTypeValue
												&& !rxTypeValue
														.isEmpty()) {
											strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTYPE);
											strFinalMsg = strFinalMsg.append(rxTypeValue);
										}
										strFinalMsg = strFinalMsg.append(getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_SHOP_BASED)
												+ shop + AppConstants.BOLD_TAG_END);
									} else{
									combinedValue = customerId + " " + shop;
									finalSubject = subject + combinedValue
											+ AppConstants.SYMBOL_COMMA_SPACE + alerts;
									strFinalMsg = strFinalMsg.append(message
											+ AppConstants.SINGLE_QTE+alerts
											+ AppConstants.ALERT_SUBSCRIPTION_FOR
											+ combinedValue +AppConstants.SINGLE_QTE);
									}
									if (AppConstants.ALERT_SUBSCRIPTION_MAIL_ADD.equalsIgnoreCase(task)) {
										strFinalMsg = strFinalMsg.append(AppConstants.ADMIN_ALERTSUB_MSGPART2);
									} else if (AppConstants.ALERT_SUBSCRIPTION_MAIL_EDIT.equalsIgnoreCase(task)) {
										strFinalMsg = strFinalMsg.append(AppConstants.ADMIN_EDIT_ALERTSUB_MSGPART2);
									}
									finalMsg = strFinalMsg.toString();
									int count = 0;
									while (count <= 0) {
										count = alertSubscriptionService
												.postMail(toEmail,
														finalSubject, finalMsg,
														fromEmail);
									}
									if (count > 0) {
										rmdWebLogger.info(AppConstants.SUCCESS);
									} else {
										rmdWebLogger.info(AppConstants.FAILURE);
									}
								}
							}
							}
						}else if (null != alertSubscriptionDtls.getModel()) {
							String[] modelArr = alertSubscriptionDtls
									.getModel().split(AppConstants.TILDA);
							strFinalMsg = new StringBuilder();
							if (modelArr.length > 0) {
								for (String model : modelArr) {
									for(String rxTypeValue : rxType)
									{
									if (AppConstants.EOA
											.equalsIgnoreCase(service)) {
										finalSubject = getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_RX_SUBJECT);
										strFinalMsg = strFinalMsg.append(prepareEoaMailFormat(
												alertSubscriptionDtls, alerts,
												message));
										if (null != rxTypeValue
												&& !rxTypeValue
														.isEmpty()) {
											strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTYPE);
											strFinalMsg = strFinalMsg.append(rxTypeValue);
										}
										strFinalMsg = strFinalMsg.append(getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_MODEL_BASED)
												+ model + AppConstants.BOLD_TAG_END);										
									} else{
									combinedValue = customerId + " " + model;
									finalSubject = subject + combinedValue
											+ AppConstants.SYMBOL_COMMA_SPACE + alerts;
									strFinalMsg = strFinalMsg.append( message
											+ AppConstants.SINGLE_QTE+alerts
											+ AppConstants.ALERT_SUBSCRIPTION_FOR
											+ combinedValue +AppConstants.SINGLE_QTE);
									}
									if (AppConstants.ALERT_SUBSCRIPTION_MAIL_ADD.equalsIgnoreCase(task)) {
										strFinalMsg = strFinalMsg.append(AppConstants.ADMIN_ALERTSUB_MSGPART2);
									} else if (AppConstants.ALERT_SUBSCRIPTION_MAIL_EDIT.equalsIgnoreCase(task)) {
										strFinalMsg = strFinalMsg.append(AppConstants.ADMIN_EDIT_ALERTSUB_MSGPART2);
									}	
									finalMsg = strFinalMsg.toString();
									int count = 0;
									while (count <= 0) {
										count = alertSubscriptionService
												.postMail(toEmail,
														finalSubject, finalMsg,
														fromEmail);
									}
									if (count > 0) {
										rmdWebLogger.info(AppConstants.SUCCESS);
									} else {
										rmdWebLogger.info(AppConstants.FAILURE);
									}
								}
							}
							}
						}else{
							if(rxType.length > 0){
								for(String rxTypeValue : rxType)
								{
							strFinalMsg = new StringBuilder();
							if (AppConstants.EOA.equalsIgnoreCase(service)) {
								finalSubject = getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_RX_SUBJECT);
								strFinalMsg = strFinalMsg.append(prepareEoaMailFormat(
										alertSubscriptionDtls, alerts, message)
										+ AppConstants.BOLD_TAG_END);
								if (null != rxTypeValue
										&& !rxTypeValue
												.isEmpty()) {
									strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTYPE);
									strFinalMsg = strFinalMsg.append(rxTypeValue);
								}
								
							}else{
							combinedValue = customerId ;
							finalSubject = subject + combinedValue
									+ AppConstants.SYMBOL_COMMA_SPACE + alerts;
							strFinalMsg = strFinalMsg.append(message
									+ AppConstants.SINGLE_QTE+alerts
									+ AppConstants.ALERT_SUBSCRIPTION_FOR
									+ combinedValue + AppConstants.SINGLE_QTE);
							}
							if (AppConstants.ALERT_SUBSCRIPTION_MAIL_ADD.equalsIgnoreCase(task)) {
								strFinalMsg = strFinalMsg.append(AppConstants.ADMIN_ALERTSUB_MSGPART2);
							} else if (AppConstants.ALERT_SUBSCRIPTION_MAIL_EDIT.equalsIgnoreCase(task)) {
								strFinalMsg = strFinalMsg.append(AppConstants.ADMIN_EDIT_ALERTSUB_MSGPART2);
							}
							finalMsg = strFinalMsg.toString();
							int count = 0;
							while (count <= 0) {
								count = alertSubscriptionService
										.postMail(toEmail,
												finalSubject, finalMsg,
												fromEmail);
							}
							if (count > 0) {
								rmdWebLogger.info(AppConstants.SUCCESS);
							} else {
								rmdWebLogger.info(AppConstants.FAILURE);
							}
							}
						}
						
						}
					}
				}
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in AlertSubscriptionServiceImpl() method getUserComponentList",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
	}
	
	public void prepareMultiSubMailFormat(
			List<AlertSubscriptionDetailsVO> alertSubscriptionDetailsVOList,
			AlertSubscriptionDetailsVO alertSubscriptionDtls, String task,
			String fromEmailId, String toEmailId, String toEName, UserVO userVO)
			throws RMDWebException {
		String customer = "";
		String value = "";			
		String strValue = "";
		String subject = null;
		String finalMsg = null;
		StringBuilder strCurrentUser = null;
		StringBuilder strEOAFinalMsg = null;
		StringBuilder strBuildValue = null;
		String message = null;
		String commonMsg = null;
		String finalSubject = null;
		String fromName = userVO.getStrFirstName();
		try {			
			Map<String, String> sysParamMap;
			sysParamMap = alertSubscriptionService.getAllSystemParameters();
			String fromEmailID = sysParamMap
					.get(AppConstants.CUSTMAILER_DEFAULT_EMAIL_ID);
			String mailFooter = sysParamMap
					.get(AppConstants.CUSTMAILER_EMAIL_FOOTER);
			String subjectGE = AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_GE;
			String subjectAlertSub = AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_ALERT;
			String subjectNotification = AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_NOTIFICATION;
			strBuildValue = new StringBuilder();
			if (!AppConstants.ALERT_SUBSCRIPTION_MAIL_ADD.equalsIgnoreCase(task)
					&& null != alertSubscriptionDetailsVOList) {				
				for (AlertSubscriptionDetailsVO rows : alertSubscriptionDetailsVOList) {
					String alerts = rows.getAlertSubscribed();
					alerts = alerts.replace("Rx - ", "");
					customer = rows.getCustomer();
					if (rows.getFleet() != null && !rows.getFleet().isEmpty()) {
						value = rows.getFleet();
						strValue = AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXFLEET;
					} else if (rows.getAsset() != null
							&& !rows.getAsset().isEmpty()) {
						value = rows.getAsset();
						strValue = AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXASSET;
					} else if (rows.getRegion() != null
							&& !rows.getRegion().isEmpty()) {
						value = rows.getRegion();
						if (rows.getSubDivision() != null
								&& !rows.getSubDivision().isEmpty()) {
							strBuildValue = strBuildValue.append(value);
							strBuildValue = strBuildValue.append(',');
							strBuildValue = strBuildValue.append(rows.getSubDivision());
							value = strBuildValue.toString();
						}
						strValue = AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXREGION;
					} else if (rows.getShop() != null
							&& !rows.getShop().isEmpty()) {
						value = rows.getShop();
						value=value.replace('|',','); 
						strValue = AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXSHOP;
					} else if (null != rows.getModel()
							&& !rows.getModel().isEmpty()) {
						value = rows.getModel();
						strValue = AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXMODEL;
					}
					String toName = rows.getUserName();
					String fromEmail = userVO.getStrEmail();
					String toEmail = rows.getUserEmail();
					strCurrentUser = new StringBuilder();
					strCurrentUser = strCurrentUser
							.append(getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_HI));
					strCurrentUser = strCurrentUser.append(toName);
					strCurrentUser = strCurrentUser
							.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE);
					strCurrentUser = strCurrentUser.append(fromName);
					strCurrentUser = strCurrentUser
							.append(AppConstants.OPEN_BRACKET);
					strCurrentUser = strCurrentUser.append(fromEmail);
					commonMsg = strCurrentUser.toString();

					if (AppConstants.EOA.equalsIgnoreCase(rows.getService())) {
						subject = subjectGE
								+ AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_RX
								+ subjectAlertSub;
					} else if (AppConstants.CONFIG_ALERT.equalsIgnoreCase(rows
							.getService())) {
						subject = subjectGE
								+ AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_CONFIG
								+ subjectAlertSub;
					} else {
						subject = subjectGE + AppConstants.ATS
								+ subjectAlertSub;
					}

					if ((AppConstants.ALERT_SUBSCRIPTION_MAIL_EDIT).equalsIgnoreCase(task)) {
						finalSubject = subject
								+ AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_EDIT
								+ subjectNotification;
						message = commonMsg
								+ getMailTemplateLookupVal(AppConstants.ADMIN_EDIT_ALERTSUB_MSGPART);
					} else if ((AppConstants.ALERT_SUBSCRIPTION_DELETE).equalsIgnoreCase(task)) {
						finalSubject = subject
								+ AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_DELETE
								+ subjectNotification;
						message = commonMsg
								+ getMailTemplateLookupVal(AppConstants.ADMIN_DELETE_ALERTSUB_MSGPART);
					} else if (AppConstants.ALERT_SUBSCRIPTION_DEACTIVATE.equalsIgnoreCase(task)) {
						finalSubject = subject
								+ AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_DEACTIVE
								+ subjectNotification;
						message = commonMsg
								+ getMailTemplateLookupVal(AppConstants.ADMIN_DEACTIVATE_ALERTSUB_MSGPART);
					} else if (AppConstants.ALERT_SUBSCRIPTION_ACTIVATE.equalsIgnoreCase(task)) {
						finalSubject = subject
								+ AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_ACTIVE
								+ subjectNotification;
						message = commonMsg
								+ getMailTemplateLookupVal(AppConstants.ADMIN_ACTIVATE_ALERTSUB_MSGPART);
					}

					if (AppConstants.EOA.equalsIgnoreCase(rows.getService())) {
						strEOAFinalMsg = new StringBuilder();
						strEOAFinalMsg = strEOAFinalMsg.append(message);
						strEOAFinalMsg = strEOAFinalMsg
								.append(AppConstants.ATTR_COLON);
						strEOAFinalMsg = strEOAFinalMsg
								.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE);
						if (alerts.equalsIgnoreCase(AppConstants.RX_URGENCY)) {
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXFILTER);
							strEOAFinalMsg = strEOAFinalMsg.append(alerts);
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXURGENCY_TYPE);
							strEOAFinalMsg = strEOAFinalMsg.append(rows
									.getValue());
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
						} else if (alerts
								.equalsIgnoreCase(AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_RXLOCOIMPACT)) {
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXFILTER);
							strEOAFinalMsg = strEOAFinalMsg.append(alerts);
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXLOCO_TYPE);
							strEOAFinalMsg = strEOAFinalMsg.append(rows
									.getValue());
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
						} else if (alerts
								.equalsIgnoreCase(AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_RXSUB_SYSTEM)) {
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXFILTER);
							strEOAFinalMsg = strEOAFinalMsg.append(alerts);
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXSUBSYSTEM_TYPE);
							strEOAFinalMsg = strEOAFinalMsg.append(rows
									.getValue());
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
						} else if (alerts.equalsIgnoreCase(AppConstants.TITLES)) {
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXFILTER);
							strEOAFinalMsg = strEOAFinalMsg.append(alerts);
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTITLE_TYPE);
							strEOAFinalMsg = strEOAFinalMsg.append(rows
									.getValue());
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
						}
						if (null != rows.getRxType() && !rows.getRxType().equalsIgnoreCase(AppConstants.EMPTYSTRING)) {
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTYPE);
							strEOAFinalMsg = strEOAFinalMsg.append(rows.getRxType());
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
						}
						if (null != value && !value.isEmpty()) {
							strEOAFinalMsg = strEOAFinalMsg.append(strValue);
							strEOAFinalMsg = strEOAFinalMsg.append(value);
							strEOAFinalMsg = strEOAFinalMsg
									.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
						}
						else
						{
							strEOAFinalMsg = strEOAFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_CUSTOMER);
							strEOAFinalMsg = strEOAFinalMsg.append(customer);
							strEOAFinalMsg = strEOAFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
						}
						strEOAFinalMsg = strEOAFinalMsg
								.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART);
						strEOAFinalMsg = strEOAFinalMsg.append(omdConnection);
						strEOAFinalMsg = strEOAFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART_URL);
						strEOAFinalMsg = strEOAFinalMsg
								.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE);
						strEOAFinalMsg = strEOAFinalMsg.append(mailFooter);
						finalMsg = strEOAFinalMsg.toString();
					} else if (AppConstants.CONFIG_ALERT.equalsIgnoreCase(rows
							.getService())) {
						finalMsg = prepareConfigMailFormat(message, alerts,
								customer, value, strValue,null,null,mailFooter);
					} else {
						finalMsg = prepareATSMailFormat(message, alerts,
								customer, value, strValue,null,null,mailFooter);
					}

					int count = 0;
					if (!fromEmail.equalsIgnoreCase(toEmail)) {
						while (count <= 0) {
							String mailID = fromEmailID;
							count = alertSubscriptionService.postMail(toEmail,
									finalSubject, finalMsg, mailID);
						}
						if (count > 0) {
							rmdWebLogger.info(AppConstants.SUCCESS);
						} else {
							rmdWebLogger.info(AppConstants.FAILURE);
						}
					}
				}
			} else if (null != alertSubscriptionDtls) {
				String service = alertSubscriptionDtls.getService();
				commonMsg = getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_HI)
						+ toEName
						+ AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE
						+ fromName + AppConstants.OPEN_BRACKET + fromEmailId;

				if (AppConstants.EOA.equalsIgnoreCase(service)) {
					subject = subjectGE
							+ AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_RX
							+ subjectAlertSub;
				} else if (AppConstants.CONFIG_ALERT.equalsIgnoreCase(service)) {
					subject = subjectGE
							+ AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_CONFIG
							+ subjectAlertSub;
				} else {
					subject = subjectGE + AppConstants.ATS + subjectAlertSub;
				}

				if ((AppConstants.ALERT_SUBSCRIPTION_MAIL_ADD).equalsIgnoreCase(task)) {
					finalSubject = subject
							+ AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_ADD
							+ subjectNotification;
					message = commonMsg
							+ getMailTemplateLookupVal(AppConstants.ADMIN_ADD_ALERTSUB_MSGPART);
				} else if ((AppConstants.ALERT_SUBSCRIPTION_MAIL_EDIT).equalsIgnoreCase(task)) {
					finalSubject = subject
							+ AppConstants.ALERT_SUBSCRIPTION_MAILSUBJECT_EDIT
							+ subjectNotification;
					message = commonMsg
							+ getMailTemplateLookupVal(AppConstants.ADMIN_EDIT_ALERTSUB_MSGPART);
				}
				String customerId = alertSubscriptionDtls.getCustomer();				
				String[] alertsArr = null;
				String[] rxType = null;
				if (null != alertSubscriptionDtls.getAlertSubscribed()) {
					if (AppConstants.EOA.equalsIgnoreCase(service)) {
						if(alertSubscriptionDtls.getValue()!= null && !alertSubscriptionDtls.getValue().equals(AppConstants.EMPTY_SPACE)){
						alertsArr = alertSubscriptionDtls.getValue().split(AppConstants.TILDA);
						}
						else
						{
							alertsArr = new String[0];
						}
						if(alertSubscriptionDtls.getRxTypeValue()!=null && !alertSubscriptionDtls.getRxTypeValue().equals(AppConstants.EMPTY_SPACE)){
							rxType = alertSubscriptionDtls.getRxTypeValue().split(AppConstants.TILDA);
						}
						else
						{
							rxType = new String[0];
						}
					} else {
						alertsArr = alertSubscriptionDtls.getAlertSubscribed()
								.split(AppConstants.TILDA);
					}
					for (String alerts : alertsArr) {
						alerts=alerts.replace('~',',');
						if (null != alertSubscriptionDtls.getRegion()) {
							String[] regionArr = alertSubscriptionDtls
									.getRegion().split(AppConstants.SYMBOL_COMMA);
							String regionName = AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXREGION;
							String subregionName = AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXSUBDIVISION;
							if (regionArr.length == 1 && !RMDCommonUtility.isNullOrEmpty(alertSubscriptionDtls.getSubDivision())) {
									regionArr = alertSubscriptionDtls
											.getSubDivision().split(AppConstants.SYMBOL_COMMA);
								}					
							if (regionArr.length > 0) {
								for (String region : regionArr) {
									if (AppConstants.EOA
											.equalsIgnoreCase(service)) {
										for(String rxTypeValue : rxType)
										{
										StringBuilder strfinalMsg = new StringBuilder();
										strfinalMsg = strfinalMsg.append(prepareAlertEoaMailFormat(
												alertSubscriptionDtls, alerts,
												message));
										if (null != rxTypeValue
												&& !rxTypeValue
														.isEmpty()) {
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTYPE);
										strfinalMsg = strfinalMsg.append(rxTypeValue);
										}
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXREGION);
										strfinalMsg = strfinalMsg.append(alertSubscriptionDtls.getRegion());
										if (null != alertSubscriptionDtls
												.getSubDivision()
												&& !alertSubscriptionDtls
														.getSubDivision()
														.isEmpty()) {
											strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
											strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXSUBDIVISION);
											strfinalMsg = strfinalMsg.append(region);
										}										
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART);
										strfinalMsg = strfinalMsg.append(omdConnection);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART_URL);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE);
										strfinalMsg = strfinalMsg.append(mailFooter);
										finalMsg = strfinalMsg.toString();
										int result = postMail(toEmailId,
														finalSubject, finalMsg,
														fromEmailID);
										if (result > 0) {
											rmdWebLogger.info(AppConstants.SUCCESS);
										} else {
											rmdWebLogger.info(AppConstants.FAILURE);
										}
									}
									} else if (AppConstants.CONFIG_ALERT
											.equalsIgnoreCase(service)) {
										if (null != alertSubscriptionDtls
												.getSubDivision()
												&& !alertSubscriptionDtls
														.getSubDivision()
														.isEmpty()) {
											finalMsg = prepareConfigMailFormat(
													message, alerts, customerId,
													alertSubscriptionDtls.getRegion(), regionName,region, subregionName,mailFooter);

										}else{
											finalMsg = prepareConfigMailFormat(
													message, alerts, customerId,
													alertSubscriptionDtls.getRegion(), regionName,null, null,mailFooter);

										}
										int result = postMail(toEmailId,
												finalSubject, finalMsg,
												fromEmailID);
								if (result > 0) {
									rmdWebLogger.info(AppConstants.SUCCESS);
								} else {
									rmdWebLogger.info(AppConstants.FAILURE);
								}
										} else {
											if (null != alertSubscriptionDtls
													.getSubDivision()
													&& !alertSubscriptionDtls
															.getSubDivision()
															.isEmpty()) {
										finalMsg = prepareATSMailFormat(
												message, alerts, customerId,
												alertSubscriptionDtls.getRegion(), regionName,region, subregionName,mailFooter);
											}else
											{
												finalMsg = prepareATSMailFormat(
														message, alerts, customerId,
														alertSubscriptionDtls.getRegion(), regionName,null, null,mailFooter);
											}
											int result = postMail(toEmailId,
													finalSubject, finalMsg,
													fromEmailID);
									if (result > 0) {
										rmdWebLogger.info(AppConstants.SUCCESS);
									} else {
										rmdWebLogger.info(AppConstants.FAILURE);
									}
									}
								}
							}
						} else if (null != alertSubscriptionDtls.getFleet()) {
							String[] fleetArr = alertSubscriptionDtls
									.getFleet().split(AppConstants.SYMBOL_COMMA);
							String valueName = AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXFLEET;
							if (fleetArr.length > 0) {
								for (String fleet : fleetArr) {
									if (AppConstants.EOA
											.equalsIgnoreCase(service)) {
										for(String rxTypeValue : rxType)
										{
										StringBuilder strfinalMsg = new StringBuilder();
										strfinalMsg = strfinalMsg.append(prepareAlertEoaMailFormat(
												alertSubscriptionDtls, alerts,
												message));
										if(rxTypeValue !=null && !rxTypeValue.equals(AppConstants.EMPTYSTRING)){
											strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTYPE);
											strfinalMsg = strfinalMsg.append(rxTypeValue);
										}
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXFLEET);
										strfinalMsg = strfinalMsg.append(fleet);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART);
										strfinalMsg = strfinalMsg.append(omdConnection);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART_URL);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE);
										strfinalMsg = strfinalMsg.append(mailFooter);
										finalMsg = strfinalMsg.toString();
										int result = postMail(toEmailId,
												finalSubject, finalMsg,
												fromEmailID);
										if (result > 0) {
											rmdWebLogger.info(AppConstants.SUCCESS);
										} else {
											rmdWebLogger.info(AppConstants.FAILURE);
										}
									}
									} else if (AppConstants.CONFIG_ALERT
											.equalsIgnoreCase(service)) {
										finalMsg = prepareConfigMailFormat(
												message, alerts, customerId,
												fleet,valueName,null,null,mailFooter);
										int result = postMail(toEmailId,
												finalSubject, finalMsg,
												fromEmailID);
										if (result > 0) {
											rmdWebLogger.info(AppConstants.SUCCESS);
										} else {
											rmdWebLogger.info(AppConstants.FAILURE);
										}
									} else {
										finalMsg = prepareATSMailFormat(
												message, alerts, customerId,
												fleet,valueName,null,null, mailFooter);
										int result = postMail(toEmailId,
												finalSubject, finalMsg,
												fromEmailID);
										if (result > 0) {
											rmdWebLogger.info(AppConstants.SUCCESS);
										} else {
											rmdWebLogger.info(AppConstants.FAILURE);
										}
									}
								
								}
							}
						} else if (null != alertSubscriptionDtls.getAsset()) {
							String[] assetArr = alertSubscriptionDtls
									.getAsset().split(AppConstants.SYMBOL_COMMA);
							String valueName = AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXASSET;
							if (assetArr.length > 0) {
								for (String asset : assetArr) {
									
									if (AppConstants.EOA
											.equalsIgnoreCase(service)) {
										for(String rxTypeValue : rxType)
										{
										StringBuilder strfinalMsg = new StringBuilder();
										strfinalMsg = strfinalMsg.append(prepareAlertEoaMailFormat(
												alertSubscriptionDtls, alerts,
												message));
										if(rxTypeValue !=null && !rxTypeValue.equals(AppConstants.EMPTYSTRING)){
											strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTYPE);
											strfinalMsg = strfinalMsg.append(rxTypeValue);
										}
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXASSET);
										strfinalMsg = strfinalMsg.append(asset);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART);
										strfinalMsg = strfinalMsg.append(omdConnection);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART_URL);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE);
										strfinalMsg = strfinalMsg.append(mailFooter);
										finalMsg = strfinalMsg.toString();
										int result = postMail(toEmailId,
												finalSubject, finalMsg,
												fromEmailID);
										if (result > 0) {
											rmdWebLogger.info(AppConstants.SUCCESS);
										} else {
											rmdWebLogger.info(AppConstants.FAILURE);
										}
									}
									} else if (AppConstants.CONFIG_ALERT
											.equalsIgnoreCase(service)) {
										finalMsg = prepareConfigMailFormat(
												message, alerts, customerId,
												asset, valueName,null,null,mailFooter);
										int result = postMail(toEmailId,
												finalSubject, finalMsg,
												fromEmailID);
										if (result > 0) {
											rmdWebLogger.info(AppConstants.SUCCESS);
										} else {
											rmdWebLogger.info(AppConstants.FAILURE);
										}
									} else {
										finalMsg = prepareATSMailFormat(
												message, alerts, customerId,
												asset, valueName,null,null,mailFooter);
										int result = postMail(toEmailId,
												finalSubject, finalMsg,
												fromEmailID);
										if (result > 0) {
											rmdWebLogger.info(AppConstants.SUCCESS);
										} else {
											rmdWebLogger.info(AppConstants.FAILURE);
										}
									}	
								}
							}
						} else if (null != alertSubscriptionDtls.getShop()) {
							String[] shopArr = alertSubscriptionDtls.getShop()
									.split(AppConstants.TILDA);
							String valueName = AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXSHOP;
							if (shopArr.length > 0) {
								for (String shop : shopArr) {
									
									if (AppConstants.EOA
											.equalsIgnoreCase(service)) {
										for(String rxTypeValue : rxType)
										{
										StringBuilder strfinalMsg = new StringBuilder();
										strfinalMsg = strfinalMsg.append(prepareAlertEoaMailFormat(
												alertSubscriptionDtls, alerts,
												message));
										if(rxTypeValue !=null && !rxTypeValue.equals(AppConstants.EMPTYSTRING)){
											strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTYPE);
											strfinalMsg = strfinalMsg.append(rxTypeValue);
										}
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXSHOP);
										strfinalMsg = strfinalMsg.append(shop);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART);
										strfinalMsg = strfinalMsg.append(omdConnection);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART_URL);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE);
										strfinalMsg = strfinalMsg.append(mailFooter);
										finalMsg = strfinalMsg.toString();
										int result = postMail(toEmailId,
												finalSubject, finalMsg,
												fromEmailID);
										if (result > 0) {
											rmdWebLogger.info(AppConstants.SUCCESS);
										} else {
											rmdWebLogger.info(AppConstants.FAILURE);
										}
									}
									} else if (AppConstants.CONFIG_ALERT
											.equalsIgnoreCase(service)) {
										finalMsg = prepareConfigMailFormat(
												message, alerts, customerId,
												shop, valueName,null,null,mailFooter);
										int result = postMail(toEmailId,
												finalSubject, finalMsg,
												fromEmailID);
										if (result > 0) {
											rmdWebLogger.info(AppConstants.SUCCESS);
										} else {
											rmdWebLogger.info(AppConstants.FAILURE);
										}
									} else {
										finalMsg = prepareATSMailFormat(
												message, alerts, customerId,
												shop, valueName,null,null,mailFooter);
										int result = postMail(toEmailId,
												finalSubject, finalMsg,
												fromEmailID);
										if (result > 0) {
											rmdWebLogger.info(AppConstants.SUCCESS);
										} else {
											rmdWebLogger.info(AppConstants.FAILURE);
										}
									}
								
							}
							}
						} else if (null != alertSubscriptionDtls.getModel()) {
							String[] modelArr = alertSubscriptionDtls
									.getModel().split(AppConstants.TILDA);
							String valueName = AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXMODEL;
							if (modelArr.length > 0) {
								for (String model : modelArr) {
									
									if (AppConstants.EOA
											.equalsIgnoreCase(service)) {
										for(String rxTypeValue : rxType)
										{
										StringBuilder strfinalMsg = new StringBuilder();
										strfinalMsg = strfinalMsg.append(prepareAlertEoaMailFormat(
												alertSubscriptionDtls, alerts,
												message));
										if(rxTypeValue !=null && !rxTypeValue.equals(AppConstants.EMPTYSTRING)){
											strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTYPE);
											strfinalMsg = strfinalMsg.append(rxTypeValue);
										}
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXMODEL);
										strfinalMsg = strfinalMsg.append(model );
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART);
										strfinalMsg = strfinalMsg.append(omdConnection);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART_URL);
										strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE);
										strfinalMsg = strfinalMsg.append(mailFooter);
										finalMsg = strfinalMsg.toString();
										int result = postMail(toEmailId,
												finalSubject, finalMsg,
												fromEmailID);
										if (result > 0) {
											rmdWebLogger.info(AppConstants.SUCCESS);
										} else {
											rmdWebLogger.info(AppConstants.FAILURE);
										}
									}
									} else if (AppConstants.CONFIG_ALERT
											.equalsIgnoreCase(service)) {
										finalMsg = prepareConfigMailFormat(
												message, alerts, customerId,
												model, valueName,null,null,mailFooter);
										int result = postMail(toEmailId,
												finalSubject, finalMsg,
												fromEmailID);
										if (result > 0) {
											rmdWebLogger.info(AppConstants.SUCCESS);
										} else {
											rmdWebLogger.info(AppConstants.FAILURE);
										}
									} else {
										finalMsg = prepareATSMailFormat(
												message, alerts, customerId,
												model, valueName,null,null,mailFooter);
										int result = postMail(toEmailId,
												finalSubject, finalMsg,
												fromEmailID);
										if (result > 0) {
											rmdWebLogger.info(AppConstants.SUCCESS);
										} else {
											rmdWebLogger.info(AppConstants.FAILURE);
										}
									}
							}
							}
						} else {
							String alertValue = "";
							String valueName = "";
							if (AppConstants.EOA.equalsIgnoreCase(service)) {
								for(String rxTypeValue : rxType)
								{
								StringBuilder strfinalMsg = new StringBuilder();
								strfinalMsg = strfinalMsg.append(prepareAlertEoaMailFormat(
										alertSubscriptionDtls, alerts, message));	
								if(rxTypeValue !=null && !rxTypeValue.equals(AppConstants.EMPTYSTRING)){
									strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTYPE);
									strfinalMsg = strfinalMsg.append(rxTypeValue);
								}
								strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
								strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_CUSTOMER);
								strfinalMsg = strfinalMsg.append(alertSubscriptionDtls.getCustomer());
								strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);		
								strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART);
								strfinalMsg = strfinalMsg.append(omdConnection);
								strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART_URL);
								strfinalMsg = strfinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE);
								strfinalMsg = strfinalMsg.append(mailFooter);
								finalMsg = strfinalMsg.toString();
								int result = postMail(toEmailId,
										finalSubject, finalMsg,
										fromEmailID);
								if (result > 0) {
									rmdWebLogger.info(AppConstants.SUCCESS);
								} else {
									rmdWebLogger.info(AppConstants.FAILURE);
								}
							}
							} else if (AppConstants.CONFIG_ALERT
									.equalsIgnoreCase(service)) {
								finalMsg = prepareConfigMailFormat(message,
										alerts, customerId, alertValue,valueName,null,null,
										mailFooter);
								int result = postMail(toEmailId,
										finalSubject, finalMsg,
										fromEmailID);
								if (result > 0) {
									rmdWebLogger.info(AppConstants.SUCCESS);
								} else {
									rmdWebLogger.info(AppConstants.FAILURE);
								}
							} else {
								finalMsg = prepareATSMailFormat(message,
										alerts, customerId, alertValue,valueName,null,null,
										mailFooter);
								int result = postMail(toEmailId,
										finalSubject, finalMsg,
										fromEmailID);
								if (result > 0) {
									rmdWebLogger.info(AppConstants.SUCCESS);
								} else {
									rmdWebLogger.info(AppConstants.FAILURE);
								}
							}
						}
					}
				}
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in AlertSubController() method prepareMultiSubMailFormat",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
	}
	
	@RequestMapping(value = AppConstants.REQ_URI_RX_FILTER)
	@ResponseBody public  Map<String, String> getRXFilterLookupValue()
			throws RMDWebException {
		rmdWebLogger.debug("Inside RxServiceImpl in getRxType Method");

		Map<String, String> rxFilterMap = new HashMap<String, String>();
		String listName=AppConstants.RX_FILTER_VALUES;

		try {
			rxFilterMap= alertSubscriptionService
					.getRXFilterLookupValue(listName);
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getRXFilterLookupValue() method - AlertSubController",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return rxFilterMap;
	}
	
	@RequestMapping(value = AppConstants.REQ_URI_RX_SHOPS)
	@ResponseBody public
	Map<String, String> getShopForCustomer(
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId)
			throws  RMDWebException {
		rmdWebLogger.debug("Inside RxServiceImpl in getRxType Method");

		Map<String, String> rxShopMap = new HashMap<String, String>();

		try {
			rxShopMap = alertSubscriptionService.getShopForCustomer(EsapiUtil.stripXSSCharacters(customerId));

		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getShopForCustomer() method - AlertSubController",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return rxShopMap;
	}
	
	@RequestMapping(value = AppConstants.GET_ALERTS_FOR_SHOP)
	@ResponseBody public 
	Map<String, String> getRestrictedAlertShop(
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId)
					throws RMDWebException {
		Map<String, String> alertChkMap = null;
		try {
			
			alertChkMap = alertSubscriptionService.getRestrictedAlertShop(EsapiUtil.stripXSSCharacters(customerId));
			
			} catch (Exception ex) {
				rmdWebLogger.error("Exception occured in getAllAlertShopChk method ", ex);
				RMDWebErrorHandler.handleException(ex);

			}
		return alertChkMap;
	}
	
	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 * @Description * This method is used for fetching Urgency of repair values.
	 *              This method will be invoked through ajax call.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_SUB_SYSTEM_WITH_OBJID)
	@ResponseBody public 
	java.util.Map<String, String> getSubSystemWithObjid(final HttpServletRequest request)throws RMDWebException {

		rmdWebLogger.debug("Inside RxController in getSubSystem Method");
		Map<String, String> subSystemMap = null;
		final TreeMap<String, String> result = new TreeMap<String, String>();
		String flag = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.FLAG));
		try {
			subSystemMap = alertSubscriptionService.getSubSystemWithObjid(flag);

			result.putAll(subSystemMap);
		} catch (Exception e) {
			rmdWebLogger
					.error("Error occurred in AlertSubController - getSubSystemWithObjid Method"
							+ e);
			RMDWebErrorHandler.handleException(e);
		}
		return result;
	}
	
	@RequestMapping(value = AppConstants.REQ_URI_GET_LOCOMOTIVE_IMPACT_WITH_OBJID)
	@ResponseBody public 
	java.util.Map<String, String> getLocomotiveImpactWithObjid(final HttpServletRequest request)throws RMDWebException {

		rmdWebLogger.debug("Inside RxController in getLocomotiveImpact Method");
		Map<String, String> locoImpactMap = null;
		final 	TreeMap<String, String> result = new TreeMap<String, String>();
		String flag = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.FLAG));
		try {
			locoImpactMap = alertSubscriptionService.getLocomotiveImpactWithObjid(flag);

			result.putAll(locoImpactMap);
		} catch (Exception e) {
			rmdWebLogger
					.error("Error occurred in AlertSubController - getLocomotiveImpactWithObjid Method"
							+ e);
			RMDWebErrorHandler.handleException(e);
		}
		return result;
	}
	
	
	@RequestMapping(value = AppConstants.REQ_URI_GET_URGENCY_REPAIR_WITH_OBJID)
	@ResponseBody public 
	java.util.Map<String, String> getUrgencyOfRepairWithObjid(
			final HttpServletRequest request) throws RMDWebException {

		rmdWebLogger.info("Cache: RMDUrgencyOfRepairCache");
		Map<String, String> urgencyOfRepairMap = null;
		String flag =EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG));
		String customerId =EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CUSTOMER_ID));
		try {
			urgencyOfRepairMap = alertSubscriptionService
					.getUrgencyOfRepairWithObjid(flag, customerId);
		} catch (Exception e) {
			rmdWebLogger
					.error("Error occurred in AlertSubController - getUrgencyOfRepairWithObjid Method"
							+ e);
			RMDWebErrorHandler.handleException(e);
		}
		return urgencyOfRepairMap;
	}
	
	private String prepareEoaMailFormat(
			AlertSubscriptionDetailsVO alertSubscriptionDtls, String alerts,
			String message) throws RMDWebException {
		String finalMsg = null;
		try {
			finalMsg = message
					+ " "
					+ getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_Rx_Filter)
					+ alertSubscriptionDtls.getRxSubscribedAlerts();
			if (AppConstants.RX_URGENCY.equalsIgnoreCase(alertSubscriptionDtls
					.getRxSubscribedAlerts())) {
				finalMsg = finalMsg
						+ getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_Urgency_Type)
						+ alerts;
			} else if (AppConstants.LOCO_IMPACT
					.equalsIgnoreCase(alertSubscriptionDtls
							.getRxSubscribedAlerts())) {
				finalMsg = finalMsg
						+ getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_LOCOIMPACT_Type)
						+ alerts;
			} else if (AppConstants.SUB_SYSTEM
					.equalsIgnoreCase(alertSubscriptionDtls
							.getRxSubscribedAlerts())) {
				finalMsg = finalMsg
						+ getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_SUBSYSTEM_Type)
						+ alerts;
			} else if (AppConstants.TITLES
					.equalsIgnoreCase(alertSubscriptionDtls
							.getRxSubscribedAlerts())) {
				finalMsg = finalMsg
						+ getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_TITLE_Type)
						+ alerts;
			}
			if(null!=alertSubscriptionDtls.getCustomer() && !alertSubscriptionDtls.getCustomer().isEmpty()){
				finalMsg = finalMsg
						+ getMailTemplateLookupVal(AppConstants.ADMIN_ALERTSUB_CUSTOMER)
						+ alertSubscriptionDtls.getCustomer();
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in prepareEoaMailFormat() method - AlertSubController",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}

		return finalMsg;
	}	
	

	public String getMailTemplateLookupVal(String listName)
			throws  RMDWebException {
		rmdWebLogger.debug("Inside RxServiceImpl in getMailTemplateLookupVal Method");

		String rxFilterMap = AppConstants.EMPTY_STRING;

		try {
			rxFilterMap= alertSubscriptionService
					.getMailTemplateLookupVal(listName);
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getMailTemplateLookupVal() method - AlertSubController",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return rxFilterMap;
	}
	
	
	/**
	 * To export the alert subscriptions
	 * @param response
	 * @param request
	 * @param locale
	 * @throws Exception
	 */
	@RequestMapping(value = AppConstants.EXPORT_ALERT_SUBSCRIPTION, method = RequestMethod.POST)
	public void exportAlertSubscriptions(final HttpServletResponse response,
			final HttpServletRequest request, final Locale locale)
			throws Exception {

		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String userId = null;
		String customerId = null;
		String customerList = "";
		List<AlertSubscriptionDetailsVO> alertSubscriptionDtlsLst = new ArrayList<AlertSubscriptionDetailsVO>();
		AlertSubscriptionDetailsVO alertSubscriptionDtls = new AlertSubscriptionDetailsVO();
		boolean modelprivilege = false;
		boolean configAlertPrivilege = false;
		boolean multiSubscriptionPrivilege = false;
		boolean smsPrivilege = false;
		modelprivilege = RMDCommonUtil.componentValue(
				userVO.getComponentList(),
				AppConstants.ALERT_SUBSCRIPTION_MODEL);
		multiSubscriptionPrivilege = RMDCommonUtil.componentValue(
				userVO.getComponentList(),
				AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION);
		configAlertPrivilege = RMDCommonUtil.componentValue(
				userVO.getComponentList(),
				AppConstants.ALERT_SUBSCRIPTION_CONFIG_ALERT);
		smsPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.ALERT_SUBSCRIPTION_SMS);
		try {
			if (null != request.getParameter(AppConstants.CUSTOMER)
					&& !request.getParameter(AppConstants.CUSTOMER).trim()
							.isEmpty()) {
				customerId = request.getParameter(AppConstants.CUSTOMER);

				if (userVO.isAllCustomer()) {
					alertSubscriptionDtls
							.setCustomerId(AppConstants.EMPTY_STRING);
				} else {
					if (userVO.getCustomerList().size() > 1) {
						customerList = getCustomerList(userVO.getCustomerList());
						alertSubscriptionDtls.setCustomerList(customerList);
						alertSubscriptionDtls.setCustomerId(customerList);
					} else {
						alertSubscriptionDtls.setCustomerId(customerId);
					}
				}
			}
			userId = userVO.getUserId();
			alertSubscriptionDtls.setUserId(userId);
			//For AlerSubcription Export
			alertSubscriptionDtls.setFlag(AppConstants.ALL_SUBSCRIPTION);
			alertSubscriptionDtls.setModelPrivilege(modelprivilege);
			alertSubscriptionDtls
					.setMultiSubscriptionPrivilege(multiSubscriptionPrivilege);
			alertSubscriptionDtls.setConfigAlertPrivilege(configAlertPrivilege);
			alertSubscriptionDtls.setAllCustomer(userVO.isAllCustomer());
			alertSubscriptionDtls.setUserType(userVO.getUserType());
			alertSubscriptionDtlsLst = alertSubscriptionService
					.getAlertSubscriptionDetails(alertSubscriptionDtls);
			csvContent = convertToCSVAlerts(alertSubscriptionDtlsLst, locale,
					modelprivilege, multiSubscriptionPrivilege,
					configAlertPrivilege, smsPrivilege);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.ALERT_SUBSCRIPTION_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);

			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);

			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in exportAlertSubscriptions method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}
		}
	}
	
	/**
	 * To get the alert subscriptions in csv format
	 * @param alertSubscriptionList
	 * @param locale
	 * @return
	 */
	private String convertToCSVAlerts(
			List<AlertSubscriptionDetailsVO> alertSubscriptionList,
			Locale locale, boolean modelPrivilege,
			boolean multiSubscriptionPrivilege, boolean configAlertPrivilege, boolean smsPrivilege) {
		String csvContent = null;
		StringBuilder strBufferAlertHeader = new StringBuilder();
		try {
			if (multiSubscriptionPrivilege) {
				if ((modelPrivilege && configAlertPrivilege)
						|| (!modelPrivilege && configAlertPrivilege)) {
					if(smsPrivilege)
						strBufferAlertHeader
						.append(appContext
								.getMessage(
										AppConstants.ALERT_SUBSCRIPTION_HEADER_WITH_MULTISUB_CONFIG_ALERT_SMS,
										null, locale));
					else
						strBufferAlertHeader
								.append(appContext
										.getMessage(
												AppConstants.ALERT_SUBSCRIPTION_HEADER_WITH_MULTISUB_CONFIG_ALERT,
												null, locale));
				} else if (modelPrivilege && !configAlertPrivilege) {
					if(smsPrivilege)
						strBufferAlertHeader
						.append(appContext
								.getMessage(
										AppConstants.ALERT_SUBSCRIPTION_HEADER_WITH_MULTISUB_MODEL_SMS,
										null, locale));
					else
						strBufferAlertHeader
								.append(appContext
										.getMessage(
												AppConstants.ALERT_SUBSCRIPTION_HEADER_WITH_MULTISUB_MODEL,
												null, locale));
				} else {
					if(smsPrivilege)
						strBufferAlertHeader.append(appContext.getMessage(
								AppConstants.ALERT_SUBSCRIPTION_HEADER_MULTISUB_SMS,
								null, locale));
					else
						strBufferAlertHeader.append(appContext.getMessage(
								AppConstants.ALERT_SUBSCRIPTION_HEADER_MULTISUB,
								null, locale));
				}
			} else {
				if ((modelPrivilege && configAlertPrivilege)
						|| (!modelPrivilege && configAlertPrivilege)) {
					if(smsPrivilege)
						strBufferAlertHeader
						.append(appContext
								.getMessage(
										AppConstants.ALERT_SUBSCRIPTION_HEADER_WITH_CONFIG_ALERT_SMS,
										null, locale));
					else
						strBufferAlertHeader
								.append(appContext
										.getMessage(
												AppConstants.ALERT_SUBSCRIPTION_HEADER_WITH_CONFIG_ALERT,
												null, locale));
				} else if (modelPrivilege && !configAlertPrivilege) {
					if(smsPrivilege)
						strBufferAlertHeader.append(appContext.getMessage(
								AppConstants.ALERT_SUBSCRIPTION_HEADER_WITH_MODEL_SMS,
								null, locale));
					else
						strBufferAlertHeader.append(appContext.getMessage(
								AppConstants.ALERT_SUBSCRIPTION_HEADER_WITH_MODEL,
								null, locale));
				} else {
					if(smsPrivilege)
						strBufferAlertHeader.append(appContext.getMessage(
								AppConstants.ALERT_SUBSCRIPTION_HEADER_SMS, null,
								locale));
					else
						strBufferAlertHeader.append(appContext.getMessage(
								AppConstants.ALERT_SUBSCRIPTION_HEADER, null,
								locale));
				}
			}
			strBufferAlertHeader.append(RMDCommonConstants.NEWLINE);
			for (AlertSubscriptionDetailsVO subscriptionList : alertSubscriptionList) {

				if (multiSubscriptionPrivilege) {
					if (null != subscriptionList.getUserName()) {
						strBufferAlertHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+ subscriptionList.getUserName()
								+ AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					} else {
						strBufferAlertHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					}
				}
				if(smsPrivilege) {
					if (null != subscriptionList.getNotificationType()) {
						if(subscriptionList.getNotificationType().equals(AppConstants.ALL)){
							String notification = "Email, SMS";
							strBufferAlertHeader.append(AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ notification
									+ AppConstants.QUOTE
									+ RMDCommonConstants.COMMMA_SEPARATOR);
						}
						else{
						strBufferAlertHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+ subscriptionList.getNotificationType()
								+ AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
						}
					} else {
						strBufferAlertHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					}
				}
				if (multiSubscriptionPrivilege) {
					if (null != subscriptionList.getUserEmail()) {
						strBufferAlertHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+ subscriptionList.getUserEmail()
								+ AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					} else {
						strBufferAlertHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					}
					if(smsPrivilege) {
						if (null != subscriptionList.getPhoneNumber()) {
							strBufferAlertHeader.append(AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ subscriptionList.getPhoneNumber()
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ RMDCommonConstants.COMMMA_SEPARATOR);
						} else {
							strBufferAlertHeader.append(AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
									+ RMDCommonConstants.COMMMA_SEPARATOR);
						}
					}
				}
				if (null != subscriptionList.getService()) {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ subscriptionList.getService()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != subscriptionList.getCustomerId()) {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ subscriptionList.getCustomerId()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != subscriptionList.getAlertSubscribed()) {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE);
					if (null != subscriptionList.getService()
							&& subscriptionList.getService().equalsIgnoreCase(
									AppConstants.EOA)) {
						strBufferAlertHeader.append(subscriptionList
								.getAlertSubscribed()
								+ AppConstants.EMPTY_SPACE
								+ RMDCommonConstants.HYPHEN
								+ AppConstants.EMPTY_SPACE
								+ subscriptionList.getRxSubscribedAlerts());
					} else {
						strBufferAlertHeader.append(subscriptionList
								.getAlertSubscribed());
					}
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != subscriptionList.getValue()) {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ subscriptionList.getValue() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != subscriptionList.getRxType()) {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ subscriptionList.getRxType() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != subscriptionList.getRegion()) {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ subscriptionList.getRegion() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != subscriptionList.getSubDivision()) {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ subscriptionList.getSubDivision()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != subscriptionList.getFleet()) {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ subscriptionList.getFleet() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != subscriptionList.getAsset()) {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ subscriptionList.getAsset() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != subscriptionList.getShop()) {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ subscriptionList.getShop() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (modelPrivilege || configAlertPrivilege) {
					if (null != subscriptionList.getModel()) {
						strBufferAlertHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+ subscriptionList.getModel()
								+ AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					} else {
						strBufferAlertHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					}
				}
				if (configAlertPrivilege) {
					if (null != subscriptionList.getRuleModel()) {
						strBufferAlertHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+ subscriptionList.getRuleModel()
								+ AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					} else {
						strBufferAlertHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					}
				}
				if (null != subscriptionList.getEmailFormat()) {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ subscriptionList.getEmailFormat()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != subscriptionList.getStatus()) {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ subscriptionList.getStatus() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAlertHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (configAlertPrivilege) {
					if (null != subscriptionList.getActive()) {
						strBufferAlertHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+ subscriptionList.getActive()
								+ AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					} else {
						strBufferAlertHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					}
				}

				strBufferAlertHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBufferAlertHeader.toString();
		} catch (Exception exception) {
			rmdWebLogger.error("Export to CSV Alert Subscription"
					+ exception);
		}
		return csvContent;
	}
	
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:GenericAjaxException,RMDWebException
	 * @Description: This method is used for fetching the Model values for particular Customer.
	 */
	@RequestMapping(value = AppConstants.REQ_URI_ALERT_MODELS)
	@ResponseBody public 
	Map<String, String> getModelDetails(String customerId, String methodFlag)
			throws  RMDWebException {
		rmdWebLogger
				.debug("Inside AlertSubscriptionController in getModelDetails Method");
		Map<String, String> alertShopMap = new HashMap<String, String>();
		try {
			alertShopMap = alertSubscriptionService.getModelDetails(EsapiUtil.stripXSSCharacters(customerId),EsapiUtil.stripXSSCharacters(methodFlag));
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getModelDetails() method - AlertSubscriptionController",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return alertShopMap;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:GenericAjaxException,RMDWebException
	 * @Description: This method is used for fetching the Multi Users particular
	 *               Customer.
	 */
	@RequestMapping(value = AppConstants.REQ_URI_MULTI_USERS)
	@ResponseBody public 
	Map<String, String> getMultiUsers(final HttpServletRequest request)
			throws  RMDWebException {
		rmdWebLogger
				.debug("Inside AlertSubscriptionController in getMultiUsers Method");
		Map<String, String> alertMultiUsersMap = new HashMap<String, String>();
		String customerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CUSTOMER_ID));
		final HttpSession session = request.getSession(false);
		UserVO userVO = null;
		try {
			userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			alertMultiUsersMap = alertSubscriptionService.getMultiUsers(
					customerId, userVO.getUserType());
		} catch (Exception ex) {
			rmdWebLogger.error("RMDWebException occured in getMultiUsers", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		finally {
			userVO = null;
		}
		return alertMultiUsersMap;
	}
	
	private String prepareConfigMailFormat(String message,String alerts,String customerId,String value,String strValue,String region,String regionName,String mailFooter) throws RMDWebException
	{
		String finalMsg = null;
		try 
		{
			StringBuilder strFinalMsg = new StringBuilder();
			strFinalMsg = strFinalMsg.append(message);
			strFinalMsg = strFinalMsg.append(AppConstants.ATTR_COLON );
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE);
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RULETITLE);
			strFinalMsg = strFinalMsg.append(alerts);
			if (value != null && !value.isEmpty()) 
			{
				strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
				strFinalMsg = strFinalMsg.append(strValue);
				strFinalMsg = strFinalMsg.append(value);
				if (region != null && !region.isEmpty()) 
				{
					strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
					strFinalMsg = strFinalMsg.append(regionName);
					strFinalMsg = strFinalMsg.append(region);
				}
			}
			else
			{
				strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
				strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_CUSTOMER);
				strFinalMsg = strFinalMsg.append(customerId);
			}
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART);
			strFinalMsg = strFinalMsg.append(omdConnection);
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART_URL);
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE);
			strFinalMsg = strFinalMsg.append(mailFooter);	
			finalMsg = strFinalMsg.toString();
		} 
		catch (Exception rmdEx) 
		{
			rmdWebLogger.error("RMDWebException occured in prepareConfigMailFormat() method - AlertSubController",	rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}

		return finalMsg;
	}
	
	private String prepareATSMailFormat(String message,String alerts,String customerId,String value,String strValue,String region,String regionName,String mailFooter) throws RMDWebException
	{
		String finalMsg = null;
		try 
		{
			StringBuilder strFinalMsg = new StringBuilder();
			strFinalMsg = strFinalMsg.append(message);
			strFinalMsg = strFinalMsg.append(AppConstants.ATTR_COLON );
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE);
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_ALERTTYPE);
			strFinalMsg = strFinalMsg.append(alerts);
			if (value != null && !value.isEmpty()) 
			{
				strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
				strFinalMsg = strFinalMsg.append(strValue);
				strFinalMsg = strFinalMsg.append(value);
				if (region != null && !region.isEmpty()) 
				{
					strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
					strFinalMsg = strFinalMsg.append(regionName);
					strFinalMsg = strFinalMsg.append(region);
				}
			}
			else
			{
				strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
				strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_CUSTOMER);
				strFinalMsg = strFinalMsg.append(customerId);
			}
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART);
			strFinalMsg = strFinalMsg.append(omdConnection);
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_MSGPART_URL);
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE);
			strFinalMsg = strFinalMsg.append(mailFooter);	
			finalMsg = strFinalMsg.toString();
		} 
		catch (Exception rmdEx) 
		{
			rmdWebLogger.error("RMDWebException occured in prepareATSMailFormat() method - AlertSubController",	rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}

		return finalMsg;
	}
	private String prepareAlertEoaMailFormat(
			AlertSubscriptionDetailsVO alertSubscriptionDtls, String alerts,
			String message) throws RMDWebException {
		String finalMsg = null;
		try 
		{
			StringBuilder strFinalMsg = new StringBuilder();
			strFinalMsg = strFinalMsg.append(message);
			strFinalMsg = strFinalMsg.append(AppConstants.ATTR_COLON );
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_Next_LINE);
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXFILTER);
			strFinalMsg = strFinalMsg.append(alertSubscriptionDtls.getRxSubscribedAlerts());
			if (AppConstants.RX_URGENCY.equalsIgnoreCase(alertSubscriptionDtls.getRxSubscribedAlerts()))
			{
				strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
				strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXURGENCY_TYPE);
				strFinalMsg = strFinalMsg.append(alerts);
			} else if (AppConstants.LOCO_IMPACT
					.equalsIgnoreCase(alertSubscriptionDtls
							.getRxSubscribedAlerts())) {
				strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
				strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXLOCO_TYPE);
				strFinalMsg = strFinalMsg.append( alerts);
			} else if (AppConstants.SUB_SYSTEM
					.equalsIgnoreCase(alertSubscriptionDtls
							.getRxSubscribedAlerts())) {
				strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
				strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXSUBSYSTEM_TYPE);
				strFinalMsg = strFinalMsg.append( alerts);
			} else if (AppConstants.TITLES
					.equalsIgnoreCase(alertSubscriptionDtls
							.getRxSubscribedAlerts())) {
				strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
				strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_RXTITLE_TYPE);
				strFinalMsg = strFinalMsg.append( alerts);
			}
			strFinalMsg = strFinalMsg.append(AppConstants.ALERT_SUBSCRIPTION_MULTI_SUCSCRIPTION_MAIL_SINGALE_Next_LINE);
			finalMsg = strFinalMsg.toString();
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in prepareAlertEoaMailFormat() method - AlertSubController",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}

		return finalMsg;
	}	
	
	/**
	 * @param userId
	 * @return String
	 * @Description: method to get user email of the user
	 */
	@ResponseBody public 
	String getUserEmailId(String userId) throws RMDWebException {
		String userEmailId = AppConstants.EMPTY_STRING;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(userId)) {
				userEmailId = alertSubscriptionService.getUserEmailId(EsapiUtil
						.stripXSSCharacters(userId));
			}
			
			if (userEmailId.equalsIgnoreCase(AppConstants.NULL_STRING)) {
				userEmailId = AppConstants.EMPTY_STRING;
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getUserEmailId method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return userEmailId;
	}
	
	/**
	 * @param userId
	 * @return String
	 * @Description: method to get user phone no. of the user
	 */
	@ResponseBody public 
	String getUserPhoneNo(String userId) throws RMDWebException {
		String userPhoneNo = AppConstants.EMPTY_STRING;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(userId)) {
				userPhoneNo = alertSubscriptionService.getUserPhoneNo(EsapiUtil
						.stripXSSCharacters(userId));
			}
			
			if (userPhoneNo.equalsIgnoreCase(AppConstants.NULL_STRING)) {
				userPhoneNo = AppConstants.EMPTY_STRING;
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getUserEmailId method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return userPhoneNo;
	}
	
	/**
	 * @param userId
	 * @return String
	 * @Description: method to get user phone no. country code of the user
	 */
	@ResponseBody public 
	String getUserPhoneCountryCode(String userId) throws RMDWebException {
		String userPhoneCountryCode = AppConstants.EMPTY_STRING;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(userId)) {
				userPhoneCountryCode = alertSubscriptionService.getUserPhoneCountryCode(EsapiUtil
						.stripXSSCharacters(userId));
			}
			
			if (userPhoneCountryCode.equalsIgnoreCase(AppConstants.NULL_STRING)) {
				userPhoneCountryCode = AppConstants.EMPTY_STRING;
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getUserEmailId method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return userPhoneCountryCode;
	}
	
	public int postMail(String toEmailId,String finalSubject,String finalMsg,String fromEmailID){
		int count = 0;
		while (count <= 0) {
			try {
				count = alertSubscriptionService
						.postMail(toEmailId,
								finalSubject, finalMsg,
								fromEmailID);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		return count;
	}
	@RequestMapping(value = AppConstants.REQ_URI_RX_TYPE)
	@ResponseBody public  List<AlertRxTypeDetails> getRXTypeLookupValue()
			throws RMDWebException {
		rmdWebLogger.debug("Inside RxServiceImpl in getRxType Method");

		List<AlertRxTypeDetails> rxTypeMap = new ArrayList<AlertRxTypeDetails>();
		String listName=AppConstants.ALERT_RX_TYPE_HOVER_TEXT;

		try {
			rxTypeMap= alertSubscriptionService
					.getRXTypeLookupValue(listName);
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getRXFilterLookupValue() method - AlertSubController",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return rxTypeMap;
	}
	
}
