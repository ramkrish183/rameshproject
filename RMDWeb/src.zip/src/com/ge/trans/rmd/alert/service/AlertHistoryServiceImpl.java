package com.ge.trans.rmd.alert.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.services.alert.valueobjects.AlertHistoryRequestType;
import com.ge.trans.rmd.services.alert.valueobjects.AlertHistoryResponseType;
import com.ge.trans.rmd.services.alert.valueobjects.AlertAssetRequestType;
import com.ge.trans.rmd.services.alert.valueobjects.AlertAssetResponseType;
import com.ge.trans.rmd.services.alert.valueobjects.AlertHstDetailsResponseType;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.alert.valueobjects.AlertHistoryDetailsVO;
import com.ge.trans.rmd.alert.valueobjects.AlertHstDetailsVO;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class AlertHistoryServiceImpl extends RMDBaseServiceImpl implements AlertHistoryService
{
	private final RMDWebLogger rmdWebLogger = RMDWebLogger.getLogger(getClass());
	@Autowired
	private CachedService cachedService;
	@Autowired
	WebServiceInvoker webServiceInvoker;
	
	@Override
	public Map<String, String> getAlertHistoryLookUp(String listName)throws RMDWebException 
	{
		Map<String, String> allAlertHistoryLookUp = new TreeMap<String, String>();	
		try
		{
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService
					.getAllLookupValues().get(listName);
			if (applParamResponseTypeList != null
					&& !applParamResponseTypeList.isEmpty()) {
				for (ApplicationParametersResponseType objResponse : applParamResponseTypeList) {
					allAlertHistoryLookUp.put(objResponse.getLookupValue(), objResponse.getLookupValue());
				}
			}
		}
		catch (Exception ex) 
		{
			rmdWebLogger.error("Exception occured in getAlertHistoryLookUp method ",ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allAlertHistoryLookUp;
	
	}

	@Override
	public String getAltHstLookUp(String listName) throws RMDWebException 
	{
		String strAltHstLookUp = null;
		try 
		{
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService
					.getAllLookupValues().get(listName);
			if (applParamResponseTypeList != null) {
				strAltHstLookUp = applParamResponseTypeList.get(0).getLookupValue();
			}
		} 
		catch (Exception ex) 
		{
			rmdWebLogger.error("Exception occured in getAltHstLookUp method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return strAltHstLookUp;	
	}

	@Override
	public AlertHstDetailsVO getAlertHistoryDetails(AlertHistoryDetailsVO objAlertHistoryDetailsVO)	throws RMDWebException 
	{		
		AlertHistoryRequestType objAlertHistoryRequestType=new AlertHistoryRequestType();
		List<AlertHistoryDetailsVO> objAlertHistoryDetailsVOlst = new ArrayList<AlertHistoryDetailsVO>();
		AlertHstDetailsVO objAlertHstDetailsVO=new AlertHstDetailsVO();
		AlertHistoryDetailsVO objAltHstDetailsVO;
		String strType=AppConstants.EMPTY_STRING;
		String strLat = AppConstants.EMPTY_STRING;
		String strLog = AppConstants.EMPTY_STRING;
		String defaultTimezone =null;
		String applicationTimezone = null;
		final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		final TimeZone timeZone = TimeZone.getTimeZone(objAlertHistoryDetailsVO.getUserTimeZone());
		defaultTimezone=EsapiUtil.stripXSSCharacters(AppConstants.DEFAULT_TIME_ZONE);
		applicationTimezone=RMDCommonUtil.getTimezone(defaultTimezone,EsapiUtil.stripXSSCharacters(objAlertHistoryDetailsVO.getUserTimeZone()));
		String convertedFormDate = null;
		String convertedToDate = null;
		TimeZone firstTime = null;
		Date fromDate = null;
		Date toDate = null;
		DateFormat zoneDateFormater = null;
		try
		{
			if(objAlertHistoryDetailsVO.getStrFromDate()!=null && !objAlertHistoryDetailsVO.getStrFromDate().equals(AppConstants.EMPTY_STRING)
					&& objAlertHistoryDetailsVO.getStrToDate()!=null && !objAlertHistoryDetailsVO.getStrToDate().equals(AppConstants.EMPTY_STRING)){
			firstTime = TimeZone.getTimeZone(applicationTimezone); 
			zoneDateFormater = new SimpleDateFormat(AppConstants.TO_DATE_FORMAT, Locale.ENGLISH);
			zoneDateFormater.setTimeZone(TimeZone.getTimeZone("US/Eastern"));
			DateFormat estZoneFormater = new SimpleDateFormat(AppConstants.TO_DATE_FORMAT);
			estZoneFormater.setTimeZone(firstTime); 
			fromDate = estZoneFormater.parse(objAlertHistoryDetailsVO.getStrFromDate());
			toDate = estZoneFormater.parse(objAlertHistoryDetailsVO.getStrToDate());
			convertedFormDate = zoneDateFormater.format(fromDate);
			convertedToDate = zoneDateFormater.format(toDate);
			}
			objAlertHistoryRequestType.setStrAlert(objAlertHistoryDetailsVO.getStrAlert());
			objAlertHistoryRequestType.setStrAsset(objAlertHistoryDetailsVO.getStrAsset());
			objAlertHistoryRequestType.setStrCustomer(objAlertHistoryDetailsVO.getStrCustomer());		
			objAlertHistoryRequestType.setStrFleet(objAlertHistoryDetailsVO.getStrFleet());
			objAlertHistoryRequestType.setStrFromDate(convertedFormDate);
			objAlertHistoryRequestType.setStrModel(objAlertHistoryDetailsVO.getStrModel());		
			objAlertHistoryRequestType.setStrMultiUsers(objAlertHistoryDetailsVO.getStrMultiUsers());
			objAlertHistoryRequestType.setStrNumberOfDays(objAlertHistoryDetailsVO.getStrNumberOfDays());
			objAlertHistoryRequestType.setStrToDate(convertedToDate);		
			objAlertHistoryRequestType.setStrType(objAlertHistoryDetailsVO.getStrType());
			objAlertHistoryRequestType.setStrRegion(objAlertHistoryDetailsVO.getStrRegion());		
			objAlertHistoryRequestType.setStrRule(objAlertHistoryDetailsVO.getStrRule());
			objAlertHistoryRequestType.setStrRxFilter(objAlertHistoryDetailsVO.getStrRxFilter());
			objAlertHistoryRequestType.setStrSearchValue(objAlertHistoryDetailsVO.getStrSearchValue());		
			objAlertHistoryRequestType.setStrShop(objAlertHistoryDetailsVO.getStrShop());
			objAlertHistoryRequestType.setStrSubDivision(objAlertHistoryDetailsVO.getStrSubDivision());	
			objAlertHistoryRequestType.setMultiSubscriptionPrivilege(objAlertHistoryDetailsVO.isMultiSubscriptionPrivilege());	
			objAlertHistoryRequestType.setUserType(objAlertHistoryDetailsVO.getUserType());	
			objAlertHistoryRequestType.setUserId(objAlertHistoryDetailsVO.getUserId());	
			objAlertHistoryRequestType.setPageNo(objAlertHistoryDetailsVO.getPageNo());			
			objAlertHistoryRequestType.setStrMethodFlag(objAlertHistoryDetailsVO.getStrMethodFlag());	
			if (objAlertHistoryDetailsVO.getStartRow() == null) 
			{
				objAlertHistoryRequestType.setStartRow(AppConstants.DEFAULT_START_ROW);       
			} 
			else 
			{
				objAlertHistoryRequestType.setRecordsPerPage(objAlertHistoryDetailsVO.getRecordsPerPage());	
			}
			if (objAlertHistoryDetailsVO.getStartRow() == null) 
			{
				objAlertHistoryRequestType.setRecordsPerPage(AppConstants.DEFAULT_END_ROW);          
			} 
			else 
			{
				objAlertHistoryRequestType.setStartRow(objAlertHistoryDetailsVO.getStartRow());	
			}
			AlertHstDetailsResponseType objAlertHstDetailsResponseType;
			objAlertHstDetailsResponseType = (AlertHstDetailsResponseType) webServiceInvoker.post(ServiceConstants.ALERTHISTORYDETAILS,objAlertHistoryRequestType,AlertHstDetailsResponseType.class);
			if (!RMDCommonUtility.checkNull(objAlertHistoryRequestType)) 
	        {
				for(AlertHistoryResponseType objAlertHistoryResponseType : objAlertHstDetailsResponseType.getAlertHdrResponseTypelst())
	        	{
					objAltHstDetailsVO = new AlertHistoryDetailsVO();
					objAltHstDetailsVO.setStrMultiUsers(objAlertHistoryResponseType.getStrMultiUsers());	
					strType = objAlertHistoryResponseType.getStrType();
					objAltHstDetailsVO.setStrType(strType);												
					if (null == objAlertHistoryResponseType.getStrGPSLat() && null == objAlertHistoryResponseType.getStrGPSLog())
					{
						objAltHstDetailsVO.setStrGPSLatLog(AppConstants.NOT_APLICABLE);
					}
					else
					{
						objAltHstDetailsVO.setStrGPSLatLog(objAlertHistoryResponseType.getStrGPSLat()+AppConstants.LEVEL_SEPERATOR+objAlertHistoryResponseType.getStrGPSLog());
					}					
					objAltHstDetailsVO.setStrAlertTitle(objAlertHistoryResponseType.getStrAlertTitle());																					
					objAltHstDetailsVO.setStrPdfUrl(objAlertHistoryResponseType.getStrPdfUrl());	
					objAltHstDetailsVO.setEmailText(objAlertHistoryResponseType.getEmailText());
					objAltHstDetailsVO.setEmailText(objAlertHistoryResponseType.getEmailText());
					objAltHstDetailsVO.setFiringId(objAlertHistoryResponseType.getFiringId());
					objAltHstDetailsVO.setFiredOn(objAlertHistoryResponseType.getFiredOn());
					if (!RMDCommonUtility.isNullOrEmpty(objAlertHistoryResponseType.getStrAsset()))
					{
						objAltHstDetailsVO.setStrAsset(objAlertHistoryResponseType.getStrAsset());
					}
					else
					{
						objAltHstDetailsVO.setStrAsset(AppConstants.NOT_APLICABLE);
					}
					if (!RMDCommonUtility.isNullOrEmpty(objAlertHistoryResponseType.getStrRegion()))
					{
						objAltHstDetailsVO.setStrRegion(objAlertHistoryResponseType.getStrRegion());	
					}
					else
					{
						objAltHstDetailsVO.setStrRegion(AppConstants.NOT_APLICABLE);
					}
					if (!RMDCommonUtility.isNullOrEmpty(objAlertHistoryResponseType.getStrSubDivision()))
					{
						objAltHstDetailsVO.setStrSubDivision(objAlertHistoryResponseType.getStrSubDivision());	
					}
					else
					{
						objAltHstDetailsVO.setStrSubDivision(AppConstants.NOT_APLICABLE);
					}
					if (!RMDCommonUtility.isNullOrEmpty(objAlertHistoryResponseType.getStrFleet()))
					{
						objAltHstDetailsVO.setStrFleet(objAlertHistoryResponseType.getStrFleet());	
					}
					else
					{
						objAltHstDetailsVO.setStrFleet(AppConstants.NOT_APLICABLE);
					}
					if (!RMDCommonUtility.isNullOrEmpty(objAlertHistoryResponseType.getStrModel()))
					{
						objAltHstDetailsVO.setStrModel(objAlertHistoryResponseType.getStrModel());	
					}
					else
					{
						objAltHstDetailsVO.setStrModel(AppConstants.NOT_APLICABLE);
					}
					if (!RMDCommonUtility.isNullOrEmpty(objAlertHistoryResponseType.getStrShop()))
					{
						objAltHstDetailsVO.setStrShop(objAlertHistoryResponseType.getStrShop());	
					}
					else
					{
						objAltHstDetailsVO.setStrShop(AppConstants.NOT_APLICABLE);
					}
					if (!RMDCommonUtility.isNullOrEmpty(objAlertHistoryResponseType.getStrRuleLogic()))
					{
						objAltHstDetailsVO.setStrRuleLogic(AppConstants.ALERT_HST_VIEW);
						objAltHstDetailsVO.setStrRuleLogicVal(objAlertHistoryResponseType.getStrRuleLogic());
					}
					else
					{
						objAltHstDetailsVO.setStrRuleLogic(AppConstants.NOT_APLICABLE);
					}
					final XMLGregorianCalendar strAlertDate = objAlertHistoryResponseType.getStrAlertDate();
					zoneFormater.setTimeZone(timeZone);
					if (null != objAlertHistoryResponseType.getStrAlertDate()) 
					{
						objAltHstDetailsVO.setStrAlertDate(zoneFormater.format(strAlertDate.toGregorianCalendar().getTime()));
					}
					if(strType!= null && strType.equalsIgnoreCase(AppConstants.EOA) && objAlertHistoryResponseType.getStrPdfUrl() != null)
					{				
						objAltHstDetailsVO.setStrDtTrigPoint(AppConstants.ALERT_HST_DOWNLOAD_PDF);
					}
					else
					{
						objAltHstDetailsVO.setStrDtTrigPoint(AppConstants.NOT_APLICABLE);
					}
					if(strType.equalsIgnoreCase(AppConstants.ALERT_HST_CONFIG))
					{
						objAltHstDetailsVO.setStrDtTrigPoint(AppConstants.ALERT_HST_VIEW);
					}
					if(strType.equalsIgnoreCase(AppConstants.ATS))
					{
						objAltHstDetailsVO.setStrDtTrigPoint(AppConstants.ALERT_HST_VIEW_EMAIL_TEXT);
					}	
					if (!RMDCommonUtility.isNullOrEmpty(objAlertHistoryResponseType.getNotification()))
					{
						objAltHstDetailsVO.setNotification(objAlertHistoryResponseType.getNotification());	
					}
					else
					{
						objAltHstDetailsVO.setNotification(AppConstants.NOT_APLICABLE);
					}
					if (!RMDCommonUtility.isNullOrEmpty(objAlertHistoryResponseType.getMobileNo()))
					{
						objAltHstDetailsVO.setMobileNo(objAlertHistoryResponseType.getMobileNo());	
					}
					else
					{
						objAltHstDetailsVO.setMobileNo(AppConstants.NOT_APLICABLE);
					}
					if (!RMDCommonUtility.isNullOrEmpty(objAlertHistoryResponseType.getIsEmailFlag()))
					{
						objAltHstDetailsVO.setIsEmailFlag(objAlertHistoryResponseType.getIsEmailFlag());	
					}
					else
					{
						objAltHstDetailsVO.setIsEmailFlag(AppConstants.NOT_APLICABLE);
					}
					if (!RMDCommonUtility.isNullOrEmpty(objAlertHistoryResponseType.getIsSmsFlag()))
					{
						objAltHstDetailsVO.setIsSmsFlag(objAlertHistoryResponseType.getIsSmsFlag());	
					}
					else
					{
						objAltHstDetailsVO.setIsSmsFlag(AppConstants.NOT_APLICABLE);
					}
					if (!RMDCommonUtility.isNullOrEmpty(objAlertHistoryResponseType.getSmsText()))
					{
						objAltHstDetailsVO.setSmsText(objAlertHistoryResponseType.getSmsText());	
					}
					else
					{
						objAltHstDetailsVO.setSmsText(AppConstants.NOT_APLICABLE);
					}
					objAlertHistoryDetailsVOlst.add(objAltHstDetailsVO);
				}
	        }
			objAlertHstDetailsVO.setAlertHistoryHdrlst(objAlertHistoryDetailsVOlst);
			objAlertHstDetailsVO.setRecordsTotal(objAlertHstDetailsResponseType.getCount());
		} 
		catch (Exception ex) 
		{
			rmdWebLogger.error("Exception occured in getAlertHistoryDetails method ",ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return objAlertHstDetailsVO;
	}

	@Override
	public Map<String, String> getAltHstAssets(String customerId, String strFleet, String strModel) throws RMDWebException 
	{
		final Map<String, String> assetList = new HashMap<String, String>();
		AlertAssetRequestType assetRequestType = new AlertAssetRequestType();
		assetRequestType.setCustomerId(customerId);
		assetRequestType.setStrFleet(strFleet);			
		assetRequestType.setStrModel(strModel);
		AlertAssetResponseType[] assetResponseType;
		try 
		{			
			assetResponseType = (AlertAssetResponseType[]) webServiceInvoker.post(ServiceConstants.GET_ALERT_HST_POPULATE_DATA, assetRequestType, AlertAssetResponseType[].class);
			if (!RMDCommonUtility.checkNull(assetResponseType)) 
			{
				for (int i = 0; i < assetResponseType.length; i++) 
				{
					assetList.put(assetResponseType[i].getAssetNumber(),assetResponseType[i].getAssetNumber());
				}
			}

		} 
		catch (Exception ex)
		{
			rmdWebLogger.error("Exception occured in getAltHstAssets method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return assetList;	
	}

	/**
	 * @return Map<String, Map<String, String>>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Site Shipping,Site Status & SiteEdit Types
	 *              dropdown.
	 */
	@Override
	public Map<String, Map<String, String>> getAlertHisotryPopulateData(String customerId)	throws RMDWebException 
	{
		Map<String, Map<String, String>> allAlertHisotryPopulateData = new LinkedHashMap<String, Map<String, String>>();
		Map<String, String> getModelLst =  new TreeMap<String, String>();
		Map<String, String> getFleetLst = new TreeMap<String, String>();
		Map<String, String> getAssetLst = new TreeMap<String, String>();
		AlertAssetRequestType assetRequestType = new AlertAssetRequestType();
		assetRequestType.setCustomerId(customerId);
		AlertAssetResponseType[] assetResponseType;
		try 
		{			
			assetResponseType = (AlertAssetResponseType[]) webServiceInvoker.post(ServiceConstants.GET_ALERT_HST_POPULATE_DATA, assetRequestType, AlertAssetResponseType[].class);
			if (!RMDCommonUtility.checkNull(assetResponseType))
			{
				for (int i = 0; i < assetResponseType.length; i++) 
				{
					getModelLst.put(assetResponseType[i].getModel(),assetResponseType[i].getModel());
					getFleetLst.put(assetResponseType[i].getFleet(),assetResponseType[i].getFleet());
					getAssetLst.put(assetResponseType[i].getAssetNumber(),assetResponseType[i].getAssetNumber());
				}
			}
			allAlertHisotryPopulateData.put(AppConstants.ALERT_HST_MODEL, getModelLst);
			allAlertHisotryPopulateData.put(AppConstants.ALERT_HST_FLEET, getFleetLst);
			allAlertHisotryPopulateData.put(AppConstants.ALERT_HST_ASSET, getAssetLst);
		} 
		catch (Exception ex)
		{
			rmdWebLogger.error("Exception occured in getAlertHisotryPopulateData method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allAlertHisotryPopulateData;
	}

	@Override
	public List<String> getSubMenuList(String userId) throws RMDWebException 
	{
		List<String> subMenuList = null;
		Map<String, String> queryParamMap = null;
		String subMenuString = RMDCommonConstants.EMPTY_STRING;
		try 
		{
			queryParamMap = new LinkedHashMap<String, String>();
			queryParamMap.put(AppConstants.USER_ID, userId);
			subMenuString = (String) webServiceInvoker.get(ServiceConstants.GET_SUBMENU_LIST, null, queryParamMap,null, String.class);
			if (!RMDCommonUtility.isNullOrEmpty(subMenuString))
			{
				subMenuList = Arrays.asList(subMenuString.split(RMDCommonConstants.COMMMA_SEPARATOR));
			}
		} 
		catch (Exception exp)
		{
			rmdWebLogger.error("Exception occured in getSubMenuList method ", exp);
			RMDWebErrorHandler.handleException(exp);
		}
		return subMenuList;
	}
	
}
