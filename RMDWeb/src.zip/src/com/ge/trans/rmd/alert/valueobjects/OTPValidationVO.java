package com.ge.trans.rmd.alert.valueobjects;

import java.io.Serializable;
import java.util.Date;

public class OTPValidationVO implements Serializable{

	private String userId;
	private String otp;
	private Date created_date;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getOtp() {
		return otp;
	}
	public void setOtp(String otp) {
		this.otp = otp;
	}
	public Date getCreated_date() {
		return created_date;
	}
	public void setCreated_date(Date created_date) {
		this.created_date = created_date;
	}
}
