package com.ge.trans.rmd.alert.valueobjects;

import java.io.Serializable;
import java.util.List;

/**
 * @author rr807273
 *
 */
public class AlertActivateDeleteVO implements Serializable{

	
	private String flag;	
	private String userId;
	private List<AlertSubscriptionDetailsVO> alertRowList;
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<AlertSubscriptionDetailsVO> getAlertRowList() {
		return alertRowList;
	}
	public void setAlertRowList(List<AlertSubscriptionDetailsVO> alertRowList) {
		this.alertRowList = alertRowList;
	}
	
}	
