package com.ge.trans.rmd.alert.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.alert.service.AlertHistoryService;
import com.ge.trans.rmd.alert.service.AlertSubscriptionService;
import com.ge.trans.rmd.alert.valueobjects.AlertHistoryDetailsVO;
import com.ge.trans.rmd.alert.valueobjects.AlertHstDetailsVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class AlertHistoryController extends RMDBaseController
{
	 private final RMDWebLogger rmdWebLogger = RMDWebLogger.getLogger(getClass());
	@Autowired
	private AlertHistoryService alertHistoryService;
	@Autowired
	private AlertSubscriptionService alertSubscriptionService;
	@Autowired
	private ApplicationContext appContext;
	
	@RequestMapping(value = AppConstants.REQ_URI_GET_ALERT_HISTORY_PAGE,method =RequestMethod.GET)
	public String viewAlertHistory(final HttpServletRequest request)  throws Exception
	{
		List<String> atsCustomers = new ArrayList<String>();
		List<String> eoaCustomers = new ArrayList<String>();
		List<String> configAlertCustomers = new ArrayList<String>();
		List<String> subMenuList = new ArrayList<String>();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		boolean multiSubscriptionPrivilege = false;
		boolean configAlertPrivilege = false;
		boolean iAuthorPrivilege = false;
		boolean hitsPrivilege = false;
		boolean smsPrivilege = false;
		try
		{			
			atsCustomers = alertSubscriptionService.getATSEnabledCustomers();
			String comaSepratedStr = RMDCommonUtility.getCommaSeperatedString(atsCustomers);
			request.setAttribute(AppConstants.ATS_CUSTOEMRS, comaSepratedStr);
			eoaCustomers = alertSubscriptionService.getEOACustomerList();
			comaSepratedStr = RMDCommonUtility.getCommaSeperatedString(eoaCustomers);
			request.setAttribute(AppConstants.EOA_CUSTOMERS, comaSepratedStr);
			configAlertCustomers = alertSubscriptionService.getConfigAlertCustomerList();
			comaSepratedStr = RMDCommonUtility.getCommaSeperatedString(configAlertCustomers);
			request.setAttribute(AppConstants.CONFIG_ALERT_CUSTOMERS, comaSepratedStr);
			subMenuList = alertHistoryService.getSubMenuList(userVO.getUserId());
			iAuthorPrivilege=componentValue(subMenuList ,AppConstants.ALERT_HISTORY_IAUTHOR);
			hitsPrivilege=componentValue(subMenuList ,AppConstants.ALERT_HISTORY_HITS);
			Calendar cal = Calendar.getInstance();
			final SimpleDateFormat fromDateFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
			String previousDate = null;
			String previousDateRange = null;
			String currentDate = null;
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			currentDate = fromDateFormat.format(cal.getTime());
			previousDateRange=alertHistoryService.getAltHstLookUp(AppConstants.ALERT_HISTORY_LOOKBACK_DAYS);
			previousDateRange = AppConstants.SYMBOL_MINUS + previousDateRange;
			cal.add(Calendar.DATE, Integer.parseInt(previousDateRange));
			cal.set(Calendar.HOUR_OF_DAY, 0);
			cal.set(Calendar.MINUTE, 0);
			cal.set(Calendar.SECOND, 0);
			previousDate = fromDateFormat.format(cal.getTime());
								
			request.setAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE, userVO.getIsCMPrivilege());
			request.setAttribute(AppConstants.PP_FROM_PREVOIUSDATE, previousDate);
			request.setAttribute(AppConstants.PP_CURRENT_DATE, currentDate);
			request.setAttribute(AppConstants.ATTR_USER_OBJECT, userVO);
			multiSubscriptionPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.ALERT_HISTORY_MULTI_SUCSCRIPTION);
			request.setAttribute(AppConstants.ALERT_HISTORY_MULTI_SUCSCRIPTION_COMPONENT,multiSubscriptionPrivilege);
			configAlertPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.ALERT_HISTORY_CONFIG_ALERT);
			request.setAttribute(AppConstants.ALERT_HISTORY_CONFIG_ALERT_COMPONENT,configAlertPrivilege);
			request.setAttribute(AppConstants.ALERT_HISTORY_HITS_COMPONENT,hitsPrivilege);
			request.setAttribute(AppConstants.ALERT_HISTORY_IAUTHOR_COMPONENT,iAuthorPrivilege);
			request.setAttribute(AppConstants.ALERT_HISTORY_DEFAULT_NOOFDAYS,alertHistoryService.getAltHstLookUp(AppConstants.ALERT_HISTORY_DEFAULT_NO_OF_DAYS));
			request.setAttribute(AppConstants.USER_MAIL_ID, userVO.getStrEmail());
			smsPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.ALERT_SUBSCRIPTION_SMS);
			if(smsPrivilege)
			{
			request.setAttribute(AppConstants.ALERT_SUBSCRIPTION_SMS_COMPONENT, true);
			}
			else
			{
				request.setAttribute(AppConstants.ALERT_SUBSCRIPTION_SMS_COMPONENT, false);
			}
		} 
		catch (Exception ex) 
		{
			rmdWebLogger.error("Exception occured in viewAlertHistory method ", ex);
			RMDWebErrorHandler.handleException(ex);			
			request.setAttribute(AppConstants.ERRORMSG,AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		}
		finally 
		{
			atsCustomers= null;
			eoaCustomers= null;
			configAlertCustomers= null;
		}
		return AppConstants.ALERT_HISTORY_VIEW;
	}
	
	/**
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Site Type dropdown.
	 */
	@RequestMapping(value = AppConstants.GET_ALERT_HISTORY_NO_OF_DAYS)
	@ResponseBody public 
	Map<String, String> getAlertHistoryNoofDays() throws RMDWebException 
	{
		Map<String, String> allAalertHistoryNoofDays = new TreeMap<String, String>();
		try 
		{
			allAalertHistoryNoofDays = alertHistoryService.getAlertHistoryLookUp(AppConstants.ALERTHISTORY_NO_OF_DAYS);
		} 
		catch (Exception ex) 
		{
			rmdWebLogger.error("Exception occured in getAlertHistoryNoofDays method ",ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allAalertHistoryNoofDays;
	}	
	
	/**
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Site Type dropdown.
	 */
	@RequestMapping(value = AppConstants.GET_ALERT_HISTORY_SERVICE_TYPES)
	@ResponseBody public 
	Map<String, String> getServiceTypes() throws RMDWebException 
	{
		Map<String, String> allServiceTypes = new TreeMap<String, String>();
		try
		{
			allServiceTypes = alertHistoryService.getAlertHistoryLookUp(AppConstants.SERVICE_TYPES);
		}
		catch (Exception ex) 
		{
			rmdWebLogger.error("Exception occured in getServiceTypes method ",ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allServiceTypes;
	}	
		
	@RequestMapping(value = AppConstants.REQ_URI_GET_ALERTHISTORYDETAILS, method = RequestMethod.POST)
	@ResponseBody
	 public AlertHstDetailsVO getAlertHistoryDetails(final HttpServletRequest request) throws RMDWebException
	 {
		AlertHistoryDetailsVO objAlertHistoryDetailsVO = new AlertHistoryDetailsVO();
		AlertHstDetailsVO objAlertHstDetailsVO = new AlertHstDetailsVO();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		boolean multiSubscriptionPrivilege;
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_CUSTOMER)))
		{
			objAlertHistoryDetailsVO.setStrCustomer(request.getParameter(AppConstants.ALERT_HISTORY_CUSTOMER));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_TYPE)))
		{
			objAlertHistoryDetailsVO.setStrType(request.getParameter(AppConstants.ALERT_HISTORY_TYPE));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_ALERT)))
		{
			objAlertHistoryDetailsVO.setStrAlert(request.getParameter(AppConstants.ALERT_HISTORY_ALERT));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_RXFILTER)))
		{
			objAlertHistoryDetailsVO.setStrRxFilter(request.getParameter(AppConstants.ALERT_HISTORY_RXFILTER));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_RULE)))
		{
			objAlertHistoryDetailsVO.setStrRule(request.getParameter(AppConstants.ALERT_HISTORY_RULE));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_REGION)))
		{
			objAlertHistoryDetailsVO.setStrRegion(request.getParameter(AppConstants.ALERT_HISTORY_REGION));
		}		
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_SUBDIVISION)))
		{
			objAlertHistoryDetailsVO.setStrSubDivision(request.getParameter(AppConstants.ALERT_HISTORY_SUBDIVISION));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_ASSET)))
		{
			objAlertHistoryDetailsVO.setStrAsset(request.getParameter(AppConstants.ALERT_HISTORY_ASSET));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_FLEET)))
		{
			objAlertHistoryDetailsVO.setStrFleet(request.getParameter(AppConstants.ALERT_HISTORY_FLEET));
		}		
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_MODEL)))
		{
			objAlertHistoryDetailsVO.setStrModel(request.getParameter(AppConstants.ALERT_HISTORY_MODEL));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_SHOP)))
		{
			objAlertHistoryDetailsVO.setStrShop(request.getParameter(AppConstants.ALERT_HISTORY_SHOP));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_MULTIUSER)))
		{
			objAlertHistoryDetailsVO.setStrMultiUsers(request.getParameter(AppConstants.ALERT_HISTORY_MULTIUSER));
		}		
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_FROMDATE)))
		{
			objAlertHistoryDetailsVO.setStrFromDate(request.getParameter(AppConstants.ALERT_HISTORY_FROMDATE));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_TODATE)))
		{
			objAlertHistoryDetailsVO.setStrToDate(request.getParameter(AppConstants.ALERT_HISTORY_TODATE));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_NUMBEROFDAYS)))
		{
			objAlertHistoryDetailsVO.setStrNumberOfDays(request.getParameter(AppConstants.ALERT_HISTORY_NUMBEROFDAYS));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_SEARCHVALUE)))
		{
			objAlertHistoryDetailsVO.setStrSearchValue(request.getParameter(AppConstants.ALERT_HISTORY_SEARCHVALUE));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_PAGE_NO)))
		{
			objAlertHistoryDetailsVO.setPageNo(request.getParameter(AppConstants.ALERT_HISTORY_PAGE_NO));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_RECORDS_PERPAGE)))
		{
			objAlertHistoryDetailsVO.setRecordsPerPage(request.getParameter(AppConstants.ALERT_HISTORY_RECORDS_PERPAGE));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HISTORY_START_ROW)))
		{
			objAlertHistoryDetailsVO.setStartRow(request.getParameter(AppConstants.ALERT_HISTORY_START_ROW));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request.getParameter(AppConstants.ALERT_HST_METHOD_FLAG)))
		{
			objAlertHistoryDetailsVO.setStrMethodFlag(request.getParameter(AppConstants.ALERT_HST_METHOD_FLAG));
		}
		multiSubscriptionPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.ALERT_HISTORY_MULTI_SUCSCRIPTION);
		objAlertHistoryDetailsVO.setMultiSubscriptionPrivilege(multiSubscriptionPrivilege);
		objAlertHistoryDetailsVO.setUserId(EsapiUtil.stripXSSCharacters(userVO.getStrEmail()));
		objAlertHistoryDetailsVO.setUserType(EsapiUtil.stripXSSCharacters(userVO.getUserType()));
		objAlertHistoryDetailsVO.setUserTimeZone(EsapiUtil.stripXSSCharacters(userVO.getTimeZone()));		
		objAlertHstDetailsVO = alertHistoryService.getAlertHistoryDetails(objAlertHistoryDetailsVO);
		return objAlertHstDetailsVO;
	 }
	/**
	 * 
	 * @param
	 * @return 
	 * @Description * This method is used for export selected data.
	 * 
	 */
	@RequestMapping(value = AppConstants.EXPORT_ALERTHISTORY_SCREEN, method = RequestMethod.POST)
	public void exportAlertHistoryReport(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws RMDWebException {
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		AlertHstDetailsVO objAlertHstDetailsVO = new AlertHstDetailsVO();
		boolean multiSubscriptionPrivilege = false;
		boolean smsPrivilege = false;
		try
		{
			multiSubscriptionPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(),AppConstants.ALERT_HISTORY_MULTI_SUCSCRIPTION);
			smsPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.ALERT_SUBSCRIPTION_SMS);
			objAlertHstDetailsVO = getAlertHistoryDetails(request);
			if (null != objAlertHstDetailsVO.getAlertHistoryHdrlst() && !objAlertHstDetailsVO.getAlertHistoryHdrlst().isEmpty()) 
			{  
				csvContent = convertToCSVAlertHistoryReport(objAlertHstDetailsVO.getAlertHistoryHdrlst(), locale,multiSubscriptionPrivilege,smsPrivilege);
				response.setContentType(AppConstants.CONTENT_TYPE);
				response.setHeader(AppConstants.CONTENT,AppConstants.ATTACH_FILENAME+ AppConstants.ALERTHISTORY_EXPORT_FILENAME);
				objServletOutputStream = response.getOutputStream();
				ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(csvContent.getBytes());
				objBufferedInputStream = new BufferedInputStream(objByteArrayInputStream);
				objBufferedOutputStream = new BufferedOutputStream(objServletOutputStream);
				byte[] byteArr = new byte[2048];
				int bytesread;
				while ((bytesread = objBufferedInputStream.read(byteArr, 0,	byteArr.length)) != -1)
				{
					objBufferedOutputStream.write(byteArr, 0, bytesread);
					objBufferedOutputStream.flush();
				}
			}
		}
		catch (Exception e) 
		{
			rmdWebLogger.error("Exception occured in exportAlertHistoryReport method ",e);
			RMDWebErrorHandler.handleException(e);
		} 
	}
	/**
	 * 
	 * @param
	 * @return 
	 * @Description * This method is used to convert in CVS for export selected data.
	 * 
	 */
	private String convertToCSVAlertHistoryReport(List<AlertHistoryDetailsVO> objAlertHistoryDetailsVOlst, Locale locale,boolean multiSubscriptionPrivilege,boolean smsPrivilege) 
	{
		StringBuilder strBuffeHeader = new StringBuilder();
		String csvContent = null;
		try 
		{
			
			if (multiSubscriptionPrivilege && smsPrivilege) 
			{
				strBuffeHeader.append(appContext.getMessage(AppConstants.ALERTHISTORY_EXPORT_HEADER_MULTIUSER_SMS,null, locale));
			}
			else if(multiSubscriptionPrivilege){
				strBuffeHeader.append(appContext.getMessage(AppConstants.ALERTHISTORY_EXPORT_HEADER_MULTIUSER,null, locale));
			}
			else if(smsPrivilege){
				strBuffeHeader.append(appContext.getMessage(AppConstants.ALERTHISTORY_EXPORT_HEADER_SMS,null, locale));
			}
			else
			{
				strBuffeHeader.append(appContext.getMessage(AppConstants.ALERTHISTORY_EXPORT_HEADER,null, locale));
			}			
			strBuffeHeader.append(RMDCommonConstants.NEWLINE);
			for (AlertHistoryDetailsVO objAlertHistoryDetailsVO  : objAlertHistoryDetailsVOlst)
			{
				if (multiSubscriptionPrivilege) 
				{
					if (null != objAlertHistoryDetailsVO.getStrMultiUsers())
					{
						strBuffeHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE
						+ objAlertHistoryDetailsVO.getStrMultiUsers()
						+ AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR);
					} 
					else 
					{
						strBuffeHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR);
					}
				}
				if(smsPrivilege){
					if (null != objAlertHistoryDetailsVO.getMobileNo())
					{
						strBuffeHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE
						+ objAlertHistoryDetailsVO.getMobileNo()
						+ AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR);
					} 
					else 
					{
						strBuffeHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR);
					}
					if (null != objAlertHistoryDetailsVO.getNotification())
					{
						strBuffeHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE
						+ objAlertHistoryDetailsVO.getNotification()
						+ AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR);
					} 
					else 
					{
						strBuffeHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR);
					}
				}
				if (null != objAlertHistoryDetailsVO.getStrAsset())
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE
					+ objAlertHistoryDetailsVO.getStrAsset()
					+ AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				} 
				else 
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != objAlertHistoryDetailsVO.getStrType())
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE
					+ objAlertHistoryDetailsVO.getStrType()
					+ AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				} 
				else 
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != objAlertHistoryDetailsVO.getStrAlertDate())
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE
					+ objAlertHistoryDetailsVO.getStrAlertDate()
					+ AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				} 
				else 
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != objAlertHistoryDetailsVO.getStrGPSLatLog())
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE
					+ objAlertHistoryDetailsVO.getStrGPSLatLog()
					+ AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				} 
				else 
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != objAlertHistoryDetailsVO.getStrRegion())
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE
					+ objAlertHistoryDetailsVO.getStrRegion()
					+ AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				} 
				else 
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				}												
				if (null != objAlertHistoryDetailsVO.getStrSubDivision())
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE
					+ objAlertHistoryDetailsVO.getStrSubDivision()
					+ AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				} 
				else 
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != objAlertHistoryDetailsVO.getStrModel())
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE
					+ objAlertHistoryDetailsVO.getStrModel()
					+ AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				} 
				else 
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != objAlertHistoryDetailsVO.getStrFleet())
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE
					+ objAlertHistoryDetailsVO.getStrFleet()
					+ AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				} 
				else 
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != objAlertHistoryDetailsVO.getStrShop())
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE
					+ objAlertHistoryDetailsVO.getStrShop()
					+ AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				} 
				else 
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != objAlertHistoryDetailsVO.getStrAlertTitle())
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE
					+ objAlertHistoryDetailsVO.getStrAlertTitle()
					+ AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				} 
				else 
				{
					strBuffeHeader.append(AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
					+ RMDCommonConstants.COMMMA_SEPARATOR);
				}																		
				strBuffeHeader.append(RMDCommonConstants.NEWLINE);
			}			
			csvContent = strBuffeHeader.toString();
		} catch (Exception exception) 
		{
			rmdWebLogger.error("Convert To CSV convertToCSVAlertHistoryReport Report"+ exception);
		}
		return csvContent;
	}
	
	@RequestMapping(value = AppConstants.REQ_URI_ALERT_HISTORY_ASSETS)
	@ResponseBody public 
	Map<String, String> getAltHstAssets(final HttpServletRequest request)throws  RMDWebException 
	{
		Map<String, String> alertHstAssetsMap = new HashMap<String, String>();
		String customerId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CUSTOMER_ID));
		String strFleet = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_HISTORY_FLEET));
		String strModel = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ALERT_HISTORY_MODEL));
		try 
		{
			alertHstAssetsMap = alertHistoryService.getAltHstAssets(customerId,strFleet,strModel);
		} 
		catch (Exception rmdEx) 
		{
			rmdWebLogger.error("RMDWebException occured in getAltHstAssets()",rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return alertHstAssetsMap;
	}
	
	/**
	 * @return Map<String, Map<String, String>>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Site Shipping,Site Status & SiteEdit Types
	 *              dropdown.
	 */
	@RequestMapping(value = AppConstants.GET_ALERT_HST_POPULATE_DATA)
	@ResponseBody public
	Map<String, Map<String, String>> getAlertHisotryPopulateData(final HttpServletRequest request) throws RMDWebException 
	{
		Map<String, Map<String, String>> allAlertHisotryData = new TreeMap<String, Map<String, String>>();
		String customerId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CUSTOMER_ID));
		try 
		{
			allAlertHisotryData = alertHistoryService.getAlertHisotryPopulateData(customerId);
		} 
		catch (Exception ex) 
		{
			rmdWebLogger.error("Exception occured in getAlertHisotryPopulateData method ",ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allAlertHisotryData;
	}
	
	public static boolean componentValue(List<String> componentList,String lookupValue) 
	{
		boolean compPrivilage = false;
		if (RMDCommonUtility.isCollectionNotEmpty(componentList)	&& !componentList.isEmpty()) 
		{
			for (int i = 0; i < componentList.size(); i++)
			{
				if ((lookupValue != null && !lookupValue.isEmpty()) && componentList.get(i).equalsIgnoreCase(lookupValue))
				{
						compPrivilage = true;
						break;										
				}

			}
		}
		return compPrivilage;
	}
}
