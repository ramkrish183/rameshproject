package com.ge.trans.rmd.alert.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.apache.http.HttpHost;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.fluent.Content;
import org.apache.http.client.fluent.Form;
import org.apache.http.client.fluent.Request;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.alert.valueobjects.AlertRxTypeDetails;
import com.ge.trans.rmd.alert.valueobjects.AlertSubscriptionDetailsVO;
import com.ge.trans.rmd.alert.valueobjects.ModelVO;
import com.ge.trans.rmd.alert.valueobjects.RestrictedAlertShopVO;
import com.ge.trans.rmd.alert.valueobjects.ShopsVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.valueobjects.UserRequestType;
import com.ge.trans.rmd.common.vo.SMSResponseVO;
import com.ge.trans.rmd.common.vo.UpdatePhoneVO;
import com.ge.trans.rmd.km.util.KMConstants;
import com.ge.trans.rmd.pp.valueobjects.CustLookupVO;
import com.ge.trans.rmd.pp.valueobjects.FleetVO;
import com.ge.trans.rmd.pp.valueobjects.RegionVO;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.alert.valueobjects.AlertActivateDeleteAlertRequestType;
import com.ge.trans.rmd.services.alert.valueobjects.AlertAssetRequestType;
import com.ge.trans.rmd.services.alert.valueobjects.AlertAssetResponseType;
import com.ge.trans.rmd.services.alert.valueobjects.AlertMultiUsersResponseType;
import com.ge.trans.rmd.services.alert.valueobjects.AlertSubResponseType;
import com.ge.trans.rmd.services.alert.valueobjects.AlertSubscriptionRequestType;
import com.ge.trans.rmd.services.alert.valueobjects.AlertSubscriptionResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.Customer;
import com.ge.trans.rmd.services.assets.valueobjects.Fleet;
import com.ge.trans.rmd.services.assets.valueobjects.SubDivisionResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.sun.jersey.core.impl.provider.entity.XMLJAXBElementProvider.App;

@Service
public class AlertSubscriptionServiceImpl extends RMDBaseServiceImpl implements
		AlertSubscriptionService {

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	WebServiceInvoker webServiceInvoker;
	
	@Autowired
	private CachedService cachedService;
	@Value("${" + AppConstants.ADMIN_LDAP_CONNECTION_FACTORY + "}")
	String ldapConnectionFact;
	@Value("${" + AppConstants.ADMIN_LDAP_CONNECTION_URL + "}")
	String ldapConnectionUrl;
	@Value("${" + AppConstants.ADMIN_LDAP_CONNECTION_PSWD + "}")
	String ldapConnectionPswd;
	@Value("${" + AppConstants.ADMIN_SECURITY_AUTHENTICATION + "}")
	String securityAuthentication;
	@Value("${" + AppConstants.SMTP_SERVER_NAME + "}")
	String emailServerName;
	@Value("${" + AppConstants.ADMIN_MAIL_SERVER + "}")
	String mailServer;
	@Value("${" + AppConstants.ADMIN_LDAP_SECURITY_PRINCIPLE + "}")
	String ldapSecurityPrinciple;
	@Value("${" + AppConstants.ADMIN_BASE_DN + "}")
	String baseDn;
	@Value("${" + AppConstants.TWILIO_ENDPOINT_URL + "}")
	String TWILIO_ENDPOINT_URL;
	@Value("${" + AppConstants.TWILIO_AUTH_HEADER + "}")
	String TWILIO_AUTH_HEADER;
	@Value("${" + AppConstants.PROXY_HOST_TWILIO + "}")
	String PROXY_HOST_TWILIO;
	@Value("${" + AppConstants.PROXY_PORT_TWILIO + "}")
	String PROXY_PORT_TWILIO;
	@Value("${" + AppConstants.TWILIO_SERVICE_SID + "}")
	String TWILIO_SERVICE_SID;
	@Value("${" + AppConstants.OMD_CONNECTION_PATH + "}")
	String OMD_CONNECTION_PATH;
	
	
	/**
	 * This is the method used for fetch the asset for Eoa Service 
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */
	@Override
	public Map<String, String> getAssetForCustomer(String customerId)
			throws RMDWebException {
		final Map<String, String> assetList = new HashMap<String, String>();
		AlertAssetRequestType assetRequestType = new AlertAssetRequestType();
		assetRequestType.setCustomerId(customerId);
		AlertAssetResponseType[] assetResponseType;

		try {			
			assetResponseType = (AlertAssetResponseType[]) webServiceInvoker.post(
					ServiceConstants.GET_ASSET_FOR_CUSTOMER, assetRequestType, AlertAssetResponseType[].class);
			// setting the result in bean
			if (!RMDCommonUtility.checkNull(assetResponseType)) {
				for (int i = 0; i < assetResponseType.length; i++) {
					assetList.put(assetResponseType[i].getVehicleObjId(),
							assetResponseType[i].getAssetNumber());
				}
			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAssetForCustomer method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return assetList;
	}
	
	@Override
	public Map<String, String> getAssetEOAForCustomer(String customerId)
			throws RMDWebException {
		final Map<String, String> assetList = new HashMap<String, String>();
		AlertAssetRequestType assetRequestType = new AlertAssetRequestType();
		assetRequestType.setCustomerId(customerId);
		AssetsRequestType objAssetsReqType = new AssetsRequestType();

		try {
			final AssetResponseType[] assetResponseType = (AssetResponseType[]) webServiceInvoker
					.post(ServiceConstants.GET_ASSETS, objAssetsReqType,
							AssetResponseType[].class);
			if (null != assetResponseType && assetResponseType.length > 0) {
				for (AssetResponseType assetResponse : assetResponseType) {
					if (assetResponse.getCustomerID().equalsIgnoreCase(
							assetRequestType.getCustomerId())) {
						assetList.put(assetResponse.getAssetObjid(),
								assetResponse.getAssetNumber());
					}
				}
			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAssetEOAForCustomer method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return assetList;
	}

	@Override
	public Map<String, String> getAlertForCustomer(String customerID)
			throws RMDWebException {

		LinkedHashMap<String, String> mapNotificationLevelsNValues = new LinkedHashMap<String, String>();
		ArrayList<String> assetList = new ArrayList<String>();
		AlertAssetRequestType assetRequestType = new AlertAssetRequestType();
		assetRequestType.setCustomerId(customerID);
		AlertSubResponseType assetResponseType;

		try {
			assetResponseType = (AlertSubResponseType) webServiceInvoker.post(
					ServiceConstants.GET_ALERT_FOR_CUSTOMER, assetRequestType,
					AlertSubResponseType.class);
			// setting the result in bean
			if (!RMDCommonUtility.checkNull(assetResponseType)) {

				assetList = assetResponseType.getAlertNotifyType();
				final Map<String, String> pathParamsMapForLevels = new HashMap<String, String>();
				ApplicationParametersResponseType[] notificationLevelValues;
				if (assetList != null && !assetList.isEmpty()) {
					for (String notifyString : assetList) {
						pathParamsMapForLevels.put(AppConstants.LIST_NAME,
								notifyString);
						notificationLevelValues = getLookupValue(pathParamsMapForLevels);
						if (!RMDCommonUtility
								.checkNull(notificationLevelValues)) {
							for (ApplicationParametersResponseType notificationLevelValue : notificationLevelValues) {
								mapNotificationLevelsNValues.put(notificationLevelValue
										.getListDescription(),notificationLevelValue.getLookupValue());
							}
						}

					}
				}

			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAlertForCustomer method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return mapNotificationLevelsNValues;
	}

	@Override
	public List<String> getATSEnabledCustomers() throws RMDWebException {
		final List<String> customers = new ArrayList<String>();

		try {
			Customer[] customer = (Customer[]) webServiceInvoker.get(
					ServiceConstants.GET_SUBSCRIPTION_CUSTOMER, null, null,
					null, Customer[].class);

			for (int i = 0; i < customer.length; i++) {
				customers.add(customer[i].getCustomerID());
			}

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				rmdWebLogger
						.error("AlertSubscriptionServiceImpl :: No records found for getATSEnabledCustomers() service "
								+ e.getMessage());
			} else {
				rmdWebLogger
						.error("AlertSubscriptionServiceImpl :: Exception occured in getATSEnabledCustomers() method "
								+ e.getMessage());
				throw e;
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getATSEnabledCustomers() method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return customers;
	}

	@Override
	public String activateOrDeactivateAlert(
			List<AlertSubscriptionDetailsVO> alertSubscriptionDetailsVOList)
			throws RMDWebException {

		String pass = AppConstants.FAILURE;
		try {

			AlertSubscriptionRequestType ppAlertSubscriptionRequestType;

			AlertActivateDeleteAlertRequestType rowList = new AlertActivateDeleteAlertRequestType();

			List<AlertSubscriptionRequestType> rowValues = new ArrayList<AlertSubscriptionRequestType>();

			for (AlertSubscriptionDetailsVO rows : alertSubscriptionDetailsVOList) {
				ppAlertSubscriptionRequestType = new AlertSubscriptionRequestType();
				ppAlertSubscriptionRequestType.setCustomerAlertObjId(rows.getCustomerAlertObjId());
				if (rows.getFleetid() != null && !rows.getFleetid().isEmpty()) {
					ppAlertSubscriptionRequestType.setFleetid(rows.getFleetid());
				}else if(rows.getVehicleObjId() != null && !rows.getVehicleObjId().isEmpty()) {
					ppAlertSubscriptionRequestType.setVehicleObjId(rows.getVehicleObjId());
				}else if(rows.getRegionid() != null && !rows.getRegionid().isEmpty()) {
					ppAlertSubscriptionRequestType.setRegionid(rows.getRegionid());
				}else if (rows.getShopid() != null && !rows.getShopid().isEmpty()) {
					ppAlertSubscriptionRequestType.setShopid(rows
							.getShopid());
				}else if (null != rows.getModelId() && !rows.getModelId().isEmpty()) {
					ppAlertSubscriptionRequestType.setModelId(rows.getModelId());
				}
				ppAlertSubscriptionRequestType.setStatus(rows.getStatus());
				ppAlertSubscriptionRequestType.setUserid(rows.getUserId());
				rowValues.add(ppAlertSubscriptionRequestType);
			}

			rowList.setListAlertSubscriptionDetails(rowValues);
			pass = (String) webServiceInvoker.post(
					ServiceConstants.ACT_DEACT_ALERT, rowList, String.class);

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: No records found for activateOrDeactivateAlert service "
								+ e.getMessage());
			} else {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: Exception occured in activateOrDeactivateAlert method "
								+ e.getMessage());
				throw e;
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in activateOrDeactivateAlert method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return pass;
	}

	@Override
	public String deleteAlert(
			List<AlertSubscriptionDetailsVO> alertSubscriptionDetailsVOList)
			throws RMDWebException {

		String pass = AppConstants.FAILURE;
		try {
			AlertSubscriptionRequestType ppAlertSubscriptionRequestType;
			AlertActivateDeleteAlertRequestType rowList = new AlertActivateDeleteAlertRequestType();
			List<AlertSubscriptionRequestType> rowValues = new ArrayList<AlertSubscriptionRequestType>();

			for (AlertSubscriptionDetailsVO rowVal : alertSubscriptionDetailsVOList) {
				ppAlertSubscriptionRequestType = new AlertSubscriptionRequestType();
				ppAlertSubscriptionRequestType.setNotifyAlertObjId(rowVal
						.getAlertConfSeqId());
				ppAlertSubscriptionRequestType.setCustomerAlertObjId(rowVal
						.getCustomerAlertObjId());
				if (rowVal.getVehicleObjId() != null
						&& !rowVal.getVehicleObjId().isEmpty()) {
					ppAlertSubscriptionRequestType.setVehicleObjId(rowVal
							.getVehicleObjId());
				} else if (rowVal.getFleetid() != null
						&& !rowVal.getFleetid().isEmpty()) {
					ppAlertSubscriptionRequestType.setFleetid(rowVal
							.getFleetid());
				} else if (rowVal.getRegionid() != null
						&& !rowVal.getRegionid().isEmpty()) {
					ppAlertSubscriptionRequestType.setRegionid(rowVal
							.getRegionid());
				} else if (rowVal.getShopid() != null
						&& !rowVal.getShopid().isEmpty()) {
					ppAlertSubscriptionRequestType.setShopid(rowVal
							.getShopid());
				}else if (null != rowVal.getModelId()
						&& !rowVal.getModelId().isEmpty()) {
					ppAlertSubscriptionRequestType.setModelId(rowVal
							.getModelId());
				}
				ppAlertSubscriptionRequestType.setUserid(rowVal.getUserId());
				rowValues.add(ppAlertSubscriptionRequestType);

			}

			rowList.setListAlertSubscriptionDetails(rowValues);
			pass = (String) webServiceInvoker.post(ServiceConstants.DEL_ALERT,
					rowList, String.class);
		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: No records found for activateOrDeactivateAlert service "
								+ e.getMessage());
			} else {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: Exception occured in activateOrDeactivateAlert method "
								+ e.getMessage());
				throw e;
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in activateOrDeactivateAlert method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return pass;
	}
	
	@Override
	public String updatephone(List<UpdatePhoneVO> tempList) throws RMDWebException {

		String pass = AppConstants.FAILURE;
		try {
			UserRequestType userrequesttype = new UserRequestType();
			if (tempList.size() > 0) {
				for (UpdatePhoneVO updatePhoneVO : tempList) {
					UserRequestType iterValue = new UserRequestType();
					if (!RMDCommonUtility.isNullOrEmpty(updatePhoneVO.getUserId())) {
						iterValue.setUserId(updatePhoneVO.getUserId());
					}
					if (!RMDCommonUtility.isNullOrEmpty(updatePhoneVO.getUserPhoneNo())) {
						iterValue.setUserPhoneNo(updatePhoneVO.getUserPhoneNo());
					}
					if (!RMDCommonUtility.isNullOrEmpty(updatePhoneVO.getUserPhoneCountryCode())){
						iterValue.setUserPhoneCountryCode(updatePhoneVO.getUserPhoneCountryCode());
					}	
					userrequesttype.getarrUserRequestType().add(iterValue);
				}
			  }
			pass = (String) webServiceInvoker.post(ServiceConstants.UPDATE_PHONE,
					userrequesttype, String.class);
		}  catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in updatephone method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return pass;
	}
		
	@Override
	public String getOTPParameters() throws RMDWebException {
		String otp_parameters = (String) webServiceInvoker.get(
				ServiceConstants.GET_OTP_PARAMETERS, null, null,
				null, String.class);
		return otp_parameters;
	}
	
	@Override
	public SMSResponseVO sendOTP(String to,String body,String RetryAttempts) throws RMDWebException {
		
		SMSResponseVO smsresponsevo = new SMSResponseVO();
		try {
			int i,retries = Integer.parseInt(RetryAttempts);
			for(i=0;i<retries&&retries>0;i++)
			{
				Content content = Request.Post(TWILIO_ENDPOINT_URL)
						.addHeader("Authorization",TWILIO_AUTH_HEADER)
						.viaProxy(new HttpHost(PROXY_HOST_TWILIO,Integer.parseInt(PROXY_PORT_TWILIO)))
						.bodyForm(Form.form().add("To",to).add("Body",body).add("MessagingServiceSid",TWILIO_SERVICE_SID).build())
						.execute().returnContent();
				JSONObject obj = new JSONObject(content.toString());
				smsresponsevo.setSid(obj.getString("sid"));
				smsresponsevo.setStatus(obj.getString("status"));
				smsresponsevo.setError_code(obj.getString("error_code"));
				if(smsresponsevo.getError_code() == null || smsresponsevo.getError_code().equals("null"))
					break;
				retries--;
			}
		} catch (ClientProtocolException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return smsresponsevo;
	}

	@Override
	public String editAlert(AlertSubscriptionDetailsVO alertSubscriptionDtl)
			throws RMDWebException {
		String pass = AppConstants.FAILURE;
		try {
			AlertSubscriptionRequestType ppAlertRequestType = new AlertSubscriptionRequestType();
			ppAlertRequestType.setUserid(alertSubscriptionDtl.getUserId());
			ppAlertRequestType.setRegionid(alertSubscriptionDtl.getRegionid());
			ppAlertRequestType.setFleetid(alertSubscriptionDtl.getFleetid());
			ppAlertRequestType.setVehicleObjId(alertSubscriptionDtl
					.getVehicleObjId());
			ppAlertRequestType.setCustomerAlertObjId(alertSubscriptionDtl
					.getCustomerAlertObjId());
			ppAlertRequestType.setEmailFormat(alertSubscriptionDtl
					.getEmailFormat());
			ppAlertRequestType.setShopid(alertSubscriptionDtl
						.getShopid());
			ppAlertRequestType.setModelId(alertSubscriptionDtl
					.getModelId());
			ppAlertRequestType.setNotificationType(alertSubscriptionDtl
					.getNotificationType());
			ppAlertRequestType.setRxType(alertSubscriptionDtl
					.getRxType());
			pass = (String) webServiceInvoker.post(ServiceConstants.EDIT_ALERT,
					ppAlertRequestType, String.class);
		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: No records found for editAlert service "
								+ e.getMessage());
			} else {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: Exception occured in editAlert method "
								+ e.getMessage());
				throw e;
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in editAlert method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return pass;
	}
	
	@Override
	public String addAlertSubscriptionData(AlertSubscriptionDetailsVO alertSubscriptionDtls)
			throws RMDWebException {

		String returnString = null;
		AlertSubscriptionRequestType ppAlertRequestType = new AlertSubscriptionRequestType();
		if(alertSubscriptionDtls.getAlertSubscribed() != null && !alertSubscriptionDtls.getAlertSubscribed().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setAlertSubscribed(alertSubscriptionDtls.getAlertSubscribed());
		}
		if(alertSubscriptionDtls.getService() != null && !alertSubscriptionDtls.getService().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setService(alertSubscriptionDtls.getService());
		}
		if(alertSubscriptionDtls.getCustomerId() != null && !alertSubscriptionDtls.getCustomerId().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setCustomerId(alertSubscriptionDtls.getCustomerId());
		}
		if(alertSubscriptionDtls.getAlertType() != null && !alertSubscriptionDtls.getAlertType().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setAlertType(alertSubscriptionDtls.getAlertType());
		}
		if(alertSubscriptionDtls.getRegion() != null && !alertSubscriptionDtls.getRegion().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setRegion(alertSubscriptionDtls.getRegion());
		}
		if(alertSubscriptionDtls.getFleet() != null && !alertSubscriptionDtls.getFleet().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setFleet(alertSubscriptionDtls.getFleet());
		}
		if(alertSubscriptionDtls.getAsset() != null && !alertSubscriptionDtls.getAsset().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setAsset(alertSubscriptionDtls.getAsset());
		}
		if(alertSubscriptionDtls.getEmailFormat() != null && !alertSubscriptionDtls.getEmailFormat().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setEmailFormat(alertSubscriptionDtls.getEmailFormat());
		}
		if(alertSubscriptionDtls.getSubscriptionModel() != null && !alertSubscriptionDtls.getSubscriptionModel().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setSubscriptionModel(alertSubscriptionDtls.getSubscriptionModel());
		}
		if(alertSubscriptionDtls.getStatus() != null && !alertSubscriptionDtls.getStatus().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setStatus(alertSubscriptionDtls.getStatus());
		}
		if(alertSubscriptionDtls.getUserId() != null && !alertSubscriptionDtls.getUserId().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setUserid(alertSubscriptionDtls.getUserId());
		}
		if(alertSubscriptionDtls.getEmailId() != null && !alertSubscriptionDtls.getEmailId().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setEmailId(alertSubscriptionDtls.getEmailId());
		}
		if(alertSubscriptionDtls.getUserId() != null && !alertSubscriptionDtls.getUserId().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setUserid(alertSubscriptionDtls.getUserId());
		}
		if(alertSubscriptionDtls.getUserSeqId() != null && !alertSubscriptionDtls.getUserSeqId().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setUserSeqId(alertSubscriptionDtls.getUserSeqId());
		}		
		if(alertSubscriptionDtls.getSubDivision() != null && !alertSubscriptionDtls.getSubDivision().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setSubDivision(alertSubscriptionDtls.getSubDivision());
		}
		if(alertSubscriptionDtls.getShop() != null && !alertSubscriptionDtls.getShop().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setShop(alertSubscriptionDtls.getShop());
		}
		if(alertSubscriptionDtls.getRxSubscribedAlerts() != null && !alertSubscriptionDtls.getRxSubscribedAlerts().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setRxSubscribedAlerts(alertSubscriptionDtls.getRxSubscribedAlerts());
		}
		if(alertSubscriptionDtls.getValue() != null && !alertSubscriptionDtls.getValue().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setRxAlertValue(alertSubscriptionDtls.getValue());
		}
		if(null != alertSubscriptionDtls.getModel() && !alertSubscriptionDtls.getModel().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setModel(alertSubscriptionDtls.getModel());
		}
		if(null != alertSubscriptionDtls.getMultiUsers() && !alertSubscriptionDtls.getMultiUsers().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setMultiUsers(alertSubscriptionDtls.getMultiUsers());
		}
		if(null != alertSubscriptionDtls.getConfigAlertModelVal() && !alertSubscriptionDtls.getConfigAlertModelVal().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setConfigAlertModelVal(alertSubscriptionDtls.getConfigAlertModelVal());
		}
		if(null != alertSubscriptionDtls.getNotificationType() && !alertSubscriptionDtls.getNotificationType().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setNotificationType(alertSubscriptionDtls.getNotificationType());
		}
		if(null != alertSubscriptionDtls.getPhoneNumber() && !alertSubscriptionDtls.getPhoneNumber().equals(AppConstants.EMPTY_STRING)){
			ppAlertRequestType.setPhoneNumber(alertSubscriptionDtls.getPhoneNumber());
		}
			ppAlertRequestType.setRxType(alertSubscriptionDtls.getRxType());
		ppAlertRequestType.setMultiSubscriptionPrivilege(alertSubscriptionDtls.isMultiSubscriptionPrivilege());
		try {		
			returnString = (String) webServiceInvoker.post(
					ServiceConstants.ADD_ALERT_SUBSCRIPTION_DATA, ppAlertRequestType,
					String.class);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in addAlertSubscriptionData method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return returnString;
	}
	
	@Override
	public List<AlertSubscriptionDetailsVO> getAlertSubscriptionDetails(AlertSubscriptionDetailsVO alertSubscriptionDtls)
			throws RMDWebException {
		List<AlertSubscriptionDetailsVO> alertSubscriptionDetailslst = new ArrayList<AlertSubscriptionDetailsVO>();
		AlertSubscriptionDetailsVO alertSubscriptionDetails = null;
		AlertSubscriptionRequestType ppAlertSubscriptionRequestType = new AlertSubscriptionRequestType();		
		ppAlertSubscriptionRequestType.setUserid(alertSubscriptionDtls.getUserId());
		ppAlertSubscriptionRequestType.setFlag(alertSubscriptionDtls.getFlag());
		ppAlertSubscriptionRequestType.setModelPrivilege(alertSubscriptionDtls.isModelPrivilege());
		ppAlertSubscriptionRequestType.setConfigAlertPrivilege(alertSubscriptionDtls.isConfigAlertPrivilege());		
		ppAlertSubscriptionRequestType.setAllCustomer(alertSubscriptionDtls.isAllCustomer());
		ppAlertSubscriptionRequestType.setMultiSubscriptionPrivilege(alertSubscriptionDtls.isMultiSubscriptionPrivilege());
		ppAlertSubscriptionRequestType.setUserType(alertSubscriptionDtls.getUserType());		
		ppAlertSubscriptionRequestType.setCustomerId(alertSubscriptionDtls.getCustomerId());
		ppAlertSubscriptionRequestType.setCustomerList(alertSubscriptionDtls.getCustomerList());

		AlertSubscriptionResponseType[] ppAlertRespObj;
		
		ppAlertRespObj = (AlertSubscriptionResponseType[]) webServiceInvoker.post(
				ServiceConstants.GET_ALERT_SUBSCRIPTION_DATA, ppAlertSubscriptionRequestType,
				AlertSubscriptionResponseType[].class);
		List<ApplicationParametersResponseType> newUrgencyList = cachedService.getAllLookupValues().get(AppConstants.URGENCY_OF_REPAIR_DETAILS);
		StringBuilder uniqueStr = null;
		String service = null;
		String urgencyValue=null;
		String urgencyData = null;
		String []urgencyInfo=null;
		String uniqSr=null;
		try
		{
			if (!RMDCommonUtility.checkNull(ppAlertRespObj)) {
				//the order should not be changed as this will affect the duplicate check.
				for(int i = 0; i < ppAlertRespObj.length; i++){
					alertSubscriptionDetails = new AlertSubscriptionDetailsVO();
					uniqueStr = new StringBuilder();
					if(ppAlertRespObj[i].getService() != null && !ppAlertRespObj[i].getService().equals(AppConstants.EMPTY_STRING)){
						service=ppAlertRespObj[i].getService();
					}
					alertSubscriptionDetails.setEoaAlert(AppConstants.FALSE);
					if (null != ppAlertRespObj[i].getFirstName() && !ppAlertRespObj[i].getFirstName().equals(AppConstants.EMPTY_STRING)) {
						alertSubscriptionDetails.setUserName(ppAlertRespObj[i].getFirstName()+AppConstants.EMPTY_SPACE+ppAlertRespObj[i].getLastName());
						uniqSr = ppAlertRespObj[i].getFirstName()+AppConstants.EMPTY_SPACE+ppAlertRespObj[i].getLastName();
						uniqueStr.append(uniqSr);						
					}		
					if(null != ppAlertRespObj[i].getUserEmail() && !ppAlertRespObj[i].getUserEmail().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setUserEmail(ppAlertRespObj[i].getUserEmail().trim());		
						uniqueStr.append(AppConstants.TILDA + ppAlertRespObj[i].getUserEmail().trim());
					}
					//same for ATS and EOA
					if(ppAlertRespObj[i].getAlertSubscribed() != null && !ppAlertRespObj[i].getAlertSubscribed().equals(AppConstants.EMPTY_STRING)){																		
						if (null != service	&& AppConstants.CONFIG_ALERT.equals(service)) 
						{
							alertSubscriptionDetails.setAlertSubscribed(ppAlertRespObj[i].getRuleTitle());						
							if (null != uniqSr
									&& !uniqSr.equals(AppConstants.EMPTY_STRING)) {
								uniqueStr.append(AppConstants.TILDA
										+ ppAlertRespObj[i]
												.getRuleTitle());
							} else {
								uniqueStr.append(ppAlertRespObj[i]
										.getRuleTitle());
							}
						}
						else
						{
							alertSubscriptionDetails.setAlertSubscribed(ppAlertRespObj[i].getAlertSubscribed());						
							if (null != uniqSr
									&& !uniqSr.equals(AppConstants.EMPTY_STRING)) {
								uniqueStr.append(AppConstants.TILDA
										+ ppAlertRespObj[i]
												.getAlertSubscribed()
												.replace(AppConstants.ATTR_EMPTY,
														AppConstants.UNDERSCORE)
												.toUpperCase());
							} else {
								uniqueStr.append(ppAlertRespObj[i]
										.getAlertSubscribed()
										.replace(AppConstants.ATTR_EMPTY,
												AppConstants.UNDERSCORE)
										.toUpperCase());
							}
						}
						
						
						
					}/*if eoa then value rx-""*/
					if(ppAlertRespObj[i].getService() != null && !ppAlertRespObj[i].getService().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setService(ppAlertRespObj[i].getService());
						uniqueStr.append(AppConstants.TILDA + ppAlertRespObj[i].getService());
					}
					if(ppAlertRespObj[i].getCustomerId() != null && !ppAlertRespObj[i].getCustomerId().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setCustomerId(ppAlertRespObj[i].getCustomerId());
						uniqueStr.append(AppConstants.TILDA + ppAlertRespObj[i].getCustomerId());
					}
					//EOA SERVICE
					if(null!=service && AppConstants.EOA.equals(service)){
						alertSubscriptionDetails.setEoaAlert(AppConstants.TRUE);
						//Rx(urgency,locoimpact,subsystem,title)
						if(ppAlertRespObj[i].getRxSubscribedAlerts() != null && !ppAlertRespObj[i].getRxSubscribedAlerts().equals(AppConstants.EMPTY_STRING)){
							alertSubscriptionDetails.setRxSubscribedAlerts(ppAlertRespObj[i].getRxSubscribedAlerts());
							uniqueStr.append(AppConstants.TILDA + ppAlertRespObj[i].getRxSubscribedAlerts());
						}
						//value of the rx
						if(ppAlertRespObj[i].getValue() != null && !ppAlertRespObj[i].getValue().equals(AppConstants.EMPTY_STRING)){
							if(ppAlertRespObj[i].getValue().length()==1)
							{
							for(ApplicationParametersResponseType urgency:newUrgencyList)
	 {
								urgencyData = urgency.getLookupValue();
								if (urgencyData.indexOf('~') != -1) {
									urgencyInfo = urgencyData.split("~");
									urgencyValue = urgencyInfo[0];

									if (ppAlertRespObj[i].getValue().equals(
											urgencyValue)) {
										alertSubscriptionDetails
												.setValue(urgencyInfo[0] + ":"
														+ urgencyInfo[1]);
										uniqueStr.append(AppConstants.TILDA
												+ urgencyInfo[0] + ":"
												+ urgencyInfo[1]);
									}
								} else {
									alertSubscriptionDetails
											.setValue(ppAlertRespObj[i].getValue());
									uniqueStr.append(AppConstants.TILDA
											+ ppAlertRespObj[i].getValue());
								}
							}
							}
							else
							{
								alertSubscriptionDetails
								.setValue(ppAlertRespObj[i].getValue());
						uniqueStr.append(AppConstants.TILDA
								+ ppAlertRespObj[i].getValue());
							}
							
						}
					} 
					else {
						alertSubscriptionDetails
								.setValue(AppConstants.NOT_APLICABLE);
					}
					if(ppAlertRespObj[i].getAlertType() != null && !ppAlertRespObj[i].getAlertType().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setAlertType(ppAlertRespObj[i].getAlertType());
						
					}
					if(ppAlertRespObj[i].getEmailFormat() != null && !ppAlertRespObj[i].getEmailFormat().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setEmailFormat(ppAlertRespObj[i].getEmailFormat());
						//uniqueStr.append(AppConstants.TILDA + ppAlertRespObj[i].getEmailFormat());
					}
					if(ppAlertRespObj[i].getSubscriptionModel() != null && !ppAlertRespObj[i].getSubscriptionModel().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setSubscriptionModel(ppAlertRespObj[i].getSubscriptionModel());					
					}
					if(ppAlertRespObj[i].getRegion() != null && !ppAlertRespObj[i].getRegion().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setRegion(ppAlertRespObj[i].getRegion());
						uniqueStr.append(AppConstants.TILDA + ppAlertRespObj[i].getRegion());
					}
					//sub division
					if(ppAlertRespObj[i].getSubDivision() != null && !ppAlertRespObj[i].getSubDivision().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setSubDivision(ppAlertRespObj[i].getSubDivision());
						uniqueStr.append(AppConstants.TILDA + ppAlertRespObj[i].getSubDivision());
					}
					if(ppAlertRespObj[i].getFleet() != null && !ppAlertRespObj[i].getFleet().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setFleet(ppAlertRespObj[i].getFleet());
						uniqueStr.append(AppConstants.TILDA + ppAlertRespObj[i].getFleet());
					}
					if(ppAlertRespObj[i].getAsset() != null && !ppAlertRespObj[i].getAsset().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setAsset(ppAlertRespObj[i].getAsset());
						uniqueStr.append(AppConstants.TILDA + ppAlertRespObj[i].getAsset());
					}
					//shop				
					if(ppAlertRespObj[i].getShop() != null && !ppAlertRespObj[i].getShop().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setShop(ppAlertRespObj[i].getShop());
						uniqueStr.append(AppConstants.TILDA + ppAlertRespObj[i].getShop());
					}
					if(ppAlertRespObj[i].getStatus() != null && !ppAlertRespObj[i].getStatus().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setStatus(ppAlertRespObj[i].getStatus());
					}
					if(ppAlertRespObj[i].getUserid() != null && !ppAlertRespObj[i].getUserid().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setUserId(ppAlertRespObj[i].getUserid());
					}
					if(ppAlertRespObj[i].getEmailId() != null && !ppAlertRespObj[i].getEmailId().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setEmailId(ppAlertRespObj[i].getEmailId());
					}
					if(ppAlertRespObj[i].getUserSeqId() != null && !ppAlertRespObj[i].getUserSeqId().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setUserSeqId(alertSubscriptionDtls.getUserSeqId());
					}				
					if (ppAlertRespObj[i].getCustomerAlertObjId() != null && !ppAlertRespObj[i].getCustomerAlertObjId().equals(AppConstants.EMPTY_STRING)) {
						alertSubscriptionDetails.setCustomerAlertObjId(ppAlertRespObj[i].getCustomerAlertObjId());					
					}
					if (ppAlertRespObj[i].getRegionid() != null && !ppAlertRespObj[i].getRegionid().equals(AppConstants.EMPTY_STRING)) {
						alertSubscriptionDetails.setRegionid(ppAlertRespObj[i].getRegionid());					
					}
					if (ppAlertRespObj[i].getFleetid() != null && !ppAlertRespObj[i].getFleetid().equals(AppConstants.EMPTY_STRING)) {
						alertSubscriptionDetails.setFleetid(ppAlertRespObj[i].getFleetid());					
					}
					if (ppAlertRespObj[i].getVehicleObjId() != null && !ppAlertRespObj[i].getVehicleObjId().equals(AppConstants.EMPTY_STRING)) {
						alertSubscriptionDetails.setVehicleObjId(ppAlertRespObj[i].getVehicleObjId());					
					}
					//subdivision ID
					if (ppAlertRespObj[i].getSubDivisionid() != null && !ppAlertRespObj[i].getSubDivisionid().equals(AppConstants.EMPTY_STRING)) {
						alertSubscriptionDetails.setSubDivisionid(ppAlertRespObj[i].getSubDivisionid());					
					}
					//shopId
					if (ppAlertRespObj[i].getShopid() != null && !ppAlertRespObj[i].getShopid().equals(AppConstants.EMPTY_STRING)) {
						alertSubscriptionDetails.setShopid(ppAlertRespObj[i].getShopid());					
					}
					//Rx alert id
					if (ppAlertRespObj[i].getRxAlertId() != null && !ppAlertRespObj[i].getRxAlertId().equals(AppConstants.EMPTY_STRING)) {
						alertSubscriptionDetails.setRxAlertId(ppAlertRespObj[i].getRxAlertId());
					}
					//Model				
					if(null != ppAlertRespObj[i].getModel() && !ppAlertRespObj[i].getModel().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setModel(ppAlertRespObj[i].getModel());
						uniqueStr.append(AppConstants.TILDA + ppAlertRespObj[i].getModel());
					}
					//ModelId
					if (null != ppAlertRespObj[i].getModelId() && !ppAlertRespObj[i].getModelId().equals(AppConstants.EMPTY_STRING)) {
						alertSubscriptionDetails.setModelId(ppAlertRespObj[i].getModelId());					
					}
					if (null != ppAlertRespObj[i].getRuleTitle() && !ppAlertRespObj[i].getRuleTitle().equals(AppConstants.EMPTY_STRING)) {
						alertSubscriptionDetails.setRuleTitle(ppAlertRespObj[i].getRuleTitle());
					}			
					if(null != ppAlertRespObj[i].getOriginalId() && !ppAlertRespObj[i].getOriginalId().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setOriginalId(ppAlertRespObj[i].getOriginalId());					
					}	
					if (null != service
							&& AppConstants.CONFIG_ALERT.equals(service)
							&& null != ppAlertRespObj[i].getRuleModel()
							&& !ppAlertRespObj[i].getRuleModel().equals(
									AppConstants.EMPTY_STRING)) {
						alertSubscriptionDetails.setRuleModel(ppAlertRespObj[i]
								.getRuleModel());
						uniqueStr.append(AppConstants.TILDA + ppAlertRespObj[i]
								.getRuleModel());
					}else {
						alertSubscriptionDetails
						.setRuleModel(AppConstants.NOT_APLICABLE);
			}		
					if (null != ppAlertRespObj[i].getRxType() && !ppAlertRespObj[i].getRxType().equals(AppConstants.EMPTY_STRING)) {
						String rxType = null;
						if(ppAlertRespObj[i].getRxType().equals(AppConstants.EOA_PROBLEM)){
							alertSubscriptionDetails.setRxType(AppConstants.EOA);
							rxType = AppConstants.EOA;
						}
						else if(ppAlertRespObj[i].getRxType().equals(AppConstants.ESTP_PROBLEM)){
							alertSubscriptionDetails.setRxType(AppConstants.SHOP_ADVICER);
							rxType = AppConstants.SHOP_ADVICER;
						}
						else 
						{
							alertSubscriptionDetails.setRxType(AppConstants.NOT_APLICABLE);
							rxType = AppConstants.NOT_APLICABLE;
							
						}
						if(ppAlertRespObj[i].getService() != null && !ppAlertRespObj[i].getService().equals(AppConstants.EMPTY_STRING) && ppAlertRespObj[i].getService().equals(AppConstants.EOA)){
						uniqueStr.append(AppConstants.TILDA + rxType);
						}
					}	
					if(null != ppAlertRespObj[i].getNotificationType() && !ppAlertRespObj[i].getNotificationType().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setNotificationType(ppAlertRespObj[i].getNotificationType());	
					}
					else {
						alertSubscriptionDetails
								.setNotificationType(AppConstants.NOT_APLICABLE);
					}
					if(null != ppAlertRespObj[i].getPhoneNumber() && !ppAlertRespObj[i].getPhoneNumber().equals(AppConstants.EMPTY_STRING)){
						alertSubscriptionDetails.setPhoneNumber(ppAlertRespObj[i].getPhoneNumber());					
					}
					else {
						alertSubscriptionDetails
								.setPhoneNumber(AppConstants.NOT_APLICABLE);
					}
					if (null != service
							&& AppConstants.CONFIG_ALERT.equals(service)
							&& null != ppAlertRespObj[i].getActive()
							&& !ppAlertRespObj[i].getActive().equals(
									AppConstants.EMPTY_STRING)) {
						alertSubscriptionDetails.setActive(ppAlertRespObj[i]
								.getActive());
					} else {
						alertSubscriptionDetails
								.setActive(AppConstants.NOT_APLICABLE);
					}																						
					if(null != uniqueStr && uniqueStr.length() > 0){
						alertSubscriptionDetails.setUniqueString(uniqueStr.toString());
					}
					if (null != ppAlertRespObj[i].getAlertConfSeqId() && !ppAlertRespObj[i].getAlertConfSeqId().equals(AppConstants.EMPTY_STRING)) {
						alertSubscriptionDetails.setAlertConfSeqId(ppAlertRespObj[i].getAlertConfSeqId());
					}	
					alertSubscriptionDetailslst.add(alertSubscriptionDetails);
				}
			}
		}
		 catch (Exception ex) 
		 {
				rmdWebLogger.error("Exception occured in getAlertSubscriptionDetails method ", ex);
				RMDWebErrorHandler.handleException(ex);
		}
		
		finally
		{
			ppAlertRespObj = null;
		}
		return alertSubscriptionDetailslst;
	}
	
	@Override
	public Map<String, String> getFleetsForCustomer(String customerId)
			throws RMDWebException {
		Map<String, ArrayList<FleetVO>> fleetmap = new TreeMap<String, ArrayList<FleetVO>>();
		Map<String, String> fleetList = null;
				try {	
					
					fleetmap = cachedService.getAllFleets();
					fleetList = new TreeMap<String, String>();
					if(fleetmap != null && fleetmap.size() > 0 && fleetmap.get(customerId) != null){
							for(FleetVO fleetVo : fleetmap.get(customerId)){
								fleetList.put(fleetVo.getFleetId(), fleetVo.getFleetNo());
						}
					}				
					
			
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getFleetsForCustomer method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return fleetList;
	}

	@Override
	public Map<String, String> getRegionsForCustomer(String customerId)
			throws RMDWebException {
		Map<String, ArrayList<RegionVO>> regionmap = null;
		Map<String, String> regionList = null;
				try {	
					
					regionmap = cachedService.getAllRegions();
					regionList = new TreeMap<String, String>();
					if(regionmap != null && regionmap.size() > 0 && regionmap.get(customerId) != null){
							for(RegionVO regionVo : regionmap.get(customerId)){
								regionList.put(regionVo.getRegionId(), regionVo.getRegionName());
						}
					}				
					
			
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getRegionsForCustomer method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return regionList;
	}
	
	@Override
	public Map<String, String> getSubDivisionForRegion(String region, String customerId)
			throws RMDWebException {
		Map<String, String> subDivisionList = null;
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>(2);
				try {	
					queryParamMap.put(AppConstants.REGION,region);
					queryParamMap.put(AppConstants.CUSTOMER_ID,customerId);
					SubDivisionResponseType[] regionList = (SubDivisionResponseType[]) webServiceInvoker.get(
							ServiceConstants.GET_SUB_DIVISION, null, queryParamMap, null,
							SubDivisionResponseType[].class);
					subDivisionList = new TreeMap<String, String>();
					if(regionList != null && regionList.length > 0){
						for (int i = 0; i < regionList.length; i++) {
							if(null!=regionList[i].getSubDivisionId()&& null!=regionList[i].getSubDivisionName()){
							subDivisionList.put(regionList[i].getSubDivisionId(),regionList[i].getSubDivisionName());
							}
						}
					}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getSubDivisionForRegion method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return subDivisionList;
	}
	
	@Override
	public String getAlertSubAssetCountForUser(String userId)
			throws RMDWebException {
		String count = "0";
		try {
			final Map<String, String> pathParamsMap = new HashMap<String, String>();
			pathParamsMap.put(AppConstants.USER_ID, userId);
			count = (String) webServiceInvoker.post(
					ServiceConstants.GET_ALERT_SUB_ASSET_COUNT, userId, String.class);

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				rmdWebLogger
						.error("AlertSubscriptionServiceImpl :: No records found for getAlertSubAssetCountForUser service "
								+ e.getMessage());
			} else {
				rmdWebLogger
						.error("AlertSubscriptionServiceImpl :: Exception occured in getAlertSubAssetCountForUser method "
								+ e.getMessage());
				throw e;
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAlertSubAssetCountForUser method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return count;
	}
	

	/**
	 * getUserEmail This method is used to connect to LDAP and fetch the email
	 * 
	 * @param attr
	 *            the attr
	 * @return the sso users list
	 */
	@Override
	public String getUserEmail(String userId) throws Exception {

		rmdWebLogger.info("start of getUserEmail method");
		DirContext ctx = connectToLdap();
		String email = null;
		SearchControls constraints = new SearchControls();
		constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
		NamingEnumeration result = ctx.search(baseDn, userId, constraints);
		while (result.hasMore()) {
			SearchResult search = (SearchResult) result.next();
			String activationStatus = getDn(search.getAttributes(),
					AppConstants.SSO_STATUS);
			email = getDn(search.getAttributes(),AppConstants.MAIL);
			if (activationStatus != null
					&& !(activationStatus.equalsIgnoreCase(AppConstants.LETTER_A))) {
				rmdWebLogger.info("SSO Status for email " + email
						+ " is inactive ");
			}
		}
		rmdWebLogger.info("End of getUserEmail method");
		return email;
	}

	/**
	 * Connect to ldap.
	 * 
	 * @return the dir context
	 */
	// This Method is used to connect to LDAP
	public DirContext connectToLdap() throws RMDWebException {

		rmdWebLogger.info("start of connectToLdap method");
		DirContext context = null;
		Properties env = new Properties();
		try {
		env.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY,
				ldapConnectionFact);
		env.setProperty(javax.naming.Context.PROVIDER_URL, ldapConnectionUrl);
		env.setProperty(javax.naming.Context.SECURITY_PRINCIPAL,
				ldapSecurityPrinciple);
		env.setProperty(javax.naming.Context.SECURITY_CREDENTIALS,
				ldapConnectionPswd);
		env.setProperty(javax.naming.Context.SECURITY_AUTHENTICATION,
				securityAuthentication);
			context = new InitialDirContext(env);
		} catch (NamingException e) {
			rmdWebLogger.error("Exception occured in connectToLdap method ",
					e);
			RMDWebErrorHandler.handleException(e);
		}
		rmdWebLogger.info("end connectToLdap mehtod " + context);
		return context;
	}

	/**
	 * Gets the dn.
	 * 
	 * @param attrs the attrs
	 * @param attributeID
	 *            the attribute id
	 * @return the dn
	 */

	public String getDn(Attributes attrs, String attributeID) throws RMDWebException {

		String value = AppConstants.LETTER_E;
		if (attrs == null) {
			rmdWebLogger.info("No attributes");
		} else {
			try {
				rmdWebLogger.info("in getdn");
				for (NamingEnumeration ae = attrs.getAll(); ae.hasMore();) {
					Attribute attr = (Attribute) ae.next();
					if (attr.getID().equals(attributeID)) {
						for (NamingEnumeration e = attr.getAll(); e.hasMore(); value = e
								.next().toString())
							rmdWebLogger.info(attr.getID() + "........."
									+ value);
					}

				}
			} catch (Exception e) {
				rmdWebLogger.error("Exception occured in getDn method ",
						e);
				RMDWebErrorHandler.handleException(e);
			}

		}
		return value;
	}

	@Override
	public int postMail(String to, String subject, String message, String from)
			throws MessagingException, IOException  {
		int iReturn = 0;
		boolean debug = false;
		// Set the host smtp address
		Properties props = new Properties();
		props.put(AppConstants.MAIL_SERVER_NAME, mailServer);
		props.put(AppConstants.MAIL_SERVER_NAME, emailServerName);
		// create some properties and get the default Session
		Session session = Session.getDefaultInstance(props, null);
		session.setDebug(debug);
		if(OMD_CONNECTION_PATH.contains("dev"))
			subject = "DEV - " + subject;
		if(OMD_CONNECTION_PATH.contains("qa"))
			subject = "QA - " + subject;
		try {
			// create a message
			MimeMessage msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress(from));
			InternetAddress[] address = { new InternetAddress(to) };
			msg.setRecipients(Message.RecipientType.TO, address);
			msg.setSubject(subject);
			msg.setContent(message, AppConstants.MAIL_CONTENT_TYPE);

			msg.setSentDate(new java.util.Date());
			// send the message
			Transport.send(msg);
			iReturn = 1;
			rmdWebLogger.info("File Sent");
		} catch (MessagingException mex) {
			iReturn = 0;
			
			Exception ex;
			if ((ex = mex.getNextException()) != null) {
				rmdWebLogger.info(" Exception in postMail ");
			}
			rmdWebLogger.error("Exception occured in postMail method ",
					mex);
		}
		return iReturn;
	}

	@Override
	public boolean getcomponentValue(List<String> userComponentList,
			String componentName) {
		boolean compPrivilage = false;
		if (RMDCommonUtility.isCollectionNotEmpty(userComponentList)
				&& !userComponentList.isEmpty()) {
			for (int i = 0; i < userComponentList.size(); i++) {
				String componentObj =userComponentList.get(i);
				if (componentName != null && !componentName.isEmpty() && componentObj.equalsIgnoreCase(componentName)) {
						compPrivilage = true;
						break;
				}

			}
		}

		return compPrivilage;
	}

	@Override
	public Map<String, String> getRXFilterLookupValue(String listName)
			throws RMDWebException {
		rmdWebLogger
				.debug("Inside AlertSubscriptionServiceImpl in getRXFilterLookupValue Method");

		final Map<String, String> rxFilterMap = new TreeMap<String, String>();
		String rxFilterID = null;
		String rxFilterName = null;

		try {
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService
					.getAllLookupValues().get(listName);
			if (applParamResponseTypeList != null
					&& !applParamResponseTypeList.isEmpty()) {

				for (ApplicationParametersResponseType objResponse : applParamResponseTypeList) {
					rxFilterID = objResponse.getLookupValue();
					rxFilterName = objResponse.getLookupValue();
					rxFilterMap.put(rxFilterID, rxFilterName);
				}
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getRXFilterLookupValue() method - AlertSubscriptionServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return rxFilterMap;
	}

	@Override
	public Map<String, String> getShopForCustomer(String customerId)
			throws RMDWebException {
		rmdWebLogger
				.debug("Inside AlertSubscriptionServiceImpl in getShopForCustomer Method");

		Map<String, ArrayList<ShopsVO>> rxShopMap = new HashMap<String, ArrayList<ShopsVO>>();
		Map<String, String> shopList = null;
		try {
			rxShopMap = cachedService.getAllShops();
			shopList = new TreeMap<String, String>();
			if(rxShopMap != null && rxShopMap.size() > 0 && rxShopMap.get(customerId) != null){
					for(ShopsVO shopVO : rxShopMap.get(customerId)){
						shopList.put(shopVO.getShopId(), shopVO.getShopName());
				}
			}	
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getShopForCustomer() method - AlertSubscriptionServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return shopList;
	}
	
	/**
	 * @Description: Function to get the eligibility for the customer to view in
	 *               kph and litres from the lookup for the customer id passed
	 * @param customerId
	 * @return String
	 */
	@Override
	public List<String> getEOACustomerList()
			throws RMDWebException {
		List<String> customerList = new ArrayList<String>();
		Map<String, CustLookupVO> custLookupMap = new HashMap<String, CustLookupVO>();
		CustLookupVO custLookupVO = null;
		
		try {
			custLookupMap = cachedService.getSDCustLookup();
			if (null != custLookupMap) {

				Object []key = custLookupMap.keySet().toArray();
				for (int i = 0; i < key.length; i++) {
					custLookupVO = custLookupMap.get(key[i]);
					if (null == custLookupVO.getRxEmailCheck()
							|| custLookupVO.getRxEmailCheck().equals(AppConstants.STR_Y)) {
						customerList.add(custLookupVO.getCustomerId());
					}
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getEOACustomerList method ",
					ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return customerList;
	}
	
	@Override
	public Map<String, String> getRestrictedAlertShop(String customerId)
			throws RMDWebException {
		Map<String, ArrayList<RestrictedAlertShopVO>> alertShopMap = null;
		Map<String, String> alertShopList = null;
				try {	
					
					alertShopMap = cachedService.getRestrictedAlertShop();
					alertShopList = new TreeMap<String, String>();
					if(alertShopMap != null && alertShopMap.size() > 0 && alertShopMap.get(customerId) != null){
							for(RestrictedAlertShopVO restrictedAlertShopVO : alertShopMap.get(customerId)){
								if(null!=restrictedAlertShopVO.getProximityCheckFlag() && AppConstants.YES_FLAG.equalsIgnoreCase(restrictedAlertShopVO.getProximityCheckFlag())){
									alertShopList.put( restrictedAlertShopVO.getAlertName(),restrictedAlertShopVO.getAlertName());
								}
								
							}
					}				
					
			
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAllAlertShopChk method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return alertShopList;
	}
	
	/**
	 * This is the method used for fetching the SubSystem values through
	 * jquery call
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */
	@Override
	public Map<String, String> getSubSystemWithObjid(String flag)
			throws RMDWebException {
		rmdWebLogger
				.debug("Inside AlertSubscriptionServiceImpl in getSubSystemWithObjid Method");

		Map<String, String> subSystemMap = new HashMap<String, String>();
		String subSystemID = null;
		String subSystemName = null;
		try {

			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService
					.getAllLookupValues().get(KMConstants.SUB_SYSTEM);
			if (applParamResponseTypeList != null
					&& !applParamResponseTypeList.isEmpty()) {

				for (ApplicationParametersResponseType objResponse : applParamResponseTypeList) {
					if (!(AppConstants.SPECIFY.equalsIgnoreCase(objResponse
							.getLookupValue()))
							&& (AppConstants.ACTIVE
									.equalsIgnoreCase(objResponse
											.getLookupState()) || AppConstants.DEFAULT
									.equalsIgnoreCase(objResponse
											.getLookupState()))) {

						subSystemID = RMDCommonUtility
								.convertObjectToString(objResponse
										.getSysLookupSeqId());
						subSystemName = objResponse.getLookupValue();
						subSystemMap.put(subSystemID, subSystemName);
					}
				}
			}

		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getSubSystemWithObjid() method - AlertSubscriptionServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return subSystemMap;
	}

	/**
	 * This is the method used for fetching the Urgency of Repair values through
	 * jquery call
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */
	@Override
	public Map<String, String> getUrgencyOfRepairWithObjid(String flag,
			String customerId) throws RMDWebException {
		rmdWebLogger
				.debug("Inside AlertSubscriptionServiceImpl in getUrgencyOfRepairWithObjid Method");
		String urgencyRepairID = null;
		List<String> urgencyDetails = new ArrayList<String>();
		String urgencyData = null; 
		String urgencyId = null; 
		String urgencyVal = null;
		String oldUrgency=null;
		String []urgencyInfo = null;
		List<ApplicationParametersResponseType> valueList = null;
		List<ApplicationParametersResponseType> completevalueList = new ArrayList<ApplicationParametersResponseType>();
		Map<String, String> urgencyMap = new LinkedHashMap<String, String>();
		try {
			Map<String, List<ApplicationParametersResponseType>> applParamResponseTypeList = cachedService
					.getCustomerBasedLookupValues(customerId);
			List<ApplicationParametersResponseType> listOfUgrencyInfo = cachedService
					.getAllLookupValues().get(
							AppConstants.URGENCY_OF_REPAIR_DETAILS);
			List<ApplicationParametersResponseType> oldUrgencyList = cachedService.getAllLookupValues().get(KMConstants.URGENCY_OF_REPAIR);
			if (applParamResponseTypeList != null
					&& applParamResponseTypeList.size() > 0) {

				for (Map.Entry<String, List<ApplicationParametersResponseType>> entry : applParamResponseTypeList
						.entrySet()) {
					valueList = entry.getValue();
					completevalueList.addAll(valueList);
				}
				for (ApplicationParametersResponseType objResponse : listOfUgrencyInfo) {
					urgencyData = objResponse.getLookupValue();
					urgencyInfo = urgencyData.split("~");
					urgencyRepairID = urgencyInfo[0];
					for (ApplicationParametersResponseType objResponseList : completevalueList) {
						urgencyVal = objResponseList.getUrgency();
						if (urgencyRepairID.equals(urgencyVal)) {
							for(ApplicationParametersResponseType objUrgency:oldUrgencyList)
							{
								oldUrgency=objUrgency.getLookupValue();
								urgencyId = RMDCommonUtility
										.convertObjectToString(objUrgency
												.getSysLookupSeqId());
								if(urgencyVal.equals(oldUrgency))
								{
									urgencyMap.put(urgencyData,urgencyId);
								}
							}
							
						}
					}

				}

			} else {
				for (ApplicationParametersResponseType urgencyResponse : listOfUgrencyInfo) {
					if (!(AppConstants.SPECIFY.equalsIgnoreCase(urgencyResponse
							.getLookupValue()))) {
						urgencyData = urgencyResponse.getLookupValue();
						urgencyInfo = urgencyData.split("~");
						urgencyRepairID = urgencyInfo[0];
						urgencyDetails.add(urgencyRepairID);
						for(ApplicationParametersResponseType objUrgency:oldUrgencyList)
						{
							oldUrgency=objUrgency.getLookupValue();
							urgencyId = RMDCommonUtility
									.convertObjectToString(objUrgency
											.getSysLookupSeqId());
							if(urgencyRepairID.equals(oldUrgency))
							{
								urgencyMap.put(urgencyData,urgencyId);
							}
						}
						
					}
				}

			}

		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getUrgencyOfRepairWithObjid() method - AlertSubscriptionServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return urgencyMap;
	}
		
	

	
	/**
	 * This is the method used for fetching the Locomotive Impact values through
	 * jquery call
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */
	@Override
	public Map<String, String> getLocomotiveImpactWithObjid(String flag)
			throws RMDWebException {
		rmdWebLogger
				.debug("Inside AlertSubscriptionServiceImpl in getLocomotiveImpactWithObjid Method");

		Map<String, String> locoImpactMap = new HashMap<String, String>();
		String locoImpactID = null;
		String locoImpactName = null;

		try {
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService
					.getAllLookupValues().get(KMConstants.LOCOMOTIVE_IMPACT);
			if (applParamResponseTypeList != null
					&& !applParamResponseTypeList.isEmpty()) {

				for (ApplicationParametersResponseType objResponse : applParamResponseTypeList) {
					if (!(AppConstants.SPECIFY.equalsIgnoreCase(objResponse
							.getLookupValue())) && (AppConstants.ACTIVE.equalsIgnoreCase(objResponse
									.getLookupState()) || AppConstants.DEFAULT
									.equalsIgnoreCase(objResponse.getLookupState()))) {
							locoImpactID = RMDCommonUtility
									.convertObjectToString(objResponse
											.getSysLookupSeqId());
							locoImpactName = objResponse.getLookupValue();
							locoImpactMap.put(locoImpactID, locoImpactName);
					}
				}
			}

		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getLocomotiveImpactWithObjid() method - AlertSubscriptionServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return locoImpactMap;
	}
	
	/**
	 * This is the method used for fetching the Urgency of Repair values through
	 * jquery call
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */
	@Override
	public String getRXLookupFlag() throws RMDWebException {
		rmdWebLogger
				.debug("Inside AlertSubscriptionServiceImpl in getRXLookupFlag Method");
		String flag = null;
		try {
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService
					.getAllLookupValues().get(AppConstants.RX_SUBSCRIPTION_DELIVERY_EMAIL_FLAG);
			if (applParamResponseTypeList != null
					&& !applParamResponseTypeList.isEmpty()) {

				for (ApplicationParametersResponseType objResponse : applParamResponseTypeList) {
					if(null!=objResponse.getLookupValue() && !objResponse.getLookupValue().isEmpty()){
						flag = objResponse.getLookupValue();
					}else{
						flag=AppConstants.NO_FLAG;

					}
				}
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getUrgencyOfRepairWithObjid() method - AlertSubscriptionServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return flag;
	}
	
	/**
	 * This is the method used for fetch the fleets for Eoa Service 
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */
	@Override
	public Map<String, String> getFleetsForEOACustomer(String customerId)
			throws RMDWebException {
		Map<String, String> fleetList = new LinkedHashMap<String, String>();
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>(1);
		String fleetsName = null;
		String fleetID = null;
		try {
			queryParamMap.put(AppConstants.CUSTOMER, customerId);
			final Fleet[] fleet = (Fleet[]) webServiceInvoker.get(
					ServiceConstants.GET_FLEET_KEP, null, queryParamMap, null,
					Fleet[].class);
			if (fleet != null) {
				for (int i = 0; i < fleet.length; i++) {
					fleetsName = fleet[i].getFleet();
					fleetID = fleet[i].getFleetID();
					fleetList.put(fleetID, fleetsName);

				}
			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getFleetsForCustomer method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return fleetList;
	}
	
	@Override
	public String getMailTemplateLookupVal(String listName)
			throws RMDWebException {
		rmdWebLogger
				.debug("Inside AlertSubscriptionServiceImpl in getRXFilterLookupValue Method");

		String templateLookupVal = null;

		try {
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService
					.getAllLookupValues().get(listName);
			if (applParamResponseTypeList != null
					&& !applParamResponseTypeList.isEmpty()) {

				for (ApplicationParametersResponseType objResponse : applParamResponseTypeList) {
					templateLookupVal = objResponse.getLookupValue();

				}
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getRXFilterLookupValue() method - AlertSubscriptionServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return templateLookupVal;
	}
	
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Model values for
	 *               particular Customer.
	 */
	@Override
	public Map<String, String> getModelDetails(String customerId,String methodFlag)
			throws RMDWebException {
		rmdWebLogger
				.debug("Inside AlertSubscriptionServiceImpl in getModelDetails Method");
		Map<String, ArrayList<ModelVO>> modelMap = new TreeMap<String, ArrayList<ModelVO>>();
		Map<String, String> modelList = null;
		try {
			modelMap = cachedService.getAllModels();
			modelList = new TreeMap<String, String>();
			if (null != modelMap && !modelMap.isEmpty() && null != modelMap.get(customerId)) {
					if(methodFlag.equalsIgnoreCase(AppConstants.LOAD_MODEL_FOR_CONFIG))
					{
						for (ModelVO objModelVO : modelMap.get(customerId)) {
							modelList.put(objModelVO.getModelFamily(),
									objModelVO.getModelFamily());
						}
					}
					else
					{
						for (ModelVO objModelVO : modelMap.get(customerId)) {
							modelList.put(objModelVO.getModelObjId(),
									objModelVO.getModelName());
						}
					}
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getModelDetails() method - AlertSubscriptionServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return modelList;
	}
	
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Multi Users particular
	 *               Customer.
	 */
	@Override
	public Map<String, String> getMultiUsers(String customerId, String userType)
			throws RMDWebException {
		Map<String, String> multiUsersList = null; 
		Map<String, String> queryParamMap = new LinkedHashMap<String, String>(2);
		queryParamMap.put(AppConstants.CUSTOMER_ID, customerId);
		queryParamMap.put(AppConstants.USERTYPE, userType);
		AlertMultiUsersResponseType[] multiUsersResponseType;
		try {
			multiUsersResponseType = (AlertMultiUsersResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_MULTI_USERS, null, queryParamMap,
							null, AlertMultiUsersResponseType[].class);
			if (!RMDCommonUtility.checkNull(multiUsersResponseType)) {
				multiUsersList = new HashMap<String, String>(multiUsersResponseType.length);
				for (int i = 0; i < multiUsersResponseType.length; i++) {
					multiUsersList.put(
							multiUsersResponseType[i].getUserId(),
							multiUsersResponseType[i].getFirstName()
									+ AppConstants.BLANK_STRING
									+ multiUsersResponseType[i].getLastName()
									+ AppConstants.TILDA
									+ multiUsersResponseType[i]
											.getUserEmailId()
									+ AppConstants.TILDA
									+ multiUsersResponseType[i]
											.getUserPhoneNumber()
									+ AppConstants.TILDA
									+ multiUsersResponseType[i]
											.getUserCountryCode()
									);
				}
			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getMultiUsers method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		finally
		{
			multiUsersResponseType=null;
			queryParamMap = null;
		}
		return multiUsersList;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:List<String>
	 * @throws:Exception,RMDWebException
	 * @Description: This method is used for fetching the Config Alert for
	 *               Customer.
	 */
	@Override
	public List<String> getConfigAlertCustomerList() throws RMDWebException {
		List<String> customerList = new ArrayList<String>();
		Map<String, CustLookupVO> custLookupMap = new HashMap<String, CustLookupVO>();
		CustLookupVO custLookupVO = null;

		try {
			custLookupMap = cachedService.getSDCustLookup();
			if (null != custLookupMap) {
				Object []key = custLookupMap.keySet().toArray();
				for (int i = 0; i < key.length; i++) {
					custLookupVO = custLookupMap.get(key[i]);
					if (null != custLookupVO.getConfigAlertFlg()
							&& custLookupVO.getConfigAlertFlg().equals(AppConstants.YES_FLAG)) {
						customerList.add(custLookupVO.getCustomerId());
					}
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getConfigAlertCustomerList method ",
					ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return customerList;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Model values for
	 *               particular Customer.
	 */
	@Override
	public Map<String, String> getConfigAlertForCustomer(String customerId,
			String modelVal) throws RMDWebException {
		Map<String, String> configAlertList = null;
		Map<String, String> queryParamMap = new LinkedHashMap<String, String>(2);
		queryParamMap.put(AppConstants.CUSTOMER_ID, customerId);
		queryParamMap.put(AppConstants.MODEL_VALUE, modelVal);
		AlertSubResponseType[] assetResponseType;
		try {
			assetResponseType = (AlertSubResponseType[]) webServiceInvoker.get(
					ServiceConstants.GET_ALERT_RULES, null, queryParamMap,
					null, AlertSubResponseType[].class);
			if (!RMDCommonUtility.checkNull(assetResponseType)) {
				configAlertList = new HashMap<String, String>(assetResponseType.length);
				for (int i = 0; i < assetResponseType.length; i++) {
					configAlertList.put(assetResponseType[i].getOriginalId(),
							assetResponseType[i].getRuleTitle());
				}
			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getConfigAlertForCustomer method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		finally
		{
			assetResponseType=null;
			queryParamMap = null;
		}
		return configAlertList;
	}
	
	/**
	 * @Author:
	 * @return: system parameter map
	 * @Description: Fetching all system parameters
	 */
	@Override
	public Map<String, String> getAllSystemParameters() throws RMDWebException {
		Map<String, String> sysParamMap = null;
		try {
			sysParamMap = cachedService.getAllSystemParameters();

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAllSystemParameters method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return sysParamMap;
	}
	
	/**
	 * @param userId
	 * @return String
	 * @Description: method to get user email of the user
	 */
	@Override
	public String getUserEmailId(String userId) throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		String userEmailId = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(userId)) {
				queryParams.put(AppConstants.USER_ID, userId);
			}
			userEmailId = (String) webServiceInvoker.get(
					ServiceConstants.GET_USER_EMAIL_ID, null, queryParams,
					null, String.class);
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getUserEmailId method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return userEmailId;
	}
	
	/**
	 * @param userId
	 * @return String
	 * @Description: method to get user Phone No. of the user
	 */
	@Override
	public String getUserPhoneNo(String userId) throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		String userPhoneNo = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(userId)) {
				queryParams.put(AppConstants.USER_ID, userId);
			}
			userPhoneNo = (String) webServiceInvoker.get(
					ServiceConstants.GET_USER_PHONE_NO, null, queryParams,
					null, String.class);
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getUserPhoneNo method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return userPhoneNo;
	}
	
	/**
	 * @param userId
	 * @return String
	 * @Description: method to get user Phone No. country code of the user
	 */
	@Override
	public String getUserPhoneCountryCode(String userId) throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		String userPhoneCountryCode = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(userId)) {
				queryParams.put(AppConstants.USER_ID, userId);
			}
			userPhoneCountryCode = (String) webServiceInvoker.get(
					ServiceConstants.GET_USER_PHONE_COUNTRY_CODE, null, queryParams,
					null, String.class);
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getUserPhoneCountryCode method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return userPhoneCountryCode;
	}
	@Override
	public List<AlertRxTypeDetails> getRXTypeLookupValue(String listName)
			throws RMDWebException {
		rmdWebLogger
				.debug("Inside AlertSubscriptionServiceImpl in getRXFilterLookupValue Method");

		final List<AlertRxTypeDetails> rxTypeMap = new ArrayList<AlertRxTypeDetails>();
		AlertRxTypeDetails alertRxTypeDetails = null;
		try {
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService
					.getAllLookupValues().get(listName);
			if (applParamResponseTypeList != null
					&& !applParamResponseTypeList.isEmpty()) {

				for (ApplicationParametersResponseType objResponse : applParamResponseTypeList) {
					if(objResponse.getLookupValue()!=null){
					String[] rxTypeArr =objResponse.getLookupValue().split("~");
					alertRxTypeDetails = new AlertRxTypeDetails();
					alertRxTypeDetails.setRxType(rxTypeArr[0]);
					alertRxTypeDetails.setRxTypeDesc(rxTypeArr[2]);
					alertRxTypeDetails.setRxTypeTitle(rxTypeArr[1]);
					rxTypeMap.add(alertRxTypeDetails);
					}
				}
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getRXTypeLookupValue() method - AlertSubscriptionServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return rxTypeMap;
	}
}


