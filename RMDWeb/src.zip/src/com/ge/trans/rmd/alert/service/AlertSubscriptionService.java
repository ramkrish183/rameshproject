package com.ge.trans.rmd.alert.service;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;

import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.SMSResponseVO;
import com.ge.trans.rmd.common.vo.UpdatePhoneVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.alert.valueobjects.AlertRxTypeDetails;
import com.ge.trans.rmd.alert.valueobjects.AlertSubscriptionDetailsVO;

public interface AlertSubscriptionService 
{
	public  List<String> getATSEnabledCustomers() throws RMDWebException, Exception;

	
	public Map<String, String> getAssetForCustomer(String customerId) throws RMDWebException,
			Exception;

	public Map<String, String> getAlertForCustomer(String customerId)
			throws RMDWebException, Exception;

	public String activateOrDeactivateAlert(List<AlertSubscriptionDetailsVO> alertSubscriptionDetailsVOList) throws RMDWebException, Exception;

	public String editAlert(AlertSubscriptionDetailsVO alertSubscriptionDtl)throws RMDWebException, Exception;
	public String deleteAlert(List<AlertSubscriptionDetailsVO> alertSubscriptionDetailsVOList)throws RMDWebException, Exception;
	
	public String updatephone(List<UpdatePhoneVO> tempList)throws RMDWebException, Exception;
	
	public SMSResponseVO sendOTP(String to,String body,String RetryAttempts) throws RMDWebException;
	
	public String getOTPParameters() throws RMDWebException;

	public String addAlertSubscriptionData(
			AlertSubscriptionDetailsVO alertSubscriptionDtls)throws RMDWebException, Exception;


	public List<AlertSubscriptionDetailsVO> getAlertSubscriptionDetails(
			AlertSubscriptionDetailsVO alertSubscriptionDtls)
			throws RMDWebException, Exception;
	
	public Map<String, String> getFleetsForCustomer(
			String customerId)
			throws RMDWebException, Exception;


	public Map<String, String> getRegionsForCustomer(String customerId)throws RMDWebException, Exception;
	public Map<String, String> getSubDivisionForRegion(String region, String customerId)throws RMDWebException, Exception;

	public String getAlertSubAssetCountForUser(String userId) throws RMDWebException,
			Exception;


	public String getUserEmail(String userId)throws Exception;
	
 	public int postMail( String to, String subject, String message , String from) throws MessagingException, FileNotFoundException, IOException;
 	
	public boolean getcomponentValue(List<String> userComponentList,String componentName);
	
	public Map<String, String> getRXFilterLookupValue(String listName) throws GenericAjaxException, RMDWebException;
	
	public Map<String, String> getShopForCustomer(String customerId) throws GenericAjaxException, RMDWebException;
	public List<String> getEOACustomerList() throws RMDWebException, Exception;
	public Map<String, String> getRestrictedAlertShop(String customerId) throws RMDWebException, Exception;
	public Map<String, String> getSubSystemWithObjid(String flag) throws RMDWebException;
	public Map<String, String> getLocomotiveImpactWithObjid(String flag) throws RMDWebException;
	public Map<String, String> getUrgencyOfRepairWithObjid(String flag,String customerId) throws RMDWebException;
	public String getRXLookupFlag() throws RMDWebException;
	public Map<String, String> getAssetEOAForCustomer(String customerId) throws RMDWebException, Exception;
	public Map<String, String> getFleetsForEOACustomer(String customerId) throws RMDWebException, Exception;
	public String getMailTemplateLookupVal(String listName) throws GenericAjaxException, RMDWebException;
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:GenericAjaxException,RMDWebException
	 * @Description: This method is used for fetching the Model values for particular Customer.
	 */
	public Map<String, String> getModelDetails(String customerId, String methodFlag) throws GenericAjaxException, RMDWebException;
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:GenericAjaxException,RMDWebException
	 * @Description: This method is used for fetching the Model values for particular Customer.
	 */
	public Map<String, String> getMultiUsers(String customerId,String userType) throws RMDWebException, Exception;
	public List<String> getConfigAlertCustomerList() throws RMDWebException, Exception;
	public Map<String, String> getConfigAlertForCustomer(String customerId,String modelVal)throws RMDWebException, Exception;


	public Map<String, String> getAllSystemParameters()throws RMDWebException, Exception;


	public String getUserEmailId(String stripXSSCharacters)throws RMDWebException, Exception;
	public String getUserPhoneNo(String stripXSSCharacters)throws RMDWebException, Exception;
	public String getUserPhoneCountryCode(String stripXSSCharacters)throws RMDWebException, Exception;
	public List<AlertRxTypeDetails> getRXTypeLookupValue(String listName) throws GenericAjaxException, RMDWebException;

	
}
