package com.ge.trans.rmd.alert.valueobjects;

public class AlertRxTypeDetails {
	private String rxType;
	private String rxTypeDesc;
	private String rxTypeTitle;
	public String getRxType() {
		return rxType;
	}
	public void setRxType(String rxType) {
		this.rxType = rxType;
	}
	public String getRxTypeDesc() {
		return rxTypeDesc;
	}
	public void setRxTypeDesc(String rxTypeDesc) {
		this.rxTypeDesc = rxTypeDesc;
	}
	public String getRxTypeTitle() {
		return rxTypeTitle;
	}
	public void setRxTypeTitle(String rxTypeTitle) {
		this.rxTypeTitle = rxTypeTitle;
	}

}
