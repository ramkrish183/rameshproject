package com.ge.trans.rmd.alert.service;

import java.util.List;
import java.util.Map;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.alert.valueobjects.AlertHistoryDetailsVO;
import com.ge.trans.rmd.alert.valueobjects.AlertHstDetailsVO;

public interface AlertHistoryService
{
	public String getAltHstLookUp(String lisName) throws RMDWebException;

	public AlertHstDetailsVO getAlertHistoryDetails(AlertHistoryDetailsVO objAlertHistoryDetailsVO) throws RMDWebException;

	public Map<String, String> getAlertHistoryLookUp(String serviceTypes)throws RMDWebException;

	public Map<String, String> getAltHstAssets(String customerId,
			String strFleet, String strModel)throws RMDWebException;

	public Map<String, Map<String, String>> getAlertHisotryPopulateData(
			String customerId) throws RMDWebException;

	public List<String> getSubMenuList(String userId) throws RMDWebException;

}
