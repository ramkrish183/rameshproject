/**
 * ============================================================
 * Classification: GE Confidential
 * File : AssetFaultService.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.cm.service;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on : February 14, 2012
 * History
 * Modified By : iGATE
 *
 * Copyright (C) 2012 General Electric Company. All rights reserved
 *
 * ============================================================
 */ 
package com.ge.trans.rmd.cm.service;

import com.ge.trans.rmd.cm.beans.AssetFaultDataBean;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface AssetFaultService {
	
	public Object getAssetFaultDetails(final AssetFaultDataBean assetFaultDataBean, String userCustomer)throws RMDWebException, Exception ;
	public Object getAssetFaultDetailsForCaseID(final AssetFaultDataBean assetFaultDataBean)throws RMDWebException, Exception ;

}