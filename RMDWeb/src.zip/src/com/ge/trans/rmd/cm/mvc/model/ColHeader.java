package com.ge.trans.rmd.cm.mvc.model;

public class ColHeader {

}
