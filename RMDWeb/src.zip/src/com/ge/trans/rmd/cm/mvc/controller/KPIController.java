/**
 * ============================================================
 * File 			: KPIController.java
 * Description 		: Controller for KPIs * 
 * Package 			: com.ge.trans.rmd.cm.mvc.controller
 * Author 			: UST
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		: April 04, 2012
 * History
 * Modified By 		: Initial Release
 * Copyright (C) 2012 General Electric Company. All rights reserved
 * ============================================================
 */
package com.ge.trans.rmd.cm.mvc.controller;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import com.ge.trans.rmd.cm.beans.KPIBean;
import com.ge.trans.rmd.cm.beans.OpenCasesBean;
import com.ge.trans.rmd.cm.service.KPIService;
import com.ge.trans.rmd.cm.valueobjects.KPITotalCountResponseTypeVO;
import com.ge.trans.rmd.cm.valueobjects.KpiInfoTypeVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.vo.ResourceVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.logging.RMDLogger;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class KPIController extends RMDBaseController {

	@Autowired
	private KPIService kpiService;
	@Autowired
	private ApplicationContext appContext;
	@Autowired
	private AuthorizationService authorizationService;
	public static final RMDLogger LOG = RMDLogger
			.getLogger(SolutionExecutionController.class);

	public void setKpiService(final KPIService kpiService) {
		this.kpiService = kpiService;
	}

	/**
	 * This method will fetch RxCount to be displayed in the KPI Dashboard
	 * 
	 * @param model
	 * @param response
	 * @param request
	 * @return
	 * @throws RMDWebException 
	 * @throws GenericAjaxException 
	 */
	@RequestMapping(AppConstants.GET_KPIS)
	public ModelAndView getKPIValues(final Model model,
			final HttpServletResponse response,
			final HttpServletRequest request, final Locale locale) throws GenericAjaxException, RMDWebException {
		try {
			List<ResourceVO> lstKPI = new ArrayList<ResourceVO>();
			List<KPITotalCountResponseTypeVO> lsKPIResponseTypes = new ArrayList<KPITotalCountResponseTypeVO>();
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			/* For timezone issue */
			final String defaultTimezone = (String) request
					.getAttribute(AppConstants.DEFAULT_TIMEZONE);
			String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
					userVO.getTimeZone());
			/* For timezone issue */
			String customerId = null;
			String roleName = RMDCommonUtil.getRoleName(userVO.getRolesVOLst(),
					userVO.getRoleId());
			List<String> kpiDefaultLookupList = new ArrayList<String>();
			List<String> kpiLookupList = new ArrayList<String>();
			boolean rxAccuracyNodata = true;
			boolean ntfNodata = true;
			boolean responseTimeNodata = true;
			KPIBean kpiBean = null;
			Map<String, List<String>> noOfDaysForDropDowns = new HashMap<String, List<String>>();
			customerId = userVO.getCustomerId();

			if (RMDCommonUtility.isNullOrEmpty(customerId)) {
				customerId = RMDCommonConstants.ALL_CUSTOMER;
			} else {
				customerId = userVO.getCustomerId();
			}

			if (!RMDCommonUtility.isNullOrEmpty(roleName)) {
				// used to bring the list of kpis for the particular role
				// and user
				lstKPI = getOrderedKPIs(userVO);
			}

			Map<String, String> componentList = new HashMap<String, String>();
			componentList.put(AppConstants.KPI_RX_DELIVERED,
					AppConstants.KPI_RX_DELIVERED_ATTR);
			componentList.put(AppConstants.KPI_RX_CLOSED_URGENCY,
					AppConstants.KPI_RX_CLOSED_URGENCY_ATTR);
			componentList.put(AppConstants.KPI_RX_CLOSED_TYPE,
					AppConstants.KPI_RX_CLOSED_TYPE_ATTR);
			componentList.put(AppConstants.KPI_RX_ACCURACY,
					AppConstants.KPI_RX_ACCURACY_ATTR);
			componentList.put(AppConstants.KPI_NTF, AppConstants.KPI_NTF_ATTR);
			componentList.put(AppConstants.KPI_RESPONSE_TIME,
					AppConstants.KPI_RESPONSE_TIME_ATTR);

			// used to bring the component name from lookup
			getComponentPrivilege(componentList, userVO, request);
			// Filter the unavailable kpi from order list
			filterResourceByKPIPrivilege(request, lstKPI);

			final OpenCasesBean openCaseBean = new OpenCasesBean();

			openCaseBean.setUserLanguage(userVO.getStrUserLanguage());
			//TZ Fix Changes			
			openCaseBean.setTimeZone(applicationTimezone);
			openCaseBean.setTimeZoneCode(userVO.getTimeZoneCode());
			openCaseBean.setCustomerId(userVO.getCustomerId());
			if (null != userVO.getProducts() && !userVO.getProducts().isEmpty()) {
				openCaseBean.setProducts(userVO.getProducts());
			}

			if ((Boolean) request
					.getAttribute(AppConstants.KPI_RX_DELIVERED_ATTR)) {
				kpiDefaultLookupList
						.add(AppConstants.KPI_RXDELIVERED_URGENCY_DEFAULT_LOOKBACK_DAYS);
				kpiLookupList
						.add(AppConstants.KPI_RXDELIVERED_URGENCY_LOOKBACK_DAYS);
			}
			if ((Boolean) request
					.getAttribute(AppConstants.KPI_RX_CLOSED_URGENCY_ATTR)) {
				kpiDefaultLookupList
						.add(AppConstants.KPI_RXCLOSED_URGENCY_DEFAULT_LOOKBACK_DAYS);
				kpiLookupList
						.add(AppConstants.KPI_RXCLOSED_URGENCY_LOOKBACK_DAYS);
			}
			if ((Boolean) request
					.getAttribute(AppConstants.KPI_RX_CLOSED_TYPE_ATTR)) {
				kpiDefaultLookupList
						.add(AppConstants.KPI_RXCLOSED_TYPE_DEFAULT_LOOKBACK_DAYS);
				kpiLookupList.add(AppConstants.KPI_RXCLOSED_TYPE_LOOKBACK_DAYS);
			}
			if ((Boolean) request
					.getAttribute(AppConstants.KPI_RX_ACCURACY_ATTR)) {
				kpiDefaultLookupList
						.add(AppConstants.KPI_RX_ACCURACY_DEFAULT_LOOKBACK_DAYS);
			}
			if ((Boolean) request.getAttribute(AppConstants.KPI_NTF_ATTR)) {
				kpiDefaultLookupList
						.add(AppConstants.KPI_NTF_DEFAULT_LOOKBACK_DAYS);
			}
			if ((Boolean) request
					.getAttribute(AppConstants.KPI_RESPONSE_TIME_ATTR)) {
				kpiDefaultLookupList
						.add(AppConstants.KPI_RESPONSE_TIME_DEFAULT_LOOKBACK_DAYS);
			}

			// number of days populated on the drop down
			noOfDaysForDropDowns = kpiService.getDaysFromLookUp(kpiLookupList);
			// numberOfDays is taken from lookup table
			final Map<String, Long> numberOfDaysMap = kpiService
					.findDefaultNumberOfDays(kpiDefaultLookupList);

			request.setAttribute(AppConstants.KPI_DEFAULT_LOOKBACK_DAYS,
					numberOfDaysMap);
			request.setAttribute(AppConstants.KPI_LOOKBACK_DAYS,
					noOfDaysForDropDowns);
			// fetch RxCount to be displayed in the KPI charts
			KPITotalCountResponseTypeVO rxDeliveredKpi = null, rxClosedByUrgencyKpi = null, rxClosedByTypeKPI = null, rxAccuracyKPI = null, ntfKPI = null, responseTimeKPI = null;
			final List<KPIBean> kpiList = new ArrayList<KPIBean>();
			List<KPITotalCountResponseTypeVO> responseList = null;
			KPITotalCountResponseTypeVO responseVO;
			if ((Boolean) request
					.getAttribute(AppConstants.KPI_RX_DELIVERED_ATTR)) {
				populateKPIList(
						AppConstants.RXDELIVERED,
						AppConstants.KPI_RXDELIVERED_URGENCY_DEFAULT_LOOKBACK_DAYS,
						numberOfDaysMap, kpiList);
			}
			if ((Boolean) request
					.getAttribute(AppConstants.KPI_RX_CLOSED_URGENCY_ATTR)) {
				populateKPIList(
						AppConstants.RX_CLOSEDBY_URGENCY,
						AppConstants.KPI_RXCLOSED_URGENCY_DEFAULT_LOOKBACK_DAYS,
						numberOfDaysMap, kpiList);
			}
			if ((Boolean) request
					.getAttribute(AppConstants.KPI_RX_CLOSED_TYPE_ATTR)) {
				populateKPIList(AppConstants.RX_CLOSEDBY_TYPE,
						AppConstants.KPI_RXCLOSED_TYPE_DEFAULT_LOOKBACK_DAYS,
						numberOfDaysMap, kpiList);
			}
			if ((Boolean) request
					.getAttribute(AppConstants.KPI_RX_ACCURACY_ATTR)) {
				populateKPIList(AppConstants.RX_ACCURACY,
						AppConstants.KPI_RX_ACCURACY_DEFAULT_LOOKBACK_DAYS,
						numberOfDaysMap, kpiList);
			}
			if ((Boolean) request.getAttribute(AppConstants.KPI_NTF_ATTR)) {
				populateKPIList(AppConstants.NO_TROUBLE_FOUND,
						AppConstants.KPI_NTF_DEFAULT_LOOKBACK_DAYS,
						numberOfDaysMap, kpiList);

			}
			if ((Boolean) request
					.getAttribute(AppConstants.KPI_RESPONSE_TIME_ATTR)) {
				populateKPIList(AppConstants.RESPONSE_TIME,
						AppConstants.KPI_RESPONSE_TIME_DEFAULT_LOOKBACK_DAYS,
						numberOfDaysMap, kpiList);
			}
			if (null != userVO.getProducts() && !userVO.getProducts().isEmpty()) {
				responseList = getKPIValues(kpiList, openCaseBean, userVO.getCustomerId());
			}
			if (null != responseList) {
				Iterator<KPITotalCountResponseTypeVO> it = responseList
						.iterator();
				while (it.hasNext()) {
				    responseVO = it.next();
					if (AppConstants.RXDELIVERED.equalsIgnoreCase(responseVO
							.getKpiName())) {
						rxDeliveredKpi = responseVO;
					} else if (AppConstants.RX_CLOSEDBY_URGENCY
							.equalsIgnoreCase(responseVO.getKpiName())) {
						rxClosedByUrgencyKpi = responseVO;
					} else if (AppConstants.RX_CLOSEDBY_TYPE
							.equalsIgnoreCase(responseVO.getKpiName())) {
						rxClosedByTypeKPI = responseVO;
					} else if (AppConstants.RX_ACCURACY
							.equalsIgnoreCase(responseVO.getKpiName())) {
						rxAccuracyKPI = responseVO;
						rxAccuracyNodata = false;
						responseVO.setIndex(3);
						lsKPIResponseTypes.add(responseVO);
					} else if (AppConstants.NO_TROUBLE_FOUND
							.equalsIgnoreCase(responseVO.getKpiName())) {
						ntfKPI = responseVO;
						ntfNodata = false;
						responseVO.setIndex(4);
						lsKPIResponseTypes.add(responseVO);
					} else if (AppConstants.RESPONSE_TIME
							.equalsIgnoreCase(responseVO.getKpiName())) {
						responseTimeKPI = responseVO;
						responseTimeNodata = false;
						responseVO.setIndex(5);
						lsKPIResponseTypes.add(responseVO);
					}

				}
			}

			String kpiCustInfoJson = getKpiCustomerInfoJSON(lsKPIResponseTypes,
					customerId);

			Map<String, String> jsonMap = getKPIPieChartData(rxDeliveredKpi,
					rxClosedByUrgencyKpi, rxClosedByTypeKPI, locale);
			getKPIColumnChartData(rxAccuracyKPI, ntfKPI, responseTimeKPI,
					model, locale);
			model.addAttribute(AppConstants.TOAL_RX_DELIVERED_JSON,
					jsonMap.get(AppConstants.TOAL_RX_DELIVERED_JSON));
			model.addAttribute(AppConstants.TOTAL_CLOSED_URGENCY_JSON,
					jsonMap.get(AppConstants.TOTAL_CLOSED_URGENCY_JSON));
			model.addAttribute(AppConstants.TOTAL_CLOSED_TYPE_JSON,
					jsonMap.get(AppConstants.TOTAL_CLOSED_TYPE_JSON));
			model.addAttribute(AppConstants.DELIVERED_RX_JSON,
					jsonMap.get(AppConstants.DELIVERED_RX_JSON));
			model.addAttribute(AppConstants.CLOSED_RX_JSON,
					jsonMap.get(AppConstants.CLOSED_RX_JSON));
			model.addAttribute(AppConstants.TYPE_RX_JSON,
					jsonMap.get(AppConstants.TYPE_RX_JSON));
			model.addAttribute(AppConstants.KPI_LIST, lstKPI);

			/*
			 * adding request attributes to identify whether each KPI has data
			 * or not
			 */

			model.addAttribute(AppConstants.KPI_RXACCURACY_NODATA,
					rxAccuracyNodata);
			model.addAttribute(AppConstants.KPI_NTF_NODATA, ntfNodata);
			model.addAttribute(AppConstants.KPI_RESPONSETIME_NODATA,
					responseTimeNodata);
			model.addAttribute(AppConstants.KPI_CUSTOMER_INFO, kpiCustInfoJson);
		} catch (Exception ex) {
			LOG.error("Exception occured in getKPIValues method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			RMDWebErrorHandler.handleException(ex);
		}
		LOG.debug("KPIController Controller : getKPIValues() method Ends");
		return new ModelAndView(AppConstants.VIEW_KPIS);
	}

	private List<ResourceVO> getOrderedKPIs(UserVO userVO) throws GenericAjaxException, RMDWebException {
		// TODO Auto-generated method stub
		List<ResourceVO> kpiList = new ArrayList<ResourceVO>();
		ResourceVO tempVO = null;
		try {
			tempVO = RMDCommonUtil.getPrivilegeType(userVO,
					AppConstants.KPI_RX_DELIVERED);
			if (null != tempVO) {
				tempVO.setResourceId(tempVO.getName());
				kpiList.add(tempVO);
			}
			tempVO = RMDCommonUtil.getPrivilegeType(userVO,
					AppConstants.KPI_RX_CLOSED_URGENCY);
			if (null != tempVO) {
				tempVO.setResourceId(tempVO.getName());
				kpiList.add(tempVO);
			}
			tempVO = RMDCommonUtil.getPrivilegeType(userVO,
					AppConstants.KPI_RX_CLOSED_TYPE);
			if (null != tempVO) {
				tempVO.setResourceId(tempVO.getName());
				kpiList.add(tempVO);
			}
			tempVO = RMDCommonUtil.getPrivilegeType(userVO,
					AppConstants.KPI_RX_ACCURACY);
			if (null != tempVO) {
				tempVO.setResourceId(tempVO.getName());
				kpiList.add(tempVO);
			}
			tempVO = RMDCommonUtil.getPrivilegeType(userVO,
					AppConstants.KPI_NTF);
			if (null != tempVO) {
				tempVO.setResourceId(tempVO.getName());
				kpiList.add(tempVO);
			}
			tempVO = RMDCommonUtil.getPrivilegeType(userVO,
					AppConstants.KPI_RESPONSE_TIME);
			if (null != tempVO) {
				tempVO.setResourceId(tempVO.getName());
				kpiList.add(tempVO);
			}
			 Collections.sort(kpiList, new Comparator() {
		          public int compare(Object o1, Object o2) {
		               return ((Comparable) ((ResourceVO) (o1)).getSortOrder())
		              .compareTo(((ResourceVO) (o2)).getSortOrder());
		          }
		     });
		} catch (Exception ex) {
			LOG.error("Exception occured in getOrderedKPI() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return kpiList;
	}

	/**
	 * Method to populate the values to kpi list
	 * 
	 */
	private void populateKPIList(String kpiName, String defaultDays,
			Map<String, Long> numberOfDaysMap, List<KPIBean> kpiList) {
		KPIBean kpiBean = new KPIBean();
		kpiBean.setKpiName(kpiName);
		kpiBean.setNumDays(numberOfDaysMap.get(defaultDays));
		kpiList.add(kpiBean);

	}
	/**
	 * Method to fetch RxCount to be displayed in the KPI charts
	 * 
	 * @param kpiNameList
	 * @param days
	 * @param openCaseBean
	 * @return
	 * @throws RMDWebException 
	 * @throws GenericAjaxException 
	 */
	private List<KPITotalCountResponseTypeVO> getKPIValues(
			final List<KPIBean> kpiList, final OpenCasesBean openCaseBean, final String userCustomer) throws GenericAjaxException, RMDWebException {
		List<KPITotalCountResponseTypeVO> kpiTotalCountResponseTypeVOList = null;
		try {
			kpiTotalCountResponseTypeVOList = kpiService.getRxKPIValues(
					kpiList, openCaseBean, userCustomer);
		} catch (Exception ex) {
			LOG.error("Exception occured in getKPIValues() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return kpiTotalCountResponseTypeVOList;
	}

	/**
	 * Method to fetch RxCount to be displayed in the KPI charts
	 * 
	 * @param kpiNameList
	 * @param days
	 * @param openCaseBean
	 * @return
	 * @throws RMDWebException 
	 * @throws GenericAjaxException 
	 */

	@RequestMapping(value = AppConstants.GET_KPI_VALUES, method = RequestMethod.GET)
	public @ResponseBody
	Map<String, String> getIndividualKpiValues(
			final HttpServletRequest request,
			@RequestParam(value = AppConstants.KPI_NAME, required = true) final String kpiName,
			@RequestParam(value = AppConstants.NO_OF_DAYS, required = true) final long noOfDays,
			final Locale locale) throws GenericAjaxException, RMDWebException {
		List<KPITotalCountResponseTypeVO> kpiTotalCountResponseTypeVOList = null;
		KPIBean kpiBean = new KPIBean();
		List<KPIBean> kpiList = new ArrayList<KPIBean>();
		final OpenCasesBean openCaseBean = new OpenCasesBean();
		KPITotalCountResponseTypeVO rxDeliveredKpi = null, rxClosedByUrgencyKpi = null, rxClosedByTypeKPI = null;
		Map<String, String> jsonMap = null;
		KPITotalCountResponseTypeVO responseVO;
		try {

			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			 /*For timezone issue */
			final String defaultTimezone = (String) request
					.getAttribute(AppConstants.DEFAULT_TIMEZONE);
			String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
					userVO.getTimeZone());
			/* For timezone issue */
			openCaseBean.setUserLanguage(userVO.getStrUserLanguage());
			openCaseBean.setTimeZone(applicationTimezone);
			openCaseBean.setTimeZoneCode(userVO.getTimeZoneCode());
			openCaseBean.setCustomerId(userVO.getCustomerId());
			if (null != userVO.getProducts() && !userVO.getProducts().isEmpty()) {
				openCaseBean.setProducts(userVO.getProducts());
			}
			kpiBean.setKpiName(kpiName);
			kpiBean.setNumDays(noOfDays);
			kpiList.add(kpiBean);
			kpiTotalCountResponseTypeVOList = kpiService.getRxKPIValues(
					kpiList, openCaseBean, userVO.getCustomerId());
			if (null != kpiTotalCountResponseTypeVOList) {
				Iterator<KPITotalCountResponseTypeVO> it = kpiTotalCountResponseTypeVOList
						.iterator();
				while (it.hasNext()) {
					responseVO = it.next();
					if (AppConstants.RXDELIVERED.equalsIgnoreCase(responseVO
							.getKpiName())) {
						rxDeliveredKpi = responseVO;
					} else if (AppConstants.RX_CLOSEDBY_URGENCY
							.equalsIgnoreCase(responseVO.getKpiName())) {
						rxClosedByUrgencyKpi = responseVO;
					} else if (AppConstants.RX_CLOSEDBY_TYPE
							.equalsIgnoreCase(responseVO.getKpiName())) {
						rxClosedByTypeKPI = responseVO;
					}
				}

				jsonMap = getKPIPieChartData(rxDeliveredKpi,
						rxClosedByUrgencyKpi, rxClosedByTypeKPI, locale);

			}

		} catch (Exception ex) {
			LOG.error("Exception occured in getKPIValues() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return jsonMap;
	}

	/**
	 * Preparing pie chart data from response
	 * 
	 * @param rxClosedByTypeKPI
	 * @param rxClosedByUrgencyKpi
	 * @param rxDeliveredKpi
	 * @param responseTimeKPI
	 * @param ntfKPI
	 * @param rxAccuracyKPI
	 * @return
	 * @throws RMDWebException 
	 * @throws GenericAjaxException 
	 */
	private Map<String, String> getKPIPieChartData(
			KPITotalCountResponseTypeVO rxDeliveredKpi,
			KPITotalCountResponseTypeVO rxClosedByUrgencyKpi,
			KPITotalCountResponseTypeVO rxClosedByTypeKPI, Locale locale) throws GenericAjaxException, RMDWebException {

		String kpiLabelColorRed = appContext.getMessage(
				AppConstants.KPI_LABEL_COLOR_RED, null, locale);
		String kpiLabelColorYellow = appContext.getMessage(
				AppConstants.KPI_LABEL_COLOR_YELLOW, null, locale);
		String kpiLabelColorWhite = appContext.getMessage(
				AppConstants.KPI_LABEL_COLOR_WHITE, null, locale);
		String kpiLabelColorBlue = appContext.getMessage(
				AppConstants.KPI_LABEL_COLOR_BLUE, null, locale);
		String kpiLabelColorConditional = appContext.getMessage(
				AppConstants.KPI_LABEL_COLOR_CONDITIONAL, null, locale);
		String kpiLabelColorOil = appContext.getMessage(
				AppConstants.KPI_LABEL_COLOR_OIL, null, locale);
		String kpiLabelRepaired = appContext.getMessage(
				AppConstants.KPI_LABEL_REPAIRED, null, locale);
		String kpiLabelDeferred = appContext.getMessage(
				AppConstants.KPI_LABEL_DEFFERED, null, locale);
		String kpiLabelNtf = appContext.getMessage(AppConstants.KPI_LABEL_NTF,
				null, locale);

		int totalRxDelivered = 0;
		int totalClosedUrgency = 0;
		int totalClosedType = 0;
		int otherCount = 0;

		Object[][] deliveredRx = { { 0, kpiLabelColorRed },
				{ 0, kpiLabelColorYellow }, { 0, kpiLabelColorWhite },
				{ 0, kpiLabelColorBlue }, { 0, kpiLabelColorConditional }, { 0, kpiLabelColorOil } };
		Object[][] closedRx = { { 0, kpiLabelColorRed },
				{ 0, kpiLabelColorYellow }, { 0, kpiLabelColorWhite },
				{ 0, kpiLabelColorBlue }, { 0, kpiLabelColorConditional }, { 0, kpiLabelColorOil } };
		Object[][] typeRx = { { 0, kpiLabelRepaired }, { 0, kpiLabelDeferred },
				{ 0, kpiLabelNtf } };
		Map<String, String> jsonMap = new HashMap<String, String>();
		try {
			if (null != rxDeliveredKpi
					&& null != rxDeliveredKpi.getTotalCount()
					&& !rxDeliveredKpi.getTotalCount().equals(
							AppConstants.EMPTY_STRING)) {
				totalRxDelivered = RMDCommonUtility
						.convertObjectToInt(rxDeliveredKpi.getTotalCount());
			}
			if (null != rxClosedByUrgencyKpi
					&& null != rxClosedByUrgencyKpi.getTotalCount()
					&& !rxClosedByUrgencyKpi.getTotalCount().equals(
							AppConstants.EMPTY_STRING)) {
				totalClosedUrgency = RMDCommonUtility
						.convertObjectToInt(rxClosedByUrgencyKpi
								.getTotalCount());
			}
			if (null != rxClosedByTypeKPI
					&& null != rxClosedByTypeKPI.getTotalCount()
					&& !rxClosedByTypeKPI.getTotalCount().equals(
							AppConstants.EMPTY_STRING)) {
				totalClosedType = RMDCommonUtility
						.convertObjectToInt(rxClosedByTypeKPI.getTotalCount());
			}

			// fetching values from rxDelivered
			if (null != rxDeliveredKpi
					&& RMDCommonUtility.isCollectionNotEmpty(rxDeliveredKpi
							.getParameter())) {
				for (KpiInfoTypeVO kpiInfoTypeVO : rxDeliveredKpi
						.getParameter()) {
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.LETTER_R)) {
						deliveredRx[0][0] = kpiInfoTypeVO.getParameterCount();
					}
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.LETTER_Y)) {
						deliveredRx[1][0] = kpiInfoTypeVO.getParameterCount();
					}
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.LETTER_W)) {
						deliveredRx[2][0] = kpiInfoTypeVO.getParameterCount();
					}
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.LETTER_B)) {
						deliveredRx[3][0] = kpiInfoTypeVO.getParameterCount();
					}
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.LETTER_C)) {
						deliveredRx[4][0] = kpiInfoTypeVO.getParameterCount();
					}
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.LETTER_O)) {
						deliveredRx[5][0] = kpiInfoTypeVO.getParameterCount();
					}
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.LETTER_G)) {
						totalRxDelivered = totalRxDelivered - kpiInfoTypeVO.getParameterCount();
					}
				}
			}
			otherCount = 0;
			if (null != rxClosedByUrgencyKpi
					&& RMDCommonUtility
							.isCollectionNotEmpty(rxClosedByUrgencyKpi
									.getParameter())) {
				for (KpiInfoTypeVO kpiInfoTypeVO : rxClosedByUrgencyKpi
						.getParameter()) {
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.LETTER_R)) {
						closedRx[0][0] = kpiInfoTypeVO.getParameterCount();
					}
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.LETTER_Y)) {
						closedRx[1][0] = kpiInfoTypeVO.getParameterCount();
					}
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.LETTER_W)) {
						closedRx[2][0] = kpiInfoTypeVO.getParameterCount();
					}
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.LETTER_B)) {
						closedRx[3][0] = kpiInfoTypeVO.getParameterCount();
					}
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.LETTER_C)) {
						closedRx[4][0] = kpiInfoTypeVO.getParameterCount();
					}
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.LETTER_O)) {
						closedRx[5][0] = kpiInfoTypeVO.getParameterCount();
					}
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.LETTER_G)) {
						totalClosedUrgency = totalClosedUrgency - kpiInfoTypeVO.getParameterCount();
					}
					
				}
			}
			if (null != rxClosedByTypeKPI
					&& null != rxClosedByTypeKPI.getParameter()) {
				for (KpiInfoTypeVO kpiInfoTypeVO : rxClosedByTypeKPI
						.getParameter()) {
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.DEFFERED)) {
						typeRx[1][0] = kpiInfoTypeVO.getParameterCount();
					}
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.REPAIRED)) {
						typeRx[0][0] = kpiInfoTypeVO.getParameterCount();
					}
					if (kpiInfoTypeVO.getParameterName().equals(
							AppConstants.NTF)) {
						typeRx[2][0] = kpiInfoTypeVO.getParameterCount();
					}

				}
			}

			String totalRxDeliveredJson = AppConstants.EMPTY_STRING, totalClosedUrgencyJson = AppConstants.EMPTY_STRING, totalClosedTypeJson = AppConstants.EMPTY_STRING, deliveredRxJson = AppConstants.EMPTY_STRING, closedRxJson = AppConstants.EMPTY_STRING, typeRxJson = AppConstants.EMPTY_STRING;

			ObjectMapper jsonMapper = new ObjectMapper();

			totalRxDeliveredJson = jsonMapper
					.writeValueAsString(totalRxDelivered);
			totalClosedUrgencyJson = jsonMapper
					.writeValueAsString(totalClosedUrgency);
			totalClosedTypeJson = jsonMapper
					.writeValueAsString(totalClosedType);
			deliveredRxJson = jsonMapper.writeValueAsString(deliveredRx);
			closedRxJson = jsonMapper.writeValueAsString(closedRx);
			typeRxJson = jsonMapper.writeValueAsString(typeRx);
			jsonMap.put(AppConstants.TOAL_RX_DELIVERED_JSON,
					totalRxDeliveredJson);
			jsonMap.put(AppConstants.TOTAL_CLOSED_URGENCY_JSON,
					totalClosedUrgencyJson);
			jsonMap.put(AppConstants.TOTAL_CLOSED_TYPE_JSON,
					totalClosedTypeJson);
			jsonMap.put(AppConstants.DELIVERED_RX_JSON, deliveredRxJson);
			jsonMap.put(AppConstants.CLOSED_RX_JSON, closedRxJson);
			jsonMap.put(AppConstants.TYPE_RX_JSON, typeRxJson);

		} catch (Exception ex) {
			LOG.error("Exception occured in getKPIChartData() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return jsonMap;
	}

	/**
	 * Preparing the json data for column chart from response
	 * 
	 * @param rxAccuracyKPI
	 * @param ntfKPI
	 * @param responseTimeKPI
	 * @param model
	 * @param locale
	 * @throws RMDWebException 
	 * @throws GenericAjaxException 
	 */
	private void getKPIColumnChartData(
			KPITotalCountResponseTypeVO rxAccuracyKPI,
			KPITotalCountResponseTypeVO ntfKPI,
			KPITotalCountResponseTypeVO responseTimeKPI, Model model,
			Locale locale) throws GenericAjaxException, RMDWebException {
		Object[] fourWeek = { 0, 0, 0 };
		Object[] previousQtr = { 0, 0, 0, };
		Object[] yearToDate = { 0, 0, 0 };
		Object[] lastdate = { 0, 0, 0 };
		Object[][] rxAccuracy = { { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
				{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
				{ "", 0 }, { "", 0 }, { "", 0 } };
		Object[][] ntf = { { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
				{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
				{ "", 0 }, { "", 0 }, { "", 0 } };
		Object[][] responseTime = { { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
				{ "", 0 }, { "", 0 }, { "", 0 }, { "", 0 }, { "", 0 },
				{ "", 0 }, { "", 0 }, { "", 0 } };
		DecimalFormat df2 = new DecimalFormat(AppConstants.DECIMAL_STRING);

		try {
			/*
			 * get customerId for each KPI. if user associated with all customer
			 * and KPI doesn't have no data then set customerId as NA
			 */

			if (null != rxAccuracyKPI
					&& null != rxAccuracyKPI.getLastUpdatedDate()
					&& !rxAccuracyKPI.getLastUpdatedDate().equals(
							AppConstants.EMPTY_STRING)) {
				lastdate[0] = rxAccuracyKPI.getLastUpdatedDate();

			}
			if (null != ntfKPI
					&& null != ntfKPI.getLastUpdatedDate()
					&& !ntfKPI.getLastUpdatedDate().equals(
							AppConstants.EMPTY_STRING)) {

				lastdate[1] = ntfKPI.getLastUpdatedDate();

			}
			if (null != responseTimeKPI
					&& null != responseTimeKPI.getLastUpdatedDate()
					&& !responseTimeKPI.getLastUpdatedDate().equals(
							AppConstants.EMPTY_STRING)) {
				lastdate[2] = responseTimeKPI.getLastUpdatedDate();
			}

			// accuracy, ntf and response time kpis
			// Last 4 week Average
			if (null != rxAccuracyKPI
					&& null != rxAccuracyKPI.getLastFourWeekAvg()
					&& !rxAccuracyKPI.getLastFourWeekAvg().equals(
							AppConstants.EMPTY_STRING)) {
				fourWeek[0] = rxAccuracyKPI.getLastFourWeekAvg();
				if (!fourWeek[0].equals(RMDCommonConstants.N_A)) {
					fourWeek[0] = Double.valueOf(df2.format(Double
							.parseDouble(fourWeek[0].toString())));
				}
			}
			if (null != ntfKPI
					&& null != ntfKPI.getLastFourWeekAvg()
					&& !ntfKPI.getLastFourWeekAvg().equals(
							AppConstants.EMPTY_STRING)) {
				fourWeek[1] = ntfKPI.getLastFourWeekAvg();
				if (!fourWeek[1].equals(RMDCommonConstants.N_A)) {
					fourWeek[1] = Double.valueOf(df2.format(Double
							.parseDouble(fourWeek[1].toString())));
				}
			}
			if (null != responseTimeKPI
					&& null != responseTimeKPI.getLastFourWeekAvg()
					&& !responseTimeKPI.getLastFourWeekAvg().equals(
							AppConstants.EMPTY_STRING)) {
				fourWeek[2] = responseTimeKPI.getLastFourWeekAvg();
				if (!fourWeek[2].equals(RMDCommonConstants.N_A)) {
					fourWeek[2] = Double.valueOf(df2.format(Double
							.parseDouble(fourWeek[2].toString())));
				}
			}
			// Last quarter Average
			if (null != rxAccuracyKPI
					&& null != rxAccuracyKPI.getLastQuarterAvg()
					&& !rxAccuracyKPI.getLastQuarterAvg().equals(
							AppConstants.EMPTY_STRING)) {
				previousQtr[0] = rxAccuracyKPI.getLastQuarterAvg();
				if (!previousQtr[0].equals(RMDCommonConstants.N_A)) {
					previousQtr[0] = Double.valueOf(df2.format(Double
							.parseDouble(previousQtr[0].toString())));
				}
			}
			if (null != ntfKPI
					&& null != ntfKPI.getLastQuarterAvg()
					&& !ntfKPI.getLastQuarterAvg().equals(
							AppConstants.EMPTY_STRING)) {
				previousQtr[1] = ntfKPI.getLastQuarterAvg();
				if (!previousQtr[1].equals(RMDCommonConstants.N_A)) {
					previousQtr[1] = Double.valueOf(df2.format(Double
							.parseDouble(previousQtr[1].toString())));
				}
			}
			if (null != responseTimeKPI
					&& null != responseTimeKPI.getLastQuarterAvg()
					&& !responseTimeKPI.getLastQuarterAvg().equals(
							AppConstants.EMPTY_STRING)) {
				previousQtr[2] = responseTimeKPI.getLastQuarterAvg();
				if (!previousQtr[2].equals(RMDCommonConstants.N_A)) {
					previousQtr[2] = Double.valueOf(df2.format(Double
							.parseDouble(previousQtr[2].toString())));
				}
			}
			// Current year Average
			if (null != rxAccuracyKPI
					&& null != rxAccuracyKPI.getCurrentYearAvg()
					&& !rxAccuracyKPI.getCurrentYearAvg().equals(
							AppConstants.EMPTY_STRING)) {
				yearToDate[0] = rxAccuracyKPI.getCurrentYearAvg();
				if (!yearToDate[0].equals(RMDCommonConstants.N_A)) {
					yearToDate[0] = Double.valueOf(df2.format(Double
							.parseDouble(yearToDate[0].toString())));
				}
			}
			if (null != ntfKPI
					&& null != ntfKPI.getCurrentYearAvg()
					&& !ntfKPI.getCurrentYearAvg().equals(
							AppConstants.EMPTY_STRING)) {
				yearToDate[1] = ntfKPI.getCurrentYearAvg();
				if (!yearToDate[1].equals(RMDCommonConstants.N_A)) {
					yearToDate[1] = Double.valueOf(df2.format(Double
							.parseDouble(yearToDate[1].toString())));
				}
			}
			if (null != responseTimeKPI
					&& null != responseTimeKPI.getCurrentYearAvg()
					&& !responseTimeKPI.getCurrentYearAvg().equals(
							AppConstants.EMPTY_STRING)) {
				yearToDate[2] = responseTimeKPI.getCurrentYearAvg();
				if (!yearToDate[2].equals(RMDCommonConstants.N_A)) {
					yearToDate[2] = Double.valueOf(df2.format(Double
							.parseDouble(yearToDate[2].toString())));
				}
			}
			int count = 0;
			// Monthly Average For RX Accuracy
			if (null != rxAccuracyKPI
					&& RMDCommonUtility.isCollectionNotEmpty(rxAccuracyKPI
							.getParameter())) {
				for (KpiInfoTypeVO kpiInfoTypeVO : rxAccuracyKPI.getParameter()) {
					rxAccuracy[count][0] = kpiInfoTypeVO.getParameterName();
					rxAccuracy[count][1] = kpiInfoTypeVO.getPercentage();
					if (!kpiInfoTypeVO.getPercentage().equals(
							RMDCommonConstants.N_A)) {
						rxAccuracy[count][1] = (Double.valueOf(df2
								.format(Double.parseDouble(kpiInfoTypeVO
										.getPercentage()))));
					}
					count++;
				}
			} else {
				rxAccuracy = null;
			}
			// Monthly Average For No Trouble Found
			count = 0;
			if (null != ntfKPI
					&& RMDCommonUtility.isCollectionNotEmpty(ntfKPI
							.getParameter())) {
				for (KpiInfoTypeVO kpiInfoTypeVONTF : ntfKPI.getParameter()) {
					ntf[count][0] = kpiInfoTypeVONTF.getParameterName();
					ntf[count][1] = kpiInfoTypeVONTF.getPercentage();
					if (!kpiInfoTypeVONTF.getPercentage().equals(
							RMDCommonConstants.N_A)) {
						ntf[count][1] = (Double
								.valueOf(df2.format(Double
										.parseDouble(kpiInfoTypeVONTF
												.getPercentage()))));
					}
					count++;
				}
			} else {
				ntf = null;
			}
			// Monthly Average For Response Time
			count = 0;
			if (null != responseTimeKPI
					&& RMDCommonUtility.isCollectionNotEmpty(responseTimeKPI
							.getParameter())) {
				for (KpiInfoTypeVO kpiInfoTypeVORT : responseTimeKPI
						.getParameter()) {
					responseTime[count][0] = kpiInfoTypeVORT.getParameterName();
					responseTime[count][1] = kpiInfoTypeVORT.getPercentage();
					if (!kpiInfoTypeVORT.getPercentage().equals(
							RMDCommonConstants.N_A)) {
						responseTime[count][1] = (Double.valueOf(df2
								.format(Double.parseDouble(kpiInfoTypeVORT
										.getPercentage()))));
					}
					count++;
				}
			} else {
				responseTime = null;
			}

			String fourWeekJson = AppConstants.EMPTY_STRING, previousQtrJson = AppConstants.EMPTY_STRING, yearToDateJson = AppConstants.EMPTY_STRING, accuracyJson = AppConstants.EMPTY_STRING, ntfJson = AppConstants.EMPTY_STRING, responseTimeJson = AppConstants.EMPTY_STRING, lastUpdatedDateJson = AppConstants.EMPTY_STRING;
			ObjectMapper jsonMapper = new ObjectMapper();
			fourWeekJson = jsonMapper.writeValueAsString(fourWeek);
			previousQtrJson = jsonMapper.writeValueAsString(previousQtr);
			yearToDateJson = jsonMapper.writeValueAsString(yearToDate);
			accuracyJson = jsonMapper.writeValueAsString(rxAccuracy);
			ntfJson = jsonMapper.writeValueAsString(ntf);
			responseTimeJson = jsonMapper.writeValueAsString(responseTime);
			lastUpdatedDateJson = jsonMapper.writeValueAsString(lastdate);
			model.addAttribute(AppConstants.FOUR_WEEK_JSON, fourWeekJson);
			model.addAttribute(AppConstants.PREVIOUS_QUARTER_JSON,
					previousQtrJson);
			model.addAttribute(AppConstants.YEAR_TO_DATE_JSON, yearToDateJson);
			model.addAttribute(AppConstants.RX_ACCURACY_JSON, accuracyJson);
			model.addAttribute(AppConstants.LAST_UPDATED_DATE_JSON,
					lastUpdatedDateJson);
			model.addAttribute(AppConstants.NTF_JSON, ntfJson);
			model.addAttribute(AppConstants.RESPONSE_TIME_JSON,
					responseTimeJson);

		} catch (Exception ex) {
			LOG.error("Exception occured in getKPIChartData() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
	}

	/*
	 * get customerId for each KPI. if user associated with all customer and KPI
	 * doesn't have no data then set customerId as NA the order of json is 0-Rx
	 * Delivered, 1-Rx closed urgency, 2-Rx closed type, 3-Rx Accuracy,
	 * 4-Response time, 5-NTF
	 */
	public String getKpiCustomerInfoJSON(
			List<KPITotalCountResponseTypeVO> lsKPIResponseTypes,
			String associatedCustomer) throws GenericAjaxException, RMDWebException {
		String[] kpiCustInfo = { associatedCustomer, associatedCustomer,
				associatedCustomer, RMDCommonConstants.N_A,
				RMDCommonConstants.N_A, RMDCommonConstants.N_A };
		String kpiCustInfoJson = AppConstants.EMPTY_STRING;
		ObjectMapper jsonMapper = new ObjectMapper();
		int idx = 0;
		try {
			if (RMDCommonUtility.isCollectionNotEmpty(lsKPIResponseTypes)) {
				for (KPITotalCountResponseTypeVO responseVO : lsKPIResponseTypes) {
					if (null != responseVO) {
						idx = responseVO.getIndex();

						if (idx != -1) {
							if (null != responseVO
									&& null != responseVO.getCustomerId()
									&& !responseVO.getCustomerId().equals(
											AppConstants.EMPTY_STRING)
									&& kpiCustInfo.length >= idx) {
								kpiCustInfo[idx] = responseVO.getCustomerId();
							}

						}
					}
				}
			}

			for (int i = 0; i < kpiCustInfo.length; i++) {

				if (null != kpiCustInfo[i]
						&& kpiCustInfo[i]
								.equalsIgnoreCase(RMDCommonConstants.N_A)
						&& !associatedCustomer
								.equalsIgnoreCase(RMDCommonConstants.ALL_CUSTOMER)) {
					kpiCustInfo[i] = associatedCustomer;
				}
			}

			kpiCustInfoJson = jsonMapper.writeValueAsString(kpiCustInfo);
		} catch (Exception ex) {
			LOG.error("Exception occured in getKpiCustomerInfoJSON() method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return kpiCustInfoJson;
	}

}
