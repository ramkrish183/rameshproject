package com.ge.trans.rmd.cm.valueobjects;



/*******************************************************************************
*
* @Author 		:  
* @Version 	: 1.0
* @Date Created: June 22 2016
* @Date Modified : 
* @Modified By : 
* @Contact 	:
* @Description : 
* @History		:
*
******************************************************************************/
public class LDVRGeofenceVO {
	
	private String geozoneObjid;
	private String geozoneId;
	private String geozoneName;
	private String assetOwnerId;
	private double lattitude1;
	private double longitude1;
	private double lattitude3;
	private double longitude3;
	private String obsolete;
	private String active;
	private String geozoneStatus;
		
	public String getGeozoneObjid() {
		return geozoneObjid;
	}
	public void setGeozoneObjid(String geozoneObjid) {
		this.geozoneObjid = geozoneObjid;
	}
	public String getGeozoneId() {
		return geozoneId;
	}
	public void setGeozoneId(String geozoneId) {
		this.geozoneId = geozoneId;
	}
	public String getGeozoneName() {
		return geozoneName;
	}
	public void setGeozoneName(String geozoneName) {
		this.geozoneName = geozoneName;
	}
	public String getAssetOwnerId() {
		return assetOwnerId;
	}
	public void setAssetOwnerId(String assetOwnerId) {
		this.assetOwnerId = assetOwnerId;
	}


	public double getLattitude1() {
		return lattitude1;
	}
	public void setLattitude1(double lattitude1) {
		this.lattitude1 = lattitude1;
	}
	public double getLongitude1() {
		return longitude1;
	}
	public void setLongitude1(double longitude1) {
		this.longitude1 = longitude1;
	}
	public double getLattitude3() {
		return lattitude3;
	}
	public void setLattitude3(double lattitude3) {
		this.lattitude3 = lattitude3;
	}
	public double getLongitude3() {
		return longitude3;
	}
	public void setLongitude3(double longitude3) {
		this.longitude3 = longitude3;
	}
	public void setLongitude3(long longitude3) {
		this.longitude3 = longitude3;
	}
	public String getObsolete() {
		return obsolete;
	}
	public void setObsolete(String obsolete) {
		this.obsolete = obsolete;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
	/**
	 * @return the geozoneStatus
	 */
	public String getGeozoneStatus() {
		return geozoneStatus;
	}
	/**
	 * @param geozoneStatus the geozoneStatus to set
	 */
	public void setGeozoneStatus(String geozoneStatus) {
		this.geozoneStatus = geozoneStatus;
	}
	
}


