package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.BOMConfigVO;
import com.ge.trans.rmd.cm.valueobjects.BOMMaintenanceVO;
import com.ge.trans.rmd.cm.valueobjects.MdscStartUpControllersVO;
import com.ge.trans.rmd.cm.valueobjects.VehicleCfgTemplateVO;
import com.ge.trans.rmd.cm.valueobjects.VehicleCfgVO;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.km.util.KMConstants;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.BOMRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.BOMResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.MdscStartUpControllersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.VehCfgTemplateRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.VehCfgTemplateResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.VehicleCfgRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.VehicleCfgResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseInfoType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class BOMServiceImpl extends RMDBaseServiceImpl implements BOMService {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	WebServiceInvoker webServiceInvoker;
	@Autowired
	private CachedService cachedService;

	@Override
	public Map<String, String> getConfigList() throws RMDWebException {

		BOMResponseType[] objBOMResponseType = null;
		Map<String, String> objBOMCfgVO = new HashMap<String, String>();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		BOMMaintenanceVO bOMMaintenanceVO = null;

		try {
			objBOMResponseType = (BOMResponseType[]) webServiceInvoker.get(
					ServiceConstants.GET_BOM_CONFIG_LIST, null, queryParams,
					null, BOMResponseType[].class);
			if (null != objBOMResponseType && objBOMResponseType.length > 0) {
				for (BOMResponseType bOMResponseType : objBOMResponseType) {
					objBOMCfgVO.put(bOMResponseType.getConfigList(),
							bOMResponseType.getObjid());

				}
			}
			objBOMResponseType = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getConfigList() method - BOMServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}

		return objBOMCfgVO;
	}

	@Override
	public List<BOMConfigVO> populateConfigDetails(String configId)
			throws RMDWebException {
		BOMResponseType[] objBOMResponseType = null;
		List<BOMConfigVO> objBOMConfigVO = new ArrayList<BOMConfigVO>();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		BOMConfigVO bOMConfigVO = null;
		try {
			queryParams.put(AppConstants.CONFIG_ID, configId);
			objBOMResponseType = (BOMResponseType[]) webServiceInvoker.get(
					ServiceConstants.POPULATE_BOM_CONFIG_DETAILS, null,
					queryParams, null, BOMResponseType[].class);
			if (null != objBOMResponseType && objBOMResponseType.length > 0) {
				objBOMConfigVO = new ArrayList<BOMConfigVO>(
						objBOMResponseType.length);
				for (BOMResponseType bOMResponseType : objBOMResponseType) {
					bOMConfigVO = new BOMConfigVO();
					bOMConfigVO.setConfigItem(bOMResponseType.getConfigItem());
					bOMConfigVO.setValue(ESAPI.encoder().decodeForHTML(
							bOMResponseType.getValue()));
					bOMConfigVO.setStatus(bOMResponseType.getStatus());
					bOMConfigVO.setObjid(bOMResponseType.getBomObjid());
					bOMConfigVO.setParameterObjid(bOMResponseType
							.getParameterObjid());
					bOMConfigVO.setParameterNumber(bOMResponseType
							.getParameterNumber());
					bOMConfigVO.setParameterDesc(bOMResponseType
							.getParameterDesc());
					bOMConfigVO.setNotificationFlag(bOMResponseType
							.getNotificationFlag());
					objBOMConfigVO.add(bOMConfigVO);
				}
			}
			objBOMResponseType = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in populateConfigDetails() method - BOMServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}

		return objBOMConfigVO;
	}

	@Override
	public Map<String, String> getConfigItemsList() throws RMDWebException {
		final Map<String, String> configItems = new HashMap<String, String>();
		String configItemName = null;
		String urgencyRepairName = null;
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();

		try {
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService
					.getAllLookupValues().get(AppConstants.CONFIGURATION_ITEM);
			if (applParamResponseTypeList != null
					&& applParamResponseTypeList.size() > 0) {

				for (ApplicationParametersResponseType objResponse : applParamResponseTypeList) {
					if (!(AppConstants.SPECIFY.equalsIgnoreCase(objResponse
							.getLookupValue()))) {
						configItemName = objResponse.getLookupValue();
						configItems.put(configItemName, configItemName);
					}
				}
			}
			applParamResponseTypeList = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getConfigItemsList() method - BOMServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return configItems;
	}

	@Override
	public Map<String, String> getParameterList(String configId)
			throws RMDWebException {
		BOMResponseType[] objBOMResponseType = null;
		Map<String, String> objBOMCfgVO = new HashMap<String, String>();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		BOMConfigVO bOMConfigVO = null;
		try {
			queryParams.put(AppConstants.CONFIG_ID, configId);
			objBOMCfgVO.put(AppConstants.ZERO,AppConstants.ZERO);
			objBOMResponseType = (BOMResponseType[]) webServiceInvoker.get(
					ServiceConstants.GET_PARAMETER_LIST, null, queryParams,
					null, BOMResponseType[].class);
			if (null != objBOMResponseType && objBOMResponseType.length > 0) {
				for (BOMResponseType bOMResponseType : objBOMResponseType) {
					objBOMCfgVO.put(bOMResponseType.getParameterNumber() + "-"
							+ bOMResponseType.getParameterDesc(),
							bOMResponseType.getParameterObjid());

				}
			}
			objBOMResponseType = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in populateConfigDetails() method - BOMServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}

		return objBOMCfgVO;
	}

	@Override
	public String saveBOMDetails(List<BOMConfigVO> bOMConfigVO)
			throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<BOMRequestType> bOMRequestType = new ArrayList<BOMRequestType>();
		BOMRequestType objBOMRequestTypeList = new BOMRequestType();
		BOMRequestType objBOMRequestType = null;
		try {

			for (BOMConfigVO objBOMConfigVO : bOMConfigVO) {
				objBOMRequestType = new BOMRequestType();

				if (!RMDCommonUtility.isNullOrEmpty(objBOMConfigVO.getAction())) {
					objBOMRequestType.setAction(objBOMConfigVO.getAction());
				} else {
					objBOMRequestType.setAction(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objBOMConfigVO
						.getConfigId())) {
					objBOMRequestType.setConfigId(objBOMConfigVO.getConfigId());
				} else {
					objBOMRequestType.setConfigId(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objBOMConfigVO
						.getConfigItem())) {
					objBOMRequestType.setConfigItem(objBOMConfigVO
							.getConfigItem());
				} else {
					objBOMRequestType.setConfigItem(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objBOMConfigVO.getObjid())) {
					objBOMRequestType.setObjid(objBOMConfigVO.getObjid());
				} else {
					objBOMRequestType.setObjid(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objBOMConfigVO
						.getParameterDesc())) {
					objBOMRequestType.setParameterDesc(objBOMConfigVO
							.getParameterDesc());
				} else {
					objBOMRequestType
							.setParameterDesc(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objBOMConfigVO
						.getParameterNumber())) {
					objBOMRequestType.setParameterNumber(objBOMConfigVO
							.getParameterNumber());
				} else {
					objBOMRequestType
							.setParameterNumber(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objBOMConfigVO
						.getParameterObjid())) {
					objBOMRequestType.setParameterObjid(objBOMConfigVO
							.getParameterObjid());
				} else {
					objBOMRequestType
							.setParameterObjid(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objBOMConfigVO.getStatus())) {
					objBOMRequestType.setStatus(objBOMConfigVO.getStatus());
				} else {
					objBOMRequestType.setStatus(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objBOMConfigVO.getValue())) {
					objBOMRequestType.setValue(ESAPI.encoder().encodeForXML(
							objBOMConfigVO.getValue()));
				} else {
					objBOMRequestType.setValue(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objBOMConfigVO
						.getUserName())) {
					objBOMRequestType.setUserName(objBOMConfigVO.getUserName());
				} else {
					objBOMRequestType.setUserName(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objBOMConfigVO
						.getNotificationFlag())) {
					objBOMRequestType.setNotificationFlag(objBOMConfigVO
							.getNotificationFlag());
				} else {
					objBOMRequestType.setNotificationFlag(AppConstants.EMPTY_STRING);
				}
				bOMRequestType.add(objBOMRequestType);
			}
			objBOMRequestTypeList.setArlBOMRequestType(bOMRequestType);
			status = (String) webServiceInvoker.post(
					ServiceConstants.UPDATE_BOM_CFG_ITEMS,
					objBOMRequestTypeList, String.class);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("Exception occured in saveVehicleBOMConfigs method  method of VehicleCfgServiceImpl ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return status;
	}

}
