package com.ge.trans.rmd.cm.valueobjects;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.ge.trans.rmd.cm.mvc.model.HeatMap;
import com.ge.trans.rmd.cm.mvc.model.ColModel;
import com.ge.trans.rmd.common.vo.RMDBaseVO;
import com.ge.trans.rmd.services.assets.valueobjects.FaultDataDetailsResponseType;

@SuppressWarnings("serial")
public class AssetDataResponseVO extends RMDBaseVO{

	private String page;
	private String total;
	private String defaultFromDt;
	private String defaultToDt;
	private String defaultNoOfDays;
	private String maxDateRange;
	private String partStatus;
	private String controllerCfg;
	private String caseDefaultDays;
	private String caseDefaultSortOrder;
	private String recordsTotal;
	private HeatMap[] heatMapData;
	private String records;
	private List<Map<String,String>> rows;
	private List<ColModel> colModel;	
	private List<String> colHeader;
	private List<String> noOfDaysList;
	private Map<String,String> grupCounts;
	private Map<String,String> groupColors = new HashMap<String, String>();
	private List<String> groupNames=null;
	private FaultDataDetailsResponseType responseObject = null;
	private List<Map<String,String>> lsFaultAssetValuePart = null;
	private String assetNumber;
	private String assetTabId;
	private String oilCase;
	private String flagFAM;
	private String linkFAM;
	private Map<String,String> errorMsgs;
	private boolean heatMapEnabled;
	
	public String getFlagFAM() {
		return flagFAM;
	}

	public void setFlagFAM(String flagFAM) {
		this.flagFAM = flagFAM;
	}

	public String getLinkFAM() {
		return linkFAM;
	}

	public void setLinkFAM(String linkFAM) {
		this.linkFAM = linkFAM;
	}

	public String getOilCase() {
		return oilCase;
	}

	public void setOilCase(String oilCase) {
		this.oilCase = oilCase;
	}

	public String getRecordsTotal() {
		return recordsTotal;
	}

	public void setRecordsTotal(String recordsTotal) {
		this.recordsTotal = recordsTotal;
	}

	public String getCaseDefaultDays() {
		return caseDefaultDays;
	}

	public void setCaseDefaultDays(String caseDefaultDays) {
		this.caseDefaultDays = caseDefaultDays;
	}

	public String getCaseDefaultSortOrder() {
		return caseDefaultSortOrder;
	}

	public void setCaseDefaultSortOrder(String caseDefaultSortOrder) {
		this.caseDefaultSortOrder = caseDefaultSortOrder;
	}

	public List<String> getNoOfDaysList() {
		return noOfDaysList;
	}

	public void setNoOfDaysList(List<String> noOfDaysList) {
		this.noOfDaysList = noOfDaysList;
	}

	public String getPartStatus() {
		return partStatus;
	}

	public void setPartStatus(String partStatus) {
		this.partStatus = partStatus;
	}

	public String getControllerCfg() {
		return controllerCfg;
	}

	public void setControllerCfg(String controllerCfg) {
		this.controllerCfg = controllerCfg;
	}

	public String getMaxDateRange() {
		return maxDateRange;
	}

	public void setMaxDateRange(String maxDateRange) {
		this.maxDateRange = maxDateRange;
	}

	public String getDefaultFromDt() {
		return defaultFromDt;
	}

	public void setDefaultFromDt(String defaultFromDt) {
		this.defaultFromDt = defaultFromDt;
	}

	public String getDefaultToDt() {
		return defaultToDt;
	}

	public void setDefaultToDt(String defaultToDt) {
		this.defaultToDt = defaultToDt;
	}

	public String getDefaultNoOfDays() {
		return defaultNoOfDays;
	}

	public void setDefaultNoOfDays(String defaultNoOfDays) {
		this.defaultNoOfDays = defaultNoOfDays;
	}

	public Map<String, String> getGroupColors() {
		return groupColors;
	}

	public void setGroupColors(Map<String, String> groupColors) {
		this.groupColors = groupColors;
	}

	public Map<String, String> getErrorMsgs() {
		return errorMsgs;
	}

	public void setErrorMsgs(final Map<String, String> errorMsgs) {
		this.errorMsgs = errorMsgs;
	}

	//adding for multiple customers
	private String customerId;
	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(final String customerId) {
		this.customerId = customerId;
	}

	public String getAssetGrpName() {
		return assetGrpName;
	}

	public void setAssetGrpName(final String assetGrpName) {
		this.assetGrpName = assetGrpName;
	}

	private String assetGrpName;
	
	public HeatMap[] getHeatMapData() {
		return heatMapData;
	}

	public void setHeatMapData(final HeatMap[] heatMapData) {
		this.heatMapData = heatMapData;
	}

	public FaultDataDetailsResponseType getResponseObject() {
		return responseObject;
	}
	
	public void setResponseObject(final FaultDataDetailsResponseType responseObject) {
		this.responseObject = responseObject;
	}
	
	public List<Map<String, String>> getLsFaultAssetValuePart() {
		return lsFaultAssetValuePart;
	}
	
	public void setLsFaultAssetValuePart(
			final List<Map<String, String>> lsFaultAssetValuePart) {
		this.lsFaultAssetValuePart = lsFaultAssetValuePart;
	}
	
	private ArrayList<ArrayList<ArrayList<Number>>> colData;
	

	public ArrayList<ArrayList<ArrayList<Number>>> getColData() {
		return colData;
	}

	public void setColData(final ArrayList<ArrayList<ArrayList<Number>>> colData) {
		this.colData = colData;
	}

	public List<String> getGroupNames() {
		return groupNames;
	}

	public void setGroupNames(final List<String> groupNames) {
		this.groupNames = groupNames;
	}
	
	public Map<String, String> getGrupCounts() {
		return grupCounts;
	}

	public void setGrupCounts(final Map<String, String> grupCounts) {
		this.grupCounts = grupCounts;
	}
	
	public List<ColModel> getColModel() {
		return colModel;
	}

	public void setColModel(final List<ColModel> colModel) {
		this.colModel = colModel;
	}

	public List<String> getColHeader() {
		return colHeader;
	}

	public void setColHeader(final List<String> colHeader) {
		this.colHeader = colHeader;
	}
	
	public String getPage() {
		return page;
	}

	public void setPage(final String page) {
		this.page = page;
	}

	public String getTotal() {
		return total;
	}

	public void setTotal(final String total) {
		this.total = total;
	}

	public String getRecords() {
		return records;
	}

	public void setRecords(final String records) {
		this.records = records;
	}

	public List<Map<String,String>>  getRows() {
		return rows;
	}

	public void setRows(final List<Map<String,String>>  rows) {
		this.rows = rows;
	}

	public String getAssetNumber() {
		return assetNumber;
	}

	public void setAssetNumber(final String assetNumber) {
		this.assetNumber = assetNumber;
	}

	public String getAssetTabId() {
		return assetTabId;
	}

	public void setAssetTabId(final String assetTabId) {
		this.assetTabId = assetTabId;
	}
	
	public boolean isHeatMapEnabled() {
		return heatMapEnabled;
	}

	public void setHeatMapEnabled(boolean heatMapEnabled) {
		this.heatMapEnabled = heatMapEnabled;
	}

}
