package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.common.beans.GpocNotesBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.vo.GenNotesVO;
import com.ge.trans.rmd.exception.RMDServiceException;
import com.ge.trans.rmd.services.gpocnotes.valueobjects.GeneralNotesRequestType;
import com.ge.trans.rmd.services.gpocnotes.valueobjects.GeneralNotesResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class CommNotesServiceImpl extends RMDBaseServiceImpl implements CommNotesService {
	
	@Autowired
	private CachedService cachedService;
	@Autowired
	private WebServiceInvoker rsInvoker;

	private final RMDWebLogger logger = RMDWebLogger.getLogger(getClass());
	@Override
	public String addCommNotes(GpocNotesBean gpocNotesBean)
			throws GenericAjaxException, RMDWebException {
		String status = null;
		GeneralNotesRequestType requestObj = null;
		try {

			if (null != gpocNotesBean) {
				requestObj = new GeneralNotesRequestType();

				requestObj.setNotesdesc(gpocNotesBean.getNotesdesc());
				requestObj.setEnteredby(gpocNotesBean.getEnteredby());
				requestObj.setVisibilityFlag(gpocNotesBean.getVisibilityFlag());
				

				status = (String) (rsInvoker.post(
						ServiceConstants.ADD_COMM_NOTES_GPOC, requestObj,
						String.class));	
			}

		} catch (Exception e) {
			logger.error(
					"Exception occured in addCommNotes in CommNotesServiceImpl",
					e);
			RMDWebErrorHandler.handleException(e);
		}
		return status;
	}

	@Override
	public List<GenNotesVO> showAllCommNotes(GpocNotesBean gpocNotesBean,
			String userTimeZone) throws RMDWebException, Exception {
		
		
		GeneralNotesResponseType[] arGeneralNotesResponseType = null;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		final Map<String, String> headerParams = getHeaderMap(gpocNotesBean);
		final List<GenNotesVO> commnotesVOLst = new ArrayList<GenNotesVO>();
		GenNotesVO gnVO = null;
		final DateFormat nonESTZoneFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		Date updatedOn = null;
		
		try {
			
			arGeneralNotesResponseType = (GeneralNotesResponseType[]) rsInvoker
					.get(ServiceConstants.GET_All_COMM_NOTES,null,queryParams,headerParams,
							GeneralNotesResponseType[].class);

				if (arGeneralNotesResponseType != null && arGeneralNotesResponseType.length > 0) {
					for (GeneralNotesResponseType gnRespType : arGeneralNotesResponseType) {
						gnVO = new GenNotesVO();
						gnVO.setGetnotesSeqId(gnRespType.getCommnotesSeqId());
						gnVO.setNotesdesc(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(gnRespType.getNotesdesc())));
						gnVO.setEnteredby(gnRespType.getEnteredby());
			
					    if (userTimeZone.equals(AppConstants.EST_TIMEZONE)) {
					    	gnVO.setLastUpdatedTime(gnRespType.getLastUpdatedTime());	
						} else {
							updatedOn = RMDCommonUtility.stringToUSESTDate(
									gnRespType.getLastUpdatedTime(),
									RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
							gnVO.setLastUpdatedTime(nonESTZoneFormat
									.format(updatedOn));
						}	
					    gnVO.setVisibilityFlag(gnRespType.getVisibilityFlag());
						commnotesVOLst.add(gnVO);
					}
				}
			} catch (Exception ex) {
				logger.error("Exception occured in showAll method ", ex);
				RMDWebErrorHandler.handleException(ex);

			}
			logger.debug("UserManagementServiceImpl : showAll() method Ends");
			return commnotesVOLst;
		}

	@Override
	public String removeCommNotes(List<GenNotesVO> commnotesvo)
			throws RMDServiceException, Exception {
		String status = AppConstants.FAILURE;
		List<GeneralNotesRequestType> lstGeneralNotesRequestType = new ArrayList<GeneralNotesRequestType>();
		GeneralNotesRequestType reqobj = new GeneralNotesRequestType();
		GeneralNotesRequestType generalNotesRequestType = null;
		try {

			for (GenNotesVO objGenNotesVO : commnotesvo) {
				generalNotesRequestType = new GeneralNotesRequestType();

				if (!RMDCommonUtility.isNull(Long.toString(objGenNotesVO.getGetnotesSeqId()))) {
					generalNotesRequestType.setGetnotesSeqId(objGenNotesVO.getGetnotesSeqId());
				} else {
					generalNotesRequestType.setGetnotesSeqId(AppConstants.INACTIVE_STATE);
				}
				lstGeneralNotesRequestType.add(generalNotesRequestType);
			}
			reqobj.setArlGeneralNotesRequestType(lstGeneralNotesRequestType);
			status = (String) rsInvoker.post(
					ServiceConstants.REMOVE_COMM_NOTES, reqobj,
					String.class);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			logger
					.error("Exception occured in removeCommNotes method  method ofCommNotesServiceImpl.java ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return status;
	}

}
