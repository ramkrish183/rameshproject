/**
 * ============================================================
 * Classification: GE Confidential
 * File 			: RepairCodeVO.java
 * Description 		: Value Object for repair code details  
 * Package 			:  com.ge.trans.rmd.cm.valueobjects
 * Author 			: 
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		: 
 * History
 * Modified By 		: Initial Release
 * Copyright (C) 2012 General Electric Company. All rights reserved
 * ============================================================
 */
package com.ge.trans.rmd.cm.valueobjects;
/*******************************************************************************
*
* @Author 		:
* @Version 	    : 1.0
* @Date Created : 
* @Date Modified:
* @Modified By  :
* @Contact 	    :
* @Description  :This is plain POJO class which contains repaircode Id,desc,count.
 *             	 Declarations along with their respective getters and setters.
* @History		:
*
******************************************************************************/
public class RepairCodeVO {
	private String repairCode;
	private String repairDesc;
	private String noOfCases;
	private String status;
	private String models;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getModels() {
		return models;
	}
	public void setModels(String models) {
		this.models = models;
	}
	public String getRepairCode() {
		return repairCode;
	}
	public void setRepairCode(String repairCode) {
		this.repairCode = repairCode;
	}
	public String getRepairDesc() {
		return repairDesc;
	}
	public void setRepairDesc(String repairDesc) {
		this.repairDesc = repairDesc;
	}
	public String getNoOfCases() {
		return noOfCases;
	}
	public void setNoOfCases(String noOfCases) {
		this.noOfCases = noOfCases;
	}
	
}
