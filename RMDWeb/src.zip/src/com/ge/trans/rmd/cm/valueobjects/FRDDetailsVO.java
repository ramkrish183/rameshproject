package com.ge.trans.rmd.cm.valueobjects;

public class FRDDetailsVO {
	
	private String preValue;
	private String postValue;
	private String biasValue;
	public String getPreValue() {
		return preValue;
	}
	public void setPreValue(String preValue) {
		this.preValue = preValue;
	}
	public String getPostValue() {
		return postValue;
	}
	public void setPostValue(String postValue) {
		this.postValue = postValue;
	}
	public String getBiasValue() {
		return biasValue;
	}
	public void setBiasValue(String biasValue) {
		this.biasValue = biasValue;
	}

}
