/**
 * ============================================================
 * File : QueueListController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.cm.mvc.controller
 * Author : GE Transportation
 * Last Edited By :
 * Version : 1.0
 * Created on : Apr 16, 2015
 * History
 * Modified By : Initial Release
 * Classification : GE Sensitive
 * Copyright (C) 2015 General Electric Company. All rights reserved
 *
 * ============================================================
 */

package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.QueueCasesService;
import com.ge.trans.rmd.cm.valueobjects.OpenCasesVO;
import com.ge.trans.rmd.cm.valueobjects.QueueCaseVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.common.vo.CustomerVO;

@Controller
public class QueueCaseListController extends RMDBaseController {
	
	@Autowired
	private QueueCasesService queueCasesService;

	
	@Autowired
	private ApplicationContext appContext;
	
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	
	/**
	 * @Author:
	 * @param:HttpServletRequest request
	 * @return:ModelAndView
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching list of Queues by calling
	 *               getQueueList() method in QueueCasesService.java
	 */

	@RequestMapping(AppConstants.REQ_URI_QUEUELIST)
	public ModelAndView getQueueList(final HttpServletRequest request)
			throws RMDWebException {
		List<QueueCaseVO> lstQueueCaseVO = null;
		try {
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			lstQueueCaseVO = queueCasesService.getQueueList(userVO.getRoleId().toString());

			if (lstQueueCaseVO != null) {
				request.setAttribute(AppConstants.QUEUE_VO_LST, lstQueueCaseVO);
			}
			
			request.setAttribute(
					AppConstants.QUEUES_DEFAULT_RECORDS,
					findNumberOfRecords(AppConstants.QUEUES_TABLE_DEFAULT_RECORDS));
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getQueueList() method ", rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getQueueList() method ");
			RMDWebErrorHandler.handleException(ex);
		}
		return new ModelAndView(AppConstants.VIEW_QUEUECASES);
	}

	/**
	 * @Author:
	 * @param:HttpServletRequest reques
	 * @return:List<QueueCaseVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching list of Cases Associated
	 *               to particular Queue by calling getQueueCases() method in
	 *               QueueCasesService.java
	 */

	@RequestMapping(AppConstants.REQ_URI_QUEUECASE)
	public @ResponseBody
	List<QueueCaseVO> getQueueCases(final HttpServletRequest request)
			throws RMDWebException, Exception {
		List<QueueCaseVO> lstQueueCaseVO = null;
		String customerList = "";
		final String defaultTimezone = (String) request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		try {
			final String queueobjid = request
					.getParameter(AppConstants.QUEUE_OBJ_ID);
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			if (!RMDCommonUtility.isNullOrEmpty(userVO.getCustomerId())) {
				customerList = getCustomerList(userVO.getCustomerList());
				userVO.setCustomerId(customerList);
			}
			lstQueueCaseVO = queueCasesService.getQueueCases(queueobjid,
					userVO.getCustomerId(), userVO.getTimeZone(), defaultTimezone);
			if (lstQueueCaseVO != null) {
				request.setAttribute(AppConstants.QUEUE_VO_CASES,
						lstQueueCaseVO);
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getQueueCases() method ",
							rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getQueueCases method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		}
		return lstQueueCaseVO;
	}


	
	/**
	 * @Author:
	 * @param:HttpServletRequest reques
	 * @return:List<QueueCaseVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for exporting Queue Cases to CSV
	 *               Format.
	 */

	@RequestMapping(AppConstants.EXPORT_QUEUE_CASES)
	public @ResponseBody
	void exportQueueCases(final HttpServletRequest request,final HttpServletResponse response,final Locale locale)
			throws RMDWebException, Exception {
		List<QueueCaseVO> lstQueueCaseVO = null;
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		String customerList="";
		final String defaultTimezone = (String) request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		try {
			final String queueobjid = request
					.getParameter(AppConstants.QUEUE_OBJ_ID);
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			if (!RMDCommonUtility.isNullOrEmpty(userVO.getCustomerId())) {
				customerList = getCustomerList(userVO.getCustomerList());
				userVO.setCustomerId(customerList);
			}
			lstQueueCaseVO = queueCasesService.getQueueCases(queueobjid,
					userVO.getCustomerId(), userVO.getTimeZone(), defaultTimezone);
			if (lstQueueCaseVO != null) {
				request.setAttribute(AppConstants.QUEUE_VO_CASES,
						lstQueueCaseVO);
			}
			csvContent = convertToCSVQueueCases(lstQueueCaseVO, locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.QUEUE_CASES_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);
			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);
			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getQueueCases() method ",
							rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getQueueCases method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		}
		finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}
		
	}

	
	/**
	 * @Description:This method is used convert Queue cases into csv format
	 * @return: String
	 * @param:List<QueueCaseVO> queuCasesList, Locale locale
	 */
	private String convertToCSVQueueCases(List<QueueCaseVO> queuCasesList,
			Locale locale) {
		String csvContent = null;
		StringBuffer strBufferAssetHeader = new StringBuffer();
		try {
			strBufferAssetHeader.append(appContext.getMessage(
					AppConstants.QUEUE_CASES_HEADER, null, locale));
			strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			for (QueueCaseVO queueCases : queuCasesList) {
				strBufferAssetHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE + queueCases.getCaseId()
						+ AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ queueCases.getCustomerId() + AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ queueCases.getVehHdr() + AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ queueCases.getSitepartSerialNo() + AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ queueCases.getTitle() + AppConstants.QUOTE);
				if (null != queueCases.getPriority()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ queueCases.getPriority()
									+ AppConstants.QUOTE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				strBufferAssetHeader.append(RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ queueCases.getSeverity() + AppConstants.QUOTE);
				if (null != queueCases.getAge()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ queueCases.getAge() + AppConstants.QUOTE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (null != queueCases.getCreationTime()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ queueCases.getCreationTime()
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (null != queueCases.getStatus()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ queueCases.getStatus()
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}

				strBufferAssetHeader.append(RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ queueCases.getCondition() + AppConstants.QUOTE);
				if (null != queueCases.getUserLoginName()
						&& !queueCases.getUserLoginName().equals(
								AppConstants.OWNER_UNASSIGNED)) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ queueCases.getUserLoginName()
									+ AppConstants.QUOTE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBufferAssetHeader.toString();
		} catch (Exception exception) {
			rmdWebLogger.error("Export to CSV Case List"
					+ exception.getMessage());
		}
		return csvContent;
	}
}
