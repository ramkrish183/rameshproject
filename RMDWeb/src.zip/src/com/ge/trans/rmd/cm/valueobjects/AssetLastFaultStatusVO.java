package com.ge.trans.rmd.cm.valueobjects;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.trans.rmd.common.vo.RMDBaseVO;
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class AssetLastFaultStatusVO extends RMDBaseVO{

	private String lstEOAFaultHeader;
	private String lstEOAFault;
	private String lstESTPDownloadHeader;
	private String lstESTPDownload;
	private String lstPPATSMsgHeader;
	private String lstPPATSMsg;
	private String services;
	private String nextScheduledRun;
	private String lastToolRun;
	private String lastRecord;	
	private Boolean showToolRun;
	
	public Boolean getShowToolRun() {
		return showToolRun;
	}
	public void setShowToolRun(Boolean showToolRun) {
		this.showToolRun = showToolRun;
	}
	public String getLastRecord() {
		return lastRecord;
	}
	public void setLastRecord(String lastRecord) {
		this.lastRecord = lastRecord;
	}
	public String getLastToolRun() {
		return lastToolRun;
	}
	public void setLastToolRun(String lastToolRun) {
		this.lastToolRun = lastToolRun;
	}
	public String getServices() {
		return services;
	}
	public void setServices(String services) {
		this.services = services;
	}
	public String getNextScheduledRun() {
		return nextScheduledRun;
	}
	public void setNextScheduledRun(String nextScheduledRun) {
		this.nextScheduledRun = nextScheduledRun;
	}
	private String lstFaultDateCell;
	
	public String getLstFaultDateCell() {
		return lstFaultDateCell;
	}
	public void setLstFaultDateCell(String lstFaultDateCell) {
		this.lstFaultDateCell = lstFaultDateCell;
	}
	public String getLstEOAFaultHeader() {
		return lstEOAFaultHeader;
	}
	public void setLstEOAFaultHeader(String lstEOAFaultHeader) {
		this.lstEOAFaultHeader = lstEOAFaultHeader;
	}
	public String getLstEOAFault() {
		return lstEOAFault;
	}
	public void setLstEOAFault(String lstEOAFault) {
		this.lstEOAFault = lstEOAFault;
	}
	public String getLstESTPDownloadHeader() {
		return lstESTPDownloadHeader;
	}
	public void setLstESTPDownloadHeader(String lstESTPDownloadHeader) {
		this.lstESTPDownloadHeader = lstESTPDownloadHeader;
	}
	public String getLstESTPDownload() {
		return lstESTPDownload;
	}
	public void setLstESTPDownload(String lstESTPDownload) {
		this.lstESTPDownload = lstESTPDownload;
	}
	public String getLstPPATSMsgHeader() {
		return lstPPATSMsgHeader;
	}
	public void setLstPPATSMsgHeader(String lstPPATSMsgHeader) {
		this.lstPPATSMsgHeader = lstPPATSMsgHeader;
	}
	public String getLstPPATSMsg() {
		return lstPPATSMsg;
	}
	public void setLstPPATSMsg(String lstPPATSMsg) {
		this.lstPPATSMsg = lstPPATSMsg;
	}

	
}
