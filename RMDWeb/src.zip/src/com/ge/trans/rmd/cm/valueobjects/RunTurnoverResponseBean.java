package com.ge.trans.rmd.cm.valueobjects;

import com.ge.trans.rmd.common.valueobjects.BaseVO;

@SuppressWarnings("unchecked")
public class RunTurnoverResponseBean extends BaseVO {

	private static final long serialVersionUID = 1L;
	
	public InboundTurnoverReportBean inboundTurnoverReportBean;

	public InboundTurnoverReportBean getInboundTurnoverReportBean() {
		return inboundTurnoverReportBean;
	}

	public void setInboundTurnoverReportBean(
			InboundTurnoverReportBean inboundTurnoverReportBean) {
		this.inboundTurnoverReportBean = inboundTurnoverReportBean;
	}

	
	
	
	
}
