package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

public class LDVRGeofenceResponseVO {
	
	private List<LDVRGeofenceVO> ldvrGeoZones;
	private List<String> geoZoneIds;

	public List<LDVRGeofenceVO> getLdvrGeoZones() {
		return ldvrGeoZones;
	}

	public void setLdvrGeoZones(List<LDVRGeofenceVO> ldvrGeoZones) {
		this.ldvrGeoZones = ldvrGeoZones;
	}

	public List<String> getGeoZoneIds() {
		return geoZoneIds;
	}

	public void setGeoZoneIds(List<String> geoZoneIds) {
		this.geoZoneIds = geoZoneIds;
	}

}
