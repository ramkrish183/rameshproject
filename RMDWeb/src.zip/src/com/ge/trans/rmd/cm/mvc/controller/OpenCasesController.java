/**
 * ============================================================
 * File : OpenCasesController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.cm.mvc.controller
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Feb 22, 2012
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map.Entry;
import java.util.SortedSet;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.beans.OpenCasesBean;
import com.ge.trans.rmd.cm.service.OpenCasesService;
import com.ge.trans.rmd.cm.valueobjects.OpenCasesVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.common.vo.CustomerVO;
@Controller
public class OpenCasesController extends RMDBaseController {

	@Autowired
	OpenCasesService openCasesService;
	
	@Autowired
	private AuthorizationService authService;

	@Autowired
	private ApplicationContext appContext;

	@SuppressWarnings("unused")
	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	/**
	 * @Author:
	 * @return
	 * @Description: Displays the Open Cases page of the RMD application and
	 *               fetching data for open cases
	 */
	@RequestMapping(AppConstants.REQ_URI_CASES)
	public ModelAndView showCases(final HttpServletRequest request) throws RMDWebException {
		request.setAttribute(AppConstants.FILTERFLAG,
				EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG)));
		try {
			final String openCasesRefreshTime = authService
					.getLookUpValueForName(AppConstants.DWQ_CASES_REFRESH_TIME);
			request.setAttribute(AppConstants.OPENCASE_REFRESH_TIME,
					openCasesRefreshTime);
					final SortedSet<Entry<String, String>> mapDropdown = openCasesService
					.getDropDownValues();
					if (mapDropdown != null) {
				request.setAttribute(AppConstants.OPENCASES_DROPDOWN,
						mapDropdown);
				request.setAttribute(
						AppConstants.CASES_DEFAULT_RECORDS,
						findNumberOfRecords(AppConstants.CASES_TABLE_DEFAULT_RECORDS));
			}
		} catch (Exception e) {
			logger.error("In OpenCasesController : Exception occured in showCases() method "+e.getMessage(), e);
			
		}
		return new ModelAndView(AppConstants.VIEW_CASES);
	}

	/*
	 * This method is use for take the ownership for particular case.
	 */
	@RequestMapping(value = AppConstants.TAKEOWNERSHIP, method = RequestMethod.GET)
	public @ResponseBody
	String takeOwnerShip( @RequestParam(value = AppConstants.CASE_ID) String caseId,
			@RequestParam(value = AppConstants.CURRENT_OWNER) String currentOwner,final HttpServletRequest request)
			throws RMDWebException {
		String result = AppConstants.FAILURE;
		final OpenCasesBean openCaseBean = new OpenCasesBean();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			openCaseBean.setUserId(EsapiUtil.stripXSSCharacters(userVO.getUserId()));
			openCaseBean.setLanguage(EsapiUtil.stripXSSCharacters(userVO.getStrLanguage()));
			openCaseBean.setUserFirstName(EsapiUtil.stripXSSCharacters(userVO.getStrFirstName()));
			openCaseBean.setUserLastName(EsapiUtil.stripXSSCharacters(userVO.getStrLastName()));
			openCaseBean.setCaseId(EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.WS_PARAM_CASEID_2)));
			openCaseBean.setCurrentOwner(EsapiUtil.stripXSSCharacters(currentOwner));
			result = openCasesService.takeOwnerShip(openCaseBean);
			if (result.equals(AppConstants.SUCCESS)) {
				result = EsapiUtil.stripXSSCharacters(userVO.getUserId());
			}

		} catch (RMDWebException ex) {
			if (AppConstants.TAKE_OWNERSHIP_RTU_FAILED_CODE.equals(ex
					.getErrorCode())) {
				result = AppConstants.TAKE_OWNERSHIP_RTU_FAILED_CODE;
			} else {
				logger.error("Exception occured in takeOwnership method ", ex);
				RMDWebErrorHandler.handleException(ex);
			}
		} catch (Exception ex) {
			logger.error("Exception occured in takeOwnership method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	
	/*
	 * This method is used for real time check of the owner of the case from eoa and omd 
	 */
	@RequestMapping(value = AppConstants.FETCH_CURRENT_OWNERSHIP, method = RequestMethod.GET)
	public @ResponseBody
	String getCurrentOwnership( @RequestParam(value = AppConstants.CASE_ID) String caseId, HttpServletRequest request)
			throws RMDWebException {
		String result = AppConstants.FAILURE;
		final OpenCasesBean openCaseBean = new OpenCasesBean();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			openCaseBean.setUserId(userVO.getUserId());
			openCaseBean.setCaseId(EsapiUtil.stripXSSCharacters(caseId));
			openCaseBean.setCmAliasName(userVO.getCmAliasName());
			result = openCasesService.getCurrentOwnership(openCaseBean);
		} catch (Exception ex) {
			logger.error("Exception occured in takeOwnership method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return result;
	}
	
	/*
	 * This method is use for take the ownership for Close case.So case will
	 * re-open after assigning.
	 */
	@RequestMapping(value = AppConstants.REOPEN_CASE, method = RequestMethod.GET)
	public @ResponseBody
	String reopenCase(final HttpServletRequest request) throws RMDWebException {
		String result = AppConstants.FAILURE;
		final OpenCasesBean openCaseBean = new OpenCasesBean();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			openCaseBean.setUserId(EsapiUtil.stripXSSCharacters(userVO.getUserId()));
			openCaseBean.setLanguage(EsapiUtil.stripXSSCharacters(userVO.getStrLanguage()));
			openCaseBean.setCaseId(EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.WS_PARAM_CASEID_2)));
			result = openCasesService.reOpenCase(openCaseBean);
			if (result.equals(AppConstants.SUCCESS)) {
				result = EsapiUtil.stripXSSCharacters(userVO.getStrUserName());
			}

		} catch (Exception ex) {
			logger.error("Exception occured in reopenCase method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return result;
	}
	
	/**
	 * @Author:
	 * @return: ModelAndView
	 * @Description: Displays the Cases page of the RMD application and fetching
	 *               data for cases related to the logged in user.
	 */
	@RequestMapping(AppConstants.REQ_URI_USER_CASES)
	public ModelAndView getUserCases(final HttpServletRequest request)
			throws RMDWebException {
		try
		{
			/*request.setAttribute(
				AppConstants.CASES_DEFAULT_RECORDS,
					findNumberOfRecords(AppConstants.CASES_TABLE_DEFAULT_RECORDS));*/
			final String myCasesRefreshTime = authService
					.getLookUpValueForName(AppConstants.MY_CASES_REFRESH_TIME);
			request.setAttribute(AppConstants.REFRESH_TIME,
					myCasesRefreshTime);
		}catch(Exception ex) {
			logger.error(
					"Exception occured in getUserCases method ", ex);
		} 
		return new ModelAndView(AppConstants.VIEW_MY_CASES);
	}
	
	/**
	 * @Description:This method is used for calling the serviceImpl in turn
	 *                   which will call webservices and bring the records for
	 *                   download
	 * @return: void
	 * @param:HttpServletRequest request,HttpServletResponse response,Locale
	 *                           locale
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 */
	@RequestMapping(value = AppConstants.EXPORT_MY_CASE, method = RequestMethod.POST)
	public void exportUserCases(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws IOException, GenericAjaxException, RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		/* For timezone issue */
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		/* For timezone issue */
		final OpenCasesBean openCaseBean = new OpenCasesBean();
		List<OpenCasesVO> openCasesVOLst = null;
		String csvContent = null;
		
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		String customerList="";
		try {
			openCaseBean.setUserLanguage(userVO.getStrUserLanguage());
			openCaseBean.setTimeZone(applicationTimezone);
			openCaseBean.setCustomerId(userVO.getCustomerId());
			openCaseBean.setUserId(userVO.getUserId());
			if (!RMDCommonUtility.isNullOrEmpty(userVO.getCustomerId())) {
				customerList = getCustomerList(userVO.getCustomerList());
				openCaseBean.setCustomerId(customerList);
			}
			openCaseBean.setMycases(AppConstants.TRUE);
			if (null != userVO.getProducts() && !userVO.getProducts().isEmpty()) {
				openCaseBean.setProducts(userVO.getProducts());
				request.setAttribute(
						AppConstants.CASES_DEFAULT_RECORDS,
						findNumberOfRecords(AppConstants.CASES_TABLE_DEFAULT_RECORDS));
				final String myCasesRefreshTime = authService
						.getLookUpValueForName(AppConstants.MY_CASES_REFRESH_TIME);
				request.setAttribute(AppConstants.REFRESH_TIME,
						myCasesRefreshTime);
				openCasesVOLst = openCasesService.getUserCases(openCaseBean);
			csvContent = convertToCSVMyCases(openCasesVOLst,
					locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.MY_CASES_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);

			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);

			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
			}
		} catch (Exception ex) {
			logger.error(
					"Exception occured in getLifeStatisticsData method ", ex);
			RMDWebErrorHandler.handleException(ex);
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}
	/**
	 * @Description:This method is used convert my cases into csv format
	 * @return: String
	 * @param:List<OpenCasesVO> openCasesVOLst, Locale locale
	 */
	private String convertToCSVMyCases(List<OpenCasesVO> openCasesVOLst,
			Locale locale) {
		String csvContent = null;
		StringBuffer strBufferAssetHeader = new StringBuffer();
		try {
			strBufferAssetHeader.append(appContext.getMessage(
					AppConstants.MY_CASES_HEADER, null, locale));
			strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			for (OpenCasesVO myCases : openCasesVOLst) {
				strBufferAssetHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE + myCases.getCaseID()
						+ AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ myCases.getCustomerName() + AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ myCases.getStrGrpName() + AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ myCases.getAssetNumber() + AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ myCases.getCaseTitle() + AppConstants.QUOTE);
				if (null != myCases.getPriority()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ myCases.getPriority()
									+ AppConstants.QUOTE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (null != myCases.getPriority()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ myCases.getPriority()
									+ AppConstants.QUOTE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
//				strBufferAssetHeader.append(RMDCommonConstants.COMMMA_SEPARATOR
//						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
//						+ myCases.getCaseReason() + AppConstants.QUOTE);
				if (null != myCases.getAge()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ myCases.getAge() + AppConstants.QUOTE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (null != myCases.getCreatedDate()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ myCases.getCreatedDate()
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				
				if (null != myCases.getCaseStatus()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ myCases.getCaseStatus()
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				
				if (null != myCases.getCaseCondition()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ myCases.getCaseCondition()
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}

//				strBufferAssetHeader.append(RMDCommonConstants.COMMMA_SEPARATOR
//						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
//						+ myCases.getCaseType() + AppConstants.QUOTE);
				if (null != myCases.getOwner()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ myCases.getOwner()
									+ AppConstants.QUOTE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBufferAssetHeader.toString();
		} catch (Exception exception) {
			logger.error("Export to CSV Asset life Stat"
					+ exception.getMessage(), exception);
		}
		return csvContent;
	}
	
	/**
	 * @Description:This method is used convert open cases into csv format
	 * @return: String
	 * @param:List<OpenCasesVO> openCasesVOLst, Locale locale
	 */
	private String convertToCSVOpenCases(List<OpenCasesVO> openCasesVOLst,
			Locale locale) {
		String csvContent = null;
		StringBuffer strBufferAssetHeader = new StringBuffer();
		try {
			strBufferAssetHeader.append(appContext.getMessage(
					AppConstants.OPEN_CASES_HEADER, null, locale));
			strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			for (OpenCasesVO myCases : openCasesVOLst) {
				strBufferAssetHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE + myCases.getCaseID()
						+ AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ myCases.getStrGrpName() + AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ myCases.getAssetNumber() + AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ myCases.getCaseTitle() + AppConstants.QUOTE);
				if (null != myCases.getPriority()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ myCases.getPriority()
									+ AppConstants.QUOTE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				strBufferAssetHeader.append(RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ myCases.getCaseReason() + AppConstants.QUOTE);
				if (null != myCases.getAge()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ myCases.getAge() + AppConstants.QUOTE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (null != myCases.getCreatedDate()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ myCases.getCreatedDate()
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (null != myCases.getCaseCondition()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ myCases.getCaseCondition()
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}

				strBufferAssetHeader.append(RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ myCases.getCaseType() + AppConstants.QUOTE);
				if (null != myCases.getOwner()
						&& !myCases.getOwner().equals(
								AppConstants.OWNER_UNASSIGNED)) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ myCases.getOwner() + AppConstants.QUOTE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBufferAssetHeader.toString();
		} catch (Exception exception) {
			logger.error("Export to CSV Case List" + exception.getMessage());
		}
		return csvContent;
	}
	
	/**
	 * @Description:This method is used to  export the Open Cases from Case List page
	 * @return: void
	 * @param:HttpServletRequest request,HttpServletResponse response,Locale
	 *                           locale
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 */
	@RequestMapping(value = AppConstants.EXPORT_OPEN_CASE, method = RequestMethod.POST)
	public void exportOpenCases(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws IOException, GenericAjaxException, RMDWebException {
		request.setAttribute(AppConstants.FILTERFLAG,
				EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG)));
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		/* For timezone issue */
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		/* For timezone issue */
		final OpenCasesBean openCaseBean = new OpenCasesBean();
		List<OpenCasesVO> openCasesVOLst = null;
		String csvContent = null;

		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		String customerList="";
		try {
			openCaseBean.setUserLanguage(userVO.getStrUserLanguage());
			openCaseBean.setTimeZone(applicationTimezone);
			openCaseBean.setCustomerId(userVO.getCustomerId());
			openCaseBean.setDefaultTimeZone(defaultTimezone);
			if (!RMDCommonUtility.isNullOrEmpty(userVO.getCustomerId())) {
				customerList = getCustomerList(userVO.getCustomerList());
				openCaseBean.setCustomerId(customerList);
			}
			if (null != userVO.getProducts() && !userVO.getProducts().isEmpty()) {
				openCaseBean.setProducts(userVO.getProducts());
				// adding for pagination
				request.setAttribute(
						AppConstants.CASES_DEFAULT_RECORDS,
						findNumberOfRecords(AppConstants.CASES_TABLE_DEFAULT_RECORDS));
				final String openCasesRefreshTime = authService
						.getLookUpValueForName(AppConstants.DWQ_CASES_REFRESH_TIME);
				request.setAttribute(AppConstants.OPENCASE_REFRESH_TIME,
						openCasesRefreshTime);
				openCasesVOLst = openCasesService.fetchOpenCases(openCaseBean);
				csvContent = convertToCSVOpenCases(openCasesVOLst, locale);
				response.setContentType(AppConstants.CONTENT_TYPE);
				response.setHeader(AppConstants.CONTENT,
						AppConstants.ATTACH_FILENAME
								+ AppConstants.OPEN_CASES_EXPORT_FILENAME);
				objServletOutputStream = response.getOutputStream();
				ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
						csvContent.getBytes());
				objBufferedInputStream = new BufferedInputStream(
						objByteArrayInputStream);

				objBufferedOutputStream = new BufferedOutputStream(
						objServletOutputStream);

				byte[] byteArr = new byte[2048];
				int bytesread;

				while ((bytesread = objBufferedInputStream.read(byteArr, 0,
						byteArr.length)) != -1) {
					objBufferedOutputStream.write(byteArr, 0, bytesread);
					objBufferedOutputStream.flush();
				}
			}
		} catch (Exception ex) {
			logger.error("Exception occured in getLifeStatisticsData method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	

}

	/**
	 * @author 
	 * @param HttpServletRequest  request
	 * @return List<OpenCasesVO>
	 * @throws RMDWebException
	 * @description This method is responsible for fetching the list of open
	 *              Cases.
	 */

	@RequestMapping(value = AppConstants.GET_OPEN_CASES, method = RequestMethod.GET)
	public @ResponseBody
	List<OpenCasesVO> getOpenCases(final HttpServletRequest request)
			throws RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		/* For timezone issue */
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		/* For timezone issue */
		final OpenCasesBean openCaseBean = new OpenCasesBean();
		List<OpenCasesVO> openCasesVOLst = new ArrayList<OpenCasesVO>();
		String customerList = "";
		try {
			openCaseBean.setUserLanguage(userVO.getStrUserLanguage());
			openCaseBean.setTimeZone(applicationTimezone);
			openCaseBean.setCustomerId(userVO.getCustomerId());
			openCaseBean.setCmAliasName(userVO.getCmAliasName());
			openCaseBean.setDefaultTimeZone(defaultTimezone);
			if (!RMDCommonUtility.isNullOrEmpty(userVO.getCustomerId())) {
				customerList = getCustomerList(userVO.getCustomerList());
				openCaseBean.setCustomerId(customerList);
			}
			if (null != userVO.getProducts() && !userVO.getProducts().isEmpty()) {
				openCaseBean.setProducts(userVO.getProducts());
				openCasesVOLst = openCasesService.fetchOpenCases(openCaseBean);

			}
		} catch (Exception exception) {
			logger.error("Error Occured in getOpenCases() method"
					+ exception.getMessage());
		}
		return openCasesVOLst;
	}
	
	
	
	/**
	 * @author
	 * @param HttpServletRequest
	 *            request
	 * @return List<OpenCasesVO>
	 * @throws RMDWebException
	 * @description Displays the Cases page of the RMD application and fetching
	 *               data for cases related to the logged in user.
	 */

	@RequestMapping(value = AppConstants.GET_MY_CASES, method = RequestMethod.GET)
	public @ResponseBody
	List<OpenCasesVO> getMyCases(final HttpServletRequest request)
			throws RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		/* For timezone issue */
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		/* For timezone issue */
		final OpenCasesBean openCaseBean = new OpenCasesBean();
		List<OpenCasesVO> openCasesVOLst = null;
		String customerList = "";
		try {
			openCaseBean.setUserLanguage(userVO.getStrUserLanguage());
			openCaseBean.setTimeZone(applicationTimezone);
			openCaseBean.setCustomerId(userVO.getCustomerId());
			openCaseBean.setUserId(userVO.getUserId());
			openCaseBean.setMycases(AppConstants.TRUE);
			if (!RMDCommonUtility.isNullOrEmpty(userVO.getCustomerId())) {
				customerList = getCustomerList(userVO.getCustomerList());
				openCaseBean.setCustomerId(customerList);
			}
			if (null != userVO.getProducts() && !userVO.getProducts().isEmpty()) {
				openCaseBean.setProducts(userVO.getProducts());
				openCasesVOLst = openCasesService.getUserCases(openCaseBean);
			}
		} catch (Exception e) {
			logger.error("Exception occured in getMyCases() method ");
			RMDWebErrorHandler.handleException(e);
		}
		return openCasesVOLst;
	}
}
