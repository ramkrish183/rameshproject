package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.valueobjects.SiteSearchVO;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface SiteService {
    /**
     * @return Map<String, String>
     * @throws RMDWebException
     * @Description * This method is used to fetch the values from lookup table
     *              to populate the Site Type dropdown.
     */
    public List<String> getSiteTypes() throws RMDWebException;

    /**
     * 
     * @param
     * @return List<SiteSearchVO>
     * @throws Exception
     * @Description * This method is used to get the Sites.
     * 
     */
    public List<SiteSearchVO> getSites(SiteSearchVO objSiteVO)
            throws RMDWebException;

    /**
     * @Author :
     * @return :SiteSearchVO
     * @param :String siteObjId
     * @throws :RMDWebException
     * @Description:This method is used to get View Site Details.
     */
    public SiteSearchVO viewSiteDetails(String siteObjId)
            throws RMDWebException;

    /**
     * 
     * @param SiteSearchVO
     *            objSiteVO
     * @return String
     * @throws Exception
     * @Description * This method is used to Update the Site.
     * 
     */
    public String updateSite(SiteSearchVO objSiteVO) throws RMDWebException;

    /**
     * 
     * @param SiteSearchVO
     *            objSiteVO
     * @return String
     * @throws Exception
     * @Description * This method is used to create the Site.
     * 
     */
    public String createSite(SiteSearchVO objSiteVO) throws RMDWebException;

    /**
     * @return Map<String, Map<String, String>>
     * @throws RMDWebException
     * @Description * This method is used to fetch the values from lookup table
     *              to populate the Site Shipping,Site Status & SiteEdit Types
     *              dropdown.
     */
    public Map<String, List<String>> getPopulateData() throws RMDWebException;

}
