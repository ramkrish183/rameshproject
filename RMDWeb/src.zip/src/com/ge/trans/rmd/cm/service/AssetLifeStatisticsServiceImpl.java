/**
 * ============================================================
 * File : AssetLifeStatisticsServiceImpl.java
 * Description : 
 * 
 * Package :  com.ge.trans.rmd.cm.service
 * Author : iGATE 
 * Last Edited By :
 * Version : 1.0
 * Created on : Nov 21, 2014
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2013 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.LifeStatisticsVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.assets.valueobjects.LifeStatisticsRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.LifeStatisticsResponseType;

@Service
public class AssetLifeStatisticsServiceImpl extends RMDBaseServiceImpl
		implements AssetLifeStatisticsService {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	WebServiceInvoker webServiceInvoker;
	@Autowired
	private CachedService cachedService;
	/**
	 * @return:ModelAndView
	 * @Description: Displays the life statistics page of the RMD application
	 */
	@Override
	public LifeStatisticsVO getassetLifeStatistics(
			AssetOverviewBean assetOverviewBean, String userCustomer) throws RMDWebException,
			Exception {
		rmdWebLogger
				.debug("AssetCasesServiceImpl : Inside getLifeStatisticsData() method:::STARTT");
		LifeStatisticsRequestType objAssetReqType = new LifeStatisticsRequestType();
		final Map<String, String> pathParamsPastDays = new LinkedHashMap<String, String>();
		pathParamsPastDays.put(AppConstants.LIST_NAME,
				AppConstants.ASSET_CASE_LOOKBACK_DAYS);
		List<XMLGregorianCalendar> headerDatesList = new ArrayList<XMLGregorianCalendar>();
		List<String> headerDatesListStr = new ArrayList<String>();
		LinkedHashMap<String, Map<String, String>> attributeNameMap = new LinkedHashMap<String, Map<String, String>>();
		Map<String, String> timeStampValueMap = new HashMap<String, String>();
		Map<String,String> toolTipMap = new LinkedHashMap<String, String>();
		DateFormat zoneFormater = new SimpleDateFormat(
				AppConstants.DATE_FORMAT_24HRS);
		if (cachedService.getSDCustLookup().get(userCustomer) != null
                && cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
                && !cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim().equals("")) {
			zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat());
        }
		final TimeZone firstTime = TimeZone.getTimeZone(assetOverviewBean
				.getUserTimeZone());
		LifeStatisticsVO lifeStatisticsVO = new LifeStatisticsVO();

		try {

			LifeStatisticsResponseType[] assetResponseType = null;
			objAssetReqType.setAssetNumber(assetOverviewBean.getAsset());
			objAssetReqType
					.setAssetGroupName(assetOverviewBean.getAssetGroup());
			objAssetReqType.setCustomerID(assetOverviewBean.getCustomer());
			objAssetReqType.setFromDate(assetOverviewBean.getFromDate());
			objAssetReqType.setToDate(assetOverviewBean.getToDate());
			objAssetReqType.setControllerCfg(assetOverviewBean
					.getControllerConfig());
			objAssetReqType.setHideL3Fault(assetOverviewBean
					.isHideL3Fault());
			assetResponseType = (LifeStatisticsResponseType[]) webServiceInvoker
					.post(ServiceConstants.LIFE_STATISTICS, objAssetReqType,
							LifeStatisticsResponseType[].class);
			for (LifeStatisticsResponseType currentResultVO : assetResponseType) {
				final XMLGregorianCalendar creationDate = currentResultVO
						.getStatisticGatheringDate();
				zoneFormater.setTimeZone(firstTime);
				if (!headerDatesList.contains(currentResultVO
						.getStatisticGatheringDate())) {
					headerDatesList.add(currentResultVO
							.getStatisticGatheringDate());
				}

				if (attributeNameMap.containsKey(currentResultVO
						.getAttributeName()
						+ AppConstants.UNDERSCORE
						+ currentResultVO.getUnits())) {
					Map<String, String> tempMap = attributeNameMap
							.get(currentResultVO.getAttributeName()
									+ AppConstants.UNDERSCORE
									+ currentResultVO.getUnits());
					tempMap.put(zoneFormater.format(creationDate
							.toGregorianCalendar().getTime()), currentResultVO
							.getAttributeValue());
				} else {
					timeStampValueMap = new HashMap<String, String>();
					timeStampValueMap.put(zoneFormater.format(creationDate
							.toGregorianCalendar().getTime()), currentResultVO
							.getAttributeValue());
					attributeNameMap.put(
							currentResultVO.getAttributeName()
									+ AppConstants.UNDERSCORE
									+ currentResultVO.getUnits(),
							timeStampValueMap);
					toolTipMap.put(currentResultVO.getAttributeName(), currentResultVO.getAttributeToolTip());
				}

			}
			Collections.sort(headerDatesList, DATECOMPARATOR);
			for (XMLGregorianCalendar currentDate : headerDatesList) {
				headerDatesListStr.add(zoneFormater.format(currentDate
						.toGregorianCalendar().getTime()));
			}
			lifeStatisticsVO.setHeaderDatesList(headerDatesListStr);
			lifeStatisticsVO.setTimeStampValueMap(attributeNameMap);
			lifeStatisticsVO.setAttributeToolTip(toolTipMap);
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getLifeStatisticsData() method ",
							rmdEx);
			if (!AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(rmdEx
					.getMessage())) {
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLifeStatisticsData() method ", ex);
		}
		rmdWebLogger
				.debug("AssetCasesServiceImpl : Inside getLifeStatisticsData() method:::END");

		return lifeStatisticsVO;
	}

	/**
	 *
	 */
	public static final Comparator DATECOMPARATOR = new Comparator() {

		/**
		 * @Author:
		 * @param objFirst
		 * @param objSecond
		 * @return
		 * @Description:
		 */
		public int compare(Object objFirst, Object objSecond) {
			XMLGregorianCalendar dateFirst = (XMLGregorianCalendar) objFirst;
			XMLGregorianCalendar dateSecond = (XMLGregorianCalendar) objSecond;
			if (dateFirst == null) {
				return +1;
			}
			if (dateSecond == null) {
				return -1;
			}
			return -dateFirst.compare(dateSecond);
		}
	};
}
