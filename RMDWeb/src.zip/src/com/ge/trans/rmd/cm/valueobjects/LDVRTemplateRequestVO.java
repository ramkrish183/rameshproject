package com.ge.trans.rmd.cm.valueobjects;

import java.io.Serializable;
import java.util.List;


public class LDVRTemplateRequestVO  implements Serializable {
	
	private static final long serialVersionUID = -6539201271719681719L;
	
	private String templateObjid;
	private String applicationId;
	private String description;
	private String userName;
	private String templateNumber;
	private String templateVersion;
	private String createdDate;
	private String lastUpdatedDate;
	private String templateStatus;
	private List<String> customerId;
	private String messageId;
	private LDVRTemplateDetailsVO ldvrTemplateDetVO;
	private String device;
	private String timeZone;
	private String customerName;
	private String category;
	private String ctrlCfgName;
	
	
	public String getTemplateNumber() {
		return templateNumber;
	}

	public void setTemplateNumber(String templateNumber) {
		this.templateNumber = templateNumber;
	}

	public String getTemplateVersion() {
		return templateVersion;
	}

	public void setTemplateVersion(String templateVersion) {
		this.templateVersion = templateVersion;
	}

	public String getTemplateDescription() {
		return description;
	}

	public void setTemplateDescription(String templateDescription) {
		this.description = templateDescription;
	}

	public String getTemplateStatus() {
		return templateStatus;
	}

	public void setTemplateStatus(String templateStatus) {
		this.templateStatus = templateStatus;
	}

	public List<String> getCustomerId() {
		return customerId;
	}

	public void setCustomerId(List<String> customerId) {
		this.customerId = customerId;
	}

	public String getMessageId() {
		return messageId;
	}

	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}

	public LDVRTemplateDetailsVO getLdvrTemplateDetVO() {
		return ldvrTemplateDetVO;
	}

	public void setLdvrTemplateDetVO(LDVRTemplateDetailsVO ldvrTemplateDetVO) {
		this.ldvrTemplateDetVO = ldvrTemplateDetVO;
	}

	/**
	 * @return the templateObjid
	 */
	public String getTemplateObjid() {
		return templateObjid;
	}

	/**
	 * @param templateObjid the templateObjid to set
	 */
	public void setTemplateObjid(String templateObjid) {
		this.templateObjid = templateObjid;
	}

	/**
	 * @return the applicationId
	 */
	public String getApplicationId() {
		return applicationId;
	}

	/**
	 * @param applicationId the applicationId to set
	 */
	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the createdDate
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the lastUpdatedDate
	 */
	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	/**
	 * @param lastUpdatedDate the lastUpdatedDate to set
	 */
	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	/**
	 * @return the device
	 */
	public String getDevice() {
		return device;
	}

	/**
	 * @param device the device to set
	 */
	public void setDevice(String device) {
		this.device = device;
	}

	/**
	 * @return the timeZone
	 */
	public String getTimeZone() {
		return timeZone;
	}

	/**
	 * @param timeZone the timeZone to set
	 */
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}

	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getCtrlCfgName() {
        return ctrlCfgName;
    }

    public void setCtrlCfgName(String ctrlCfgName) {
        this.ctrlCfgName = ctrlCfgName;
    }	

	
	
}