package com.ge.trans.rmd.cm.mvc.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import com.ge.trans.rmd.cm.service.RxResearchService;
import com.ge.trans.rmd.cm.valueobjects.RxRepairCodeDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.RxResearchVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
@Controller
@SessionAttributes
public class RXResearchController extends RMDBaseController {
	@Autowired
	private RxResearchService rxResearchService;
	private final  RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param :
	 * @throws :RMDWebException
	 * @Description: Displays the RX Research page of the RMD application
	 *               when clicked on RxResearch sub Tab in view Page.
	 * 
	 */
	@RequestMapping(AppConstants.REQ_RX_RESEARCH_PAGE)
	public ModelAndView viewRxResearchPage(final HttpServletRequest request)
			throws RMDWebException {
		 Calendar cal = Calendar.getInstance();
	        final SimpleDateFormat fromDateFormat = new SimpleDateFormat(
	                AppConstants.DATE_FORMAT_24HRS);
	        String previousDate = null;
	        int previousDateRange = 0;
	        String currentDate = null;
	        String previousDateRangeVal = null;
	        cal.set(Calendar.HOUR_OF_DAY, cal.getTime().getHours());
	        cal.set(Calendar.MINUTE, cal.getTime().getMinutes());
	        cal.set(Calendar.SECOND, cal.getTime().getSeconds());
	        currentDate = fromDateFormat.format(cal.getTime());
	        previousDateRange =180;
	        previousDateRangeVal = AppConstants.SYMBOL_MINUS + previousDateRange;
	        cal.add(Calendar.DATE, Integer.parseInt(previousDateRangeVal));
	        cal.set(Calendar.HOUR_OF_DAY, cal.getTime().getHours());
	        cal.set(Calendar.MINUTE, cal.getTime().getMinutes());
	        cal.set(Calendar.SECOND, cal.getTime().getSeconds());
	        previousDate = fromDateFormat.format(cal.getTime());
	        request.setAttribute(AppConstants.PP_FROM_PREVOIUSDATE, previousDate);
	        request.setAttribute(AppConstants.PP_CURRENT_DATE, currentDate);
		return new ModelAndView(AppConstants.RX_RESEARCH);
	}
	
	@RequestMapping(AppConstants.REQ_RX_RESEARCH_SEARCH_SOLUTION)
	@ResponseBody public  List<String> getSearchSolution(final HttpServletRequest request,
			@RequestParam("selectBy") String selectBy,
			@RequestParam("condition") String condition,
			@RequestParam("searchVal") String searchVal,
			@RequestParam("rxType") String rxType
			)
			throws RMDWebException {
		RxResearchVO rxResearchVO = new RxResearchVO();
		List<String> objectMap = null;
		if(condition!=null && !condition.equals(AppConstants.EMPTY_STRING)){
		rxResearchVO.setCondition(condition);
		}
		if(selectBy!=null && !selectBy.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setSelectBy(selectBy);
		}
		if(searchVal!=null && !searchVal.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setSearchVal(searchVal);
		}
		if(rxType!=null && !rxType.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setRxType(rxType);
		}
		try {
			objectMap =  rxResearchService.getSearchSolution(rxResearchVO);
		} catch (Exception e) {
			rmdWebLogger.error(
					"Exception occured in getConfigList method ", e);
			RMDWebErrorHandler.handleException(e);
		}
	
		
		return objectMap;
	}
	@RequestMapping(AppConstants.REQ_RX_RESEARCH_GET_GRAPH_DATA)
	@ResponseBody public  List<RxResearchVO> getGraphicalData(final HttpServletRequest request,
			@RequestParam("selectBy") String selectBy,
			@RequestParam("condition") String condition,
			@RequestParam("searchVal") String searchVal,
			@RequestParam("rxType") String rxType,
			@RequestParam("startDate") String startDate,
			@RequestParam("endDate") String endDate,
			@RequestParam("caseType") String caseType,
			@RequestParam("customerId") String customerId,
			@RequestParam("fleet") String fleet,
			@RequestParam("model") String model,
			@RequestParam("rnh") String rnh,
			@RequestParam("isGoodFdbk") String isGoodFdbk
			)
			throws RMDWebException {
		RxResearchVO rxResearchVO = new RxResearchVO();
		SimpleDateFormat sdf = new SimpleDateFormat("mm/dd/yyyy hh:mm:ss",
                Locale.ENGLISH);
		 SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
		List<RxResearchVO> objectMap = null;
		if(condition!=null && !condition.equals(AppConstants.EMPTY_STRING)){
		rxResearchVO.setCondition(condition);
		}
		if(selectBy!=null && !selectBy.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setSelectBy(selectBy);
		}
		if(searchVal!=null && !searchVal.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setSearchVal(searchVal);
		}
		if(rxType!=null && !rxType.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setRxType(rxType);
		}
		if(startDate!=null && !startDate.equals(AppConstants.EMPTY_STRING)){
			String fromDate = null;
			try {
				Date date = sdf.parse(startDate);
				fromDate = formatter.format(date);
			} catch (ParseException e) {
				e.printStackTrace();
				rmdWebLogger.error("Parse Error in start date"+e);
			}
			rxResearchVO.setStartDate(fromDate);
		}
		if(endDate!=null && !endDate.equals(AppConstants.EMPTY_STRING)){
			String toDate = null;
			try {
				Date date = sdf.parse(endDate);
				toDate = formatter.format(date);
			} catch (ParseException e) {
				e.printStackTrace();
				rmdWebLogger.error("Parse Error in end date"+e);
			}
			rxResearchVO.setEndDate(toDate);
		}
		if(caseType!=null && !caseType.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setCaseType(caseType);
		}
		if(customerId!=null && !customerId.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setCustomerId(customerId);
		}
		if(fleet!=null && !fleet.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setFleet(fleet);
		}
		if(model!=null && !model.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setModel(model);
		}
		if(rnh!=null && !rnh.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setRnh(rnh);
		}
		if(isGoodFdbk!=null && !isGoodFdbk.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setIsGoodFdbk(isGoodFdbk);
		}
		try {
			objectMap =  rxResearchService.getGraphicalData(rxResearchVO);
		} catch (Exception e) {
			rmdWebLogger.error(
					"Exception occured in getConfigList method ", e);
			RMDWebErrorHandler.handleException(e);
		}
	
		
		return objectMap;
	}
	@RequestMapping(AppConstants.POPULATE_REPAIR_CODE_DETAILS)
	@ResponseBody public  List<RxRepairCodeDetailsVO> populateRepairCodeDetails(final HttpServletRequest request,
			@RequestParam("repairCode") String repairCode,
			@RequestParam("searchVal") String searchVal,
			@RequestParam("rxType") String rxType,
			@RequestParam("startDate") String startDate,
			@RequestParam("endDate") String endDate,
			@RequestParam("caseType") String caseType,
			@RequestParam("customerId") String customerId,
			@RequestParam("fleet") String fleet,
			@RequestParam("model") String model,
			@RequestParam("rnh") String rnh,
			@RequestParam("initFlag") String initFlag,
			@RequestParam("isGoodFdbk") String isGoodFdbk
			)
			throws RMDWebException {
		RxResearchVO rxResearchVO = new RxResearchVO();
		SimpleDateFormat sdf = new SimpleDateFormat("mm/dd/yyyy hh:mm:ss",
                Locale.ENGLISH);
		 SimpleDateFormat formatter = new SimpleDateFormat("dd-MMM-yyyy hh:mm:ss");
		List<RxRepairCodeDetailsVO> objectMap = null;
		if(repairCode!=null && !repairCode.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setRepairCode(repairCode);
		}
		if(searchVal!=null && !searchVal.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setSearchVal(searchVal);
		}
		if(rxType!=null && !rxType.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setRxType(rxType);
		}
		if(startDate!=null && !startDate.equals(AppConstants.EMPTY_STRING)){
			String fromDate = null;
			try {
				Date date = sdf.parse(startDate);
				fromDate = formatter.format(date);
			} catch (ParseException e) {
				e.printStackTrace();
				rmdWebLogger.error("Parse Error in start date"+e);
			}
			rxResearchVO.setStartDate(fromDate);
		}
		if(endDate!=null && !endDate.equals(AppConstants.EMPTY_STRING)){
			String toDate = null;
			try {
				Date date = sdf.parse(endDate);
				toDate = formatter.format(date);
			} catch (ParseException e) {
				e.printStackTrace();
				rmdWebLogger.error("Parse Error in end date"+e);
			}
			rxResearchVO.setEndDate(toDate);
		}
		if(caseType!=null && !caseType.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setCaseType(caseType);
		}
		if(customerId!=null && !customerId.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setCustomerId(customerId);
		}
		if(fleet!=null && !fleet.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setFleet(fleet);
		}
		if(model!=null && !model.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setModel(model);
		}
		if(rnh!=null && !rnh.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setRnh(rnh);
		}
		if(initFlag!=null && !initFlag.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setInitFlag(initFlag);
		}
		if(isGoodFdbk!=null && !isGoodFdbk.equals(AppConstants.EMPTY_STRING)){
			rxResearchVO.setIsGoodFdbk(isGoodFdbk);
		}
		try {
			objectMap =  rxResearchService.populateRepairCodeDetails(rxResearchVO);
		} catch (Exception e) {
			rmdWebLogger.error(
					"Exception occured in populateRepairCodeDetails method ", e);
			RMDWebErrorHandler.handleException(e);
		}
	
		
		return objectMap;
	}
	
}
