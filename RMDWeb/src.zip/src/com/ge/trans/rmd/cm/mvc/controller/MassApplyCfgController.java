/**
 * ============================================================

 * Classification		: GE Confidential
 * File 				: MassApplyCfgController.java
 * Description 			:
 * Package 				: com.ge.trans.rmd.cm.valueobjects;
 * Author 				: Capgemini India.
 * Last Edited By 		:
 * Version 				: 1.0
 * Created on 			:
 * History				:
 * Modified By 			: Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.mvc.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.MassApplyCfgService;
import com.ge.trans.rmd.cm.valueobjects.ApplyCfgTemplateVO;
import com.ge.trans.rmd.cm.valueobjects.ApplyEFICfgVO;
import com.ge.trans.rmd.cm.valueobjects.AssetSearchVO;
import com.ge.trans.rmd.cm.valueobjects.ConfigSearchVO;
import com.ge.trans.rmd.cm.valueobjects.MassApplyCfgVO;
import com.ge.trans.rmd.cm.valueobjects.VerifyCfgTemplateVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
@Controller
@SessionAttributes
public class MassApplyCfgController {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	MassApplyCfgService massApplyCfgService;

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param : HttpServletRequest request
	 * @throws :RMDWebException
	 * @Description: Displays the Mass Apply Cfg Screen of the RMD application
	 *               when clicked on VehicleConfig Tab in View Page.
	 * 
	 */
	@RequestMapping(AppConstants.REQ_URI_MASS_APPLY_CONFIG)
	public ModelAndView showMassApplyConfigScreen(
			final HttpServletRequest request, final Model model)
			throws RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String userName = userVO.getCmAliasName();
		try {
			List<String> userList = massApplyCfgService.getMassApplyCfgUsers();
			if (null != userName && userList.contains(userName)) {
				model.addAttribute(AppConstants.isMassApplyCfgUser, true);
			} else {
				model.addAttribute(AppConstants.isMassApplyCfgUser, false);
			}
			model.addAttribute(AppConstants.USER_ID, userName);
			userList = null;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in showMassApplyConfigScreen method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return new ModelAndView(AppConstants.MASS_APPLY_CFG);
	}

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param : HttpServletRequest request
	 * @throws :RMDWebException
	 * @Description: Displays the Mass Apply Cfg Screen of the RMD application
	 *               when clicked on VehicleConfig Tab in View Page.
	 * 
	 */
	@RequestMapping(AppConstants.REQ_URI_CASE_MASS_APPLY_CONFIG)
	public ModelAndView showCaseMassApplyConfigScreen(
			final HttpServletRequest request,
			final Model model,
			@RequestParam(value = AppConstants.CTRL_CFG_NAME, required = false) String ctrlCfgName,
			@RequestParam(value = AppConstants.VEHICLE_OBJID, required = false) String vehicleObjId,
			@RequestParam(value = AppConstants.ASSET_NUMBER, required = false) String assetNumber,
			@RequestParam(value = AppConstants.ASSET_GROUP_NAME, required = false) String assetGrpName,
			@RequestParam(value = AppConstants.CUSTOMER, required = false) String customer,
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = false) String customerId,
			@RequestParam(value = AppConstants.MODEL, required = false) String modelname,
			@RequestParam(value = AppConstants.FLEET, required = false) String fleet,
			@RequestParam(value = AppConstants.ASSET_VEH_HDR_NO, required = false) String assetVehHdrNo)
			throws RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String userName = userVO.getCmAliasName();
		String ctrlCfgObjId = null;
		try {
			List<String> userList = massApplyCfgService.getMassApplyCfgUsers();
			if (null != userName && userList.contains(userName)) {
				model.addAttribute(AppConstants.isMassApplyCfgUser, true);
			} else {
				model.addAttribute(AppConstants.isMassApplyCfgUser, false);
			}
			Map<String, String> ctrlcfgMap = getControllerConfigs();

			if (ctrlcfgMap.containsKey(ctrlCfgName)) {
				ctrlCfgObjId = ctrlcfgMap.get(ctrlCfgName);
			}
			userList = null;
			ctrlcfgMap = null;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in showMassApplyConfigScreen method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		model.addAttribute(AppConstants.CASE_MASS_APPLY_CFG_SCREEN, true);
		model.addAttribute(AppConstants.CTRL_CFG_NAME, ctrlCfgName);
		model.addAttribute(AppConstants.CTRL_CFG_OBJID, ctrlCfgObjId);
		model.addAttribute(AppConstants.USER_ID, userName);
		model.addAttribute(AppConstants.VEHICLE_OBJID, vehicleObjId);
		model.addAttribute(AppConstants.ASSET_NUMBER, assetNumber);
		model.addAttribute(AppConstants.ASSET_GROUP_NAME, assetGrpName);
		model.addAttribute(AppConstants.CUSTOMER, customer);
		model.addAttribute(AppConstants.CUSTOMER_ID, customerId);
		model.addAttribute(AppConstants.MODEL, modelname);
		model.addAttribute(AppConstants.FLEET, fleet);
		model.addAttribute(AppConstants.ASSET_VEH_HDR_NO, assetVehHdrNo);

		return new ModelAndView(AppConstants.MASS_APPLY_CFG);
	}

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param : HttpServletRequest request
	 * @throws :RMDWebException
	 * @Description: Displays the Apply Cfg Screen of the RMD application when
	 *               clicked on Apply button from MassApply Config Screen.
	 * 
	 */
	@RequestMapping(AppConstants.REQ_URI_APPLY_CONFIG)
	public ModelAndView showApplyConfigScreen(
			final HttpServletRequest request,
			final Model model,
			@RequestParam(value = AppConstants.EDP_OBJID, required = false) String edpObjId,
			@RequestParam(value = AppConstants.FFD_OBJID, required = false) String ffdObjId,
			@RequestParam(value = AppConstants.FRD_OBJID, required = false) String frdObjId,
			@RequestParam(value = AppConstants.AHC_OBJID, required = false) String ahcObjId,
			@RequestParam(value = AppConstants.RCI_OBJID, required = false) String rciObjId,
			@RequestParam(value = AppConstants.CTRL_CFG_NAME, required = false) String ctrlCfgName,
			@RequestParam(value = AppConstants.CTRL_CFG_OBJID, required = false) String ctrlCfgObjId,
			@RequestParam(value = AppConstants.IS_CONFIG_MAINTAINENCE_SCREEN, required = false) String isConfigMaintainenceScreen)
			throws RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String userName = userVO.getCmAliasName();
		try {
			List<String> userList = massApplyCfgService.getMassApplyCfgUsers();
			if (null != userName && userList.contains(userName)) {
				model.addAttribute(AppConstants.isMassApplyCfgUser, true);
			} else {
				model.addAttribute(AppConstants.isMassApplyCfgUser, false);
			}
			userList = null;
			model.addAttribute(AppConstants.EDP_OBJID, edpObjId);
			model.addAttribute(AppConstants.FFD_OBJID, ffdObjId);
			model.addAttribute(AppConstants.FRD_OBJID, frdObjId);
			model.addAttribute(AppConstants.AHC_OBJID, ahcObjId);
			model.addAttribute(AppConstants.RCI_OBJID, rciObjId);
			model.addAttribute(AppConstants.CTRL_CFG_NAME, ctrlCfgName);
			model.addAttribute(AppConstants.CTRL_CFG_OBJID, ctrlCfgObjId);
			model.addAttribute(AppConstants.USER_ID, userName);
			model.addAttribute(
					AppConstants.IS_CONFIG_MAINTAINENCE_SCREEN,
					RMDCommonConstants.YES
							.equalsIgnoreCase(isConfigMaintainenceScreen) ? true
							: false);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in showApplyConfigScreen method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return new ModelAndView(AppConstants.APPLY_CONFIG);
	}

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param : HttpServletRequest request
	 * @throws :RMDWebException
	 * @Description: Displays the Apply Cfg Screen of the RMD application when
	 *               clicked on Apply button from MassApply Config Screen.
	 * 
	 */
	@RequestMapping(AppConstants.REQ_URI_CASE_APPLY_CONFIG)
	public ModelAndView showCaseApplyConfigScreen(
			final HttpServletRequest request,
			final Model model,
			@RequestParam(value = AppConstants.EDP_OBJID, required = false) String edpObjId,
			@RequestParam(value = AppConstants.FFD_OBJID, required = false) String ffdObjId,
			@RequestParam(value = AppConstants.FRD_OBJID, required = false) String frdObjId,
			@RequestParam(value = AppConstants.AHC_OBJID, required = false) String ahcObjId,
			@RequestParam(value = AppConstants.RCI_OBJID, required = false) String rciObjId,
			@RequestParam(value = AppConstants.AGT_OBJID, required = false) String agtObjId,
			@RequestParam(value = AppConstants.CTRL_CFG_NAME, required = false) String ctrlCfgName,
			@RequestParam(value = AppConstants.CTRL_CFG_OBJID, required = false) String ctrlCfgObjId,
			@RequestParam(value = AppConstants.ASSET_NUMBER, required = false) String assetNumber,
			@RequestParam(value = AppConstants.ASSET_GROUP_NAME, required = false) String assetGrpName,
			@RequestParam(value = AppConstants.CUSTOMER, required = false) String customer,
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = false) String customerId,
			@RequestParam(value = AppConstants.MODEL, required = false) String modelname,
			@RequestParam(value = AppConstants.FLEET, required = false) String fleet,
			@RequestParam(value = AppConstants.ASSET_VEH_HDR_NO, required = false) String vehHdrNo)
			throws RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String userName = userVO.getCmAliasName();
		try {
			List<String> userList = massApplyCfgService.getMassApplyCfgUsers();
			if (null != userName && userList.contains(userName)) {
				model.addAttribute(AppConstants.isMassApplyCfgUser, true);
			} else {
				model.addAttribute(AppConstants.isMassApplyCfgUser, false);
			}
			userList = null;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in showCaseApplyConfigScreen method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		model.addAttribute(AppConstants.EDP_OBJID, edpObjId);
		model.addAttribute(AppConstants.FFD_OBJID, ffdObjId);
		model.addAttribute(AppConstants.FRD_OBJID, frdObjId);
		model.addAttribute(AppConstants.AHC_OBJID, ahcObjId);
		model.addAttribute(AppConstants.RCI_OBJID, rciObjId);
		model.addAttribute(AppConstants.AGT_OBJID, agtObjId);
		model.addAttribute(AppConstants.ASSET_NUMBER, assetNumber);
		model.addAttribute(AppConstants.ASSET_GROUP_NAME, assetGrpName);
		model.addAttribute(AppConstants.CUSTOMER, customer);
		model.addAttribute(AppConstants.CUSTOMER_ID, customerId);
		model.addAttribute(AppConstants.MODEL, modelname);
		model.addAttribute(AppConstants.FLEET, fleet);
		model.addAttribute(AppConstants.ASSET_VEH_HDR_NO, vehHdrNo);
		model.addAttribute(AppConstants.CTRL_CFG_NAME, ctrlCfgName);
		model.addAttribute(AppConstants.CTRL_CFG_OBJID, ctrlCfgObjId);
		model.addAttribute(AppConstants.USER_ID, userName);
		if(RMDCommonUtility.isNullOrEmpty(agtObjId))
		    model.addAttribute(AppConstants.SHOW_DEVICE, false);
		else
		    model.addAttribute(AppConstants.SHOW_DEVICE, true);
		model.addAttribute(AppConstants.IS_CASE_APPLY_CONFIG, true);
		return new ModelAndView(AppConstants.APPLY_CONFIG);
	}

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param : HttpServletRequest request
	 * @throws :RMDWebException
	 * @Description: Displays the Apply Cfg Screen of the RMD application when
	 *               clicked on Apply button from MassApply Config Screen.
	 * 
	 */
	@RequestMapping(AppConstants.REQ_URI_APPLY_EFI_CFG)
	public ModelAndView showEFIApplyConfigScreen(Model model,
			@RequestParam(value = AppConstants.EFI_OBJID) String efiObjId)
			throws RMDWebException {
		try {
			model.addAttribute(AppConstants.EFI_OBJID, efiObjId);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in showCaseApplyConfigScreen method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return new ModelAndView(AppConstants.EFI_APPLY);
	}

	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching controller Configs.
	 * 
	 */

	@RequestMapping(AppConstants.GET_CTRL_CONFIG)
	@ResponseBody
	public Map<String, String> getControllerConfigs() throws RMDWebException {
		Map<String, String> ctrlCfgMap = null;
		try {
			ctrlCfgMap = massApplyCfgService.getControllerConfigs();
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getControllerConfigs method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return ctrlCfgMap;
	}

	/**
	 * @Author :
	 * @return :List<MassApplyCfgVO>
	 * @param :String ctrlCfgObjId,String vehicleObjId,String isCaseMassApplyCFG
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Type EDP.
	 * 
	 */
	@RequestMapping(AppConstants.GET_EDP_CONFIGS)
	@ResponseBody
	public List<MassApplyCfgVO> getEDPConfigs(
			@RequestParam(AppConstants.CTRL_CFG_OBJID) String ctrCfgObjId,
			@RequestParam(value = AppConstants.VEHICLE_OBJID, required = false) String vehicleObjId,
			@RequestParam(value = AppConstants.IS_CASE_MASS_APPLY_CFG, required = false) String isCaseMassApplyCFG,
			final HttpServletRequest request) throws RMDWebException {
		ConfigSearchVO objConfigSearchVO = new ConfigSearchVO();
		List<MassApplyCfgVO> arlEDpConCfgVOs = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String defaultTimezone = EsapiUtil.stripXSSCharacters((String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE));
	String applicationTimezone = EsapiUtil.stripXSSCharacters(RMDCommonUtil.getTimezone(defaultTimezone,
				EsapiUtil.stripXSSCharacters(userVO.getTimeZone())));
		try {
			objConfigSearchVO.setCtrlcfgObjId(ctrCfgObjId);
			objConfigSearchVO.setVehicleObjId(vehicleObjId);
			objConfigSearchVO.setCaseMassApplyCFG(RMDCommonConstants.YES
					.equalsIgnoreCase(isCaseMassApplyCFG) ? true : false);
			objConfigSearchVO.setTimeZone(defaultTimezone);
			objConfigSearchVO.setDefaultTimeZone(applicationTimezone);
			arlEDpConCfgVOs = massApplyCfgService
					.getEDPConfigs(objConfigSearchVO);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getEDPConfigs method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return arlEDpConCfgVOs;

	}

	/**
	 * @Author :
	 * @return :List<MassApplyCfgVO>
	 * @param :String ctrlCfgObjId,String vehicleObjId,String isCaseMassApplyCFG
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Type FFD.
	 * 
	 */
	@RequestMapping(AppConstants.GET_FFD_CONFIGS)
	@ResponseBody
	public List<MassApplyCfgVO> getFFDConfigs(
			@RequestParam(AppConstants.CTRL_CFG_OBJID) String ctrCfgObjId,
			@RequestParam(value = AppConstants.VEHICLE_OBJID, required = false) String vehicleObjId,
			@RequestParam(value = AppConstants.IS_CASE_MASS_APPLY_CFG, required = false) String isCaseMassApplyCFG,
			final HttpServletRequest request) throws RMDWebException {
		ConfigSearchVO objConfigSearchVO = new ConfigSearchVO();
		List<MassApplyCfgVO> arlFFDConCfgVOs = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String defaultTimezone = EsapiUtil.stripXSSCharacters((String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE));
		String applicationTimezone = EsapiUtil.stripXSSCharacters(RMDCommonUtil.getTimezone(defaultTimezone,
				EsapiUtil.stripXSSCharacters(userVO.getTimeZone())));
		try {
			objConfigSearchVO.setCtrlcfgObjId(ctrCfgObjId);
			objConfigSearchVO.setVehicleObjId(vehicleObjId);
			objConfigSearchVO.setCaseMassApplyCFG(RMDCommonConstants.YES
					.equalsIgnoreCase(isCaseMassApplyCFG) ? true : false);
			objConfigSearchVO.setTimeZone(defaultTimezone);
			objConfigSearchVO.setDefaultTimeZone(applicationTimezone);
			arlFFDConCfgVOs = massApplyCfgService
					.getFFDConfigs(objConfigSearchVO);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getEDPConfigs method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return arlFFDConCfgVOs;

	}

	/**
	 * @Author :
	 * @return :List<MassApplyCfgVO>
	 * @param :String ctrlCfgObjId,String vehicleObjId,String isCaseMassApplyCFG
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Type FRD.
	 * 
	 */
	@RequestMapping(AppConstants.GET_FRD_CONFIGS)
	@ResponseBody
	public List<MassApplyCfgVO> getFRDConfigs(
			@RequestParam(AppConstants.CTRL_CFG_OBJID) String ctrCfgObjId,
			@RequestParam(value = AppConstants.VEHICLE_OBJID, required = false) String vehicleObjId,
			@RequestParam(value = AppConstants.IS_CASE_MASS_APPLY_CFG, required = false) String isCaseMassApplyCFG,
			final HttpServletRequest request) throws RMDWebException {
		ConfigSearchVO objConfigSearchVO = new ConfigSearchVO();
		List<MassApplyCfgVO> arlFRDConCfgVOs = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String defaultTimezone =  EsapiUtil.stripXSSCharacters((String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE));
		String applicationTimezone =  EsapiUtil.stripXSSCharacters(RMDCommonUtil.getTimezone(defaultTimezone,
				 EsapiUtil.stripXSSCharacters(userVO.getTimeZone())));
		try {
			objConfigSearchVO.setCtrlcfgObjId(ctrCfgObjId);
			objConfigSearchVO.setVehicleObjId(vehicleObjId);
			objConfigSearchVO.setCaseMassApplyCFG(RMDCommonConstants.YES
					.equalsIgnoreCase(isCaseMassApplyCFG) ? true : false);
			objConfigSearchVO.setTimeZone(defaultTimezone);
			objConfigSearchVO.setDefaultTimeZone(applicationTimezone);
			arlFRDConCfgVOs = massApplyCfgService
					.getFRDConfigs(objConfigSearchVO);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getFRDConfigs method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlFRDConCfgVOs;
	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Types.
	 * 
	 */
	@RequestMapping(AppConstants.GET_MASS_APPLY_CFG_LIST)
	@ResponseBody
	public List<String> getMassApplyCfgList() throws RMDWebException {
		List<String> cfgList = null;
		try {
			cfgList = massApplyCfgService.getMassApplyCfgList();
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getFRDConfigs method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return cfgList;

	}

	/**
	 * @Author :
	 * @return :List<VerifyCfgTempaltesVO>
	 * @param :SelectedCfgTemplatesVO objSelectedCfgTemplatesVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching selected
	 *               Configurations for applying.
	 * 
	 */

	@RequestMapping(AppConstants.VERIFY_CONFIG_TEMPLATES)
	@ResponseBody
	public List<VerifyCfgTemplateVO> verifyConfigTemplates(
			@RequestParam(value = AppConstants.EDP_OBJID, required = false) String edpObjId,
			@RequestParam(value = AppConstants.FFD_OBJID, required = false) String ffdObjId,
			@RequestParam(value = AppConstants.FRD_OBJID, required = false) String frdObjId,
			@RequestParam(value = AppConstants.AHC_OBJID, required = false) String ahcObjId,
			@RequestParam(value = AppConstants.RCI_OBJID, required = false) String rciObjId,
			@RequestParam(value = AppConstants.AGT_OBJID, required = false) String agtObjId,
			@RequestParam(value = AppConstants.EFI_OBJID, required = false) String efiObjId,
			final HttpServletRequest request)
			throws RMDWebException {
		List<VerifyCfgTemplateVO> arlVerifyCfgTemplateVOs = null;
		try {
		    
		    final HttpSession session = request.getSession(false);
            final UserVO userVO = (UserVO) session
                    .getAttribute(AppConstants.ATTR_USER_OBJECT);
            final String defaultTimezone =  EsapiUtil.stripXSSCharacters((String) request
                    .getAttribute(AppConstants.DEFAULT_TIMEZONE));
            String applicationTimezone =  EsapiUtil.stripXSSCharacters(RMDCommonUtil.getTimezone(defaultTimezone,
                     EsapiUtil.stripXSSCharacters(userVO.getTimeZone())));
		    
			arlVerifyCfgTemplateVOs = massApplyCfgService
					.verifyConfigTemplates(EsapiUtil.stripXSSCharacters(edpObjId), EsapiUtil.stripXSSCharacters(ffdObjId), EsapiUtil.stripXSSCharacters(frdObjId),
							EsapiUtil.stripXSSCharacters(efiObjId),EsapiUtil.stripXSSCharacters(ahcObjId),EsapiUtil.stripXSSCharacters(rciObjId),EsapiUtil.stripXSSCharacters(agtObjId),applicationTimezone);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in verifyConfigTemplates method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlVerifyCfgTemplateVOs;
	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :String ctrlCfgObjId
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching software Versions.
	 * 
	 */
	@RequestMapping(AppConstants.GET_ON_BOARD_SOFTWARE_VERSION)
	@ResponseBody
	public List<String> getOnboardSoftwareVersion(
			@RequestParam(value = AppConstants.CTRL_CFG_OBJID) String ctrlCfgObjId)
			throws RMDWebException {
		List<String> arlSftWareVersions = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(ctrlCfgObjId)) {
				arlSftWareVersions = massApplyCfgService
						.getOnboardSoftwareVersion(EsapiUtil.stripXSSCharacters(ctrlCfgObjId));
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getOnboardSoftwareVersion method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlSftWareVersions;
	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :String cfgType, String templateObjId, String ctrlCfgObjId
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 * @Description: This method is Responsible for fetching template versions.
	 * 
	 */
	@RequestMapping(AppConstants.GET_CFG_TEMPLATE_VERSIONS)
	@ResponseBody
	public List<String> getCfgTemplateVersions(
			@RequestParam(value = AppConstants.CFG_FILE) String cfgFile,
			@RequestParam(value = AppConstants.TEMPLATE) String template,
			@RequestParam(value = AppConstants.CTRL_CFG_OBJID) String ctrlCfgObjId)
			throws RMDWebException {
		List<String> arlCfgTemplateVersions = null;
		try {

			if (!RMDCommonUtility.isNullOrEmpty(ctrlCfgObjId)
					&& !RMDCommonUtility.isNullOrEmpty(template)
					&& !RMDCommonUtility.isNullOrEmpty(cfgFile)) {
			arlCfgTemplateVersions = massApplyCfgService
						.getCfgTemplateVersions(EsapiUtil.stripXSSCharacters(cfgFile), EsapiUtil.stripXSSCharacters(template), EsapiUtil.stripXSSCharacters(ctrlCfgObjId));
			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getCfgTemplateVersions method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlCfgTemplateVersions;
	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :AssetSearchVO objAssetSearchVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching specific
	 *               assetNumbers
	 * 
	 */
	@RequestMapping(AppConstants.GET_SPECIFIC_ASSET_NUMBERS)
	@ResponseBody
	public List<String> getSpecificAssetNumbers(
			@RequestParam(value = AppConstants.ASSET_GROUP_NAME) String assetGrpName,
			@RequestParam(value = AppConstants.WS_PARAM_ASSTNUMFROM) String assetNumberFrom,
			@RequestParam(value = AppConstants.WS_PARAM_ASSTNUMTO) String assetNumberTo,
			@RequestParam(value = AppConstants.CTRL_CFG_OBJID) String ctrlCfgObjId,
			@RequestParam(value = AppConstants.CUSTOMER_ID) String customerId)
			throws RMDWebException {
		List<String> arlAssetNumbers = null;
		try {

			if (!RMDCommonUtility.isNullOrEmpty(ctrlCfgObjId)
					&& !RMDCommonUtility.isNullOrEmpty(assetGrpName)
					&& !RMDCommonUtility.isNullOrEmpty(assetNumberFrom)
					&& !RMDCommonUtility.isNullOrEmpty(assetNumberTo)) {
				AssetSearchVO objAssetSearchVO = new AssetSearchVO();
		        	objAssetSearchVO.setAssetFrom(EsapiUtil.stripXSSCharacters(assetNumberFrom));
				objAssetSearchVO.setAssetTo(EsapiUtil.stripXSSCharacters(assetNumberTo));
				objAssetSearchVO.setAssetGroupName(EsapiUtil.stripXSSCharacters(assetGrpName));
				objAssetSearchVO.setCtrlCfgObjId(EsapiUtil.stripXSSCharacters(ctrlCfgObjId));
				objAssetSearchVO.setCustomerId(EsapiUtil.stripXSSCharacters(customerId));
				arlAssetNumbers = massApplyCfgService
						.getSpecificAssetNumbers(objAssetSearchVO);
			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getSpecificAssetNumbers method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlAssetNumbers;
	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :AssetSearchVO objAssetSearchVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for Applying selected configs to
	 *               the assets
	 * 
	 */
	@RequestMapping(AppConstants.APPLY_CONFIG_TEMPLATES)
	@ResponseBody
	public List<String> applyCfgTemplates(
			@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString,
			HttpServletRequest request) throws RMDWebException {
		List<String> arlLogMessages = new ArrayList<String>();
		List<String> userList = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final ObjectMapper mapper = new ObjectMapper();
		String userName = null;
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			ApplyCfgTemplateVO objApplyCfgTemplateVO = mapper.readValue(
					parameterString, ApplyCfgTemplateVO.class);
			userName = userVO.getCmAliasName();
			userList = massApplyCfgService.getMassApplyCfgUsers();
			if (null != userName && userList.contains(userName)) {
				String status = validateMassApplyConfig(objApplyCfgTemplateVO);
				if (AppConstants.SUCCESS.equalsIgnoreCase(status)) {
					objApplyCfgTemplateVO.setUserName(userName);
					objApplyCfgTemplateVO.setUserId(userVO.getUserId());
					arlLogMessages = massApplyCfgService
							.applyCfgTemplates(objApplyCfgTemplateVO);
				} else {
					arlLogMessages.add(status);
				}
			} else {
				arlLogMessages
						.add(AppConstants.MASSAPPLY_CFG_PREVILIGE_IS_NOT_PRESENT);
			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in applyCfgTemplates method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlLogMessages;
	}

	/**
	 * @Author :
	 * @return : String
	 * @param :ApplyCfgTemplateVO objApplyCfgTemplateVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for Vaidating MassApply Config.
	 */

	public String validateMassApplyConfig(
			ApplyCfgTemplateVO objApplyCfgTemplateVO) throws RMDWebException {
		try {
			if (RMDCommonUtility.isNullOrEmpty(objApplyCfgTemplateVO
					.getCtrlCfgObjId())) {
				return AppConstants.ERROR
						+ AppConstants.CTRL_CFG_OBJID_NOT_PROVIDED;
			}

			if (!RMDCommonConstants.ALL.equalsIgnoreCase(objApplyCfgTemplateVO
					.getSearchType())
					&& (null == objApplyCfgTemplateVO.getArlAssetSearchVOs()|| !RMDCommonUtility
							.isCollectionNotEmpty(objApplyCfgTemplateVO
									.getArlAssetSearchVOs()))) {
				return AppConstants.ERROR + AppConstants.UNDERSCORE
						+ AppConstants.ITEMS_ARE_NOT_SELECTED_FOR_APPLYING;

			}

			if (null == objApplyCfgTemplateVO.getCfgTemplateList()
					|| !RMDCommonUtility
							.isCollectionNotEmpty(objApplyCfgTemplateVO
									.getCfgTemplateList())) {
				return AppConstants.ERROR + AppConstants.UNDERSCORE
						+ AppConstants.CFG_TEMPALTES_NOT_PROVIDED;
			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in validateMassApplyConfig method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return AppConstants.SUCCESS;

	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :ApplyEFICfgVO objApplyEFICfgVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for Applying EFI configs to the
	 *               assets
	 * 
	 */
	@RequestMapping(AppConstants.APPLY_EFI_CFG)
	@ResponseBody
	public List<String> applyEFICfg(
			@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString,
			HttpServletRequest request) throws RMDWebException {
		List<String> arlLogMessages = new ArrayList<String>();
		List<String> userList = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final ObjectMapper mapper = new ObjectMapper();
		String userName = null;
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			ApplyEFICfgVO objApplyEFICfgVO = mapper.readValue(EsapiUtil.stripXSSCharacters(parameterString),
					ApplyEFICfgVO.class);
			userName = userVO.getCmAliasName();
			userList = massApplyCfgService.getMassApplyCfgUsers();
			if (null != userName && userList.contains(userName)) {
				String status = validateEFIApplyConfig(objApplyEFICfgVO);
				if (AppConstants.SUCCESS.equalsIgnoreCase(status)) {
					objApplyEFICfgVO.setUserName(userName);
					arlLogMessages = massApplyCfgService
							.applyEFICfg(objApplyEFICfgVO);
				} else {
					arlLogMessages.add(status);
				}
			} else {
				arlLogMessages
						.add(AppConstants.MASSAPPLY_CFG_PREVILIGE_IS_NOT_PRESENT);
			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in applyCfgTemplates method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlLogMessages;
	}

	/**
	 * @Author :
	 * @return :String
	 * @param :ApplyEFICfgVO objApplyEFICfgVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for Validating EFI configs to
	 *               the assets
	 * 
	 */
	public String validateEFIApplyConfig(ApplyEFICfgVO objApplyEFICfgVO)
			throws RMDWebException {

		if (RMDCommonUtility.isNullOrEmpty(objApplyEFICfgVO.getCustomer())) {
			return AppConstants.ERROR + AppConstants.UNDERSCORE
					+ AppConstants.CUSTOMER_ID_NOT_PROVIDED;
		}
		if (RMDCommonUtility.isNullOrEmpty(objApplyEFICfgVO.getAssetGrpName())) {
			return AppConstants.ERROR + AppConstants.UNDERSCORE
					+ AppConstants.ASSET_GROUP_NAME_NOT_PROVIDED;
		}
		if (RMDCommonUtility.isNullOrEmpty(objApplyEFICfgVO
				.getFromAssetNumber())) {
			return AppConstants.ERROR + AppConstants.UNDERSCORE
					+ AppConstants.FROM_ASSET_NUMBER_NOT_PROVIDED;
		}
		if (RMDCommonUtility.isNullOrEmpty(objApplyEFICfgVO.getToAssetNumber())) {
			return AppConstants.ERROR + AppConstants.UNDERSCORE
					+ AppConstants.TO_ASSET_NUMBER_NOT_PROVIDED;
		}
		if (null == objApplyEFICfgVO.getObjVerifyCfgTemplateVO()) {
			return AppConstants.ERROR + AppConstants.UNDERSCORE
					+ AppConstants.CFG_TEMPALTES_NOT_PROVIDED;
		}
		if (objApplyEFICfgVO.isChangeVersion()
				&& RMDCommonUtility.isNullOrEmpty(objApplyEFICfgVO
						.getFromVersion())) {
			return AppConstants.ERROR + AppConstants.UNDERSCORE
					+ AppConstants.VERSION_NUMBER;

		}

		return AppConstants.SUCCESS;
	}
	
	/**
     * @Author :
     * @return :List<MassApplyCfgVO>
     * @param :String ctrlCfgObjId,String vehicleObjId,String isCaseMassApplyCFG
     * @throws :RMDWebException
     * @Description: This method is Responsible for fetching template of
     *               Type AHC.
     * 
     */
    @RequestMapping(AppConstants.GET_AHC_CONFIGS)
    @ResponseBody
    public List<MassApplyCfgVO> getAHCConfigs(
            @RequestParam(AppConstants.CTRL_CFG_OBJID) String ctrCfgObjId,
            @RequestParam(value = AppConstants.VEHICLE_OBJID, required = false) String vehicleObjId,
            @RequestParam(value = AppConstants.IS_CASE_MASS_APPLY_CFG, required = false) String isCaseMassApplyCFG,
            final HttpServletRequest request) throws RMDWebException {
        ConfigSearchVO objConfigSearchVO = new ConfigSearchVO();
        List<MassApplyCfgVO> arlAHCConCfgVOs = null;
        final HttpSession session = request.getSession(false);
        final UserVO userVO = (UserVO) session
                .getAttribute(AppConstants.ATTR_USER_OBJECT);
        final String defaultTimezone =  EsapiUtil.stripXSSCharacters((String) request
                .getAttribute(AppConstants.DEFAULT_TIMEZONE));
        String applicationTimezone =  EsapiUtil.stripXSSCharacters(RMDCommonUtil.getTimezone(defaultTimezone,
                 EsapiUtil.stripXSSCharacters(userVO.getTimeZone())));
        try {
            objConfigSearchVO.setCtrlcfgObjId(ctrCfgObjId);
            objConfigSearchVO.setVehicleObjId(vehicleObjId);
            objConfigSearchVO.setCaseMassApplyCFG(RMDCommonConstants.YES
                    .equalsIgnoreCase(isCaseMassApplyCFG) ? true : false);
            objConfigSearchVO.setTimeZone(defaultTimezone);
            objConfigSearchVO.setDefaultTimeZone(applicationTimezone);
            arlAHCConCfgVOs = massApplyCfgService
                    .getAHCConfigs(objConfigSearchVO);
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getAHCConfigs method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return arlAHCConCfgVOs;
    }
    /**
	 * @Author :
	 * @return :List<MassApplyCfgVO>
	 * @param :String ctrlCfgObjId,String vehicleObjId,String isCaseMassApplyCFG
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Type RCI.
	 * 
	 */
	@RequestMapping(AppConstants.GET_RCI_CONFIGS)
	@ResponseBody
	public List<MassApplyCfgVO> getRCIConfigs(
			@RequestParam(AppConstants.CTRL_CFG_OBJID) String ctrCfgObjId,
			@RequestParam(value = AppConstants.VEHICLE_OBJID, required = false) String vehicleObjId,
			@RequestParam(value = AppConstants.IS_CASE_MASS_APPLY_CFG, required = false) String isCaseMassApplyCFG,
			final HttpServletRequest request) throws RMDWebException {
		ConfigSearchVO objConfigSearchVO = new ConfigSearchVO();
		List<MassApplyCfgVO> arlRCIConCfgVOs = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String defaultTimezone = EsapiUtil.stripXSSCharacters((String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE));
	String applicationTimezone = EsapiUtil.stripXSSCharacters(RMDCommonUtil.getTimezone(defaultTimezone,
				EsapiUtil.stripXSSCharacters(userVO.getTimeZone())));
		try {
			objConfigSearchVO.setCtrlcfgObjId(ctrCfgObjId);
			objConfigSearchVO.setVehicleObjId(vehicleObjId);
			objConfigSearchVO.setCaseMassApplyCFG(RMDCommonConstants.YES
					.equalsIgnoreCase(isCaseMassApplyCFG) ? true : false);
			objConfigSearchVO.setTimeZone(defaultTimezone);
			objConfigSearchVO.setDefaultTimeZone(applicationTimezone);
			arlRCIConCfgVOs = massApplyCfgService
					.getRCIConfigs(objConfigSearchVO);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getRCIConfigs method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return arlRCIConCfgVOs;

	}
	
	/**
     * @Author :
     * @return :List<String>
     * @param :
     * @throws :RMDWebException
     * @Description: This method is Responsible for fetching AGT template Device list
     * 
     */
    @RequestMapping(AppConstants.GET_AGT_DEVICE_LIST)
    @ResponseBody
    public List<String> getAGTDeviceList() throws RMDWebException {
        List<String> cfgList = null;
        try {
            cfgList = massApplyCfgService.getAGTDeviceList();
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getAGTDeviceList method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return cfgList;

    }
}
