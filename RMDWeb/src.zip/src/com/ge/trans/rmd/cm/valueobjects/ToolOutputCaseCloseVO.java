package com.ge.trans.rmd.cm.valueobjects;

public class ToolOutputCaseCloseVO {
	
	private String assetnumber; 
	private String groupName; 
	private String customerId;	  
	private String caseType;
	private String caseId; 								  
	private String rxId; 
	private String closeoption;
	private String ruleDefId; 
	private String rxTitle; 
	private String toolid;
	private String toolObjId;
	
	public String getAssetnumber() {
		return assetnumber;
	}
	public void setAssetnumber(String assetnumber) {
		this.assetnumber = assetnumber;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getRxId() {
		return rxId;
	}
	public void setRxId(String rxId) {
		this.rxId = rxId;
	}
	public String getCloseoption() {
		return closeoption;
	}
	public void setCloseoption(String closeoption) {
		this.closeoption = closeoption;
	}
	public String getRuleDefId() {
		return ruleDefId;
	}
	public void setRuleDefId(String ruleDefId) {
		this.ruleDefId = ruleDefId;
	}
	public String getToolid() {
		return toolid;
	}
	public void setToolid(String toolid) {
		this.toolid = toolid;
	}
	public String getRxTitle() {
		return rxTitle;
	}
	public void setRxTitle(String rxTitle) {
		this.rxTitle = rxTitle;
	} 
	/**
	 * @return the toolObjId
	 */
	public String getToolObjId() {
		return toolObjId;
	}
	/**
	 * @param toolObjId the toolObjId to set
	 */
	public void setToolObjId(String toolObjId) {
		this.toolObjId = toolObjId;
	}
	  
}
