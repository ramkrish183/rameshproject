/**
 * ============================================================

 * Classification		: GE Confidential
 * File 				: MassApplyCfgVO.java
 * Description 			:
 * Package 				: com.ge.trans.rmd.cm.valueobjects;
 * Author 				: Capgemini India.
 * Last Edited By 		:
 * Version 				: 1.0
 * Created on 			:
 * History				:
 * Modified By 			: Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.valueobjects;
/*******************************************************************************
 * 
 * @Author 			:
 * @Version 		: 1.0
 * @Date Created	:
 * @Date Modified 	:
 * @Modified By 	:
 * @Contact 		:
 * @Description 	:This is plain POJO class which contains queueId,queueName
 *             		 Declarations along with their respective getters and setters.
 * @History 		:
 * 
 ******************************************************************************/
public class MassApplyCfgVO {

	private String objId;
	private String template;
	private String version;
	private String title;
	private String cfgStatus;
	private String vehicleStatus;
	private String vehicleStatusDate;
	private String offboardStatus;
	private String onBoardStatus;
	private String onBoardStatusDate;
	private String device;
	
	
	public String getObjId() {
		return objId;
	}
	public void setObjId(String objId) {
		this.objId = objId;
	}
	public String getTemplate() {
		return template;
	}
	public void setTemplate(String template) {
		this.template = template;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCfgStatus() {
		return cfgStatus;
	}
	public void setCfgStatus(String cfgStatus) {
		this.cfgStatus = cfgStatus;
	}
	public String getVehicleStatus() {
		return vehicleStatus;
	}
	public void setVehicleStatus(String vehicleStatus) {
		this.vehicleStatus = vehicleStatus;
	}
	public String getVehicleStatusDate() {
		return vehicleStatusDate;
	}
	public void setVehicleStatusDate(String vehicleStatusDate) {
		this.vehicleStatusDate = vehicleStatusDate;
	}
    public String getOffboardStatus() {
        return offboardStatus;
    }
    public void setOffboardStatus(String offboardStatus) {
        this.offboardStatus = offboardStatus;
    }
    public String getOnBoardStatus() {
        return onBoardStatus;
    }
    public void setOnBoardStatus(String onBoardStatus) {
        this.onBoardStatus = onBoardStatus;
    }
    public String getOnBoardStatusDate() {
        return onBoardStatusDate;
    }
    public void setOnBoardStatusDate(String onBoardStatusDate) {
        this.onBoardStatusDate = onBoardStatusDate;
    }
    public String getDevice() {
        return device;
    }
    public void setDevice(String device) {
        this.device = device;
    }
    
	
}
