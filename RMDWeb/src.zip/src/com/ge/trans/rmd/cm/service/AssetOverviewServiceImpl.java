package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.AssetLastDownloadStatusVO;
import com.ge.trans.rmd.cm.valueobjects.AssetLastFaultStatusVO;
import com.ge.trans.rmd.cm.valueobjects.AssetLocatorResponseVO;
import com.ge.trans.rmd.cm.valueobjects.SolutionDetailVO;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetLocRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetLocatorResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetServicesResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.Fleet;
import com.ge.trans.rmd.services.assets.valueobjects.LastDownLoadStatusResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.LastFaultStatusResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.Model;
import com.ge.trans.rmd.services.assets.valueobjects.VehicleCommStatusResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CasesRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.SolutionInfoType;
import com.ge.trans.rmd.services.notes.valueobjects.NotesInfo;
import com.ge.trans.rmd.services.notes.valueobjects.NotesRequestType;
import com.ge.trans.rmd.services.notes.valueobjects.NotesResponseType;
import com.ge.trans.rmd.utilities.AppSecUtil;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

/*******************************************************************************
 * 
 * @Author : IgatePatni
 * @Version : 1.0
 * @Date Created : Feb 01, 2012
 * @Date Modified: Feb 21, 2012
 * @Modified By :
 * @Contact :
 * @Description : Service class which will invoke the web service to get the
 *              asset details. Convert the web service response(JAXB) to
 *              AssetOverviewBean which will contain the details about the asset
 *              like locomotive information, cases, notes etc, and Its using to
 *              put the notes information to the web service for an asset
 *              number.
 * 
 * @History :
 * 
 ******************************************************************************/
@Service
public class AssetOverviewServiceImpl extends RMDBaseServiceImpl implements
		AssetOverviewService {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	private WebServiceInvoker webServiceInvoker;
	@Autowired
	private CachedService cachedService;

	/**
	 * @Author : IgatePatni
	 * @param : assetNumber
	 * @return : assetOverviewBean
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description: This method invokes the web service to get the asset
	 *               information. Convert the web service response(JAXB) to
	 *               assetOverviewBean which will contain the details about the
	 *               asset,customer,model,fleet,roadIntial.
	 */
	@Override
	public AssetOverviewBean getAssets(final AssetOverviewBean assetOverviewBean)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("AssetOverviewServiceImpl : Inside getAssets() method::START");
		final Map<String, String> qParamAsset = new LinkedHashMap<String, String>();
		final Map<String, String> headerParams = getHeaderMap(assetOverviewBean);

		try {
			AssetsRequestType objAssetsReqType=new AssetsRequestType();
			objAssetsReqType.setLanguage(headerParams.get(AppConstants.USER_LANGUAGE));
			objAssetsReqType.setCustomerId(assetOverviewBean.getCustomer());
			objAssetsReqType.setAssetNumber(assetOverviewBean.getAsset());
			objAssetsReqType.setAssetGrpName(assetOverviewBean.getAssetGroup());
			final AssetResponseType[] assetResponseType = (AssetResponseType[]) webServiceInvoker
					.post(ServiceConstants.GET_ASSETS, objAssetsReqType, AssetResponseType[].class);
			if(null != assetResponseType && assetResponseType.length > 0){
				
				for(AssetResponseType assetResponse: assetResponseType){
					if(assetResponse.getAssetNumber().equalsIgnoreCase(assetOverviewBean.getAsset())
							&& assetResponse.getCustomerID().equalsIgnoreCase(assetOverviewBean.getCustomer())
							&& assetResponse.getAssetGroupName().equalsIgnoreCase(assetOverviewBean.getAssetGroup())
							){
						assetOverviewBean.setRoadIntial(assetResponse.getAssetGroupName());
						assetOverviewBean.setCustomer(assetResponse.getCustomerName());
						assetOverviewBean.setAsset(assetResponse.getAssetNumber());
						assetOverviewBean.setModel(assetResponse.getModel());
						assetOverviewBean.setFleet(assetResponse.getFleet());
						assetOverviewBean.setDsControllerConfig(assetResponse.getDsControllerConfig());
						assetOverviewBean.setControllerConfig(assetResponse.getControllerCfg());
						assetOverviewBean.setFleetId(assetResponse.getFleetId());
						assetOverviewBean.setModelId(assetResponse.getModelId());
						break;
					}
				}
			}

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getAssets method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		rmdWebLogger
				.debug("AssetOverviewServiceImpl : Inside getAssets() method::END");
		return assetOverviewBean;
	}

	/**
	 * @Author : IgatePatni
	 * @param : assetNumber, userVO
	 * @return : notesList
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description: This method invokes the web service to get the notes
	 *               information of given asset number. Convert the web service
	 *               response(JAXB) to notesBean which will contain the details
	 *               about the
	 *               assetNumber,notesDescription,createdBy,creationDate.
	 */
	@Override
	public List<NotesBean> getNotes(final AssetOverviewBean assetOverviewBean, final String userCustomer)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("AssetOverviewServiceImpl : Inside getNotes() method:::::START");
		final Map<String, String> qParamAsset = new LinkedHashMap<String, String>();
		final Map<String, String> headerParams = getHeaderMap(assetOverviewBean);
		final List<NotesBean> notesList = new ArrayList<NotesBean>();
		String creationDate = null;
		DateFormat dateParser = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		dateParser.setTimeZone(TimeZone.getTimeZone(AppConstants.DEFAULT_TIME_ZONE));
		try {

			qParamAsset.put(AppConstants.WS_PARAM_ASSTNUMFROM,
					assetOverviewBean.getAsset());
			qParamAsset.put(AppConstants.WS_PARAM_ASSTNUMTO,
					assetOverviewBean.getAsset());
			qParamAsset.put(AppConstants.WS_PARAM_ASSTGRP,
					assetOverviewBean.getAssetGroup());
			qParamAsset.put(AppConstants.WS_PARAM_CUSTID,
					assetOverviewBean.getCustomer());
			qParamAsset.put(AppConstants.WS_PARAM_NOTETYPE,
					assetOverviewBean.getNotesType());
			qParamAsset.put(AppConstants.IS_NON_GPOC_USER,
					assetOverviewBean.getIsNonGPOCUser());

			final NotesResponseType[] notesResArr = (NotesResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_NOTES, null, qParamAsset,
							headerParams, NotesResponseType[].class);
			NotesBean notesBean;
			DateFormat zoneFormater = new SimpleDateFormat(
					AppConstants.DATE_FORMAT_24HRS);
            if (cachedService.getSDCustLookup().get(userCustomer) != null
                    && cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
                    && !cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim().equals("")) {
              zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat());
            }
			final TimeZone firstTime = TimeZone.getTimeZone(assetOverviewBean
					.getUserTimeZone());
			if (null != notesResArr) {
				for (NotesResponseType notesResponseType : notesResArr) {
					notesBean = new NotesBean();
					notesBean
							.setAssetNumber(notesResponseType.getAssetNumber());
					notesBean.setNoteDescription(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(notesResponseType
							.getNoteDescription())));
					notesBean.setCreatedBy(notesResponseType.getCreatedBy());
					if (null != notesResponseType.getCreationDate()) {
						creationDate = notesResponseType
								.getCreationDate();
						
						zoneFormater.setTimeZone(firstTime);

						notesBean.setCreationDate(zoneFormater
								.format(dateParser.parse(creationDate)));
					}

					notesList.add(notesBean);
				}
			}

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getNotes method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		rmdWebLogger
				.debug("AssetOverviewServiceImpl : Inside getNotes() method:::::END");
		return notesList;
	}

	/**
	 * @Author : IgatePatni
	 * @param : assetNumber, solutionStatus
	 * @return : casesList
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description: This method invokes the web service to get the cases
	 *               information of given status of asset number . Convert the
	 *               web service response(JAXB) to caseBean which will contain
	 *               the details about the caseId,caseTitle,caseStatus,urgency.
	 */
	@Override
	public List<CaseBean> getCases(final AssetOverviewBean assetOverviewBean, final String userCustomer)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("AssetOverviewServiceImpl : Inside getCases() method:::STARTT");
		/*final Map<String, String> qParamAsset = new LinkedHashMap<String, String>();*/
		final Map<String, String> headerParams = getHeaderMap(assetOverviewBean);
		final List<CaseBean> casesList = new ArrayList<CaseBean>();
		String age = null;
		CasesRequestType objCasesReqType=new CasesRequestType();
		try {

			DateFormat zoneFormater = new SimpleDateFormat(
					AppConstants.DATE_FORMAT_24HRS);
			if (cachedService.getSDCustLookup().get(userCustomer) != null
                    && cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
                    && !cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim().equals("")) {
              zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat());
            }
			final TimeZone firstTime = TimeZone.getTimeZone(assetOverviewBean
					.getUserTimeZone());
			zoneFormater.setTimeZone(firstTime);
			
			objCasesReqType.setAssetNumber(assetOverviewBean.getAsset());
			objCasesReqType.setAssetGrName(assetOverviewBean.getAssetGroup());
			objCasesReqType.setCustomerId(assetOverviewBean.getCustomer());
			objCasesReqType.setUserLanguage(assetOverviewBean.getUserLanguage());
			objCasesReqType.setSolutionStatus(AppConstants.STATUS_OPEN);
			final CaseResponseType[] caseResArr = (CaseResponseType[]) webServiceInvoker
					.post(ServiceConstants.CASES_SERVICE_LITE_GETDELCASES, objCasesReqType,
							CaseResponseType[].class);
			CaseBean caseBean;
			SolutionDetailVO solutionDetailVO;

			for (CaseResponseType caseResponseType : caseResArr) {
				caseBean = new CaseBean();
				solutionDetailVO = new SolutionDetailVO();
				caseBean.setAssetNumber(caseResponseType.getAssetNumber());
				caseBean.setCaseStatus(caseResponseType.getCaseInfo().getCaseStatus());
				if (caseResponseType.getCaseInfo() != null) {
					caseBean.setCaseId(caseResponseType.getCaseInfo()
							.getCaseID());
					caseBean.setCaseTitle(caseResponseType.getCaseInfo()
							.getCaseTitle());
				}
				/*
				 * Getting the data related to solution for status section of
				 * Asset Overview-Start
				 */
				final List<SolutionInfoType> lsSolutionInfo = caseResponseType
						.getSolutionInfo();
				for (SolutionInfoType eachSolution : lsSolutionInfo) {
					solutionDetailVO.setSolutionID(eachSolution
							.getSolutionCaseID());
					solutionDetailVO.setStrSolutionDelvDt(zoneFormater
							.format(eachSolution.getSolutionDelvDate()
									.toGregorianCalendar().getTime()));
					solutionDetailVO.setSolutionStatus(eachSolution
							.getSolutionStatus());
					solutionDetailVO.setSolutionTitle(AppSecUtil
							.decodeString(eachSolution
							.getSolutionTitle()));
					solutionDetailVO.setEstmTimeRepair(eachSolution
							.getEstmRepTime());
					solutionDetailVO.setLocomotiveImpact(AppSecUtil
							.decodeString(eachSolution
							.getLocomotiveImpact()));
					solutionDetailVO.setUrgRepair(eachSolution.getUrgency());
					solutionDetailVO.setSolutionNotes(AppSecUtil
							.decodeString(eachSolution.getSolutionNotes()));

					age = RMDCommonUtil.calculateAge(eachSolution
							.getSolutionDelvDate().toGregorianCalendar(),
							new GregorianCalendar(),assetOverviewBean
							.getUserTimeZone());
				}
				caseBean.setSolutionInfo(solutionDetailVO);
				caseBean.setAge(age);
				/*
				 * Getting the data related to solution for status section of
				 * Asset Overview-End
				 */
				caseBean.setUrgency(caseResponseType.getUrgency());
				casesList.add(caseBean);

			}

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCases method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		rmdWebLogger
				.debug("AssetOverviewServiceImpl : Inside getCases() method:::END");
		return casesList;
	}

	/**
	 * @Author : IgatePatni
	 * @param : assetNumber, userVO, assetOverviewBean
	 * @return : assetOverviewBean
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description: This method invokes the web service to get the information
	 *               of last time status of fault, faultReset,
	 *               healthCheck,aliveMessage sent of asset number. Convert the
	 *               web service response(JAXB) to assetOverviewBean which will
	 *               contain the details about the latest time of fault,
	 *               faultReset, healthCheck,aliveMessage.
	 */
	@Override
	public AssetOverviewBean getVehicleCommStatus(
			final AssetOverviewBean assetOverviewBean, final String userCustomer) throws RMDWebException,
			Exception {
		rmdWebLogger
				.debug("AssetOverviewServiceImpl : Inside getVehicleCommStatus() method::START");
		final Map<String, String> qParamAsset = new LinkedHashMap<String, String>();
		final Map<String, String> headerParams = getHeaderMap(assetOverviewBean);

		try {

			qParamAsset.put(AppConstants.WS_PARAM_ASSTNUM,
					assetOverviewBean.getAsset());
			qParamAsset.put(AppConstants.WS_PARAM_ASSTGRP,
					assetOverviewBean.getAssetGroup());
			qParamAsset.put(AppConstants.WS_PARAM_CUSTID,
					assetOverviewBean.getCustomer());

			final VehicleCommStatusResponseType[] vehiclComStatResp = (VehicleCommStatusResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_VEHICLECOMMSTATUS, null,
							qParamAsset, headerParams,
							VehicleCommStatusResponseType[].class);

			DateFormat zoneFormater = new SimpleDateFormat(
					AppConstants.DATE_FORMAT_24HRS);
			if (cachedService.getSDCustLookup().get(userCustomer) != null
					&& cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
					&& !cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim().equals("")) {
				zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat());
			}
			final TimeZone firstTime = TimeZone.getTimeZone(assetOverviewBean
					.getUserTimeZone());
			zoneFormater.setTimeZone(firstTime);

			if (null != vehiclComStatResp[0].getLastFaultReceivedTime()) {

				assetOverviewBean.setLastFaultReceived(zoneFormater
						.format(vehiclComStatResp[0].getLastFaultReceivedTime()
								.toGregorianCalendar().getTime()));
			}
			if (null != vehiclComStatResp[0].getLastFaultResetTime()) {
				assetOverviewBean.setLastFaultResetTime(zoneFormater
						.format(vehiclComStatResp[0].getLastFaultResetTime()
								.toGregorianCalendar().getTime()));
			}
			if (null != vehiclComStatResp[0].getLastHealthChkRequestTime()) {
				assetOverviewBean.setLastHealthCheckResponse(zoneFormater
						.format(vehiclComStatResp[0]
								.getLastHealthChkRequestTime()
								.toGregorianCalendar().getTime()));
			}
			if (null != vehiclComStatResp[0].getLastKeepAliveMsgRevdTime()) {
				assetOverviewBean.setLastKeepAliveMsgReceived(zoneFormater
						.format(vehiclComStatResp[0]
								.getLastKeepAliveMsgRevdTime()
								.toGregorianCalendar().getTime()));
			}
			if (null != vehiclComStatResp[0].getControllerConfig()) {
				assetOverviewBean.setControllerConfig(vehiclComStatResp[0]
						.getControllerConfig());
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getVehicleCommStatus method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		rmdWebLogger
				.debug("AssetOverviewServiceImpl : Inside getVehicleCommStatus() method::END");
		return assetOverviewBean;
	}

	/**
	 * @Author : IgatePatni
	 * @param : notes
	 * @param : assetNumber
	 * @param : userName
	 * @return : String
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description: This method invokes the web service to put the information
	 *               of notes of asset number.
	 */
	@Override
	public String addNotes(final NotesBean notesBean) throws RMDWebException,
			Exception {
		final Map<String, String> headerParams = getHeaderMap(notesBean);
		final NotesRequestType notesRequestType = new NotesRequestType();
		final NotesInfo notesInfo = new NotesInfo();
		String returnStr = AppConstants.FAILURE;
		try {

			if (notesBean.getNotesType() != null
					&& notesBean.getNotesType().equals(
							AppConstants.LOCOMOTIVE_NOTE)) {
				notesRequestType.setFromPage(AppConstants.LOCO);
			} else {
				notesRequestType.setFromPage(AppConstants.MENU);
			}
			notesRequestType.setSticky(AppConstants.NO);
			notesRequestType.setFromAsset(notesBean.getAssetNumber());
			notesRequestType.setToAsset(notesBean.getAssetNumber());
			notesRequestType.setNotes(AppSecUtil.htmlEscaping(notesBean.getNoteDescription()));
			notesRequestType.setNotesInfo(notesInfo);
			notesRequestType.setAssetGrpName(notesBean.getAssetGroup());
			notesRequestType.setCustomerID(notesBean.getCustomerId());
			webServiceInvoker.put(ServiceConstants.POST_NOTES,
					notesRequestType, headerParams);
			returnStr = AppConstants.SUCCESS;
		} catch (RMDWebException e) {
			rmdWebLogger.error("Exception occured in addNotes() method ", e);
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				returnStr = AppConstants.FAILURE;
			} else {
				throw e;
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in addNotes method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return returnStr;
	}

	/**
	 * @Author : IgatePatni
	 * @param :
	 * @return : AssetLocatorResponseVO
	 * @throws RMDWebException
	 * 
	 * @Description: This method invokes the web service to get the
	 *               Latitude,Longitude and max occurrence time of the asset
	 */
	@Override
	
	
	
	public AssetLocatorResponseVO getAssetLocation(
			final AssetOverviewBean overviewBean, final String userCustomer) throws RMDWebException,Exception {
		
		rmdWebLogger.debug("AssetOverviewServiceImpl : Inside getAssetLocation() method::START");
		final AssetLocatorResponseVO assetLocatorBean = new AssetLocatorResponseVO();
		AssetLocRequestType objAssetLocReqType = new AssetLocRequestType();
		DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		if (cachedService.getSDCustLookup().get(userCustomer) != null
                && cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
                && !cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim().equals("")) {
          zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat());
        }
		final TimeZone firstTime = TimeZone.getTimeZone(overviewBean.getUserTimeZone());
		zoneFormater.setTimeZone(firstTime);
		
		try {
			if (null != overviewBean) {			
				objAssetLocReqType.setCustomerId(overviewBean.getCustomer());
				objAssetLocReqType.setAssetNumber(overviewBean.getAsset());
				objAssetLocReqType.setAssetGrpName(overviewBean.getAssetGroup());
				objAssetLocReqType.setLastFault(overviewBean.isLastFault());
			}
			objAssetLocReqType.setScreenName("ASSET_OVERVIEW");
			final AssetLocatorResponseType[] arrAssetLocatorResponse = (AssetLocatorResponseType[]) webServiceInvoker.post(
					ServiceConstants.GET_ASSET_FAULT_LOCATION, objAssetLocReqType,
					AssetLocatorResponseType[].class);
			
			if (arrAssetLocatorResponse != null && arrAssetLocatorResponse.length > 0) {
				final AssetLocatorResponseType assetLocatorResponse = arrAssetLocatorResponse[0];
				if (null != assetLocatorResponse.getAssetNumber()) {
					assetLocatorBean.setAssetNumber(assetLocatorResponse.getAssetNumber());
				}
				if (null != assetLocatorResponse.getLatitude()) {
					assetLocatorBean.setLatitude(assetLocatorResponse.getLatitude());
				}
				if (null != assetLocatorResponse.getLongitude()) {
					assetLocatorBean.setLongitude(assetLocatorResponse.getLongitude());
				}
				if (null != assetLocatorResponse.getLatlonsource()) {
					assetLocatorBean.setLatlonSource(assetLocatorResponse.getLatlonsource());
				}
				if (null != assetLocatorResponse.getLatlonDate()) {
					assetLocatorBean.setLatlonDate(zoneFormater.format(assetLocatorResponse
							.getLatlonDate().toGregorianCalendar().getTime()));
				}
				if (null != assetLocatorResponse.getMaxOccurTime()) {
					assetLocatorBean.setMaxOccurTime(RMDCommonUtility
							.convertXMLDateToString(assetLocatorResponse.getMaxOccurTime()));
				}	
				
				AssetLastFaultStatusVO assetLastFaultStatusVO = new AssetLastFaultStatusVO();
				if (null != assetLocatorResponse.getLstEOAFaultHeader()) {					
					assetLastFaultStatusVO.setLstEOAFault(zoneFormater.format(assetLocatorResponse
								.getLstEOAFaultHeader().toGregorianCalendar().getTime()));	
				}
				
				if (null != assetLocatorResponse.getLstPPATSMsgHeader()) {					
					assetLastFaultStatusVO.setLstPPATSMsg(zoneFormater.format(assetLocatorResponse
								.getLstPPATSMsgHeader().toGregorianCalendar().getTime()));
				}
				if (null != assetLocatorResponse.getLstESTPDownloadHeader()) {					
					assetLastFaultStatusVO.setLstESTPDownload(zoneFormater.format(assetLocatorResponse
								.getLstESTPDownloadHeader().toGregorianCalendar().getTime()));					
				}
				
				assetLocatorBean.setAssetlastFaultStatusVo(assetLastFaultStatusVO);								
				
				AssetOverviewBean assetOverviewBean = new AssetOverviewBean();
				
				if (assetLocatorResponse.getDtLastFaultResetTime() != null
						&& !assetLocatorResponse.getDtLastFaultResetTime().toString().isEmpty()) {
					assetOverviewBean.setLastFaultResetTime(zoneFormater.format(assetLocatorResponse
							.getDtLastFaultResetTime().toGregorianCalendar().getTime()));
				}
				
				if (assetLocatorResponse.getDtLastFaultReserved() != null
						&& !assetLocatorResponse.getDtLastFaultReserved().toString().isEmpty()) {
					assetOverviewBean.setLastFaultReceived(zoneFormater.format(assetLocatorResponse
							.getDtLastFaultReserved().toGregorianCalendar().getTime()));
				}
				
				if (assetLocatorResponse.getDtLastHealthChkRequest() != null
						&& !assetLocatorResponse.getDtLastHealthChkRequest().toString().isEmpty()) {
					assetOverviewBean.setLastHealthCheckResponse(zoneFormater.format(assetLocatorResponse
							.getDtLastHealthChkRequest().toGregorianCalendar().getTime()));
				}
				
				if (assetLocatorResponse.getDtLastKeepAliveMsgRevd() != null
						&& !assetLocatorResponse.getDtLastKeepAliveMsgRevd().toString().isEmpty()) {
					assetOverviewBean.setLastKeepAliveMsgReceived(zoneFormater.format(assetLocatorResponse
							.getDtLastKeepAliveMsgRevd().toGregorianCalendar().getTime()));
				}				
				
				assetLocatorBean.setAssetOverviewBean(assetOverviewBean);	
			
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getAssetLocation() method ", ex);
			throw ex;
		}
		rmdWebLogger.debug("AssetOverviewServiceImpl : Inside getAssetLocation() method::END");
		return assetLocatorBean;
	}

	/**
	 * @Author : IgatePatni
	 * @param :
	 * @return : AssetLocatorResponseVO
	 * @throws RMDWebException
	 * 
	 * @Description: This method will fetch the last download status of the
	 *               asset
	 */
	@Override
	public AssetLastDownloadStatusVO getDownloadStatus(
			final AssetOverviewBean assetOverviewBean, final String userCustomer) throws RMDWebException,
			Exception {
		rmdWebLogger
				.debug("AssetOverviewServiceImpl : Inside getDownloadStatus() method::START");
		final AssetLastDownloadStatusVO lstDownloadStatVO = new AssetLastDownloadStatusVO();
		final Map<String, String> queryParamsMap = new HashMap<String, String>();
		try {
			if (null != assetOverviewBean) {

				queryParamsMap.put(AppConstants.ASSET_NUMBER,
						assetOverviewBean.getAsset());// Modified by Rajesh for
				// fleet view basic
				// story
				queryParamsMap.put(AppConstants.CUSTOMER_ID,
						assetOverviewBean.getCustomer());
				queryParamsMap.put(AppConstants.ASSET_GROUP_NAME,
						assetOverviewBean.getAssetGroup());
				queryParamsMap.put(AppConstants.WS_PARAM_DAYS,
						assetOverviewBean.getNoDays());
			}
		

			final LastDownLoadStatusResponseType lstDownloadStatResp = (LastDownLoadStatusResponseType) webServiceInvoker
					.get(ServiceConstants.GET_LAST_DOWNLOAD_STATUS, null,
							queryParamsMap, null,
							LastDownLoadStatusResponseType.class);
			if (lstDownloadStatResp != null
					&& !lstDownloadStatResp.toString().isEmpty()) {
				DateFormat zoneFormater = new SimpleDateFormat(
						AppConstants.DATE_FORMAT_24HRS);
				if (cachedService.getSDCustLookup().get(userCustomer) != null
	                    && cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
	                    && !cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim().equals("")) {
	              zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat());
	            }
				final TimeZone firstTime = TimeZone
						.getTimeZone(assetOverviewBean.getUserTimeZone());
				zoneFormater.setTimeZone(firstTime);
				if (lstDownloadStatResp.getLstDownloadTm() != null
						&& !lstDownloadStatResp.getLstDownloadTm().toString()
								.isEmpty()) {

					lstDownloadStatVO.setLstDownloadTm(zoneFormater
							.format(lstDownloadStatResp.getLstDownloadTm()
									.toGregorianCalendar().getTime()));
				}
				lstDownloadStatVO.setLstDownloadHeader(lstDownloadStatResp
						.getLstDownloadHeader());
				lstDownloadStatVO.setState(lstDownloadStatResp.getState());
				lstDownloadStatVO.setStateHeader(lstDownloadStatResp
						.getStateHeader());
				lstDownloadStatVO.setVax(lstDownloadStatResp.getVax());
				if (lstDownloadStatResp.getVaxDt() != null
						&& !lstDownloadStatResp.getVaxDt().toString().isEmpty()) {
					lstDownloadStatVO.setVaxDt(zoneFormater
							.format(lstDownloadStatResp.getVaxDt()
									.toGregorianCalendar().getTime()));
				}
				lstDownloadStatVO.setVaxHeader(lstDownloadStatResp
						.getVaxHeader());
				lstDownloadStatVO.setEgu(lstDownloadStatResp.getEgu());
				if (lstDownloadStatResp.getEguDt() != null
						&& !lstDownloadStatResp.getEguDt().toString().isEmpty()) {
					lstDownloadStatVO.setEguDt(zoneFormater
							.format(lstDownloadStatResp.getEguDt()
									.toGregorianCalendar().getTime()));
				}
				lstDownloadStatVO.setEguHeader(lstDownloadStatResp
						.getEguHeader());
				lstDownloadStatVO.setInc(lstDownloadStatResp.getInc());
				if (lstDownloadStatResp.getIncDt() != null
						&& !lstDownloadStatResp.getIncDt().toString().isEmpty()) {
					lstDownloadStatVO.setIncDt(zoneFormater
							.format(lstDownloadStatResp.getIncDt()
									.toGregorianCalendar().getTime()));
				}
				lstDownloadStatVO.setIncHeader(lstDownloadStatResp
						.getIncHeader());
				lstDownloadStatVO.setSnp(lstDownloadStatResp.getSnp());
				if (lstDownloadStatResp.getSnpDt() != null
						&& !lstDownloadStatResp.getSnpDt().toString().isEmpty()) {
					lstDownloadStatVO.setSnpDt(zoneFormater
							.format(lstDownloadStatResp.getSnpDt()
									.toGregorianCalendar().getTime()));
				}
				lstDownloadStatVO.setSnpHeader(lstDownloadStatResp
						.getSnpHeader());

			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getDownloadStatus() method ",
					rmdEx);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getDownloadStatus() method ", ex);
			throw ex;
		}
		rmdWebLogger
				.debug("AssetOverviewServiceImpl : Inside getDownloadStatus() method::END");
		return lstDownloadStatVO;
	}

	/**
	 * @Author : GE
	 * @param :
	 * @return : AssetLastFaultStatusVO
	 * @throws RMDWebException
	 * 
	 * @Description: This method will fetch the last fault status of the
	 *               asset
	 */
	@Override
	public AssetLastFaultStatusVO getLastFaultStatus(
			final AssetOverviewBean assetOverviewBean, final String userCustomer) throws RMDWebException,
			Exception {
		rmdWebLogger.debug("AssetOverviewServiceImpl : Inside getLstFaultStatus() method::START");
		final AssetLastFaultStatusVO lstFaultStatVO = new AssetLastFaultStatusVO();
		final Map<String, String> queryParamsMap = new HashMap<String, String>();
		try {
			if (null != assetOverviewBean) {

				queryParamsMap.put(AppConstants.ASSET_NUMBER,
						assetOverviewBean.getAsset());
				queryParamsMap.put(AppConstants.CUSTOMER_ID,
						assetOverviewBean.getCustomer());
				queryParamsMap.put(AppConstants.ASSET_GROUP_NAME,
						assetOverviewBean.getAssetGroup());
			}

			final LastFaultStatusResponseType lstFaultStatResp = (LastFaultStatusResponseType) webServiceInvoker
					.get(ServiceConstants.GET_LAST_FAULT_STATUS, null,
							queryParamsMap, null,
							LastFaultStatusResponseType.class);
			if (lstFaultStatResp != null
					&& !lstFaultStatResp.toString().isEmpty()) {
				DateFormat zoneFormater = new SimpleDateFormat(
						AppConstants.DATE_FORMAT_24HRS);
				if (cachedService.getSDCustLookup().get(userCustomer) != null
	                    && cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
	                    && !cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim().equals("")) {
	              zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat());
	            }
				final TimeZone firstTime = TimeZone
						.getTimeZone(assetOverviewBean.getUserTimeZone());
				zoneFormater.setTimeZone(firstTime);
				
				if (lstFaultStatResp.getLstEOAFault() != null
						&& !lstFaultStatResp.getLstEOAFault().toString()
								.isEmpty()) {

					lstFaultStatVO.setLstEOAFault(zoneFormater
							.format(lstFaultStatResp.getLstEOAFault()
									.toGregorianCalendar().getTime()));
				}
				lstFaultStatVO.setLstEOAFaultHeader(lstFaultStatResp
						.getLstEOAFaultHeader());
				
				if (lstFaultStatResp.getLstESTPDownload() != null
						&& !lstFaultStatResp.getLstESTPDownload().toString().isEmpty()) {
					lstFaultStatVO.setLstESTPDownload(zoneFormater
							.format(lstFaultStatResp.getLstESTPDownload()
									.toGregorianCalendar().getTime()));
				}
				lstFaultStatVO.setLstESTPDownloadHeader(lstFaultStatResp
						.getLstESTPDownloadHeader());

				if (lstFaultStatResp.getLstPPATSMsg() != null
						&& !lstFaultStatResp.getLstPPATSMsg().toString().isEmpty()) {
					lstFaultStatVO.setLstPPATSMsg(zoneFormater
							.format(lstFaultStatResp.getLstPPATSMsg()
									.toGregorianCalendar().getTime()));
				}
				lstFaultStatVO.setLstPPATSMsgHeader(lstFaultStatResp.getLstPPATSMsgHeader());
				
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getLstFaultStatus() method ",
					rmdEx);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLstFaultStatus() method ", ex);
			throw ex;
		}
		rmdWebLogger
				.debug("AssetOverviewServiceImpl : Inside getLstFaultStatus() method::END");
		return lstFaultStatVO;
	}

	/**
	 * @Author : IgatePatni
	 * @param :
	 * @return : AssetLocatorResponseVO
	 * @throws RMDWebException
	 * 
	 * @Description: This method will fetch the lookup value for last download
	 *               status of the asset
	 */
	@Override
	public Map<String, String> getCompLookupValue(
			final Map<String, String> listName) throws Exception {

		final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(listName);
		final Map<String, String> ddComponentMap = new LinkedHashMap<String, String>();
		if (applParamResponseType != null && applParamResponseType.length > 0) {
			String key;
			String value;

			key = applParamResponseType[0].getLookupValue();
			value = applParamResponseType[0].getLookupValue();
			ddComponentMap.put(key, value);

		}
		return ddComponentMap;
	}

	/**
	 * @Author : IgatePatni
	 * @param :
	 * @return : List<String>
	 * @throws RMDWebException
	 * 
	 * @Description: This method will fetch the available services for an asset
	 */
	@Override
	public List<String> getAssetServices(final AssetOverviewBean overviewBean)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("AssetOverviewServiceImpl : Inside getAssetServices() method::Start");
		final Map<String, String> queryParamsMap = new HashMap<String, String>();
		final Map<String, String> headerParams = getHeaderMap(overviewBean);
		AssetServicesResponseType serviceResponse = null;
		List<String> serviceList = null;
		try {
			serviceList = new ArrayList<String>();
			queryParamsMap.put(AppConstants.WS_PARAM_ASSTNUM,
					overviewBean.getAsset());
			queryParamsMap.put(AppConstants.WS_PARAM_CUSTID,
					overviewBean.getCustomer());
			queryParamsMap.put(AppConstants.WS_PARAM_ASSTGRP,
					overviewBean.getAssetGroup());
			serviceResponse = (AssetServicesResponseType) webServiceInvoker
					.get(ServiceConstants.GET_ASSETS_SERVICES, null,
							queryParamsMap, headerParams,
							AssetServicesResponseType.class);
			if (null != serviceResponse) {
				serviceList = new ArrayList<String>(
						serviceResponse.getAssetService());
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getAssetServices() method ",
					rmdEx);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getDownloadStatus() method ", ex);
			throw ex;
		}
		rmdWebLogger
				.debug("AssetOverviewServiceImpl : Inside getAssetServices() method::END");

		return serviceList;
	}
	
	@Cacheable(value = "RMDModelsForFilterCache", key = "#overviewBean.customer")
	public Map<String, String> getModelsForFilter(final AssetOverviewBean overviewBean) throws RMDWebException {
		Map<String, String> modelMap = new HashMap<String, String>();
		String modelID = null;
		String modelName = null;

		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();

		try {
			queryParamMap.put(AppConstants.CUSTOMER, overviewBean.getCustomer());
			Model[] model = (Model[]) webServiceInvoker.get(
					ServiceConstants.GET_MODELS, null, queryParamMap, null,
					Model[].class);
			for (int i = 0; i < model.length; i++) {
				modelID = model[i].getModelID();
				modelName = model[i].getModelName();
				modelMap.put(modelID, modelName);

			}

		}  catch (Exception rmdEx) {
			rmdWebLogger
			.error("RMDWebException occured in getModelsForFilter() method - AssetOverviewServiceImpl",
					rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return modelMap;
	}
	
	@Cacheable(value = "RMDFleetsForFilterCache", key = "#overviewBean.customer")
	public Map<String, String> getFleets(final AssetOverviewBean overviewBean)throws RMDWebException  {

		final Map<String, String> fleetMap = new LinkedHashMap<String, String>();

		String fleetsName = null;
		String fleetID = null;
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();

		try {

			
				queryParamMap.put(AppConstants.CUSTOMER, overviewBean.getCustomer());
			
			final 	Fleet[] fleet = (Fleet[]) webServiceInvoker.get(ServiceConstants.GET_FLEET_KEP,
					null, queryParamMap, null, Fleet[].class);
			if(fleet!=null)
			{
				for (int i = 0; i < fleet.length; i++) {
					fleetsName = fleet[i].getFleet();
					fleetID = fleet[i].getFleetID();
					//Setting name as key and value pair
					//fleetsName = fleet[i].getFleetID();
					fleetMap.put(fleetID, fleetsName);

				}
			}

		}
		catch (Exception ex) {
			rmdWebLogger.error("RMDWebException occured in getFleets() method - AssetOverviewServiceImpl", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return fleetMap;
	}

	/**
	 * @param String
	 *            assetNumber,String assetGrpName
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used for fetching customerId based upon
	 *              assetNumber and assetGrpName.
	 */
	@Override
	public String getCustomerId(String assetNumber, String assetGrpName)
			throws RMDWebException {
		String customerId = null;
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		try {
			if (!RMDCommonUtility.isNullOrEmpty(assetNumber)) {
				queryParamMap.put(AppConstants.ASSET_NUMBER, assetNumber);
			}
			if (!RMDCommonUtility.isNullOrEmpty(assetGrpName)) {
				queryParamMap.put(AppConstants.ASSET_GROUP_NAME, assetGrpName);
			}
			customerId = (String) webServiceInvoker.get(
					ServiceConstants.GET_CUSTOMER_ID, null, queryParamMap,
					null, String.class);
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getCustomerId() method - AssetOverviewServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return customerId;
	}
}
