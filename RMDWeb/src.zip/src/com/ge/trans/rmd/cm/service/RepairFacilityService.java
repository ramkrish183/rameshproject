package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.valueobjects.RepairFacilityDetailsVO;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface RepairFacilityService {

	/**
	 * @Author:
	 * @param:customerId
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the sites for the selected
	 *               customer
	 */
	public Map<String, String> getCustomerSites(String customerId)
			throws RMDWebException;

	/**
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the rail code status values in drop down.
	 */
	public Map<String, String> getRepairFacilityStatus() throws RMDWebException;
	
	/**
	 * 
	 * @param customerId
	 *            ,site,status
	 * @return RepairFacilityDetailsVO
	 * @throws RMDWebException
	 * @Description This method is used to get the Repair Facility Details.
	 * 
	 */
	public List<RepairFacilityDetailsVO> getRepairFacilityDetails(String customerId,
			String site, String status) throws RMDWebException;

	/**
	 * 
	 * @param RepairFacilityBean
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used to insert new repair/site location.
	 * 
	 */
	public String insertRepairSiteLoc(RepairFacilityDetailsVO repairFacilityDetailsVO)
			throws RMDWebException;

	/**
	 * 
	 * @param parameterString
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used to update existing repair/site location
	 *              details.
	 * 
	 */
	public String updateRepairSiteLoc(
			List<RepairFacilityDetailsVO> repairFacilityDetailsVOList)
			throws RMDWebException;


}
