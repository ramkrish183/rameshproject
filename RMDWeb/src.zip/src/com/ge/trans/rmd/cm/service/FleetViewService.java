package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.beans.FLeetViewBean;
import com.ge.trans.rmd.cm.valueobjects.FleetViewVO;
import com.ge.trans.rmd.cm.valueobjects.ToolTipVO;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface FleetViewService {
	
	public String fleetSaveNotes(final NotesBean notesBean)throws RMDWebException, Exception;
	
	public Map<String, List<ToolTipVO>> getCases(FLeetViewBean fleetViewBean)
	throws RMDWebException, Exception;

	public Map<String, FleetViewVO> getFilteredFleetView(FLeetViewBean fleetViewBean, String userCustomer)
			throws RMDWebException, Exception;

}
