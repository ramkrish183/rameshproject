/**
 * 
 */
package com.ge.trans.rmd.cm.valueobjects;

/**
 * @author MSHIRAJUDDIN
 *
 */
public class AssetsVO {
	
	private String assetOwnerId;
	private String roadInitial;
	private String roadNumberFrom;
	private String roadNumberTo;
	private String roadHdrInitial;
	private String roadNumber;
	private String roadNumberHdr;
	private String customerId;
	private String customerName;

	
	/**
	 * @return the assetOwnerId
	 */
	public String getAssetOwnerId() {
		return assetOwnerId;
	}
	/**
	 * @param assetOwnerId the assetOwnerId to set
	 */
	public void setAssetOwnerId(String assetOwnerId) {
		this.assetOwnerId = assetOwnerId;
	}
	/**
	 * @return the roadInitial
	 */
	public String getRoadInitial() {
		return roadInitial;
	}
	
	/**
	 * @param roadInitial the roadInitial to set
	 */
	public void setRoadInitial(String roadInitial) {
		this.roadInitial = roadInitial;
	}
	/**
	 * @return the roadNumberFrom
	 */
	public String getRoadNumberFrom() {
		return roadNumberFrom;
	}
	/**
	 * @param roadNumberFrom the roadNumberFrom to set
	 */
	public void setRoadNumberFrom(String roadNumberFrom) {
		this.roadNumberFrom = roadNumberFrom;
	}
	/**
	 * @return the roadNumberTo
	 */
	public String getRoadNumberTo() {
		return roadNumberTo;
	}
	/**
	 * @param roadNumberTo the roadNumberTo to set
	 */
	public void setRoadNumberTo(String roadNumberTo) {
		this.roadNumberTo = roadNumberTo;
	}
	public String getRoadHdrInitial() {
		return roadHdrInitial;
	}
	public void setRoadHdrInitial(String roadHdrInitial) {
		this.roadHdrInitial = roadHdrInitial;
	}
	/**
	 * @return the roadNumber
	 */
	public final String getRoadNumber() {
		return roadNumber;
	}
	/**
	 * @param roadNumber the roadNumber to set
	 */
	public final void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}
	/**
	 * @return the roadNumberHdr
	 */
	public final String getRoadNumberHdr() {
		return roadNumberHdr;
	}
	/**
	 * @param roadNumberHdr the roadNumberHdr to set
	 */
	public final void setRoadNumberHdr(String roadNumberHdr) {
		this.roadNumberHdr = roadNumberHdr;
	}
	/**
	 * @return the customerId
	 */
	public final String getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId the customerId to set
	 */
	public final void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	/**
	 * @return the customerName
	 */
	public final String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public final void setCustomerName(String customerName) {
		this.customerName = customerName;
	}	
	
}
