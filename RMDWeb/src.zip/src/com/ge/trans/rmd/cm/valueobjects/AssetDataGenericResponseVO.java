package com.ge.trans.rmd.cm.valueobjects;

import com.ge.trans.rmd.common.vo.RMDBaseVO;

/**
 * A custom POJO that will be automatically converted to JSON format. 
 * <p>We can use this to send generic messages to our DataScreen, whether a request is successful or not.
 * Of course, you will use plain JavaScript to parse the JSON response. 
 */
@SuppressWarnings("serial")
public class AssetDataGenericResponseVO extends RMDBaseVO {

	/**
	 * true if successful. 
	 */
	private Boolean success;
	
	/**
	 * Any custom message, i.e, 'Your request has been processed successfully!'
	 */
	
	public Boolean getSuccess() {
		return success;
	}
	
	public void setSuccess(final Boolean success) {
		this.success = success;
	}
	

	
}
