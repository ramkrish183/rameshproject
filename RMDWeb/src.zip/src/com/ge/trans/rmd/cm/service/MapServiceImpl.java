/**
 * ============================================================
 * Classification: GE Confidential
 * File : MapServiceImpl.java
 * Description : This method is used to get the collective response for plotting the map 
 * from four web services
 * Package : com.ge.trans.rmd.cm.service;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on : August 2, 2012
 * History
 * Modified By : iGATE
 *
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.Future;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.beans.MapBean;
import com.ge.trans.rmd.cm.valueobjects.MapServiceVO;
import com.ge.trans.rmd.cm.valueobjects.OpenRxVO;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetLocatorResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseResponseType;
import com.ge.trans.rmd.services.solutions.valueobjects.UrgencyResponseType;
import com.ge.trans.rmd.utilities.AppSecUtil;

@Service
public class MapServiceImpl extends RMDBaseServiceImpl implements MapService {

	private final RMDWebLogger logger = RMDWebLogger.getLogger(getClass());
	@Autowired
	WebServiceInvoker rsInvoker;

	@Autowired
	private MapServiceCallWrapper mapServiceWrapper;
	@Autowired
	private CachedService cachedService;
	public Map<String, MapServiceVO> getMapPage(MapBean mapBean, String userCustomer)
			throws RMDWebException, Exception {
		//logger.debug("MapServiceImpl : Inside getMapPage() method:::START");
		Long startTime = System.currentTimeMillis();
		//logger.info("Perf: getMapPage StartTime: " + startTime);

		final Map<String, String> headerParams = getHeaderMap(mapBean);
		/*
		 * collectiveResponse is the map that contains MapServiceVO for each key
		 * where key is the combination of assetNumber|assetGroupName|customerId
		 */
		Map<String, MapServiceVO> collectiveResponse = new HashMap<String, MapServiceVO>();

		Future<AssetLocatorResponseType[]> futureAssetLocResponse = null;
		Future<CaseResponseType[]> futureCaseResponse = null;
		
		AssetLocatorResponseType[] assetLocResponseType = null;
		CaseResponseType[] caseResponseType = null;
		mapBean.setLastFault(false);
		try {
			futureAssetLocResponse = mapServiceWrapper.getAssetLocation(
					headerParams, mapBean);
				futureCaseResponse = mapServiceWrapper.getCaseResponse(
					headerParams, mapBean);
			assetLocResponseType = futureAssetLocResponse.get();			
			caseResponseType = futureCaseResponse.get();
			populateVOFromAssetLocResponse(assetLocResponseType, collectiveResponse,mapBean, userCustomer);
			populateVOFromCaseResponse(caseResponseType, collectiveResponse, mapBean, userCustomer);
			collectiveResponse = populateWorsUrgencyFromVO(collectiveResponse, mapBean);
			
		} catch (Exception e) {
			logger.error("Exception occured in getMapPage method "
					+ e.getMessage());
			RMDWebErrorHandler.handleException(e);
		}
		//logger.debug("MapServiceImpl : Inside getMapPage() method:::END");
		Long endTime = System.currentTimeMillis();
		//logger.info("Perf: getMapPage endTime: " + endTime);
		//logger.info("Perf: getMapPage Execution Time: " + (endTime - startTime)+ "ms");

		return collectiveResponse;
	}

	/*
	 * populates MapServiceVO by operating on assetlocatorresponse we will
	 * populate latitude, longitude,assetNumber,customerId,assetGrpname from
	 * assetlocatorresponse
	 */
	public Map<String, MapServiceVO> populateVOFromAssetLocResponse(
			AssetLocatorResponseType[] assetLocatorResponseType,
			Map<String, MapServiceVO> displayMap, MapBean mapBean, String userCustomer) throws RMDWebException,
			Exception {
		String assetNumber = null;
		String assetGroupName = null;
		String customerId = null;
		String latitude = null;
		String longitude = null;
		String key = null;
		MapServiceVO mapServiceVO = null;
		
		if (null != assetLocatorResponseType
				&& assetLocatorResponseType.length > 0) {			
			DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
			for (int i = 0; i < assetLocatorResponseType.length; i++) {
				if (cachedService.getSDCustLookup().get(userCustomer) != null
		                && cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
		                && !cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim().equals("")) 
				{
		          zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat());
				}}
			TimeZone firstTime=null;
			if(null != mapBean.getTimeZoneChk() && !mapBean.getTimeZoneChk().isEmpty()){
				firstTime = TimeZone.getTimeZone(mapBean.getTimeZone());
			}else{
				firstTime = TimeZone.getTimeZone("GMT");
			}
			for (AssetLocatorResponseType eachResponseType : assetLocatorResponseType) {
				assetGroupName = eachResponseType.getAssetGrpName();
				assetNumber = eachResponseType.getAssetNumber();
				customerId = eachResponseType.getCustomerId();

				key = assetNumber + AppConstants.PIPE_SEPERATOR
						+ assetGroupName + AppConstants.PIPE_SEPERATOR
						+ customerId;

				if (displayMap.containsKey(key)) {
					mapServiceVO = displayMap.get(key);
				} else {
					mapServiceVO = new MapServiceVO();
				}

				mapServiceVO.setAssetNumber(assetNumber);
				mapServiceVO.setAssetGrpName(assetGroupName);
				mapServiceVO.setCustomerId(customerId);
				//Misc Map Last Fault Time changes - Start
				if(null != eachResponseType
						.getMaxOccurTime()){
					final XMLGregorianCalendar lastFaultOccurTime = eachResponseType
							.getMaxOccurTime();
					zoneFormater.setTimeZone(firstTime);
					mapServiceVO.setLastFaultTime(zoneFormater
							.format(lastFaultOccurTime.toGregorianCalendar()
									.getTime()));
				}
				//Misc Map Last Fault Time changes - End
				setAssetLocatorResponseDetails(eachResponseType, mapServiceVO);
				if (null != mapServiceVO.getLatitude()
						&& null != mapServiceVO.getLongitude()) {
					displayMap.put(key, mapServiceVO);
				}
			}
		} else {
			logger.debug("null found in populateVOFromAssetLocResponse()");
		}

		return displayMap;
	}

	/*
	 * populate MapServiceVO from assetLocator response type
	 */
	public void setAssetLocatorResponseDetails(
			AssetLocatorResponseType assetLocatorResponseType,
			MapServiceVO mapServiceVO) throws GenericAjaxException, RMDWebException {
		if (null != assetLocatorResponseType) {
			mapServiceVO.setModel(assetLocatorResponseType.getModelName());
			if (assetLocatorResponseType.getLatitude() != null
					&& assetLocatorResponseType.getLongitude() != null) {
				try {
					float latitude = Float.parseFloat(assetLocatorResponseType.getLatitude());
					float longitude = Float.parseFloat(assetLocatorResponseType.getLongitude());
					if ( latitude >= -90.0 && latitude <= 90.0
							&& longitude >= -180.0 && longitude <= 180.0) {
						mapServiceVO.setLatitude(assetLocatorResponseType
								.getLatitude());
						mapServiceVO.setLongitude(assetLocatorResponseType
								.getLongitude());
					}
				} catch (Exception e) {
					logger.error("In MapServiceImpl : Unparsable latitude or longitude in setAssetLocatorResponseDetails "
							+ e.getMessage());
					RMDWebErrorHandler.handleException(e);
				}
			}
		} else {
			logger.debug("null found in setAssetLocatorResponseDetails()");
		}

	}

	/*
	 * populates displaymap map by operating on assetresponse we will populate
	 * model from assetresponse
	 */
	public Map<String, MapServiceVO> populateVOFromAssetResponse(
			AssetResponseType[] assetResponse,
			Map<String, MapServiceVO> displayMap) throws RMDWebException,
			Exception {
		String assetNumber = null;
		String assetGroupName = null;
		String customerId = null;
		String key = null;
		MapServiceVO mapServiceVO = null;

		if (null != assetResponse && assetResponse.length > 0) {
			for (AssetResponseType eachResponseType : assetResponse) {
				assetGroupName = eachResponseType.getAssetGroupName();
				assetNumber = eachResponseType.getAssetNumber();
				customerId = eachResponseType.getCustomerID();

				key = assetNumber + AppConstants.PIPE_SEPERATOR
						+ assetGroupName + AppConstants.PIPE_SEPERATOR
						+ customerId;

				if (displayMap.containsKey(key)) {
					mapServiceVO = displayMap.get(key);

					mapServiceVO.setAssetNumber(assetNumber);
					mapServiceVO.setAssetGrpName(assetGroupName);
					mapServiceVO.setCustomerId(customerId);

					setAssetResponseDetails(eachResponseType, mapServiceVO);
					displayMap.put(key, mapServiceVO);
				}

			}
		} else {
			logger.debug("null found in populateVOFromAssetLocResponse()");
		}

		return displayMap;
	}

	/*
	 * populate MapServiceVO from assetResponseType
	 */
	public void setAssetResponseDetails(AssetResponseType assetResponseType,
			MapServiceVO mapServiceVO) {
		if (assetResponseType != null) {
			mapServiceVO.setModel(assetResponseType.getModel());

		} else {
			logger.debug("null found in setAssetResponseDetails()");
		}

	}

	/*
	 * populates displayMap by opearting on urgencyresponse we will populate
	 * worsturgency from urgencyresponse
	 */
	public Map<String, MapServiceVO> populateVOFromUrgencyResponse(
			UrgencyResponseType[] urgencyResponseType,
			Map<String, MapServiceVO> displayMap) throws RMDWebException,
			Exception {
		String assetNumber = null;
		String assetGroupName = null;
		String customerId = null;
		String key = null;
		MapServiceVO mapServiceVO = null;

		if (null != urgencyResponseType && urgencyResponseType.length > 0) {
			for (UrgencyResponseType eachResponseType : urgencyResponseType) {
				assetGroupName = eachResponseType.getAssetGroupName();
				assetNumber = eachResponseType.getAssetNumber();
				customerId = eachResponseType.getCustomerId();

				key = assetNumber + AppConstants.PIPE_SEPERATOR
						+ assetGroupName + AppConstants.PIPE_SEPERATOR
						+ customerId;

				if (displayMap.containsKey(key)) {
					mapServiceVO = displayMap.get(key);
					mapServiceVO.setAssetNumber(assetNumber);
					mapServiceVO.setAssetGrpName(assetGroupName);
					mapServiceVO.setCustomerId(customerId);

					setUrgencyResponseDetails(eachResponseType, mapServiceVO);
					displayMap.put(key, mapServiceVO);
				}

			}
		} else {
			logger.debug("null found in populateVOFromUrgencyResponse()");
		}

		return displayMap;
	}

	/*
	 * populate MapServiceVO from urgency response type
	 */
	public void setUrgencyResponseDetails(
			UrgencyResponseType urgencyResponseType, MapServiceVO mapServiceVO) {
		if (null != urgencyResponseType) {
			mapServiceVO.setWorstUrgency(urgencyResponseType.getWorstUrgency());
			// Adding for map asset plot order story - Start
			if (urgencyResponseType.getWorstUrgency().equalsIgnoreCase(
					(AppConstants.URGENCY_R))) {
				mapServiceVO.setAssetPlotOrder(5);
			} else if (urgencyResponseType.getWorstUrgency().equalsIgnoreCase(
					(AppConstants.URGENCY_Y))) {
				mapServiceVO.setAssetPlotOrder(4);
			} else if (urgencyResponseType.getWorstUrgency().equalsIgnoreCase(
					(AppConstants.URGENCY_B))) {
				mapServiceVO.setAssetPlotOrder(3);
			} else if (urgencyResponseType.getWorstUrgency().equalsIgnoreCase(
					(AppConstants.URGENCY_W))) {
				mapServiceVO.setAssetPlotOrder(2);
			} else {
				mapServiceVO.setAssetPlotOrder(1);
			}
			// Adding for map asset plot order story - End
		} else {
			logger.debug("null found in setUrgencyResponseDetails()");
		}

	}

	/*
	 * populates displayMap by operating on populateVOFromCaseResponse we will
	 * populate openrx from caseresponse
	 */
	public Map<String, MapServiceVO> populateVOFromCaseResponse(
			CaseResponseType[] caseResponseType,
			Map<String, MapServiceVO> displayMap, MapBean mapBean, String userCustomer)
			throws RMDWebException, Exception {
		logger.debug("====================Start populateVOFromCaseResponse========");
		String assetNumber = null;
		String assetGroupName = null;
		String customerId = null;
		String key = null;
		MapServiceVO mapServiceVO = null;
		List<OpenRxVO> openRxLst = null;
		if (null != caseResponseType && caseResponseType.length > 0) {
			for (CaseResponseType eachResponseType : caseResponseType) {

				assetGroupName = eachResponseType.getAssetGrpName();
				assetNumber = eachResponseType.getAssetNumber();
				customerId = eachResponseType.getCustomerName();

				key = assetNumber + AppConstants.PIPE_SEPERATOR
						+ assetGroupName + AppConstants.PIPE_SEPERATOR
						+ customerId;

				if (displayMap.containsKey(key)) {
					mapServiceVO = displayMap.get(key);
					openRxLst = mapServiceVO.getOpenRxList();
					if (openRxLst == null || openRxLst.isEmpty()) {
						openRxLst = new ArrayList<OpenRxVO>();
					}

					mapServiceVO.setAssetNumber(assetNumber);
					mapServiceVO.setAssetGrpName(assetGroupName);
					mapServiceVO.setCustomerId(customerId);
					setCaseResponseDetails(eachResponseType, mapServiceVO,
							openRxLst, mapBean, userCustomer);
					displayMap.put(key, mapServiceVO);
				}

			}
		} else {
			logger.debug("null found in populateVOFromCaseResponse()");
		}

		return displayMap;

	}

	/*
	 * set worst urgency for asset in filtered Map
	 */
	public Map<String, MapServiceVO> populateWorsUrgencyFromVO(
			Map<String, MapServiceVO> displayMap, MapBean mapBean) throws RMDWebException,
			Exception {
		logger.debug("====================Start populateWorsUrgencyFromVO========");
		boolean hasFavFilter = true;
		if ((null == mapBean.getUrgency() || mapBean.getUrgency().equals(
				AppConstants.EMPTY_STRING))
				&& (null == mapBean.getEstRepTime() || mapBean
						.getEstRepTime().equals(AppConstants.EMPTY_STRING))
				&& (null == mapBean.getRxIds() || mapBean.getRxIds()
						.equals(AppConstants.EMPTY_STRING))
						&& (null == mapBean.getCaseType() || mapBean.getCaseType()
						.equals(AppConstants.EMPTY_STRING))) {
			hasFavFilter = false;
		} 

		List<OpenRxVO> openRxLst = new ArrayList<OpenRxVO>();
		List<String> rxUrgencyList = null;
		Map<String, MapServiceVO> finalDisplayMap = new HashMap<String, MapServiceVO>();
		if (null != displayMap && displayMap.size() > 0) {
			for (Map.Entry<String, MapServiceVO> mapEntry : displayMap
					.entrySet()) {

				openRxLst = mapEntry.getValue().getOpenRxList();
				rxUrgencyList = new ArrayList<String>();
				if (null != openRxLst && openRxLst.size() != 0) {
					for (int i = 0; i < openRxLst.size(); i++) {
						rxUrgencyList.add(mapEntry.getValue().getOpenRxList()
								.get(i).getRxUrgency());

					}
					if (rxUrgencyList.contains(AppConstants.URGENCY_R)) {
						mapEntry.getValue().setWorstUrgency(
								AppConstants.URGENCY_R);
						mapEntry.getValue().setAssetPlotOrder(5);
					} else if (rxUrgencyList.contains(AppConstants.URGENCY_Y)) {
						mapEntry.getValue().setWorstUrgency(
								AppConstants.URGENCY_Y);
						mapEntry.getValue().setAssetPlotOrder(4);
					} else if (rxUrgencyList.contains(AppConstants.URGENCY_B)) {
						mapEntry.getValue().setWorstUrgency(
								AppConstants.URGENCY_B);
						mapEntry.getValue().setAssetPlotOrder(3);
					}else if (rxUrgencyList.contains(AppConstants.URGENCY_W)) {
						mapEntry.getValue().setWorstUrgency(
								AppConstants.URGENCY_W);
						mapEntry.getValue().setAssetPlotOrder(2);
					} else {
						mapEntry.getValue().setWorstUrgency(
								AppConstants.EMPTY_STRING);
						mapEntry.getValue().setAssetPlotOrder(1);
					}
					finalDisplayMap.put(mapEntry.getKey(), mapEntry.getValue());
				}else if(!hasFavFilter){
					mapEntry.getValue().setWorstUrgency(
							AppConstants.EMPTY_STRING);
					mapEntry.getValue().setAssetPlotOrder(0);
					finalDisplayMap.put(mapEntry.getKey(), mapEntry.getValue());
				}
			}

		} else {
			logger.debug("null found in populateWorsUrgencyFromVO()");
		}
		return finalDisplayMap;
	}

	/*
	 * populate MapServiceVO from CaseResponse type
	 */
	public void setCaseResponseDetails(CaseResponseType caseResponseType,
			MapServiceVO mapServiceVO, List<OpenRxVO> openRxLst, MapBean mapBean, String userCustomer) throws RMDWebException, Exception {
		OpenRxVO openRxVO = null;
		DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		if (cachedService.getSDCustLookup().get(userCustomer) != null
                && cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
                && !cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim().equals("")) {
			zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat());
		}
		final TimeZone firstTime = TimeZone.getTimeZone(mapBean.getTimeZone());
		zoneFormater.setTimeZone(firstTime);
		if (null != caseResponseType) {
			openRxVO = new OpenRxVO();
			openRxVO.setRxcaseid(caseResponseType.getSolutionInfo().get(0)
					.getSolutionCaseID());
			openRxVO.setRxTitle(AppSecUtil.decodeString(caseResponseType.getSolutionInfo().get(0)
					.getSolutionTitle()));
			openRxVO.setRepairTime(caseResponseType.getSolutionInfo().get(0)
					.getEstmRepTime());
			if (null != caseResponseType.getCaseInfo().getCreatedDate()) {
				openRxVO.setCreationDate(zoneFormater.format(caseResponseType
						.getCaseInfo().getCreatedDate().toGregorianCalendar()
						.getTime()));
				final XMLGregorianCalendar creationDate = caseResponseType
						.getCaseInfo().getCreatedDate();
				final GregorianCalendar startDate = creationDate
						.toGregorianCalendar();
				String age = RMDCommonUtil.calculateAge(startDate,
						new GregorianCalendar(), mapBean.getTimeZone());
				startDate.setTimeZone(firstTime);
				openRxVO.setAge(age);

			}
			openRxVO.setLocoImpact(AppSecUtil.decodeString(caseResponseType.getSolutionInfo().get(0)
					.getLocomotiveImpact()));
			/*
			 * Added the below parameters for passing it in rx Execution sticky
			 * tab
			 */
			openRxVO.setCaseId(caseResponseType.getCaseInfo().getCaseID());
			openRxVO.setOwner(caseResponseType.getCaseInfo().getCustomerName());
			if (caseResponseType.getSolutionInfo().get(0).getSolutionDelvDate() != null) {
				openRxVO.setDelvDate(zoneFormater.format(caseResponseType
						.getSolutionInfo().get(0).getSolutionDelvDate()
						.toGregorianCalendar().getTime()));
				openRxVO.setRxUrgency(caseResponseType.getSolutionInfo().get(0)
						.getUrgency());
			}
			/*
			 * Added the below parameters for passing it in rx Execution sticky
			 * tab
			 */
			openRxLst.add(openRxVO);
			mapServiceVO.setOpenRxList(openRxLst);

		} else {
			logger.debug("null found in setCaseResponseDetails()");
		}

	}
	
	/* added to fetch map last ehcahe refresh time 
	 * phase 2 sprint 6 MISC change 
	 */
	public String getLastRefreshTime(String listName, String applicationTimezone, String userCustomer)
			throws RMDWebException, Exception {
		String lastRefreshTime = null;
		logger.debug("getLastRefreshTime():Start");
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		try {
			queryParamMap.put(AppConstants.LIST_NAME, listName);
			DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
			if (cachedService.getSDCustLookup().get(userCustomer) != null
	                && cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
	                && !cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim().equals("")) 
			{
	          zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat());
			}
			final TimeZone firstTime = TimeZone
					.getTimeZone(applicationTimezone);
			ApplicationParametersResponseType[] applParamResponseType = (ApplicationParametersResponseType[]) rsInvoker
					.get(ServiceConstants.GET_MAP_LAST_REFRESH_TIME, null,
							queryParamMap, null,
							ApplicationParametersResponseType[].class);

			for (ApplicationParametersResponseType applicationParametersResponseType : applParamResponseType) {
				if (null != applicationParametersResponseType
						.getLastUpdatedDate()) {
					final XMLGregorianCalendar creationDate = applicationParametersResponseType
							.getLastUpdatedDate();
					zoneFormater.setTimeZone(firstTime);
					lastRefreshTime = zoneFormater.format(creationDate
							.toGregorianCalendar().getTime());
				}
			}
		} catch (Exception ex) {
			logger.error(
					"Exception occured in getLastRefreshTime method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("getLastRefreshTime():End");
		return lastRefreshTime;
	}

}
