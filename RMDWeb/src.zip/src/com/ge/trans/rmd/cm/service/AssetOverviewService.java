package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.valueobjects.AssetLastDownloadStatusVO;
import com.ge.trans.rmd.cm.valueobjects.AssetLastFaultStatusVO;
import com.ge.trans.rmd.cm.valueobjects.AssetLocatorResponseVO;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface AssetOverviewService {

	/**
	 * @author IgatePatni
	 * @param assetNumber
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 */
	public AssetOverviewBean getAssets(final AssetOverviewBean assetOverviewBean)
			throws RMDWebException, Exception;

	/**
	 * @author IgatePatni
	 * @param assetNumber
	 * @param userVO
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 */
	public List<NotesBean> getNotes(final AssetOverviewBean assetOverviewBean, final String userCustomer)
			throws RMDWebException, Exception;

	/**
	 * @author IgatePatni
	 * @param assetNumber
	 * @param solutionStatus
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 */
	public List<CaseBean> getCases(final AssetOverviewBean assetOverviewBean, final String userCustomer)
			throws RMDWebException, Exception;

	/**
	 * @author IgatePatni
	 * @param assetNumber
	 * @param userVO
	 * @param assetOverviewBean
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 */
	public AssetOverviewBean getVehicleCommStatus(
			final AssetOverviewBean assetOverviewBean, final String userCustomer) throws RMDWebException,
			Exception;

	/**
	 * @author IgatePatni
	 * @param assetOverviewBean
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 */
	public AssetLastDownloadStatusVO getDownloadStatus(
			final AssetOverviewBean assetOverviewBean, final String userCustomer) throws RMDWebException,
			Exception;

	/**
	 * @author GE
	 * @param assetOverviewBean
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 */
	public AssetLastFaultStatusVO getLastFaultStatus(final AssetOverviewBean assetOverviewBean, final String userCustomer)throws RMDWebException, Exception;
	/**
	 * @author IgatePatni
	 * @param notes
	 * @param assetNumber
	 * @param userName
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 */
	public String addNotes(final NotesBean notesBean) throws RMDWebException,
			Exception;

	/**
	 * @author IgatePatni
	 * @param
	 * @param
	 * @param AssetLocatorBean
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 */
	public AssetLocatorResponseVO getAssetLocation(
			final AssetOverviewBean assetOverviewBean, final String userCustomer) throws RMDWebException,
			Exception;

	/**
	 * @author IgatePatni
	 * @param assetOverviewBean
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 */
	public Map<String, String> getCompLookupValue(Map<String, String> listName)
			throws Exception;

	/**
	 * @author IgatePatni
	 * @param assetOverviewBean
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 */
	public List<String> getAssetServices(final AssetOverviewBean overviewBean)
			throws RMDWebException, Exception;

	/**
	 * @param overviewBean
	 * @return
	 * @throws RMDWebException
	 */
	public Map<String, String> getModelsForFilter(final AssetOverviewBean overviewBean) throws RMDWebException;

	/**
	 * @param overviewBean
	 * @return
	 * @throws RMDWebException
	 */
	public Map<String, String> getFleets(final AssetOverviewBean overviewBean)throws RMDWebException;
	
	
	/**
	 * @param String
	 *            assetNumber,String assetGrpName
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used for fetching customerId based upon
	 *              assetNumber and assetGrpName.
	 */
	
	public String getCustomerId(String assetNumber,String assetGrpName) throws RMDWebException;
	
}
