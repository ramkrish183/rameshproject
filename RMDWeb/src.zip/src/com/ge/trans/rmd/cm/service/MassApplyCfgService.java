/**
 * ============================================================

 * Classification		: GE Confidential
 * File 				: MassApplyCfgService.java
 * Description 			:
 * Package 				: com.ge.trans.rmd.cm.valueobjects;
 * Author 				: Capgemini India.
 * Last Edited By 		:
 * Version 				: 1.0
 * Created on 			:
 * History				:
 * Modified By 			: Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.cm.valueobjects.ApplyCfgTemplateVO;
import com.ge.trans.rmd.cm.valueobjects.ApplyEFICfgVO;
import com.ge.trans.rmd.cm.valueobjects.AssetSearchVO;
import com.ge.trans.rmd.cm.valueobjects.ConfigSearchVO;
import com.ge.trans.rmd.cm.valueobjects.MassApplyCfgVO;
import com.ge.trans.rmd.cm.valueobjects.VerifyCfgTemplateVO;

public interface MassApplyCfgService {

	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching controller Configs.
	 * 
	 */
	public Map<String, String> getControllerConfigs() throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<MassApplyCfgVO>
	 * @param :ConfigSearchVO objConfigSearchVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Type EDP.
	 * 
	 */
	public List<MassApplyCfgVO> getEDPConfigs(ConfigSearchVO objConfigSearchVO)
			throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<MassApplyCfgVO>
	 * @param :ConfigSearchVO objConfigSearchVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Type FFD.
	 * 
	 */
	public List<MassApplyCfgVO> getFFDConfigs(ConfigSearchVO objConfigSearchVO)
			throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<MassApplyCfgVO>
	 * @param :ConfigSearchVO objConfigSearchVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Type FRD.
	 * 
	 */
	public List<MassApplyCfgVO> getFRDConfigs(ConfigSearchVO objConfigSearchVO)
			throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Types.
	 * 
	 */
	public List<String> getMassApplyCfgList() throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Mass Apply Cfg
	 *               Users List.
	 * 
	 * 
	 */
	public List<String> getMassApplyCfgUsers() throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<VerifyCfgTempaltesVO>
	 * @param :String edpObjId,String ffdObjId,String frdObjId,String efiObjId,String ahcObjId
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching selected
	 *               Configurations for applying.
	 * 
	 */
	public List<VerifyCfgTemplateVO> verifyConfigTemplates(String edpObjId,
			String ffdObjId, String frdObjId ,String efiObjId,String ahcObjId,String rciObjId,String agtObjId,String applicationTimezone) throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :String ctrlCfgObjId
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching selected
	 *               Configurations for applying.
	 * 
	 */
	public List<String> getOnboardSoftwareVersion(String ctrlCfgObjId)
			throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :String cfgType, String template, String ctrlCfgObjId
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching selected
	 *               Configurations for applying.
	 * 
	 */
	public List<String> getCfgTemplateVersions(String cfgType,
			String template, String ctrlCfgObjId) throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :AssetSearchVO objAssetSearchVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching selected
	 *               Configurations for applying.
	 * 
	 */
	public List<String> getSpecificAssetNumbers(AssetSearchVO objAssetSearchVO)
			throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :ApplyCfgTemplateVO objApplyCfgTemplateVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for applying the config
	 *               templates to the selected assets.
	 * 
	 */

	public List<String> applyCfgTemplates(
			ApplyCfgTemplateVO objApplyCfgTemplateVO) throws RMDWebException;
	
	/**
	 * @Author :
	 * @return :List<String>
	 * @param :ApplyCfgTemplateVO objApplyCfgTemplateVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for applying EFI config
	 *               templates to the selected assets.
	 * 
	 */

	public List<String> applyEFICfg(ApplyEFICfgVO objApplyEFICfgVO)
			throws RMDWebException;

	/**
     * @Author :
     * @return :List<MassApplyCfgVO>
     * @param :ConfigSearchVO objConfigSearchVO
     * @throws :RMDWebException
     * @Description: This method is Responsible for fetching the AHC config templates
     * 
     */
    public List<MassApplyCfgVO> getAHCConfigs(ConfigSearchVO objConfigSearchVO) throws RMDWebException;
    /**
	 * @Author :
	 * @return :List<MassApplyCfgVO>
	 * @param :ConfigSearchVO objConfigSearchVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Type RCI.
	 * 
	 */
	public List<MassApplyCfgVO> getRCIConfigs(ConfigSearchVO objConfigSearchVO)
			throws RMDWebException;
	
	/**
     * @Author :
     * @return :List<String>
     * @param :
     * @throws :RMDWebException
     * @Description: This method is Responsible for fetching AGT template device list.
     * 
     */
    public List<String> getAGTDeviceList() throws RMDWebException;

}
