package com.ge.trans.rmd.cm.valueobjects;

import java.util.LinkedHashMap;

public class ToolOutputCaseMergeVO {
	 private String assetnumber; 
	  private String groupName; 
	  private String customerId;	  
	  private String caseType;
	  private String caseId;
	  
	  private String rxId;
	  private String mergedTo;
	  private String ruleDefId; 
	  private String toolid;
	  private String toolObjId;
	  private String rxTitle;
	  
	
	public String getAssetnumber() {
		return assetnumber;
	}
	public void setAssetnumber(String assetnumber) {
		this.assetnumber = assetnumber;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getRxId() {
		return rxId;
	}
	public void setRxId(String rxId) {
		this.rxId = rxId;
	}
	
	
	
	public String getMergedTo() {
		return mergedTo;
	}
	public void setMergedTo(String mergedTo) {
		this.mergedTo = mergedTo;
	}
	public String getRuleDefId() {
		return ruleDefId;
	}
	public void setRuleDefId(String ruleDefId) {
		this.ruleDefId = ruleDefId;
	}
	public String getToolid() {
		return toolid;
	}
	public void setToolid(String toolid) {
		this.toolid = toolid;
	}
	public String getToolObjId() {
		return toolObjId;
	}
	public void setToolObjId(String toolObjId) {
		this.toolObjId = toolObjId;
	}
	public String getRxTitle() {
		return rxTitle;
	}
	public void setRxTitle(String rxTitle) {
		this.rxTitle = rxTitle;
	}
	  
}
