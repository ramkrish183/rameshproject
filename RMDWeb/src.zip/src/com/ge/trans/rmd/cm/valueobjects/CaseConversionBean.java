package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;
import java.util.Map;

public class CaseConversionBean {
	
	private Map<String, Map<Integer, String>> conversionMap;
	

	public Map<String, Map<Integer, String>> getConversionMap() {
		return conversionMap;
	}

	public void setConversionMap(Map<String, Map<Integer, String>> conversionMap) {
		this.conversionMap = conversionMap;
	}



}
