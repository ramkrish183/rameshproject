package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.AddEditEDPDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.ConfigTemplateDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.EDPHeaderDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.EDPParamDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.EDPSearchParamVO;
import com.ge.trans.rmd.cm.valueobjects.EFIDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.FFDDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.FRDDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.FaultFilterDefDetails;
import com.ge.trans.rmd.cm.valueobjects.FaultRangeDefDetails;
import com.ge.trans.rmd.cm.valueobjects.TemplateReportBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.configmaintenance.valueobjects.TemplateReportResponseType;
import com.ge.trans.rmd.services.assets.configmaintenance.valueobjects.TemplateRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.AddEditEDPRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.ConfigRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.ConfigTemplateDetailsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.EDPHeaderResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.EDPParamDetailsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.EFIDetailsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.FFDRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.FFDResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.FRDRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.FRDResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.FaultValueResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class ConfigMaintenanceServiceImpl extends RMDBaseServiceImpl implements
		ConfigMaintenanceService {

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private CachedService cachedService;
	@Autowired
	WebServiceInvoker webServiceInvoker;

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the all controller configs
	 */
	@Override
	public Map<String, String> getControllerConfigs() throws RMDWebException {
		Map<String, String> ctrlCfgMap = null;
		try {
			ctrlCfgMap = new LinkedHashMap<String, String>(
					cachedService.getControllerConfigs());
		}catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getControllerConfigs() method of ConfigMaintenanceServiceImpl ", ex);
			RMDWebErrorHandler.handleException(ex);
		} 
		return ctrlCfgMap;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the all controller config
	 *               files
	 */
	@Override
	public Map<String, String> getConfigFiles() throws RMDWebException{
		Map<String, String> cfgFileNameMap = new LinkedHashMap<String, String>();
		ApplicationParametersResponseType[] applParamResponseType=null;
		Map<String, String> pathParams = new LinkedHashMap<String, String>();
		String cfgFileName = null;
		try {
			pathParams.put(AppConstants.LIST_NAME, AppConstants.CTRL_CFG_FILE_NAMES_LIST);
			applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				cfgFileNameMap = new LinkedHashMap<String, String>(applParamResponseType.length);
				for (int i = 0; i < applParamResponseType.length; i++) {
					cfgFileName = applParamResponseType[i].getLookupValue();
					cfgFileNameMap.put(cfgFileName, cfgFileName);
				}				
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getConfigFiles() method of ConfigMaintenanceServiceImpl ", ex);
			RMDWebErrorHandler.handleException(ex);
		}finally{
			applParamResponseType=null;
			pathParams=null;
		}
		return cfgFileNameMap;
	}
	
	/**
	 * 
	 * @param ctrlCfgObjId
	 *            , cfgFile
	 * @return List<ConfigTemplateDetailsVO>
	 * @throws RMDWebException
	 * @Description This method is used to get the Templates for the selected
	 *              Controller Config and Config File.
	 * 
	 */
	@Override
	public List<ConfigTemplateDetailsVO> getCtrlCfgTemplates(
			String ctrlCfgObjId, String cfgFileName) throws RMDWebException{
		List<ConfigTemplateDetailsVO> arlTemplateDetailsVO = new ArrayList<ConfigTemplateDetailsVO>();
		Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		ConfigTemplateDetailsResponseType[] arrConfigTemplateDetailsResponseType =null;
		ConfigTemplateDetailsVO objConfigTemplateDetailsVO = null;
		try {
			queryParamMap.put(AppConstants.CTRL_CFG_OBJ_ID, ctrlCfgObjId);
			queryParamMap.put(AppConstants.CFG_FILE_NAME, cfgFileName);
			arrConfigTemplateDetailsResponseType = (ConfigTemplateDetailsResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_CONFIG_TEMPLATE_DETAILS, null,
							queryParamMap, null,
							ConfigTemplateDetailsResponseType[].class);
			if (null != arrConfigTemplateDetailsResponseType
					&& arrConfigTemplateDetailsResponseType.length > 0) {
				arlTemplateDetailsVO = new ArrayList<ConfigTemplateDetailsVO>(arrConfigTemplateDetailsResponseType.length);
				for (ConfigTemplateDetailsResponseType objRepairFacilityDetailsResponseType : arrConfigTemplateDetailsResponseType) {
					objConfigTemplateDetailsVO = new ConfigTemplateDetailsVO();
					objConfigTemplateDetailsVO
							.setTempObjId(objRepairFacilityDetailsResponseType
									.getTempObjId());
					objConfigTemplateDetailsVO.setTemplateNo(
									objRepairFacilityDetailsResponseType
											.getTemplateNo());
					objConfigTemplateDetailsVO.setVersionNo(
									objRepairFacilityDetailsResponseType
											.getVersionNo());
					objConfigTemplateDetailsVO.setTitle(ESAPI
							.encoder().decodeForHTML(
									objRepairFacilityDetailsResponseType
											.getTitle()));
					objConfigTemplateDetailsVO
							.setStatus(objRepairFacilityDetailsResponseType
									.getStatus());
					arlTemplateDetailsVO.add(objConfigTemplateDetailsVO);
					objConfigTemplateDetailsVO=null;
				}
				
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getRepairFacilityDetails() method of ConfigMaintenanceServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}finally{
			arrConfigTemplateDetailsResponseType =null;
			queryParamMap=null;
		}
		return arlTemplateDetailsVO;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:List<EFIDetailsVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the existing EFI templates
	 */
	@Override
	public List<EFIDetailsVO> getEFIDetails() throws RMDWebException {
		List<EFIDetailsVO> arlEFIDetailsVO = new ArrayList<EFIDetailsVO>();
		EFIDetailsResponseType[] efiResponseType = null;
		EFIDetailsVO objEFIDetailsVO = null;
		try {
			efiResponseType = (EFIDetailsResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_EFI_DETAILS, null,
							null, null,
							EFIDetailsResponseType[].class);
			if (null != efiResponseType
					&& efiResponseType.length > 0) {
				arlEFIDetailsVO = new ArrayList<EFIDetailsVO>(efiResponseType.length);
				for (EFIDetailsResponseType objEFIDetailsResponse : efiResponseType) {
					objEFIDetailsVO = new EFIDetailsVO();
					objEFIDetailsVO
							.setTempObjId(objEFIDetailsResponse
									.getTempObjId());
					objEFIDetailsVO.setTemplateNo(
									objEFIDetailsResponse
											.getTemplateNo());
					objEFIDetailsVO.setVersionNo(
									objEFIDetailsResponse
											.getVersionNo());
					objEFIDetailsVO.setIsActive(
									objEFIDetailsResponse
											.getIsActive());
					arlEFIDetailsVO.add(objEFIDetailsVO);
					objEFIDetailsVO=null;
				}
				
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getEFIDetails() method of ConfigMaintenanceServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}finally{
			efiResponseType =null;
		}
		return arlEFIDetailsVO;
	}

	/**
	 * @Author:
	 * @param:userName
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for creating new EFI templates
	 */
	@Override
	public String createNewEFI(String userName) throws RMDWebException {
		String result = AppConstants.FAILURE;
		Map<String, String> headerParams = new LinkedHashMap<String, String>();
		try {
			headerParams.put(AppConstants.CM_ALIAS_NAME, userName);
			result = (String) webServiceInvoker.post(
					ServiceConstants.CREATE_NEW_EFI, null,
					String.class, headerParams);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in createNewEFI() method of ConfigMaintenanceServiceImpl",
							ex);
			result = AppConstants.FAILURE;
			RMDWebErrorHandler.handleException(ex);
		}finally{
			headerParams =null;
		}
		return result;
	}
	
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the status for templates
	 */
	@Override
	public Map<String, String> getCtrlCfgStatus() throws RMDWebException{
		Map<String, String> cfgStatusMap = new LinkedHashMap<String, String>();
		Map<String, String> pathParams = new LinkedHashMap<String, String>();
		String templateStatus = null;
		ApplicationParametersResponseType[] applParamResponseType =null;
		try {
			pathParams.put(AppConstants.LIST_NAME, AppConstants.CTRL_CFG_STATUS_LIST);
			applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				cfgStatusMap = new LinkedHashMap<String, String>(applParamResponseType.length);
				for (int i = 0; i < applParamResponseType.length; i++) {
					templateStatus = applParamResponseType[i].getLookupValue();
					cfgStatusMap.put(templateStatus, templateStatus);
				}				
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCtrlCfgStatus() method of ConfigMaintenanceServiceImpl ", ex);
			RMDWebErrorHandler.handleException(ex);
		}finally{
			applParamResponseType=null;
			pathParams=null;
		}
		return cfgStatusMap;
	}
	
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the SearchBy dropdown values for EDP template
	 */
	@Override
	public Map<String, String> getEDPSearchByOptions() throws RMDWebException{
		Map<String, String> edpSearchByMap = new LinkedHashMap<String, String>();
		Map<String, String> pathParams = new LinkedHashMap<String, String>();
		ApplicationParametersResponseType[] applParamResponseType=null;
		String searchByVal = null;
		try {
			pathParams.put(AppConstants.LIST_NAME, AppConstants.CTRL_CFG_SEARCH_BY_LIST);
			applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				edpSearchByMap = new LinkedHashMap<String, String>(applParamResponseType.length);
				for (int i = 0; i < applParamResponseType.length; i++) {
					searchByVal = applParamResponseType[i].getLookupValue();
					edpSearchByMap.put(searchByVal, searchByVal);
				}
				
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getEDPSearchByOptions() method of ConfigMaintenanceServiceImpl ", ex);
			RMDWebErrorHandler.handleException(ex);
		}finally{
			applParamResponseType=null;
			pathParams=null;
		}
		return edpSearchByMap;
	}
	
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Condition dropdown values for EDP template
	 */
	@Override
	public Map<String, String> getEDPConditionOptions() throws RMDWebException{
		ApplicationParametersResponseType[] applParamResponseType=null;
		Map<String, String> edpConditionMap = new LinkedHashMap<String, String>();
		Map<String, String> pathParams = new LinkedHashMap<String, String>();
		String conditionVal = null;
		try {
			pathParams.put(AppConstants.LIST_NAME, AppConstants.CTRL_CFG_CONDITION_LIST);
			applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				edpConditionMap = new LinkedHashMap<String, String>(applParamResponseType.length);
				for (int i = 0; i < applParamResponseType.length; i++) {
					conditionVal = applParamResponseType[i].getLookupValue();
					edpConditionMap.put(conditionVal, conditionVal);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getEDPConditionOptions() method of ConfigMaintenanceServiceImpl ", ex);
			RMDWebErrorHandler.handleException(ex);
		}finally{
			pathParams=null;
			applParamResponseType=null;
		}
		return edpConditionMap;
	}
	
	/**
	 * @Author:
	 * @param:ctrlCfgObjId, cfgFileName
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the latest template Number
	 */
	@Override
	public String getMaxTemplateNumber(
			String ctrlCfgObjId, String cfgFileName) throws RMDWebException{
		String maxTempNo = null;
		Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		try {
			queryParamMap.put(AppConstants.CTRL_CFG_OBJ_ID, ctrlCfgObjId);
			queryParamMap.put(AppConstants.CFG_FILE_NAME, cfgFileName);
			maxTempNo = (String) webServiceInvoker
					.get(ServiceConstants.GET_MAX_TEMPLATE_NUMBER, null,
							queryParamMap, null,
							String.class);			
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getMaxTemplateNumber() method of ConfigMaintenanceServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}finally{
			queryParamMap=null;
		}
		return maxTempNo;
	}
	
	/**
	 * @Author:
	 * @param:ctrlCfgObjId, cfgFileName,templateNo
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the latest version number
	 *               of the opened template
	 */
	@Override
	public String getTempMaxVerNumber(String ctrlCfgObjId, String cfgFileName,
			String templateNo) throws RMDWebException {
		String tempMaxVerNo = null;
		Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		try {
			queryParamMap.put(AppConstants.CTRL_CFG_OBJ_ID, ctrlCfgObjId);
			queryParamMap.put(AppConstants.CFG_FILE_NAME, cfgFileName);
			queryParamMap.put(AppConstants.TEMPLATE_NO, templateNo);
			tempMaxVerNo = (String) webServiceInvoker
					.get(ServiceConstants.GET_TEMPLATE_MAX_VER_NUMBER, null,
							queryParamMap, null,
							String.class);			
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getTempMaxVerNumber() method of ConfigMaintenanceServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}finally{
			queryParamMap=null;
		}
		return tempMaxVerNo;
	}

	/**
	 * @Author:
	 * @param EDPSearchParamVO
	 * @return List<EDPParamDetailsVO>
	 * @throws RMDWebException
	 * @Description This method is used to get the parameters that can be added
	 *              for EDP templates.
	 * 
	 */
	@Override
	public List<EDPParamDetailsVO> getEDPParameters(
			EDPSearchParamVO objEDPSearchParamVO) throws RMDWebException {
		List<EDPParamDetailsVO> objEDPParamDetailsVOList = new ArrayList<EDPParamDetailsVO>();
		Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		EDPParamDetailsResponseType objEDPParamDetailsResponseType[] = null;
		EDPParamDetailsVO objEDPParamDetailsVO = null;
		try {
			queryParamMap.put(AppConstants.SEARCH_BY, objEDPSearchParamVO.getSearchBy());
			queryParamMap.put(AppConstants.CONDITION, objEDPSearchParamVO.getCondition());
			queryParamMap.put(AppConstants.SEARCH_VAL, ESAPI
					.encoder().encodeForXML(objEDPSearchParamVO
					.getSearchVal()));
			queryParamMap.put(AppConstants.CTRL_CFG_OBJ_ID, objEDPSearchParamVO
					.getCtrlCfgObjId());
			queryParamMap.put(AppConstants.CFG_FILE_NAME, objEDPSearchParamVO
					.getCfgFileName());
			 objEDPParamDetailsResponseType = (EDPParamDetailsResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_EDP_PARAMETRES, null,
							queryParamMap, null,
							EDPParamDetailsResponseType[].class);
			if (null != objEDPParamDetailsResponseType
					&& objEDPParamDetailsResponseType.length > 0) {
				objEDPParamDetailsVOList = new ArrayList<EDPParamDetailsVO>(
						objEDPParamDetailsResponseType.length);
				for (EDPParamDetailsResponseType objEDPParamDetailsResponse : objEDPParamDetailsResponseType) {
					objEDPParamDetailsVO = new EDPParamDetailsVO();
					objEDPParamDetailsVO
							.setParamObjId(objEDPParamDetailsResponse
									.getParamObjId());
					objEDPParamDetailsVO.setParamNo(objEDPParamDetailsResponse
							.getParamNo());
					objEDPParamDetailsVO.setCtrlName(objEDPParamDetailsResponse
							.getCtrlName());
					objEDPParamDetailsVO
							.setParamDesc(ESAPI
									.encoder().decodeForHTML(objEDPParamDetailsResponse
									.getParamDesc()));
					objEDPParamDetailsVO
							.setUsageRate(objEDPParamDetailsResponse
									.getUsageRate());
					objEDPParamDetailsVO.setUom(objEDPParamDetailsResponse
							.getUom());
					objEDPParamDetailsVO.setDestType(objEDPParamDetailsResponse
							.getDestType());
					objEDPParamDetailsVOList.add(objEDPParamDetailsVO);
					objEDPParamDetailsVO=null;

				}
				
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getEDPParameters() method of ConfigMaintenanceServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}finally{
			queryParamMap=null;
			objEDPParamDetailsResponseType = null;
		}
		return objEDPParamDetailsVOList;

	}

	/**
	 * @Author:
	 * @param:tempObjId
	 * @return:List< EDPParamDetailsVO >
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the opened template added
	 *               parameters
	 */
	@Override
	public List<EDPParamDetailsVO> getAddedEDPParams(String tempObjId)
			throws RMDWebException {
		List<EDPParamDetailsVO> objAddedEDPParamDetailsVOList = new ArrayList<EDPParamDetailsVO>();
		Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		EDPParamDetailsResponseType objAddedEDPParamDetailsResponseType[] = null;
		EDPParamDetailsVO objEDPParamDetailsVO = null;
		try {
			queryParamMap.put(AppConstants.TEMP_OBJ_ID, tempObjId);
			objAddedEDPParamDetailsResponseType = (EDPParamDetailsResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_ADDED_EDP_PARAMETRES, null,
							queryParamMap, null,
							EDPParamDetailsResponseType[].class);
			if (null != objAddedEDPParamDetailsResponseType
					&& objAddedEDPParamDetailsResponseType.length > 0) {
				objAddedEDPParamDetailsVOList = new ArrayList<EDPParamDetailsVO>(
						objAddedEDPParamDetailsResponseType.length);
				for (EDPParamDetailsResponseType objAddedEDPParamDetailsResponse : objAddedEDPParamDetailsResponseType) {
					objEDPParamDetailsVO = new EDPParamDetailsVO();
					objEDPParamDetailsVO
							.setParamObjId(objAddedEDPParamDetailsResponse
									.getParamObjId());
					objEDPParamDetailsVO.setParamNo(objAddedEDPParamDetailsResponse
							.getParamNo());
					objEDPParamDetailsVO.setCtrlName(objAddedEDPParamDetailsResponse
							.getCtrlName());
					objEDPParamDetailsVO
							.setParamDesc(ESAPI
									.encoder().decodeForHTML(objAddedEDPParamDetailsResponse
									.getParamDesc()));
					objEDPParamDetailsVO
							.setUsageRate(objAddedEDPParamDetailsResponse
									.getUsageRate());
					objEDPParamDetailsVO.setUom(objAddedEDPParamDetailsResponse
							.getUom());
					objEDPParamDetailsVO.setDestType(objAddedEDPParamDetailsResponse
							.getDestType());
					objAddedEDPParamDetailsVOList.add(objEDPParamDetailsVO);
					objEDPParamDetailsVO=null;

				}
				
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getAddedEDPParams() method of ConfigMaintenanceServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}finally{
			queryParamMap=null;
			objAddedEDPParamDetailsResponseType = null;
		}
		return objAddedEDPParamDetailsVOList;
	}

	/**
	 * @Author:
	 * @param:objAddEditEDPDetailsVO
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for creating or updating EDP templates
	 */
	@Override
	public String saveEDPTemplate(AddEditEDPDetailsVO objAddEditEDPDetailsVO)
			throws RMDWebException {
		String status = null;
		AddEditEDPRequestType objAddEditEDPRequestType = null;
		try {
			if (null != objAddEditEDPDetailsVO) {
				objAddEditEDPRequestType = new AddEditEDPRequestType();
				objAddEditEDPRequestType.setTempObjId(objAddEditEDPDetailsVO
						.getTempObjId());
				objAddEditEDPRequestType.setCtrlCfgObjId(objAddEditEDPDetailsVO
						.getCtrlCfgObjId());
				objAddEditEDPRequestType.setCtrlCfgName(objAddEditEDPDetailsVO
						.getCtrlCfgName());
				objAddEditEDPRequestType.setCfgFileName(objAddEditEDPDetailsVO
						.getCfgFileName());
				objAddEditEDPRequestType.setParamObjId(objAddEditEDPDetailsVO
						.getParamObjId());
				objAddEditEDPRequestType.setAddedParamObjId(objAddEditEDPDetailsVO
						.getAddedParamObjId());
				objAddEditEDPRequestType.setRemovedParamObjId(objAddEditEDPDetailsVO
						.getRemovedParamObjId());
				objAddEditEDPRequestType.setTemplateNo(objAddEditEDPDetailsVO
						.getTemplateNo());
				objAddEditEDPRequestType.setVersionNo(objAddEditEDPDetailsVO
						.getVersionNo());
				objAddEditEDPRequestType.setStatus(objAddEditEDPDetailsVO
						.getStatus());
				objAddEditEDPRequestType.setTitle(ESAPI
						.encoder().encodeForXML(objAddEditEDPDetailsVO
						.getTitle()));
				objAddEditEDPRequestType.setWhatNew(objAddEditEDPDetailsVO
						.getWhatNew());
				objAddEditEDPRequestType.setUserName(objAddEditEDPDetailsVO
						.getUserName());
				status = (String) (webServiceInvoker.post(
						ServiceConstants.SAVE_EDP_TEMPLATE,
						objAddEditEDPRequestType, String.class));
			}

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in saveEDPTemplate() method of ConfigMaintenanceServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}finally{
			objAddEditEDPRequestType=null;
		}

		return status;
	}

	/**
	 * @Author:
	 * @param:String cfgFileName,
			String templateNo, String versionNo, String ctrlCfgObjId
	 * @return:EDPHeaderDetailsVO
	 * @throws:RMDWebException
	 * @Description: This method is used for getting the Next/Previous EDP
	 *               template templates
	 */
	@Override
	public EDPHeaderDetailsVO getPreNextEDPDetails(String cfgFileName,
			String templateNo, String versionNo,String ctrlCfgObjId) throws RMDWebException {
		Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		EDPHeaderDetailsVO tempHeaderVO = null;
		EDPHeaderResponseType headerDetailsResponse = null;
		try {
			queryParamMap.put(AppConstants.CFG_FILE_NAME, cfgFileName);
			queryParamMap.put(AppConstants.TEMPLATE_NO, templateNo);
			queryParamMap.put(AppConstants.VERSION_NO, versionNo);
			queryParamMap.put(AppConstants.CTRL_CFG_OBJ_ID, ctrlCfgObjId);
			headerDetailsResponse = (EDPHeaderResponseType) webServiceInvoker
						.get(ServiceConstants.GET_PRE_NEXT_EDP_DETAILS, null,
								queryParamMap, null,
								EDPHeaderResponseType.class);
			if(null!=headerDetailsResponse){
				tempHeaderVO=new EDPHeaderDetailsVO();
				tempHeaderVO.setTempObjId(headerDetailsResponse.getTempObjId());
				tempHeaderVO.setCtrlCfgObjId(headerDetailsResponse.getCtrlCfgObjId());
				tempHeaderVO.setCfgFileName(headerDetailsResponse.getCfgFileName());
				tempHeaderVO.setCtrlCfgName(headerDetailsResponse.getCtrlCfgName());
				tempHeaderVO.setTemplateNo(headerDetailsResponse.getTemplateNo());
				tempHeaderVO.setVesrionNo(headerDetailsResponse.getVesrionNo());
				tempHeaderVO.setTitle(ESAPI
						.encoder().decodeForHTML(headerDetailsResponse.getTitle()));
				tempHeaderVO.setStatus(headerDetailsResponse.getStatus());				
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getPreNextEDPDetails() method of ConfigMaintenanceServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}finally{
			queryParamMap=null;
			headerDetailsResponse=null;
		}
		 return tempHeaderVO;
	}
	/**
	 * @Author:
	 * @param:String configId
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetch parameter title list
	 * 
	 */
	@Override
	public Map<String, String> getParameterTitle(String configId)
			throws RMDWebException {
		FaultValueResponseType[] objFFDResponseType = null;
		Map<String, String> objParameter = new HashMap<String, String>();
		Map<String, String> queryParams = new LinkedHashMap<String, String>();
		try {
			queryParams.put(AppConstants.CONFIG_ID, configId);
			objFFDResponseType = (FaultValueResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_PARAMETER_TITLE, null,
							queryParams, null, FaultValueResponseType[].class);
			if (null != objFFDResponseType && objFFDResponseType.length > 0) {
				for (FaultValueResponseType fFDResponseType : objFFDResponseType) {
					objParameter.put(fFDResponseType.getParameterTitle(),
							fFDResponseType.getObjId());
				}
			}
			
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getParameterTitle() method - ConfigMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally{
			queryParams=null;
			objFFDResponseType = null;
		}

		return objParameter;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching operator values from
	 *               Lookup table
	 */
	@Override
	public Map<String, String> getOperatorList() throws RMDWebException {
		final Map<String, String> operatorList = new HashMap<String, String>();
		String operator = null,text = AppConstants.EMPTY_SPACE, value = AppConstants.ZERO;
		int count = 1;
		List<ApplicationParametersResponseType> applParamResponseTypeList=null;
		try {
			applParamResponseTypeList = cachedService
					.getAllLookupValues().get(AppConstants.CONFIG_OPERTORS);
			if (applParamResponseTypeList != null
					&& applParamResponseTypeList.size() > 0) {

				for (ApplicationParametersResponseType objResponse : applParamResponseTypeList) {
					if (!(AppConstants.SPECIFY.equalsIgnoreCase(objResponse
							.getLookupValue()))) {
						operator = objResponse.getLookupValue();
						operatorList.put(value, text);
						operatorList.put(String.valueOf(count), operator);
						count++;
					}
				}
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getOperatorList() method - ConfigMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally{
			applParamResponseTypeList = null;
		}
		return operatorList;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching conjunction values from
	 *               Lookup table
	 */
	@Override
	public Map<String, String> getConjunctionList() throws RMDWebException {
		final Map<String, String> conjunctionList = new HashMap<String, String>();
		String conjunction = null, text = AppConstants.EMPTY_SPACE, value = AppConstants.ZERO;
		int count = 1;
		List<ApplicationParametersResponseType> applParamResponseTypeList=null;
		try {
			applParamResponseTypeList = cachedService
					.getAllLookupValues().get(AppConstants.CONFIG_CONJUNCTION);
			if (applParamResponseTypeList != null
					&& applParamResponseTypeList.size() > 0) {

				for (ApplicationParametersResponseType objResponse : applParamResponseTypeList) {
					if (!(AppConstants.SPECIFY.equalsIgnoreCase(objResponse
							.getLookupValue()))) {
						conjunction = objResponse.getLookupValue();
						conjunctionList.put(value, text);
						conjunctionList.put(String.valueOf(count), conjunction);
						count++;
					}
				}
			}
			
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getConjunctionList() method - ConfigMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally{
			applParamResponseTypeList = null;
		}
		return conjunctionList;
	}

	/**
	 * @Author:
	 * @param:String configId,String templateId,String versionId
	 * @return:List<FaultFilterDefDetails>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching FFD Template list from
	 *               database
	 */
	@Override
	public List<FaultFilterDefDetails> populateFFDDetails(String configId,
			String templateId, String versionId) throws RMDWebException {
		FFDResponseType[] objFFDResponseType = null;
		List<FaultFilterDefDetails> objFaultFilterDefDetails = new ArrayList<FaultFilterDefDetails>();
		Map<String, String> queryParams = new LinkedHashMap<String, String>();
		FaultFilterDefDetails faultFilterDefDetails = null;
		try {
			queryParams.put(AppConstants.CONFIG_ID, configId);
			queryParams.put(AppConstants.TEMPLATE_ID, templateId);
			queryParams.put(AppConstants.VERSION_ID, versionId);
			objFFDResponseType = (FFDResponseType[]) webServiceInvoker.get(
					ServiceConstants.POPULATE_FFD_DETAILS, null, queryParams,
					null, FFDResponseType[].class);
			if (null != objFFDResponseType && objFFDResponseType.length > 0) {
				objFaultFilterDefDetails = new ArrayList<FaultFilterDefDetails>(
						objFFDResponseType.length);
				for (FFDResponseType ffdResponseType : objFFDResponseType) {
					faultFilterDefDetails = new FaultFilterDefDetails();
					faultFilterDefDetails.setConjunction(ffdResponseType
							.getConjunction());
					faultFilterDefDetails.setOperatorFrom(ffdResponseType
							.getOperatorFrom());
					faultFilterDefDetails.setOperatorTo(ffdResponseType
							.getOpertorTo());
					faultFilterDefDetails.setParameterTitle(ffdResponseType
							.getParameterTitle());
					faultFilterDefDetails.setValueFrom(ffdResponseType
							.getValueFrom());
					faultFilterDefDetails.setValueTo(ffdResponseType
							.getValueTo());
					faultFilterDefDetails.setParameterObjId(ffdResponseType
							.getParameterObjId());
					faultFilterDefDetails.setObjectId(ffdResponseType
							.getObjId());
					objFaultFilterDefDetails.add(faultFilterDefDetails);
					faultFilterDefDetails=null;
				}
			}
			
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in objFaultFilterDefDetails() method - ConfigMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally{
			queryParams=null;
			objFFDResponseType = null;
		}
		return objFaultFilterDefDetails;

	}

	/**
	 * @Author:
	 * @param:List<FFDDetailsVO>
	 * @return:List<FaultRangeDefDetails>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching FRD Template list from
	 *               database
	 */
	@Override
	public List<FaultRangeDefDetails> populateFRDDetails(
			List<FFDDetailsVO> ffdDetailsVO) throws RMDWebException {
		FRDResponseType[] objFRDResponseType = null;
		List<FaultRangeDefDetails> objFaultRangeDefDetails = new ArrayList<FaultRangeDefDetails>();
		Map<String, String> queryParams = new LinkedHashMap<String, String>();
		FaultRangeDefDetails faultRangeDefDetails = null;
		String configId = null, templateId = null, versionId = null, configValue = null;
		try {
			for (FFDDetailsVO objffdDetailsVO : ffdDetailsVO) {
				configId = objffdDetailsVO.getConfigId();
				templateId = objffdDetailsVO.getTemplateId();
				versionId = objffdDetailsVO.getVersion();
				configValue = objffdDetailsVO.getConfigValue();
			}

			queryParams.put(AppConstants.CONFIG_ID, configId);
			queryParams.put(AppConstants.TEMPLATE_ID, templateId);
			queryParams.put(AppConstants.VERSION_ID, versionId);
			queryParams.put(AppConstants.CONFIG_VALUE, configValue);
			objFRDResponseType = (FRDResponseType[]) webServiceInvoker.get(
					ServiceConstants.POPULATE_FRD_DETAILS, null, queryParams,
					null, FRDResponseType[].class);
			if (null != objFRDResponseType && objFRDResponseType.length > 0) {
				objFaultRangeDefDetails = new ArrayList<FaultRangeDefDetails>(
						objFRDResponseType.length);
				for (FRDResponseType frdResponseType : objFRDResponseType) {
					faultRangeDefDetails = new FaultRangeDefDetails();
					faultRangeDefDetails.setBiasValue(frdResponseType
							.getBiasValue());
					faultRangeDefDetails.setPostValue(frdResponseType
							.getPostValue());
					faultRangeDefDetails.setPreValue(frdResponseType
							.getPreValue());
					faultRangeDefDetails.setEdpTemplate(frdResponseType
							.getEdpTemplate());
					faultRangeDefDetails.setFaultCodeFrom(frdResponseType
							.getFaultCodeFrom());
					faultRangeDefDetails.setFaultCodeTo(frdResponseType
							.getFaultCodeTo());
					if((AppConstants.ZERO).equals(frdResponseType
							.getSubIdFrom()))
					{
						faultRangeDefDetails.setSubIdFrom(AppConstants.EMPTY_SPACE);	
					}
					else
					{
						faultRangeDefDetails.setSubIdFrom(frdResponseType
								.getSubIdFrom());	
					}
					if((AppConstants.ZERO).equals(frdResponseType
							.getSubIdTo()))
					{
						faultRangeDefDetails.setSubIdTo(AppConstants.EMPTY_SPACE);
					}
					else
					{
					faultRangeDefDetails.setSubIdTo(frdResponseType
							.getSubIdTo());
					}
					faultRangeDefDetails.setVersion(frdResponseType
							.getVersion());
					faultRangeDefDetails.setFaultSource(frdResponseType
							.getFaultSource());
					faultRangeDefDetails.setObjId(frdResponseType.getObjId());
					faultRangeDefDetails.setFaultStart(frdResponseType
							.getFaultStart());
					faultRangeDefDetails.setFaultEnd(frdResponseType
							.getFaultEnd());
					faultRangeDefDetails.setControllerName(frdResponseType
							.getControllerName());
					objFaultRangeDefDetails.add(faultRangeDefDetails);
				}
			}
			
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in objFaultRangeDefDetails() method - ConfigMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally{
			queryParams=null;
			objFRDResponseType = null;
		}

		return objFaultRangeDefDetails;
	}

	/**
	 * @Author:
	 * @param:List<FaultFilterDefDetails>
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for save FFD Template details in
	 *               database
	 */
	@Override
	public String saveFFDTemplate(
			List<FaultFilterDefDetails> lstFaultFilterDefDetails)
			throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<FFDRequestType> FFDRequestType = new ArrayList<FFDRequestType>();
		FFDRequestType objFFDRequestType = new FFDRequestType();
		FFDRequestType ffdRequestType = null;
		try {

			for (FaultFilterDefDetails objFaultFilterDefDetails : lstFaultFilterDefDetails) {
				ffdRequestType = new FFDRequestType();

				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getConfigId())) {
					ffdRequestType.setConfigId(objFaultFilterDefDetails
							.getConfigId());
				} else {
					ffdRequestType.setConfigId(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getConfigValue())) {
					ffdRequestType.setConfigValue(objFaultFilterDefDetails
							.getConfigValue());
				} else {
					ffdRequestType.setConfigValue(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getConjunction())) {
					if (objFaultFilterDefDetails.getConjunction().matches(
							"[0-9]+")) {
						ffdRequestType.setConjunction(objFaultFilterDefDetails
								.getConjunction());
					} else {
						if (objFaultFilterDefDetails.getConjunction().equals(
								"AND")) {
							ffdRequestType.setConjunction("1");
						} else if (objFaultFilterDefDetails.getConjunction()
								.equals("OR")) {
							ffdRequestType.setConjunction("2");
						} else if (objFaultFilterDefDetails.getConjunction()
								.equals("NOT AND")) {
							ffdRequestType.setConjunction("3");
						} else if (objFaultFilterDefDetails.getConjunction()
								.equals("NOT OR")) {
							ffdRequestType.setConjunction("4");
						} else if (objFaultFilterDefDetails.getConjunction()
								.equals("AND NOT")) {
							ffdRequestType.setConjunction("5");
						} else if (objFaultFilterDefDetails.getConjunction()
								.equals("OR NOT")) {
							ffdRequestType.setConjunction("6");
						} else {
							ffdRequestType.setConjunction("0");
						}
					}

				} else {
					ffdRequestType.setConjunction(AppConstants.ZERO);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getOperatorFrom())) {
					if (objFaultFilterDefDetails.getOperatorFrom().matches(
							"[0-9]+")) {
						ffdRequestType.setOperatorFrom(objFaultFilterDefDetails
								.getOperatorFrom());
					} else {
						if (objFaultFilterDefDetails.getOperatorFrom().equals(
								"=")) {
							ffdRequestType.setOperatorFrom("1");
						} else if (objFaultFilterDefDetails.getOperatorFrom()
								.equals("<>")) {
							ffdRequestType.setOperatorFrom("2");
						} else if (objFaultFilterDefDetails.getOperatorFrom()
								.equals(">")) {
							ffdRequestType.setOperatorFrom("3");
						} else if (objFaultFilterDefDetails.getOperatorFrom()
								.equals("<")) {
							ffdRequestType.setOperatorFrom("4");
						} else if (objFaultFilterDefDetails.getOperatorFrom()
								.equals(">=")) {
							ffdRequestType.setOperatorFrom("5");
						} else if (objFaultFilterDefDetails.getOperatorFrom()
								.equals("<=")) {
							ffdRequestType.setOperatorFrom("6");
						} else {
							ffdRequestType.setOperatorFrom("0");
						}
					}
				} else {
					ffdRequestType.setOperatorFrom(AppConstants.ZERO);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getOperatorTo())) {
					if (objFaultFilterDefDetails.getOperatorTo().matches(
							"[0-9]+")) {
						ffdRequestType.setOpertorTo(objFaultFilterDefDetails
								.getOperatorTo());
					} else {
						if (objFaultFilterDefDetails.getOperatorTo()
								.equals("=")) {
							ffdRequestType.setOpertorTo("1");
						} else if (objFaultFilterDefDetails.getOperatorTo()
								.equals("<>")) {
							ffdRequestType.setOpertorTo("2");
						} else if (objFaultFilterDefDetails.getOperatorTo()
								.equals(">")) {
							ffdRequestType.setOpertorTo("3");
						} else if (objFaultFilterDefDetails.getOperatorTo()
								.equals("<")) {
							ffdRequestType.setOpertorTo("4");
						} else if (objFaultFilterDefDetails.getOperatorTo()
								.equals(">=")) {
							ffdRequestType.setOpertorTo("5");
						} else if (objFaultFilterDefDetails.getOperatorTo()
								.equals("<=")) {
							ffdRequestType.setOpertorTo("6");
						} else {
							ffdRequestType.setOpertorTo("0");
						}
					}
				} else {
					ffdRequestType.setOpertorTo(AppConstants.ZERO);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getParameterTitle())) {
					ffdRequestType.setParameterTitle(objFaultFilterDefDetails
							.getParameterTitle());
				} else {
					ffdRequestType.setParameterTitle(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getTitle())) {
					ffdRequestType.setTitle(ESAPI.encoder().encodeForXML(
							objFaultFilterDefDetails.getTitle()));
				} else {
					ffdRequestType.setTitle(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getTemplate())) {
					ffdRequestType.setTemplate(objFaultFilterDefDetails
							.getTemplate());
				} else {
					ffdRequestType.setTemplate(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getStatus())) {
					ffdRequestType.setStatus(objFaultFilterDefDetails
							.getStatus());
				} else {
					ffdRequestType.setStatus(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getVersion())) {
					ffdRequestType.setVersion(objFaultFilterDefDetails
							.getVersion());
				} else {
					ffdRequestType.setVersion(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getValueFrom())) {
					ffdRequestType.setValueFrom(objFaultFilterDefDetails
							.getValueFrom());
				} else {
					ffdRequestType.setValueFrom(AppConstants.ZERO);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getValueTo())) {
					ffdRequestType.setValueTo(objFaultFilterDefDetails
							.getValueTo());
				} else {
					ffdRequestType.setValueTo(AppConstants.ZERO);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getUserName())) {
					ffdRequestType.setUserName(objFaultFilterDefDetails
							.getUserName());
				} else {
					ffdRequestType.setUserName(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getAction())) {
					ffdRequestType.setAction(objFaultFilterDefDetails
							.getAction());
				} else {
					ffdRequestType.setAction(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getObjid())) {
					ffdRequestType
							.setObjId(objFaultFilterDefDetails.getObjid());
				} else {
					ffdRequestType.setObjId(AppConstants.ZERO);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultFilterDefDetails
						.getParameterObjId())) {
					ffdRequestType.setParameterObjId(objFaultFilterDefDetails
							.getParameterObjId());
				} else {
					ffdRequestType.setParameterObjId(AppConstants.EMPTY_STRING);
				}

				FFDRequestType.add(ffdRequestType);
			}
			objFFDRequestType.setArlFFDRequestType(FFDRequestType);
			status = (String) webServiceInvoker.post(
					ServiceConstants.SAVE_FFD_TEMPLATE, objFFDRequestType,
					String.class);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("Exception occured in saveFFDTemplate method  method of ConfigMaintenanceServiceImpl ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		
		return status;
	}

	/**
	 * @Author:
	 * @param:List<FaultRangeDefDetails>
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for save FRD Template details in
	 *               database
	 */
	@Override
	public String saveFRDTemplate(
			List<FaultRangeDefDetails> lstFaultRangeDefDetails)
			throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<FRDRequestType> FRDRequestType = new ArrayList<FRDRequestType>();
		FRDRequestType objFRDRequestType = new FRDRequestType();
		FRDRequestType frdRequestType = null;
		try {

			for (FaultRangeDefDetails objFaultRangeDefDetails : lstFaultRangeDefDetails) {
				frdRequestType = new FRDRequestType();

				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getConfigId())) {
					frdRequestType.setConfigId(objFaultRangeDefDetails
							.getConfigId());
				} else {
					frdRequestType.setConfigId(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getConfigValue())) {
					frdRequestType.setConfigValue(objFaultRangeDefDetails
							.getConfigValue());
				} else {
					frdRequestType.setConfigValue(AppConstants.EMPTY_STRING);
				}

				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getTitle())) {
					frdRequestType.setTitle(ESAPI.encoder().encodeForXML(
							objFaultRangeDefDetails.getTitle()));
				} else {
					frdRequestType.setTitle(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getTemplate())) {
					frdRequestType.setTemplate(objFaultRangeDefDetails
							.getTemplate());
				} else {
					frdRequestType.setTemplate(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getStatus())) {
					frdRequestType.setStatus(objFaultRangeDefDetails
							.getStatus());
				} else {
					frdRequestType.setStatus(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getVersion())) {
					frdRequestType.setVersion(objFaultRangeDefDetails
							.getVersion());
				} else {
					frdRequestType.setVersion(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getUserName())) {
					frdRequestType.setUserName(objFaultRangeDefDetails
							.getUserName());
				} else {
					frdRequestType.setUserName(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getFaultCodeFrom())) {
					frdRequestType.setFaultCodeFrom(objFaultRangeDefDetails
							.getFaultCodeFrom());
				} else {
					frdRequestType.setFaultCodeFrom(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getFaultCodeTo())) {
					frdRequestType.setFaultCodeTo(objFaultRangeDefDetails
							.getFaultCodeTo());
				} else {
					frdRequestType.setFaultCodeTo(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getFaultSource())) {
					frdRequestType.setFaultSource(objFaultRangeDefDetails
							.getFaultSource());
				} else {
					frdRequestType.setFaultSource(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getSubIdFrom())) {
					frdRequestType.setSubIdFrom(objFaultRangeDefDetails
							.getSubIdFrom());
				} else {
					frdRequestType.setSubIdFrom(AppConstants.ZERO);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getSubIdTo())) {
					frdRequestType.setSubIdTo(objFaultRangeDefDetails
							.getSubIdTo());
				} else {
					frdRequestType.setSubIdTo(AppConstants.ZERO);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getEdpTemplate())) {
					frdRequestType.setEdpTemplate(objFaultRangeDefDetails
							.getEdpTemplate());
				} else {
					frdRequestType.setEdpTemplate(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getPreValue())) {
					frdRequestType.setPreValue(objFaultRangeDefDetails
							.getPreValue());
				} else {
					frdRequestType.setPreValue(AppConstants.ZERO);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getPostValue())) {
					frdRequestType.setPostValue(objFaultRangeDefDetails
							.getPostValue());
				} else {
					frdRequestType.setPostValue(AppConstants.ZERO);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getBiasValue())) {
					frdRequestType.setBiasValue(objFaultRangeDefDetails
							.getBiasValue());
				} else {
					frdRequestType.setBiasValue(AppConstants.ZERO);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getAction())) {
					frdRequestType.setAction(objFaultRangeDefDetails
							.getAction());
				} else {
					frdRequestType.setAction(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getTempVersion())) {
					frdRequestType.setTempVersion(objFaultRangeDefDetails
							.getTempVersion());
				} else {
					frdRequestType.setTempVersion(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getCtrlSourceId())) {
					frdRequestType.setCtrlSourceId(objFaultRangeDefDetails
							.getCtrlSourceId());
				} else {
					frdRequestType.setCtrlSourceId(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getFaultStart())) {
					frdRequestType.setFaultStart(objFaultRangeDefDetails
							.getFaultStart());
				} else {
					frdRequestType.setFaultStart(AppConstants.ZERO);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getFaultEnd())) {
					frdRequestType.setFaultEnd(objFaultRangeDefDetails
							.getFaultEnd());
				} else {
					frdRequestType.setFaultEnd(AppConstants.ZERO);
				}
				FRDRequestType.add(frdRequestType);
			}
			objFRDRequestType.setArlFRDRequestType(FRDRequestType);
			status = (String) webServiceInvoker.post(
					ServiceConstants.SAVE_FRD_TEMPLATE, objFRDRequestType,
					String.class);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("Exception occured in saveFRDTemplate method  method of ConfigMaintenanceServiceImpl ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return status;
	}

	/**
	 * @Author:
	 * @param:List<FFDDetailsVO>
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for remove FRD Template details in
	 *               database
	 */
	@Override
	public String removeFRDTemplate(List<FFDDetailsVO> ffdDetailsVO)
			throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<ConfigRequestType> lstconfigRequestType = new ArrayList<ConfigRequestType>();
		ConfigRequestType objConfigRequestType = new ConfigRequestType();
		ConfigRequestType configRequestType = null;
		try {

			for (FFDDetailsVO objFFDDetailsVO : ffdDetailsVO) {
				configRequestType = new ConfigRequestType();

				if (!RMDCommonUtility.isNullOrEmpty(objFFDDetailsVO.getObjId())) {
					configRequestType.setObjId(objFFDDetailsVO.getObjId());
				} else {
					configRequestType.setObjId(AppConstants.EMPTY_STRING);
				}
				lstconfigRequestType.add(configRequestType);
			}
			objConfigRequestType.setArlConfigRequestType(lstconfigRequestType);
			status = (String) webServiceInvoker.post(
					ServiceConstants.REMOVE_FRD_TEMPLATE, objConfigRequestType,
					String.class);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("Exception occured in removeFRDTemplate method  method of ConfigMaintenanceServiceImpl ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return status;
	}

	/**
	 * @Author:
	 * @param:List<FFDDetailsVO>
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for remove FFD Template details in
	 *               database
	 */
	@Override
	public String removeFFDTemplate(List<FFDDetailsVO> ffdDetailsVO)
			throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<ConfigRequestType> lstconfigRequestType = new ArrayList<ConfigRequestType>();
		ConfigRequestType objConfigRequestType = new ConfigRequestType();
		ConfigRequestType configRequestType = null;
		try {

			for (FFDDetailsVO objFFDDetailsVO : ffdDetailsVO) {
				configRequestType = new ConfigRequestType();

				if (!RMDCommonUtility.isNullOrEmpty(objFFDDetailsVO.getObjId())) {
					configRequestType.setObjId(objFFDDetailsVO.getObjId());
				} else {
					configRequestType.setObjId(AppConstants.ZERO);
				}

				lstconfigRequestType.add(configRequestType);
			}
			objConfigRequestType.setArlConfigRequestType(lstconfigRequestType);
			status = (String) webServiceInvoker.post(
					ServiceConstants.REMOVE_FFD_TEMPLATE, objConfigRequestType,
					String.class);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("Exception occured in removeFFDTemplate method  method of ConfigMaintenanceServiceImpl ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return status;
	}

	/**
	 * @Author:
	 * @param:FaultValueResponseType[]
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching EDP template value
	 */
	@Override
	public Map<String, String> getEDPTemplate(String configId)
			throws RMDWebException {
		FaultValueResponseType[] objFaultValueResponseType = null;
		Map<String, String> edpTemplate = new HashMap<String, String>();
		Map<String, String> queryParams = new LinkedHashMap<String, String>();
		try {
			queryParams.put(AppConstants.CONFIG_ID, configId);
			objFaultValueResponseType = (FaultValueResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_EDP_TEMPLATE, null, queryParams,
							null, FaultValueResponseType[].class);
			if (null != objFaultValueResponseType
					&& objFaultValueResponseType.length > 0) {
				for (FaultValueResponseType faultValueResponseType : objFaultValueResponseType) {
					edpTemplate.put(
							faultValueResponseType.getObjId(),
							faultValueResponseType.getCfgDetailDesc()
									+ AppConstants.DOT
									+ faultValueResponseType.getCfgVersion()
									+ AppConstants.UNDERSCORE
									+ faultValueResponseType.getCfgDesc());
				}
			}
			
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getEDPTemplate() method - ConfigMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally{
			queryParams=null;
			objFaultValueResponseType = null;
		}
		return edpTemplate;
	}

	/**
	 * @Author:
	 * @param:String configId, String configValue
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching fault source list.
	 */
	@Override
	public Map<String, String> getFaultSource(String configId,
			String configValue) throws RMDWebException {
		FaultValueResponseType[] objFRDResponseType = null;
		Map<String, String> faultSourceMap = new HashMap<String, String>();
		Map<String, String> queryParams = new LinkedHashMap<String, String>();
		try {
			queryParams.put(AppConstants.CONFIG_ID, configId);
			queryParams.put(AppConstants.CONFIG_VALUE, configValue);
			objFRDResponseType = (FaultValueResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_FAULT_SOURCE, null, queryParams,
							null, FaultValueResponseType[].class);
			if (null != objFRDResponseType && objFRDResponseType.length > 0) {
				for (FaultValueResponseType fRDResponseType : objFRDResponseType) {
					faultSourceMap.put(fRDResponseType.getObjId(),
							fRDResponseType.getFaultSource() + "-"
									+ fRDResponseType.getControllerName());
				}
			}
			
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getFaultSource() method - ConfigMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally{
			queryParams=null;
			objFRDResponseType = null;
		}
		return faultSourceMap;
	}

	/**
	 * @Author:
	 * @param:FaultValueResponseType[]
	 * @return:List<FRDDetailsVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching default values from
	 *               database.
	 */
	@Override
	public List<FRDDetailsVO> getDefaultValuesRange() throws RMDWebException {
		FaultValueResponseType[] objFaultValueResponseType = null;
		List<FRDDetailsVO> lstFRDDetailsVO = new ArrayList<FRDDetailsVO>();
		FRDDetailsVO objFRDDetailsVO = null;
		Map<String, String> queryParams = new LinkedHashMap<String, String>();
		try {
			objFaultValueResponseType = (FaultValueResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_DEFAULT_VALUES_RANGE, null,
							queryParams, null, FaultValueResponseType[].class);
			if (null != objFaultValueResponseType
					&& objFaultValueResponseType.length > 0) {
				lstFRDDetailsVO = new ArrayList<FRDDetailsVO>(
						objFaultValueResponseType.length);
				for (FaultValueResponseType faultValueResponseType : objFaultValueResponseType) {
					objFRDDetailsVO = new FRDDetailsVO();
					objFRDDetailsVO.setBiasValue(faultValueResponseType
							.getBiasValue());
					objFRDDetailsVO.setPreValue(faultValueResponseType
							.getPreValue());
					objFRDDetailsVO.setPostValue(faultValueResponseType
							.getPostValue());
					lstFRDDetailsVO.add(objFRDDetailsVO);

				}
			}
			
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getDefaultValuesRange() method - ConfigMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally{
			queryParams=null;
			objFaultValueResponseType = null;
		}

		return lstFRDDetailsVO;
	}

	/**
	 * @Author:
	 * @param:String configId,String templateId,String configFile
	 * @return:Integer
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching maximum version value
	 */
	@Override
	public int getMaximumVersion(String configId, String templateId,
			String configFile) throws RMDWebException {
		Map<String, String> queryParams = new LinkedHashMap<String, String>();
		String maximumVersion = null;
		int maxVersion = 0;
		try {
			queryParams.put(AppConstants.CONFIG_ID, configId);
			queryParams.put(AppConstants.TEMPLATE_ID, templateId);
			queryParams.put(AppConstants.CONFIG_FILE, configFile);
			maximumVersion = (String) webServiceInvoker.get(
					ServiceConstants.GET_MAXIMUM_VERSION, null, queryParams,
					null, String.class);
			if (maximumVersion != null) {
				maxVersion = Integer.parseInt(maximumVersion);
			} else {
				maxVersion = 0;
			}

		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getMaximumVersion() method - ConfigMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally{
			queryParams=null;
		}

		return maxVersion;
	}

	/**
	 * @Author:
	 * @param:String configId,String configFile
	 * @return:Integer
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching current template value.
	 */
	@Override
	public int getCurrentTemplate(String configId, String configFile)
			throws RMDWebException {
		Map<String, String> queryParams = new LinkedHashMap<String, String>();
		String currentTemplate = null;
		int currentTemp = 0;
		try {
			queryParams.put(AppConstants.CONFIG_ID, configId);
			queryParams.put(AppConstants.CONFIG_FILE, configFile);
			currentTemplate = (String) webServiceInvoker.get(
					ServiceConstants.GET_CURRENT_TEMPLATE, null, queryParams,
					null, String.class);
			if (currentTemplate != null) {
				currentTemp = Integer.parseInt(currentTemplate);
			} else {
				currentTemp = 0;
			}

		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getCurrentTemplate() method - ConfigMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally{
			queryParams=null;
		}
		return currentTemp;
	}

	/**
	 * @Author:
	 * @param:String configId, String templateId, String versionId
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching status values
	 */
	@Override
	public String getCurrentStatus(String configId, String templateId,
			String versionId) throws RMDWebException {
		Map<String, String> queryParams = new LinkedHashMap<String, String>();
		String currentStatus = null;
		try {
			queryParams.put(AppConstants.CONFIG_ID, configId);
			queryParams.put(AppConstants.TEMPLATE_ID, templateId);
			queryParams.put(AppConstants.VERSION_ID, versionId);
			currentStatus = (String) webServiceInvoker.get(
					ServiceConstants.GET_CURRENT_STATUS, null, queryParams,
					null, String.class);

		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getCurrentStatus() method - ConfigMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally{
			queryParams=null;
		}
		return currentStatus;
	}

	/**
	 * @Author:
	 * @param:String configId, String templateId, String versionId
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching title values
	 */
	@Override
	public String getTitle(String configId, String templateId, String versionId)
			throws RMDWebException {
		Map<String, String> queryParams = new LinkedHashMap<String, String>();
		String title = null;
		try {
			queryParams.put(AppConstants.CONFIG_ID, configId);
			queryParams.put(AppConstants.TEMPLATE_ID, templateId);
			queryParams.put(AppConstants.VERSION_ID, versionId);
			title = (String) webServiceInvoker.get(ServiceConstants.GET_TITLE,
					null, queryParams, null, String.class);

		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getTitle() method - ConfigMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally{
			queryParams=null;
		}
		return title;
	}

	/**
	 * @Author:
	 * @param:String configId, String templateId, String versionId
	 * @return:List<FFDDetailsVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching status details
	 */
	@Override
	public List<FFDDetailsVO> getStatusDetails(String configId,
			String templateId, String versionId) throws RMDWebException {
		FaultValueResponseType[] objFRDResponseType = null;
		Map<String, String> queryParams = new LinkedHashMap<String, String>();
		List<FFDDetailsVO> lstFFDDetailsVO = new ArrayList<FFDDetailsVO>();
		FFDDetailsVO ffdDetailsVO = null;
		try {
			queryParams.put(AppConstants.CONFIG_ID, configId);
			queryParams.put(AppConstants.TEMPLATE_ID, templateId);
			queryParams.put(AppConstants.VERSION_ID, versionId);
			objFRDResponseType = (FaultValueResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_STATUS_DETAILS, null,
							queryParams, null, FaultValueResponseType[].class);
			if (null != objFRDResponseType && objFRDResponseType.length > 0) {
				for (FaultValueResponseType fRDResponseType : objFRDResponseType) {
					ffdDetailsVO = new FFDDetailsVO();
					ffdDetailsVO.setStatus(fRDResponseType.getStatus());
					ffdDetailsVO.setObjId(fRDResponseType.getObjId());
					ffdDetailsVO.setDescription(fRDResponseType.getCfgDesc());
					lstFFDDetailsVO.add(ffdDetailsVO);
				}
			}
			
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getStatusDetails() method - ConfigMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally{
			queryParams=null;
			objFRDResponseType = null;
		}
		return lstFFDDetailsVO;
	}

	/**
	 * @Author:
	 * @param:List<FaultRangeDefDetails>
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for check fault range details
	 */
	@Override
	public String checkFaultRange(
			List<FaultRangeDefDetails> lstFaultRangeDetails)
			throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<FRDRequestType> lstconfigRequestType = new ArrayList<FRDRequestType>();
		FRDRequestType objFRDRequestType = null;
		FRDRequestType frdRequestType = new FRDRequestType();
		try {

			for (FaultRangeDefDetails objFaultRangeDefDetails : lstFaultRangeDetails) {
				objFRDRequestType = new FRDRequestType();

				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getFaultSource())) {
					objFRDRequestType.setFaultSource(objFaultRangeDefDetails
							.getFaultSource());
				} else {
					objFRDRequestType.setFaultSource(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getFaultStart())) {
					objFRDRequestType.setFaultStart(objFaultRangeDefDetails
							.getFaultStart());
				} else {
					objFRDRequestType.setFaultStart(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getFaultEnd())) {
					objFRDRequestType.setFaultEnd(objFaultRangeDefDetails
							.getFaultEnd());
				} else {
					objFRDRequestType.setFaultEnd(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getFaultCodeFrom())) {
					objFRDRequestType.setFaultCodeFrom(objFaultRangeDefDetails
							.getFaultCodeFrom());
				} else {
					objFRDRequestType
							.setFaultCodeFrom(AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objFaultRangeDefDetails
						.getFaultCodeTo())) {
					objFRDRequestType.setFaultCodeTo(objFaultRangeDefDetails
							.getFaultCodeTo());
				} else {
					objFRDRequestType.setFaultCodeTo(AppConstants.EMPTY_STRING);
				}
				lstconfigRequestType.add(objFRDRequestType);
			}
			frdRequestType.setArlFRDRequestType(lstconfigRequestType);
			status = (String) webServiceInvoker.post(
					ServiceConstants.CHECK_FAULT_RANGE, frdRequestType,
					String.class);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("Exception occured in checkFaultRange method  method of ConfigMaintenanceServiceImpl ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return status;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching maximum number of
	 *               parameter allowed details.
	 */
	@Override
	public String getMaxParameterCount() throws RMDWebException {
		String maxParameterCount = null;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		try {
			maxParameterCount = (String) webServiceInvoker.get(
					ServiceConstants.GET_MAX_PARAMETER_COUNT, null,
					queryParams, null, String.class);

		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getMaxParameterCount() method - ConfigMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}

		return maxParameterCount;
	}

	
	 /**
     * @Author:
     * @param:
     * @return:List<ConfigTemplateDetailsVO>
     * @throws:RMDWebException
     * @Description: This method is used for get the list of Templates associated with a unit.
     */
	@Override
	public List<ConfigTemplateDetailsVO> getTemplateReport(final TemplateReportBean templateReportBean) throws RMDWebException{
		List<ConfigTemplateDetailsVO> arlTemplateDetailsVO = new ArrayList<ConfigTemplateDetailsVO>();
		Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		TemplateReportResponseType[] arrTemplateReportResponseType=null;
		ConfigTemplateDetailsVO objConfigTemplateDetailsVO = null;
		try {
			
			if(null!=templateReportBean){
				if(!RMDCommonUtility.isNullOrEmpty(templateReportBean.getConfigFile())){
					queryParamMap.put(RMDCommonConstants.CONFIG_TYPE, EsapiUtil.stripXSSCharacters(templateReportBean.getConfigFile()));
				}
				if(!RMDCommonUtility.isNullOrEmpty(templateReportBean.getControllerConfigId())){
					queryParamMap.put(RMDCommonConstants.CONTROLLER_ID, EsapiUtil.stripXSSCharacters(templateReportBean.getControllerConfigId()));
				}
				if(!RMDCommonUtility.isNullOrEmpty(templateReportBean.getRoadNumber())){
					queryParamMap.put(RMDCommonConstants.VEHICLE_NO, EsapiUtil.stripXSSCharacters(templateReportBean.getRoadNumber()));
				}
				if(!RMDCommonUtility.isNullOrEmpty(templateReportBean.getCustomerId())){
					queryParamMap.put(RMDCommonConstants.CUSTOMER_ID, EsapiUtil.stripXSSCharacters(templateReportBean.getCustomerId()));
				}
				if(!RMDCommonUtility.isNullOrEmpty(templateReportBean.getRoadNumberHdr())){
					queryParamMap.put(RMDCommonConstants.VEHICLE_HEADER, EsapiUtil.stripXSSCharacters(templateReportBean.getRoadNumberHdr()));
				}
				if(!RMDCommonUtility.isNullOrEmpty(templateReportBean.getTemplateNumber())){
					queryParamMap.put(RMDCommonConstants.TEMPLATE_NO,EsapiUtil.stripXSSCharacters(templateReportBean.getTemplateNumber()));
				}
				if(!RMDCommonUtility.isNullOrEmpty(templateReportBean.getTemplateStatus())){
					queryParamMap.put(RMDCommonConstants.TEMPLATE_STATUS,EsapiUtil.stripXSSCharacters(templateReportBean.getTemplateStatus()));
				}
				if(!RMDCommonUtility.isNullOrEmpty(templateReportBean.getTemplateTitle())){
					queryParamMap.put(RMDCommonConstants.TEMPLATE,EsapiUtil.stripXSSCharacters(templateReportBean.getTemplateTitle()));
				}
				if(!RMDCommonUtility.isNullOrEmpty(templateReportBean.getTemplateVersion())){
					queryParamMap.put(RMDCommonConstants.VERSION_NO,EsapiUtil.stripXSSCharacters(templateReportBean.getTemplateVersion()));
				}
			}
			
			arrTemplateReportResponseType=(TemplateReportResponseType[])webServiceInvoker
					.get(ServiceConstants.GET_CONFIG_TEMPLATE_REPORT, null,
							queryParamMap, null,
							TemplateReportResponseType[].class);
			
			if(null!=arrTemplateReportResponseType && arrTemplateReportResponseType.length>0){
				arlTemplateDetailsVO = new ArrayList<ConfigTemplateDetailsVO>(arrTemplateReportResponseType.length);				
				for (TemplateReportResponseType templateReportResponseType : arrTemplateReportResponseType) {
					objConfigTemplateDetailsVO = new ConfigTemplateDetailsVO();
					objConfigTemplateDetailsVO.setStatus(templateReportResponseType.getTemplateStatus());
					objConfigTemplateDetailsVO.setTemplateNo(templateReportResponseType.getTemplateNumber());
					objConfigTemplateDetailsVO.setTitle(templateReportResponseType.getTemplateDescription());
					objConfigTemplateDetailsVO.setVersionNo(templateReportResponseType.getTemplateVersion());
					objConfigTemplateDetailsVO.setConfigFile(templateReportResponseType.getConfigType());
					objConfigTemplateDetailsVO.setOffBoardStatus(templateReportResponseType.getOffboardTemplateStatus());
					objConfigTemplateDetailsVO.setOnBoardStatus(templateReportResponseType.getOnboardTemplateStatus());
					objConfigTemplateDetailsVO.setRoadNumber(templateReportResponseType.getAssetNumber());
					objConfigTemplateDetailsVO.setRoadNumberHdr(templateReportResponseType.getAssetGroupName());
					objConfigTemplateDetailsVO.setCustomerId(templateReportResponseType.getCustomerID());
					objConfigTemplateDetailsVO.setControllerConfig(templateReportResponseType.getControllerCfg());
					objConfigTemplateDetailsVO.setOnBoardStatusDate(templateReportResponseType.getOnboardTemplateDate());
					objConfigTemplateDetailsVO.setOffBoardStatusDate(templateReportResponseType.getOffboardTemplateDate());
					arlTemplateDetailsVO.add(objConfigTemplateDetailsVO);
				}
			}
			
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getTemplateReport() method of ConfigMaintenanceServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}finally{
			arrTemplateReportResponseType =null;
			queryParamMap=null;
		}
		return arlTemplateDetailsVO;
	}
	
	/**
     * @Author :
     * @return :String
     * @param : String tempObjId,String templateNo,String versionNo,String userId,String status
     * @throws :RMDWebException
     * @Description: This method is Responsible for updating the RCI template
     * 
     */
	@Override
    public String updateRCITemplate(String tempObjId,String templateNo,String versionNo,String userId,String status) throws RMDWebException {
        String result = RMDCommonConstants.EMPTY_STRING;
        Map<String, String> queryParams = null;
        try{
            queryParams = new LinkedHashMap<String, String>();
            queryParams.put(AppConstants.TEMP_OBJ_ID, tempObjId);
            queryParams.put(AppConstants.TEMPLATE_NO, templateNo);
            queryParams.put(AppConstants.VERSION_NO, versionNo);
            queryParams.put(AppConstants.USER_ID, userId);
            queryParams.put(AppConstants.STATUS, status);
           
            result = (String) webServiceInvoker
                    .get(ServiceConstants.UPDATE_RCI_TEMPLATE, null,
                            queryParams, null,
                            String.class);
            
        
        }catch (Exception ex) {
            result = AppConstants.FAILURE;
            rmdWebLogger
                    .error("Exception occured in updateRCITemplate method ",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        
        return result;
    }
    
		/**
    * @Author:
    * @param:
    * @return:List<ConfigTemplateDetailsVO>
    * @throws:RMDWebException
    * @Description: This method is used to call RCI Template details.
    */
	public String saveRCITemplate(final TemplateReportBean templateInfo)
			throws RMDWebException {
		String status = RMDCommonConstants.FAIL;
		TemplateRequestType templateRequestType = null;
		try {
			if (null != templateInfo) {
				templateRequestType = new TemplateRequestType();
				if (null != templateInfo.getConfigFile()) {
					templateRequestType.setConfigType(templateInfo
							.getConfigFile());
				}
                if (null != templateInfo.getTemplateTitle()) {
                    templateRequestType.setTemplateDescription(EsapiUtil
                            .escapeSpecialChars(ESAPI.encoder().encodeForXML(
                                    templateInfo.getTemplateTitle())));
                }
				if (null != templateInfo.getTemplateVersion()) {
					templateRequestType.setTemplateVersion(templateInfo
							.getTemplateVersion());
				}
                if (null != templateInfo.getTemplateFileContent()) {
                    templateRequestType.setTemplateFileContent(EsapiUtil
                            .escapeSpecialChars(ESAPI.encoder().encodeForXML(
                                    templateInfo.getTemplateFileContent())));
                }
				if (null != templateInfo.getTemplateTitle()) {
					templateRequestType.setTemplateFileName(templateInfo
							.getFileName());
				}
				if (null != templateInfo.getTemplateStatus()) {
                    templateRequestType.setTemplateStatus(templateInfo
                            .getTemplateStatus());
                }
				if (null != templateInfo.getFaultCode()) {
				    templateRequestType.setFaultCode(templateInfo
							.getFaultCode());
				}
				if (null != templateInfo.getTemplateNumber()) {
					templateRequestType.setTemplateNumber(templateInfo
							.getTemplateNumber());
				}
				if (null != templateInfo.getUserName()) {
                    templateRequestType.setUserName(templateInfo
                            .getUserName());
                }
				status = (String) webServiceInvoker.post(
						ServiceConstants.SAVE_RCI_TEMPLATE,
						templateRequestType, String.class);
			}

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in saveRCITemplate() method of ConfigMaintenanceServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		} finally {
			templateRequestType = null;
		}
		return status;
	}
}
