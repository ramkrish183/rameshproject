package com.ge.trans.rmd.cm.mvc.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.UnitShipperService;
import com.ge.trans.rmd.cm.valueobjects.UnitShipDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.UnitShippersVO;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.CustomerVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.pp.beans.AssetBean;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class UnitShipperController extends RMDBaseController {
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private UnitShipperService unitShipperService;

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param : caseBean
	 * @throws :RMDWebException
	 * @Description: Displays the Shippers page of the RMD application when
	 *               clicked on Shippers Tab in Administration Page.
	 * 
	 */
	@RequestMapping(AppConstants.REQ_URI_SHIPPERS)
	public ModelAndView showShippersPage(final HttpServletRequest request)
			throws RMDWebException {

		Calendar cal = Calendar.getInstance();
		final SimpleDateFormat fromDateFormat = new SimpleDateFormat(
				AppConstants.DATE_FORMAT_24HRS);
		String currentDate = null;
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		currentDate = fromDateFormat.format(cal.getTime());
		request.setAttribute(AppConstants.PP_CURRENT_DATE, currentDate);
		return new ModelAndView(AppConstants.SHIPPERS);

	}

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param :
	 * @throws :RMDWebException
	 * @Description: Displays the Shipped Units page of the RMD application when
	 *               user clicks on Last Shipped Units Button in Shippers
	 *               Screen.
	 * 
	 */
	@RequestMapping(AppConstants.REQ_URI_SHIPPED_UNITS)
	public ModelAndView showShippedUnitsPage(final HttpServletRequest request)
			throws RMDWebException {

		return new ModelAndView(AppConstants.SHIPPED_UNITS);

	}

	/**
	 * @Author :
	 * @return :List<UnitShippersVO>
	 * @param :final HttpServletRequest request
	 * @throws :RMDWebException
	 * @Description: This Method Fetches the list of Units to be shipped.
	 * 
	 */
	@RequestMapping(AppConstants.GET_UNIT_TO_BE_SHIPPED)
	public @ResponseBody
	List<UnitShippersVO> getUnitsToBeShipped(final HttpServletRequest request)
			throws RMDWebException {
		List<UnitShippersVO> arlUnits = new ArrayList<UnitShippersVO>();
		String defaultTimezone=EsapiUtil.stripXSSCharacters((String)request.getAttribute(AppConstants.DEFAULT_TIMEZONE));
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String filterCustmrList = null, rnh = null, roadNumber = null, customerList = null;
		try {
			String timeZone = EsapiUtil.stripXSSCharacters(userVO.getTimeZone());
			filterCustmrList = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CUSTOMER_NAME));
			rnh = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_GROUP_NAME));
			roadNumber = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_NUMBER));
			UnitShipDetailsVO objDetailsVO = new UnitShipDetailsVO();
			if (null != userVO.getCustomerId()) {
				customerList = getCustomerList(userVO.getCustomerList());
			}
			if (!RMDCommonUtility.isNullOrEmpty(filterCustmrList)) {
				objDetailsVO.setCustomerList(filterCustmrList);
			} else {
				objDetailsVO.setCustomerList(customerList);
			}

			if (!RMDCommonUtility.isNullOrEmpty(rnh)) {
				objDetailsVO.setAssetGrpName(rnh);
			}

			if (!RMDCommonUtility.isNullOrEmpty(roadNumber)) {
				objDetailsVO.setAssetNumber(roadNumber);
			}

			arlUnits = unitShipperService.getUnitsToBeShipped(objDetailsVO,
					timeZone,defaultTimezone);

		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getUnitsToBeShipped() method - UnitShipperController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlUnits;

	}

	/**
	 * @Author :
	 * @return :List<UnitShippersVO>
	 * @param :HttpServletRequest request
	 * @throws :RMDWebException
	 * @Description: This Method Fetches the list of Units which are already
	 *               Shipped.
	 * 
	 */

	@RequestMapping(AppConstants.GET_LAST_SHIPPED_UNITS)
	public @ResponseBody
	List<UnitShippersVO> getLastShippedUnits(final HttpServletRequest request)
			throws RMDWebException {
		List<UnitShippersVO> arlLastShippedUnits = new ArrayList<UnitShippersVO>();
		String defaultTimezone=EsapiUtil.stripXSSCharacters((String)request.getAttribute(AppConstants.DEFAULT_TIMEZONE));
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String customerName = null, rnh = null, roadNumber = null, isDefaultLoad = null, customerList = null;
		try {
			String timeZone = EsapiUtil.stripXSSCharacters(userVO.getTimeZone());
			customerName = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CUSTOMER_NAME));
			rnh = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_GROUP_NAME));
			roadNumber = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_NUMBER));
			isDefaultLoad = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.IS_DEFAULT_LOAD));
			UnitShipDetailsVO objDetailsVO = new UnitShipDetailsVO();

			if (null != userVO.getCustomerId()) {
				customerList = getCustomerList(userVO.getCustomerList());
			}

			if (!RMDCommonUtility.isNullOrEmpty(customerName)) {
				objDetailsVO.setCustomerList(customerName);
			} else {
				objDetailsVO.setCustomerList(customerList);
			}
			if (!RMDCommonUtility.isNullOrEmpty(rnh)) {
				objDetailsVO.setAssetGrpName(rnh);
			}
			if (!RMDCommonUtility.isNullOrEmpty(roadNumber)) {
				objDetailsVO.setAssetNumber(roadNumber);
			}
			if (!RMDCommonUtility.isNullOrEmpty(isDefaultLoad)) {
				objDetailsVO.setIsDefaultLoad(isDefaultLoad);
			}

			arlLastShippedUnits = unitShipperService.getLastShippedUnits(
					objDetailsVO, timeZone,defaultTimezone);
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getLastShippedUnits() method - UnitShipperController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlLastShippedUnits;

	}

	/**
	 * @Author :
	 * @return :String
	 * @param :String
	 * @throws :RMDWebException
	 * @Description: This Method Fetches the list of Units to be shipped.
	 * 
	 */

	@RequestMapping(AppConstants.UPDATE_UNITS_TO_BE_SHIPPED)
	public @ResponseBody
	String updateUnitsToBeShipped(
			@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString,
			final HttpServletRequest request)
			throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<UnitShippersVO> arlShippersVOs = new ArrayList<UnitShippersVO>();
		final ObjectMapper mapper = new ObjectMapper();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			String timeZone = userVO.getTimeZone();
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			UnitShippersVO[] arrShippersVOs = mapper.readValue(EsapiUtil.stripXSSCharacters(parameterString),
					UnitShippersVO[].class);
			arlShippersVOs = Arrays.asList(arrShippersVOs);
			String result=checkForFutureDate(arlShippersVOs);
			if (AppConstants.SUCCESS.equalsIgnoreCase(result)) {
				status = unitShipperService.updateUnitsToBeShipped(
						arlShippersVOs, timeZone);
			} else {
				status =result;
			}
		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("RMDWebException occured in updateUnitsToBeShipped() method - UnitShipperController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return status;
	}

	/**
	 * @Author :
	 * @return :String
	 * @param :String
	 * @throws :RMDWebException
	 * @Description: This Method Fetches the list of customers.
	 * 
	 */

	public String getCustomerList(List<CustomerVO> customerVOList) {
		String customerList = "";
		for (CustomerVO customer : customerVOList) {
			customerList = customerList + EsapiUtil.stripXSSCharacters(customer.getCustomerName())
					+ AppConstants.COMMA;
		}
		customerList = customerList.substring(0, customerList.length() - 1);
		return customerList;
	}

	/**
	 * @Author :
	 * @return :boolean
	 * @param :List<UnitShippersVO> arlShippersVOs
	 * @throws :RMDWebException
	 * @Description: This Method Fetches the list of customers.
	 * 
	 */
	public String checkForFutureDate(List<UnitShippersVO> arlShippersVOs)
			throws RMDWebException {

		DateFormat formatter = new SimpleDateFormat(
				AppConstants.UTC_DATE_FORMAT);
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.set(Calendar.HOUR_OF_DAY, 23);
		cal.set(Calendar.MINUTE, 59);
		cal.set(Calendar.SECOND, 59);
		cal.set(Calendar.MILLISECOND, 999);
		Date sysDate = cal.getTime();
		try {
			for (UnitShippersVO objShippersVO : arlShippersVOs) {
				if (!RMDCommonUtility.isNullOrEmpty(objShippersVO
						.getTestTrackDate())) {
					Date testTrackDate = formatter.parse(objShippersVO
							.getTestTrackDate());
					if (RMDCommonUtility.isDate1AfterDate2(testTrackDate,
							sysDate)) {
						return AppConstants.INVALID_DATE;
					}

				}
				if (!RMDCommonUtility
						.isNullOrEmpty(objShippersVO.getShipDate())) {
					Date shipDate = formatter
							.parse(objShippersVO.getShipDate());
					if (RMDCommonUtility.isDate1AfterDate2(shipDate, sysDate)) {
						return AppConstants.INVALID_DATE;
					}
				}

				if (!RMDCommonUtility
						.isNullOrEmpty(objShippersVO.getShipDate())
						&& !RMDCommonUtility.isNullOrEmpty(objShippersVO
								.getTestTrackDate())) {
					Date testDate = formatter.parse(objShippersVO
							.getTestTrackDate());
					Date shipDt = formatter.parse(objShippersVO.getShipDate());
					if (RMDCommonUtility.isDate1AfterDate2(testDate, shipDt)) {
						return AppConstants.INVALID_SHIP_DATE;
					}
				}
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in checkForFutureDate() method - UnitShipperController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return AppConstants.SUCCESS;
	}

	@RequestMapping(value = AppConstants.GET_ASSET_NUMBERS_FOR_SHIP_UNITS, method = RequestMethod.GET)
	public @ResponseBody
	java.util.List<String> getAssetNumbersForShipUnits(
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId,
			@RequestParam(value = AppConstants.CREATCASE_ASSTGRP, required = true) final String assetGroup,
			@RequestParam(value = AppConstants.ASSET_NUMBER, required = true) final String assetNumber,
			@RequestParam(value = AppConstants.FLEET) final String fleet,
			final HttpServletRequest request, final Model model) throws RMDWebException {
		rmdWebLogger
		.debug("Inside UnitShipperController in getAssetNumbersForShipUnits Method");
		List<String> assetNumbers = null;
		AssetBean assetBean;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
		.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {

			assetBean = new AssetBean();
			assetBean.setUserFirstName(userVO.getStrFirstName());
			assetBean.setUserLastName(userVO.getStrLastName());
			assetBean.setUserId(userVO.getUserId());
			assetBean.setUserLanguage(userVO.getStrUserLanguage());
			assetBean.setCustomerId(EsapiUtil.stripXSSCharacters(customerId));
			assetBean.setAssetGroup(EsapiUtil.stripXSSCharacters(assetGroup));
			assetBean.setAssetNumber(EsapiUtil.stripXSSCharacters(assetNumber));
			assetBean.setFleetId(EsapiUtil.stripXSSCharacters(fleet));
			assetNumbers = unitShipperService.getAssetNumbersForShipUnits(assetBean);

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getAssetNumbersForShipUnits method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return assetNumbers;

	}

}
