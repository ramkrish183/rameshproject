/*******************************************************************************
 *
 * @Author 		: GE
 * @Version 	: 1.0
 * @Date Created: Jan 21, 2016
 * @Date Modified:
 * @Modified By : 
 * @Contact 	:
 * @Description : This class act as a controller to get call log data
 * 
 * @History		:
 *
 ******************************************************************************/
package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.AssetDataScreenService;
import com.ge.trans.rmd.cm.service.AssetOverviewService;
import com.ge.trans.rmd.cm.service.LDVRRequestsService;
import com.ge.trans.rmd.cm.valueobjects.ActivePreservationDataRequestVO;
import com.ge.trans.rmd.cm.valueobjects.ActivePreservationDataResponseVO;
import com.ge.trans.rmd.cm.valueobjects.CameraDetailsRequestVO;
import com.ge.trans.rmd.cm.valueobjects.CameraDetailsResponseVO;
import com.ge.trans.rmd.cm.valueobjects.CheckActiveLDVRPreservationRequestVO;
import com.ge.trans.rmd.cm.valueobjects.CheckActiveLDVRPreservationResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRPreservationRequestTemplateVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRRequestVO;
import com.ge.trans.rmd.cm.valueobjects.RemoveTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.RemoveTemplateResponseVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;


@Controller
@SessionAttributes
public class LDVRRequestController extends RMDBaseController {
     private final  RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

     @Autowired
     LDVRAssetPQController ldvrAssetPQController;
     
	@Autowired
	private LDVRRequestsService ldvrRequestsService;

	@Autowired
	private AuthorizationService authorizationService;

	@Autowired
	private ApplicationContext appContext;

	@Autowired
	private AssetOverviewService asstOvwService;
	
	@Autowired
	private AssetDataScreenService objAssetDataScreenService;
	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description:
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_REQUEST, method = RequestMethod.GET)
	public ModelAndView getLDVRRequestPage(final HttpServletRequest request)
			throws RMDWebException {
		String fromDate = null;
		String toDate = null;
		rmdWebLogger.info("Inside getLDVRRequest method");
		final String strAssetNumber = request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM);
		final String strAssetGroup = request
				.getParameter(AppConstants.ASSET_GROUP_NAME);
		String strCustomerId = request
				.getParameter(AppConstants.REQ_PARAM_CUSID);
		
		if(RMDCommonUtility.isNullOrEmpty(strCustomerId)){
			strCustomerId = asstOvwService.getCustomerId(strAssetNumber, strAssetGroup);
			//request.setAttribute(AppConstants.WS_PARAM_CUSTID, strCustomerId);
		}
		
		final String roadInitial = ldvrRequestsService.getRoadInitial(
				strCustomerId, strAssetNumber, strAssetGroup);
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		
		final SimpleDateFormat dateFormat = new SimpleDateFormat(RMDCommonConstants.ddMMyyyyHHmmss);
		
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);

		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());

		dateFormat.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
		Calendar fromDtCal = Calendar.getInstance();
		fromDtCal.add(Calendar.MINUTE, -40);
		fromDate = dateFormat.format(fromDtCal.getTime());
		rmdWebLogger.info("fromDate in getLDVRRequestPage " + fromDate);

		toDate = dateFormat.format(new Date());
		rmdWebLogger.info("toDate in getLDVRRequestPage " + toDate);

		request.setAttribute(AppConstants.FROM_DATE, fromDate);
		request.setAttribute(AppConstants.TO_DATE, toDate);
		request.setAttribute(AppConstants.REQ_PARAM_ASSTNUM, strAssetNumber);
		request.setAttribute(AppConstants.ASSET_GROUP_NAME, strAssetGroup);
		request.setAttribute(AppConstants.WS_PARAM_CUSTID, strCustomerId);
		request.setAttribute(AppConstants.LDVR_ROAD_INITIAL, roadInitial);

		return new ModelAndView(AppConstants.VIEW_LDVR_REQUESTS);
	}

	/**
	 * @param lcvRequestVO
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description:
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_SUBMIT_LDVR_REQUEST, method = RequestMethod.POST)
	@ResponseBody public String submitLDVRRequest(
			final HttpServletRequest request, LDVRRequestVO lcvRequestVO)
			throws RMDWebException {
		rmdWebLogger
				.info("Inside submitLCVRequest in ldvrStartStopRequest Method");
		String messageOutId = null;
		try {
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);

			final String roadNumber = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
			final String assetOwnerId = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_CUSID));
			final String roadInitial = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.LDVR_ROAD_INITIAL));
			
			final String defaultTimezone = (String) request
					.getAttribute(AppConstants.DEFAULT_TIMEZONE);

			String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
					userVO.getTimeZone());

			LDVRRequestVO ldvrRequestVO = new LDVRRequestVO();
			ldvrRequestVO.setRoadInitial(roadInitial);
			ldvrRequestVO.setAssetOwnerId(assetOwnerId);
			ldvrRequestVO.setRoadNumber(roadNumber);

			String requestType = request.getParameter("requestType");
			String device = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.DEVICE));

			if ("ldvr_start_stop".equals(requestType)) {
				String internalMemory = EsapiUtil.stripXSSCharacters(request
						.getParameter(AppConstants.LDVR_INTERNAL_MEMORY));
				String networkMemory =EsapiUtil.stripXSSCharacters( request
						.getParameter(AppConstants.LDVR_NETWORK_MEMORY));
				ldvrRequestVO.setInternalMemory(internalMemory);
				ldvrRequestVO.setExternalMemory(networkMemory);
			}
			if ("ldvr_data".equals(requestType)
					|| "ldvr_media".equals(requestType)
					|| "ldvr_preserv_download".equals(requestType)) {
				ldvrRequestVO.setSelectedCameras(EsapiUtil.stripXSSCharacters(request
						.getParameter(AppConstants.LDVR_SELECTED_CAMERAS)));
			}
			if ("ldvr_preserv_download".equals(requestType)) {
				String requestTitle = EsapiUtil.stripXSSCharacters(request
						.getParameter(AppConstants.LDVR_REQUEST_TITLE));
				String requestStartTime = EsapiUtil.stripXSSCharacters(request
						.getParameter(AppConstants.LDVR_REQUEST_START_TIME));
				String requestEndTime = EsapiUtil.stripXSSCharacters(request
						.getParameter(AppConstants.LDVR_REQUEST_END_TIME));
				if (!RMDCommonUtility.isNullOrEmpty(requestStartTime)) {
					// ldvrRequestVO.setStartTime(String.valueOf(format.parse(requestStartTime).getTime()));
					ldvrRequestVO.setStartTime(String.valueOf(convertDatetoEST(
							requestStartTime, applicationTimezone,
							RMDCommonConstants.ddMMyyyyHHmmss)));
				}
				if (!RMDCommonUtility.isNullOrEmpty(requestEndTime)) {
					// ldvrRequestVO.setEndTime(String.valueOf(format.parse(requestEndTime).getTime()));
					ldvrRequestVO.setEndTime(String.valueOf(convertDatetoEST(requestEndTime,
							applicationTimezone,
							RMDCommonConstants.ddMMyyyyHHmmss)));
				}
				
				String deletionType = EsapiUtil.stripXSSCharacters(request
						.getParameter(AppConstants.LDVR_DELETION_TYPE));
				String importance = EsapiUtil.stripXSSCharacters(request
						.getParameter(AppConstants.LDVR_IMPORTANCE));

				ldvrRequestVO.setRequestTitle(requestTitle);			
				ldvrRequestVO.setImportance(importance);
				ldvrRequestVO.setDeletionType(deletionType);
			}
			ldvrRequestVO.setDevice(device);
			ldvrRequestVO.setMessageId(getLDVRMessageID(requestType));
			ldvrRequestVO.setRequestorName(userVO.getUserId());

			rmdWebLogger.info("Request submitLDVRRequest :: "
					+ ldvrRequestVO.toString());

			messageOutId = ldvrRequestsService.submitLDVRRequest(ldvrRequestVO);

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in submitLDVRRequest  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return messageOutId;
	}

	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_CAMERA_DETAILS, method = RequestMethod.GET)
	@ResponseBody public  CameraDetailsResponseVO getLDVRCameraDetails(
			final HttpServletRequest request) throws RMDWebException {
		rmdWebLogger
				.info("Inside submitLCVRequest in getLDVRCameraDetails Method");

		CameraDetailsResponseVO cameraDetailsResponseVO = null;
		final String roadNumber = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String assetOwnerId =EsapiUtil.stripXSSCharacters( request
				.getParameter(AppConstants.REQ_PARAM_CUSID));
		final String roadInitial = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.LDVR_ROAD_INITIAL));

		String device = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.DEVICE));

		try {
			CameraDetailsRequestVO cameraDetailsRequestVO = new CameraDetailsRequestVO();
			cameraDetailsRequestVO.setRoadInitial(roadInitial);
			cameraDetailsRequestVO.setAssetOwnerId(assetOwnerId);
			cameraDetailsRequestVO.setRoadNumber(roadNumber);
			cameraDetailsRequestVO.setDevice(device);

			rmdWebLogger.info("Request getLDVRCameraDetails ::: "
					+ cameraDetailsRequestVO.toString());
			cameraDetailsResponseVO = ldvrRequestsService
					.getLDVRCameraDetails(cameraDetailsRequestVO);

		} catch (RMDWebException ex) {
			rmdWebLogger.error(
					"RMDWebException occured in getLDVRCameraDetails  method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLDVRCameraDetails  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return cameraDetailsResponseVO;

	}

	@RequestMapping(value = AppConstants.REQ_URI_GET_ACTIVE_PRESERVATION_DATA, method = RequestMethod.GET)
	@ResponseBody public ActivePreservationDataResponseVO getActivePreservationData(
			final HttpServletRequest request) throws RMDWebException {
		rmdWebLogger.info("Inside  getActivePreservationData Method");
		ActivePreservationDataRequestVO activePreservationDataRequestVO = new ActivePreservationDataRequestVO();
		ActivePreservationDataResponseVO activePreservationDataResponseVO = new ActivePreservationDataResponseVO();
		final String roadNumber = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String roadInitial = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.LDVR_ROAD_INITIAL));
		final String assetOwnerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_CUSID));
		String device = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.DEVICE));
	
		try {
			/*SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy HH:mm a");
			SimpleDateFormat  osdf = new SimpleDateFormat(RMDCommonConstants.ddMMyyyyHHmmss);*/
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
			final String defaultTimezone = (String) request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
			String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,	userVO.getTimeZone());
			//osdf.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
			
			
			activePreservationDataRequestVO.setRoadInitial(roadInitial);
			activePreservationDataRequestVO.setAssetOwnerId(assetOwnerId);
			activePreservationDataRequestVO.setRoadNumber(roadNumber);
			activePreservationDataRequestVO.setDevice(device);
			activePreservationDataRequestVO.setTimeZone(applicationTimezone);			
			
			activePreservationDataResponseVO = ldvrRequestsService
					.getActivePreservationData(activePreservationDataRequestVO);
			if(activePreservationDataResponseVO!=null){
				String recDateStr = activePreservationDataResponseVO.getRecordingDate();
				String presQUtilDtStr = activePreservationDataResponseVO.getPreservationQueueUtilizationDt();			
						
				if(!RMDCommonUtility.isNullOrEmpty(recDateStr)){
					activePreservationDataResponseVO.setRecordingDate(RMDCommonUtility
							.convertDateFormatTimezone(recDateStr,
									RMDCommonConstants.ddMMyyyyhhmma,
									RMDCommonConstants.ddMMyyyyHHmmss,
									applicationTimezone));
				}
			
				if(!RMDCommonUtility.isNullOrEmpty(presQUtilDtStr)){
					activePreservationDataResponseVO.setPreservationQueueUtilizationDt(RMDCommonUtility
							.convertDateFormatTimezone(presQUtilDtStr,
									RMDCommonConstants.MMddyyyyhhmma,
									RMDCommonConstants.ddMMyyyyHHmmss,
									applicationTimezone));
				}
				

				for( LDVRPreservationRequestTemplateVO  presReqT : activePreservationDataResponseVO.getActivePreservationTemplates()) {
					String statusDtTm = presReqT.getRequestedStartTime();
					String requestDtTm = presReqT.getRequestedEndTime();
					/*Date statusDateTimeD = sdf.parse(statusDtTm);
							
					presReqT.setRequestedStartTime(osdf.format(statusDateTimeD.getTime()));
					Date requestDateTimeD = sdf.parse(requestDtTm);
					presReqT.setRequestedEndTime(osdf.format(requestDateTimeD.getTime()));*/
					if(!RMDCommonUtility.isNullOrEmpty(statusDtTm)){
						presReqT.setRequestedStartTime(RMDCommonUtility
								.convertDateFormatTimezone(statusDtTm,
										RMDCommonConstants.MMddyyyyhhmma,
										RMDCommonConstants.ddMMyyyyHHmmss,
										applicationTimezone));
					}
					if(!RMDCommonUtility.isNullOrEmpty(requestDtTm)){
						presReqT.setRequestedEndTime(RMDCommonUtility
							.convertDateFormatTimezone(requestDtTm,
									RMDCommonConstants.MMddyyyyhhmma,
									RMDCommonConstants.ddMMyyyyHHmmss,
									applicationTimezone));				
					}
				}
			}
			
			
			
			
		} catch (RMDWebException ex) {
			rmdWebLogger
					.error("RMDWebException occured in getActivePreservationData  method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getActivePreservationData  method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return activePreservationDataResponseVO;

	}

	@RequestMapping(value = AppConstants.REQ_URI_CHECK_ACTIVE_LDVR_PRESERVATION_REQUESTS, method = RequestMethod.GET)
	@ResponseBody public  CheckActiveLDVRPreservationResponseVO checkActiveLDVRPreservationRequests(
			final HttpServletRequest request) throws RMDWebException {

		rmdWebLogger
				.info("Inside submitLCVRequest in checkActiveLDVRPreservationRequests Method");
		CheckActiveLDVRPreservationRequestVO checkActiveLDVRPreservationRequestVO = new CheckActiveLDVRPreservationRequestVO();
		CheckActiveLDVRPreservationResponseVO checkActiveLDVRPreservationResponseVO = null;

		final String roadNumber = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String roadInitial = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.LDVR_ROAD_INITIAL));
		final String assetOwnerId =EsapiUtil.stripXSSCharacters( request
				.getParameter(AppConstants.REQ_PARAM_CUSID));

		String device = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.DEVICE));
		checkActiveLDVRPreservationRequestVO.setRoadInitial(roadInitial);
		checkActiveLDVRPreservationRequestVO.setAssetOwnerId(assetOwnerId);
		checkActiveLDVRPreservationRequestVO.setRoadNumber(roadNumber);
		checkActiveLDVRPreservationRequestVO.setDevice(device);

		try {
			checkActiveLDVRPreservationResponseVO = ldvrRequestsService
					.checkActiveLDVRPreservationRequests(checkActiveLDVRPreservationRequestVO);
		} catch (RMDWebException ex) {
			rmdWebLogger
					.error("RMDWebException occured in checkActiveLDVRPreservationRequests  method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in checkActiveLDVRPreservationRequests  method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return checkActiveLDVRPreservationResponseVO;
	}

	@RequestMapping(value = AppConstants.REQ_URI_REMOVE_TEMPLATE, method = RequestMethod.POST)
	@ResponseBody public  RemoveTemplateResponseVO removeTemplate(
			final HttpServletRequest request) throws RMDWebException {
		rmdWebLogger.info("Inside  removeTemplate Method");

		RemoveTemplateRequestVO removeTemplateRequestVO = new RemoveTemplateRequestVO();
		RemoveTemplateResponseVO removTemplateResponse = null;
		final String roadNumber = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String roadInitial = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.LDVR_ROAD_INITIAL));
		final String assetOwnerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_CUSID));

		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String userName = userVO.getUserId();

		ObjectMapper mapper = new ObjectMapper();
		List<String> templateIds = null;
		try {
			templateIds = mapper.readValue(
					EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TEMPLATE_IDS)),
					new TypeReference<List<String>>() {
					});

			rmdWebLogger.info("Templateid list size" + templateIds.size());
			StringBuilder templateIdsStr = new StringBuilder();
			for (String tmplID : templateIds) {
				if (templateIdsStr.length() != 0) {
					templateIdsStr.append(",");
				}
				templateIdsStr.append(tmplID);
			}

			String device = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.DEVICE));
			removeTemplateRequestVO.setRoadInitial(roadInitial);
			removeTemplateRequestVO.setAssetOwnerId(assetOwnerId);
			removeTemplateRequestVO.setRoadNumber(roadNumber);
			removeTemplateRequestVO.setDevice(device);
			removeTemplateRequestVO.setUserName("");
			removeTemplateRequestVO.setTemplateIds(templateIdsStr.toString());
			removeTemplateRequestVO.setUserName(userName);

			removTemplateResponse = ldvrRequestsService
					.removeTemplate(removeTemplateRequestVO);
		} catch (RMDWebException ex) {
			rmdWebLogger.error(
					"RMDWebException occured in removeTemplate  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in removeTemplate  method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return removTemplateResponse;

	}

	/**
	 * @param request
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description Function to get user preferred timezone date.
	 */
	@RequestMapping(value = AppConstants.GET_LDVR_MESSAGE_ID, method = RequestMethod.GET)
	@ResponseBody  public String getLDVRMessageID(String listName)
			throws RMDWebException {

		String messageID = null;
		try {
			messageID = authorizationService.getLookUpValueForName(listName);
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getLDVRMessageID() method - LDVRRequestController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return messageID;
	}

	/**
	 * @Author:
	 * @param:HttpServletRequest reques
	 * @return:List<CallLogVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for exporting call log notes to CSV
	 *               Format.
	 */

	@RequestMapping(AppConstants.EXPORT_LDVR_REQUEST)
	@ResponseBody public  void exportLDVRRequest(
			final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws RMDWebException, Exception {
		ActivePreservationDataResponseVO activePreservationDataResponseVO = null;
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;		
		try {
			activePreservationDataResponseVO = getActivePreservationData(request);
			csvContent = convertToCSVLDVRRequest(
					activePreservationDataResponseVO
							.getActivePreservationTemplates(),
					locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.LDVR_REQUEST_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);
			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);
			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"Exception occured in exportLDVRRequest method ", rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in exportLDVRRequest method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}

	/**
	 * @Description:This method is used convert Queue cases into csv format
	 * @return: String
	 * @param:List<QueueCaseVO> queuCasesList, Locale locale
	 * @throws RMDWebException 
	 * @throws GenericAjaxException 
	 */
	private String convertToCSVLDVRRequest(
			List<LDVRPreservationRequestTemplateVO> ldvrPreservationReqLst,
			Locale locale) throws GenericAjaxException, RMDWebException {
		String csvContent = null;
		StringBuilder strBuilderAssetHeader = new StringBuilder();
		try {
			strBuilderAssetHeader.append(appContext.getMessage(
					AppConstants.LDVR_REQUEST_HEADER, null, locale));

			strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);

			for (LDVRPreservationRequestTemplateVO ldvrMsgVO : ldvrPreservationReqLst) {
			
				if (ldvrMsgVO.getTitle() != null) {
					strBuilderAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + ldvrMsgVO.getTitle()
							+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (ldvrMsgVO.getNumVer() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ ldvrMsgVO.getNumVer()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (ldvrMsgVO.getComplete() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ ldvrMsgVO.getComplete()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (ldvrMsgVO.getFilesPreserved() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ ldvrMsgVO.getFilesPreserved()
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (ldvrMsgVO.getRequestedStartTime() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ ldvrMsgVO.getRequestedStartTime()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (ldvrMsgVO.getRequestedEndTime() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ ldvrMsgVO.getRequestedEndTime()
									+ AppConstants.QUOTE);

				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}

				strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBuilderAssetHeader.toString();
		} catch (Exception ex) {
			rmdWebLogger.error("Export to CSV LDVR Request List"+ ex.getMessage());
			RMDWebErrorHandler.handleException(ex);
		}
		return csvContent;
	}
	
	/**
	 * @param lcvRequestVO
	 * @Author:
	 * @return
	 * @throws Exception 
	 * @Description:
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_CHECK_LCV_LDVR_REQUEST, method = RequestMethod.GET)
	@ResponseBody public  boolean checkLCVLDVRStatus(
			final HttpServletRequest request)
			throws RMDWebException,Exception {
		rmdWebLogger
				.info("Inside LDVRRequestController in checkLCVLDVRStatus Method");	
		boolean isLocoEnabled = false; 
		try {		
			
			final String strAssetNumber = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
			final String strAssetGroup = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.ASSET_GROUP_NAME));
			String strCustomerId = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_CUSID));
			
			if(RMDCommonUtility.isNullOrEmpty(strCustomerId)){
				strCustomerId = asstOvwService.getCustomerId(strAssetNumber, strAssetGroup);
				request.setAttribute(AppConstants.WS_PARAM_CUSTID, strCustomerId);
			}
			
			final String roadInitial = ldvrRequestsService.getRoadInitial(
					strCustomerId, strAssetNumber, strAssetGroup);
						
			LDVRRequestVO ldvrRequestVO = new LDVRRequestVO();
			ldvrRequestVO.setRoadInitial(roadInitial);
			ldvrRequestVO.setAssetOwnerId(strCustomerId);
			ldvrRequestVO.setRoadNumber(strAssetNumber);	
			ldvrRequestVO.setDevice(AppConstants.LCV_DEVICE_TYPE);		
			
			rmdWebLogger.info("Request checkLCVLDVRStatus :: "
					+ ldvrRequestVO.toString());
			
            List<String> ldvrAssetNumber = ldvrAssetPQController
                    .getAssetsProducts(strCustomerId, strAssetGroup,
                            strAssetNumber, null, request, null);
			
			if(CollectionUtils.isEmpty(ldvrAssetNumber)){
			    
                String errorMsg = ldvrRequestsService.getLookupValueForError(
                        AppConstants.LCV_PRODUCT_MAPPING_ERROR_CD, "");
			    throw new RMDWebException(AppConstants.LCV_PRODUCT_MAPPING_ERROR_CD, "InvalidAssetException",
			            errorMsg);
			}
			isLocoEnabled = ldvrRequestsService.getLDVRAssetSnapshotList(ldvrRequestVO);

		}catch (RMDWebException ex) {
            rmdWebLogger.error(
                    "RMDWebException occured in checkLCVLDVRStatus method ",
                    ex);
            if (!ex.getErrorCode().equalsIgnoreCase(
                    AppConstants.LCV_PRODUCT_MAPPING_ERROR_CD)) {
                String errorMsg = ldvrRequestsService.getLookupValueForError(AppConstants.LCV_LDVR_CHECK_ERROR_CD, "");
                if(!RMDCommonUtility.isNullOrEmpty(errorMsg)){
                    ex.setErrorType(errorMsg);
                }
            }           
            RMDWebErrorHandler.handleException(ex);
        } catch (Exception ex) {
            rmdWebLogger.error(
                    "Exception occured in checkLCVLDVRStatus  method ", ex);
            String errorMsg = ldvrRequestsService.getLookupValueForError(
                    AppConstants.LCV_LDVR_CHECK_ERROR_CD, "");
            if (!RMDCommonUtility.isNullOrEmpty(errorMsg)) {
                RMDWebErrorHandler.handleException(new RMDWebException(
                        AppConstants.LCV_LDVR_CHECK_ERROR_CD, "MCSException", errorMsg));
            }
        }
		return isLocoEnabled;
	}	
	
	public long convertDatetoEST(String fromDate, String timeZone,
			String format) throws RMDWebException {
		long convertedDate = 0;
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat(format);
			SimpleDateFormat estDateFormat = new SimpleDateFormat(format);
			dateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
			estDateFormat.setTimeZone(TimeZone.getTimeZone("US/Eastern"));
			convertedDate = estDateFormat.parse(estDateFormat.format(dateFormat.parse(fromDate))).getTime();		
			
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in checkLCVLDVRStatus  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return convertedDate;
	}

	@RequestMapping(value = AppConstants.GET_LCV_REQUEST_TYPE, method = RequestMethod.GET)
	@ResponseBody public  Map<String, String> getLcvRequestData()
			throws Exception {

		Map<String, String> ddDropdownVal = null;
		try {
			final Map<String, String> listName = new LinkedHashMap<String, String>();
			listName.put(AppConstants.LIST_NAME,
					AppConstants.LCV_REQUEST_TYPE_DROPDOWN);
			ddDropdownVal = objAssetDataScreenService.getDDDropdown(listName);
			return ddDropdownVal;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLcvRequestData method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return ddDropdownVal;
	}
	
}
