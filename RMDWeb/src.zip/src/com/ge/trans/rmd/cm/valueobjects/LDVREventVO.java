package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

/**
 * This pojo contains all the possible values to the corresponding templates
 * event based
 */

public class LDVREventVO {

	private String preTriggerAndPostTrigger;
	private List<LDVRMPVO> mps;

	public String getPreTriggerAndPostTrigger() {
		return preTriggerAndPostTrigger;
	}

	public void setPreTriggerAndPostTrigger(String preTriggerAndPostTrigger) {
		this.preTriggerAndPostTrigger = preTriggerAndPostTrigger;
	}

	public List<LDVRMPVO> getMps() {
		return mps;
	}

	public void setMps(List<LDVRMPVO> mps) {
		this.mps = mps;
	}

}
