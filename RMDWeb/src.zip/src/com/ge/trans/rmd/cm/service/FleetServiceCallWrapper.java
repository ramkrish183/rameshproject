package com.ge.trans.rmd.cm.service;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import com.ge.trans.rmd.cm.beans.FLeetViewBean;
import com.ge.trans.rmd.cm.valueobjects.ToolTipVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetLocRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetLocatorResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.VehicleCommStatusResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CasesRequestType;
import com.ge.trans.rmd.services.kpi.valueobjects.KpiAssetCountsResponseType;
import com.ge.trans.rmd.services.notes.valueobjects.NotesResponseType;
import com.ge.trans.rmd.services.solutions.valueobjects.UrgencyResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Component
public class FleetServiceCallWrapper extends RMDBaseServiceImpl{

	private final RMDWebLogger logger = RMDWebLogger.getLogger(getClass());
	
	@Autowired
	private WebServiceInvoker rsInvoker;
	
	@Async
	public Future<AssetResponseType[]> getAssetResponse(
			final FLeetViewBean fleetViewBean,
			final Map<String, String> headerParams) throws RMDWebException,
			Exception {

		AssetResponseType[] assetResponses = null;
		AssetsRequestType objAssetsReqType=new AssetsRequestType();
		objAssetsReqType.setLanguage(headerParams.get(AppConstants.USER_LANGUAGE));
		objAssetsReqType.setCustomerId(fleetViewBean.getCustomerId());
		parseProducts(fleetViewBean.getProducts(),objAssetsReqType);
		try {
	/*For Fleet*/
			if (null != fleetViewBean.getFleet()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(fleetViewBean.getFleet())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(fleetViewBean.getFleet())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(fleetViewBean.getFleet())) {

				objAssetsReqType.setFleetId(fleetViewBean.getFleet());
			}
			/*For Model*/
			if (null != fleetViewBean.getModel()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(fleetViewBean.getModel())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(fleetViewBean.getModel())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(fleetViewBean.getModel())) {

				objAssetsReqType.setModelId(fleetViewBean.getModel());
			}
			assetResponses = (AssetResponseType[]) rsInvoker.post(
					ServiceConstants.GET_ASSETS, objAssetsReqType, AssetResponseType[].class);

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				logger.error("FleetViewServiceImpl :: No records found for getAssetResponse() service "
						+ e.getMessage());
				assetResponses = null;
			} else {
				logger.error("FleetViewServiceImpl :: Exception occured in getAssetResponse() method "
						+ e.getMessage());
			}
		} catch (Exception e) {
			logger.error("Exception occured in getAssetResponse method ", e);
			throw e;
		}
		return new AsyncResult<AssetResponseType[]>(assetResponses);
	}

	@Async
	public Future<UrgencyResponseType[]> getUrgencyResponse(
			final FLeetViewBean fleetViewBean,
			final Map<String, String> headerParams) throws RMDWebException,
			Exception {

		UrgencyResponseType[] urgencyResponses = null;
		final Map<String, String> queryParamsMap = new HashMap<String, String>();
		try {
			queryParamsMap.put(AppConstants.WS_PARAM_CUSTID,
					fleetViewBean.getCustomerId());
			urgencyResponses = (UrgencyResponseType[]) rsInvoker.get(
					ServiceConstants.GET_WORST_URGENCY, null, queryParamsMap,
					headerParams, UrgencyResponseType[].class);

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				logger.error("FleetViewServiceImpl :: No records found for getUrgencyResponse() service "
						+ e.getMessage());
				urgencyResponses = null;
			} else {
				logger.error("FleetViewServiceImpl :: Exception occured in getUrgencyResponse() method "
						+ e.getMessage());
			}
		} catch (Exception e) {
			logger.error("Exception occured in getUrgencyResponse() method ", e);
			throw e;
		}
		return new AsyncResult<UrgencyResponseType[]>(urgencyResponses);
	}

	@Async
	public Future<AssetLocatorResponseType[]> getAssetLocation(
			FLeetViewBean fleetViewBean, Map<String, String> headerParams)
			throws RMDWebException, Exception {

		AssetLocRequestType objAssetLocReqType=new AssetLocRequestType();
		objAssetLocReqType.setLanguage(headerParams.get(AppConstants.USER_LANGUAGE));
		objAssetLocReqType.setCustomerId(fleetViewBean.getCustomerId());
		objAssetLocReqType.setLastFault(fleetViewBean.isLastFalult());
		parseProducts(fleetViewBean.getProducts(),objAssetLocReqType);
		AssetLocatorResponseType[] assetLocResponses = null;
		try {
			
			if (null != fleetViewBean.getFleet()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(fleetViewBean.getFleet())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(fleetViewBean.getFleet())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(fleetViewBean.getFleet())) {

				objAssetLocReqType.setFleetId(fleetViewBean.getFleet());
			}
			/*For Model*/
			if (null != fleetViewBean.getModel()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(fleetViewBean.getModel())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(fleetViewBean.getModel())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(fleetViewBean.getModel())) {

				objAssetLocReqType.setModelId(fleetViewBean.getModel());
			}
			objAssetLocReqType.setScreenName("FLEETS");
			assetLocResponses = (AssetLocatorResponseType[]) rsInvoker.post(
					ServiceConstants.GET_ASSET_FAULT_LOCATION, objAssetLocReqType,
					AssetLocatorResponseType[].class);
			
			
			

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				logger.error("FleetViewServiceImpl :: No records found for getAssetLocation() service "
						+ e.getMessage());
				assetLocResponses = null;
			} else {
				logger.error("FleetViewServiceImpl :: Exception occured in getAssetLocation() method "
						+ e.getMessage());
			}
		} catch (Exception e) {
			logger.error("Exception occured in getAssetLocation method ", e);
			throw e;
		}
		return new AsyncResult<AssetLocatorResponseType[]>(assetLocResponses);
	}

	/*
	 * gets notes for all assets and customers
	 */
	@Async
	public Future<NotesResponseType[]> getNotes(FLeetViewBean fleetViewBean,
			final Map<String, String> headerParams) throws RMDWebException,
			Exception {

		NotesResponseType[] noteResponses = null;
		final Map<String, String> queryParamsMap = new HashMap<String, String>();
		try {
			queryParamsMap.put(AppConstants.WS_PARAM_NOTETYPE,
					fleetViewBean.getNoteType());
			queryParamsMap.put(AppConstants.WS_PARAM_CUSTID,
					fleetViewBean.getCustomerId());

			noteResponses = (NotesResponseType[]) rsInvoker.get(
					ServiceConstants.GET_NOTES, null, queryParamsMap, null,
					NotesResponseType[].class);

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				logger.error("FleetViewServiceImpl :: No records found for getNotes() service "
						+ e.getMessage());
				noteResponses = null;
			} else {
				logger.error("FleetViewServiceImpl :: Exception occured in getNotes() method "
						+ e.getMessage());
				throw e;
			}
		} catch (Exception e) {
			logger.error("FleetViewServiceImpl :: Exception occured in getNotes() method "
					+ e.getMessage());
			throw e;
		}
		return new AsyncResult<NotesResponseType[]>(noteResponses);
	}

	/*
	 * gets assetkpicounts for all assets based on the given numberofdays
	 */
	@Async
	public Future<KpiAssetCountsResponseType[]> getAssetKPICounts(
			final FLeetViewBean fleetViewBean,
			final Map<String, String> headerParams) throws RMDWebException,
			Exception {

		KpiAssetCountsResponseType[] kpiAssetCountsRespType = null;
		final Map<String, String> queryParamsMap = new HashMap<String, String>();
		final Map<String, String> pathParamsMap = new HashMap<String, String>();
		final String numDays = getKpiDaysLookupValue();
		try {
			pathParamsMap.put(AppConstants.WS_PARAM_KPINAME,
					fleetViewBean.getKpiName());
			queryParamsMap.put(AppConstants.WS_PARAM_DAYS, numDays);
			queryParamsMap.put(AppConstants.WS_PARAM_CUSTID,
					fleetViewBean.getCustomerId());
			kpiAssetCountsRespType = (KpiAssetCountsResponseType[]) rsInvoker
					.get(ServiceConstants.GET_ASSET_KPI_COUNTS, pathParamsMap,
							queryParamsMap, headerParams,
							KpiAssetCountsResponseType[].class);

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				logger.error("FleetViewServiceImpl :: No records found for getAssetKPICounts() service "
						+ e.getMessage());
				kpiAssetCountsRespType = null;
			} else {
				logger.error("FleetViewServiceImpl :: Exception occured in getAssetKPICounts() method "
						+ e.getMessage());
			}
		} catch (Exception e) {
			logger.error("Exception occured in getAssetKPICounts() method "
					+ e.getMessage());
			throw e;
		}
		return new AsyncResult<KpiAssetCountsResponseType[]>(kpiAssetCountsRespType);
	}


	/*
	 * method to fetch num of days value from lookup table for getAssetKPICounts
	 * service
	 */
	public String getKpiDaysLookupValue() {
		String numDays = null;
		final Map<String, String> pathParamsPastDays = new LinkedHashMap<String, String>();
		pathParamsPastDays.put(AppConstants.LIST_NAME,
				AppConstants.FLEET_VIEW_DEFAULT_NO_OF_DAYS);
		try {
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParamsPastDays);

			if (applParamResponseType != null) {
				numDays = applParamResponseType[0].getLookupValue();
			}
		} catch (Exception ex) {
			numDays = null;
			logger.error(
					"Exception occured in getKpiDaysLookupValue() method ", ex);
		} finally {
			if (numDays == null) {
				numDays = AppConstants.NUMERIC_30_DAYS;
			}
		}
		return numDays;
	}

	/*
	 * gets VehicleCommStatus for all assets based on the given customerid
	 */
	@Async
	public Future<VehicleCommStatusResponseType[]> getVehicleCommStatus(
			final FLeetViewBean fleetViewBean,
			final Map<String, String> headerParams) throws RMDWebException,
			Exception {

		VehicleCommStatusResponseType[] vehicleCommStatusResponseType = null;
		final Map<String, String> queryParamsMap = new HashMap<String, String>();
		try {
			queryParamsMap.put(AppConstants.WS_PARAM_CUSTID,
					fleetViewBean.getCustomerId());
			queryParamsMap.put(AppConstants.LAST_FAULT_FLAG, AppConstants.YES_FLAG);
			vehicleCommStatusResponseType = (VehicleCommStatusResponseType[]) rsInvoker
					.get(ServiceConstants.GET_VEHICLECOMMSTATUS, null,
							queryParamsMap, headerParams,
							VehicleCommStatusResponseType[].class);

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				logger.error("FleetViewServiceImpl :: No records found for getVehicleCommStatus() service "
						+ e.getMessage());
				vehicleCommStatusResponseType = null;
			} else {
				logger.error("FleetViewServiceImpl :: Exception occured in getVehicleCommStatus() method "
						+ e.getMessage());
				// throw e;
			}
		} catch (Exception e) {
			logger.error("Exception occured in getVehicleCommStatus() method "
					+ e.getMessage());
			throw e;
		}
		return new AsyncResult<VehicleCommStatusResponseType[]>(vehicleCommStatusResponseType);
	}

	@Async
	public Future<CaseResponseType[]> getCases(
			final FLeetViewBean fleetViewBean) throws RMDWebException,
			Exception {

		CaseResponseType[] caseResponseType = null;
		Map<String, List<ToolTipVO>> resultToolTipMap = new HashMap<String, List<ToolTipVO>>();
		final Map<String, String> headerParams = getHeaderMap(fleetViewBean);
		CasesRequestType objCasesReqType=new CasesRequestType();
		try {
			objCasesReqType.setCustomerId(fleetViewBean.getCustomerId());
			objCasesReqType.setUserLanguage(fleetViewBean.getUserLanguage());
			objCasesReqType.setSolutionStatus(AppConstants.STATUS_OPEN);
			parseProducts(fleetViewBean.getProducts(),objCasesReqType);

			if (null != fleetViewBean.getUrgencies()
					&& !RMDCommonConstants.EMPTY_STRING.equals(fleetViewBean
							.getUrgencies()))
				objCasesReqType.setUrgency(fleetViewBean.getUrgencies());
			if (null != fleetViewBean.getEstRepTime()
					&& !RMDCommonConstants.EMPTY_STRING.equals(fleetViewBean
							.getEstRepTime()))
				objCasesReqType.setEstRepTm(fleetViewBean.getEstRepTime());

			/* For CaseType */
			if (null != fleetViewBean.getCaseType()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(fleetViewBean.getCaseType())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(fleetViewBean.getCaseType())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(fleetViewBean.getCaseType())) {

				objCasesReqType.setCaseType(fleetViewBean.getCaseType());
			}
			/*For Fleet*/
			if (null != fleetViewBean.getFleet()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(fleetViewBean.getFleet())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(fleetViewBean.getFleet())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(fleetViewBean.getFleet())) {

				objCasesReqType.setFleetId(fleetViewBean.getFleet());
			}
			/*For Model*/
			if (null != fleetViewBean.getModel()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(fleetViewBean.getModel())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(fleetViewBean.getModel())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(fleetViewBean.getModel())) {

				objCasesReqType.setModelId(fleetViewBean.getModel());
			}
			/*For CaseType*/
			if (null != fleetViewBean.getRxIds() && !RMDCommonConstants.EMPTY_STRING.equals(fleetViewBean.getRxIds())) {				
					objCasesReqType.setRxId(fleetViewBean.getRxIds());
					caseResponseType = (CaseResponseType[]) rsInvoker.post(
							ServiceConstants.CASES_SERVICE_LITE_GETDELCASES, objCasesReqType, CaseResponseType[].class);				

			} else {
				caseResponseType = (CaseResponseType[]) rsInvoker.post(
						ServiceConstants.CASES_SERVICE_LITE_GETDELCASES,objCasesReqType, CaseResponseType[].class);
			}
		

		} catch (Exception ex) {
			logger.error("Exception occured in getCases method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return new AsyncResult<CaseResponseType[]>(caseResponseType);
		
	}
	
}
