/*******************************************************************************
 *
 * @Author 		: iGATE Patni
 * @Version 	: 1.0
 * @Date Created: FEB 01, 2012
 * @Date Modified : FEB 21, 2012
 * @Modified By : 
 * @Contact 	:
 * @Description : This class act as a controller to give the overview data  of selected asset.
 * 
 * @History		:
 *
 ******************************************************************************/
package com.ge.trans.rmd.cm.mvc.controller;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ge.trans.rmd.cm.service.AssetOverviewService;
import com.ge.trans.rmd.cm.valueobjects.AssetLastDownloadStatusVO;
import com.ge.trans.rmd.cm.valueobjects.AssetLastFaultStatusVO;
import com.ge.trans.rmd.cm.valueobjects.AssetLocatorResponseVO;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class AssetOverviewController extends RMDBaseController {
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());


	@Autowired
	private AssetOverviewService asstOvwService;
	
	@Autowired
	private AuthorizationService authService;


	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description: Redirect to asset overview page for requested asset Number.
	 * 
	 *               1) return AssetOverView view.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_ASSETOVW, method = RequestMethod.GET)
	public String getOverviewPage(final HttpServletRequest request)
			throws Exception {

		rmdWebLogger.debug("Received request to show overview page");

		final String strAssetNumber = request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM);
		final String strAssetGroup = request
				.getParameter(AppConstants.ASSET_GROUP_NAME);
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
        Boolean isRunToolsNow=false;
		final Map<String, String> listName = new LinkedHashMap<String, String>();
		listName.put(AppConstants.LIST_NAME,
				AppConstants.ASSET_OVERVIEW_LAST_DOWNLOAD);
		Map<String, String> componentList = new HashMap<String, String>();
		try {
			componentList.put(AppConstants.ASSET_OVERVIEW_LAST_DOWNLOAD,
					AppConstants.ASSET_OVW_COMPONENT);
			componentList.put(AppConstants.ASSET_OVERVIEW_FAULT_STATUS,
					AppConstants.ASSET_OVW_ADMIN_COMPONENT);
			componentList.put(AppConstants.ASSETOVERVIEW_STATUS,
					AppConstants.DIESELDOC);
			componentList.put(AppConstants.ASSET_OVERVIEW_LAST_FAULT,
					AppConstants.ASSET_OVW_LST_FAULT);
			componentList.put(AppConstants.ASSETOVERVIEW_LASTSHOPDOWNLOAD,
					AppConstants.ASSET_OVW_SHOP_LAST_DWNLD);
			componentList.put(AppConstants.ASSETOVERVIEW_SERVICES,
					AppConstants.ASSETOVERVIEW_SERVICES_PREV);
			componentList.put(AppConstants.ASSETOVERVIEW_CONFIGURATION,
					AppConstants.ASSETOVERVIEW_CONFIGURATION_PREV);
			componentList.put(AppConstants.ASSETOVERVIEW_NOTES,
					AppConstants.ASSET_OVERVIEW_NOTES_PRIV);
			componentList.put(AppConstants.ASSETOVERVIEW_REPLACE_NOTES,
					AppConstants.ASSET_OVERVIEW_NOTES_REPLACE_PRIV);
			componentList.put(AppConstants.RUN_TOOLS_NOW,
					AppConstants.IS_RUN_TOOLS_NOW);
			getComponentPrivilege(componentList,userVO,request);
			/*Begin of Changes for fetching customer Id from Webservices */
			String strCustomerId =asstOvwService.getCustomerId(strAssetNumber, strAssetGroup);
			/*End of Changes*/
			isRunToolsNow= (Boolean) request
					.getAttribute(AppConstants.IS_RUN_TOOLS_NOW);
			request.setAttribute(AppConstants.FILTERFLAG, request.getParameter(AppConstants.FLAG));			
			request.setAttribute(AppConstants.REQ_PARAM_ASSTNUM, strAssetNumber);
			request.setAttribute(AppConstants.WS_PARAM_ASSTGRP, strAssetGroup);
			request.setAttribute(AppConstants.WS_PARAM_CUSTID, strCustomerId);
			request.setAttribute(AppConstants.IS_RUN_TOOLS_NOW, isRunToolsNow);		
		}

		catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getOverviewPage method ",
					ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		}
		return AppConstants.VIEW_ASSETOVW;

	}

	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description: get the locomotive data for rquested asset number.
	 * 
	 *               1) Retrieve the asset information like customer, asset,
	 *               model, fleet and set the asset information in the
	 *               AssetOverViewBean.
	 * 
	 *               2) return AssetOverViewBean to the view.
	 * 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_ASSETOVW_ASSETS, method = RequestMethod.GET)
	public @ResponseBody
	AssetOverviewBean getAssetOViewAssets(final HttpServletRequest request)
			throws RMDWebException, Exception {

		rmdWebLogger
				.debug("AssetOverview Controller : getAssetOViewAssets() method Starts");
		AssetOverviewBean assetOverviewBean = new AssetOverviewBean();
		final String assetNumber = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String groupName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.WS_PARAM_ASSTGRP));
		final String customerId =EsapiUtil.stripXSSCharacters( request
				.getParameter(AppConstants.REQ_PARAM_CUSID));
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {

			assetOverviewBean.setAsset(assetNumber);
			assetOverviewBean.setAssetGroup(groupName);
			assetOverviewBean.setCustomer(customerId);
			assetOverviewBean.setUserLanguage(EsapiUtil.stripXSSCharacters(userVO.getStrUserLanguage()));
			// Get the basic information of asset
			assetOverviewBean = asstOvwService.getAssets(assetOverviewBean);

			rmdWebLogger.debug("getAssetOViewAssets():::END");

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAssetOViewAssets method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
				.debug("AssetOverview Controller : getAssetOViewAssets() method Endss");
		return assetOverviewBean;

	}

	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description: get the notes data for requested asset number.
	 * 
	 *               1) Retrieve the notes information of asset like author,
	 *               date of notes and set in the AssetOverViewBean.
	 * 
	 * 
	 *               2) return List of NotesBean.
	 * 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_ASSETOVW_NOTES, method = RequestMethod.GET)
	public @ResponseBody
	List<NotesBean> getAssetOViewNotes(final HttpServletRequest request)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("AssetOverview Controller : getAssetOViewNotes() method Starts");
		List<NotesBean> notesList = null;
		// Get the asset number from request
		final String assetNumber = request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM);
		final String groupName = request
				.getParameter(AppConstants.WS_PARAM_ASSTGRP);
		final String customerId = request
				.getParameter(AppConstants.REQ_PARAM_CUSID);

		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final AssetOverviewBean assetOverviewBean = new AssetOverviewBean();
		/*For timezone issue*/
		final String defaultTimezone=(String)request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone=RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone());
		/*For timezone issue*/
		try {
			assetOverviewBean.setUserTimeZone(applicationTimezone);
			assetOverviewBean.setAsset(assetNumber);
			assetOverviewBean.setUserLanguage(userVO.getStrUserLanguage());
			assetOverviewBean.setCustomer(customerId);
			assetOverviewBean.setAssetGroup(groupName);
			// Get the notes information of asset
			String ddAssetOverview = null;
			boolean assetDD = false;
			String hideNotesRoleId = null;
			ddAssetOverview=authService.getLookUpValueForName(AppConstants.ASSETOVERVIEW_REPLACE_NOTES);
			assetDD=RMDCommonUtil.componentValue(userVO.getComponentList(), ddAssetOverview);
			
			if (assetDD == true) {
				assetOverviewBean.setNotesType(AppConstants.LOCOMOTIVE_NOTE);
			} else {
				assetOverviewBean.setNotesType(AppConstants.GENERIC_NOTE);
			}
			request.setAttribute(AppConstants.DIESELDOC, assetDD);
			/*Added by Murali */
			hideNotesRoleId = authService
			.getLookUpValueForName(AppConstants.HIDE_ASSETOVERVIEW_NOTES_CREATED_BY_ROLE_ID);
			List<String> roleIdList = Arrays.asList(
					hideNotesRoleId.split(
							RMDCommonConstants.COMMMA_SEPARATOR));
			if(roleIdList != null && roleIdList.contains(userVO.getRoleId().toString()))
				 assetOverviewBean.setIsNonGPOCUser(RMDCommonConstants.NO); //If the user is logged in with DE role
				else
					assetOverviewBean.setIsNonGPOCUser(RMDCommonConstants.YES);
			/*End*/
			notesList = asstOvwService.getNotes(assetOverviewBean, userVO.getCustomerId());

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAssetOViewNotes method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
				.debug("AssetOverview Controller : getAssetOViewNotes() method Ends");

		return notesList;
	}

	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description: get the cases data for requested asset number.
	 * 
	 * 
	 *               1) Retrieve the cases information of asset like case id,
	 *               title, status, urgency and set in the AssetOverViewBean.
	 * 
	 * 
	 *               2) return AssetOverViewBean to the view.
	 * 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_ASSETOVW_CASE, method = RequestMethod.GET)
	public @ResponseBody
	AssetOverviewBean getAssetOViewCases(final HttpServletRequest request)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("AssetOverview Controller : getAssetOViewCases() method Starts");
		final List<CaseBean> casesList;
		// Get the asset number from request
		final String assetNumber = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String groupName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.WS_PARAM_ASSTGRP));
		final String customerId =EsapiUtil.stripXSSCharacters( request
				.getParameter(AppConstants.REQ_PARAM_CUSID));

		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final AssetOverviewBean assetOverviewBean = new AssetOverviewBean();
		String urgency = AppConstants.URGENCY_NONE;
		/*For timezone issue*/
		final String defaultTimezone=EsapiUtil.stripXSSCharacters((String)request.getAttribute(AppConstants.DEFAULT_TIMEZONE));
		String applicationTimezone=RMDCommonUtil.getTimezone(defaultTimezone,EsapiUtil.stripXSSCharacters(userVO.getTimeZone()));
		/*For timezone issue*/
		try {
			assetOverviewBean.setAsset(assetNumber);
			assetOverviewBean.setUserLanguage(EsapiUtil.stripXSSCharacters(userVO.getStrUserLanguage()));
			assetOverviewBean.setCustomer(customerId);
			assetOverviewBean.setAssetGroup(groupName);
			assetOverviewBean.setUserTimeZone(applicationTimezone);
			// Get the case information of asset
			casesList = asstOvwService.getCases(assetOverviewBean, EsapiUtil.stripXSSCharacters(userVO.getCustomerId()));
			if (null != casesList) {
				assetOverviewBean.setCaselist(casesList);

				// Get the most severe urgency code of case of asset
				final CaseBean[] casebeanArr = (CaseBean[]) casesList
						.toArray(new CaseBean[casesList.size()]);
				for (CaseBean caseBean : casebeanArr) {
					if (AppConstants.URGENCY_R.equalsIgnoreCase(caseBean
							.getUrgency())) {
						urgency = caseBean.getUrgency();
						break;
					} else if (AppConstants.URGENCY_Y.equalsIgnoreCase(caseBean
							.getUrgency())) {
						urgency = caseBean.getUrgency();
					} else if (AppConstants.URGENCY_B.equalsIgnoreCase(caseBean
							.getUrgency())
							&& AppConstants.URGENCY_NONE
									.equalsIgnoreCase(urgency)) {
						urgency = caseBean.getUrgency();

					}
				}

			}
			//added to have new icon for assets having no open rx -Start
			if(casesList.isEmpty()){
				urgency = AppConstants.URGENCY_G;
			}
			//added to have new icon for assets having no open rx - end
			assetOverviewBean.setUrgencyCode(urgency);

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAssetOViewCases method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
				.debug("AssetOverview Controller : getAssetOViewCases() method Ends");

		return assetOverviewBean;
	}

	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description: get the fault time information for requested asset number.
	 * 
	 * 
	 *               1) Retrieve the LastFaultReceivedTime,LastFaultResetTime,
	 *               LastHealthChkRequestTime
	 *               ,LastKeepAliveMsgRevdTime,ControllerConfig of asset and set
	 *               in the AssetOverViewBean.
	 * 
	 *               2) return AssetOverViewBean to the view.
	 * 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_ASSETOVW_FSTATUS, method = RequestMethod.GET)
	public @ResponseBody
	AssetOverviewBean getAssetOViewFStats(final HttpServletRequest request)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("AssetOverview Controller : getAssetOViewFStats() method Starts");
		// Get the asset number from request
		final String assetNumber =EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String groupName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.WS_PARAM_ASSTGRP));
		final String customerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_CUSID));

		AssetOverviewBean assetOverviewBean = new AssetOverviewBean();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		/*For timezone issue*/
		final String defaultTimezone=EsapiUtil.stripXSSCharacters ((String)request.getAttribute(AppConstants.DEFAULT_TIMEZONE));
		String applicationTimezone=RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone());
		/*For timezone issue*/
		try {
			assetOverviewBean.setAsset(assetNumber);
			assetOverviewBean.setUserTimeZone(applicationTimezone);
			assetOverviewBean.setUserLanguage(userVO.getStrUserLanguage());
			assetOverviewBean.setCustomer(customerId);
			assetOverviewBean.setAssetGroup(groupName);
			// Get Fault Status Time Data
			assetOverviewBean = asstOvwService
					.getVehicleCommStatus(assetOverviewBean, userVO.getCustomerId());

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAssetOViewFStats method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
				.debug("AssetOverview Controller : getAssetOViewFStats() method Ends");
		return assetOverviewBean;
	}

	/*---------------------------------------------------------------------------------------*/
	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description: get the Last Download Status info from DB for requested
	 *               asset number.
	 * 
	 * 
	 * 
	 * 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_ASSETOVW_LAST_DOWNLOAD, method = RequestMethod.GET)
	public @ResponseBody
	AssetLastDownloadStatusVO getDownloadStatus(final HttpServletRequest request)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("AssetOverview Controller : getDownloadStatus() method Starts");
		// Get the asset number from request
		final String assetNumber = request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM);
		final String groupName = request
				.getParameter(AppConstants.WS_PARAM_ASSTGRP);
		final String customerId = request
				.getParameter(AppConstants.REQ_PARAM_CUSID);

		AssetOverviewBean assetOverviewBean = new AssetOverviewBean();
		AssetLastDownloadStatusVO assetLstDwnLoadStatVO = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);

		Map<String, String> ddNoDaysMap = null;
		final Map<String, String> listName = new LinkedHashMap<String, String>();
		listName.put(AppConstants.LIST_NAME, AppConstants.DOWNLOAD_STATUS_DAYS);

		ddNoDaysMap = asstOvwService.getCompLookupValue(listName);
		String ddNoDays = null;

		if (ddNoDaysMap != null && !ddNoDaysMap.isEmpty()) {
			for (Map.Entry<String, String> entry : ddNoDaysMap.entrySet()) {
				ddNoDays = (String) entry.getValue();
			}
		}
		/*For timezone issue*/
		final String defaultTimezone=(String)request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone=RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone());
		/*For timezone issue*/
		try {

			assetOverviewBean.setAsset(assetNumber);
			assetOverviewBean.setUserTimeZone(applicationTimezone);
			assetOverviewBean.setUserLanguage(userVO.getStrUserLanguage());
			assetOverviewBean.setCustomer(customerId);
			assetOverviewBean.setAssetGroup(groupName);
			assetOverviewBean.setNoDays(ddNoDays);
			// Get Last Download Status Data
			assetLstDwnLoadStatVO = asstOvwService
					.getDownloadStatus(assetOverviewBean, userVO.getCustomerId());

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getDownloadStatus() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
				.debug("AssetOverview Controller : getDownloadStatus() method Ends");
		return assetLstDwnLoadStatVO;
	}

	/*---------------------------------------------------------------------------------------*/
	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description: get the Last Fault Status info from DB for requested
	 *               asset number.
	 * 
	 * 
	 * 
	 * 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_ASSETOVW_LST_FLT_STATUS, method = RequestMethod.GET)
	public @ResponseBody
	AssetLastFaultStatusVO getLastFaultStatus(final HttpServletRequest request)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("AssetOverview Controller : getLstFaultStatus() method Starts");
		// Get the asset number from request
		final String assetNumber = request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM);
		final String groupName = request
				.getParameter(AppConstants.WS_PARAM_ASSTGRP);
		final String customerId = request
				.getParameter(AppConstants.REQ_PARAM_CUSID);

		AssetOverviewBean assetOverviewBean = new AssetOverviewBean();
		AssetLastFaultStatusVO assetLstFaultStatVO = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);

		/*For timezone issue*/
		final String defaultTimezone=(String)request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone=RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone());
		/*For timezone issue*/
		try {

			assetOverviewBean.setAsset(assetNumber);
			assetOverviewBean.setUserTimeZone(applicationTimezone);
			assetOverviewBean.setUserLanguage(userVO.getStrUserLanguage());
			assetOverviewBean.setCustomer(customerId);
			assetOverviewBean.setAssetGroup(groupName);
			// Get Last Fault Status Data
			assetLstFaultStatVO = asstOvwService.getLastFaultStatus(assetOverviewBean, userVO.getCustomerId());

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLstFaultStatus() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
				.debug("AssetOverview Controller : getLstFaultStatus() method Ends");
		return assetLstFaultStatVO;
	}

	/*-----------------------------------------------------------------------------------------------*/
	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description: post the new notes information for requested asset number.
	 * 
	 * 
	 *               1) put the notes to the service call with required params
	 *               like assetNumber,notes and user name 2) return a String for
	 *               successful post of notes.
	 * 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_ASSETOVW_SETNOTES, method = RequestMethod.POST)
	public @ResponseBody
	Map<String, String> setAssetOViewNotes(final HttpServletRequest request)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("AssetOverview Controller : setAssetOViewNotes() method Starts");
		// Get the asset number from request
		final String assetNumber = request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM);
		final String groupName = request
				.getParameter(AppConstants.WS_PARAM_ASSTGRP);
		final String customerId = request
				.getParameter(AppConstants.REQ_PARAM_CUSID);
		final String notes = request
				.getParameter(AppConstants.REQ_PARAM_ASSTNOTES);
		String returnStr =isValidAddNotesInput(notes);
		final NotesBean notesBean = new NotesBean();

		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		if (AppConstants.TRUE_STRING.equals(returnStr)) {
			notesBean.setAssetNumber(assetNumber);
			notesBean.setNoteDescription(notes);
			notesBean.setUserFirstName(userVO.getStrFirstName());
			notesBean.setUserLastName(userVO.getStrLastName());
			notesBean.setUserId(userVO.getUserId());
			notesBean.setUserLanguage(userVO.getStrUserLanguage());
			notesBean.setCustomerId(customerId);
			notesBean.setAssetGroup(groupName);

			String ddAssetOverview = null;
			boolean assetDD = false;
			
			ddAssetOverview=authService.getLookUpValueForName(AppConstants.ASSETOVERVIEW_REPLACE_NOTES);
			assetDD=RMDCommonUtil.componentValue(userVO.getComponentList(), ddAssetOverview);
			
			if (assetDD == true) {
				notesBean.setNotesType(AppConstants.LOCOMOTIVE_NOTE);
			} else {
				notesBean.setNotesType(AppConstants.GENERIC_NOTE);
			}
			request.setAttribute(AppConstants.DIESELDOC, assetDD);
			try {
				// Get Fault Status Time Data
				returnStr = asstOvwService.addNotes(notesBean);

			}catch (Exception ex) {
				rmdWebLogger.error("Exception occured in setAssetOViewNotes method ", ex);
				RMDWebErrorHandler.handleException(ex);
			}
		} 

		rmdWebLogger
				.debug("AssetOverview Controller : setAssetOViewNotes() method Ends");
		return Collections.singletonMap(AppConstants.MESSAGE, returnStr);
	}

	/**
	 * validate the input for notes
	 * @param request
	 * @return
	 */
	private String isValidAddNotesInput(String notes) {
		if (null == notes
				|| AppConstants.EMPTY_STRING.equals(notes)) {
			return AppConstants.NOTEMPTY;
		}
		if (RMDCommonUtility.isSpecialCharactersFound(notes)) {
			return AppConstants.INVALID_SPECIAL_CHARACTER;
		}
		return AppConstants.TRUE_STRING;
	}
	
	/**
	 * @Author:iGate Patni
	 * @return
	 * @throws RMDWebException
	 * @Description: get the locomotive data for requested asset number.
	 * 
	 *               Passing Asset Number to the webservice call to find the
	 *               asset Latitude,Longitude and maximum occurrence time.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_ASSETOVW_LOCATION, method = RequestMethod.GET)
	public @ResponseBody
	AssetLocatorResponseVO getAssetLocation(final HttpServletRequest request)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("AssetOverview Controller : getAssetLocation()### Starts");
		final AssetOverviewBean overviewBean = new AssetOverviewBean();
		overviewBean.setLastFault(false);
		AssetLocatorResponseVO locatorResponse = null;
		if (null != request.getParameter(AppConstants.ASSET_NUMBER)) {
			overviewBean.setAsset(EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.ASSET_NUMBER)));
		}
		if (null != request.getParameter(AppConstants.WS_PARAM_CUSTID)) {
			overviewBean.setCustomer(EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.WS_PARAM_CUSTID)));
		}
		if (null != request.getParameter(AppConstants.WS_PARAM_ASSTGRP)) {
			overviewBean.setAssetGroup(EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.WS_PARAM_ASSTGRP)));
		}
		try {
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			/*For timezone issue*/
			final String defaultTimezone=EsapiUtil.stripXSSCharacters((String)request.getAttribute(AppConstants.DEFAULT_TIMEZONE));
			String applicationTimezone=RMDCommonUtil.getTimezone(defaultTimezone,EsapiUtil.stripXSSCharacters(userVO.getTimeZone()));
			/*For timezone issue*/
			overviewBean.setUserTimeZone(applicationTimezone);
			locatorResponse = asstOvwService.getAssetLocation(overviewBean, EsapiUtil.stripXSSCharacters(userVO.getCustomerId()));
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAssetLocation method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger.debug("getAssetLocation():::END");
		return locatorResponse;
	}
	

	/**
	 * @Author:iGate Patni
	 * @return
	 * @throws RMDWebException
	 *             ,Exception
	 * @Description: gets the available services for requested asset number.
	 * 
	 *               Passing Asset Number, asset group name and customer id to
	 *               the web service call to find the services
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_ASSETOVW_GETSERVICES, method = RequestMethod.GET)
	public @ResponseBody
	List<String> getAssetOViewServices(final HttpServletRequest request)
			throws RMDWebException, Exception {
		List<String> assetServices = null;
		AssetOverviewBean overviewBean = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {

			overviewBean = new AssetOverviewBean();
			final String assetNumber = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
			final String groupName = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.WS_PARAM_ASSTGRP));
			final String customerId = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_CUSID));
			overviewBean.setAsset(assetNumber);
			overviewBean.setAssetGroup(groupName);
			overviewBean.setCustomer(customerId);
			overviewBean.setUserLanguage(userVO.getStrLanguage());
			assetServices = asstOvwService.getAssetServices(overviewBean);
		} catch (RMDWebException e) {
			RMDWebErrorHandler.handleException(e);
		}catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getAssetLocation method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return assetServices;
	}
	
	
	/**
	 * @param request
	 * @return
	 * @throws RMDWebException
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_MODELS_FOR_FILTERS)
	public @ResponseBody
	java.util.Map<String, String> getModelsForFilter(final HttpServletRequest request)throws RMDWebException {

		rmdWebLogger.debug("Inside AssetOverviewController in getModelsForFilter Method");
		Map<String, String> modelMap = null;
		AssetOverviewBean overviewBean = null;
		Map<String, String> sortedMap = new LinkedHashMap<String, String>();
		final HttpSession session=request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			overviewBean = new AssetOverviewBean();
			if(null==userVO.getCustomerId() || userVO.getCustomerId().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING))
				overviewBean.setCustomer(RMDCommonConstants.ALL_CUSTOMER);
			else	
				overviewBean.setCustomer(userVO.getCustomerId());
			overviewBean.setUserLanguage(userVO.getStrLanguage());
			modelMap = asstOvwService.getModelsForFilter(overviewBean);
			sortedMap = SortMapValues(modelMap);
		} catch (Exception e) {
			rmdWebLogger
					.error("Error occurred in AssetOverviewController - getModelsForFilter Method"
							+ e);
			RMDWebErrorHandler.handleException(e);
		}
		return sortedMap;
	}
	
	
	@RequestMapping(value = AppConstants.GET_FLEETS)
	public @ResponseBody
	Map<String, String> getFleets(final HttpServletRequest request)throws RMDWebException {	

		Map<String, String> result = new LinkedHashMap<String, String>();
		final HttpSession session=request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		AssetOverviewBean overviewBean = null;
		try 
		{
			overviewBean = new AssetOverviewBean();
			if(null==userVO.getCustomerId()||userVO.getCustomerId().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING))
				overviewBean.setCustomer(RMDCommonConstants.ALL_CUSTOMER);
			else	
				overviewBean.setCustomer(userVO.getCustomerId());
			overviewBean.setUserLanguage(userVO.getStrLanguage());
			final	Map<String, String> custMap = asstOvwService.getFleets(overviewBean);
			result = SortMapValues(custMap);
		}
			catch (Exception ex) {
				rmdWebLogger.error("RMDWebException occured in getFleets() method - KnowledgeSeekerRequestController", ex);
			RMDWebErrorHandler.handleException(ex);
			
		}
		return result;
	}
}