package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.VehicleCfgService;
import com.ge.trans.rmd.cm.valueobjects.MdscStartUpControllersVO;
import com.ge.trans.rmd.cm.valueobjects.VehicleCfgTemplateVO;
import com.ge.trans.rmd.cm.valueobjects.VehicleCfgVO;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.exception.RMDConcurrencyException;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class VehicleConfigController {
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	ApplicationContext appContext;
	@Autowired
	private VehicleCfgService vehicleCfgService;

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param : caseBean
	 * @throws :RMDWebException
	 * @Description: Displays the VehicleConfigScreen page of the RMD
	 *               application when clicked on VehicleConfig Tab in View Page.
	 * 
	 */
	@RequestMapping(AppConstants.REQ_URI_VEHICLE_CONFIG)
	public ModelAndView showVehicleConfigScreen(final HttpServletRequest request)
			throws RMDWebException {
		return new ModelAndView(AppConstants.VEHICLE_CONFIG);
	}

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param : caseBean
	 * @throws :RMDWebException
	 * @Description: Displays the VehicleConfigScreen page of the RMD
	 *               application when clicked on VehicleConfig Tab in View Page.
	 * 
	 */
	@RequestMapping(AppConstants.REQ_URI_CASE_VEHICLE_CONFIG)
	public ModelAndView showCaseVehicleConfigScreen(
			final HttpServletRequest request) throws RMDWebException {
		String customerName = EsapiUtil.stripXSSCharacters((String) request
				.getParameter(AppConstants.CUSTOMER_NAME));
		String customerId = EsapiUtil.stripXSSCharacters((String) request
				.getParameter(AppConstants.CUSTOMER_ID));
		String assetGrpName = EsapiUtil.stripXSSCharacters((String) request
				.getParameter(AppConstants.ASSET_GROUP_NAME));
		String assetNumber = EsapiUtil.stripXSSCharacters((String) request
				.getParameter(AppConstants.ASSET_NUMBER));
		String caseId = EsapiUtil.stripXSSCharacters((String) request.getParameter(AppConstants.CASE_ID));
		String caseObjId = EsapiUtil.stripXSSCharacters((String) request
				.getParameter(AppConstants.CASE_OBJID));
		String locoId = EsapiUtil.stripXSSCharacters((String) request.getParameter(AppConstants.LOCO_ID));
		String caseType = EsapiUtil.stripXSSCharacters((String) request.getParameter(AppConstants.CASE_TYPE));
		String caseOwner = EsapiUtil.stripXSSCharacters((String) request.getParameter(AppConstants.OWNER));
		String caseCondition = EsapiUtil.stripXSSCharacters((String) request
				.getParameter(AppConstants.CASE_CONDITION));
		request.setAttribute(AppConstants.CUSTOMER_NAME, customerName);
		request.setAttribute(AppConstants.CUSTOMER_ID, customerId);
		request.setAttribute(AppConstants.ASSET_GROUP_NAME, assetGrpName);
		request.setAttribute(AppConstants.ASSET_NUMBER, assetNumber);
		request.setAttribute(AppConstants.CASE_ID, caseId);
		request.setAttribute(AppConstants.CASE_OBJID, caseObjId);
		request.setAttribute(AppConstants.LOCO_ID, locoId);
		request.setAttribute(AppConstants.CASE_TYPE, caseType);
		request.setAttribute(AppConstants.OWNER, caseOwner);
		request.setAttribute(AppConstants.CASE_CONDITION, caseCondition);
		request.setAttribute(AppConstants.CASE_VEHICLE_CONFIG_SCREEN, true);
		return new ModelAndView(AppConstants.VEHICLE_CONFIG);
	}

	/**
	 * @Author :
	 * @return :List<VehicleCfgVO>
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method fetches vehicle BOM configuration details
	 * 
	 */
	@RequestMapping(AppConstants.REQ_URI_GET_VEHICLE_BOM_CONFIG)
	public @ResponseBody
	List<VehicleCfgVO> getVehicleBOMConfigs(
			@RequestParam(value = AppConstants.CUSTOMER) final String customer,
			@RequestParam(value = AppConstants.RNH) final String rnh,
			@RequestParam(value = AppConstants.ROAD_NUMBER) final String roadNumber,
			final HttpServletRequest request) throws RMDWebException {
		List<VehicleCfgVO> vehicleCfg = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(customer)
					&& !RMDCommonUtility.isNullOrEmpty(rnh)
					&& !RMDCommonUtility.isNullOrEmpty(roadNumber)) {
				vehicleCfg = vehicleCfgService.getVehicleBOMConfigs(customer,
						rnh, roadNumber);
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getVehicleBOMConfigs method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return vehicleCfg;

	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param : request
	 * @throws :RMDWebException
	 * @Description: This method fetches MDSC Start Up controller Names from RMD
	 *               Lookup table
	 * 
	 */

	@RequestMapping(AppConstants.REQ_URI_GET_MDSC_STARTUP_CONTROLLERS)
	public @ResponseBody
	List<String> getMDSCStartUpControllerNames(final HttpServletRequest request)
			throws RMDWebException {
		rmdWebLogger
				.debug("Inside VehicleConfigController in getMDSCStartUpControllerNames Method");
		List<String> mdscStartUpCtrlNames = null;
		try {
			mdscStartUpCtrlNames = vehicleCfgService
					.getMDSCStartUpControllerNames();
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getMDSCStartUpControllerNames method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return mdscStartUpCtrlNames;

	}

	/**
	 * @Author :
	 * @return :MdscStartUpControllersVO
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method fetches MDSC Start Up controller Information
	 * 
	 */

	@RequestMapping(AppConstants.REQ_URI_GET_MDSC_STARTUP_CONTROLLERS_INFO)
	public @ResponseBody
	MdscStartUpControllersVO getMDSCStartUpControllersInfo(
			@RequestParam(value = AppConstants.CUSTOMER) final String customer,
			@RequestParam(value = AppConstants.RNH) final String rnh,
			@RequestParam(value = AppConstants.ROAD_NUMBER) final String roadNumber,
			final HttpServletRequest request) throws RMDWebException {
		rmdWebLogger
				.debug("Inside VehicleConfigController in getMDSCStartUpControllersInfo Method");
		MdscStartUpControllersVO objMdscStartUpControllersVO = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(customer)
					&& !RMDCommonUtility.isNullOrEmpty(rnh)
					&& !RMDCommonUtility.isNullOrEmpty(roadNumber)) {
				objMdscStartUpControllersVO = vehicleCfgService
						.getMDSCStartUpControllersInfo(EsapiUtil.stripXSSCharacters(customer), EsapiUtil.stripXSSCharacters(rnh),
								EsapiUtil.stripXSSCharacters(roadNumber));
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getMDSCStartUpControllersInfo method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return objMdscStartUpControllersVO;

	}

	/**
	 * @Author :
	 * @return :String
	 * @param : ParameterString,HttpServletRequest request
	 * @throws :RMDWebException
	 * @Description: This method is used to update vehicle Bom Configuration
	 *               information
	 * 
	 */

	@RequestMapping(AppConstants.REQ_URI_SAVE_VEHICLE_BOM_CONFIGS)
	public @ResponseBody
	String saveVehicleBOMConfigs(
			@RequestParam(value = AppConstants.GET_PARAMETER_STRING) final String parameterString,
			@RequestParam(value = AppConstants.IS_CASE_VEH_CONFIG) final String isCaseVehicleConfig,
			@RequestParam(value = AppConstants.CASE_DETAILS_STR) final String caseString,
			final HttpServletRequest request) throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<VehicleCfgVO> vehicleCfgVOList = new ArrayList<VehicleCfgVO>();
		final ObjectMapper mapper = new ObjectMapper();
		final HttpSession session = request.getSession(false);
		CaseBean objcaseBean = null;
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {

			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			VehicleCfgVO[] arrVehicleCfgVO = mapper.readValue(EsapiUtil.stripXSSCharacters(parameterString),
					VehicleCfgVO[].class);
			vehicleCfgVOList = Arrays.asList(arrVehicleCfgVO);
			if (AppConstants.STR_Y.equals(isCaseVehicleConfig)
					&& !RMDCommonUtility.isNullOrEmpty(caseString)) {
				objcaseBean = mapper.readValue(EsapiUtil.stripXSSCharacters(caseString), CaseBean.class);
				objcaseBean.setUserId(userVO.getUserId());
			}
			String result = validateParameter(vehicleCfgVOList);
			if (AppConstants.SUCCESS.equalsIgnoreCase(result)) {
				status = vehicleCfgService.saveVehicleBOMConfigs(
						vehicleCfgVOList, objcaseBean, EsapiUtil.stripXSSCharacters(isCaseVehicleConfig));
			} else {
				status = result;
			}
		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("RMDWebException occured in saveVehicleBOMConfigs() method - VehicleConfigController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return status;

	}

	/**
	 * @Author :
	 * @return :List<VehicleCfgTemplateVO>
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method is used to fetch vehicle configuartion template
	 *               details
	 * 
	 */

	@RequestMapping(AppConstants.REQ_URI_GET_VEHICLE_CFG_TEMPLATES)
	public @ResponseBody
	List<VehicleCfgTemplateVO> getVehicleCfgTemplates(
			@RequestParam(value = AppConstants.CUSTOMER) final String customer,
			@RequestParam(value = AppConstants.RNH) final String rnh,
			@RequestParam(value = AppConstants.ROAD_NUMBER) final String roadNumber,
			final HttpServletRequest request) throws RMDWebException {
		rmdWebLogger
				.debug("Inside VehicleConfigController in getVehicleCfgTemplates Method");
		List<VehicleCfgTemplateVO> objVehicleCfgTemplateVO = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(customer)
					&& !RMDCommonUtility.isNullOrEmpty(rnh)
					&& !RMDCommonUtility.isNullOrEmpty(roadNumber)) {
				objVehicleCfgTemplateVO = vehicleCfgService
						.getVehicleCfgTemplates(EsapiUtil.stripXSSCharacters(customer), EsapiUtil.stripXSSCharacters(rnh), EsapiUtil.stripXSSCharacters(roadNumber));
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getVehicleCfgTemplates method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return objVehicleCfgTemplateVO;
	}

	/**
	 * @Author :
	 * @return :String
	 * @param : List<VehicleCfgVO>
	 * @throws :RMDWebException
	 * @Description: This method is used to validate whether parameter contains
	 *               any special character or not
	 * 
	 */

	public String validateParameter(List<VehicleCfgVO> vehicleCfgVO)
			throws RMDWebException {
		String status = AppConstants.FAILURE;
		try {
			for (VehicleCfgVO objVehicleCfgVO : vehicleCfgVO) {
				if (!RMDCommonUtility.isSpecialCharactersFound(objVehicleCfgVO
						.getCurrentVersion())
						&& !RMDCommonUtility
								.isSpecialCharactersFound(objVehicleCfgVO
										.getExpectedVersion())
						&& !RMDCommonUtility
								.isSpecialCharactersFound(objVehicleCfgVO
										.getSerialNumber())
						&& !RMDCommonUtility
								.isSpecialCharactersFound(objVehicleCfgVO
										.getConfigObjId())) {
					status = AppConstants.SUCCESS;
				} else {
					status = AppConstants.SPECIAL_CHARACTER_FOUND;
				}

			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in validateParameter() method - VehicleConfigController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return status;

	}

	/**
	 * @Author :
	 * @return :String
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for Deleting vehicle
	 *               Configuration Template.
	 * 
	 */
	@RequestMapping(AppConstants.DELETE_VEHICLE_CFG_TEMPLATE)
	public @ResponseBody
	String deleteVehicleCfgTemplate(
			@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString)
			throws RMDWebException {

		String result = AppConstants.FAILURE;
		final ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			VehicleCfgTemplateVO objVehicleCfgTemplateVO = mapper.readValue(
					EsapiUtil.stripXSSCharacters(parameterString), VehicleCfgTemplateVO.class);
			List<String> configList = getConfigFiles();
			if (configList.contains(objVehicleCfgTemplateVO.getConfigFile())) {
				result = vehicleCfgService
						.deleteVehicleCfgTemplate(objVehicleCfgTemplateVO);
			} else {
				result = AppConstants.DELETE_CFG_NOT_ALLOWED;
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in deleteVehicleCfgTemplate method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @Author :
	 * @return :String
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching config Files from
	 *               LookUp table.
	 * 
	 */
	@RequestMapping(AppConstants.GET_CONFIG_FILES)
	public @ResponseBody
	List<String> getConfigFiles() throws RMDWebException {
		List<String> arlConfigItems = new ArrayList<String>();
		try {
			arlConfigItems = vehicleCfgService.getConfigFiles();
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getConfigFiles method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlConfigItems;
	}

	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching controller configs
	 * 
	 */
	@RequestMapping(AppConstants.GET_CONTROLLER_CONFIGURATIONS)
	public @ResponseBody Map<String, String> getControllerConfigs()
			throws RMDWebException {
		Map<String, String> cntrlCnfgMap = null;
		try {
			cntrlCnfgMap = vehicleCfgService.getControllerConfigs();
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getControllerConfigs method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return cntrlCnfgMap;
	}
	
	/**
	 * @Author :
	 * @return :List<VehicleCfgTemplateVO>
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching controller configs
	 *               templates
	 * 
	 */
	@RequestMapping(AppConstants.GET_CONTROLLER_CONFIGURATION_TEMPLATES)
	public @ResponseBody List<VehicleCfgTemplateVO> getControllerConfigTemplates(
			@RequestParam(value = AppConstants.CONTROLLER_CONFIGURATION) final String cntrlCnfg,
			@RequestParam(value = AppConstants.CONFIGURATION_FILE) final String cnfgFile,
			final HttpServletRequest request) throws RMDWebException {
		List<VehicleCfgTemplateVO> templateList = null;
		try {
			templateList = vehicleCfgService.getControllerConfigTemplates(
					cntrlCnfg, cnfgFile);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getControllerConfigTemplates method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return templateList;
	}
	
	/**
	 * @Author :
	 * @return :String
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for Deleting vehicle
	 *               Configuration Template.
	 * 
	 */
	@RequestMapping(AppConstants.DELETE_VEHICLE_CFG)
	public @ResponseBody String deleteVehicleCfg(
			@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString,
			final HttpServletRequest request) throws RMDWebException {
		String result = AppConstants.FAILURE;
		final ObjectMapper mapper = new ObjectMapper();
		List<VehicleCfgTemplateVO> tempList = new ArrayList<VehicleCfgTemplateVO>();
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			VehicleCfgTemplateVO[] arrVehCfgTempList = mapper.readValue(
					EsapiUtil.stripXSSCharacters(parameterString), VehicleCfgTemplateVO[].class);
			tempList = Arrays.asList(arrVehCfgTempList);
			result = vehicleCfgService.deleteVehicleCfg(tempList);

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in deleteVehicleCfg method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param : 
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for loading delete Configuration page
	 * 
	 */
	@RequestMapping(AppConstants.GET_DELETE_CONFIG_PAGE)
	public ModelAndView showDeleteConfigPage(final HttpServletRequest request)
			throws RMDWebException {
		return new ModelAndView(AppConstants.DELETE_CONFIG);
	}
	
	/**
	 * @Author:
	 * @param:HttpServletRequest request
	 * @return:
	 * @throws:RMDWebException
	 * @Description: This method is used for exporting Template details to CSV
	 *               Format.
	 */

	@RequestMapping(AppConstants.EXPORT_CONIFG_TEMPLATES)
	public @ResponseBody
	void exportConfigfgTemplateDetails(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws RMDWebException, Exception {
		List<VehicleCfgTemplateVO> templateList = null;
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		String customerList = "";
		try {
			final String cntrlCnfg = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CONTROLLER_CONFIGURATION));
			final String cnfgFile = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CONFIGURATION_FILE));
			templateList = vehicleCfgService.getControllerConfigTemplates(cntrlCnfg, cnfgFile);					
			if (null != templateList && templateList.size() > 0) {
				request.setAttribute(AppConstants.TEMPLATE_LIST, templateList);
				csvContent = convertToCSVTemplateReport(templateList, locale);
				response.setContentType(AppConstants.CONTENT_TYPE);
				response.setHeader(AppConstants.CONTENT,
						AppConstants.ATTACH_FILENAME
								+ AppConstants.CFG_TEMPLATE_EXPORT_FILENAME);
				objServletOutputStream = response.getOutputStream();
				ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
						csvContent.getBytes());
				objBufferedInputStream = new BufferedInputStream(
						objByteArrayInputStream);
				objBufferedOutputStream = new BufferedOutputStream(
						objServletOutputStream);
				byte[] byteArr = new byte[2048];
				int bytesread;

				while ((bytesread = objBufferedInputStream.read(byteArr, 0,
						byteArr.length)) != -1) {
					objBufferedOutputStream.write(byteArr, 0, bytesread);
					objBufferedOutputStream.flush();
				}
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in exportProximityDetails() method ",
							rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in exportProximityDetails method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}

	private String convertToCSVTemplateReport(
			List<VehicleCfgTemplateVO> templateList, Locale locale) {
		StringBuffer strTempDetailsBuffer = new StringBuffer();
		String csvContent = null;
		try {
			strTempDetailsBuffer.append(appContext
					.getMessage(AppConstants.CTRL_CONFIG_TEMPLATES_REPORT_HEADER,
							null, locale));
			strTempDetailsBuffer.append(RMDCommonConstants.NEWLINE);
			if (RMDCommonUtility.isCollectionNotEmpty(templateList)) {
				for (VehicleCfgTemplateVO objVehicleCfgTemplateVO : templateList) {
					strTempDetailsBuffer
							.append(RMDCommonUtil
									.removeHtmlandNullValues(objVehicleCfgTemplateVO
											.getCntrlCnfg())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+RMDCommonUtil
									.removeHtmlandNullValues(objVehicleCfgTemplateVO
											.getConfigFile())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+RMDCommonUtil
									.removeHtmlandNullValues(objVehicleCfgTemplateVO
											.getTemplate())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objVehicleCfgTemplateVO
													.getVersion())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objVehicleCfgTemplateVO
													.getTitle())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objVehicleCfgTemplateVO
													.getStatus()));
					strTempDetailsBuffer.append(RMDCommonConstants.NEWLINE);
				}
			}
			csvContent = strTempDetailsBuffer.toString();
		} catch (Exception ex) {
			rmdWebLogger.error("Export to CSV convertToCSVTemplateReport"
					+ ex.getMessage());
		}
		return csvContent;
	}
	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching tooltip of lookup value
	 * 
	 */
	@RequestMapping(AppConstants.GET_LOOKUP_VALUE_TOOLTIP)
	@ResponseBody public Map<String, String> getLookupValueTooltip()
			throws RMDWebException {
		Map<String, String> lookupValueTooltipMap = null;
		try {
			lookupValueTooltipMap = vehicleCfgService.getLookupValueTooltip();
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLookupValueTooltip method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lookupValueTooltipMap;
	}
	
		/**
     * @Author :
     * @return :String
     * @param : String
     * @throws :RMDWebException
     * @Description: This method is Responsible for reApply vehicle
     *               Configuration Template.
     * 
     */
    @RequestMapping(AppConstants.RE_APPLY_TEMPLATE)
    public @ResponseBody
    String reApplyTemplate(
            @RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString)
            throws RMDWebException {

        String result = AppConstants.FAILURE;
        final ObjectMapper mapper = new ObjectMapper();
        try {
            mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
            VehicleCfgTemplateVO objVehicleCfgTemplateVO = mapper.readValue(
                    EsapiUtil.stripXSSCharacters(parameterString), VehicleCfgTemplateVO.class);
            List<String> configList = getConfigFiles();
            if (configList.contains(objVehicleCfgTemplateVO.getConfigFile())) {
                result = vehicleCfgService
                        .reApplyTemplate(objVehicleCfgTemplateVO);
            } else {
                result = AppConstants.DELETE_CFG_NOT_ALLOWED;
            }
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in reApplyTemplate method ",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return result;
    }
    
    /**
     * @Author :
     * @return :String
     * @param : String vehStatusObjId,String userId
     * @throws :RMDWebException
     * @Description: This method is Responsible for re notify vehicle
     *               Configuration Template.
     * 
     */
    @RequestMapping(AppConstants.RE_NOTIFY_TEMPLATE_ASSOCIATION)
    @ResponseBody
    public String reNotifyTemplateAssociation(@RequestParam(value=AppConstants.VEH_STATUS_OBJID) String vehStatusObjId,
            @RequestParam(value=AppConstants.USER_ID) String userId) throws RMDWebException{
        String result = RMDCommonConstants.EMPTY_STRING;
        
        try{
            if(!RMDCommonUtility.isNullOrEmpty(vehStatusObjId) && !RMDCommonUtility.isNullOrEmpty(userId))
                result = vehicleCfgService.reNotifyTemplateAssociation(vehStatusObjId,userId);
            else
                result=RMDCommonConstants.NO_DATA_FOUND;
            
        }catch(Exception ex) {
            rmdWebLogger.error("Exception occured in reNotifyTemplateAssociation() method ",ex);
            RMDWebErrorHandler.handleException(ex);
            
        }
        
        return result;
        
    }
}
