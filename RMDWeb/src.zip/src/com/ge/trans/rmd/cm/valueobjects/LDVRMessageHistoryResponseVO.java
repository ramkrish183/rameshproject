package com.ge.trans.rmd.cm.valueobjects;

import java.util.ArrayList;
import java.util.List;

public class LDVRMessageHistoryResponseVO {

	
	protected List<LDVRMessageVO> messages;
	protected String errorCode;
	protected String errorDescription;
	protected String maxRecordsReturned;
	
	public List<LDVRMessageVO> getMessages(){
		if(messages == null){
			messages = new ArrayList<LDVRMessageVO>();
		}
		return this.messages;
	}
	
	public void setMessages(List<LDVRMessageVO> messages){
		this.messages = messages;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorDescription() {
		return errorDescription;
	}

	public void setErrorDescription(String errorDescription) {
		this.errorDescription = errorDescription;
	}

	public String getMaxRecordsReturned() {
		return maxRecordsReturned;
	}

	public void setMaxRecordsReturned(String maxRecordsReturned) {
		this.maxRecordsReturned = maxRecordsReturned;
	}
	
}
