package com.ge.trans.rmd.cm.valueobjects;

import java.util.Map;

public class CaseTrendBean {
	private String problemDesc;
	private String count;
	private String creationRXDate;
	private Map<String,Integer> caseTrend;
	public String getProblemDesc() {
		return problemDesc;
	}
	public void setProblemDesc(String problemDesc) {
		this.problemDesc = problemDesc;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getCreationRXDate() {
		return creationRXDate;
	}
	public void setCreationRXDate(String creationRXDate) {
		this.creationRXDate = creationRXDate;
	}
	public Map<String, Integer> getCaseTrend() {
		return caseTrend;
	}
	public void setCaseTrend(Map<String, Integer> caseTrend) {
		this.caseTrend = caseTrend;
	}
	

}
