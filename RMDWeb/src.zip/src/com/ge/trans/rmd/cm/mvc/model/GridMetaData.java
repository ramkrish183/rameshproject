package com.ge.trans.rmd.cm.mvc.model;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.services.assets.valueobjects.FaultDataDetailsResponseType;

public class GridMetaData {
	private List<String> columHeader=null;
	private List<ColModel> columModel=null;
	private Map<String,String> grupCounts=null;
	private Map<String,String> grupColors=null;
	private List<String> groupNames=null;
	private FaultDataDetailsResponseType responseObject = null;
	private List<Map<String,String>> lsFaultAssetValuePart = null;
	private List<String> unitConversionRoleList;
	public FaultDataDetailsResponseType getResponseObject() {
		return responseObject;
	}
	public void setResponseObject(final FaultDataDetailsResponseType responseObject) {
		this.responseObject = responseObject;
	}
	public List<Map<String, String>> getLsFaultAssetValuePart() {
		return lsFaultAssetValuePart;
	}
	public void setLsFaultAssetValuePart(
			final List<Map<String, String>> lsFaultAssetValuePart) {
		this.lsFaultAssetValuePart = lsFaultAssetValuePart;
	}
	public List<String> getGroupNames() {
		return groupNames;
	}
	public void setGroupNames(final List<String> groupNames) {
		this.groupNames = groupNames;
	}
	public Map<String, String> getGrupCounts() {
		return grupCounts;
	}
	public void setGrupCounts(final Map<String, String> grupCounts) {
		this.grupCounts = grupCounts;
	}
	public Map<String, String> getGrupColors() {
		return grupColors;
	}
	public void setGrupColors(Map<String, String> grupColors) {
		this.grupColors = grupColors;
	}
	public List<String> getColumHeader() {
		return columHeader;
	}
	public void setColumHeader(final List<String> columHeader) {
		this.columHeader = columHeader;
	}
	public List<ColModel> getColumModel() {
		return columModel;
	}
	public void setColumModel(final List<ColModel> columModel) {
		this.columModel = columModel;
	}
	public List<String> getUnitConversionRoleList() {
		return unitConversionRoleList;
	}
	public void setUnitConversionRoleList(List<String> unitConversionRoleList) {
		this.unitConversionRoleList = unitConversionRoleList;
	}
}
