package com.ge.trans.rmd.cm.beans;

import com.ge.trans.rmd.common.beans.RMDBaseBean;

@SuppressWarnings("serial")
public class OpenCasesBean extends RMDBaseBean {
	
	private String timeZone;
	private String customerId;
	private String caseId;
	private String rxCaseId;
	private String currentOwner;
	private Integer rowVersion;
	private int  closedRxLookBackDays;
	private boolean mycases;
	private String timeZoneCode;
	private String defaultTimeZone;
	
	
	


	/**
	 * @return the mycases
	 */
	public boolean isMycases() {
		return mycases;
	}

	/**
	 * @param mycases the mycases to set
	 */
	public void setMycases(boolean mycases) {
		this.mycases = mycases;
	}

	public String getRxCaseId() {
		return rxCaseId;
	}

	public void setRxCaseId(String rxCaseId) {
		this.rxCaseId = rxCaseId;
	}

	public Integer getRowVersion() {
		return rowVersion;
	}

	public void setRowVersion(final Integer rowVersion) {
		this.rowVersion = rowVersion;
	}

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(final String caseId) {
		this.caseId = caseId;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(final String timeZone) {
		this.timeZone = timeZone;
	}

	public void setCustomerId(final String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerId() {
		return customerId;
	}

	public int getClosedRxLookBackDays() {
		return closedRxLookBackDays;
	}

	public void setClosedRxLookBackDays(int closedRxLookBackDays) {
		this.closedRxLookBackDays = closedRxLookBackDays;
	}

	public String getCurrentOwner() {
		return currentOwner;
	}

	public void setCurrentOwner(String currentOwner) {
		this.currentOwner = currentOwner;
	}

	public String getTimeZoneCode() {
		return timeZoneCode;
	}

	public void setTimeZoneCode(String timeZoneCode) {
		this.timeZoneCode = timeZoneCode;
	}

	public String getDefaultTimeZone() {
		return defaultTimeZone;
	}

	public void setDefaultTimeZone(String defaultTimeZone) {
		this.defaultTimeZone = defaultTimeZone;
	}

	

	

}
