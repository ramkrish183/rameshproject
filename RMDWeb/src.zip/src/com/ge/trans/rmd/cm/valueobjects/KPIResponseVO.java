package com.ge.trans.rmd.cm.valueobjects;

public class KPIResponseVO {
	
	
	private double totalDelivered;
	private double totalClosedUrgency;
	private double totalClosedType;
	private double deliveredRed;
	private double deliveredYellow;
	private double deliveredWhite;
	private double deliveredBlue;
	private double closedRed;
	private double closedYellow;
	private double closedWhite;
	private double closedBlue;
	private double repaired;
	private double deferred;
	private double ntf;
	private String assetNumber;
	private String assetGroupName;
	private String customerId;
	private String kpiname; 
	
	
	public double getTotalDelivered() {
		return totalDelivered;
	}
	public void setTotalDelivered(final double totalDelivered) {
		this.totalDelivered = totalDelivered;
	}
	public double getTotalClosedUrgency() {
		return totalClosedUrgency;
	}
	public void setTotalClosedUrgency(final double totalClosedUrgency) {
		this.totalClosedUrgency = totalClosedUrgency;
	}
	public double getTotalClosedType() {
		return totalClosedType;
	}
	public void setTotalClosedType(final double totalClosedType) {
		this.totalClosedType = totalClosedType;
	}
	public double getDeliveredRed() {
		return deliveredRed;
	}
	public void setDeliveredRed(final double deliveredRed) {
		this.deliveredRed = deliveredRed;
	}
	public double getDeliveredYellow() {
		return deliveredYellow;
	}
	public void setDeliveredYellow(final double deliveredYellow) {
		this.deliveredYellow = deliveredYellow;
	}
	public double getDeliveredWhite() {
		return deliveredWhite;
	}
	public void setDeliveredWhite(final double deliveredWhite) {
		this.deliveredWhite = deliveredWhite;
	}
	public double getDeliveredBlue() {
		return deliveredBlue;
	}
	public void setDeliveredBlue(final double deliveredBlue) {
		this.deliveredBlue = deliveredBlue;
	}
	public double getClosedRed() {
		return closedRed;
	}
	public void setClosedRed(final double closedRed) {
		this.closedRed = closedRed;
	}
	public double getClosedYellow() {
		return closedYellow;
	}
	public void setClosedYellow(final double closedYellow) {
		this.closedYellow = closedYellow;
	}
	public double getClosedWhite() {
		return closedWhite;
	}
	public void setClosedWhite(final double closedWhite) {
		this.closedWhite = closedWhite;
	}
	public double getClosedBlue() {
		return closedBlue;
	}
	public void setClosedBlue(final double closedBlue) {
		this.closedBlue = closedBlue;
	}
	public double getRepaired() {
		return repaired;
	}
	public void setRepaired(final double repaired) {
		this.repaired = repaired;
	}
	public double getDeferred() {
		return deferred;
	}
	public void setDeferred(final double deferred) {
		this.deferred = deferred;
	}
	public double getNtf() {
		return ntf;
	}
	public void setNtf(final double ntf) {
		this.ntf = ntf;
	}
	public String getAssetNumber() {
		return assetNumber;
	}
	public void setAssetNumber(final String assetNumber) {
		this.assetNumber = assetNumber;
	}
	public String getAssetGroupName() {
		return assetGroupName;
	}
	public void setAssetGroupName(final String assetGroupName) {
		this.assetGroupName = assetGroupName;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(final String customerId) {
		this.customerId = customerId;
	}
	public String getKpiname() {
		return kpiname;
	}
	public void setKpiname(final String kpiname) {
		this.kpiname = kpiname;
	}
	
	

}
