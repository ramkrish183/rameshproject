package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.valueobjects.AddRemoveSecondarySiteVO;
import com.ge.trans.rmd.cm.valueobjects.AddressDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.AddressSearchVO;
import com.ge.trans.rmd.cm.valueobjects.ContactDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.ContactSearchVO;
import com.ge.trans.rmd.cm.valueobjects.ContactSiteDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.SiteDetailsVO;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface ContactSiteService {

    /**
     * 
     * @param objContactSearchVO
     * @return List<ContactDetailsVO>
     * @throws RMDWebException
     * @Description This method is used to get the contact details for the given
     *              search combination.
     * 
     */
    public List<ContactDetailsVO> getContacts(ContactSearchVO objContactSearchVO)
            throws RMDWebException;

    /**
     * 
     * @param contactObjId
     * @return ContactSiteDetailsVO
     * @throws RMDWebException
     * @Description This method is used to get the all details for the selected
     *              contact
     * 
     */
    public ContactSiteDetailsVO viewContactDetails(String contactObjId)
            throws RMDWebException;

    /**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:RMDWebException
     * @Description: This method is used for fetching the contact status
     */
    public Map<String, String> getContactStatus() throws RMDWebException;

    /**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:RMDWebException
     * @Description: This method is used for fetching the contact roles
     */
    public Map<String, String> getContactRoles() throws RMDWebException;

    /**
     * 
     * @param contactObjId
     * @return List<SiteDetailsVO>
     * @throws RMDWebException
     * @Description This method is used to get the secondary site details
     * 
     */
    public List<SiteDetailsVO> getContactSecondarySites(String contactObjId)
            throws RMDWebException;

    /**
     * 
     * @param AddRemoveSecondarySiteVO
     * @return String
     * @throws RMDWebException
     * @Description This method is used to add the secondary site to a contact
     * 
     */
    public String addContactSecondarySite(
            AddRemoveSecondarySiteVO objAddRemoveSecondarySiteVO)
            throws RMDWebException;

    /**
     * 
     * @param List
     *            <AddRemoveSecondarySiteVO>
     * @return String
     * @throws RMDWebException
     * @Description This method is used to remove the secondary sites from the
     *              contact
     * 
     */
    public String removeContactSecondarySite(
            List<AddRemoveSecondarySiteVO> removeSecondarySiteVOList)
            throws RMDWebException;

    /**
     * 
     * @param ContactSiteDetailsVO
     * @return String
     * @throws RMDWebException
     * @Description This method is used to add or update the Contact details
     * 
     */
    public String addOrUpdateContact(
            ContactSiteDetailsVO objContactSiteDetailsVO)
            throws RMDWebException;

    /**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:RMDWebException
     * @Description: This method is used for fetching the address search filter
     *               options
     */
    public Map<String, String> getAddressFilterOptions() throws RMDWebException;

    /**
     * 
     * @param
     * @return List<AddressDetailsVO>
     * @throws RMDWebException
     * @Description This method is used to get the address details for the given
     *              search combination.
     * 
     */
    public List<AddressDetailsVO> getAddress(AddressSearchVO objAdressSearchVO)
            throws RMDWebException;

    /**
     * 
     * @param addrObjId
     * @return AddressDetailsVO
     * @throws RMDWebException
     * @Description This method is used to get the all details for the selected
     *              address
     * 
     */
    public AddressDetailsVO viewAddressDetails(String addrObjId)
            throws RMDWebException;

    /**
     * 
     * @param
     * @return List<String>
     * @throws RMDWebException
     * @Description This method is used to get the all country List
     * 
     */
    public List<String> getCountryList() throws RMDWebException;

    /**
     * 
     * @param String
     *            country
     * @return List<String>
     * @throws RMDWebException
     * @Description This method is used to get the states for the selected
     *              Country
     * 
     */
    public List<String> getCountryStates(String country) throws RMDWebException;

    /**
     * 
     * @param String
     *            country
     * @return List<String>
     * @throws RMDWebException
     * @Description This method is used to get the time zones for the selected
     *              Country
     * 
     */
    public List<String> getCountryTimeZones(String country)
            throws RMDWebException;

    /**
     * 
     * @param AddressDetailsVO
     * @return String
     * @throws RMDWebException
     * @Description This method is used to add or update the Address details
     * 
     */
    public String addOrUpdateAddress(AddressDetailsVO objAddressDetailsVO)
            throws RMDWebException;
    
    /**
     * 
     * @param ]
     *            
     * @return Map<String, String>
     * @throws RMDWebException
     * @Description This method is used for fetching the ISD code list
     * 
     */
    public Map<String, String> getContactISDList() throws RMDWebException;

}
