package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.trans.rmd.common.vo.RMDBaseVO;
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class FleetViewVO extends RMDBaseVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String assetNumber;
	private String assetGrpName;
	private String customerId;
	private String customerName;
	private Long assetGrpNumber;
	private String priority;
	private String model;
	private Long redRx;
	private Long yellowRx;
	private Long whiteRx;
	private Long blueRx;
	private String note;
	private String dtLastProcessedDate;
	private String dtLastFaultDate;
	private String location;
	private String fleet;
	private String noteType;
	private String noteDescription;
	private String createdBy;
	private String noteSeqID;
	private String noteCreationDate;
	private String worstUrgency;
	private String latitude;
	private String longitude;
	private String maxOccurTime;
	private String kpiName;
	private Long kpiTotalCount;
	private  List<ToolTipVO> toolTipList;
	
	
	
	public List<ToolTipVO> getToolTipList() {
		return toolTipList;
	}
	public void setToolTipList(final List<ToolTipVO> toolTipList) {
		this.toolTipList = toolTipList;
	}
	public String getAssetNumber() {
		return assetNumber;
	}
	public void setAssetNumber(final String assetNumber) {
		this.assetNumber = assetNumber;
	}
	public String getAssetGrpName() {
		return assetGrpName;
	}
	public void setAssetGrpName(final String assetGrpName) {
		this.assetGrpName = assetGrpName;
	}
	public String getCustomer() {
		return customerId;
	}
	public void setCustomer(final String customerId) {
		this.customerId = customerId;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(final String priority) {
		this.priority = priority;
	}
	public String getModel() {
		return model;
	}
	public void setModel(final String model) {
		this.model = model;
	}
	public Long getRedRx() {
		return redRx;
	}
	public void setRedRx(final Long redRx) {
		this.redRx = redRx;
	}
	public Long getYellowRx() {
		return yellowRx;
	}
	public void setYellowRx(final Long yellowRx) {
		this.yellowRx = yellowRx;
	}
	public Long getWhiteRx() {
		return whiteRx;
	}
	public void setWhiteRx(final Long whiteRx) {
		this.whiteRx = whiteRx;
	}
	public String getNote() {
		return note;
	}
	public void setNote(final String note) {
		this.note = note;
	}
	public String getDtLastProcessedDate() {
		return dtLastProcessedDate;
	}
	public void setDtLastProcessedDate(final String dtLastProcessedDate) {
		this.dtLastProcessedDate = dtLastProcessedDate;
	}
	public String getDtLastFaultDate() {
		return dtLastFaultDate;
	}
	public void setDtLastFaultDate(final String dtLastDownloadDate) {
		this.dtLastFaultDate= dtLastDownloadDate;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(final String location) {
		this.location = location;
	}
	public String getFleet() {
		return fleet;
	}
	public void setFleet(final String fleet) {
		this.fleet = fleet;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(final String customerName) {
		this.customerName = customerName;
	}
	public Long getAssetGrpNumber() {
		return assetGrpNumber;
	}
	public void setAssetGrpNumber(final Long assetGrpNumber) {
		this.assetGrpNumber = assetGrpNumber;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(final String customerId) {
		this.customerId = customerId;
	}
	public String getNoteType() {
		return noteType;
	}
	public void setNoteType(final String noteType) {
		this.noteType = noteType;
	}
	public String getNoteDescription() {
		return noteDescription;
	}
	public void setNoteDescription(final String noteDescription) {
		this.noteDescription = noteDescription;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(final String createdBy) {
		this.createdBy = createdBy;
	}
	public String getNoteSeqID() {
		return noteSeqID;
	}
	public void setNoteSeqID(final String noteSeqID) {
		this.noteSeqID = noteSeqID;
	}
	public String getNoteCreationDate() {
		return noteCreationDate;
	}
	public void setNoteCreationDate(final String noteCreationDate) {
		this.noteCreationDate = noteCreationDate;
	}
	public String getWorstUrgency() {
		return worstUrgency;
	}
	public void setWorstUrgency(final String worstUrgency) {
		this.worstUrgency = worstUrgency;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(final String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(final String longitude) {
		this.longitude = longitude;
	}
	public String getMaxOccurTime() {
		return maxOccurTime;
	}
	public void setMaxOccurTime(final String maxOccurTime) {
		this.maxOccurTime = maxOccurTime;
	}
	public String getKpiName() {
		return kpiName;
	}
	public void setKpiName(final String kpiName) {
		this.kpiName = kpiName;
	}
	public Long getKpiTotalCount() {
		return kpiTotalCount;
	}
	public void setKpiTotalCount(final Long kpiTotalCount) {
		this.kpiTotalCount = kpiTotalCount;
	}
	
	public Long getBlueRx() {
		return blueRx;
	}
	public void setBlueRx(Long blueRx) {
		this.blueRx = blueRx;
	}
	
	@Override
	public String toString() {
		return "FleetViewVO [assetNumber=" + assetNumber + ", assetGrpName="
				+ assetGrpName + ", customerId=" + customerId
				+ ", customerName=" + customerName + ", assetGrpNumber="
				+ assetGrpNumber + ", priority=" + priority + ", model="
				+ model + ", redRx=" + redRx + ", yellowRx=" + yellowRx
				+ ", whiteRx=" + whiteRx + ", note=" + note
				+ ", dtLastProcessedDate=" + dtLastProcessedDate
				+ ", dtLastDownloadDate=" + dtLastFaultDate + ", location="
				+ location + ", fleet=" + fleet + ", noteType=" + noteType
				+ ", noteDescription=" + noteDescription + ", createdBy="
				+ createdBy + ", noteSeqID=" + noteSeqID
				+ ", noteCreationDate=" + noteCreationDate + ", worstUrgency="
				+ worstUrgency + ", latitude=" + latitude + ", longitude="
				+ longitude + ", maxOccurTime=" + maxOccurTime + ", kpiName="
				+ kpiName + ", kpiTotalCount=" + kpiTotalCount + "]";
	}
}
