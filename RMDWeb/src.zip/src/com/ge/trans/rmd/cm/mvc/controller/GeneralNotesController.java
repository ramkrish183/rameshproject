package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.portlet.ModelAndView;

import com.ge.trans.rmd.cm.service.GeneralNotesService;
import com.ge.trans.rmd.common.beans.GpocNotesBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.vo.GenNotesVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
public class GeneralNotesController extends RMDBaseController {

	@Autowired
	private GeneralNotesService generalNotesService;
	@Autowired
	private org.springframework.cache.CacheManager cacheManager;
	@Autowired
	private ApplicationContext appContext;

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@RequestMapping(AppConstants.REQ_URI_GENERAL_NOTES)
	public ModelAndView generalNotesPage(final HttpServletRequest request)
			throws RMDWebException {
		rmdWebLogger
				.debug("Inside GeneralNotesController in generalNotesPage Method");
		try {
			HttpSession session = request.getSession(false);
			UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			request.setAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE,
					userVO.getIsCMPrivilege());

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in generalNotesPage() method in GeneralNotesController ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return new ModelAndView(AppConstants.GENERAL_NOTES);
	}

	@RequestMapping(value = AppConstants.GENERALNOTES_SHOW_ALL, method = RequestMethod.GET)
	public @ResponseBody List<GenNotesVO> showAllGeneralNotes(
			final HttpServletRequest request) throws Exception {

		final HttpSession session = request.getSession(false);
		final GpocNotesBean objGpocNotesBean = new GpocNotesBean();
		List<GenNotesVO> objlst = new ArrayList<GenNotesVO>();
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			objGpocNotesBean.setLanguage(userVO.getStrLanguage());
			objlst = generalNotesService.showAllGeneralNotes(objGpocNotesBean,
					userVO.getTimeZone());
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in showAll method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return objlst;

	}

	/**
	 * @Author:
	 * @param :
	 * @return String
	 * @throws RMDWebException
	 * @Description: This method is used to insert the notes
	 */
	@RequestMapping(value = AppConstants.ADD_GENERAL_NOTES, method = RequestMethod.POST)
	public @ResponseBody String addGeneralNotes(final HttpServletRequest request)
			throws RMDWebException {

		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String uniquerecord = null;
		GpocNotesBean gpocNotesBean = new GpocNotesBean();
		try {
			String notesdesc = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.NOTES_DESC));
			String flag = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG));
			if (!RMDCommonUtility.isNullOrEmpty(notesdesc)) {
				gpocNotesBean.setNotesdesc(notesdesc);
			}
			if(!RMDCommonUtility.isNullOrEmpty(flag)){
			    gpocNotesBean.setVisibilityFlag(flag);
			}else{
			    gpocNotesBean.setVisibilityFlag(RMDCommonConstants.N_LETTER_UPPER);
			}
			gpocNotesBean.setEnteredby(userVO.getUserId());
			uniquerecord = generalNotesService.addGeneralNotes(gpocNotesBean);

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in addNotesToVehicle  method in NotesController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return uniquerecord;
	}

	/**
	 * @Description:This method is used to export the Gneral notes under
	 *                   Turnover
	 * @return: void
	 * @param:HttpServletRequest request,HttpServletResponse response,Locale
	 *                           locale,
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 */
	@RequestMapping(value = AppConstants.EXPORT_AT_GENERAL_NOTES, method = RequestMethod.POST)
	public void exportGeneralNotes(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws IOException, GenericAjaxException, RMDWebException {

		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final GpocNotesBean gpocBean = new GpocNotesBean();
		List<GenNotesVO> arlgennotesvo = new ArrayList<GenNotesVO>();

		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;

		try {
			gpocBean.setUserLanguage(userVO.getStrUserLanguage());
			arlgennotesvo = generalNotesService.showAllGeneralNotes(gpocBean,
					userVO.getTimeZone());

			if (null != arlgennotesvo && !arlgennotesvo.isEmpty()) {
				csvContent = convertToCSVGenetalnotes(arlgennotesvo, locale);
				response.setContentType(AppConstants.CONTENT_TYPE);
				response.setHeader(AppConstants.CONTENT,
						AppConstants.ATTACH_FILENAME
								+ AppConstants.GENERAL_NOES_EXPORT_FILENAME);
				objServletOutputStream = response.getOutputStream();
				ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
						csvContent.getBytes());
				objBufferedInputStream = new BufferedInputStream(
						objByteArrayInputStream);

				objBufferedOutputStream = new BufferedOutputStream(
						objServletOutputStream);

				byte[] byteArr = new byte[2048];
				int bytesread;

				while ((bytesread = objBufferedInputStream.read(byteArr, 0,
						byteArr.length)) != -1) {
					objBufferedOutputStream.write(byteArr, 0, bytesread);
					objBufferedOutputStream.flush();
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in exportGeneralNotes method ", ex);
			RMDWebErrorHandler.handleException(ex);
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}
		}
	}

	/**
	 * @Description:This method is used convert General Notes List into csv
	 *                   format
	 * @return: String
	 * @param:List<GpocBean> gnStatus, Locale locale
	 */

	private String convertToCSVGenetalnotes(List<GenNotesVO> arlgennotesvo,
			Locale locale) {
		String csvContent = null;
		StringBuilder strBufferAssetHeader = new StringBuilder();
		try {
			strBufferAssetHeader.append(appContext.getMessage(
					AppConstants.GENERAL_NOTES_HEADER, null, locale));
			strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			for (GenNotesVO gnList : arlgennotesvo) {
				if (null != gnList.getNotesdesc()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + gnList.getNotesdesc()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != gnList.getVisibilityFlag()) {
                    strBufferAssetHeader.append(AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE + gnList.getVisibilityFlag()
                            + AppConstants.QUOTE
                            + RMDCommonConstants.COMMMA_SEPARATOR);
                } else {
                    strBufferAssetHeader.append(AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                            + RMDCommonConstants.COMMMA_SEPARATOR);
                }				
				if (null != gnList.getEnteredby()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + gnList.getEnteredby()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != gnList.getLastUpdatedTime()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ gnList.getLastUpdatedTime() + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}

				strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBufferAssetHeader.toString();
		} catch (Exception exception) {
			rmdWebLogger.error("Export to CSV General Notes" + exception);
		}
		return csvContent;
	}

	/**
	 * @Author:
	 * @param :
	 * @return String
	 * @throws RMDWebException
	 * @Description: This method is used to delete notes in General notes
	 *               sccreen.
	 */
	@RequestMapping(value = AppConstants.REMOVE_GENERAL_NOTES, method = RequestMethod.POST)
	@ResponseBody
	public String removeGeneralNotes(
			@RequestParam(value = AppConstants.GET_GNSEQIDS_STRING) final String gnseqids,
			final HttpServletRequest request) throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<GenNotesVO> objGenNotesVO = new ArrayList<GenNotesVO>();
		final ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			GenNotesVO[] arrGenNotesVO = mapper.readValue(gnseqids,
					GenNotesVO[].class);
			objGenNotesVO = Arrays.asList(arrGenNotesVO);
			status = generalNotesService.removeGeneralNotes(objGenNotesVO);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("RMDWebException occured in removeGeneralNotes() method - GeneralNotesController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return status;

	}
	
	/**
     * @Author:
     * @param :List<GenNotesVO>
     * @return String
     * @throws RMDWebException
     * @Description: This method is used to update the visibility flag of General/Comm notes
     */
    @RequestMapping(value = AppConstants.UPDATE_GEN_OR_COMM_NOTES, method = RequestMethod.POST)
    @ResponseBody
    public String updateGenOrCommNotes(
            @RequestParam(value = AppConstants.GET_PARAMETER_STRING) final String parameterString,           
            final HttpServletRequest request) throws RMDWebException {
        String status = AppConstants.FAILURE;
        List<GenNotesVO> objGenNotesVO = new ArrayList<GenNotesVO>();
        final ObjectMapper mapper = new ObjectMapper();
        try {
            if(null !=parameterString){
                mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
                mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
                GenNotesVO[] arrGenNotesVO = mapper.readValue(parameterString,
                        GenNotesVO[].class);
                objGenNotesVO = Arrays.asList(arrGenNotesVO);           
                status = generalNotesService.updateGenOrCommNotes(objGenNotesVO);
            }else
                 status = AppConstants.NO_INPUT_SELECTED;
        } catch (Exception ex) {
            status = AppConstants.FAILURE;
            rmdWebLogger
                    .error("RMDWebException occured in updateGenOrCommNotes() method of GeneralNotesController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }

        return status;

    }

}
