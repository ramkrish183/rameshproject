/**
 * 
 */
package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.valueobjects.FindNotesDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.StickyNotesDetailsVO;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface NotesService {

	/**
	 * @Author :
	 * @return :Map<String, String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This controller method will fetch the list of controllers.
	 * 
	 */
	public Map<String, String> getAllControllers() throws RMDWebException;

	/**
	 * @Author :
	 * @return :String
	 * @param :NotesBean
	 * @throws :RMDWebException
	 * @Description: This method adds the notes for the selected customer.
	 * 
	 */
	public String addNotesToVehicle(NotesBean notesBean) throws RMDWebException;

	/**
	 * @Author :
	 * @return :StickyNotesDetailsVO
	 * @param :customerId,fromRN,timeZone
	 * @throws :RMDWebException
	 * @throws :Exception
	 * @Description: This method adds the notes for the selected customer.
	 * 
	 */
	public List<StickyNotesDetailsVO> fetchVehicleStickyDetails(String customerId,
			String fromRN,String noOfUnits, String timeZone) throws RMDWebException, Exception;

	/**
	 * @Author :
	 * @return :Map<String, String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This controller method will fetch the list of Creators .
	 * 
	 */
	public Map<String, String> getNotesCreatersList() throws RMDWebException;

	/**
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Find Notes Note Type Options By drop down.
	 */
	public Map<String, String> getNoteTypes() throws RMDWebException;

	/**
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Find Notes From Date default value.
	 */
	public String getFindNotesLookBackDays() throws RMDWebException;

	/**
	 * @Author:
	 * @param:NotesBean
	 * @return:List<FindNotesDetailsVO>
	 * @throws RMDWebException
	 * @throws:RMDWebException
	 * @Description: This method is used to get Notes Details.
	 */

	public List<FindNotesDetailsVO> getFindNotes(NotesBean objNotesBean,
			String timeZone) throws RMDWebException;

	/**
	 * @Author:
	 * @param :caseStickyObjId,unitStickyObjId
	 * @return:String
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used for removing a unit Level as well as
	 *               case Level Sticky Notes.
	 */
	public String removeSticky(String unitStickyObjId, String caseStickyObjId)
			throws RMDWebException;

}
