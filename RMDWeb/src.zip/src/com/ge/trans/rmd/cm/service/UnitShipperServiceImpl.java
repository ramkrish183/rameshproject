package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.InfancyUnitBean;
import com.ge.trans.rmd.cm.valueobjects.ShipUnitDataVO;
import com.ge.trans.rmd.cm.valueobjects.UnitShipDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.UnitShippersVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.pp.beans.AssetBean;
import com.ge.trans.rmd.services.assets.valueobjects.AssetNumberResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.UnitShippersRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.UnitShippersResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class UnitShipperServiceImpl extends RMDBaseServiceImpl implements
		UnitShipperService {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	WebServiceInvoker webServiceInvoker;
	@Autowired
	private CachedService cachedService;

	/**
	 * @Author :
	 * @return :List<UnitShippersVO>
	 * @param :UnitShipDetailsVO objDetailsVO
	 * @throws :RMDWebException
	 * @Description: This Method Fetches the list of Units to be shipped.
	 * 
	 */

	public List<UnitShippersVO> getUnitsToBeShipped(
			UnitShipDetailsVO objDetailsVO, String timeZone,String defaultTimezone)
			throws RMDWebException {
		List<UnitShippersVO> arlShipperDetails = new ArrayList<UnitShippersVO>();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		UnitShippersResponseType[] arrUnitShippersType=null;
		UnitShippersVO objShippersVO = null;
		Date testTrackDate=null;
		final DateFormat nonESTZoneFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		final TimeZone firstTime = TimeZone.getTimeZone(timeZone);
		nonESTZoneFormat.setTimeZone(firstTime);
		String userTimeZone = firstTime.getID();
		try {

			if (!RMDCommonUtility.isNullOrEmpty(objDetailsVO.getAssetGrpName())) {

				queryParams.put(AppConstants.ASSET_GROUP_NAME,
						objDetailsVO.getAssetGrpName());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objDetailsVO.getAssetNumber())) {

				queryParams.put(AppConstants.ASSET_NUMBER,
						objDetailsVO.getAssetNumber());
			}

			if (!RMDCommonUtility.isNullOrEmpty(objDetailsVO.getCustomerList())) {
				queryParams.put(AppConstants.CUSTOMER_LIST,
						objDetailsVO.getCustomerList());
			}

			 arrUnitShippersType = (UnitShippersResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_UNITS_TO_BE_SHIPPED, null,
							queryParams, null, UnitShippersResponseType[].class);
			 
			 if (arrUnitShippersType != null && arrUnitShippersType.length > 0) {
				 arlShipperDetails = new ArrayList<UnitShippersVO>(arrUnitShippersType.length);
				 for (UnitShippersResponseType objUnitShippersType : arrUnitShippersType) {
						objShippersVO = new UnitShippersVO();
						objShippersVO.setObjId(objUnitShippersType.getObjId());
						objShippersVO
								.setRoadNumber(objUnitShippersType.getRoadNumber());
						objShippersVO.setRnh(objUnitShippersType.getRnh());
						
						if (userTimeZone.equals(AppConstants.EST_TIMEZONE)
                                && defaultTimezone.equals(AppConstants.TIMEZONE_EASTERN)) {
                         if (null != objUnitShippersType.getTestTrackDate()) {
                        	 objShippersVO.setTestTrackDate(objUnitShippersType.getTestTrackDate());
                         }

                  } else {
                         if (null != objUnitShippersType.getTestTrackDate()) {
                        	 testTrackDate = RMDCommonUtility.stringToUSESTDate(
                                		objUnitShippersType.getTestTrackDate(),
                                              RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
                        	 objShippersVO.setTestTrackDate(nonESTZoneFormat.format(testTrackDate));
                         }
                  }

			
						arlShipperDetails.add(objShippersVO);
					}
				 arrUnitShippersType=null;
			}

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getUnitsToBeShipped method of UnitShipperServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return arlShipperDetails;
	}

	/**
	 * @Author :
	 * @return :List<UnitShippersVO>
	 * @param :UnitShipDetailsVO objDetailsVO
	 * @throws :RMDWebException
	 * @Description: This Method Fetches the list of Units which are already
	 *               Shipped.
	 * 
	 */

	public List<UnitShippersVO> getLastShippedUnits(
			UnitShipDetailsVO objDetailsVO, String timeZone,String defaultTimezone)
			throws RMDWebException {
		List<UnitShippersVO> arlLastShippedUnits = new ArrayList<UnitShippersVO>();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		UnitShippersVO objShippersVO = null;
		final DateFormat nonESTZoneFormat = new SimpleDateFormat(
				AppConstants.DATE_FORMAT_24HRS);
		final TimeZone firstTime = TimeZone.getTimeZone(timeZone);
		nonESTZoneFormat.setTimeZone(firstTime);
		String userTimeZone = firstTime.getID();
		Date shipTrackDate=null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(objDetailsVO.getCustomerList())) {
				queryParams.put(AppConstants.CUSTOMER_LIST,
						objDetailsVO.getCustomerList());
			}

			if (!RMDCommonUtility.isNullOrEmpty(objDetailsVO.getAssetGrpName())) {

				queryParams.put(AppConstants.ASSET_GROUP_NAME,
						objDetailsVO.getAssetGrpName());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objDetailsVO.getAssetNumber())) {

				queryParams.put(AppConstants.ASSET_NUMBER,
						objDetailsVO.getAssetNumber());
			}

			if (!RMDCommonUtility
					.isNullOrEmpty(objDetailsVO.getIsDefaultLoad())) {

				queryParams.put(AppConstants.IS_DEFAULT_LOAD,
						objDetailsVO.getIsDefaultLoad());

			}
			UnitShippersResponseType[] arrUnitShippersType = (UnitShippersResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_LAST_SHIPPED_UNITS, null,
							queryParams, null, UnitShippersResponseType[].class);
			if(arrUnitShippersType!=null&&arrUnitShippersType.length>0){
				arlLastShippedUnits = new ArrayList<UnitShippersVO>(arrUnitShippersType.length);
				for (UnitShippersResponseType objUnitShippersType : arrUnitShippersType) {
					 objShippersVO = new UnitShippersVO();
					 objShippersVO.setObjId(objUnitShippersType.getObjId());
					 objShippersVO
							.setRoadNumber(objUnitShippersType.getRoadNumber());
					 objShippersVO.setRnh(objUnitShippersType.getRnh());
					
					if (userTimeZone.equals(AppConstants.EST_TIMEZONE)
                            && defaultTimezone.equals(AppConstants.TIMEZONE_EASTERN)) {
                     if (null != objUnitShippersType.getShipDate()) {
                    	 objShippersVO.setShipDate(objUnitShippersType.getShipDate());
                     }

              } else {
                     if (null != objUnitShippersType.getShipDate()) {
                    	 shipTrackDate = RMDCommonUtility.stringToUSESTDate(
                            		objUnitShippersType.getShipDate(),
                                          RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
                    	 objShippersVO.setShipDate(nonESTZoneFormat.format(shipTrackDate));
                     }
              }
					
					if (userTimeZone.equals(AppConstants.EST_TIMEZONE)
                            && defaultTimezone.equals(AppConstants.TIMEZONE_EASTERN)) {
                     if (null != objUnitShippersType.getTestTrackDate()) {
                    	 objShippersVO.setTestTrackDate(objUnitShippersType.getTestTrackDate());
                     }

              } else {
                     if (null != objUnitShippersType.getTestTrackDate()) {
                    	 shipTrackDate = RMDCommonUtility.stringToUSESTDate(
                            		objUnitShippersType.getTestTrackDate(),
                                          RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
                    	 objShippersVO.setTestTrackDate(nonESTZoneFormat.format(shipTrackDate));
                     }
              }
					
					arlLastShippedUnits.add(objShippersVO);
				}
				
			}
			arrUnitShippersType=null;
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getLastShippedUnits method  method of UnitShipperServiceImpl ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlLastShippedUnits;
	}

	/**
	 * @Author :
	 * @return :String
	 * @param :List<UnitShippersVO> arlShipperUnits
	 * @throws :RMDWebException
	 * @Description: This Method is used to update the shipped units.
	 * 
	 */

	public String updateUnitsToBeShipped(List<UnitShippersVO> arlShipperUnits,
			String timeZone) throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<UnitShippersRequestType> arlUnitsTobeShipped = new ArrayList<UnitShippersRequestType>();
		UnitShippersRequestType objShippersReqType = new UnitShippersRequestType();
		DateFormat formatter = new SimpleDateFormat(
				AppConstants.UTC_DATE_FORMAT);
		try {
			TimeZone tZone = TimeZone.getTimeZone(timeZone);
			formatter.setTimeZone(tZone);
			for (UnitShippersVO objUnitShippersVO : arlShipperUnits) {
				UnitShippersRequestType objShippersRequestType = new UnitShippersRequestType();
				if (!RMDCommonUtility.isNullOrEmpty(objUnitShippersVO
						.getObjId())) {
					objShippersRequestType.setObjId(objUnitShippersVO
							.getObjId());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objUnitShippersVO
						.getTestTrackDate())) {
					Date tesTrackDate = (Date) formatter
							.parse(objUnitShippersVO.getTestTrackDate());
					objShippersRequestType.setTestTrackDate(RMDCommonUtility
							.convertDateToXMLGregorianCalender(tesTrackDate,
									timeZone));
				}
				if (!RMDCommonUtility.isNullOrEmpty(objUnitShippersVO
						.getShipDate())) {
					Date shipDate = (Date) formatter.parse(objUnitShippersVO
							.getShipDate());
					objShippersRequestType.setShipDate(RMDCommonUtility
							.convertDateToXMLGregorianCalender(shipDate,
									timeZone));
				}
				arlUnitsTobeShipped.add(objShippersRequestType);
			}
			objShippersReqType.setArlUnitShipperReqType(arlUnitsTobeShipped);
			status = (String) webServiceInvoker.post(
					ServiceConstants.UPDATE_UNITS_TO_BE_SHIPPED,
					objShippersReqType, String.class);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("Exception occured in updateUnitsToBeShipped method  method of UnitShipperServiceImpl ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return status;
	}

	/**
	 * This method will call web-service to return list of asset numbers for
	 * given keys like customerId, assetGroup and assetnumber
	 */
	@Override
	public List<String> getAssetNumbersForShipUnits(AssetBean assetBean) throws RMDWebException,
			Exception {

		AssetNumberResponseType[] assetResponses = null;
		List<String> assetNumbers = new ArrayList<String>();
		final Map<String, String> headerParams = getHeaderMap(assetBean);
		try {
			AssetsRequestType objAssetsReqType=new AssetsRequestType();
			objAssetsReqType.setLanguage(headerParams.get(AppConstants.USER_LANGUAGE));
			objAssetsReqType.setCustomerId(assetBean.getCustomerId());
			objAssetsReqType.setAssetNumberLike(assetBean.getAssetNumber());
			objAssetsReqType.setFleetId(assetBean.getFleetId());
			if(null!=assetBean.getAssetGroup()&&!assetBean.getAssetGroup().equals(RMDCommonConstants.EMPTY_STRING)){
				objAssetsReqType.setAssetGrpName(assetBean.getAssetGroup());
			}
			assetResponses = (AssetNumberResponseType[])webServiceInvoker
					.post(ServiceConstants.GET_ASSET_NUMBERS_FOR_SHIP_UNITS, objAssetsReqType, AssetNumberResponseType[].class);
            if(assetResponses!=null&&assetResponses.length>0){
            	assetNumbers = new ArrayList<String>(assetResponses.length);
			for (int i = 0; i < assetResponses.length; i++) {
				assetNumbers.add(assetResponses[i].getAssetNumber() + "");
			}
           }
		assetResponses=null;
		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				rmdWebLogger
						.error("unitShippertCaseServiceImpl :: No records found for getAssetNumbersForShipUnits() service "
								+ e.getMessage());
				assetResponses = null;
			} else {
				rmdWebLogger
						.error("unitShippertCaseServiceImpls :: Exception occured in getAssetNumbersForShipUnits() method "
								+ e.getMessage());
				throw e;
			}
		} catch (Exception e) {
			rmdWebLogger.error("Exception occured in getAssetNumbersForShipUnits method ", e);
			throw e;
		}
		return assetNumbers;
	}
	@Override
	public Future<List<ShipUnitDataVO>> getShipUnitDetails() throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		UnitShippersResponseType[] unitShippersResponseType = null;
		List<ShipUnitDataVO> openCommList = new ArrayList<ShipUnitDataVO>();
		ShipUnitDataVO shipData = null;
		try {
			unitShippersResponseType = (UnitShippersResponseType[]) webServiceInvoker.get(
					ServiceConstants.GET_SHIP_UNIT_DETAILS, null, queryParams,
					null, UnitShippersResponseType[].class);
			if (null != unitShippersResponseType
					&& unitShippersResponseType.length > 0) {
				for (UnitShippersResponseType objUnitShippersResponseType : unitShippersResponseType) {
					shipData = new ShipUnitDataVO();
					shipData.setRoadNumberHeader(objUnitShippersResponseType.getRnh());
					shipData.setRoadNumber(objUnitShippersResponseType.getRoadNumber());
					shipData.setShipDate(objUnitShippersResponseType.getShipDate());
					openCommList.add(shipData);
				}
			}
			unitShippersResponseType = null;
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getShipUnitDetails() method of UnitShipperService.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return new AsyncResult<List<ShipUnitDataVO>>(openCommList);
	}

	@Override
	public Future<List<InfancyUnitBean>> getInfancyFailureDetails()
			throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		UnitShippersResponseType[] unitShippersResponseType = null;
		List<InfancyUnitBean> infancyUnitList = new ArrayList<InfancyUnitBean>();
		InfancyUnitBean infancyUnit = null;
		try {
			unitShippersResponseType = (UnitShippersResponseType[]) webServiceInvoker.get(
					ServiceConstants.GET_INFANCY_FAILURE_UNITS, null, queryParams,
					null, UnitShippersResponseType[].class);
			if (null != unitShippersResponseType
					&& unitShippersResponseType.length > 0) {
				for (UnitShippersResponseType objUnitShippersResponseType : unitShippersResponseType) {
					infancyUnit = new InfancyUnitBean();
					infancyUnit.setRoadNumberHeader(objUnitShippersResponseType.getRnh());
					infancyUnit.setRoadNumber(objUnitShippersResponseType.getRoadNumber());
					infancyUnit.setShipDate(objUnitShippersResponseType.getShipDate());
					infancyUnit.setCode(objUnitShippersResponseType.getCode());
					infancyUnit.setComment(objUnitShippersResponseType.getComment());
					infancyUnitList.add(infancyUnit);
				}
			}
			unitShippersResponseType = null;
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getInfancyFailureDetails() method of UnitShipperService.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return new AsyncResult<List<InfancyUnitBean>>(infancyUnitList);
	}
}
