package com.ge.trans.rmd.cm.beans;

import com.ge.trans.rmd.common.beans.RMDBaseBean;

public class KPIBean extends RMDBaseBean{
	private String customerId;
	private String kpiName;
	private long numDays;
	private String assetNumber;
	private String assetGroupName;
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getKpiName() {
		return kpiName;
	}
	public void setKpiName(String kpiName) {
		this.kpiName = kpiName;
	}
	public long getNumDays() {
		return numDays;
	}
	public void setNumDays(long numDays) {
		this.numDays = numDays;
	}
	public String getAssetNumber() {
		return assetNumber;
	}
	public void setAssetNumber(String assetNumber) {
		this.assetNumber = assetNumber;
	}
	public String getAssetGroupName() {
		return assetGroupName;
	}
	public void setAssetGroupName(String assetGroupName) {
		this.assetGroupName = assetGroupName;
	}

}
