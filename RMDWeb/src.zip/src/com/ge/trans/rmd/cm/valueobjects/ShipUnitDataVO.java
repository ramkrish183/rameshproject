package com.ge.trans.rmd.cm.valueobjects;

public class ShipUnitDataVO {
	
	private String roadNumberHeader;
	private String roadNumber;
	private String shipDate;
	public String getRoadNumberHeader() {
		return roadNumberHeader;
	}
	public void setRoadNumberHeader(String roadNumberHeader) {
		this.roadNumberHeader = roadNumberHeader;
	}
	public String getRoadNumber() {
		return roadNumber;
	}
	public void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}
	public String getShipDate() {
		return shipDate;
	}
	public void setShipDate(String shipDate) {
		this.shipDate = shipDate;
	}


}
