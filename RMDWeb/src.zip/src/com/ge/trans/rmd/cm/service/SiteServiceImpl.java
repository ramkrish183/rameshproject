package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.ContactSiteDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.SiteSearchVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ContactDetailsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.SiteDetailsRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.SiteDetailsResponseType;

@Service
public class SiteServiceImpl extends RMDBaseServiceImpl implements SiteService {

    private final RMDWebLogger rmdWebLogger = RMDWebLogger
            .getLogger(getClass());
    @Autowired
    WebServiceInvoker webServiceInvoker;
    @Autowired
    private CachedService cachedService;

    /**
     * @return Map<String, String>
     * @throws RMDWebException
     * @Description * This method is used to fetch the values from lookup table
     *              to populate the Site Type dropdown.
     */
    @Override
    public List<String> getSiteTypes() throws RMDWebException {
        List<String> allSiteTypes = new ArrayList<String>();
        try {
            allSiteTypes = getData(AppConstants.SITE_TYPES);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getSiteTypes method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return allSiteTypes;
    }

    /**
     * 
     * @param
     * @return List<SiteSearchVO>
     * @throws Exception
     * @Description * This method is used to get the Sites.
     * 
     */
    @Override
    public List<SiteSearchVO> getSites(SiteSearchVO objSiteVO)
            throws RMDWebException {
        List<SiteSearchVO> objSiteSearchVOlst = new ArrayList<SiteSearchVO>();
        SiteDetailsRequestType objSiteDetailsRequestType = new SiteDetailsRequestType();
        SiteDetailsResponseType[] objSiteDetailsResponseType = null;
        SiteSearchVO objSiteSearchVO = null;
        try {
            objSiteDetailsRequestType.setStrType(objSiteVO.getStrType());
            objSiteDetailsRequestType.setStrSiteID(objSiteVO.getStrSiteID());
            objSiteDetailsRequestType
                    .setStrSiteName(objSiteVO.getStrSiteName());
            objSiteDetailsRequestType.setStrAddress(objSiteVO.getStrAddress());
            objSiteDetailsRequestType.setStrCity(objSiteVO.getStrCity());
            objSiteDetailsRequestType.setStrState(objSiteVO.getStrState());
            objSiteDetailsRequestType.setStrAccountID(objSiteVO
                    .getStrAccountID());
            objSiteDetailsRequestType.setStrAccountName(objSiteVO
                    .getStrAccountName());
            objSiteDetailsRequestType.setStrInclInactiveContacts(objSiteVO
                    .getStrInclInactiveContacts());

            // Call web service for find cases
            objSiteDetailsResponseType = (SiteDetailsResponseType[]) webServiceInvoker
                    .post(ServiceConstants.GET_SITES,
                            objSiteDetailsRequestType,
                            SiteDetailsResponseType[].class);

            if (null != objSiteDetailsResponseType) {
                objSiteSearchVOlst = new ArrayList<SiteSearchVO>(
                        objSiteDetailsResponseType.length);
                for (SiteDetailsResponseType objFindCasesDtlsResponseType : objSiteDetailsResponseType) {
                    objSiteSearchVO = new SiteSearchVO();
                    objSiteSearchVO.setStrSiteID(objFindCasesDtlsResponseType
                            .getStrSiteID());
                    objSiteSearchVO.setStrSiteName(objFindCasesDtlsResponseType
                            .getStrSiteName());
                    objSiteSearchVO.setStrAddress(objFindCasesDtlsResponseType
                            .getStrAddress());
                    objSiteSearchVO
                            .setStrAddressEx(objFindCasesDtlsResponseType
                                    .getStrAddressEx());
                    objSiteSearchVO.setStrCity(objFindCasesDtlsResponseType
                            .getStrCity());
                    objSiteSearchVO.setStrState(objFindCasesDtlsResponseType
                            .getStrState());
                    objSiteSearchVO.setStrType(objFindCasesDtlsResponseType
                            .getStrType());
                    objSiteSearchVO
                            .setStrSiteObjId(objFindCasesDtlsResponseType
                                    .getStrSiteObjId());
                    objSiteSearchVO.setStrCountry(objFindCasesDtlsResponseType
                            .getStrCountry());
                    objSiteSearchVO.setStrZipCode(objFindCasesDtlsResponseType
                            .getStrZipCode());
                    objSiteSearchVOlst.add(objSiteSearchVO);
                }
            }
            objSiteDetailsResponseType = null;
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getSites method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return objSiteSearchVOlst;
    }

    /**
     * @Author :
     * @return :SiteSearchVO
     * @param :String siteObjId
     * @throws :RMDWebException
     * @Description:This method is used to get View Site Details.
     */
    @Override
    public SiteSearchVO viewSiteDetails(String siteObjId)
            throws RMDWebException {
        final Map<String, String> queryParams = new LinkedHashMap<String, String>(
                1);
        SiteSearchVO objSiteSearchVO = null;
        SiteDetailsResponseType objSiteDetailsResponseType = new SiteDetailsResponseType();
        List<ContactDetailsResponseType> listContactDetailsResponseType = null;
        ListIterator<ContactDetailsResponseType> listIterator = null;
        List<ContactSiteDetailsVO> listContactSiteDetailsVO = new ArrayList<ContactSiteDetailsVO>();
        try {
            queryParams.put(AppConstants.SITE_OBJID, siteObjId);
            objSiteDetailsResponseType = (SiteDetailsResponseType) webServiceInvoker
                    .get(ServiceConstants.VIEW_SITE_DETAILS, null, queryParams,
                            null, SiteDetailsResponseType.class);
            if (null != objSiteDetailsResponseType) {
                objSiteSearchVO = new SiteSearchVO();
                objSiteSearchVO.setStrSiteObjId(objSiteDetailsResponseType
                        .getStrSiteObjId());
                objSiteSearchVO.setPrimAddObjId(objSiteDetailsResponseType
                        .getPrimAddObjId());
                objSiteSearchVO.setShipAddObjId(objSiteDetailsResponseType
                        .getShipAddObjId());
                objSiteSearchVO.setBillAddObjId(objSiteDetailsResponseType
                        .getBillAddObjId());
                objSiteSearchVO.setStrSiteID(objSiteDetailsResponseType
                        .getStrSiteID());
                objSiteSearchVO.setStrSiteName(objSiteDetailsResponseType
                        .getStrSiteName());
                objSiteSearchVO.setStrStatus(objSiteDetailsResponseType
                        .getStrStatus());
                objSiteSearchVO.setStrCreateType(objSiteDetailsResponseType
                        .getStrCreateType());
                objSiteSearchVO.setStrAddress(objSiteDetailsResponseType
                        .getStrAddress());
                objSiteSearchVO.setStrBillTo(objSiteDetailsResponseType
                        .getStrBillTo());
                objSiteSearchVO.setStrShipTo(objSiteDetailsResponseType
                        .getStrShipTo());
                objSiteSearchVO.setStrAddressEx(objSiteDetailsResponseType
                        .getStrAddressEx());
                objSiteSearchVO.setStrBillToEx(objSiteDetailsResponseType
                        .getStrBillToEx());
                objSiteSearchVO.setStrShipToEx(objSiteDetailsResponseType
                        .getStrShipToEx());
                objSiteSearchVO.setStrCellPhone(objSiteDetailsResponseType
                        .getStrCellPhone());
                objSiteSearchVO.setStrFax(objSiteDetailsResponseType
                        .getStrFax());
                objSiteSearchVO.setStrPrefShipMethod(objSiteDetailsResponseType
                        .getStrPrefShipMethod());
                objSiteSearchVO.setStrCustomer(objSiteDetailsResponseType
                        .getStrCustomer());
                if (objSiteDetailsResponseType.getContactDetailsResponseType() != null
                        && !objSiteDetailsResponseType
                                .getContactDetailsResponseType().isEmpty()) {
                    listContactDetailsResponseType = objSiteDetailsResponseType
                            .getContactDetailsResponseType();
                    listIterator = listContactDetailsResponseType
                            .listIterator();
                    while (listIterator.hasNext()) {
                        final ContactSiteDetailsVO contactSiteDetailsVO = new ContactSiteDetailsVO();
                        ContactDetailsResponseType contactDetailsResponseType = new ContactDetailsResponseType();
                        contactDetailsResponseType = listIterator.next();
                        contactSiteDetailsVO
                                .setContactObjId(contactDetailsResponseType
                                        .getContactObjId());
                        contactSiteDetailsVO
                                .setLocObjId(contactDetailsResponseType
                                        .getSiteObjId());
                        contactSiteDetailsVO
                                .setFirstName(contactDetailsResponseType
                                        .getFirstName());
                        contactSiteDetailsVO
                                .setLastName(contactDetailsResponseType
                                        .getLastName());
                        contactSiteDetailsVO.setPhNo(contactDetailsResponseType
                                .getPhNo());
                        contactSiteDetailsVO.setFax(contactDetailsResponseType
                                .getFax());
                        contactSiteDetailsVO
                                .setEmailId(contactDetailsResponseType
                                        .getEmailId());
                        listContactSiteDetailsVO.add(contactSiteDetailsVO);
                    }
                    objSiteSearchVO
                            .setArlContactSiteDetailsVO(listContactSiteDetailsVO);
                }
            }
            objSiteDetailsResponseType = null;
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in viewSiteDetails method ",
                    ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return objSiteSearchVO;
    }

    /**
     * 
     * @param SiteSearchVO
     *            objSiteVO
     * @return String
     * @throws Exception
     * @Description * This method is used to Update the Site.
     * 
     */
    @Override
    public String updateSite(SiteSearchVO objSiteVO) throws RMDWebException {
        SiteDetailsRequestType objSiteDetailsRequestType = new SiteDetailsRequestType();
        String strResult = null;
        try {
            objSiteDetailsRequestType.setStrSiteObjId(objSiteVO
                    .getStrSiteObjId());
            objSiteDetailsRequestType.setPrimAddObjId(objSiteVO
                    .getPrimAddObjId());
            objSiteDetailsRequestType.setShipAddObjId(objSiteVO
                    .getShipAddObjId());
            objSiteDetailsRequestType.setBillAddObjId(objSiteVO
                    .getBillAddObjId());
            objSiteDetailsRequestType.setStrCreateType(objSiteVO
                    .getStrCreateType());
            objSiteDetailsRequestType.setStrStatus(objSiteVO.getStrStatus());
            objSiteDetailsRequestType.setStrPrefShipMethod(objSiteVO
                    .getStrPrefShipMethod());
            objSiteDetailsRequestType
                    .setStrCustomer(objSiteVO.getStrCustomer());
            objSiteDetailsRequestType.setStrSiteID(objSiteVO.getStrSiteID());
            objSiteDetailsRequestType
                    .setStrSiteName(objSiteVO.getStrSiteName());
            objSiteDetailsRequestType.setStrCellPhone(objSiteVO
                    .getStrCellPhone());
            objSiteDetailsRequestType.setStrFax(objSiteVO.getStrFax());

            // Call web service for find cases
            strResult = (String) webServiceInvoker.post(
                    ServiceConstants.UPDATE_SITE, objSiteDetailsRequestType,
                    String.class);

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in updateSite method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return strResult;

    }

    /**
     * 
     * @param SiteSearchVO
     *            objSiteVO
     * @return String
     * @throws Exception
     * @Description * This method is used to create the Site.
     * 
     */
    @Override
    public String createSite(SiteSearchVO objSiteVO) throws RMDWebException {
        SiteDetailsRequestType objSiteDetailsRequestType = new SiteDetailsRequestType();
        String strResult = null;
        try {
            objSiteDetailsRequestType.setStrCreateType(objSiteVO
                    .getStrCreateType());
            objSiteDetailsRequestType.setStrStatus(objSiteVO.getStrStatus());
            objSiteDetailsRequestType.setStrPrefShipMethod(objSiteVO
                    .getStrPrefShipMethod());
            objSiteDetailsRequestType
                    .setStrCustomer(objSiteVO.getStrCustomer());
            objSiteDetailsRequestType.setStrSiteID(objSiteVO.getStrSiteID());
            objSiteDetailsRequestType
                    .setStrSiteName(objSiteVO.getStrSiteName());
            objSiteDetailsRequestType.setPrimAddObjId(objSiteVO
                    .getPrimAddObjId());
            objSiteDetailsRequestType.setShipAddObjId(objSiteVO
                    .getShipAddObjId());
            objSiteDetailsRequestType.setBillAddObjId(objSiteVO
                    .getBillAddObjId());
            objSiteDetailsRequestType.setStrCellPhone(objSiteVO
                    .getStrCellPhone());
            objSiteDetailsRequestType.setStrFax(objSiteVO.getStrFax());

            // Call web service for find cases
            strResult = (String) webServiceInvoker.post(
                    ServiceConstants.CREATE_SITE, objSiteDetailsRequestType,
                    String.class);

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in createSite method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return strResult;

    }

    /**
     * @return Map<String, Map<String, String>>
     * @throws RMDWebException
     * @Description * This method is used to fetch the values from lookup table
     *              to populate the Site Shipping,Site Status & SiteEdit Types
     *              dropdown.
     */
    @Override
    public Map<String, List<String>> getPopulateData() throws RMDWebException {
        Map<String, List<String>> allSiteStatus = new LinkedHashMap<String, List<String>>();
        List<String> getSiteEditTypes = new ArrayList<String>();
        List<String> getSiteStatus = new ArrayList<String>();
        List<String> getSiteShipping = new ArrayList<String>();
        getSiteEditTypes = getData(AppConstants.SITE_EDIT_NEW_TYPES);
        getSiteStatus = getData(AppConstants.SITE_STATUS);
        getSiteShipping = getData(AppConstants.SITE_SHIPPING_DETAILS);
        Collections.sort(getSiteShipping);
        allSiteStatus.put(AppConstants.SITE_EDIT_NEW_TYPES, getSiteEditTypes);
        allSiteStatus.put(AppConstants.SITE_STATUS, getSiteStatus);
        allSiteStatus.put(AppConstants.SITE_SHIPPING_DETAILS, getSiteShipping);
        return allSiteStatus;
    }

    public List<String> getData(String listName) throws RMDWebException {
        List<String> allSiteData = new ArrayList<String>();
        try {
            List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService
                    .getAllLookupValues().get(listName);
            if (applParamResponseTypeList != null
                    && applParamResponseTypeList.size() > 0) {
                for (ApplicationParametersResponseType objResponse : applParamResponseTypeList) {
                    allSiteData.add(objResponse.getLookupValue());
                }
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getData method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return allSiteData;
    }
}
