package com.ge.trans.rmd.cm.service;


import com.ge.trans.rmd.cm.valueobjects.HeatMapResponseVO;
import com.ge.trans.rmd.cm.valueobjects.HeatMapSearchVO;
import com.ge.trans.rmd.common.exception.RMDWebException;


/**
 * @author 212338353
 *
 */
public interface HeatMapService {
    /**
     * To populate models based on customer
     * @param heatmapSearchVO
     * @return
     * @throws RMDWebException
     */
    public HeatMapResponseVO getHeatMapModels(HeatMapSearchVO heatmapSearchVO)
            throws RMDWebException;
    /**
     *  To populate asset headers based on model & customer
     * @param heatmapSearchVO
     * @return
     * @throws RMDWebException
     */
    public HeatMapResponseVO getHeatMapAssetNumbers(HeatMapSearchVO heatmapSearchVO)
            throws RMDWebException;
    /**
     * To populate asset numbers based on model & customer
     * @param heatmapSearchVO
     * @return
     * @throws RMDWebException
     */
    public HeatMapResponseVO getHeatMapAssetHeaders(HeatMapSearchVO heatmapSearchVO)
            throws RMDWebException;
    /**
     * To populate fault based on model,customer & days or date
     * @param heatmapSearchVO
     * @return
     * @throws RMDWebException
     */
    public HeatMapResponseVO getHeatMapFaults(HeatMapSearchVO heatmapSearchVO)
            throws RMDWebException;
    /**
     * To populate fault along with lat/long based on model,customer,fault & days or date 
     * @param heatmapSearchVO
     * @param timeZone
     * @return
     * @throws RMDWebException
     * @throws Exception
     */
    public HeatMapResponseVO getHeatMapFilterResults(HeatMapSearchVO heatmapSearchVO,String timeZone)
            throws RMDWebException;
            
			
}
