package com.ge.trans.rmd.cm.valueobjects;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.trans.rmd.common.vo.RMDBaseVO;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class CasesHeaderVO extends RMDBaseVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String assetNumber; 
	private String customerName;
	private String strGrpName;
	private String caseID;
	
	
	
	
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	public String getAssetNumber() {
		return assetNumber;
	}
	public void setAssetNumber(final String assetNumber) {
		this.assetNumber = assetNumber;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(final String customerName) {
		this.customerName = customerName;
	}
	public String getStrGrpName() {
		return strGrpName;
	}
	public void setStrGrpName(final String strGrpName) {
		this.strGrpName = strGrpName;
	}


	public String getCaseID() {
		return caseID;
	}


	public void setCaseID(String caseID) {
		this.caseID = caseID;
	}
	
	
	
}
