package com.ge.trans.rmd.cm.valueobjects;

public class ConfigTemplateDetailsVO extends AssetsVO{

	private String tempObjId;
	private String templateNo;
	private String versionNo;
	private String title;
	private String status;
	private String offBoardStatus;
	private String onBoardStatus;
	private String controllerId;
	private String controllerConfig;
	private String configFile;
	private String onBoardStatusDate;
	private String offBoardStatusDate;

	public String getTempObjId() {
		return this.tempObjId;
	}

	public void setTempObjId(String tempObjId) {
		this.tempObjId = tempObjId;
	}

	public String getTemplateNo() {
		return this.templateNo;
	}

	public void setTemplateNo(String templateNo) {
		this.templateNo = templateNo;
	}

	public String getVersionNo() {
		return this.versionNo;
	}

	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the offBoardStatus
	 */
	public final String getOffBoardStatus() {
		return offBoardStatus;
	}

	/**
	 * @param offBoardStatus the offBoardStatus to set
	 */
	public final void setOffBoardStatus(String offBoardStatus) {
		this.offBoardStatus = offBoardStatus;
	}

	/**
	 * @return the onBoardStatus
	 */
	public final String getOnBoardStatus() {
		return onBoardStatus;
	}

	/**
	 * @param onBoardStatus the onBoardStatus to set
	 */
	public final void setOnBoardStatus(String onBoardStatus) {
		this.onBoardStatus = onBoardStatus;
	}

	/**
	 * @return the controllerId
	 */
	public final String getControllerId() {
		return controllerId;
	}

	/**
	 * @param controllerId the controllerId to set
	 */
	public final void setControllerId(String controllerId) {
		this.controllerId = controllerId;
	}

	/**
	 * @return the controllerConfig
	 */
	public final String getControllerConfig() {
		return controllerConfig;
	}

	/**
	 * @param controllerConfig the controllerConfig to set
	 */
	public final void setControllerConfig(String controllerConfig) {
		this.controllerConfig = controllerConfig;
	}

	/**
	 * @return the configFile
	 */
	public final String getConfigFile() {
		return configFile;
	}

	/**
	 * @param configFile the configFile to set
	 */
	public final void setConfigFile(String configFile) {
		this.configFile = configFile;
	}

	/**
	 * @return the onBoardStatusDate
	 */
	public final String getOnBoardStatusDate() {
		return onBoardStatusDate;
	}

	/**
	 * @param onBoardStatusDate the onBoardStatusDate to set
	 */
	public final void setOnBoardStatusDate(String onBoardStatusDate) {
		this.onBoardStatusDate = onBoardStatusDate;
	}

	/**
	 * @return the offBoardStatusDate
	 */
	public final String getOffBoardStatusDate() {
		return offBoardStatusDate;
	}

	/**
	 * @param offBoardStatusDate the offBoardStatusDate to set
	 */
	public final void setOffBoardStatusDate(String offBoardStatusDate) {
		this.offBoardStatusDate = offBoardStatusDate;
	}
	
}
