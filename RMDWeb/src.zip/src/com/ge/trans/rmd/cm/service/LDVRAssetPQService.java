package com.ge.trans.rmd.cm.service;

import java.util.List;

import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.pp.beans.AssetBean;

public interface LDVRAssetPQService {
    /**
     * 
     * @param assetBean
     * @return
     * @throws RMDWebException
     */
    public List<String> getAssetProducts(AssetBean assetBean)
            throws RMDWebException;
    /**
     * 
     * @param assetBean
     * @return
     * @throws RMDWebException
     */
    public List<String> getAssetsProductList(AssetBean assetBean)
            throws RMDWebException;

}