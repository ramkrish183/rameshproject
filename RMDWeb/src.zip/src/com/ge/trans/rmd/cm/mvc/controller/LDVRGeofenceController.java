package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.type.TypeFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.LDVRGeofenceService;
import com.ge.trans.rmd.cm.valueobjects.LDVRGeofenceRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRGeofenceResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRGeofenceVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRSaveGeofenceRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRSaveGeofenceResponseVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
@Controller
@SessionAttributes
public class LDVRGeofenceController extends RMDBaseController {
	private final  RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private LDVRGeofenceService ldvrGeofenceService;
	
	@Autowired
	private AuthorizationService authorizationService;
	
	@Autowired
	private ApplicationContext appContext;
	
	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description: To get the Goefence page on click of sub tab
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_GEOFENCE, method = RequestMethod.GET)
	public ModelAndView getLDVRGeofencePage(final HttpServletRequest request)
			throws RMDWebException {
		rmdWebLogger.info("Inside getLDVRGeofence method");
		final String strAssetNumber = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String strAssetGroup = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_GROUP_NAME));
		final String strCustomerId = getCustomerId(request);
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String userName = userVO.getUserId();
		
		
		request.setAttribute(AppConstants.REQ_PARAM_ASSTNUM, strAssetNumber);
		request.setAttribute(AppConstants.ASSET_GROUP_NAME, strAssetGroup);
		request.setAttribute(AppConstants.WS_PARAM_CUSTID, strCustomerId);
		request.setAttribute(AppConstants.USERNAME, userName);
		return new ModelAndView(AppConstants.VIEW_LDVR_GEOFENCE);	
	}

	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description:
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_GEOFENCE_LIST, method = RequestMethod.GET)
	public @ResponseBody LDVRGeofenceResponseVO getLDVRGeofenceList(final HttpServletRequest request) throws RMDWebException {
		
		rmdWebLogger.info("Inside getLDVRGeofenceList method");
	
		LDVRGeofenceRequestVO ldvrGeoZoneRequestVO = new LDVRGeofenceRequestVO();
		final String assetOwnerId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REQ_PARAM_CUSID));
		final String activeFlag = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.GEOFENCE_ACTIVE_FLG));
		final String geofenceName = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.GEOFENCE_NAME));
		ldvrGeoZoneRequestVO.setAssetOwnerId(assetOwnerId);
		ldvrGeoZoneRequestVO.setActiveFlag(activeFlag);
		ldvrGeoZoneRequestVO.setGeofenceName(geofenceName);
		rmdWebLogger.info("Inputis : "+ldvrGeoZoneRequestVO.toString());
		LDVRGeofenceResponseVO ldvrGeofenceResponseVO = null;
		try {	
			ldvrGeofenceResponseVO = ldvrGeofenceService.getLDVRGeoZones(ldvrGeoZoneRequestVO);
		} catch (RMDWebException ex) {
			rmdWebLogger.error(
					"RMDWebException occured in getLDVRGeofenceList  method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLDVRGeofenceList  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return ldvrGeofenceResponseVO;
	}
	
	
	
	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description:
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_SAVE_UPDATE_LDVR_GEOFENCE, method = RequestMethod.POST)
	public @ResponseBody LDVRSaveGeofenceResponseVO saveUpdateLDVRGeofence(final HttpServletRequest request) throws RMDWebException {
		
		rmdWebLogger.info("Inside saveUpdateLDVRGeofence method");
		
		String geofenceList = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.GEOFENCELIST));
		ObjectMapper mapper = new ObjectMapper();
		rmdWebLogger.info("THIS IS JSON FROM BROWSER"+geofenceList);
		LDVRSaveGeofenceResponseVO ldvrSaveGeofenceResponseVO = null;
		try {	
			List<LDVRSaveGeofenceRequestVO> ldvrSaveGeofenceRequestVOs = mapper.readValue(geofenceList, TypeFactory.defaultInstance().constructCollectionType(List.class, LDVRSaveGeofenceRequestVO.class));
			ldvrSaveGeofenceResponseVO = ldvrGeofenceService.saveUpdateLDVRGeoZones(ldvrSaveGeofenceRequestVOs);
		} catch (RMDWebException ex) {
			rmdWebLogger.error(
					"RMDWebException occured in saveUpdateLDVRGeofence  method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in saveUpdateLDVRGeofence  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return ldvrSaveGeofenceResponseVO;
	}
	
	/**
	* @param request
	* @param customerIdList
	*/
	private String getCustomerId(final HttpServletRequest request) {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String customerId;
		if (userVO.getCustomerId() != null && !userVO.getCustomerId().isEmpty()) {
			customerId = userVO.getCustomerId();
		} else {
			customerId = RMDCommonConstants.ALL_CUSTOMER;
		}
		return customerId;
	}
	
	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description:
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_UPDATE_GEOFENCE_STATUS, method = RequestMethod.POST)
	public @ResponseBody LDVRSaveGeofenceResponseVO updateGeofenceStatus(final HttpServletRequest request) throws RMDWebException {
		
		rmdWebLogger.info("Inside updateGeofenceStatus method");
		String geofenceList = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.GEOFENCELIST));
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		rmdWebLogger.info("THIS IS JSON FROM BROWSER"+geofenceList);
		LDVRSaveGeofenceResponseVO ldvrSaveGeofenceResponseVO = null;
		try {	
			List<LDVRSaveGeofenceRequestVO> ldvrSaveGeofenceRequestVOs = mapper.readValue(geofenceList, TypeFactory.defaultInstance().constructCollectionType(List.class, LDVRSaveGeofenceRequestVO.class));
			rmdWebLogger.info("Inputis : " + ldvrSaveGeofenceRequestVOs.size());
			ldvrSaveGeofenceResponseVO = ldvrGeofenceService.saveUpdateLDVRGeoZones(ldvrSaveGeofenceRequestVOs);
		} catch (RMDWebException ex) {
			rmdWebLogger.error(
					"RMDWebException occured in updateGeofenceStatus  method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in updateGeofenceStatus  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return ldvrSaveGeofenceResponseVO;
	}
	
	
	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description:
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_IMPORT_GEOFENCE, method = RequestMethod.POST)
	public void importGeofence(final HttpServletRequest request,final HttpServletResponse response, @RequestParam("file") MultipartFile file, @RequestParam("userNamef") String userName,@RequestParam("customerId") String customerId) throws RMDWebException {
		
		rmdWebLogger.info("Inside importGeofence method");
		response.setContentType("text/html");
		PrintWriter out = null;
		BufferedOutputStream stream = null;
		FileOutputStream oStream = null;
		File serverFile = null;
		try {	
			out = response.getWriter();	
			if (!file.isEmpty()) {
                byte[] bytes = file.getBytes();
                String rootPath = EsapiUtil.stripXSSCharacters(System
                        .getProperty("catalina.home"));
					File dir = new File(rootPath + File.separator + "tmp"+File.separator+"tmpFiles");
					if (!dir.exists())
						dir.mkdirs();
					serverFile = new File(dir.getAbsolutePath()
							+ File.separator + System.currentTimeMillis()+"_"+file.getOriginalFilename());
					oStream = 	new FileOutputStream(serverFile);
					stream = new BufferedOutputStream(oStream);
					stream.write(bytes);
					List<LDVRSaveGeofenceRequestVO> ldvrSaveGeofenceRequestVOs = ldvrGeofenceService.readXLS(serverFile, EsapiUtil.stripXSSCharacters(userName),EsapiUtil.stripXSSCharacters(customerId));
					LDVRSaveGeofenceResponseVO ldvrSaveGeofenceResponseVO = ldvrGeofenceService.saveUpdateLDVRGeoZones(ldvrSaveGeofenceRequestVOs);
					rmdWebLogger.info("Server File Location="+ serverFile.getAbsolutePath());
					out.print("<script>parent.$('body').trigger('uploadsuccess',{'status':'"+ldvrSaveGeofenceResponseVO.getStatus()+"','file':'"+file.getOriginalFilename()+"'});</script>");
			} else {
				rmdWebLogger.error("Uploaded file is empty");				
				RMDWebException ex = new RMDWebException();
				ex.setErrorMessageOnUI("empty file");
				throw ex;
			}
			
		} catch (RMDWebException ex) {
			rmdWebLogger.info(ex.getErrorType()+"  "+ex.getErrorMessageOnUI()+"  "+ex.getMessage());
			rmdWebLogger.error(
					"RMDWebException occured in importGeofence  method ", ex);
			out.print("<script>parent.$('body').trigger('uploadfail','"+ex.getErrorType()+"');</script>");
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in importGeofence  method ", ex);
			if(out != null)
			out.print("<script>parent.$('body').trigger('uploadfail','"+ex.getMessage()+"');</script>");
		} finally {
			try {
				if (stream != null){
				stream.close();
				}
				else
				if(oStream != null ){
				oStream.close();
				}
				else if(serverFile != null){
			
				serverFile.delete();
				}
			} catch (Exception ex) {
				rmdWebLogger.error(
						"Exception occured in getLDVRMessageHistory  method ", ex);
				RMDWebErrorHandler.handleException(ex);
			}

			
		}
	}
	
	/**
	 * @Author:
	 * @param:HttpServletRequest reques
	 * @return:List<CallLogVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for exporting call log notes to CSV
	 *               Format.
	 */

	@RequestMapping(AppConstants.EXPORT_LDVR_GEOFENCE)
	@ResponseBody public void exportLDVRGeofence(final HttpServletRequest request,final HttpServletResponse response,final Locale locale)
			throws RMDWebException, Exception {
		rmdWebLogger.info("Inside exportLDVRGeofence method");
		LDVRGeofenceResponseVO ldvrGeofenceResponseVO = null;
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		String customerList="";
		try {		
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			if (!RMDCommonUtility.isNullOrEmpty(userVO.getCustomerId())) {
				customerList = getCustomerList(userVO.getCustomerList());
				userVO.setCustomerId(customerList);
			}
			final String strAssetNumber =EsapiUtil.stripXSSCharacters( request
					.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
			ldvrGeofenceResponseVO = getLDVRGeofenceList(request);
			rmdWebLogger.info(" ldvrGeofenceResponseVO size..."+ldvrGeofenceResponseVO.getLdvrGeoZones().size());
			csvContent = convertToCSVMessageHistory(ldvrGeofenceResponseVO.getLdvrGeoZones(),strAssetNumber, locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.LDVR_GEOFENCE_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			rmdWebLogger.info("CSV Content"+csvContent);
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);
			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);
			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
			.error("Exception occured in exportLDVRMessageHistory method ", rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in exportLDVRMessageHistory method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		}
		finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}
		
	}
	
	/**
	 * @Description:This method is used convert Queue cases into csv format
	 * @return: String
	 * @param:List<QueueCaseVO> queuCasesList, Locale locale
	 */
	private String convertToCSVMessageHistory(List<LDVRGeofenceVO> ldvrGeofenceList,String strAssetNumber,
			Locale locale) {
		rmdWebLogger.info("Inside convertToCSVMessageHistory method");
		String csvContent = null;
		StringBuilder strBuilderAssetHeader = new StringBuilder();
		try {
			strBuilderAssetHeader.append(appContext.getMessage(
					AppConstants.LDVR_GEOFENCE_HEADER, null, locale));
			strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);
			for (LDVRGeofenceVO ldvrGeofenceVo : ldvrGeofenceList) {
				
						strBuilderAssetHeader
						.append(AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ ldvrGeofenceVo.getAssetOwnerId()
									+ AppConstants.QUOTE);
						
						strBuilderAssetHeader
						.append(RMDCommonConstants.COMMMA_SEPARATOR
								+ AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+ ldvrGeofenceVo.getGeozoneId()
								+ AppConstants.QUOTE);
						
						
						strBuilderAssetHeader
						.append(RMDCommonConstants.COMMMA_SEPARATOR
								+ AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+ ldvrGeofenceVo.getGeozoneName()
								+ AppConstants.QUOTE);
						
						
						strBuilderAssetHeader
						.append(RMDCommonConstants.COMMMA_SEPARATOR
								+ AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+ ldvrGeofenceVo.getLattitude1()
								+ AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE);
							
				
						strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ ldvrGeofenceVo.getLongitude1()
									+ AppConstants.QUOTE);
			
					
						strBuilderAssetHeader
						.append(RMDCommonConstants.COMMMA_SEPARATOR
								+ AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+ ldvrGeofenceVo.getLattitude3()
								+ AppConstants.QUOTE);
	
						strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ ldvrGeofenceVo.getLongitude3()
											+ AppConstants.QUOTE);		
						
						strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ ldvrGeofenceVo.getGeozoneStatus()
											+ AppConstants.QUOTE);		
										

				strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBuilderAssetHeader.toString();
		} catch (Exception exception) {
			rmdWebLogger.error("Export to CSV LDVR Geofence List", exception);
		}
		return csvContent;
	}
	@RequestMapping(AppConstants.DOWNLOAD_GEOZONE_IMPORT_FILE)
	@ResponseBody public void downloadGeozoneImportFile(final HttpServletRequest request,final HttpServletResponse response,final Locale locale)
			throws RMDWebException, Exception {
		
			String rootPath = System.getProperty("catalina.home");
			ServletOutputStream out = response.getOutputStream();
	        FileInputStream in = new FileInputStream(rootPath +File.separator + "appdata" +File.separator +AppConstants.LDVR_GEOZONE_DOWNLOAD_FILENAME);
	    	response.setContentType(AppConstants.CONTENT_TYPE);
			response.addHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.LDVR_GEOZONE_DOWNLOAD_FILENAME);
	        int octet;
	        while((octet = in.read()) != -1)
	            out.write(octet);

	        in.close();
	        out.close();
		
	}
}
