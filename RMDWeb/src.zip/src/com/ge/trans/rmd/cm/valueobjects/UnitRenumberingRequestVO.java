package com.ge.trans.rmd.cm.valueobjects;

public class UnitRenumberingRequestVO {
	protected int oldUnitNumber;
	protected int newUnitNumber;
	protected String vehicleHeader;
	
	public int getOldUnitNumber() {
		return oldUnitNumber;
	}
	public void setOldUnitNumber(int oldUnitNumber) {
		this.oldUnitNumber = oldUnitNumber;
	}
	public int getNewUnitNumber() {
		return newUnitNumber;
	}
	public void setNewUnitNumber(int newUnitNumber) {
		this.newUnitNumber = newUnitNumber;
	}
	public String getVehicleHeader() {
		return vehicleHeader;
	}
	public void setVehicleHeader(String vehicleHeader) {
		this.vehicleHeader = vehicleHeader;
	}
	
}
