package com.ge.trans.rmd.cm.valueobjects;

public class VisualizationMPParmNumVO {

	private String parmNumber;
	private String parmDescription;
	private String columnName;
	private String tableName;
	private String controllerCfg;
	private String parmDescriptionName;	
	
	public String getParmDescriptionName() {
		return parmDescriptionName;
	}
	public void setParmDescriptionName(String parmDescriptionName) {
		this.parmDescriptionName = parmDescriptionName;
	}
	public String getParmNumber() {
		return parmNumber;
	}
	public void setParmNumber(String parmNumber) {
		this.parmNumber = parmNumber;
	}
	public String getParmDescription() {
		return parmDescription;
	}
	public void setParmDescription(String parmDescription) {
		this.parmDescription = parmDescription;
	}
	public String getColumnName() {
		return columnName;
	}
	public void setColumnName(String columnName) {
		this.columnName = columnName;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getControllerCfg() {
		return controllerCfg;
	}
	public void setControllerCfg(String controllerCfg) {
		this.controllerCfg = controllerCfg;
	}
	
	
	
	
}
