package com.ge.trans.rmd.cm.service;

import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.xml.namespace.QName;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.mcs.Fault;
import com.ge.trans.rmd.cm.mcs.SendMultiDeviceMessageRequest;
import com.ge.trans.rmd.cm.mcs.SendMultiDeviceMessageResponse;
import com.ge.trans.rmd.cm.mcs.SendMultiDeviceMessageService;
import com.ge.trans.rmd.cm.mcs.SendMultiDeviceMessageServiceInterface;
import com.ge.trans.rmd.cm.mcs.assestmessagehistory.AssetCriteria;
import com.ge.trans.rmd.cm.mcs.assestmessagehistory.GroupMsgHistoryRequest;
import com.ge.trans.rmd.cm.mcs.assestmessagehistory.GroupMsgHistoryRequest.DateTimeFrom;
import com.ge.trans.rmd.cm.mcs.assestmessagehistory.GroupMsgHistoryRequest.DateTimeTo;
import com.ge.trans.rmd.cm.mcs.assestmessagehistory.Message;
import com.ge.trans.rmd.cm.mcs.assestmessagehistory.MessageCriteria;
import com.ge.trans.rmd.cm.mcs.assestmessagehistory.MessageHistoryResponse;
import com.ge.trans.rmd.cm.mcs.assestmessagehistory.MessageHistoryService;
import com.ge.trans.rmd.cm.mcs.assestmessagehistory.MessageHistoryServiceInterface;
import com.ge.trans.rmd.cm.valueobjects.HealthCheckAvailableVO;
import com.ge.trans.rmd.cm.valueobjects.HealthCheckFaultsDataVO;
import com.ge.trans.rmd.cm.valueobjects.HealthCheckSubmitVO;
import com.ge.trans.rmd.cm.valueobjects.HealthCheckVO;
import com.ge.trans.rmd.cm.valueobjects.MessageHistoryResponseVO;
import com.ge.trans.rmd.cm.valueobjects.RDRNotificationsResponseVO;
import com.ge.trans.rmd.cm.valueobjects.RDRNotificationsVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.pp.valueobjects.CustLookupVO;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.HcViewHistoryRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.HealthCheckAvailableResponse;
import com.ge.trans.rmd.services.assets.valueobjects.HealthCheckResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.HealthCheckSubmitRequest;
import com.ge.trans.rmd.services.assets.valueobjects.HealthCheckViewResponse;
import com.ge.trans.rmd.services.assets.valueobjects.RDRNotificationsSubmitRequest;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class HealthCheckServiceImpl extends RMDBaseServiceImpl implements
		HealthCheckService {
	private final RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	@Autowired
	WebServiceInvoker webServiceInvoker;
	@Value("${" + AppConstants.HEALH_CHECK_SEND_MESSAGE_SERVICE_URL + "}")
	String hcSendMessageServiceURL;
	@Value("${" + AppConstants.HC_CSX_SEND_MESSAGE_SERVICE_URL + "}")
	String hcCSXSendMessageServiceURL;
	@Value("${" + AppConstants.HEALH_CHECK_SEND_MESSAGE_SERVICE_USERNAME + "}")
	String hcSendMessageServiceUsername;
	@Value("${" + AppConstants.HEALH_CHECK_SEND_MESSAGE_SERVICE_PASSWORD + "}")
	String hcSendMessageServicePassowrd;
	@Value("${" + AppConstants.HEALH_CHECK_GET_MESSAGE_HISTORY_URL + "}")
	String viewMessageHistoryServiceURL;
	@Value("${" + AppConstants.CSX_VALID_HOSTS + "}")
	String csxValidHosts;	
	@Autowired
	private CachedService cachedService;
	public Map<String, String> getAssetHCMPGroups(String strAssetId,
			String strCustomerId, String strGrpName,String requestType,String assetType,String deviceName) throws RMDWebException,
			Exception {
		logger.debug("HealthCheckServiceImpl : Inside getAssetHCMPGroups() method:::::START");
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		HealthCheckResponseType[] arrHCResponseType = null;
		final Map<String, String> hcMPGroupMap = new HashMap<String, String>();
		try {
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTNUM, strAssetId);
			queryParamsMap.put(AppConstants.REQ_PARAM_CUSID, strCustomerId);
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTGRP, strGrpName);
			queryParamsMap.put(AppConstants.REQ_PARAM_REQTYPE_HC, requestType);
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSET_TYPE, assetType);
			queryParamsMap.put(AppConstants.REQ_PARAM_DEVICE_NAME, deviceName);
			arrHCResponseType = (HealthCheckResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_HC_MP_GROUPS, null,
							queryParamsMap, null,
							HealthCheckResponseType[].class);
			if (arrHCResponseType != null) {
				for (int i = 0; i < arrHCResponseType.length; i++) {
					hcMPGroupMap.put(arrHCResponseType[i].getMpNum(),
							arrHCResponseType[i].getMpName());
				}
			}

		} catch (Exception ex) {
			logger.error("Exception occured in getAssetHCMPGroups method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		logger.debug("HealthCheckServiceImpl : Inside getAssetHCMPGroups() method:::::END");
		return hcMPGroupMap;
	}
	/* (non-Javadoc)
	 * @see com.ge.trans.rmd.cm.service.HealthCheckService#IsHCAvailable(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public HealthCheckAvailableVO IsHCAvailable(String strAssetId, String strCustomerId,
			String strGrpName) throws RMDWebException, Exception {
		logger
				.debug("HealthCheckServiceImpl : Inside getIsHCAvailable() method::START");
		final Map<String, String> qParamMap = new LinkedHashMap<String, String>();
		HealthCheckAvailableResponse isHCAvailableResponse = null;
		HealthCheckAvailableVO result=new HealthCheckAvailableVO();
		try {
			qParamMap.put(AppConstants.REQ_PARAM_ASSTNUM, strAssetId);
			qParamMap.put(AppConstants.REQ_PARAM_CUSID, strCustomerId);
			qParamMap.put(AppConstants.REQ_PARAM_ASSTGRP, strGrpName);
			isHCAvailableResponse = (HealthCheckAvailableResponse) webServiceInvoker.get(
					ServiceConstants.IS_HC_AVAILABLE, null, qParamMap, null,
					HealthCheckAvailableResponse.class);
			result.setDefaultPlatform(isHCAvailableResponse.getDefaultPlatform());
			result.setPlatform(isHCAvailableResponse.getPlatform());
			result.setHcEnabled(isHCAvailableResponse.getStrHCMessage());

		} catch (Exception ex) {
			logger.error("Exception occured in getIsHCAvailable method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		logger
				.debug("HealthCheckServiceImpl : Inside getIsHCAvailable() method::END");

		return result;
	}

	// SOC - Raj.S(212687474)
	@Override
	public RDRNotificationsResponseVO getRDRNotifications(String userId)
			throws RMDWebException, Exception {
		logger.debug("HealthCheckServiceImpl : Inside getRDRNotifications() method:::::START");
		String notificationsString = null;
		List<RDRNotificationsVO> notifications = null;
		RDRNotificationsResponseVO result = null;
		Map<String,String> queryParamsMap = new HashMap<String,String>();
		queryParamsMap.put("userId", userId);
		try {
			notificationsString = (String) webServiceInvoker.getFromJSON(ServiceConstants.ASSET_SERVICE_GET_RDR_NOTIFICATIONS, null, queryParamsMap, null, String.class);
			ObjectMapper mapper = new ObjectMapper();
			if(notificationsString==null) {
				return null;
			}
			TypeReference<List<RDRNotificationsVO>> mapType = new TypeReference<List<RDRNotificationsVO>>() {};	
			notifications = mapper.readValue(notificationsString,mapType);
			result = new RDRNotificationsResponseVO();
			result.setNotifications(notifications);
		} catch (Exception ex) {
			logger.error("Exception occured in getRDRNotifications method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("HealthCheckServiceImpl : Inside getRDRNotifications() method:::::END");
		return result;
	}
	
	@Override
	public boolean insertRDRNotification (RDRNotificationsSubmitRequest notification)
			throws RMDWebException, Exception {
		logger.debug("HealthCheckServiceImpl : Inside insertRDRNotification() method:::::START");
		boolean status = false;
		try {
			status = Boolean.parseBoolean((String) webServiceInvoker.post(
					ServiceConstants.ASSET_SERVICE_INSERT_RDR_NOTIFICATION,
					notification, String.class));
		} catch (Exception ex) {
			logger.error("Exception occured in insertRDRNotification method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("HealthCheckServiceImpl : Inside insertRDRNotification() method:::::END");
		return status;
	}
	
	@Override
	public boolean updateRDRNotification (RDRNotificationsSubmitRequest notification)
			throws RMDWebException, Exception {
		logger.debug("HealthCheckServiceImpl : Inside updateRDRNotification() method:::::START");
		boolean status = false;
		try {
			status = Boolean.parseBoolean((String) webServiceInvoker.post(
					ServiceConstants.ASSET_SERVICE_UPDATE_RDR_NOTIFICATION,
					notification, String.class));
		} catch (Exception ex) {
			logger.error("Exception occured in insertRDRNotification method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("HealthCheckServiceImpl : Inside insertRDRNotification() method:::::END");
		return status;
	}
	
	@Override
	public HealthCheckFaultsDataVO getHCFaults(Map<String,String> pathParamsMap, Map<String,String> queryParamsMap, Map<String,String> headerParamsMap) 
			throws RMDWebException, Exception {
		logger.debug("HealthCheckServiceImpl : Inside getHCFaults() method:::::START");
		String faultsString = null;
		HealthCheckFaultsDataVO faults = null;
		try {
			logger.debug("--------------------=====DEBUGGING HCFAULTS ERROR START=======--------------------");
			logger.debug("--------------------=====PATH PARAMS MAP=======--------------------");
			logger.debug(pathParamsMap);
			logger.debug("--------------------=====QUERY PARAMS MAP=======--------------------");
			logger.debug(queryParamsMap);
			logger.debug("--------------------=====HEADER PARAMS MAP=======--------------------");
			logger.debug(headerParamsMap);
			logger.debug("--------------------=====DEBUGGING HCFAULTS ERROR END=======--------------------");
			faultsString = (String) webServiceInvoker.getFromJSON(
					ServiceConstants.ASSET_SERVICE_GET_FAULTS_FOR_MOBILE, pathParamsMap, queryParamsMap,
					headerParamsMap, String.class);
			ObjectMapper mapper = new ObjectMapper();
			faults = mapper.readValue(faultsString,HealthCheckFaultsDataVO.class);
		} catch (Exception ex) {
			logger.error("Exception occured in getHCFaults method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		logger.debug("HealthCheckServiceImpl : Inside getHCFaults() method:::::END");
		return faults;
	}
	// EOC
	
	@Override
	public String getHCAssetType(String strAssetId, String strCustomerId,
			String strGrpName) throws RMDWebException, Exception {
		logger
				.debug("HealthCheckServiceImpl : Inside getAssetType() method:::::START");
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		String strAssetType = null;
		try {
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTNUM, strAssetId);
			queryParamsMap.put(AppConstants.REQ_PARAM_CUSID, strCustomerId);
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTGRP, strGrpName);
			strAssetType = (String) webServiceInvoker.get(
					ServiceConstants.GET_HC_ASSET_TYPE, null, queryParamsMap,
					null, String.class);

		} catch (Exception ex) {
			logger.error("Exception occured in getAssetType method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		logger
				.debug("HealthCheckServiceImpl : Inside getAssetType() method:::::END");
		return strAssetType;
	}

	/**
	 * @param strAssetId,strCustomerId,strAssetGrpName,strSampleRate,noOfPostSamples,mpNumber,strCustomerName,HealthCheckResponseType,device,typeOfUser
	 * @return Map<String, String>
	 * @throws RMDWebException
	 *             ,Exception
	 * @Description:This method submits a healthCheck request 
	 */
	@Override
	public Map<String, String> submitHealthCheckRequest(String strAssetId,
			String strCustomerId, String strAssetGrpName, String strSampleRate,
			String noOfPostSamples, String mpNumber, String strCustomerName,
			HealthCheckResponseType hcResType, String device, String typeOfUser)
			throws RMDWebException, Exception {
		final Map<String, String> mapHCResponse = new HashMap<String, String>();
		SendMultiDeviceMessageResponse sendMultiDeviceMessageResponse = null;
		HealthCheckSubmitRequest objHealthCheckSubmitRequest = new HealthCheckSubmitRequest();
		try {
			
			//Added for CSX MCS
			Map<String, String> queryParamsMap = new HashMap<String, String>();
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTNUM, strAssetId);
			queryParamsMap.put(AppConstants.REQ_PARAM_CUSID, strCustomerId);
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTGRP, strAssetGrpName);
			queryParamsMap.put(AppConstants.TYPE_OF_USER, typeOfUser);
			queryParamsMap.put("fromMCS", "Y");
			String mcsSource = (String) webServiceInvoker.get(ServiceConstants.GET_DEVICE_INFO, null, queryParamsMap, null, String.class);
			
			objHealthCheckSubmitRequest.setRoadNumber(Long.parseLong(strAssetId));
			objHealthCheckSubmitRequest.setCustomerID(strCustomerId);
			objHealthCheckSubmitRequest.setRoadIntial(strAssetGrpName);
			objHealthCheckSubmitRequest.setUserId(strCustomerName);
			objHealthCheckSubmitRequest.setTypeOfUser(typeOfUser);
			objHealthCheckSubmitRequest.setPostSamples(Long.parseLong(noOfPostSamples));
			SendMultiDeviceMessageServiceInterface serviceIntf = null;
			if(mcsSource == null || "GE".equals(mcsSource)){
				serviceIntf = new SendMultiDeviceMessageServiceInterface(
					new URL(hcSendMessageServiceURL),
					new QName("http://www.getransporatation.com/railsolutions/mcs", "SendMultiDeviceMessageServiceInterface"));
			}else{
				HostnameVerifier allHostsValid = new HostnameVerifier() {
		              public boolean verify(String hostname, SSLSession session) {
		            	  boolean isValidHostname = false;
		            	  isValidHostname = isValidCSXHost(hostname);
		            	  logger.info("Is Valid host:" + isValidHostname + " HostName : "+hostname);
		                  return isValidHostname;
		              }

					private boolean isValidCSXHost(String hostname) {
						boolean isValid = false;
						if(csxValidHosts!=null && !csxValidHosts.isEmpty()){
							String[] validHosts = csxValidHosts.split(",");
							if(Arrays.asList(validHosts).contains(hostname)){
								isValid = true;
							}
						}
						return isValid;
					}
		        };
		        logger.info(" ***** allHostsValid ***** "+allHostsValid);
		        // Install the all-trusting host verifier
		        HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
				serviceIntf = new SendMultiDeviceMessageServiceInterface(
						new URL(hcCSXSendMessageServiceURL),
						new QName("http://www.getransporatation.com/railsolutions/mcs", "SendMultiDeviceMessageServiceInterface"));
			}

			SendMultiDeviceMessageService service = serviceIntf.getSendMessageServicePort(hcSendMessageServiceUsername, hcSendMessageServicePassowrd);
			logger.info(service);
			SendMultiDeviceMessageRequest request = new SendMultiDeviceMessageRequest();
			request.setApplicationId(RMDCommonConstants.MCS_APPLICATION_ID);
			request.setMessageId(RMDCommonConstants.MCS_MESSAGE_ID);
			request.setAssetOwnerId(strCustomerId);
			request.setRoadInitial(hcResType.getVehicleHDRNum());
			request.setRoadNumber(strAssetId);
			request.setRequestorName(strCustomerName);
			request.setDevice(device);
			request.getAttribute().addAll(PopulateListWsAttribute(strSampleRate, noOfPostSamples, hcResType));
			sendMultiDeviceMessageResponse = service.sendMessage(request);
			if (null != String.valueOf(sendMultiDeviceMessageResponse.getMessageOutId().intValue())
					&& sendMultiDeviceMessageResponse.getMessageOutId().intValue() > 0) {
				objHealthCheckSubmitRequest.setMsgId(String.valueOf(sendMultiDeviceMessageResponse.getMessageOutId().intValue()));
				mcsSource = (String) webServiceInvoker.post(ServiceConstants.SAVE_HC_DETAILS, objHealthCheckSubmitRequest, String.class);
				if (mcsSource.equalsIgnoreCase(RMDCommonConstants.SUCCESS)) {
					mapHCResponse.put("Success", String.valueOf(sendMultiDeviceMessageResponse.getMessageOutId().intValue()));
				}
			}
		} catch (Fault fault) {
			String errorCode = RMDCommonUtility.getErrorCode("MCS_FAULT_"+ fault.getFaultInfo().getFaultCode());
			logger.error("error code submit health check " + errorCode);
			if (errorCode != null) {
				logger.error("error message submit health check "
						+ RMDCommonUtility.getMessage(errorCode,
								new String[] {},
								RMDCommonConstants.ENGLISH_LANGUAGE));
				mapHCResponse.put("Error", "Invalid Input Parameter");

			} else
				mapHCResponse.put("Error", fault.getFaultInfo().getFaultMessage());
		} catch (Exception ex) {
			logger.error("Exception occured in submitHealthCheckRequest method ", ex);
			if (ex.getClass().getName().indexOf("WebServiceException") > -1 || ex.getClass().getName().indexOf("WSException") > -1) {
				logger.info("Got WSException from MCS :: ");
				throw new GenericAjaxException(AppConstants.EXCEPTION_JSONMAPPING, AppConstants.MINOR_ERROR);
			} else {
				RMDWebErrorHandler.handleException(ex);
			}
		}
		return mapHCResponse;
	}

	/**
	 * @param healthCheckSubmitVO
	 * @return Map<String, String>
	 * @throws RMDWebException
	 *             ,Exception
	 * @Description:This method submits a healthCheck request for Ega unit
	 */
	@Override
	public Map<String, String> submitEGAHealthCheckRequest(
			HealthCheckSubmitVO healthCheckSubmitVO) throws RMDWebException,
			Exception {
		logger.debug("HealthCheckServiceImpl : Inside getSendMessageAttributes() method:::::START");
		Map<String, String> mapHcResponse = new HashMap<String, String>();
		String msgRequestId = null;
		try {
			final Map<String, String> headerParams = getHeaderMap(healthCheckSubmitVO);
			HealthCheckSubmitRequest healthCheckSubmitRequest = new HealthCheckSubmitRequest();
			healthCheckSubmitRequest.setCustomerID(healthCheckSubmitVO
					.getCustomerID());
			healthCheckSubmitRequest.setRoadIntial(healthCheckSubmitVO
					.getRoadIntial());
			healthCheckSubmitRequest.setRoadNumber(healthCheckSubmitVO
					.getRoadNumber());
			healthCheckSubmitRequest.setAssetType(healthCheckSubmitVO
					.getAssetType());
			healthCheckSubmitRequest.setMpGroupId(healthCheckSubmitVO
					.getMpGroupId());
			healthCheckSubmitRequest.setMpGroupName(healthCheckSubmitVO
					.getMpGroupName());
			healthCheckSubmitRequest.setSampleRate(healthCheckSubmitVO
					.getSampleRate());
			healthCheckSubmitRequest.setPostSamples(healthCheckSubmitVO
					.getPostSamples());
			healthCheckSubmitRequest.setPlatform(healthCheckSubmitVO
					.getPlatform());
			healthCheckSubmitRequest
					.setMpNumber(healthCheckSubmitVO.getMpNum());
			healthCheckSubmitRequest.setTypeOfUser(healthCheckSubmitVO
					.getTypeOfUser());
			msgRequestId = (String) webServiceInvoker.post(
					ServiceConstants.SUBMIT_HC_REQUEST,
					healthCheckSubmitRequest, String.class, headerParams);
			mapHcResponse.put(AppConstants.FUNCTION_SUCCESS, msgRequestId);
		} catch (RMDWebException ex) {
			logger.error("RMDWebException occured in getCases() method ", ex);
			String errorCode = ex.getErrorCode();
			if (errorCode.endsWith(AppConstants.EXCEPTION_EOA_3032)) {
				mapHcResponse.put(AppConstants.FUNCTION_ERROR,
						AppConstants.EXCEPTION_EOA_3032);
			} else {
				RMDWebErrorHandler.handleException(ex);
			}
		} catch (Exception ex) {
			logger.error(
					"Exception occured in submitEGAHealthCheckRequest method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("HealthCheckServiceImpl : Inside submitEGAHealthCheckRequest() method:::::END");
		return mapHcResponse;
	}


	@Override
	public HealthCheckResponseType getSendMessageAttributes(String strAssetId,
			String strCustomerId, String strAssetGrpName, String strInput,
			String strAssetType, String typeOfUser,String device) throws RMDWebException, Exception {
		logger
				.debug("HealthCheckServiceImpl : Inside getSendMessageAttributes() method:::::START");
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		HealthCheckResponseType hcRepType = null;
		// String strAssetType = null;
		try {
			queryParamsMap.put("Input", strInput);
			queryParamsMap.put(AppConstants.ASSET_TYPE, strAssetType);
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTNUM, strAssetId);
			queryParamsMap.put(AppConstants.REQ_PARAM_CUSID, strCustomerId);
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTGRP, strAssetGrpName);
			queryParamsMap.put(AppConstants.TYPE_OF_USER, typeOfUser);
			queryParamsMap.put(AppConstants.DEVICE, device);
			
			hcRepType = (HealthCheckResponseType) webServiceInvoker.get(
					ServiceConstants.GET_MCS_WS_ATTRIBUTE, null,
					queryParamsMap, null, HealthCheckResponseType.class);

		} catch (Exception ex) {
			logger
					.error(
							"Exception occured in getSendMessageAttributes method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger
				.debug("HealthCheckServiceImpl : Inside getSendMessageAttributes() method:::::END");
		return hcRepType;
	}

	public static List<SendMultiDeviceMessageRequest.Attribute> PopulateListWsAttribute(
			String strSampleRate, String noOfPostSamples,
			HealthCheckResponseType hcResType) {
		SendMultiDeviceMessageRequest.Attribute attribute = null;
		List<SendMultiDeviceMessageRequest.Attribute> lstAttribute = new ArrayList<SendMultiDeviceMessageRequest.Attribute>();
		attribute = new SendMultiDeviceMessageRequest.Attribute();
		attribute.setName("numberOfPostSamples");
		attribute.setValue(noOfPostSamples);
		lstAttribute.add(attribute);
		attribute = new SendMultiDeviceMessageRequest.Attribute();
		attribute.setName("rateOfSamples");
		attribute.setValue(strSampleRate);
		lstAttribute.add(attribute);

		attribute = new SendMultiDeviceMessageRequest.Attribute();
		attribute.setName("mpNumbers");
		attribute.setValue(hcResType.getMpReqNum());
		lstAttribute.add(attribute);

		attribute = new SendMultiDeviceMessageRequest.Attribute();
		attribute.setName("sourceApps");
		attribute.setValue(hcResType.getSourceApp());
		lstAttribute.add(attribute);

		attribute = new SendMultiDeviceMessageRequest.Attribute();
		attribute.setName("noOfBytes");
		attribute.setValue(hcResType.getNoOfBytes());
		lstAttribute.add(attribute);

		attribute = new SendMultiDeviceMessageRequest.Attribute();
		attribute.setName("signed");
		attribute.setValue(hcResType.getSigned());
		lstAttribute.add(attribute);

		attribute = new SendMultiDeviceMessageRequest.Attribute();
		attribute.setName("dataType");
		attribute.setValue(hcResType.getDestType());
		lstAttribute.add(attribute);

		attribute = new SendMultiDeviceMessageRequest.Attribute();
		attribute.setName("mpRateEnum");
		attribute.setValue(hcResType.getMpRateNum());
		lstAttribute.add(attribute);

		return lstAttribute;

	}

	/** 
	 * @return List<HealthCheckVO>
	 * @param String strAssetId, String strCustomerId, String strGrpName, String userTimeZone
	 * @Description function to call mcs webservice and return message history
	 */
	@Override
	public MessageHistoryResponseVO viewHCMessageHistory(String strAssetId,
			String strCustomerId, String strGrpName, String userTimeZone,
			String device, String userCustomer, String autoHC,
			String internalPrivilege,String fromDateParam , String toDateParam) throws RMDWebException, Exception {
		
		MessageCriteria msgCriteriaRequest = null;
		MessageCriteria msgCriteriaResponse = null;
		List<HealthCheckVO> messageHistList = null;
		List<HealthCheckVO> messageHistListFilters = null;
		GroupMsgHistoryRequest request = null;
		HealthCheckViewResponse[] healthCheckViewResponse=null;
		HealthCheckVO healthCheckVO =null;
		List<String> messagesList = null;
		Date reqDate = null;
		Date statusDate = null;
		MessageHistoryResponseVO messageHistoryResponseVO =null;
				
		List<Message> lstMessages = null;
		AssetCriteria assetCriteria = null;
		try {
			
			DateFormat responseFormat = null;
			CustLookupVO custLookupVO = cachedService.getSDCustLookup().get(userCustomer);
			if (custLookupVO != null && custLookupVO.getDateFormat() != null
					&& !"".equals(custLookupVO.getDateFormat().trim())) {
				responseFormat = new SimpleDateFormat(custLookupVO.getDateFormat());
			}else{
				responseFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
			}
			responseFormat.setTimeZone(TimeZone.getTimeZone(userTimeZone));
			
			int index=device.indexOf("-");
			String deviceMsgHist=device.substring(0,index);
			String deviceType=device.substring(index+1,device.length());
			
			if (!deviceMsgHist.equals(RMDCommonConstants.PLATFORM_EGA)) {
				logger.info("viewHCMessageHistory method");
				String fromDateStr = RMDCommonUtility.convertDateFormatAndTimezone(fromDateParam, AppConstants.DATE_FORMAT_24HRS, 
						AppConstants.MCS_DATE_FORMAT, userTimeZone, AppConstants.GMT_TIMEZONE);
				String toDateStr = RMDCommonUtility.convertDateFormatAndTimezone(toDateParam, AppConstants.DATE_FORMAT_24HRS, 
						AppConstants.MCS_DATE_FORMAT, userTimeZone, AppConstants.GMT_TIMEZONE);
				DateTimeFrom fromDate = new DateTimeFrom();
				fromDate.setValue(fromDateStr);
				fromDate.setTimezone(AppConstants.GMT_TIMEZONE);
				DateTimeTo toDate = new DateTimeTo();
				toDate.setValue(toDateStr);
				toDate.setTimezone(AppConstants.GMT_TIMEZONE);
				MessageHistoryServiceInterface serviceIntf = new MessageHistoryServiceInterface(new URL(viewMessageHistoryServiceURL),
						new QName("http://www.getransporatation.com/railsolutions/mcs", "MessageHistoryServiceInterface"));
				
				MessageHistoryService service = serviceIntf.getMessageHistoryServicePort(hcSendMessageServiceUsername,
								hcSendMessageServicePassowrd);
				logger.debug(service);
				assetCriteria = new AssetCriteria();
				assetCriteria.setAssetOwnerName(strCustomerId);
				assetCriteria.setRoadInitial(getCustrnhDetails(strCustomerId, strAssetId, strGrpName));// Vehicle
				assetCriteria.setRoadNumberFrom(strAssetId);
				assetCriteria.setRoadNumberTo(strAssetId);
				assetCriteria.setDevice(deviceMsgHist);
				msgCriteriaRequest = new MessageCriteria();
				msgCriteriaRequest.setAppId(RMDCommonConstants.MCS_APPLICATION_ID);
				msgCriteriaRequest.setMsgId(RMDCommonConstants.MCS_MESSAGE_ID);
				msgCriteriaResponse = new MessageCriteria();
				msgCriteriaResponse.setAppId(RMDCommonConstants.MCS_APPLICATION_ID);
				msgCriteriaResponse.setMsgId(AppConstants.MP_MESSAGE_ID_03);
				request = new GroupMsgHistoryRequest();
				request.getMessageCriteria().add(msgCriteriaRequest);
				request.getMessageCriteria().add(msgCriteriaResponse);
				request.setDateTimeFrom(fromDate);
				request.setDateTimeTo(toDate);
				request.getAssetCriteria().add(assetCriteria);
				MessageHistoryResponse msgHistoryResponse = service.getGroupAssetMsgHistory(request);
				
				messageHistoryResponseVO = new MessageHistoryResponseVO();
				if (null != msgHistoryResponse) {
					lstMessages = msgHistoryResponse.getMessages();
					if (null != lstMessages) {
						final DateFormat mCS_DateFormat = new SimpleDateFormat(AppConstants.MCS_DATE_FORMAT);
						TimeZone gMTTimeZone = TimeZone.getTimeZone(AppConstants.GMT_TIMEZONE);
						mCS_DateFormat.setTimeZone(gMTTimeZone);
						messageHistListFilters = new ArrayList<HealthCheckVO>(lstMessages.size());
						for(Message tempVO : lstMessages){
							HealthCheckVO hcVO  = new HealthCheckVO();
							if (null != tempVO.getId()) {
								hcVO.setMessageId(tempVO.getId().longValue());
							}
							hcVO.setMessageDirection(tempVO.getMessageDirection());
							hcVO.setMessageType(tempVO.getMessageTypeName());
							hcVO.setRequestor(tempVO.getRequestor());
							if (null != tempVO.getRequestDateTime() && null != tempVO.getRequestDateTime().getValue()) {
								reqDate = mCS_DateFormat.parse(tempVO.getRequestDateTime().getValue());
								hcVO.setRequestDate(responseFormat.format(reqDate));
							}
							hcVO.setStatus(tempVO.getMessageStatus());
							if (null != tempVO.getAppRetryCount()) {
								hcVO.setRetryCount(tempVO.getAppRetryCount().longValue());
							}
							if (null != tempVO.getStatusDateTime() && null != tempVO.getStatusDateTime().getValue()) {
								statusDate = mCS_DateFormat.parse(tempVO.getStatusDateTime().getValue());
								hcVO.setStatusDate(responseFormat.format(statusDate));
							}
							if (null != tempVO.getTemplateNumber() && null != tempVO.getTemplateVersion()) {
								hcVO.setTemplateVersion(tempVO.getTemplateNumber()
										+ AppConstants.VIEW_DECIMAL + tempVO.getTemplateVersion());
							}
							if (null != tempVO.getMessageOutId()) {
								hcVO.setOffboardSequence(tempVO.getMessageOutId().toString());
							}
							messageHistListFilters.add(hcVO);
						}
						messageHistList = new ArrayList<HealthCheckVO>(messageHistListFilters.size());
						StringBuilder messageBuilder = new StringBuilder();
						for (int i = 0; i < messageHistListFilters.size(); i++) {
							messageBuilder.append(messageHistListFilters.get(i).getMessageId().toString()
									+ RMDCommonConstants.COMMMA_SEPARATOR);
						}
						messageBuilder.deleteCharAt(messageBuilder.length() - 1);
						String strMessageIdList = messageBuilder.toString();
						final Map<String, String> queryParams = new LinkedHashMap<String, String>();
						queryParams.put(AppConstants.MESSAGE_ID_LIST, strMessageIdList);
						
						if (AppConstants.YES_FLAG.equalsIgnoreCase(internalPrivilege)){
							if("GE".equalsIgnoreCase(deviceType)){
								if(AppConstants.STR_TRUE.equalsIgnoreCase(autoHC)){
									queryParams.put(AppConstants.MSG_TITLE, AppConstants.INTERNAL_AUTO_REQUESTS);
								}else{
									queryParams.put(AppConstants.MSG_TITLE, AppConstants.INTERNAL_REQUESTS);
								}
								
							} else if("Customer".equalsIgnoreCase(deviceType)){
								if(AppConstants.STR_TRUE.equalsIgnoreCase(autoHC)){
									queryParams.put(AppConstants.MSG_TITLE, AppConstants.EXTERNAL_AUTO_REQUESTS);
								}else{
									queryParams.put(AppConstants.MSG_TITLE, AppConstants.EXTERNAL_USERS);
								}
							}
						}else{
							if(AppConstants.STR_FALSE.equalsIgnoreCase(autoHC)){
								queryParams.put(AppConstants.MSG_TITLE, AppConstants.EXTERNAL_USERS);
							}
						}
						
						String filteredRecords = (String) webServiceInvoker.get(ServiceConstants.FILTER_RECORDS, null, 
								queryParams, null, String.class);
						if (null != filteredRecords) {
							messagesList = Arrays.asList(filteredRecords.split(RMDCommonConstants.COMMMA_SEPARATOR));
							for (int i = 0; i < messageHistListFilters.size(); i++) {
								if (messagesList.contains(messageHistListFilters.get(i).getMessageId().toString())) {
									messageHistList.add(messageHistListFilters.get(i));
								}
								if (messagesList.contains(messageHistListFilters.get(i).getOffboardSequence())) {
									messageHistList.add(messageHistListFilters.get(i));
								}
							}
						}
						messageHistoryResponseVO.setMessages(messageHistList);
							
					} 
				} 
				messageHistoryResponseVO.setErrorCode(msgHistoryResponse.getErrorCode());
				messageHistoryResponseVO.setErrorDescription(msgHistoryResponse.getErrorDescription());
				if(messageHistList != null && !messageHistList.isEmpty() && messageHistList.size()>=1000){
					messageHistoryResponseVO.setMaxRecordsReturned(msgHistoryResponse.getMaxRecordsReturned());
				}
				
			} else if (deviceMsgHist.equals(RMDCommonConstants.PLATFORM_EGA)) {
				HcViewHistoryRequestType hcViewHistoryRequestType = new HcViewHistoryRequestType();
				hcViewHistoryRequestType.setCustomerId(strCustomerId);
				hcViewHistoryRequestType.setRoadInitial(strGrpName);
				hcViewHistoryRequestType.setRoadNumber(strAssetId);
				hcViewHistoryRequestType.setPlatform(device);
				if (internalPrivilege.equalsIgnoreCase(AppConstants.YES_FLAG) && deviceType.equalsIgnoreCase("GE")) {
					hcViewHistoryRequestType.setMessageId("HC_GE");
				} else {
					hcViewHistoryRequestType.setMessageIdCustomer("HC_CUST");
				}
				
				String fromDateEGA = RMDCommonUtility.convertDateFormatAndTimezone(fromDateParam, AppConstants.DATE_FORMAT_24HRS, 
						AppConstants.MCS_DATE_FORMAT, userTimeZone, RMDCommonConstants.DateConstants.EST_US);
				String toDateEGA = RMDCommonUtility.convertDateFormatAndTimezone(toDateParam, AppConstants.DATE_FORMAT_24HRS, 
						AppConstants.MCS_DATE_FORMAT, userTimeZone, RMDCommonConstants.DateConstants.EST_US);
				hcViewHistoryRequestType.setFromDate(fromDateEGA);
				hcViewHistoryRequestType.setToDate(toDateEGA);
				hcViewHistoryRequestType.setMessageIdAuto(autoHC);
				hcViewHistoryRequestType.setIsInternal(internalPrivilege);
				messageHistoryResponseVO = new MessageHistoryResponseVO();
				healthCheckViewResponse = (HealthCheckViewResponse[]) webServiceInvoker.post(ServiceConstants.VIEW_HC_REQUEST_HISTORY,
								hcViewHistoryRequestType, HealthCheckViewResponse[].class);
				messageHistList = new ArrayList<HealthCheckVO>(healthCheckViewResponse.length);
				final DateFormat defaultDateFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
				defaultDateFormat.setTimeZone(TimeZone.getTimeZone(RMDCommonConstants.DateConstants.EST_US));
				for (HealthCheckViewResponse hcViewResponse : healthCheckViewResponse) {
					healthCheckVO = new HealthCheckVO();
					healthCheckVO.setMessageDirection(hcViewResponse.getMessageDirection());
					healthCheckVO.setMessageId(hcViewResponse.getMessageId());
					healthCheckVO.setMessageId(hcViewResponse.getMessageId());
					healthCheckVO.setMessageType(hcViewResponse.getMessageType());
					healthCheckVO.setRequestor(hcViewResponse.getRequestor());
					healthCheckVO.setRequestDate(responseFormat.format(defaultDateFormat.parse(hcViewResponse.getRequestDate())));
					healthCheckVO.setStatusDate(responseFormat.format(defaultDateFormat.parse(hcViewResponse.getStatusDate())));
					healthCheckVO.setStatus(hcViewResponse.getStatus());
					healthCheckVO.setRetryCount(hcViewResponse.getRetryCount());
					healthCheckVO.setTemplateVersion(hcViewResponse.getTemplateVersion());
					healthCheckVO.setMessageDirection(hcViewResponse.getMessageDirection());
					healthCheckVO.setOffboardSequence(hcViewResponse.getOffboardSequence());
					messageHistList.add(healthCheckVO);
				}
				messageHistoryResponseVO.setMessages(messageHistList);
			}  
			      
		} catch (com.ge.trans.rmd.cm.mcs.assestmessagehistory.Fault fault) {
			logger.error("Exception occured in viewHCMessageHistory method ", fault);
			messageHistList = new ArrayList<HealthCheckVO>(0);
			messageHistoryResponseVO = new MessageHistoryResponseVO();
			healthCheckVO = new HealthCheckVO();
			if (AppConstants.MCS_NO_RECORD_FOUND.equalsIgnoreCase(fault.getFaultInfo().getFaultCode())) {
				logger.error("In HealthCheckServiceImpl : error occured in viewHCMessageHistory No record Found "
						+ fault.getMessage());
			}else{
				final Map<String, String> mapHCResponse = new HashMap<String, String>();
				mapHCResponse.put("Error", fault.getFaultInfo().getFaultMessage());
				healthCheckVO.setMapHCResponse(mapHCResponse);
				messageHistList.add(healthCheckVO);
				messageHistoryResponseVO.setMessages(messageHistList);
			}
		} catch (Exception ex) {
			logger.error("Exception occured in viewHCMessageHistory method ", ex);
			String exceptionName = ex.getClass().getName();
			if (exceptionName.indexOf("WebServiceException")> -1 || exceptionName.indexOf("WSException") > -1) {
				logger.info("Got WSException from MCS :: ");
				throw new GenericAjaxException(AppConstants.EXCEPTION_JSONMAPPING, AppConstants.MINOR_ERROR);
			} else {
				RMDWebErrorHandler.handleException(ex);
			}
		} finally {
		    lstMessages = null;
			assetCriteria = null;
			msgCriteriaRequest = null;
			msgCriteriaResponse = null;
			messageHistListFilters = null;
			request = null;
			healthCheckViewResponse=null;
			healthCheckVO =null;
		}
		return messageHistoryResponseVO;
	
	}
	/**
	 * @param strCustomerId
	 * @param strAssetId
	 * @param strGrpName
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description Function get the road initial number for an asset
	 */
	public String getCustrnhDetails(String strCustomerId, String strAssetId,
			String strGrpName) throws RMDWebException,
			Exception {
		logger
				.debug("HealthCheckServiceImpl : Inside getAssetHCMPGroups() method:::::START");
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		String roadHdrNum = null;
		try {
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTNUM, strAssetId);
			queryParamsMap.put(AppConstants.REQ_PARAM_CUSID, strCustomerId);
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTGRP, strGrpName);
			roadHdrNum = (String) webServiceInvoker
					.get(ServiceConstants.GET_HC_CUST_RNH_DETAILS, null,
							queryParamsMap, null,
							 String.class);
			
		} catch (Exception ex) {
			logger.error("Exception occured in getAssetHCMPGroups method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		logger
				.debug("HealthCheckServiceImpl : Inside getAssetHCMPGroups() method:::::END");
		return roadHdrNum;
	}

	/**
	 *@Description: Function to get the SampleRate from the lookup
	 *@param listName
	 *@return String
	 */
	@Override
	public String getHCLookup(String listName) throws Exception {
		String result = null;
		try {
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService
					.getAllLookupValues().get(listName);
			if (applParamResponseTypeList != null) {

				result = applParamResponseTypeList.get(0).getLookupValue();

			}

		} catch (Exception e) {
			RMDWebErrorHandler.handleException(e);
		}
		return result;
	}

	/**
	 * @param :HealthCheckSubmitVO
	 * @return String
	 * @throws Exception
	 * @Description:This method fetches device information.
	 */
	@Override
	public String getDeviceInfo(HealthCheckSubmitVO objHealthCheckSubmitVO)
			throws RMDWebException, Exception {
		logger.debug("HealthCheckServiceImpl : Inside getDeviceInfo() method:::::START");
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		String result = null;
		try {
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTNUM,
					objHealthCheckSubmitVO.getAssetId());
			queryParamsMap.put(AppConstants.REQ_PARAM_CUSID,
					objHealthCheckSubmitVO.getCustomerID());
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTGRP,
					objHealthCheckSubmitVO.getRoadIntial());
			queryParamsMap.put(AppConstants.TYPE_OF_USER,
					objHealthCheckSubmitVO.getTypeOfUser());
			result = (String) webServiceInvoker.get(
					ServiceConstants.GET_DEVICE_INFO, null, queryParamsMap,
					null, String.class);

		} catch (Exception ex) {
			logger.error("Exception occured in getDeviceInfo method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("HealthCheckServiceImpl : Inside getDeviceInfo() method:::::END");
		return result;
	}
	/**
	 * @param :HealthCheckSubmitVO
	 * @return String
	 * @throws Exception
	 * @Description:This method validates EGA HC Request.
	 */
	@Override
	public String validateEGAHC(HealthCheckSubmitVO objHealthCheckSubmitVO)
			throws RMDWebException, Exception {
		logger.debug("HealthCheckServiceImpl : Inside validateEGAHC() method:::::START");
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		String result = null;
		try {
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTNUM,
					objHealthCheckSubmitVO.getAssetId());
			queryParamsMap.put(AppConstants.REQ_PARAM_CUSID,
					objHealthCheckSubmitVO.getCustomerID());
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTGRP,
					objHealthCheckSubmitVO.getRoadIntial());
			queryParamsMap.put(AppConstants.TYPE_OF_USER,
					objHealthCheckSubmitVO.getTypeOfUser());
			result = (String) webServiceInvoker.get(
					ServiceConstants.VALIDATE_EGA_HC, null, queryParamsMap,
					null, String.class);

		} catch (Exception ex) {
			logger.error("Exception occured in validateEGAHC method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("HealthCheckServiceImpl : Inside validateEGAHC() method:::::END");
		return result;
	}

	/**
	 * @param :HealthCheckSubmitVO
	 * @return String
	 * @throws Exception
	 * @Description:This method validates NT HC Request.
	 */
	@Override
	public String validateNTHC(HealthCheckSubmitVO objHealthCheckSubmitVO)
			throws RMDWebException, Exception {
		logger.debug("HealthCheckServiceImpl : Inside validateNTHC() method:::::START");
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		String result = null;
		try {
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTNUM,
					objHealthCheckSubmitVO.getAssetId());
			queryParamsMap.put(AppConstants.REQ_PARAM_CUSID,
					objHealthCheckSubmitVO.getCustomerID());
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTGRP,
					objHealthCheckSubmitVO.getRoadIntial());
			result = (String) webServiceInvoker.get(
					ServiceConstants.VALIDATE_NT_HC, null, queryParamsMap,
					null, String.class);
		} catch (Exception ex) {
			logger.error("Exception occured in validateNTHC method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("HealthCheckServiceImpl : Inside validateNTHC() method:::::END");
		return result;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, List<String>>
	 * @throws:RMDWebException,Exception
	 * @Description: This method is used for fetching the Customer Name and Road
	 *               Number Headers.
	 */
	@Override
	public Map<String, List<String>> getCustNameRNH() throws RMDWebException,
			Exception {
		Map<String, List<String>> custNameRNHMap = new LinkedHashMap<String, List<String>>();
		try {
			custNameRNHMap = cachedService.getCustNameRNH();
		} catch (Exception ex) {
			logger.error(
					"RMDWebException occured in getCustNameRNH() method - HealthcheckServiceImpl",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return custNameRNHMap;
	}
	
	
	
}
