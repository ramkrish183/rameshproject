package com.ge.trans.rmd.cm.mvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;

@Controller
@SessionAttributes
public class DataController extends RMDBaseController{
	
	@RequestMapping(AppConstants.REQ_URI_DATA)
	public ModelAndView displayData(final HttpServletRequest request) {
		request.setAttribute(AppConstants.FILTERFLAG, request.getParameter(AppConstants.FLAG));
		return new ModelAndView(AppConstants.VIEW_DATA);
	}
}
