package com.ge.trans.rmd.cm.valueobjects;

import java.util.ArrayList;
import java.util.List;

public class ToolOutputDeliverVO {
	
	  private String assetnumber; 
	  private String groupName; 
	  private String customerId;	  
	  private String caseType;
	  private String caseId; 								  
	  private String rxtitle; 
	  private String currnewcasetype;
	  private String mdscnote; 
	  private String urgency;
	  private String timetorepair;
	  private String newUrgency;
	  private String newEstmRepairTime;
	  private String userName;
	  private String rxObjid;	  
	  private String customerName;
	  private String caseObjid;
	  private String solutionRevisionNo;
	  private String ruleDefId;
	  private String toolId;
	  private String toolObjId;
	  private List<RecommDelvDocVO> arlRecommDelDocVO=new ArrayList<RecommDelvDocVO>();
	   
	public List<RecommDelvDocVO> getArlRecommDelDocVO() {
		return arlRecommDelDocVO;
	}
	public void setArlRecommDelDocVO(List<RecommDelvDocVO> arlRecommDelDocVO) {
		this.arlRecommDelDocVO = arlRecommDelDocVO;
	}
	public String getNewUrgency() {
		return newUrgency;
	}
	public void setNewUrgency(String newUrgency) {
		this.newUrgency = newUrgency;
	}
	public String getNewEstmRepairTime() {
		return newEstmRepairTime;
	}
	public void setNewEstmRepairTime(String newEstmRepairTime) {
		this.newEstmRepairTime = newEstmRepairTime;
	}
	public String getSolutionRevisionNo() {
		return solutionRevisionNo;
	}
	public void setSolutionRevisionNo(String solutionRevisionNo) {
		this.solutionRevisionNo = solutionRevisionNo;
	}
	public String getCaseObjid() {
		return caseObjid;
	}
	public void setCaseObjid(String caseObjid) {
		this.caseObjid = caseObjid;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	
	public String getRxObjid() {
		return rxObjid;
	}
	public void setRxObjid(String rxObjid) {
		this.rxObjid = rxObjid;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAssetnumber() {
		return assetnumber;
	}
	public void setAssetnumber(String assetnumber) {
		this.assetnumber = assetnumber;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getRxtitle() {
		return rxtitle;
	}
	public void setRxtitle(String rxtitle) {
		this.rxtitle = rxtitle;
	}
	public String getCurrnewcasetype() {
		return currnewcasetype;
	}
	public void setCurrnewcasetype(String currnewcasetype) {
		this.currnewcasetype = currnewcasetype;
	}
	public String getMdscnote() {
		return mdscnote;
	}
	public void setMdscnote(String mdscnote) {
		this.mdscnote = mdscnote;
	}
	public String getUrgency() {
		return urgency;
	}
	public void setUrgency(String urgency) {
		this.urgency = urgency;
	}
	public String getTimetorepair() {
		return timetorepair;
	}
	public void setTimetorepair(String timetorepair) {
		this.timetorepair = timetorepair;
	}
	/**
	 * @return the ruleDefId
	 */
	public String getRuleDefId() {
		return ruleDefId;
	}
	/**
	 * @param ruleDefId the ruleDefId to set
	 */
	public void setRuleDefId(String ruleDefId) {
		this.ruleDefId = ruleDefId;
	}
	/**
	 * @return the toolId
	 */
	public String getToolId() {
		return toolId;
	}
	/**
	 * @param toolId the toolId to set
	 */
	public void setToolId(String toolId) {
		this.toolId = toolId;
	}
	/**
	 * @return the toolObjId
	 */
	public String getToolObjId() {
		return toolObjId;
	}
	/**
	 * @param toolObjId the toolObjId to set
	 */
	public void setToolObjId(String toolObjId) {
		this.toolObjId = toolObjId;
	}	
}
