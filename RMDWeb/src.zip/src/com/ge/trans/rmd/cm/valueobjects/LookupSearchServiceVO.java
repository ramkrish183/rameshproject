package com.ge.trans.rmd.cm.valueobjects;

import com.ge.trans.rmd.common.valueobjects.BaseVO;

public class LookupSearchServiceVO extends BaseVO{
	/** serialVersionUID of Type long **/
	private static final long serialVersionUID = 3256345453455297L;
	/** strSearchBy of Type String **/
	private String strSearchBy;
	/** strValue of Type String **/
	private String strValue;	
	private String strSearchCondition;

	/**
	 * @Author:
	 * @return
	 * @Description:
	 */
	public String getStrSearchBy() {
		return strSearchBy;
	}

	/**
	 * @Author:
	 * @param strSearchBy
	 * @Description:
	 */
	public void setStrSearchBy(final String strSearchBy) {
		this.strSearchBy = strSearchBy;
	}

	/**
	 * @Author:
	 * @return
	 * @Description:
	 */
	public String getStrValue() {
		return strValue;
	}

	/**
	 * @Author:
	 * @param strValue
	 * @Description:
	 */
	public void setStrValue(final String strValue) {
		this.strValue = strValue;
	}

	public String getStrSearchCondition() {
		return strSearchCondition;
	}

	public void setStrSearchCondition(String strSearchCondition) {
		this.strSearchCondition = strSearchCondition;
	}

}
