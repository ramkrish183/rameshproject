/**
 * ============================================================
 * Classification: GE Confidential
 * File : VehicleCfgCaseClosure.java
 * Description :
 *
 * Package : com.ge.trans.rmd.cm.valueobjects;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on :
 * History
 * Modified By : Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.valueobjects;

public class VehicleCfgCaseClosureVO {

	private String caseId;
	private String caseObjId;
	private String userName;
	private String repairCode;
	
	public String getRepairCode() {
		return repairCode;
	}
	public void setRepairCode(String repairCode) {
		this.repairCode = repairCode;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getCaseObjId() {
		return caseObjId;
	}
	public void setCaseObjId(String caseObjId) {
		this.caseObjId = caseObjId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
}
