/**
 * 
 */
package com.ge.trans.rmd.cm.valueobjects;

/**
 * @author 212338353
 *
 */
public class DeliverSummaryVO {
	
	private String caseId; 
    private String caseTitle;
    private String type;
	
	/**
	 * @return the caseId
	 */
	public String getCaseId() {
		return caseId;
	}
	/**
	 * @param caseId the caseId to set
	 */
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	/**
	 * @return the caseTitle
	 */
	public String getCaseTitle() {
		return caseTitle;
	}
	/**
	 * @param caseTitle the caseTitle to set
	 */
	public void setCaseTitle(String caseTitle) {
		this.caseTitle = caseTitle;
	}
	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}	  
}
