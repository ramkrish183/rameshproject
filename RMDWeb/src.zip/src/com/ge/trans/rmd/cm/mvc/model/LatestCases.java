package com.ge.trans.rmd.cm.mvc.model;

import java.util.ArrayList;
import java.util.Map;

public class LatestCases {
	private String caseId;
	

	private Map<String, ArrayList<RuleBean>> lstCaseRules = null;
	

	public Map<String, ArrayList<RuleBean>> getLstCaseRules() {
		return lstCaseRules;
	}

	public void setLstCaseRules(final Map<String,  ArrayList<RuleBean>> lstCaseRules) {
		this.lstCaseRules = lstCaseRules;
	}

	

	public String getCaseId() {
		return caseId;
	}

	public void setCaseId(final String caseId) {
		this.caseId = caseId;
	}

	
}
