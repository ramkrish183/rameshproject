/**
 * ============================================================
 * Classification: GE Confidential
 * File : AssetDataScreenService.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.common.service;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on : November 14, 2011
 * History
 * Modified By : iGATE
 *
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */

package com.ge.trans.rmd.cm.service;


import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.beans.AssetFaultDataBean;
import com.ge.trans.rmd.cm.mvc.model.GridMetaData;
import com.ge.trans.rmd.cm.mvc.model.LatestCases;
import com.ge.trans.rmd.cm.valueobjects.AssetDataResponseVO;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface AssetDataScreenService {

	public GridMetaData getAssetMetaData(final AssetFaultDataBean assetFaultDataBean, final String userCustomer) throws RMDWebException, Exception; 
	public AssetDataResponseVO getAssetFaultData(final AssetFaultDataBean assetFaultDataBean, final String userCustomer) throws RMDWebException, Exception;
	public List<LatestCases> getLatestCases(final AssetFaultDataBean objAssetFaultDataBean) throws Exception;
	public Map<String,String> getDDDropdown(Map<String, String> listName) throws Exception;
	public Map<String,String> getDDRoleName(Map<String, String> listName) throws Exception;
	public Map<String,String> getTimeBasedFilter(Map<String, String> listName) throws Exception;
	public List<String> getNoOfDaysDropdownValues(String listName) throws Exception;

	/**
	 * @Author :
	 * @return :Map<String, String>
	 * @param : CaseBean
	 * @throws :RMDWebException
	 * @Description: This method is used to get unit configuration details in
	 *               data screen
	 * 
	 */
	public Map<String, List<String>> getUnitConfigDetails(CaseBean objCaseBean)
			throws RMDWebException;
	public Map<String, String> getLookupValueList(String listName)
			throws Exception;
	public String getLocoId(AssetOverviewBean assetOverviewBean)throws RMDWebException;
}