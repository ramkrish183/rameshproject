package com.ge.trans.rmd.cm.valueobjects;

import java.util.Date;



public class LDVRRequestVO {
	
	private String applicationId;
	private String messageId;
	private String assetOwnerId;
	private String roadInitial;
	private String roadNumber;
	private String device;
	private String requestorName;
	private String comments;
	private String selectedCameras;
	private String internalMemory;
	private String externalMemory;
	private String requestTitle;
	private String startTime;
	private String endTime;
	private String deletionType;
	private String importance;
	
	
	public String getApplicationId() {
		return applicationId;
	}


	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}


	public String getMessageId() {
		return messageId;
	}


	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}


	public String getAssetOwnerId() {
		return assetOwnerId;
	}


	public void setAssetOwnerId(String assetOwnerId) {
		this.assetOwnerId = assetOwnerId;
	}


	public String getRoadInitial() {
		return roadInitial;
	}


	public void setRoadInitial(String roadInitial) {
		this.roadInitial = roadInitial;
	}


	public String getRoadNumber() {
		return roadNumber;
	}


	public void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}


	public String getDevice() {
		return device;
	}


	public void setDevice(String device) {
		this.device = device;
	}


	public String getRequestorName() {
		return requestorName;
	}


	public void setRequestorName(String requestorName) {
		this.requestorName = requestorName;
	}


	public String getComments() {
		return comments;
	}


	public void setComments(String comments) {
		this.comments = comments;
	}


	public String getSelectedCameras() {
		return selectedCameras;
	}


	public void setSelectedCameras(String selectedCameras) {
		this.selectedCameras = selectedCameras;
	}


	public String getInternalMemory() {
		return internalMemory;
	}


	public void setInternalMemory(String internalMemory) {
		this.internalMemory = internalMemory;
	}


	public String getExternalMemory() {
		return externalMemory;
	}


	public void setExternalMemory(String externalMemory) {
		this.externalMemory = externalMemory;
	}


	public String getRequestTitle() {
		return requestTitle;
	}


	public void setRequestTitle(String requestTitle) {
		this.requestTitle = requestTitle;
	}


	public String getStartTime() {
		return startTime;
	}


	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}


	public String getEndTime() {
		return endTime;
	}


	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}


	public String getDeletionType() {
		return deletionType;
	}


	public void setDeletionType(String deletionType) {
		this.deletionType = deletionType;
	}


	public String getImportance() {
		return importance;
	}


	public void setImportance(String importance) {
		this.importance = importance;
	}


	@Override
	public String toString() {
		String val = "applicationId: "+applicationId
						+"\nmessageId: "+messageId
						+"\nassetOwnerId: "+assetOwnerId
						+"\nroadInitial: "+roadInitial
						+"\nroadNumber: "+roadNumber
						+"\nrequestorName: "+requestorName
						+"\ndevice: "+device
						+"\ncomments: "+comments
						+"\ninternalMemory: "+internalMemory
						+"\nnetworkMemory: "+externalMemory
						+"\nselectedCameras: "+selectedCameras
						+"\nrequestTitle: "+requestTitle
						+"\nrequestStartTime: "+startTime
						+"\nrequestEndTime: "+endTime
						+"\nimportance: "+importance
						+"\nDeletionType: "+deletionType;
		return val;
	}
	
}
