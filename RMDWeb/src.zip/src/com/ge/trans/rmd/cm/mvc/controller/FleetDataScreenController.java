/**
 * 
 */
package com.ge.trans.rmd.cm.mvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;

/**
 * @author 212338353
 *
 */
@Controller
public class FleetDataScreenController {

	
	@RequestMapping(value = AppConstants.REQ_URI_FLEET_DATASCREEN, method = RequestMethod.GET)
	public ModelAndView getFleetDataScreenPage(final HttpServletRequest request)
			 throws RMDWebException {
		return new ModelAndView(AppConstants.VIEW_FLEET_DATASCREEN);
	}
}
