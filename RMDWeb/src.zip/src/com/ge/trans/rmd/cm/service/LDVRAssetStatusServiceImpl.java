/**
 * 
 */
package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.ge.trans.pp.services.notification.valueobjects.RoadInitialType;
import com.ge.trans.rmd.cm.valueobjects.ActiveLcvLDVRCamDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.ApplyTemplatesVO;
import com.ge.trans.rmd.cm.valueobjects.AssetLDVRDataVO;
import com.ge.trans.rmd.cm.valueobjects.AssetTemplateListVO;
import com.ge.trans.rmd.cm.valueobjects.AssetTemplateVO;
import com.ge.trans.rmd.cm.valueobjects.AssetsVO;
import com.ge.trans.rmd.cm.valueobjects.DetailsVO;
import com.ge.trans.rmd.cm.valueobjects.ExcludedAssetsVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRApplyTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRApplyTemplateResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetStatusRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetStatusResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTempReapplyRemoveRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTempReapplyRemoveStatusVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTemplateResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRPreservationRequestTemplateVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRPreservationRetriveTemplateInfo;
import com.ge.trans.rmd.cm.valueobjects.MessageDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.MessageStatusVO;
import com.ge.trans.rmd.cm.valueobjects.ResponseStatusVO;
import com.ge.trans.rmd.cm.valueobjects.SkipTemplatesVO;
import com.ge.trans.rmd.cm.valueobjects.TemplatesVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.locovision.valueobjects.ActiveLcvLDVRCamDetailsType;
import com.ge.trans.rmd.services.locovision.valueobjects.ApplyTemplatesType;
import com.ge.trans.rmd.services.locovision.valueobjects.AssetLDVRDataType;
import com.ge.trans.rmd.services.locovision.valueobjects.AssetTemplateListType;
import com.ge.trans.rmd.services.locovision.valueobjects.AssetTemplateType;
import com.ge.trans.rmd.services.locovision.valueobjects.AssetsType;
import com.ge.trans.rmd.services.locovision.valueobjects.DetailsType;
import com.ge.trans.rmd.services.locovision.valueobjects.ExcludedAssetsType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRApplyTemplateRequestType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRApplyTemplateResponseType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRAssetStatusRequestType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRAssetStatusResponseType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRAssetTempReapplyRemoveRequestType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRAssetTempReapplyRemoveResponseType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRAssetTemplateRequestType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRAssetTemplateResponseType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRPreservationRequestTemplate;
import com.ge.trans.rmd.services.locovision.valueobjects.LstAssetTempReapplyRemoveStatusType;
import com.ge.trans.rmd.services.locovision.valueobjects.MessageDetailsType;
import com.ge.trans.rmd.services.locovision.valueobjects.MessageStatusType;
import com.ge.trans.rmd.services.locovision.valueobjects.SkipTemplatesType;
import com.ge.trans.rmd.services.locovision.valueobjects.TemplatesType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

/**
 * @author MSHIRAJUDDIN
 * 
 */
@Service
public class LDVRAssetStatusServiceImpl implements LDVRAssetStatusService {

    private final RMDWebLogger rmdWebLogger = RMDWebLogger
            .getLogger(getClass());

    @Autowired
    private WebServiceInvoker webServiceInvoker;
    @Value("${" + AppConstants.LDVR_GET_TEMPLATE_URL + "}")
    String mcsGetTemplateURL;
    @Value("${" + AppConstants.LDVR_MCS_APPLY_TEMPLATE_URL + "}")
    String mcsapplyTemplateURL;
    @Value("${" + AppConstants.HEALH_CHECK_SEND_MESSAGE_SERVICE_USERNAME + "}")
    String mcsGetNumCamerasUsername;
    @Value("${" + AppConstants.HEALH_CHECK_SEND_MESSAGE_SERVICE_PASSWORD + "}")
    String mcsGetNumCamerasPassowrd;
    @Value("${" + AppConstants.LDVR_MCS_GET_ASSET_STATUS_URL + "}")
    String getAssetLdvrStatusURL;
    @Value("${" + AppConstants.LDVR_MCS_GET_ASSET_TEMPLATE_LIST_URL + "}")
    String getAssetTemplateListURL;
    @Value("${" + AppConstants.LDVR_MCS_REAPPLY_REMOVE_ASSET_TEMPLATE_URL + "}")
    String reApplyRemoveAssetTemplateURL;

   public LDVRAssetStatusResponseVO getAssetLdvrStatus(
            LDVRAssetStatusRequestVO ldvrAssetStatusResquestVO)
            throws RMDWebException, Exception {
        rmdWebLogger
                .info("Inside LDVRAssetStatusServiceImpl in getAssetLdvrStatus Method");
        LDVRAssetStatusRequestType ldvrAssetStatusRequestType = null;
        LDVRAssetStatusResponseVO ldvrAssetStatusResponseVO = null;
        LDVRAssetStatusResponseType ldvrAssetStatusResponseType = null;
        ObjectMapper mapper = new ObjectMapper();
        try {
            ldvrAssetStatusRequestType = new LDVRAssetStatusRequestType();
            ldvrAssetStatusRequestType
                    .setAssetOwnerId(ldvrAssetStatusResquestVO
                            .getAssetOwnerId());
            ldvrAssetStatusRequestType.setRoadInitial(ldvrAssetStatusResquestVO
                    .getRoadInitial());
            ldvrAssetStatusRequestType.setRoadNumber(ldvrAssetStatusResquestVO
                    .getRoadNumber());
            ldvrAssetStatusRequestType.setDevice(ldvrAssetStatusResquestVO
                    .getDevice());
            ldvrAssetStatusRequestType.setDaysToView(ldvrAssetStatusResquestVO
                    .getDaysToView());

            ObjectWriter ow = mapper.writer()
                    .withDefaultPrettyPrinter();
            String inputJson = ow
                    .writeValueAsString(ldvrAssetStatusRequestType);

            rmdWebLogger.info("getAssetLdvrStatus :::" + inputJson);
            //Fix for Defect DE64701 - LDVRStatus is not displaying messages for 6021 QRNI asset Starts
          /*  ldvrAssetStatusResponseType = (LDVRAssetStatusResponseType) webServiceInvoker
                    .postMCSWebService(mcsGetNumCamerasUsername,
                            mcsGetNumCamerasPassowrd, getAssetLdvrStatusURL,
                            inputJson, LDVRAssetStatusResponseType.class);*/
            String ldvrStatusResponse = (String) webServiceInvoker
            .postMCSWebService(mcsGetNumCamerasUsername,
                    mcsGetNumCamerasPassowrd, getAssetLdvrStatusURL,
                    inputJson, String.class);
            ldvrAssetStatusResponseType = mapper.readValue(
                    ldvrStatusResponse, LDVRAssetStatusResponseType.class);
            //Fix for Defect DE64701 - LDVRStatus is not displaying messages for 6021 QRNI asset Ends
            if (ldvrAssetStatusResponseType != null) {
                ldvrAssetStatusResponseVO = new LDVRAssetStatusResponseVO();
                ldvrAssetStatusResponseVO
                        .setAssetOwnerId(ldvrAssetStatusResponseType
                                .getAssetOwnerId());
                ldvrAssetStatusResponseVO
                        .setRoadInitial(ldvrAssetStatusResponseType
                                .getRoadInitial());
                ldvrAssetStatusResponseVO
                        .setRoadNumber(ldvrAssetStatusResponseType
                                .getRoadNumber());
                ldvrAssetStatusResponseVO.setDevice(ldvrAssetStatusResponseType
                        .getDevice());
                ldvrAssetStatusResponseVO
                        .setSectionTitle(ldvrAssetStatusResponseType
                                .getSectionTitle());
                ldvrAssetStatusResponseVO
                        .setRecordingStatus(ldvrAssetStatusResponseType
                                .getRecordingStatus());

                if (!RMDCommonUtility.isNullOrEmpty(ldvrAssetStatusResponseType
                        .getRecordingDate())
                        && !"NA".equalsIgnoreCase(ldvrAssetStatusResponseType
                                .getRecordingDate())) {
                    ldvrAssetStatusResponseVO.setRecordingDate(RMDCommonUtility
                            .convertDateFormatTimezone(
                                    ldvrAssetStatusResponseType
                                            .getRecordingDate(),
                                    RMDCommonConstants.ddMMyyyyhhmma,
                                    RMDCommonConstants.ddMMyyyyHHmmss,
                                    ldvrAssetStatusResquestVO.getTimeZone()));
                } else
                    ldvrAssetStatusResponseVO
                            .setRecordingDate(ldvrAssetStatusResponseType
                                    .getRecordingDate());

                ldvrAssetStatusResponseVO
                        .setQueueUtilization(ldvrAssetStatusResponseType
                                .getQueueUtilization());

                if (!RMDCommonUtility.isNullOrEmpty(ldvrAssetStatusResponseType
                        .getPreservationQueueUtilizationDt())
                        && !"NA".equalsIgnoreCase(ldvrAssetStatusResponseType
                                .getPreservationQueueUtilizationDt())) {
                    ldvrAssetStatusResponseVO
                            .setPreservationQueueUtilizationDt(RMDCommonUtility.convertDateFormatTimezone(
                                    ldvrAssetStatusResponseType
                                            .getPreservationQueueUtilizationDt(),
                                    RMDCommonConstants.MMddyyyyhhmma,
                                    RMDCommonConstants.ddMMyyyyHHmmss,
                                    ldvrAssetStatusResquestVO.getTimeZone()));
                }

                ldvrAssetStatusResponseVO
                        .setActivePreservationRequests(ldvrAssetStatusResponseType
                                .getActivePreservationRequests());

                AssetLDVRDataType assetLDVRDataType = ldvrAssetStatusResponseType
                        .getAssetLDVRData();
                AssetLDVRDataVO assetLDVRData = new AssetLDVRDataVO();
                List<LDVRPreservationRequestTemplateVO> tempList = null;

                if (null != assetLDVRDataType) {
                    List<LDVRPreservationRequestTemplate> activePreservationTemplates = assetLDVRDataType
                            .getActivePreservationTemplates();
                    if (!CollectionUtils.isEmpty(activePreservationTemplates)) {
                        LDVRPreservationRetriveTemplateInfo templateInfo;

                        tempList = new ArrayList<LDVRPreservationRequestTemplateVO>();

                        for (LDVRPreservationRequestTemplate wsTemplate : activePreservationTemplates) {
                            LDVRPreservationRequestTemplateVO template = new LDVRPreservationRequestTemplateVO();

                            template.setComment(wsTemplate.getComment());
                            template.setComplete(wsTemplate.getComplete());
                            template.setFilesPreserved(wsTemplate
                                    .getFilesPreserved());
                            template.setNumVer(wsTemplate.getNumVer());
                            template.setLastUpdatedBy(wsTemplate
                                    .getLastUpdatedBy());
                            template.setOffBoardStatus(wsTemplate
                                    .getOffBoardStatus());
                            template.setRequestedEndTime(wsTemplate
                                    .getRequestedEndTime());
                            template.setRequestedStartTime(wsTemplate
                                    .getRequestedStartTime());
                            template.setTemplateObjId(wsTemplate
                                    .getTemplateObjId());

                            template.setTitle(wsTemplate.getTitle());

                            templateInfo = new LDVRPreservationRetriveTemplateInfo();
                            templateInfo.setComplete(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getComplete());
                            templateInfo.setDeletion(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getDeletion());
                            templateInfo.setLastUpdatedBy(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getLastUpdatedBy());
                            templateInfo.setLastUpdatedDate(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getLastUpdatedDate());
                            templateInfo.setLatestFileScannedDate(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getLatestFileScannedDate());
                            templateInfo.setNumFilesInPq(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getNumFilesInPq());
                            templateInfo.setOffloadPriority(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getOffloadPriority());
                            templateInfo.setRequestedEndTime(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getRequestedEndTime());
                            templateInfo.setRequestedStartTime(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getRequestedStartTime());
                            templateInfo.setScanExpirationCode(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getScanExpirationCode());
                            templateInfo.setStatusDate(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getStatusDate());
                            templateInfo.setTemplateNumber(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getTemplateNumber());
                            templateInfo.setTemplateStatus(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getTemplateStatus());
                            templateInfo.setTemplateTypeName(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getTemplateTypeName());
                            templateInfo.setTemplateVersion(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getTemplateVersion());
                            templateInfo.setTitle(wsTemplate
                                    .getlDVRPreservationRetriveTemplateInfo()
                                    .getTitle());
                            template.setlDVRPreservationRetriveTemplateInfo(templateInfo);

                            tempList.add(template);
                        }
                    }
                    assetLDVRData.setActivePreservationTemplates(tempList);

                    List<ActiveLcvLDVRCamDetailsType> activeLcvLDVRCamDetails = assetLDVRDataType
                            .getActiveLcvLDVRCamDetails();
                    if (!CollectionUtils.isEmpty(activeLcvLDVRCamDetails)
                            && (activeLcvLDVRCamDetails.get(0)
                                    .getCameraNumber() != null)) {
                        MessageDetailsType messageDetailsType;
                        ActiveLcvLDVRCamDetailsVO camDetails;
                        List<ActiveLcvLDVRCamDetailsVO> camDetailsList = new ArrayList<ActiveLcvLDVRCamDetailsVO>();
                        if (activeLcvLDVRCamDetails != null
                                && !CollectionUtils
                                        .isEmpty(activeLcvLDVRCamDetails)) {
                            for (ActiveLcvLDVRCamDetailsType assetCamDetails : assetLDVRDataType
                                    .getActiveLcvLDVRCamDetails()) {
                                MessageDetailsVO messageDetailsVO = new MessageDetailsVO();
                                messageDetailsType = assetCamDetails
                                        .getMessageDetails();
                                camDetails = new ActiveLcvLDVRCamDetailsVO();

                                camDetails.setCameraNumber(assetCamDetails
                                        .getCameraNumber());

                                if (!RMDCommonUtility
                                        .isNullOrEmpty(assetCamDetails
                                                .getLdvrStatusTime())
                                        && !"NA".equalsIgnoreCase(assetCamDetails
                                                .getLdvrStatusTime())) {
                                    camDetails
                                            .setLdvrStatusTime(RMDCommonUtility.convertDateFormatTimezone(
                                                    assetCamDetails
                                                            .getLdvrStatusTime(),
                                                    RMDCommonConstants.MMddyyyyhhmmssa,
                                                    RMDCommonConstants.ddMMyyyyHHmmss,
                                                    ldvrAssetStatusResquestVO
                                                            .getTimeZone()));
                                }

                                camDetails.setLocation(assetCamDetails
                                        .getLocation());
                                camDetails.setZeroSpeedStopped(assetCamDetails
                                        .getZeroSpeedStopped());
                                camDetails
                                        .setExtDriveRemotelyStopped(assetCamDetails
                                                .getExtDriveRemotelyStopped());
                                camDetails.setGpsSourceLoss(assetCamDetails
                                        .getGpsSourceLoss());
                                camDetails.setSpeedSourceLoss(assetCamDetails
                                        .getSpeedSourceLoss());
                                camDetails.setRecordingStatus(assetCamDetails
                                        .getRecordingStatus());

                                if (!RMDCommonUtility
                                        .isNullOrEmpty(assetCamDetails
                                                .getExtDriveLatestFileTime())
                                        && !"NA".equalsIgnoreCase(assetCamDetails
                                                .getExtDriveLatestFileTime())) {
                                    camDetails
                                            .setExtDriveLatestFileTime(RMDCommonUtility.convertDateFormatTimezone(
                                                    assetCamDetails
                                                            .getExtDriveLatestFileTime(),
                                                    RMDCommonConstants.MMddyyyyhhmmssa,
                                                    RMDCommonConstants.ddMMyyyyHHmmss,
                                                    ldvrAssetStatusResquestVO
                                                            .getTimeZone()));
                                }

                                camDetails.setIntDriveKBFree(assetCamDetails
                                        .getIntDriveKBFree());
                                camDetails.setExtDriveKBFree(assetCamDetails
                                        .getExtDriveKBFree());
                                if (messageDetailsType != null) {

                                    if (!RMDCommonUtility
                                            .isNullOrEmpty(messageDetailsType
                                                    .getStatusDate())
                                            && !"NA".equalsIgnoreCase(messageDetailsType
                                                    .getStatusDate())) {
                                        messageDetailsVO
                                                .setStatusDate(RMDCommonUtility
                                                        .convertDateFormatTimezone(
                                                                messageDetailsType
                                                                        .getStatusDate(),
                                                                RMDCommonConstants.MMddyyyyhhmma,
                                                                RMDCommonConstants.ddMMyyyyHHmmss,
                                                                ldvrAssetStatusResquestVO
                                                                        .getTimeZone()));
                                    }

                                    messageDetailsVO
                                            .setDevice(messageDetailsType
                                                    .getDevice());
                                    messageDetailsVO
                                            .setGpsLocation(messageDetailsType
                                                    .getGpsLocation());
                                    messageDetailsVO
                                            .setGpsSourceStatus(messageDetailsType
                                                    .getGpsSourceStatus());
                                    messageDetailsVO
                                            .setGpsSourceApplicationDataLoss(messageDetailsType
                                                    .getGpsSourceApplicationDataLoss());
                                    messageDetailsVO
                                            .setSpeedSourceStatus(messageDetailsType
                                                    .getSpeedSourceStatus());
                                    messageDetailsVO
                                            .setSpeedSourceApplicationDataLoss(messageDetailsType
                                                    .getSpeedSourceApplicationDataLoss());
                                    messageDetailsVO
                                            .setStoppedDueToZeroSpeed(messageDetailsType
                                                    .getStoppedDueToZeroSpeed());
                                    messageDetailsVO
                                            .setApplicationsReportingDataLoss(messageDetailsType
                                                    .getApplicationsReportingDataLoss());
                                    messageDetailsVO
                                            .setIntDriveSizeKB(messageDetailsType
                                                    .getIntDriveSizeKB());

                                    messageDetailsVO
                                            .setIntFreeSpaceKB(messageDetailsType
                                                    .getIntFreeSpaceKB());
                                    messageDetailsVO
                                            .setIntRemoteStopActive(messageDetailsType
                                                    .getIntRemoteStopActive());

                                    if (!RMDCommonUtility
                                            .isNullOrEmpty(messageDetailsType
                                                    .getIntOldestFileTime())
                                            && !"NA".equalsIgnoreCase(messageDetailsType
                                                    .getIntOldestFileTime())) {
                                        messageDetailsVO
                                                .setIntOldestFileName(RMDCommonUtility
                                                        .convertDateFormatTimezone(
                                                                messageDetailsType
                                                                        .getIntOldestFileTime(),
                                                                RMDCommonConstants.MMddyyyyhhmma,
                                                                RMDCommonConstants.ddMMyyyyHHmmss,
                                                                ldvrAssetStatusResquestVO
                                                                        .getTimeZone()));
                                    }

                                    if (!RMDCommonUtility
                                            .isNullOrEmpty(messageDetailsType
                                                    .getNewestFileTime())
                                            && !"NA".equalsIgnoreCase(messageDetailsType
                                                    .getNewestFileTime())) {
                                        messageDetailsVO
                                                .setNewestFileTime(RMDCommonUtility
                                                        .convertDateFormatTimezone(
                                                                (messageDetailsType
                                                                        .getNewestFileTime()),
                                                                RMDCommonConstants.MMddyyyyhhmma,
                                                                RMDCommonConstants.ddMMyyyyHHmmss,
                                                                ldvrAssetStatusResquestVO
                                                                        .getTimeZone()));
                                    }
                                    messageDetailsVO
                                            .setExttDriveSizeKB(messageDetailsType
                                                    .getExttDriveSizeKB());
                                    messageDetailsVO
                                            .setExtFreeSpaceKB(messageDetailsType
                                                    .getExtFreeSpaceKB());

                                    messageDetailsVO
                                            .setExttRemoteStopActive(messageDetailsType
                                                    .getExttRemoteStopActive());
                                    messageDetailsVO
                                            .setPreservationFreeSpaceKB(messageDetailsType
                                                    .getPreservationFreeSpaceKB());
                                    messageDetailsVO
                                            .setOldDirectoryName(messageDetailsType
                                                    .getOldDirectoryName());

                                    if (!RMDCommonUtility
                                            .isNullOrEmpty(messageDetailsType
                                                    .getNewestVamFile())
                                            && !"NA".equalsIgnoreCase(messageDetailsType
                                                    .getNewestVamFile())) {
                                        messageDetailsVO
                                                .setNewestVamFile(RMDCommonUtility
                                                        .convertDateFormatTimezone(
                                                                (messageDetailsType
                                                                        .getNewestVamFile()),
                                                                RMDCommonConstants.MMddyyyyhhmma,
                                                                RMDCommonConstants.ddMMyyyyHHmmss,
                                                                ldvrAssetStatusResquestVO
                                                                        .getTimeZone()));
                                    }

                                    if (!RMDCommonUtility
                                            .isNullOrEmpty(messageDetailsType
                                                    .getExtOldestFileTime())
                                            && !"NA".equalsIgnoreCase(messageDetailsType
                                                    .getExtOldestFileTime())) {
                                        messageDetailsVO
                                                .setExtOldestFileName(RMDCommonUtility
                                                        .convertDateFormatTimezone(
                                                                messageDetailsType
                                                                        .getExtOldestFileTime(),
                                                                RMDCommonConstants.MMddyyyyhhmma,
                                                                RMDCommonConstants.ddMMyyyyHHmmss,
                                                                ldvrAssetStatusResquestVO
                                                                        .getTimeZone()));
                                    }

                                    camDetails
                                            .setMessageDetails(messageDetailsVO);
                                }

                                camDetailsList.add(camDetails);

                            }
                        }

                        assetLDVRData
                                .setActiveLcvLDVRCamDetails(camDetailsList);
                    }
                    ldvrAssetStatusResponseVO.setAssetLDVRData(assetLDVRData);
                }

            }

        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error(
                    "Exception occured in getAssetLdvrStatus method ", rmdEx);
            throw rmdEx;
        } catch (Exception ex) {
            rmdWebLogger.error(
                    "Exception occured in getAssetLdvrStatus method ", ex);
            throw ex;
        }
        rmdWebLogger
                .info("Inside LDVRAssetStatusServiceImpl in getAssetLdvrStatus Method Done");

        return ldvrAssetStatusResponseVO;
    }


    public LDVRApplyTemplateResponseVO ldvrAssetGroupApplyTemplate(
            LDVRApplyTemplateRequestVO ldvrApplyTemplateRequestVO)
            throws RMDWebException, Exception {
        AssetsType assetType;
        List<ExcludedAssetsVO> listExcludedAssetsVO = null;
        List<ApplyTemplatesVO> listApplyTemplateVO = null;
        List<MessageStatusVO> listMessageStatusVO = null;
        List<TemplatesVO> listTemplatesVO = null;
        LDVRApplyTemplateResponseVO ldvrApplyTemplateResponseVO = null;
        List<SkipTemplatesVO> listSkipTemplatesVO = null;
        rmdWebLogger
                .info("Inside ldvrAssetGroupApplyTemplate in applyTemplate Method");

        LDVRApplyTemplateRequestType ldvrApplyTemplateRequestType = new LDVRApplyTemplateRequestType();

        ldvrApplyTemplateRequestType
                .setTemplateObjid(ldvrApplyTemplateRequestVO.getTemplateObjid());
        List<AssetsVO> assestsList = ldvrApplyTemplateRequestVO.getAssets();
        ldvrApplyTemplateRequestType.setAssets(new ArrayList<AssetsType>());

        if (!CollectionUtils.isEmpty(assestsList)) {
            for (AssetsVO assetVO : assestsList) {
                assetType = new AssetsType();
                assetType.setAssetOwnerId(assetVO.getAssetOwnerId());
                assetType.setRoadInitial(assetVO.getRoadInitial());
                assetType.setRoadNumberFrom(assetVO.getRoadNumberFrom());
                assetType.setRoadNumberTo(assetVO.getRoadNumberTo());
                ldvrApplyTemplateRequestType.getAssets().add(assetType);
            }
        }
        ldvrApplyTemplateRequestType.setDevice(ldvrApplyTemplateRequestVO
                .getDevice());
        ldvrApplyTemplateRequestType.setUserId(ldvrApplyTemplateRequestVO
                .getUserId());
        ldvrApplyTemplateRequestType
                .setMessagePriority(ldvrApplyTemplateRequestVO
                        .getMessagePriority());
        try {
            ObjectWriter ow = new ObjectMapper().writer()
                    .withDefaultPrettyPrinter();
            String inputJson = ow
                    .writeValueAsString(ldvrApplyTemplateRequestType);
            rmdWebLogger.info(inputJson);

            LDVRApplyTemplateResponseType ldvrApplyTemplateResponseType = (LDVRApplyTemplateResponseType) webServiceInvoker
                    .postMCSWebService(mcsGetNumCamerasUsername,
                            mcsGetNumCamerasPassowrd, mcsapplyTemplateURL,
                            inputJson, LDVRApplyTemplateResponseType.class);
            rmdWebLogger.info("applyTemplate jsonresponse:"
                    + ldvrApplyTemplateResponseType.toString());

            if (null != ldvrApplyTemplateResponseType) {
                ldvrApplyTemplateResponseVO = new LDVRApplyTemplateResponseVO();

                List<TemplatesType> templatesList = ldvrApplyTemplateResponseType
                        .getTemplates();

                if (!CollectionUtils.isEmpty(templatesList)) {
                    listTemplatesVO = new ArrayList<TemplatesVO>();
                    for (TemplatesType templatesTypes : templatesList) {

                        TemplatesVO templatesVO = new TemplatesVO();
                        templatesVO.setTemplateNumberVersion(templatesTypes
                                .getTemplateNumberVersion());
                        templatesVO.setTemplateType(templatesTypes
                                .getTemplateType());
                        templatesVO.setDescription(templatesTypes
                                .getDescription());
                        listTemplatesVO.add(templatesVO);
                    }
                }

                ldvrApplyTemplateResponseVO.setTemplates(listTemplatesVO);

                List<MessageStatusType> messageStatusList = ldvrApplyTemplateResponseType
                        .getMessageStatus();

                if (!CollectionUtils.isEmpty(messageStatusList)) {
                    listMessageStatusVO = new ArrayList<MessageStatusVO>();

                    for (MessageStatusType messageStatusTypes : messageStatusList) {

                        MessageStatusVO messageStatusVO = new MessageStatusVO();
                        String[] templateNumVersionArr = messageStatusTypes
                                .getTemplateNumberVersion().split("\\.");
                        messageStatusVO
                                .setRoadInitialAndNumber(messageStatusTypes
                                        .getRoadInitialAndNumber());
                        messageStatusVO.setDevice(messageStatusTypes
                                .getDevice());
                        /*
                         * messageStatusVO
                         * .setTemplateNumberVersion(messageStatusTypes
                         * .getTemplateNumberVersion());
                         */
                        /*
                         * messageStatusVO.setTemplateType(messageStatusTypes
                         * .getTemplateType());
                         */
                        messageStatusVO
                                .setTemplateNumber(templateNumVersionArr[0]);
                        messageStatusVO
                                .setTemplateVersion(templateNumVersionArr[1]);

                        messageStatusVO
                                .setTemplateType(AppConstants.PRESERVE_VIDEO_AUDIO_TEMPLATE);
                        messageStatusVO.setMessageStatus(messageStatusTypes
                                .getMessageStatus());
                        messageStatusVO.setOutboundMessageId(messageStatusTypes
                                .getOutboundMessageId());

                        listMessageStatusVO.add(messageStatusVO);
                    }
                }

                ldvrApplyTemplateResponseVO
                        .setMessageStatus(listMessageStatusVO);

                List<ExcludedAssetsType> excludedAssetsTypeList = ldvrApplyTemplateResponseType
                        .getExcludedAssets();

                if (!CollectionUtils.isEmpty(excludedAssetsTypeList)) {
                    listExcludedAssetsVO = new ArrayList<ExcludedAssetsVO>();

                    for (ExcludedAssetsType excludedAssetsTypes : excludedAssetsTypeList) {

                        ExcludedAssetsVO excludedAssetsVO = new ExcludedAssetsVO();
                        excludedAssetsVO.setRoadNumber(excludedAssetsTypes
                                .getRoadNumber());
                        excludedAssetsVO.setReason(excludedAssetsTypes
                                .getReason());

                        listExcludedAssetsVO.add(excludedAssetsVO);
                    }
                }
                ldvrApplyTemplateResponseVO
                        .setExcludedAssets(listExcludedAssetsVO);

                List<SkipTemplatesType> skipTemplateTypeList = ldvrApplyTemplateResponseType
                        .getSkipTemplates();

                if (!CollectionUtils.isEmpty(skipTemplateTypeList)) {
                    listSkipTemplatesVO = new ArrayList<SkipTemplatesVO>();

                    for (SkipTemplatesType skipTemplatesType : skipTemplateTypeList) {

                        SkipTemplatesVO skipTemplateVO = new SkipTemplatesVO();
                        String[] skiptempNumVersionArr = skipTemplatesType
                                .getNumVer().split("\\.");
                        skipTemplateVO.setRoadNumber(skipTemplatesType
                                .getRoadNumber());
                        skipTemplateVO.setDevice(skipTemplatesType.getDevice());
                        skipTemplateVO.setMessageStatus(skipTemplatesType
                                .getMessageStatus());
                        // skipTemplateVO.setNumVer(skipTemplatesType.getNumVer());
                        // skipTemplateVO.setTemplateDescription(skipTemplatesType.getTemplateDescription());
                        skipTemplateVO
                                .setTemplateNumber(skiptempNumVersionArr[0]);
                        skipTemplateVO
                                .setTemplateVersion(skiptempNumVersionArr[1]);
                        skipTemplateVO
                                .setTemplateDescription(AppConstants.PRESERVE_VIDEO_AUDIO_TEMPLATE);
                        listSkipTemplatesVO.add(skipTemplateVO);
                    }
                }
                ldvrApplyTemplateResponseVO
                        .setSkipTemplates(listSkipTemplatesVO);

                List<ApplyTemplatesType> listApplyTemplateType = ldvrApplyTemplateResponseType
                        .getApplyTemplates();
                if (!CollectionUtils.isEmpty(listApplyTemplateType)) {
                    listApplyTemplateVO = new ArrayList<ApplyTemplatesVO>();
                    for (ApplyTemplatesType applyTemplatesType : listApplyTemplateType) {
                        listExcludedAssetsVO = new ArrayList<ExcludedAssetsVO>();
                        ApplyTemplatesVO applyTemplateVO = new ApplyTemplatesVO();
                        applyTemplateVO.setOwner(applyTemplatesType.getOwner());
                        applyTemplateVO.setRoadInitial(applyTemplatesType
                                .getRoadInitial());
                        applyTemplateVO.setFromToCmuSerial(applyTemplatesType
                                .getFromToCmuSerial());
                        applyTemplateVO.setAlerts(applyTemplatesType
                                .getAlerts());
                        applyTemplateVO.setUniqueID(applyTemplatesType
                                .getUniqueID());
                        applyTemplateVO.setDetailsOwnerName(applyTemplatesType
                                .getDetailsOwnerName());
                        applyTemplateVO
                                .setDetailsRoadInitial(applyTemplatesType
                                        .getDetailsRoadInitial());
                        applyTemplateVO
                                .setDetailsRoadNumberFrom(applyTemplatesType
                                        .getDetailsRoadNumberFrom());
                        applyTemplateVO
                                .setDetailsRoadNumberTo(applyTemplatesType
                                        .getDetailsRoadNumberTo());
                        applyTemplateVO.setDetailsDevice(applyTemplatesType
                                .getDetailsDevice());
                        List<ExcludedAssetsType> lstExecuAssetType = applyTemplatesType
                                .getExcludeReason();
                        if (!CollectionUtils.isEmpty(lstExecuAssetType)) {
                            for (ExcludedAssetsType exeAssetType : lstExecuAssetType) {
                                ExcludedAssetsVO excludedAssetsVO = new ExcludedAssetsVO();
                                excludedAssetsVO.setReason(exeAssetType
                                        .getReason());
                                excludedAssetsVO.setRoadNumber(exeAssetType
                                        .getRoadNumber());
                                listExcludedAssetsVO.add(excludedAssetsVO);
                            }
                            applyTemplateVO
                                    .setExcludeReason(listExcludedAssetsVO);
                        }
                        listApplyTemplateVO.add(applyTemplateVO);
                    }
                }
                ldvrApplyTemplateResponseVO
                        .setApplyTemplates(listApplyTemplateVO);

            }

        } catch (RMDWebException rmdEx) {
            rmdWebLogger
                    .error("Exception occured in  LDVRGeofenceServiceImpl in getLDVRGeoZones Method ",
                            rmdEx);
            throw rmdEx;

        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in  LDVRGeofenceServiceImpl in getLDVRGeoZones Method ",
                            ex);
            throw ex;
        }
        rmdWebLogger
                .info("Inside  LDVRGeofenceServiceImpl in getLDVRGeoZones Method Done");

        return ldvrApplyTemplateResponseVO;

    }

    public LDVRAssetTemplateResponseVO getAssetTemplateList(
            LDVRAssetTemplateRequestVO ldvrAssetTemplateRequestVO)
            throws RMDWebException, Exception {
        rmdWebLogger
                .info("Inside LDVRAssetStatusServiceImpl in getAssetTemplateList Method");
        LDVRAssetTemplateRequestType ldvrAssetTemplateRequestType = null;
        LDVRAssetTemplateResponseVO ldvrAssetTemplateResponseVO = null;
        LDVRAssetTemplateResponseType ldvrAssetTemplateResponseType = null;

        try {
            ldvrAssetTemplateRequestType = new LDVRAssetTemplateRequestType();
            ldvrAssetTemplateRequestType
                    .setAssetOwnerId(ldvrAssetTemplateRequestVO
                            .getAssetOwnerId());
            ldvrAssetTemplateRequestType
                    .setRoadInitial(ldvrAssetTemplateRequestVO.getRoadInitial());
            ldvrAssetTemplateRequestType
                    .setRoadNumber(ldvrAssetTemplateRequestVO.getRoadNumber());
            ldvrAssetTemplateRequestType
                    .setLstDevice(ldvrAssetTemplateRequestVO.getLstDevice());
            ldvrAssetTemplateRequestType
                    .setRequestType(ldvrAssetTemplateRequestVO.getRequestType());
            ldvrAssetTemplateRequestType
                .setTemplateView(ldvrAssetTemplateRequestVO.getTemplateView());

            ObjectWriter ow = new ObjectMapper().writer()
                    .withDefaultPrettyPrinter();
            String inputJson = ow
                    .writeValueAsString(ldvrAssetTemplateRequestType);
            AssetTemplateListVO assetTempList;

            rmdWebLogger.info("getAssetTemplateList :::" + inputJson);

            ldvrAssetTemplateResponseType = (LDVRAssetTemplateResponseType) webServiceInvoker
                    .postMCSWebService(mcsGetNumCamerasUsername,
                            mcsGetNumCamerasPassowrd, getAssetTemplateListURL,
                            inputJson, LDVRAssetTemplateResponseType.class);

            rmdWebLogger.info("getAssetTemplateList  response :::"
                    + ldvrAssetTemplateResponseType.toString());

            if (ldvrAssetTemplateResponseType != null) {

                ldvrAssetTemplateResponseVO = new LDVRAssetTemplateResponseVO();

                ldvrAssetTemplateResponseVO
                        .setDevice(ldvrAssetTemplateResponseType.getDevice());

                List<AssetTemplateListType> assetTemplateListTypes = ldvrAssetTemplateResponseType
                        .getAssetTemplateLists();
                List<AssetTemplateListVO> assetTemplateListVO = new ArrayList<AssetTemplateListVO>();
                List<AssetTemplateVO> templateListVO = new ArrayList<AssetTemplateVO>();

                if (null != assetTemplateListTypes
                        || !CollectionUtils.isEmpty(assetTemplateListTypes)) {
                    for (AssetTemplateListType assetTemplateList : assetTemplateListTypes) {
                        if (assetTemplateList.getTemplateCategory()
                                .equalsIgnoreCase("Configuration Template")) {
                            assetTempList = new AssetTemplateListVO();
                            assetTempList.setTemplateCategory(assetTemplateList
                                    .getTemplateCategory());
                            assetTempList.setAgtMessage(assetTemplateList
                                    .getAgtMessage());

                            List<AssetTemplateType> templateList = assetTemplateList
                                    .getTemplateList();
                            if (!CollectionUtils.isEmpty(templateList)) {
                                for (AssetTemplateType assetTemplateType : templateList) {
                                    AssetTemplateVO assetTemplateVO = new AssetTemplateVO();
                                    assetTemplateVO
                                            .setTemplateNumber(assetTemplateType
                                                    .getTemplateNumber());
                                    assetTemplateVO
                                            .setTemplateType(assetTemplateType
                                                    .getTemplateType());
                                    assetTemplateVO
                                            .setTemplateVersion(assetTemplateType
                                                    .getTemplateVersion());

                                    assetTemplateVO
                                            .setObsoleteFlag(assetTemplateType
                                                    .getObsoleteFlag());

                                    if (!RMDCommonUtility
                                            .isNullOrEmpty(assetTemplateType
                                                    .getInstallationDate()))
                                        assetTemplateVO
                                                .setInstallationDate(RMDCommonUtility
                                                        .convertDateFormatTimezone(
                                                                assetTemplateType
                                                                        .getInstallationDate(),
                                                                RMDCommonConstants.MMddyyyyhhmmssa,
                                                                RMDCommonConstants.ddMMyyyyHHmmss,
                                                                ldvrAssetTemplateRequestVO
                                                                        .getTimeZone()));
                                    assetTemplateVO
                                            .setOffboardStatus(assetTemplateType
                                                    .getOffboardStatus());
                                    if (!RMDCommonUtility
                                            .isNullOrEmpty(assetTemplateType
                                                    .getOffboardStatusDate()))
                                        assetTemplateVO
                                                .setOffboardStatusDate(RMDCommonUtility
                                                        .convertDateFormatTimezone(
                                                                assetTemplateType
                                                                        .getOffboardStatusDate(),
                                                                RMDCommonConstants.MMddyyyyhhmmssa,
                                                                RMDCommonConstants.ddMMyyyyHHmmss,
                                                                ldvrAssetTemplateRequestVO
                                                                        .getTimeZone()));
                                    assetTemplateVO
                                            .setStrTemplateID(assetTemplateType
                                                    .getStrTemplateID());
                                    assetTemplateVO
                                            .setStrTemplateKey(assetTemplateType
                                                    .getStrTemplateKey());
                                    assetTemplateVO
                                            .setTemplateReapply(assetTemplateType
                                                    .getTemplateReapply());
                                    assetTemplateVO
                                            .setTemplateRemove(assetTemplateType
                                                    .getTemplateRemove());
                                    assetTemplateVO.setTitle(assetTemplateType
                                            .getTitle());

                                    if (assetTemplateType.getIsActive() != null
                                            && "Y".equalsIgnoreCase(assetTemplateType
                                                    .getIsActive()))
                                        assetTemplateVO
                                                .setStrActive(AppConstants.ACTIVE);
                                    else
                                        assetTemplateVO
                                                .setStrActive(AppConstants.INACTIVE);
                                    templateListVO.add(assetTemplateVO);
                                }
                                assetTempList.setTemplates(templateListVO);
                            }
                            assetTemplateListVO.add(assetTempList);
                        }
                    }

                }

                ldvrAssetTemplateResponseVO
                        .setAssetTemplateLists(assetTemplateListVO);

            }

        } catch (RMDWebException rmdEx) {
            rmdWebLogger
                    .error("Exception occured in  LDVRAssetStatusServiceImpl in getAssetTemplateList Method ",
                            rmdEx);
            throw rmdEx;

        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in  LDVRAssetStatusServiceImpl in getAssetTemplateList Method ",
                            ex);
            throw ex;
        }
        rmdWebLogger
                .info("Inside  LDVRAssetStatusServiceImpl in getAssetTemplateList Method Done");

        return ldvrAssetTemplateResponseVO;

    }

    public List<LDVRAssetTempReapplyRemoveStatusVO> ldvrReApplyRemoveAssetTemplate(
            LDVRAssetTempReapplyRemoveRequestVO ldvrAssetTempReapplyRemoveRequestVO)
            throws RMDWebException, Exception {
        rmdWebLogger
                .info("Inside LDVRAssetStatusServiceImpl in reApplyRemoveAssetTemplate Method");
        LDVRAssetTempReapplyRemoveRequestType ldvrAssetTempReapplyRemoveRequestType = null;
        List<LDVRAssetTempReapplyRemoveStatusVO> listLDVRAssetTempReapplyRemoveResponseVOs = null;
        try {

            ldvrAssetTempReapplyRemoveRequestType = new LDVRAssetTempReapplyRemoveRequestType();
            ldvrAssetTempReapplyRemoveRequestType
                    .setAssetOwnerId(ldvrAssetTempReapplyRemoveRequestVO
                            .getAssetOwnerId());
            ldvrAssetTempReapplyRemoveRequestType
                    .setRoadInitial(ldvrAssetTempReapplyRemoveRequestVO
                            .getRoadInitial());
            ldvrAssetTempReapplyRemoveRequestType
                    .setRoadNumber(ldvrAssetTempReapplyRemoveRequestVO
                            .getRoadNumber());
            ldvrAssetTempReapplyRemoveRequestType
                    .setDevice(ldvrAssetTempReapplyRemoveRequestVO.getDevice());
            ldvrAssetTempReapplyRemoveRequestType
                    .setLstReApplyTemplateIDs(ldvrAssetTempReapplyRemoveRequestVO
                            .getLstReApplyTemplateIDs());
            ldvrAssetTempReapplyRemoveRequestType
                    .setLstRemoveTemplateIDs(ldvrAssetTempReapplyRemoveRequestVO
                            .getLstRemoveTemplateIDs());
            ldvrAssetTempReapplyRemoveRequestType
                    .setUserName(ldvrAssetTempReapplyRemoveRequestVO
                            .getUserName());

            ObjectWriter ow = new ObjectMapper().writer()
                    .withDefaultPrettyPrinter();
            String inputJson = ow
                    .writeValueAsString(ldvrAssetTempReapplyRemoveRequestType);

            rmdWebLogger.info("reApplyRemoveAssetTemplate :::" + inputJson);

            LDVRAssetTempReapplyRemoveResponseType lDVRAssetTempReapplyRemoveResponseType = (LDVRAssetTempReapplyRemoveResponseType) webServiceInvoker
                    .postMCSWebService(mcsGetNumCamerasUsername,
                            mcsGetNumCamerasPassowrd,
                            reApplyRemoveAssetTemplateURL, inputJson,
                            LDVRAssetTempReapplyRemoveResponseType.class);

            if (lDVRAssetTempReapplyRemoveResponseType != null) {
                List<LstAssetTempReapplyRemoveStatusType> listLDVRAssetTempReapplyRemoveResponseType = lDVRAssetTempReapplyRemoveResponseType
                        .getLstAssetTempReapplyRemoveStatusVo();

                if (listLDVRAssetTempReapplyRemoveResponseType != null) {
                    listLDVRAssetTempReapplyRemoveResponseVOs = new ArrayList<LDVRAssetTempReapplyRemoveStatusVO>();

                    LDVRAssetTempReapplyRemoveStatusVO lstAssetTempReapplyRemoveStatusVO = null;
                    ResponseStatusVO responseStatusVO = null;
                    DetailsVO detailsVO = null;
                    List<DetailsVO> listDetailsVO = null;

                    for (LstAssetTempReapplyRemoveStatusType assetTempReapplyRemoveStatusTypes : listLDVRAssetTempReapplyRemoveResponseType) {
                        lstAssetTempReapplyRemoveStatusVO = new LDVRAssetTempReapplyRemoveStatusVO();

                        lstAssetTempReapplyRemoveStatusVO
                                .setActionType(assetTempReapplyRemoveStatusTypes
                                        .getActionType());
                        responseStatusVO = new ResponseStatusVO();
                        responseStatusVO
                                .setStatus(assetTempReapplyRemoveStatusTypes
                                        .getResponseStatusVO().getStatus());
                        List<DetailsType> detailsTypeList = assetTempReapplyRemoveStatusTypes
                                .getResponseStatusVO().getDetails();
                        if (detailsTypeList != null) {
                            listDetailsVO = new ArrayList<DetailsVO>();
                            for (DetailsType listDetailsType : detailsTypeList) {
                                detailsVO = new DetailsVO();
                                detailsVO.setAssetOwnerId(listDetailsType
                                        .getAssetOwnerId());
                                detailsVO
                                        .setDevice(listDetailsType.getDevice());
                                detailsVO.setRoadInitial(listDetailsType
                                        .getRoadInitial());
                                detailsVO.setRoadNumber(listDetailsType
                                        .getRoadNumber());
                                detailsVO.setItemObjId(listDetailsType
                                        .getItemObjId());
                                detailsVO.setStatusCode(listDetailsType
                                        .getStatusCode());
                                detailsVO.setStatusMessage(listDetailsType
                                        .getStatusMessage());
                                listDetailsVO.add(detailsVO);
                            }
                            responseStatusVO.setDetails(listDetailsVO);
                        }
                        lstAssetTempReapplyRemoveStatusVO
                                .setResponseStatusVO(responseStatusVO);
                        listLDVRAssetTempReapplyRemoveResponseVOs
                                .add(lstAssetTempReapplyRemoveStatusVO);
                    }
                    // System.out.println(listLDVRAssetTempReapplyRemoveResponseVOs);

                }
            }

        } catch (RMDWebException rmdEx) {
            rmdWebLogger
                    .error("Exception occured in  LDVRAssetStatusServiceImpl in reApplyRemoveAssetTemplate Method ",
                            rmdEx);
            throw rmdEx;

        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in  LDVRAssetStatusServiceImpl in reApplyRemoveAssetTemplate Method ",
                            ex);
            throw ex;
        }
        rmdWebLogger
                .info("Inside  LDVRAssetStatusServiceImpl in reApplyRemoveAssetTemplate Method Done");

        return listLDVRAssetTempReapplyRemoveResponseVOs;

    }

    public List<AssetsVO> getRoadInitialHDR(String customerId)
            throws RMDWebException, Exception {
        rmdWebLogger.info("LDVR ApplyTemplate : getRoadInitialHDR");
        final Map<String, String> pathParamsMap = new HashMap<String, String>();
        List<AssetsVO> roadInitials = new ArrayList<AssetsVO>();

        try {
            pathParamsMap.put(AppConstants.CUSTOMER_ID, customerId);
            RoadInitialType[] roadInitialsResponse = (RoadInitialType[]) webServiceInvoker
                    .get(ServiceConstants.GET_NOTIFICATION_ROAD_INITIALS,
                            pathParamsMap, null, null, RoadInitialType[].class);
            if (!RMDCommonUtility.checkNull(roadInitialsResponse)) {

                for (RoadInitialType notificationLevelValue : roadInitialsResponse) {
                    AssetsVO assetVO = new AssetsVO();
                    assetVO.setRoadHdrInitial(notificationLevelValue
                            .getRoadInitialNo());
                    assetVO.setRoadInitial(notificationLevelValue
                            .getRoadInitialName());
                    roadInitials.add(assetVO);

                }
            }
        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error(
                    "RMDWebException occured in getRoadInitials() method ",
                    rmdEx);
            throw rmdEx;
        } catch (Exception exp) {
            rmdWebLogger.error(
                    "Exception occured in getRoadInitials() method ", exp);
            throw exp;
        }
        return roadInitials;
    }

}
