package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import com.ge.trans.rmd.cm.service.SiteService;
import com.ge.trans.rmd.cm.valueobjects.SiteSearchVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class SiteController extends RMDBaseController {
    private final RMDWebLogger rmdWebLogger = RMDWebLogger
            .getLogger(getClass());
    @Autowired
    private SiteService siteService;
    @Autowired
    private ApplicationContext appContext;

    /**
     * @Author:
     * @return
     * @throws RMDWebException
     * @Description:
     * 
     */
    @RequestMapping(value = AppConstants.REQ_URI_GET_SITE_PAGE, method = RequestMethod.GET)
    public ModelAndView getSitePage(final HttpServletRequest request)
            throws RMDWebException {
        rmdWebLogger.info("Inside getSitePage method");
        return new ModelAndView(AppConstants.VIEW_SITE_PAGE);
    }

    /**
     * @return Map<String, String>
     * @throws RMDWebException
     * @Description * This method is used to fetch the values from lookup table
     *              to populate the Site Type dropdown.
     */
    @RequestMapping(value = AppConstants.GET_SITE_TYPES)
    @ResponseBody
    public List<String> getSiteTypes() throws RMDWebException {
        List<String> allSiteTypes = new ArrayList<String>();
        try {
            allSiteTypes = siteService.getSiteTypes();
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getSiteTypes method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return allSiteTypes;
    }

    /**
     * 
     * @param
     * @return List<SiteSearchVO>
     * @throws Exception
     * @Description * This method is used to get the Sites.
     * 
     */
    @RequestMapping(value = AppConstants.GET_SITES, method = RequestMethod.GET)
    @ResponseBody
    public List<SiteSearchVO> getSites(final HttpServletRequest request)
            throws Exception {
        List<SiteSearchVO> objSiteSearchVOlst = new ArrayList<SiteSearchVO>();
        SiteSearchVO objSiteVO = new SiteSearchVO();
        try {
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_TTPES))) {
                objSiteVO.setStrType(request
                        .getParameter(AppConstants.SITE_TTPES));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_ID))) {
                objSiteVO.setStrSiteID(request
                        .getParameter(AppConstants.SITE_ID));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_NAME))) {
                objSiteVO.setStrSiteName(request
                        .getParameter(AppConstants.SITE_NAME));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_ADDRESS))) {
                objSiteVO.setStrAddress(request
                        .getParameter(AppConstants.SITE_ADDRESS));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_CITY))) {
                objSiteVO.setStrCity(request
                        .getParameter(AppConstants.SITE_CITY));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_STATE))) {
                objSiteVO.setStrState(request
                        .getParameter(AppConstants.SITE_STATE));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_ACCOUNT_ID))) {
                objSiteVO.setStrAccountID(request
                        .getParameter(AppConstants.SITE_ACCOUNT_ID));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_ACCOUNT_NAME))) {
                objSiteVO.setStrAccountName(request
                        .getParameter(AppConstants.SITE_ACCOUNT_NAME));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_INACTIVE_FLAG))) {
                objSiteVO.setStrInclInactiveContacts(request
                        .getParameter(AppConstants.SITE_INACTIVE_FLAG));
            }
            objSiteSearchVOlst = siteService.getSites(objSiteVO);
        } catch (Exception ex) {
            ex.printStackTrace();
            rmdWebLogger.error("Exception occured in getSites method ", ex);
            RMDWebErrorHandler.handleException(ex);
            request.setAttribute(AppConstants.ERRORMSG,
                    AppConstants.UNKNOWN_EXCEPTION);
            throw ex;
        }
        return objSiteSearchVOlst;
    }

    /**
     * @Author :
     * @return :SiteSearchVO
     * @param :String siteObjId
     * @throws :RMDWebException
     * @Description:This method is used to get View Site Details.
     */
    @RequestMapping(value = AppConstants.VIEW_SITE_DETAILS)
    @ResponseBody
    public SiteSearchVO viewSiteDetails(
            @RequestParam(value = AppConstants.SITE_OBJID) String siteObjId)
            throws RMDWebException {
        SiteSearchVO objSiteVO = new SiteSearchVO();
        try {
            if (!RMDCommonUtility.isNullOrEmpty(siteObjId)) {
                objSiteVO = siteService.viewSiteDetails(EsapiUtil
                        .stripXSSCharacters(siteObjId));
            }
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured viewSiteDetails() method in SiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return objSiteVO;
    }

    /**
     * 
     * @param SiteSearchVO
     *            objSiteVO
     * @return String
     * @throws Exception
     * @Description * This method is used to create the Site.
     * 
     */
    @RequestMapping(value = AppConstants.CREATE_SITE, method = RequestMethod.POST)
    @ResponseBody
    public String createSite(final HttpServletRequest request) throws Exception {
        SiteSearchVO objSiteVO = new SiteSearchVO();
        String strResult = null;
        try {
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_TYPE))) {
                objSiteVO.setStrCreateType(request
                        .getParameter(AppConstants.SITE_EDITNEW_TYPE));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_STATUS))) {
                objSiteVO.setStrStatus(request
                        .getParameter(AppConstants.SITE_EDITNEW_STATUS));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_SHIPPING))) {
                objSiteVO.setStrPrefShipMethod(request
                        .getParameter(AppConstants.SITE_EDITNEW_SHIPPING));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_CUSTOMER))) {
                objSiteVO.setStrCustomer(request
                        .getParameter(AppConstants.SITE_EDITNEW_CUSTOMER));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_SITEID))) {
                objSiteVO.setStrSiteID(request
                        .getParameter(AppConstants.SITE_EDITNEW_SITEID));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_SITENAME))) {
                objSiteVO.setStrSiteName(request
                        .getParameter(AppConstants.SITE_EDITNEW_SITENAME));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_ADDRESS))) {
                objSiteVO.setPrimAddObjId(request
                        .getParameter(AppConstants.SITE_EDITNEW_ADDRESS));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_SHIPTO))) {
                objSiteVO.setShipAddObjId(request
                        .getParameter(AppConstants.SITE_EDITNEW_SHIPTO));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_BILLTO))) {
                objSiteVO.setBillAddObjId(request
                        .getParameter(AppConstants.SITE_EDITNEW_BILLTO));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_PHONE))) {
                objSiteVO.setStrCellPhone(request
                        .getParameter(AppConstants.SITE_EDITNEW_PHONE));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_FAX))) {
                objSiteVO.setStrFax(request
                        .getParameter(AppConstants.SITE_EDITNEW_FAX));
            }
            strResult = siteService.createSite(objSiteVO);
        } catch (Exception ex) {
            ex.printStackTrace();
            rmdWebLogger.error("Exception occured in createSite method ", ex);
            RMDWebErrorHandler.handleException(ex);
            throw ex;
        }
        return strResult;
    }

    /**
     * 
     * @param SiteSearchVO
     *            objSiteVO
     * @return String
     * @throws Exception
     * @Description * This method is used to Update the Site.
     * 
     */
    @RequestMapping(value = AppConstants.UPDATE_SITE, method = RequestMethod.POST)
    @ResponseBody
    public String updateSite(final HttpServletRequest request) throws Exception {
        SiteSearchVO objSiteVO = new SiteSearchVO();
        String strResult = null;
        try {
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_OBJID))) {
                objSiteVO.setStrSiteObjId(request
                        .getParameter(AppConstants.SITE_OBJID));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_TYPE))) {
                objSiteVO.setStrCreateType(request
                        .getParameter(AppConstants.SITE_EDITNEW_TYPE));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_STATUS))) {
                objSiteVO.setStrStatus(request
                        .getParameter(AppConstants.SITE_EDITNEW_STATUS));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_SHIPPING))) {
                objSiteVO.setStrPrefShipMethod(request
                        .getParameter(AppConstants.SITE_EDITNEW_SHIPPING));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_CUSTOMER))) {
                objSiteVO.setStrCustomer(request
                        .getParameter(AppConstants.SITE_EDITNEW_CUSTOMER));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_SITEID))) {
                objSiteVO.setStrSiteID(request
                        .getParameter(AppConstants.SITE_EDITNEW_SITEID));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_SITENAME))) {
                objSiteVO.setStrSiteName(request
                        .getParameter(AppConstants.SITE_EDITNEW_SITENAME));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_ADDRESS))) {
                objSiteVO.setPrimAddObjId(request
                        .getParameter(AppConstants.SITE_EDITNEW_ADDRESS));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_SHIPTO))) {
                objSiteVO.setShipAddObjId(request
                        .getParameter(AppConstants.SITE_EDITNEW_SHIPTO));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_BILLTO))) {
                objSiteVO.setBillAddObjId(request
                        .getParameter(AppConstants.SITE_EDITNEW_BILLTO));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_PHONE))) {
                objSiteVO.setStrCellPhone(request
                        .getParameter(AppConstants.SITE_EDITNEW_PHONE));
            }
            if (!RMDCommonUtility.isNullOrEmpty(request
                    .getParameter(AppConstants.SITE_EDITNEW_FAX))) {
                objSiteVO.setStrFax(request
                        .getParameter(AppConstants.SITE_EDITNEW_FAX));
            }
            strResult = siteService.updateSite(objSiteVO);
        } catch (Exception ex) {
            ex.printStackTrace();
            rmdWebLogger.error("Exception occured in updateSite method ", ex);
            RMDWebErrorHandler.handleException(ex);
            request.setAttribute(AppConstants.ERRORMSG,
                    AppConstants.UNKNOWN_EXCEPTION);
            throw ex;
        }
        return strResult;
    }

    /**
     * @return Map<String, Map<String, String>>
     * @throws RMDWebException
     * @Description * This method is used to fetch the values from lookup table
     *              to populate the Site Shipping,Site Status & SiteEdit Types
     *              dropdown.
     */
    @RequestMapping(value = AppConstants.GET_POPULATE_DATA)
    @ResponseBody
    public Map<String, List<String>> getPopulateData() throws RMDWebException {
        Map<String, List<String>> allSiteTypes = new TreeMap<String, List<String>>();
        try {
            allSiteTypes = siteService.getPopulateData();
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getPopulateData method ",
                    ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return allSiteTypes;
    }

    /**
     * 
     * @param
     * @return
     * @Description * This method is used for export selected data.
     * 
     */
    @RequestMapping(value = AppConstants.EXPORT_SITESCREEN, method = RequestMethod.POST)
    public void exportSiteScreenReport(final HttpServletRequest request,
            final HttpServletResponse response, final Locale locale)
            throws Exception {
        List<SiteSearchVO> objSiteSearchVOlst = new ArrayList<SiteSearchVO>();
        String csvContent = null;
        ServletOutputStream objServletOutputStream = null;
        BufferedInputStream objBufferedInputStream = null;
        BufferedOutputStream objBufferedOutputStream = null;
        try {
            objSiteSearchVOlst = getSites(request);
            csvContent = convertToCSVSiteScreenReport(objSiteSearchVOlst,
                    locale);
            response.setContentType(AppConstants.CONTENT_TYPE);
            response.setHeader(AppConstants.CONTENT,
                    AppConstants.ATTACH_FILENAME
                            + AppConstants.SITESCREEN_EXPORT_FILENAME);
            objServletOutputStream = response.getOutputStream();
            ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
                    csvContent.getBytes());
            objBufferedInputStream = new BufferedInputStream(
                    objByteArrayInputStream);
            objBufferedOutputStream = new BufferedOutputStream(
                    objServletOutputStream);
            byte[] byteArr = new byte[2048];
            int bytesread;
            while ((bytesread = objBufferedInputStream.read(byteArr, 0,
                    byteArr.length)) != -1) {
                objBufferedOutputStream.write(byteArr, 0, bytesread);
                objBufferedOutputStream.flush();
            }
        } catch (Exception e) {
            rmdWebLogger.error(
                    "Exception occured in exportSiteScreenReport method ", e);
            RMDWebErrorHandler.handleException(e);
        } finally {
            if (objBufferedInputStream != null) {
                objBufferedInputStream.close();
            }
            if (objBufferedOutputStream != null) {
                objBufferedOutputStream.close();
                objServletOutputStream.close();
                objServletOutputStream = null;
            }
        }
    }

    /**
     * 
     * @param
     * @return
     * @Description * This method is used to convert in CVS for export selected
     *              data.
     * 
     */
    private String convertToCSVSiteScreenReport(
            List<SiteSearchVO> objSiteSearchVOlst, Locale locale) {
        StringBuilder strBuffeHeader = new StringBuilder();
        String csvContent = null;
        try {
            strBuffeHeader.append(appContext.getMessage(
                    AppConstants.SITESCREEN_EXPORT_HEADER, null, locale));
            strBuffeHeader.append(RMDCommonConstants.NEWLINE);
            for (SiteSearchVO objSiteSearchVO : objSiteSearchVOlst) {
                if (null != objSiteSearchVO.getStrSiteID()) {
                    strBuffeHeader.append(AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE
                            + objSiteSearchVO.getStrSiteID()
                            + AppConstants.QUOTE
                            + RMDCommonConstants.COMMMA_SEPARATOR);
                } else {
                    strBuffeHeader.append(AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                            + RMDCommonConstants.COMMMA_SEPARATOR);
                }
                if (null != objSiteSearchVO.getStrSiteName()) {
                    strBuffeHeader.append(AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE
                            + objSiteSearchVO.getStrSiteName()
                            + AppConstants.QUOTE
                            + RMDCommonConstants.COMMMA_SEPARATOR);
                } else {
                    strBuffeHeader.append(AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                            + RMDCommonConstants.COMMMA_SEPARATOR);
                }
                if (null != objSiteSearchVO.getStrAddress()) {
                    strBuffeHeader.append(AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE
                            + objSiteSearchVO.getStrAddress()
                            + AppConstants.QUOTE
                            + RMDCommonConstants.COMMMA_SEPARATOR);
                } else {
                    strBuffeHeader.append(AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                            + RMDCommonConstants.COMMMA_SEPARATOR);
                }
                if (null != objSiteSearchVO.getStrCity()) {
                    strBuffeHeader.append(AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE
                            + objSiteSearchVO.getStrCity() + AppConstants.QUOTE
                            + RMDCommonConstants.COMMMA_SEPARATOR);
                } else {
                    strBuffeHeader.append(AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                            + RMDCommonConstants.COMMMA_SEPARATOR);
                }
                if (null != objSiteSearchVO.getStrState()) {
                    strBuffeHeader.append(AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE
                            + objSiteSearchVO.getStrState()
                            + AppConstants.QUOTE
                            + RMDCommonConstants.COMMMA_SEPARATOR);
                } else {
                    strBuffeHeader.append(AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                            + RMDCommonConstants.COMMMA_SEPARATOR);
                }
                if (null != objSiteSearchVO.getStrType()) {
                    strBuffeHeader.append(AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE
                            + objSiteSearchVO.getStrType() + AppConstants.QUOTE
                            + RMDCommonConstants.COMMMA_SEPARATOR);
                } else {
                    strBuffeHeader.append(AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
                            + RMDCommonConstants.COMMMA_SEPARATOR);
                }
                strBuffeHeader.append(RMDCommonConstants.NEWLINE);
            }
            csvContent = strBuffeHeader.toString();
        } catch (Exception exception) {
            rmdWebLogger.error("Convert To CSV SiteScreen Report" + exception);
        }
        return csvContent;
    }
}
