package com.ge.trans.rmd.cm.mvc.model;

public class HeatMap {
	private String color;
	private String rowId;
	private String cellId;
	private String className;

	public String getColor() {
		return color;
	}

	public void setColor(final String color) {
		this.color = color;
	}

	public String getRowId() {
		return rowId;
	}

	public void setRowId(final String rowId) {
		this.rowId = rowId;
	}

	public String getCellId() {
		return cellId;
	}

	public void setCellId(final String cellId) {
		this.cellId = cellId;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(final String className) {
		this.className = className;
	}
}
