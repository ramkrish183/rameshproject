package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

public class SummaryResponseVO {

	private List<DeliverSummaryVO> lstDelVO;
	private  List<AppendSummaryVO> lstAppVO;
	private  List<CloseSummaryVO> lstCloseVO;
	private  String error;
	
	public String getError() {
		return error;
	}

	public void setError(String error) {
		this.error = error;
	}
	
	/**
	 * @return the lstDelVO
	 */
	public List<DeliverSummaryVO> getLstDelVO() {
		return lstDelVO;
	}

	/**
	 * @param lstDelVO the lstDelVO to set
	 */
	public void setLstDelVO(List<DeliverSummaryVO> lstDelVO) {
		this.lstDelVO = lstDelVO;
	}

	/**
	 * @return the lstAppVO
	 */
	public List<AppendSummaryVO> getLstAppVO() {
		return lstAppVO;
	}

	/**
	 * @param lstAppVO the lstAppVO to set
	 */
	public void setLstAppVO(List<AppendSummaryVO> lstAppVO) {
		this.lstAppVO = lstAppVO;
	}

	/**
	 * @return the lstCloseVO
	 */
	public List<CloseSummaryVO> getLstCloseVO() {
		return lstCloseVO;
	}

	/**
	 * @param lstCloseVO the lstCloseVO to set
	 */
	public void setLstCloseVO(List<CloseSummaryVO> lstCloseVO) {
		this.lstCloseVO = lstCloseVO;
	}
	
}
