package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

import com.ge.trans.rmd.alert.valueobjects.ModelVO;

public class HeatMapResponseVO {

    /**
     * 
     */
    private List<AssetsVO> assets;
    private List<ModelVO> models;
    private List<FaultVO> faults;
    private List<FaultHeatMapVO> faultHeatMap;

    /**
     * @return the assets
     */
    public List<AssetsVO> getAssets() {
        return assets;
    }

    /**
     * @param assets
     *            the assets to set
     */
    public void setAssets(List<AssetsVO> assets) {
        this.assets = assets;
    }

    /**
     * @return the models
     */
    public List<ModelVO> getModels() {
        return models;
    }

    /**
     * @param models
     *            the models to set
     */
    public void setModels(List<ModelVO> models) {
        this.models = models;
    }

    /**
     * @return the faults
     */
    public List<FaultVO> getFaults() {
        return faults;
    }

    /**
     * @param faults
     *            the faults to set
     */
    public void setFaults(List<FaultVO> faults) {
        this.faults = faults;
    }

    /**
     * @return the faultHeatMap
     */
    public List<FaultHeatMapVO> getFaultHeatMap() {
        return faultHeatMap;
    }

    /**
     * @param faultHeatMap the faultHeatMap to set
     */
    public void setFaultHeatMap(List<FaultHeatMapVO> faultHeatMap) {
        this.faultHeatMap = faultHeatMap;
    }

 }
