package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import com.ge.trans.rmd.cm.service.FindCaseService;
import com.ge.trans.rmd.cm.valueobjects.FindCasesDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.FindCasesVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class FindCaseController extends RMDBaseController {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	private FindCaseService findCaseService;
	@Autowired
	ApplicationContext appContext;
	@Value("${" + RMDCommonConstants.DEFAULT_TIMEZONE_VALUE + "}")
	public String defaultTimezone;

	@RequestMapping(value = AppConstants.REQ_URI_VIEW_FIND_CASE, method = RequestMethod.GET)
	public String viewFindCasePage(final HttpServletRequest request)
			throws Exception {
		rmdWebLogger
				.debug("Inside FindCaseController Controller in viewFindCasePage Method");
		Calendar cal = Calendar.getInstance();
		final SimpleDateFormat fromDateFormat = new SimpleDateFormat(
				AppConstants.DATE_FORMAT_24HRS);
		String previousDate = null;
		String previousDateRange = null;
		previousDateRange = findCaseService.getFindCasesLookBakDays();
		previousDateRange = AppConstants.SYMBOL_MINUS + previousDateRange;
		cal.add(Calendar.MONTH, Integer.parseInt(previousDateRange));
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		previousDate = fromDateFormat.format(cal.getTime());
		request.setAttribute(AppConstants.FINDCASES_PREVOIUSDATE, previousDate);
		request.setAttribute(
				AppConstants.CASES_DEFAULT_RECORDS,
				findNumberOfRecords(AppConstants.FIND_CASES_TABLE_DEFAULT_RECORDS));
		return AppConstants.VIEW_FIND_CASE;
	}

	/**
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the FindCases Search Options By dropdown.
	 */
	@RequestMapping(value = AppConstants.GET_SEARCH_OPTIONS)
	public @ResponseBody
	Map<String, String> getfindCaseSearchOptions() throws RMDWebException {
		Map<String, String> allStatusMap = new LinkedHashMap<String, String>();
		try {
			allStatusMap = findCaseService.getfindCaseSearchOptions();
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getfindCaseSearchOptions method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allStatusMap;
	}

	/**
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the FindCases Filter Options By dropdown.
	 */
	@RequestMapping(value = AppConstants.GET_FILTER_OPTIONS)
	public @ResponseBody
	Map<String, String> getfindCaseFilterOptions() throws RMDWebException {
		Map<String, String> allStatusMap = new LinkedHashMap<String, String>();
		try {
			allStatusMap = findCaseService.getfindCaseFilterOptions();
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getfindCaseFilterOptions method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allStatusMap;
	}
	
	/**
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the RN Filter Options By dropdown.
	 */
	@RequestMapping(value = AppConstants.GET_RN_FILTER_OPTIONS)
	public @ResponseBody
	Map<String, String> getRNFilterOptions() throws RMDWebException {
		Map<String, String> allStatusMap = new LinkedHashMap<String, String>();
		try {
			allStatusMap = findCaseService.getRNFilterOptions();
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getfindCaseFilterOptions method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allStatusMap;
	}

	/**
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the FindCases Case Type dropdown.
	 */
	@RequestMapping(value = AppConstants.GET_CASE_TYPE)
	public @ResponseBody
	Map<String, String> getfindCaseCaseType() throws RMDWebException {
		Map<String, String> allStatusMap = new TreeMap<String, String>();
		try {
			allStatusMap = findCaseService.getfindCaseCaseType();
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getfindCaseFilterOptions method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allStatusMap;
	}

	/**
	 * 
	 * @param
	 * @return FindCasesDetailsVO
	 * @throws Exception
	 * @Description * This method is used to get the Cases.
	 * 
	 */
	@RequestMapping(value = AppConstants.GET_FIND_CASES, method = RequestMethod.POST)
	public @ResponseBody
	List<FindCasesDetailsVO> getFindCases(final HttpServletRequest request)
			throws Exception {
		String strError = null;
		List<FindCasesDetailsVO> objFindCasesDetailsVOlst = new ArrayList<FindCasesDetailsVO>();
		FindCasesVO objFindCasesVO = new FindCasesVO();
		FindCasesDetailsVO objFindCasesDetailsVO = new FindCasesDetailsVO();
		Map<String, String> findCasesErr = new HashMap<String, String>();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String defaultTimeZone = (String) request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		// validation
		strError = checkDateValidation(request);
		if (RMDCommonUtility.isNullOrEmpty(strError)) {
			if (!RMDCommonUtility.isNullOrEmpty(request
					.getParameter(AppConstants.FINDCASE_CUSTOMER))) {
				objFindCasesVO.setCustomerName(request
						.getParameter(AppConstants.FINDCASE_CUSTOMER));
			}
			if (!RMDCommonUtility.isNullOrEmpty(request
					.getParameter(AppConstants.FINDCASE_RNH))) {
				objFindCasesVO.setRoadNumberHeader(request
						.getParameter(AppConstants.FINDCASE_RNH));
			}
			if (!RMDCommonUtility.isNullOrEmpty(request
					.getParameter(AppConstants.FINDCASE_RN))) {
				objFindCasesVO.setRoadNumber(request
						.getParameter(AppConstants.FINDCASE_RN));
			}
			if (!RMDCommonUtility.isNullOrEmpty(request
					.getParameter(AppConstants.FINDCASE_SEARCH))) {
				objFindCasesVO.setSearchOption(request
						.getParameter(AppConstants.FINDCASE_SEARCH));
			}
			if (!RMDCommonUtility.isNullOrEmpty(request
					.getParameter(AppConstants.FINDCASE_FILTER))) {
				objFindCasesVO.setFilterOption(request
						.getParameter(AppConstants.FINDCASE_FILTER));
			}
			if (!RMDCommonUtility.isNullOrEmpty(request
					.getParameter(AppConstants.FINDCASE_CASETYPE))) {
				objFindCasesVO.setCaseType(request
						.getParameter(AppConstants.FINDCASE_CASETYPE));
			}
			if (!RMDCommonUtility.isNullOrEmpty(request
					.getParameter(AppConstants.FINDCASE_FILELD_VALUE))) {
				objFindCasesVO.setFieldValue(request
						.getParameter(AppConstants.FINDCASE_FILELD_VALUE));
			}
			if (!RMDCommonUtility.isNullOrEmpty(request
					.getParameter(AppConstants.FINDCASE_START_DATE))) {
				objFindCasesVO.setStartdate(request
						.getParameter(AppConstants.FINDCASE_START_DATE));
			}
			if (!RMDCommonUtility.isNullOrEmpty(request
					.getParameter(AppConstants.FINDCASE_END_DATE))) {
				objFindCasesVO.setEndDate(request
						.getParameter(AppConstants.FINDCASE_END_DATE));
			}
			if (!RMDCommonUtility.isNullOrEmpty(request
					.getParameter(AppConstants.FINDCASE_RN_FILTER_SELECTED))) {
				objFindCasesVO.setRoadNumberFilterSelected(request.getParameter(AppConstants.FINDCASE_RN_FILTER_SELECTED));
			}
			objFindCasesDetailsVOlst = findCaseService.getFindCases(objFindCasesVO,userVO.getTimeZone(),defaultTimeZone);
		} else {
			findCasesErr.put(strError, strError);
			objFindCasesDetailsVO.setFinCasesErr(findCasesErr);
			objFindCasesDetailsVOlst.add(objFindCasesDetailsVO);
		}
		return objFindCasesDetailsVOlst;
	}

	/**
	 * 
	 * @param
	 * @return
	 * @Description * This method is used for export selected data.
	 * 
	 */
	@RequestMapping(value = AppConstants.EXPORT_FINDCASES, method = RequestMethod.POST)
	public void exportFindCasesReport(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws Exception {
		List<FindCasesDetailsVO> objFindCasesDetailsVOlst = null;
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		try {
			objFindCasesDetailsVOlst = getFindCases(request);
			if (null != objFindCasesDetailsVOlst && !objFindCasesDetailsVOlst.isEmpty()) {    
				csvContent = convertToCSVFindCasesReport(objFindCasesDetailsVOlst,
						locale);
				response.setContentType(AppConstants.CONTENT_TYPE);
				response.setHeader(AppConstants.CONTENT,
						AppConstants.ATTACH_FILENAME
								+ AppConstants.FINDCASES_EXPORT_FILENAME);
				objServletOutputStream = response.getOutputStream();
				ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
						csvContent.getBytes());
				objBufferedInputStream = new BufferedInputStream(
						objByteArrayInputStream);
				objBufferedOutputStream = new BufferedOutputStream(
						objServletOutputStream);
				byte[] byteArr = new byte[2048];
				int bytesread;
				while ((bytesread = objBufferedInputStream.read(byteArr, 0,
						byteArr.length)) != -1) {
					objBufferedOutputStream.write(byteArr, 0, bytesread);
					objBufferedOutputStream.flush();
				}
			}
		} catch (Exception e) {
			rmdWebLogger.error(
					"Exception occured in exportFindCasesReport method ", e);
			RMDWebErrorHandler.handleException(e);
		} finally {
			if (null != objBufferedInputStream) {
				objBufferedInputStream.close();
			}
			if (null != objBufferedOutputStream) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}
		}
	}

	/**
	 * @param
	 * @Description:This method is used for looping through the list of Find
	 *                   Cases records and will covert to csv content
	 * @return: String
	 * @param:collectiveResponse,Locale locale
	 */
	private String convertToCSVFindCasesReport(
			List<FindCasesDetailsVO> listFindCasesDetailsReport, Locale locale) {
		StringBuffer strTechCasesBuffer = new StringBuffer();
		String csvContent = null;
		try {

			strTechCasesBuffer.append(appContext.getMessage(
					AppConstants.FINDCASES_REPORT_HEADER, null, locale));

			strTechCasesBuffer.append(RMDCommonConstants.NEWLINE);
			if (RMDCommonUtility
					.isCollectionNotEmpty(listFindCasesDetailsReport)) {
				for (FindCasesDetailsVO objFindCasesDetailsVO : listFindCasesDetailsReport) {

					strTechCasesBuffer
							.append(RMDCommonUtil
									.removeHtmlandNullValues(objFindCasesDetailsVO
											.getCaseID())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getTitle())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getCondition())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getStatus())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getContact())
									+ RMDCommonConstants.COMMMA_SEPARATOR);
					strTechCasesBuffer
							.append(RMDCommonUtil
									.removeHtmlandNullValues(objFindCasesDetailsVO
											.getCreationTime())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getCaseType())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getCustRNH())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getRn())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getQueue()));
					strTechCasesBuffer.append(RMDCommonConstants.NEWLINE);
				}

			}

			csvContent = strTechCasesBuffer.toString();
		} catch (Exception ex) {
			rmdWebLogger.error("Export to CSV convertToCSVFindCasesReport"
					+ ex.getMessage());
		}
		return csvContent;
	}

	/**
	 * 
	 * @param
	 * @return String
	 * @Description * This method is used for Validations.
	 * 
	 */
	public String checkDateValidation(final HttpServletRequest request)
			throws Exception {
		String strError = null;
		Date fromdate = null, todate = null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
				AppConstants.DATE_FORMAT_24HRS);
		String strFromDt = null;
		String strToDt = null;
		Date sysdate = new Date();
		try {
			strFromDt = request.getParameter(AppConstants.FINDCASE_START_DATE);
			strToDt = request.getParameter(AppConstants.FINDCASE_END_DATE);
			if ((null != strFromDt && !strFromDt.isEmpty())) {
				fromdate = simpleDateFormat.parse(strFromDt);
				if ((null != strToDt && !strToDt.isEmpty())) {
					todate = simpleDateFormat.parse(strToDt);
					if (todate.getTime() - fromdate.getTime() < 0) {
						strError = AppConstants.FINDCASES_START_END_DATE;
					}
				}
				if (sysdate.getTime() - fromdate.getTime() < 0) {
					strError = AppConstants.FINDCASES_START_FUTURE_DATE;
				}
			} else {
				strError = AppConstants.FINDCASES_START_DATE_REQUIRED;
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in checkDateValidation method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return strError;
	}
	
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, List<String>>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Customer Name and Road
	 *               Number Headers.
	 */
	@RequestMapping(value = AppConstants.GET_CUSTOMER_RNH)
	public @ResponseBody
	Map<String, List<String>> getCustNameRNH() throws RMDWebException {
		Map<String, List<String>> custNameRNHMap = new LinkedHashMap<String, List<String>>();
		try {
			custNameRNHMap = findCaseService.getCustNameRNH();
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getCustNameRNH() method - FindCaseController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return custNameRNHMap;
	}
	
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Road Number.
	 */
	@RequestMapping(value = AppConstants.GET_ROAD_NUM)
	public @ResponseBody
	Map<String, String> getRoadNumbers(final HttpServletRequest request)
			throws RMDWebException {
		Map<String, String> roadNumberMap = new TreeMap<String, String>();
		final HttpSession session = request.getSession(false);
		String customerName = null;
		String roadNumberHeader = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(request
					.getParameter(AppConstants.FINDCASE_CUSTOMER))) {
				customerName = request
						.getParameter(AppConstants.FINDCASE_CUSTOMER);
			}
			if (!RMDCommonUtility.isNullOrEmpty(request
					.getParameter(AppConstants.FINDCASE_RNH))) {
				roadNumberHeader = request
						.getParameter(AppConstants.FINDCASE_RNH);
			}
			roadNumberMap = findCaseService.getRoadNumbers(customerName,
					roadNumberHeader);
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getRoadNumbers() method - FindCaseController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return roadNumberMap;
	}
	
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Road Number.
	 */
	@RequestMapping(value = AppConstants.GET_ROAD_NUM_WITH_FILTER)
	public @ResponseBody
	Map<String, String> getRoadNumbersWithFilter(@RequestParam(value = AppConstants.FINDCASE_CUSTOMER) String customerName,
			@RequestParam(value = AppConstants.FINDCASE_RNH) String roadNumberHeader,
			@RequestParam(value = AppConstants.RN_SEARCH_STRING) String rnSearchString,
			@RequestParam(value = AppConstants.RN_FILTER) String rnFilter, HttpServletRequest request)
			throws RMDWebException {
		Map<String, String> roadNumberMap = new TreeMap<String, String>();
		final HttpSession session = request.getSession(false);
		
		try {
			roadNumberMap = findCaseService.getRoadNumbers(customerName,
					roadNumberHeader,rnSearchString,rnFilter);
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getRoadNumbers() method - FindCaseController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return roadNumberMap;
	}
	
}
