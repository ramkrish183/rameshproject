package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

import com.ge.trans.rmd.services.locovision.valueobjects.LDVRGeofenceType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRTimeFrameType;


/**
 * Template Response VO to list the templates
 */

public class LDVRTemplateDetailsVO {

	private List<Integer> cameraList = null;
	private String requestedEndTime = null;
	private Long importance = null;
	private Long deletionType = null;
	private LDVRTimeFrameVO timeframe = null;
	private LDVRGeofenceResponseVO geoZone = null;
	private LDVREventVO event = null;
	public List<Integer> getCameraList() {
		return cameraList;
	}
	public void setCameraList(List<Integer> cameraList) {
		this.cameraList = cameraList;
	}
	public String getRequestedEndTime() {
		return requestedEndTime;
	}
	public void setRequestedEndTime(String requestedEndTime) {
		this.requestedEndTime = requestedEndTime;
	}
	public Long getImportance() {
		return importance;
	}
	public void setImportance(Long importance) {
		this.importance = importance;
	}
	public Long getDeletionType() {
		return deletionType;
	}
	public void setDeletionType(Long deletionType) {
		this.deletionType = deletionType;
	}
	public LDVRTimeFrameVO getTimeframe() {
		return timeframe;
	}
	public void setTimeframe(LDVRTimeFrameVO timeframe) {
		this.timeframe = timeframe;
	}	

	public LDVRGeofenceResponseVO getGeoZone() {
		return geoZone;
	}
	public void setGeoZone(LDVRGeofenceResponseVO geoZone) {
		this.geoZone = geoZone;
	}
	public LDVREventVO getEvent() {
		return event;
	}
	public void setEvent(LDVREventVO event) {
		this.event = event;
	}
	
}
