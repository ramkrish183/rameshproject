package com.ge.trans.rmd.cm.valueobjects;

public class VisualizationDetailsBean {
	 private String rxObjid;
	 private String customerId;
	 private String assetGroupName;
	 private String assetNumber;
	 private String source;
	 private String sourceType;
	 private String fromDate;
	 private String toDate;	 
	 private String mpNumbers;
	 private String userLanguage;
	 private String controllerCfg;
	 private String dateFormat;
	 private String controllerType;	 
	 private String hidddenfaultCode;
	 private String notchOperator;
	 private String notchValue;
	 private String ambientTmpOp;
	 private String ambientTmpVal1;
	 private String ambientTmpVal2;
	 private String engGHPOp;
	 private String engGHPVal1;
	 private String engGHPVal2;
	 private String engSpeedOp;
	 private String engSpeedVal1;
	 private String engSpeedVal2;
	 private String locoStateValue;
	 private String sourceTypeCd;
	 private String family;
	 private String assetObjid;	 
	 private String barometricPressOp;
	 private String barometricPressVal1;
	 private String barometricPressVal2;
	 private String oilInletOp;
	 private String oilInletVal1;
	 private String oilInletVal2;
	 private String hpAvailableOp;
	 private String hpAvailableVal1;
	 private String hpAvailableVal2;
	 private String noOfDays;
	 
	public String getRxObjid() {
		return rxObjid;
	}
	public void setRxObjid(String rxObjid) {
		this.rxObjid = rxObjid;
	}
	public String getBarometricPressOp() {
		return barometricPressOp;
	}
	public void setBarometricPressOp(String barometricPressOp) {
		this.barometricPressOp = barometricPressOp;
	}
	public String getBarometricPressVal1() {
		return barometricPressVal1;
	}
	public void setBarometricPressVal1(String barometricPressVal1) {
		this.barometricPressVal1 = barometricPressVal1;
	}
	public String getBarometricPressVal2() {
		return barometricPressVal2;
	}
	public void setBarometricPressVal2(String barometricPressVal2) {
		this.barometricPressVal2 = barometricPressVal2;
	}
	public String getOilInletOp() {
		return oilInletOp;
	}
	public void setOilInletOp(String oilInletOp) {
		this.oilInletOp = oilInletOp;
	}
	public String getOilInletVal1() {
		return oilInletVal1;
	}
	public void setOilInletVal1(String oilInletVal1) {
		this.oilInletVal1 = oilInletVal1;
	}
	public String getOilInletVal2() {
		return oilInletVal2;
	}
	public void setOilInletVal2(String oilInletVal2) {
		this.oilInletVal2 = oilInletVal2;
	}
	public String getHpAvailableOp() {
		return hpAvailableOp;
	}
	public void setHpAvailableOp(String hpAvailableOp) {
		this.hpAvailableOp = hpAvailableOp;
	}
	public String getHpAvailableVal1() {
		return hpAvailableVal1;
	}
	public void setHpAvailableVal1(String hpAvailableVal1) {
		this.hpAvailableVal1 = hpAvailableVal1;
	}
	public String getHpAvailableVal2() {
		return hpAvailableVal2;
	}
	public void setHpAvailableVal2(String hpAvailableVal2) {
		this.hpAvailableVal2 = hpAvailableVal2;
	}
	public String getAssetObjid() {
		return assetObjid;
	}
	public void setAssetObjid(String assetObjid) {
		this.assetObjid = assetObjid;
	}
	public String getFamily() {
		return family;
	}
	public void setFamily(String family) {
		this.family = family;
	}
	public String getSourceTypeCd() {
		return sourceTypeCd;
	}
	public void setSourceTypeCd(String sourceTypeCd) {
		this.sourceTypeCd = sourceTypeCd;
	}
	public String getControllerType() {
		return controllerType;
	}
	public void setControllerType(String controllerType) {
		this.controllerType = controllerType;
	}
	public String getDateFormat() {
		return dateFormat;
	}
	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}
	public String getControllerCfg() {
		return controllerCfg;
	}
	public void setControllerCfg(String controllerCfg) {
		this.controllerCfg = controllerCfg;
	}
	public String getUserLanguage() {
		return userLanguage;
	}
	public void setUserLanguage(String userLanguage) {
		this.userLanguage = userLanguage;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getAssetGroupName() {
		return assetGroupName;
	}
	public void setAssetGroupName(String assetGroupName) {
		this.assetGroupName = assetGroupName;
	}
	public String getAssetNumber() {
		return assetNumber;
	}
	public void setAssetNumber(String assetNumber) {
		this.assetNumber = assetNumber;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getSourceType() {
		return sourceType;
	}
	public void setSourceType(String sourceType) {
		this.sourceType = sourceType;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}	
	public String getMpNumbers() {
		return mpNumbers;
	}
	public void setMpNumbers(String mpNumbers) {
		this.mpNumbers = mpNumbers;
	}
		
	public String getNotchOperator() {
		return notchOperator;
	}
	public String getHidddenfaultCode() {
		return hidddenfaultCode;
	}
	public void setHidddenfaultCode(String hidddenfaultCode) {
		this.hidddenfaultCode = hidddenfaultCode;
	}
	public String getAmbientTmpOp() {
		return ambientTmpOp;
	}
	public void setAmbientTmpOp(String ambientTmpOp) {
		this.ambientTmpOp = ambientTmpOp;
	}
	public String getAmbientTmpVal1() {
		return ambientTmpVal1;
	}
	public void setAmbientTmpVal1(String ambientTmpVal1) {
		this.ambientTmpVal1 = ambientTmpVal1;
	}
	public String getAmbientTmpVal2() {
		return ambientTmpVal2;
	}
	public void setAmbientTmpVal2(String ambientTmpVal2) {
		this.ambientTmpVal2 = ambientTmpVal2;
	}
	public String getEngGHPOp() {
		return engGHPOp;
	}
	public void setEngGHPOp(String engGHPOp) {
		this.engGHPOp = engGHPOp;
	}
	public String getEngGHPVal1() {
		return engGHPVal1;
	}
	public void setEngGHPVal1(String engGHPVal1) {
		this.engGHPVal1 = engGHPVal1;
	}
	public String getEngGHPVal2() {
		return engGHPVal2;
	}
	public void setEngGHPVal2(String engGHPVal2) {
		this.engGHPVal2 = engGHPVal2;
	}
	public String getEngSpeedOp() {
		return engSpeedOp;
	}
	public void setEngSpeedOp(String engSpeedOp) {
		this.engSpeedOp = engSpeedOp;
	}
	public String getEngSpeedVal1() {
		return engSpeedVal1;
	}
	public void setEngSpeedVal1(String engSpeedVal1) {
		this.engSpeedVal1 = engSpeedVal1;
	}
	public String getEngSpeedVal2() {
		return engSpeedVal2;
	}
	public void setEngSpeedVal2(String engSpeedVal2) {
		this.engSpeedVal2 = engSpeedVal2;
	}
	public void setNotchOperator(String notchOperator) {
		this.notchOperator = notchOperator;
	}
	public String getNotchValue() {
		return notchValue;
	}
	public void setNotchValue(String notchValue) {
		this.notchValue = notchValue;
	}
	public String getLocoStateValue() {
		return locoStateValue;
	}
	public void setLocoStateValue(String locoStateValue) {
		this.locoStateValue = locoStateValue;
	}
	public String getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(String noOfDays) {
		this.noOfDays = noOfDays;
	}
	
	
	
	
	
	
	
	
	 
	 
	 
	
}
