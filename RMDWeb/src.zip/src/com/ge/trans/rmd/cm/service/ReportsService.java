package com.ge.trans.rmd.cm.service;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.codehaus.jettison.json.JSONException;

import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.valueobjects.ComStatusVO;
import com.ge.trans.rmd.common.valueobjects.MineVO;
import com.ge.trans.rmd.common.valueobjects.ReportsRxVO;
import com.ge.trans.rmd.common.valueobjects.ReportsTruckEventsVO;
import com.ge.trans.rmd.common.valueobjects.TruckGraphVO;
import com.ge.trans.rmd.common.valueobjects.TruckVO;
import com.ge.trans.rmd.exception.RMDException;

public interface ReportsService {
	/**
	 * Added by Koushik for OHV Reports
	 * @param customerId
	 * @return
	 * @throws GenericAjaxException
	 * @throws RMDWebException
	 */
	public MineVO getMine(String customerId, HttpServletRequest request) throws GenericAjaxException, RMDWebException;
	
	/**
	 * Added by Koushik for OHV Reports
	 * This method is used to get the list of recommendations for the given truck
	 * @param customerId
	 * @param mineId
	 * @param truckId
	 * @param rxType
	 * @return List of recommendations
	 * @throws RMDWebException 
	 * @throws GenericAjaxException 
	 */
	List<ReportsRxVO> getReportsRx(String mineId, String truckId, String rxType,String urgency, String preferredTimezone) throws GenericAjaxException, RMDWebException;
	
	/**
	 * Added by Koushik for OHV Reports
	 * This method is used to get the list of truck events for the given truck
	 * @param customerId
	 * @param mineId
	 * @param truckId
	 * @param rxType
	 * @return
	 * @throws GenericAjaxException
	 * @throws RMDWebException
	 */
	List<ReportsTruckEventsVO> getReportsTruckEvents(String mineId, String truckId, String preferredTimezone) throws GenericAjaxException, RMDWebException;
	
	/**
	 * 
	 * @param mineId
	 * @param truckId
	 * @return
	 */
	public TruckVO getTruckInfo(String mineId, String truckId, HttpServletRequest request) throws GenericAjaxException, RMDWebException;
		
	/**
	 * 
	 * @param mineId
	 * @param truckId
	 * @return
	 */
	public ComStatusVO getComStatus(String mineId, String truckId) throws GenericAjaxException, RMDWebException;

	/**
	 * 
	 * @param customer
	 * @throws RMDException
	 */
	public List<ReportsTruckEventsVO> getTopMineEvents(String customer , boolean geLevelReport ) throws RMDWebException;
	
	/**
	 * 
	 * @param mineId
	 * @param truckId
	 * @param fromDate
	 * @param toDate
	 * @return
	 * @throws RMDWebException
	 */
	public TruckGraphVO getTruckGraphData(String mineId, String truckId, int period, String preferredTimezone) throws RMDWebException;
	
	/**
	 * 
	 * @param mineId
	 * @param truckId
	 * @param fromDate
	 * @param toDate
	 * @param isAvgCalc
	 * @return
	 * @throws GenericAjaxException
	 * @throws RMDWebException
	 */
	List<String> getTruckVariablesParam(String mineId, String truckId, String fromDate, String toDate, boolean isAvgCalc)
            throws GenericAjaxException, RMDWebException;
	
	/**
	 * Added by Murali D for OHV Reports
	 * This method is used to get Mine PDF Document
	 * @param document
	 * @param jsonStr
	 * @return
	 * @throws IOException 
	 * @throws JSONException
	 * @throws RMDWebException 
	 * @throws GenericAjaxException 
	 */
	PDDocument getMinePdfDocument(PDDocument document,String jsonStr) throws IOException, JSONException, GenericAjaxException, RMDWebException;
	
	/**
	 * Added by Murali D for OHV Reports
	 * This method is used to get Mine PDF Document
	 * @param document
	 * @param jsonStr
	 * @return
	 * @throws IOException 
	 * @throws JSONException
	 * @throws RMDWebException 
	 * @throws GenericAjaxException 
	 */
	PDDocument getTruckPdfDocument(PDDocument document,String jsonStr) throws IOException, JSONException, GenericAjaxException, RMDWebException;
	
	Map<String, List<String>> getTruckVariablesParamList(String mineId, String truckId, boolean isAvgCalc)
            throws GenericAjaxException, RMDWebException;
	
	Map<String, List<String>> getTruckVariablesParamListScheduler(String mineId, String truckId, boolean isAvgCalc)
            throws GenericAjaxException, RMDWebException;
}
