package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.commons.collections.CollectionUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.ActivePreservationDataRequestVO;
import com.ge.trans.rmd.cm.valueobjects.ActivePreservationDataResponseVO;
import com.ge.trans.rmd.cm.valueobjects.CameraDetailsRequestVO;
import com.ge.trans.rmd.cm.valueobjects.CameraDetailsResponseVO;
import com.ge.trans.rmd.cm.valueobjects.CheckActiveLDVRPreservationRequestVO;
import com.ge.trans.rmd.cm.valueobjects.CheckActiveLDVRPreservationResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetCriteriaVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRMessageHistoryRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRMessageHistoryResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRMessageVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRPreservationRequestTemplateVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRPreservationRetriveTemplateInfo;
import com.ge.trans.rmd.cm.valueobjects.LDVRRequestVO;
import com.ge.trans.rmd.cm.valueobjects.RemoveTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.RemoveTemplateResponseVO;
import com.ge.trans.rmd.cm.valueobjects.RemoveTemplateStatusDetails;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.locovision.valueobjects.ActivePreservationDataRequestType;
import com.ge.trans.rmd.services.locovision.valueobjects.ActivePreservationDataResponseType;
import com.ge.trans.rmd.services.locovision.valueobjects.CameraDetailsResponseType;
import com.ge.trans.rmd.services.locovision.valueobjects.CheckActiveLDVRPreservationRequestType;
import com.ge.trans.rmd.services.locovision.valueobjects.CheckActiveLDVRPreservationResponseType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRActiveServices;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRAssetCriteriaType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRAssetSnapshotRequestType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRAssetSnapshotResponseType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRMessageHistoryRequestType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRMessageHistoryResponseType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRMessageType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRPreservationRequestTemplate;
import com.ge.trans.rmd.services.locovision.valueobjects.RemoveTemplateRequestType;
import com.ge.trans.rmd.services.locovision.valueobjects.RemoveTemplateResponseType;
import com.ge.trans.rmd.services.locovision.valueobjects.RemoveTemplateStatus;
import com.ge.trans.rmd.services.locovision.valueobjects.SendMessageRequestType;
import com.ge.trans.rmd.services.locovision.valueobjects.SendMessageResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.sun.jersey.core.util.MultivaluedMapImpl;


@Service
public class LDVRRequestsServiceImpl extends RMDBaseServiceImpl implements
		LDVRRequestsService {

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private WebServiceInvoker webServiceInvoker;
	
	@Autowired
	private AuthorizationService authorizationService;
	
	@Value("${" + AppConstants.LDVR_GET_NUM_CAMERAS_URL + "}")
	String mcsGetNumCamerasURL;
	@Value("${" + AppConstants.HEALH_CHECK_SEND_MESSAGE_SERVICE_USERNAME + "}")
	String mcsGetNumCamerasUsername;
	@Value("${" + AppConstants.HEALH_CHECK_SEND_MESSAGE_SERVICE_PASSWORD + "}")
	String mcsGetNumCamerasPassowrd;

	@Value("${" + AppConstants.LDVR_MCS_GET_ACTIVE_PRESERVATION_DATA_URL + "}")
	String getActivePreservationDataURL;

	@Value("${" + AppConstants.LDVR_MCS_REMOVE_TEMPLATE_URL + "}")
	String removeTemplateURL;

	@Value("${"
			+ AppConstants.LDVR_MCS_CHECK_ACTIVE_LDVR_PRESERVATION_REQUEST_URL
			+ "}")
	String checkActiveLDVRPreservationRequestsURL;

	@Value("${" + AppConstants.LDVR_SEND_MESSAGE_SERVICE_URL + "}")
	String sendMessageURL;

	@Value("${" + AppConstants.LDVR_MCS_GET_MESSAGE_HISTORY + "}")
	String ldvrMessageHistoryURL;

	@Value("${" + AppConstants.LDVR_MCS_GET_ASSET_SNAPSHOT_URL + "}")
	String ldvrassetSnapshotURL;
		
	public String submitLDVRRequest(LDVRRequestVO lcvRequestVO)
			throws RMDWebException, Exception {

		rmdWebLogger
				.info("Inside LDVRRequestsServiceImpl in submitLDVRRequest Method Starts");
		String messageOutId = null;
		try {

			SendMessageRequestType sendMessageRequest = new SendMessageRequestType();
			sendMessageRequest
					.setApplicationId(RMDCommonConstants.LDVR_MCS_APPLICATION_ID);
			sendMessageRequest.setMessageId(lcvRequestVO.getMessageId());
			sendMessageRequest.setAssetOwnerId(lcvRequestVO.getAssetOwnerId());
			sendMessageRequest.setRoadInitial(lcvRequestVO.getRoadInitial());
			sendMessageRequest.setRoadNumber(lcvRequestVO.getRoadNumber());
			sendMessageRequest
					.setRequestorName(lcvRequestVO.getRequestorName());
			sendMessageRequest.setDevice(lcvRequestVO.getDevice());
			sendMessageRequest.setInternalMemory(lcvRequestVO
					.getInternalMemory());
			sendMessageRequest.setExternalMemory(lcvRequestVO
					.getExternalMemory());
			sendMessageRequest.setStartTime(lcvRequestVO.getStartTime());
			sendMessageRequest.setEndTime(lcvRequestVO.getEndTime());
			sendMessageRequest.setSelectedCameras(lcvRequestVO
					.getSelectedCameras());
			sendMessageRequest.setRequestTitle(lcvRequestVO.getRequestTitle());
			sendMessageRequest.setDeletionType(lcvRequestVO.getDeletionType());
			sendMessageRequest.setImportance(lcvRequestVO.getImportance());

			ObjectWriter ow = new ObjectMapper().writer()
					.withDefaultPrettyPrinter();
			String requestJson = ow.writeValueAsString(sendMessageRequest);

			rmdWebLogger
					.info("Inside LDVRRequestsServiceImpl calling sendMessageService ::: "
							+ sendMessageURL);
			rmdWebLogger.info("sendMessageService Request ::: " + requestJson);

			SendMessageResponseType sendMessageResponseType = (SendMessageResponseType) webServiceInvoker
					.postMCSWebService(mcsGetNumCamerasUsername,
							mcsGetNumCamerasPassowrd, sendMessageURL,
							requestJson, SendMessageResponseType.class);

			if (sendMessageResponseType != null) {
				messageOutId = sendMessageResponseType.getMessageOutId();
			}
			rmdWebLogger.info("Response from MCS ::: " + messageOutId);

		} catch (RMDWebException rmdEx) {			
			String errorMsgCustom = getLookupValueForError(rmdEx.getErrorCode(), rmdEx.getErrorType());
			if(!RMDCommonUtility.isNullOrEmpty(errorMsgCustom)){
				rmdEx.setErrorType(errorMsgCustom);
			}
			rmdWebLogger.error(
					"Exception occured in submitLDVRRequest method ", rmdEx);
			throw rmdEx;

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in submitLDVRRequest method ", ex);
			throw ex;
		}
		rmdWebLogger
				.info("Inside LDVRRequestsServiceImpl in submitLDVRRequest Method Ends");

		return messageOutId;
	}

	
	public CameraDetailsResponseVO getLDVRCameraDetails(
			CameraDetailsRequestVO cameraDetailsRequestVO)
			throws RMDWebException, Exception {
		rmdWebLogger
				.info("Inside LDVRRequestsServiceImpl in getLDVRCameraDetails Method");

		CameraDetailsResponseVO cameraDetailsResponseVO = new CameraDetailsResponseVO();

		try {
			final MultivaluedMap<String, String> queryParams = new MultivaluedMapImpl();
			if (null != cameraDetailsRequestVO) {
				queryParams.putSingle(AppConstants.LDVR_ASSET_OWNERID,
						cameraDetailsRequestVO.getAssetOwnerId());
				queryParams.putSingle(AppConstants.LDVR_ROAD_INITIAL,
						cameraDetailsRequestVO.getRoadInitial());
				queryParams.putSingle(AppConstants.LDVR_ROAD_NUMBER,
						cameraDetailsRequestVO.getRoadNumber());
				queryParams.putSingle(AppConstants.LDVR_DEVICE,
						cameraDetailsRequestVO.getDevice());

			rmdWebLogger
					.info("Inside LDVRRequestsServiceImpl calling getLDVRCameraDetails ::: "
							+ mcsGetNumCamerasURL);
			rmdWebLogger.info("LDVRCameraDetails Request ::: "
					+ cameraDetailsRequestVO.toString());
			}

			CameraDetailsResponseType cameraDetailsResponseType = (CameraDetailsResponseType) webServiceInvoker
					.getMCSWebService(mcsGetNumCamerasUsername,
							mcsGetNumCamerasPassowrd, mcsGetNumCamerasURL,
							queryParams, CameraDetailsResponseType.class);

			if (null != cameraDetailsResponseType) {
				cameraDetailsResponseVO
						.setAssetOwnerId(cameraDetailsResponseType
								.getAssetOwnerId());
				cameraDetailsResponseVO
						.setRoadInitial(cameraDetailsResponseType
								.getRoadInitial());
				cameraDetailsResponseVO.setDevice(cameraDetailsResponseType
						.getDevice());
				cameraDetailsResponseVO
						.setNumOfCameras(cameraDetailsResponseType
								.getNumOfCameras());
				rmdWebLogger.info("Response getLDVRCameraDetails ::: "
						+ cameraDetailsResponseType.toString());

			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"Exception occured in getLDVRCameraDetails method ", rmdEx);
			throw rmdEx;

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLDVRCameraDetails method ", ex);
			throw ex;
		}
		rmdWebLogger
				.info("Inside LDVRRequestsServiceImpl in getLDVRCameraDetails Method Done");

		return cameraDetailsResponseVO;
	}

	public CheckActiveLDVRPreservationResponseVO checkActiveLDVRPreservationRequests(
			CheckActiveLDVRPreservationRequestVO checkActiveLDVRPreservationRequestVO)
			throws RMDWebException, Exception {
		rmdWebLogger
				.info("Inside LDVRRequestsServiceImpl in CheckActiveLDVRPreservationRequests Method");
		rmdWebLogger.info("CameraDetailsRequestVO is: "
				+ checkActiveLDVRPreservationRequestVO.toString());
		CheckActiveLDVRPreservationResponseVO checkActiveLDVRPreservationResponseVO = null;
		try {
			CheckActiveLDVRPreservationRequestType checkActiveLDVRPreservationRequestType = new CheckActiveLDVRPreservationRequestType();
			checkActiveLDVRPreservationRequestType
					.setAssetOwnerId(checkActiveLDVRPreservationRequestVO
							.getAssetOwnerId());
			checkActiveLDVRPreservationRequestType
					.setDevice(checkActiveLDVRPreservationRequestVO.getDevice());
			checkActiveLDVRPreservationRequestType
					.setRoadInitial(checkActiveLDVRPreservationRequestVO
							.getRoadInitial());
			checkActiveLDVRPreservationRequestType
					.setRoadNumber(checkActiveLDVRPreservationRequestVO
							.getRoadNumber());

			ObjectWriter ow = new ObjectMapper().writer()
					.withDefaultPrettyPrinter();
			String inputJson = ow
					.writeValueAsString(checkActiveLDVRPreservationRequestType);
			rmdWebLogger
					.info("Inside LDVRRequestsServiceImpl calling checkActiveLDVRPreservationRequests ::: "
							+ checkActiveLDVRPreservationRequestsURL);
			rmdWebLogger
					.info("checkActiveLDVRPreservationRequests Request ::: "
							+ inputJson);

			checkActiveLDVRPreservationResponseVO = new CheckActiveLDVRPreservationResponseVO();
			CheckActiveLDVRPreservationResponseType checkActiveLDVRPreservationResponseType;
			checkActiveLDVRPreservationResponseType = (CheckActiveLDVRPreservationResponseType) webServiceInvoker
					.postMCSWebService(mcsGetNumCamerasUsername,
							mcsGetNumCamerasPassowrd,
							checkActiveLDVRPreservationRequestsURL, inputJson,
							CheckActiveLDVRPreservationResponseType.class);
			checkActiveLDVRPreservationResponseVO
					.setAssetOwnerId(checkActiveLDVRPreservationResponseType
							.getAssetOwnerId());
			checkActiveLDVRPreservationResponseVO
					.setDevice(checkActiveLDVRPreservationResponseType
							.getDevice());
			checkActiveLDVRPreservationResponseVO
					.setRoadInitial(checkActiveLDVRPreservationResponseType
							.getRoadInitial());
			checkActiveLDVRPreservationResponseVO
					.setRoadNumber(checkActiveLDVRPreservationResponseType
							.getRoadNumber());
			checkActiveLDVRPreservationResponseVO
					.setActiveLDVRLimitExceeded(checkActiveLDVRPreservationResponseType
							.getActiveLDVRLimitExceeded());
			checkActiveLDVRPreservationResponseVO
					.setActiveLDVRMaxLimit(checkActiveLDVRPreservationResponseType
							.getActiveLDVRMaxLimit());
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("Exception occured in checkActiveLDVRPreservationRequests method ",
							rmdEx);
			throw rmdEx;

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in checkActiveLDVRPreservationRequests method ",
							ex);
			throw ex;
		}
		rmdWebLogger
				.info("Inside LDVRRequestsServiceImpl in checkActiveLDVRPreservationRequests Method Done");

		return checkActiveLDVRPreservationResponseVO;
	}

	public ActivePreservationDataResponseVO getActivePreservationData(
			ActivePreservationDataRequestVO activePreservationDataRequestVO)
			throws RMDWebException, Exception {

		rmdWebLogger
				.info("Inside LDVRRequestsServiceImpl in getActivePreservationData Method");

		ActivePreservationDataResponseVO activePreservationDataResponseVO = null;

		try {
			ActivePreservationDataRequestType activePreservationDataRequestType = new ActivePreservationDataRequestType();
			activePreservationDataRequestType
					.setAssetOwnerId(activePreservationDataRequestVO
							.getAssetOwnerId());
			activePreservationDataRequestType
					.setRoadInitial(activePreservationDataRequestVO
							.getRoadInitial());
			activePreservationDataRequestType
					.setRoadNumber(activePreservationDataRequestVO
							.getRoadNumber());
			activePreservationDataRequestType
					.setDevice(activePreservationDataRequestVO.getDevice());

			ObjectWriter ow = new ObjectMapper().writer()
					.withDefaultPrettyPrinter();
			String inputJson = ow
					.writeValueAsString(activePreservationDataRequestType);

			rmdWebLogger
					.info("Inside LDVRRequestsServiceImpl calling getActivePreservationData ::: "
							+ getActivePreservationDataURL);
			rmdWebLogger.info("getActivePreservationData Request ::: "
					+ inputJson);

			ActivePreservationDataResponseType activePreservationDataResponseType = (ActivePreservationDataResponseType) webServiceInvoker
					.postMCSWebService(mcsGetNumCamerasUsername,
							mcsGetNumCamerasPassowrd,
							getActivePreservationDataURL, inputJson,
							ActivePreservationDataResponseType.class);

			activePreservationDataResponseVO = new ActivePreservationDataResponseVO();
			activePreservationDataResponseVO
					.setActivePreservationRequests(activePreservationDataResponseType
							.getActivePreservationRequests());
			activePreservationDataResponseVO
					.setAssetOwnerId(activePreservationDataResponseType
							.getAssetOwnerId());
			activePreservationDataResponseVO
					.setDevice(activePreservationDataResponseType.getDevice());
			activePreservationDataResponseVO
					.setPreservationQueueUtilizationDt(activePreservationDataResponseType
							.getPreservationQueueUtilizationDt());
			activePreservationDataResponseVO
					.setQueueUtilization(activePreservationDataResponseType
							.getQueueUtilization());
			activePreservationDataResponseVO
					.setRecordingDate(activePreservationDataResponseType
							.getRecordingDate());
			activePreservationDataResponseVO
					.setRecordingStatus(activePreservationDataResponseType
							.getRecordingStatus());
			activePreservationDataResponseVO
					.setRoadInitial(activePreservationDataResponseType
							.getRoadInitial());
			activePreservationDataResponseVO
					.setRoadNumber(activePreservationDataResponseType
							.getRoadNumber());
			activePreservationDataResponseVO
					.setSectionTitle(activePreservationDataResponseType
							.getSectionTitle());
			rmdWebLogger.info("Fetched object is.act:"
					+ activePreservationDataResponseVO.getSectionTitle() + ":"
					+ activePreservationDataResponseVO.getRecordingStatus());
			LDVRPreservationRequestTemplateVO template;
			LDVRPreservationRetriveTemplateInfo templateInfo;
			List<LDVRPreservationRequestTemplateVO> list = new ArrayList<LDVRPreservationRequestTemplateVO>();
			for (LDVRPreservationRequestTemplate wsTemplate : activePreservationDataResponseType
					.getActivePreservationTemplates()) {
				template = new LDVRPreservationRequestTemplateVO();

				template.setComment(wsTemplate.getComment());
				template.setComplete(wsTemplate.getComplete());
				template.setFilesPreserved(wsTemplate.getFilesPreserved());
				template.setNumVer(wsTemplate.getNumVer());
				template.setLastUpdatedBy(wsTemplate.getLastUpdatedBy());
				template.setOffBoardStatus(wsTemplate.getOffBoardStatus());
				template.setRequestedEndTime(wsTemplate.getRequestedEndTime());
				template.setRequestedStartTime(wsTemplate
						.getRequestedStartTime());
				template.setTemplateObjId(wsTemplate.getTemplateObjId());

				template.setTitle(wsTemplate.getTitle());

				templateInfo = new LDVRPreservationRetriveTemplateInfo();
				templateInfo
						.setComplete(wsTemplate
								.getlDVRPreservationRetriveTemplateInfo()
								.getComplete());
				templateInfo
						.setDeletion(wsTemplate
								.getlDVRPreservationRetriveTemplateInfo()
								.getDeletion());
				templateInfo.setLastUpdatedBy(wsTemplate
						.getlDVRPreservationRetriveTemplateInfo()
						.getLastUpdatedBy());
				if(!RMDCommonUtility.isNullOrEmpty(wsTemplate
						.getlDVRPreservationRetriveTemplateInfo()
						.getLastUpdatedDate())){
					templateInfo.setLastUpdatedDate(RMDCommonUtility
							.convertDateFormatTimezone(wsTemplate
									.getlDVRPreservationRetriveTemplateInfo()
									.getLastUpdatedDate(),
									RMDCommonConstants.MMddyyyyhhmma,
									RMDCommonConstants.ddMMyyyyHHmmss,
									activePreservationDataRequestVO.getTimeZone()));
				}
				templateInfo.setLatestFileScannedDate(wsTemplate
						.getlDVRPreservationRetriveTemplateInfo()
						.getLatestFileScannedDate());
				templateInfo.setNumFilesInPq(wsTemplate
						.getlDVRPreservationRetriveTemplateInfo()
						.getNumFilesInPq());
				templateInfo.setOffloadPriority(wsTemplate
						.getlDVRPreservationRetriveTemplateInfo()
						.getOffloadPriority());
				if(!RMDCommonUtility.isNullOrEmpty(wsTemplate
						.getlDVRPreservationRetriveTemplateInfo()
						.getRequestedEndTime())){
					templateInfo.setRequestedEndTime(RMDCommonUtility
							.convertDateFormatTimezone(wsTemplate
									.getlDVRPreservationRetriveTemplateInfo()
									.getRequestedEndTime(),
									RMDCommonConstants.MMddyyyyhhmma,
									RMDCommonConstants.ddMMyyyyHHmmss,
									activePreservationDataRequestVO.getTimeZone()));
				}
				if(!RMDCommonUtility.isNullOrEmpty(wsTemplate
						.getlDVRPreservationRetriveTemplateInfo()
						.getRequestedStartTime())){
					templateInfo.setRequestedStartTime(RMDCommonUtility
							.convertDateFormatTimezone(wsTemplate
									.getlDVRPreservationRetriveTemplateInfo()
									.getRequestedStartTime(),
									RMDCommonConstants.MMddyyyyhhmma,
									RMDCommonConstants.ddMMyyyyHHmmss,
									activePreservationDataRequestVO.getTimeZone()));
				}
				templateInfo.setScanExpirationCode(wsTemplate
						.getlDVRPreservationRetriveTemplateInfo()
						.getScanExpirationCode());
				if(!RMDCommonUtility.isNullOrEmpty(wsTemplate
						.getlDVRPreservationRetriveTemplateInfo()
						.getStatusDate())){
					templateInfo.setStatusDate(RMDCommonUtility
							.convertDateFormatTimezone(wsTemplate
									.getlDVRPreservationRetriveTemplateInfo()
									.getStatusDate(),
									RMDCommonConstants.MMddyyyyhhmma,
									RMDCommonConstants.ddMMyyyyHHmmss,
									activePreservationDataRequestVO.getTimeZone()));
				}
				templateInfo.setTemplateNumber(wsTemplate
						.getlDVRPreservationRetriveTemplateInfo()
						.getTemplateNumber());
				templateInfo.setTemplateStatus(wsTemplate
						.getlDVRPreservationRetriveTemplateInfo()
						.getTemplateStatus());
				templateInfo.setTemplateTypeName(wsTemplate
						.getlDVRPreservationRetriveTemplateInfo()
						.getTemplateTypeName());
				templateInfo.setTemplateVersion(wsTemplate
						.getlDVRPreservationRetriveTemplateInfo()
						.getTemplateVersion());
				templateInfo.setTitle(wsTemplate
						.getlDVRPreservationRetriveTemplateInfo().getTitle());
				template.setlDVRPreservationRetriveTemplateInfo(templateInfo);

				list.add(template);
			}
			activePreservationDataResponseVO
					.setActivePreservationTemplates(list);
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"Exception occured in getActivePreservationData method ",
					rmdEx);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getActivePreservationData method ",
					ex);
			throw ex;
		}
		rmdWebLogger
				.info("Inside LDVRRequestsServiceImpl in getActivePreservationData Method Done");

		return activePreservationDataResponseVO;
	}

	
	public RemoveTemplateResponseVO removeTemplate(
			RemoveTemplateRequestVO removeTemplateRequestVO)
			throws RMDWebException, Exception {
		rmdWebLogger
				.info("Inside LDVRRequestsServiceImpl in removeTemplate Method");

		RemoveTemplateResponseVO removeTemplateResponseVO = new RemoveTemplateResponseVO();
		removeTemplateResponseVO
				.setDetails(new ArrayList<RemoveTemplateStatusDetails>());
		RemoveTemplateResponseType removeTemplateResponseType = null;
		try {
			RemoveTemplateRequestType removeTemplateRequestType = new RemoveTemplateRequestType();
			removeTemplateRequestType.setAssetOwnerId(removeTemplateRequestVO
					.getAssetOwnerId());
			removeTemplateRequestType.setDevice(removeTemplateRequestVO
					.getDevice());
			removeTemplateRequestType.setRoadInitial(removeTemplateRequestVO
					.getRoadInitial());
			removeTemplateRequestType.setRoadNumber(removeTemplateRequestVO
					.getRoadNumber());
			removeTemplateRequestType.setTemplateIds(removeTemplateRequestVO
					.getTemplateIds());
			removeTemplateRequestType.setAssetOwnerId(removeTemplateRequestVO
					.getAssetOwnerId());
			removeTemplateRequestType.setUserName(removeTemplateRequestVO
					.getUserName());

			ObjectWriter ow = new ObjectMapper().writer()
					.withDefaultPrettyPrinter();
			String inputJson = ow.writeValueAsString(removeTemplateRequestType);

			rmdWebLogger
					.info("Inside LDVRRequestsServiceImpl calling removeTemplate ::: "
							+ removeTemplateURL);
			rmdWebLogger.info("removeTemplate Request ::: " + inputJson);

			removeTemplateResponseType = (RemoveTemplateResponseType) webServiceInvoker
					.postMCSWebService(mcsGetNumCamerasUsername,
							mcsGetNumCamerasPassowrd, removeTemplateURL,
							inputJson, RemoveTemplateResponseType.class);
			removeTemplateResponseVO.setStatus(removeTemplateResponseType
					.getStatus());
			RemoveTemplateStatusDetails statusDetails;
			for (RemoveTemplateStatus details : removeTemplateResponseType
					.getDetails()) {
				statusDetails = new RemoveTemplateStatusDetails();
				statusDetails.setAssetOwnerId(details.getAssetOwnerId());
				statusDetails.setDevice(details.getDevice());
				statusDetails.setItemObjId(details.getItemObjId());
				statusDetails.setRoadInitial(details.getRoadInitial());
				statusDetails.setRoadNumber(details.getRoadNumber());
				statusDetails.setStatusCode(details.getStatusCode());
				statusDetails.setStatusMessage(details.getStatusMessage());
				removeTemplateResponseVO.getDetails().add(statusDetails);
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error("Exception occured in removeTemplate method ",
					rmdEx);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in removeTemplate method ",
					ex);
			throw ex;
		}
		rmdWebLogger
				.info("Inside LDVRRequestsServiceImpl in removeTemplate Method Done");

		return removeTemplateResponseVO;
	}

	/**
	 * @param strCustomerId
	 * @param strAssetId
	 * @param strGrpName
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description Function get the road initial number for an asset
	 */
	public String getRoadInitial(String strCustomerId, String strAssetId,
			String strGrpName) throws RMDWebException {
		rmdWebLogger
				.info("LDVRRequestsServiceImpl : Inside getRoadInitial() method:::::START");
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		String roadHdrNum = null;
		try {
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTNUM, strAssetId);
			queryParamsMap.put(AppConstants.REQ_PARAM_CUSID, strCustomerId);
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTGRP, strGrpName);
			roadHdrNum = (String) webServiceInvoker.get(
					ServiceConstants.GET_HC_CUST_RNH_DETAILS, null,
					queryParamsMap, null, String.class);

		} catch (Exception ex) {
			rmdWebLogger
					.error("LDVRRequestsServiceImpl : Exception occured in getRoadInitial method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		rmdWebLogger
				.info("LDVRRequestsServiceImpl : Inside getRoadInitial() method:::::END");
		return roadHdrNum;
	}

	
	public LDVRMessageHistoryResponseVO getLDVRMessageHistory(
			LDVRMessageHistoryRequestVO ldvrMessageHistoryRequestVO)
			throws RMDWebException, Exception {

		rmdWebLogger
				.info("Inside LDVRRequestsServiceImpl in getMessageHistory Method");

		LDVRMessageHistoryRequestType ldvrMessageHisRequestType = new LDVRMessageHistoryRequestType();
		LDVRMessageHistoryResponseVO ldvrMessageHistoryResponseVO = null;
		try {
			ldvrMessageHisRequestType
					.setApplicationId(ldvrMessageHistoryRequestVO
							.getApplicationId());
			ldvrMessageHisRequestType
					.setDateTimeFrom(ldvrMessageHistoryRequestVO
							.getDateTimeFrom());
			ldvrMessageHisRequestType.setDateTimeTo(ldvrMessageHistoryRequestVO
					.getDateTimeTo());
			ldvrMessageHisRequestType
					.setMessageDirection(ldvrMessageHistoryRequestVO
							.getMessageDirection());
			ldvrMessageHisRequestType.setMessageId(ldvrMessageHistoryRequestVO
					.getMessageId());
			ldvrMessageHisRequestType
					.setMessageStatus(ldvrMessageHistoryRequestVO
							.getMessageStatus());
			ldvrMessageHisRequestType
					.setAssetCriteria(new ArrayList<LDVRAssetCriteriaType>());
			LDVRAssetCriteriaType assetType;
			for (LDVRAssetCriteriaVO assetVO : ldvrMessageHistoryRequestVO
					.getAssetCriteria()) {
				assetType = new LDVRAssetCriteriaType();
				assetType.setAssetOwnerId(assetVO.getAssetOwnerId());
				assetType.setDevice(assetVO.getDevice());
				assetType.setRoadInitial(assetVO.getRoadInitial());
				assetType.setRoadNumber(assetVO.getRoadNumber());
				assetType.setRoadNumberFrom(assetVO.getRoadNumberFrom());
				assetType.setRoadNumberTo(assetVO.getRoadNumberTo());
				ldvrMessageHisRequestType.getAssetCriteria().add(assetType);
				rmdWebLogger.info("MessagHistory Request assetcriteria "
						+ assetType.toString());
			}

			ObjectWriter ow = new ObjectMapper().writer()
					.withDefaultPrettyPrinter();
			String requestJson = ow
					.writeValueAsString(ldvrMessageHisRequestType);
			rmdWebLogger
					.info("Inside LDVRRequestsServiceImpl calling LDVR MessagHistory with URL "
							+ ldvrMessageHistoryURL);

			rmdWebLogger.info("LDVR MessagHistory Request " + requestJson);

			LDVRMessageHistoryResponseType ldvrMessageHistoryResponseType = (LDVRMessageHistoryResponseType) webServiceInvoker
					.postMCSWebService(mcsGetNumCamerasUsername,
							mcsGetNumCamerasPassowrd, ldvrMessageHistoryURL,
							requestJson, LDVRMessageHistoryResponseType.class);

			ldvrMessageHistoryResponseVO = new LDVRMessageHistoryResponseVO();
			ldvrMessageHistoryResponseVO
					.setMessages(new ArrayList<LDVRMessageVO>());

			List<LDVRMessageType> lstLDVMessages = ldvrMessageHistoryResponseType
					.getMessages();
			if (lstLDVMessages != null && !CollectionUtils.isEmpty(lstLDVMessages)) {
				for (LDVRMessageType msgType : lstLDVMessages) {
					LDVRMessageVO msgVO = new LDVRMessageVO();
					msgVO.setApplicationId(msgType.getApplicationId());
					msgVO.setAppRetryCount(msgType.getAppRetryCount());
					msgVO.setAssetOwnerName(msgType.getAssetOwnerName());
					msgVO.setCommReasonCode(msgType.getCommReasonCode());
					msgVO.setCreatedBy(msgType.getCreatedBy());
					msgVO.setCreatedDate(msgType.getCreatedDate());

					msgVO.setDestination(msgType.getDestination());
					msgVO.setDevice(msgType.getDevice());
					msgVO.setFileName(msgType.getFileName());
					msgVO.setHexMessage(msgType.getHexMessage());
					msgVO.setId(msgType.getId());

					msgVO.setLastUpdatedBy(msgType.getLastUpdatedBy());
					msgVO.setLastUpdatedDate(msgType.getLastUpdatedDate());
					msgVO.setMessageDirection(msgType.getMessageDirection());
					msgVO.setMessageGenerateTime(msgType
							.getMessageGenerateTime());
					msgVO.setMessageId(msgType.getMessageId());
					msgVO.setMessageOutId(msgType.getMessageOutId());

					msgVO.setMessagePriority(msgType.getMessagePriority());
					msgVO.setMessageRecievedTime(msgType
							.getMessageRecievedTime());
					msgVO.setMessageSentTime(msgType.getMessageSentTime());
					msgVO.setMessageSize(msgType.getMessageSize());
					msgVO.setMessageTypeName(authorizationService
							.getLookUpValueForName(msgType.getMessageTypeName()));
					
					if(("Ack").equalsIgnoreCase(msgType.getMessageStatus())){
						msgVO.setMessageStatus("Acknowledged");
					}else if(("Nack").equalsIgnoreCase(msgType.getMessageStatus())){
						msgVO.setMessageStatus("Not Acknowledged");
					}else{
						msgVO.setMessageStatus(msgType.getMessageStatus());
					}
					msgVO.setNackRetryCount(msgType.getNackRetryCount());
					msgVO.setOmrStatus(msgType.getOmrStatus());
					msgVO.setOriginalMsgId(msgType.getOriginalMsgId());

					msgVO.setRequestor(msgType.getRequestor());
					msgVO.setRoadInitial(msgType.getRoadInitial());

					msgVO.setRoadNumber(msgType.getRoadNumber());

					msgVO.setTemplateNumber(msgType.getTemplateNumber());
					msgVO.setTemplateVersion(msgType.getTemplateVersion());
					msgVO.setStatusDateTime(msgType.getStatusDateTime());
					msgVO.setRequestDateTime(msgType.getRequestDateTime());
					ldvrMessageHistoryResponseVO.getMessages().add(msgVO);
				}
			}			
			ldvrMessageHistoryResponseVO.setErrorCode(ldvrMessageHistoryResponseType.getErrorCode());
			ldvrMessageHistoryResponseVO.setErrorDescription(ldvrMessageHistoryResponseType.getErrorDescription());
			ldvrMessageHistoryResponseVO.setMaxRecordsReturned(ldvrMessageHistoryResponseType.getMaxRecordsReturned());		

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"Exception occured in getMessageHistory method ", rmdEx);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getMessageHistory method ", ex);
			throw ex;
		}
		rmdWebLogger
				.info("Inside LDVRRequestsServiceImpl in getMessageHistory Method Done");

		return ldvrMessageHistoryResponseVO;

	}

	
	public boolean getLDVRAssetSnapshotList(LDVRRequestVO ldvrRequestVO)
			throws RMDWebException, Exception {
		boolean isLocoEnabled = false;
		try {
			LDVRAssetSnapshotRequestType assetSnapshotRequest = new LDVRAssetSnapshotRequestType();

			assetSnapshotRequest.setAssetOwnerId(ldvrRequestVO
					.getAssetOwnerId());
			assetSnapshotRequest.setRoadInitial(ldvrRequestVO.getRoadInitial());
			assetSnapshotRequest.setRoadNumber(ldvrRequestVO.getRoadNumber());
			assetSnapshotRequest.setDevice(ldvrRequestVO.getDevice());
			assetSnapshotRequest
					.setRequestType(AppConstants.CHECK_LCV_LDVR_REQUEST_TYPE);

			ObjectWriter ow = new ObjectMapper().writer()
					.withDefaultPrettyPrinter();
			String requestJson = ow.writeValueAsString(assetSnapshotRequest);

			rmdWebLogger
					.info("Inside LDVRRequestsServiceImpl calling assetsnapshot webservice ::: "
							+ ldvrassetSnapshotURL);
			rmdWebLogger
					.info("ldvrassetSnapshotURL Request ::: " + requestJson);

			LDVRAssetSnapshotResponseType assetSnapshotResponseType = (LDVRAssetSnapshotResponseType) webServiceInvoker
					.postMCSWebService(mcsGetNumCamerasUsername,
							mcsGetNumCamerasPassowrd, ldvrassetSnapshotURL,
							assetSnapshotRequest,
							LDVRAssetSnapshotResponseType.class);

			if (assetSnapshotResponseType != null) {
				List<LDVRActiveServices> ldvrActiveServicesLst = assetSnapshotResponseType
						.getActiveServices();
				if ("LCV".equalsIgnoreCase(assetSnapshotResponseType
						.getDevice())) {
					for (LDVRActiveServices ldvrActiveServiceVO : ldvrActiveServicesLst) {
						if ("LDVR".equalsIgnoreCase(ldvrActiveServiceVO
								.getApplicationName())) {
							isLocoEnabled = true;
							break;
						}
					}
				}
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"Exception occured in getLDVRAssetSnapshotList method ",
					rmdEx);
			if (rmdEx.getErrorCode().equalsIgnoreCase(
					AppConstants.MCS_ERROR_MCS00007)
					|| rmdEx.getErrorCode().equalsIgnoreCase(
							AppConstants.MCS_ERROR_MCS00011)) {
				isLocoEnabled = false;
			}else
				throw rmdEx;

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getLDVRAssetSnapshotList method ",
							ex);
			throw ex;
		}
		rmdWebLogger
				.info("Inside LDVRRequestsServiceImpl in getLDVRAssetSnapshotList Method Ends");

		return isLocoEnabled;
	}
	public String getLookupValueForError(String errorCode, String errorMsg)
			throws RMDWebException, Exception {
		String key;
		if (errorCode.equalsIgnoreCase(AppConstants.MCS_ERROR_MCS00002)) {
			StringBuilder strBuilder = new StringBuilder();
			strBuilder
					.append(errorCode)
					.append(AppConstants.CHAR_UNDER_SCORE)
					.append(errorMsg.substring(errorMsg.indexOf(':') + 1,
							errorMsg.length()).trim());
			key = strBuilder.toString();
		} else {
			key = errorCode;
		}
		return authorizationService.getLookUpValueForName(key);
	}
}
