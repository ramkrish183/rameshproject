package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.valueobjects.FindCasesDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.FindCasesVO;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface FindCaseService {
	/**
	 * @param
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Find Cases Search Options By dropdown.
	 */
	public Map<String, String> getfindCaseSearchOptions() throws RMDWebException;
	/**
	 * @param
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Find Cases Filter Options By dropdown.
	 */
	public Map<String, String> getfindCaseFilterOptions() throws RMDWebException;
	/**
	 * @param
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Find Cases CaseType By dropdown. 
	 */
	public Map<String, String> getfindCaseCaseType() throws RMDWebException;
	/**
	 * @param
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Find Cases LookBakDays By dropdown.
	 */
	public String getFindCasesLookBakDays() throws RMDWebException;
	/**
	 * @param TimeZone 
	 * @Author:
	 * @param:FindCasesDetailsVO
	 * @return:List<FindCasesDetailsVO>
	 * @throws:RMDWebException
	 * @Description: This method is used to get Find Cases Details.
	 */
	public List<FindCasesDetailsVO> getFindCases(FindCasesVO objFindCasesVO, String TimeZone, String defaultTimeZone) throws RMDWebException;
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, List<String>>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Customer Name and Road
	 *               Number Headers.
	 */
	public Map<String, List<String>> getCustNameRNH() throws RMDWebException;
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Road Number.
	 */
	public Map<String, String> getRoadNumbers(String CustomerName,String RoadNumberHeader)throws RMDWebException;
	
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Road Number.
	 */
	public Map<String, String> getRoadNumbers(String CustomerName,String RoadNumberHeader, String rnSearchString, String rnFilter)throws RMDWebException;
	
	/**
	 * 
	 * @param
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the RN Filter Options By dropdown.
	 */
	public Map<String, String> getRNFilterOptions() throws RMDWebException;
}
