package com.ge.trans.rmd.cm.mvc.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import com.ge.trans.rmd.cm.service.AssetCasesService;
import org.springframework.web.servlet.ModelAndView;
import com.ge.trans.rmd.cm.service.AssetOverviewService;
import com.ge.trans.rmd.cm.service.CreateCasesService;
import com.ge.trans.rmd.cm.service.FaultServiceStrategyService;
import com.ge.trans.rmd.cm.valueobjects.AssetSearchVO;
import com.ge.trans.rmd.cm.valueobjects.CaseTypeBean;
import com.ge.trans.rmd.cm.valueobjects.CreateCaseLookUpVO;
import com.ge.trans.rmd.cm.valueobjects.CreateCasesVO;
import com.ge.trans.rmd.cm.valueobjects.FaultCodeVO;
import com.ge.trans.rmd.cm.valueobjects.FaultServiceStrategyVO;
import com.ge.trans.rmd.cm.valueobjects.ViewLogVO;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.beans.CaseSolutionVO;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.beans.SolutionBean;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.AppSecUtil;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.pp.beans.AssetBean;
import com.ge.trans.rmd.common.vo.CustomerVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
@Controller
@SessionAttributes
public class FaultServiceStrategyController extends RMDBaseController {
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
	.getLogger(getClass());

	@Autowired
	private FaultServiceStrategyService faultServiceStrategyService;

	@Value("${" + AppConstants.FAULT_ANALYSIS_MANUAL_URL + "}")
	String faultAnalysisManualUrl;
	@Value("${"+AppConstants.RULE_DEF_URL+"}")
	String ruleDefUrl;
	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Diagnostic Weight By dropdown.
	 * 
	 */
	@RequestMapping(value = AppConstants.GET_DIAGNOSTIC_WEIGHT)
	public @ResponseBody
	List<String> getDiagnosticWeight() throws RMDWebException {

		rmdWebLogger
				.debug("Inside CreateCasesController in getDiagnosticWeight Method");
		List<String> diagnosticWeight = new ArrayList<String>();
		try {
			diagnosticWeight = faultServiceStrategyService
					.getDiagnosticWeight();
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getDiagnosticWeight method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return diagnosticWeight;
	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the SubSys Weight By dropdown.
	 * 
	 */
	@RequestMapping(value = AppConstants.GET_SUBSYS_WEIGHT)
	public @ResponseBody
	List<String> getSubSysWeight() throws RMDWebException {

		rmdWebLogger
				.debug("Inside CreateCasesController in getSubSysWeight Method");
		List<String> subSysWeight = new ArrayList<String>();
		try {
			subSysWeight = faultServiceStrategyService.getSubSysWeight();
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getSubSysWeight method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return subSysWeight;
	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Diagnostic Weight By dropdown.
	 * 
	 */
	@RequestMapping(value = AppConstants.GET_MODE_RESTRICTION)
	public @ResponseBody
	Map<String, String> getModeRestriction() throws RMDWebException {

		rmdWebLogger
				.debug("Inside CreateCasesController in getSolEstRepairTime Method");
		Map<String, String> modeRestriction = new LinkedHashMap<String, String>();
		try {
			modeRestriction = faultServiceStrategyService.getModeRestriction();
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getSolEstRepairTime method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return modeRestriction;
	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Diagnostic Weight By dropdown.
	 * 
	 */
	@RequestMapping(value = AppConstants.GET_FAULT_CLASSIFICATION)
	public @ResponseBody
	Map<String, String> getFaultClassification() throws RMDWebException {

		rmdWebLogger
				.debug("Inside CreateCasesController in getFaultClassification Method");
		Map<String, String> faultClassification = new LinkedHashMap<String, String>();
		try {
			faultClassification = faultServiceStrategyService
					.getFaultClassification();
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getFaultClassification method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return faultClassification;
	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description This method is used to fetch the values from lookup table to
	 *              populate the Critical Flag By dropdown
	 * 
	 */
	@RequestMapping(value = AppConstants.GET_CRITICAL_FLAG)
	public @ResponseBody
	Map<String, String> getCriticalFlag() throws RMDWebException {

		rmdWebLogger
				.debug("Inside CreateCasesController in getCriticalFlag Method");
		Map<String, String> criticalFlag = new LinkedHashMap<String, String>();
		;
		try {
			criticalFlag = faultServiceStrategyService.getCriticalFlag();
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCriticalFlag method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return criticalFlag;
	}

	/**
	 * @Author:
	 * @param :String Fault Strategy ObjId
	 * @return:FaultServiceStrategyVO
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used for fetching the Fault Strategy
	 *               Details.It accepts Fault Strategy ObjId as an Input
	 *               Parameter and returns FaultServiceStrategyVO.
	 * 
	 */
	@RequestMapping(AppConstants.GET_FAULT_STRATEGY_DETAILS)
	public @ResponseBody
	FaultServiceStrategyVO getFaultStrategyDetails(
			@RequestParam(value = AppConstants.FAULT_STRATEGY_OBJID) final String fsObjId,
			final HttpServletRequest request) throws RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		FaultServiceStrategyVO objFaultServiceStrategyVO = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(fsObjId)) {
				objFaultServiceStrategyVO = faultServiceStrategyService
						.getFaultStrategyDetails(fsObjId, userVO.getTimeZone());
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getFaultStrategyDetails() method in FaultServiceStartegyController ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return objFaultServiceStrategyVO;
	}

	/**
	 * @Author:
	 * @param :String ObjId
	 * @return:List<FaultServiceStrategyVO>
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used for fetching the Fault Rule & Desc.It
	 *               accepts Fault Strategy ObjId as an Input Parameter and
	 *               returns FaultServiceStrategyVO List.
	 * 
	 */
	@RequestMapping(AppConstants.GET_RULE_DESC)
	public @ResponseBody
	List<FaultServiceStrategyVO> getRuleDesc(
			@RequestParam(value = AppConstants.FAULT_CODE_ID) final String faultCode)
			throws RMDWebException {
		List<FaultServiceStrategyVO> lstFaultServiceStrategyVO = new ArrayList<FaultServiceStrategyVO>();
		try {
			if (!RMDCommonUtility.isNullOrEmpty(faultCode)) {
				lstFaultServiceStrategyVO = faultServiceStrategyService
						.getRuleDesc(faultCode);
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getRuleDesc() method in FaultServiceStartegyController ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lstFaultServiceStrategyVO;
	}

	/**
	 * 
	 * @param request
	 * @return String
	 * @throws RMDWebException
	 * @Description * This method is used for update ing FaultServiceStrategy.It
	 *              accepts FaultServiceStrategyVO as an Input Parameter and
	 *              returns message.
	 * 
	 */
	@RequestMapping(value = AppConstants.UPDATE_FAULT_SERVICE_STRATEGY, method = RequestMethod.POST)
	public @ResponseBody
	String updateFaultServiceStrategy(final HttpServletRequest request)
			throws RMDWebException {
		final FaultServiceStrategyVO objFaultServiceStrategyVO = new FaultServiceStrategyVO();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String responseMessage = null;
		try {
			objFaultServiceStrategyVO.setUserId(userVO.getUserId());
			objFaultServiceStrategyVO.setCmAliasName(userVO.getCmAliasName());
			objFaultServiceStrategyVO.setFltStart2FltCode(request
					.getParameter(AppConstants.FLTSTART2FLTCODE));
			objFaultServiceStrategyVO.setFaultDesc(request
					.getParameter(AppConstants.FLTDESCRIPTION));
			objFaultServiceStrategyVO.setDiagnosticWeight(request
					.getParameter(AppConstants.DIAGNOSTIC_WEIGHT));
			objFaultServiceStrategyVO.setSubSysWeight(request
					.getParameter(AppConstants.SUBSYS_WEIGHT));
			objFaultServiceStrategyVO.setModeRestriction(request
					.getParameter(AppConstants.MODE_RESTRICTION));
			objFaultServiceStrategyVO.setFaultClassification(request
					.getParameter(AppConstants.FAULT_CLASSIFICATION));
			objFaultServiceStrategyVO.setFaultCriticalFlag(request
					.getParameter(AppConstants.CRITICAL_FLAG));
			objFaultServiceStrategyVO.setFaultLagTime(request
					.getParameter(AppConstants.FAULTLAGTIME));
			objFaultServiceStrategyVO.setFsObjId(request
					.getParameter(AppConstants.FAULT_STRATEGY_OBJID));
			objFaultServiceStrategyVO.setFaultNotes(request
					.getParameter(AppConstants.FAULTNOTES));
			responseMessage = faultServiceStrategyService
					.updateFaultServiceStrategy(objFaultServiceStrategyVO);
		} catch (RMDWebException e) {
			RMDWebErrorHandler.handleException(e);
			responseMessage = AppConstants.FAILURE;
		} catch (Exception ex) {
			responseMessage = AppConstants.FAILURE;
			rmdWebLogger.error(
					"Exception occured in updateFaultServiceStrategy method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} 
			return responseMessage;
	}
	
	/**
	 * @Author:
	 * @param request
	 * @return ModelAndView
	 * @throws RMDWebException
	 * @Description: Displays the view Fault Service page of the RMD application
	 *               when clicked on FSS Tab in Administration Page.
	 */

	@RequestMapping(AppConstants.REQ_URI_VIEW_FSS)
	public ModelAndView showViewFaultSeviceScreen(
			final HttpServletRequest request) throws RMDWebException {
		try {
			HttpSession session = request.getSession(false);
			UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
			request.setAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE, userVO.getIsCMPrivilege());
			request.setAttribute(AppConstants.REQ_FAULT_ANALYSIS_MANUAL_URL,
					faultAnalysisManualUrl);
			request.setAttribute(AppConstants.STR_RULE_DEF_URL,ruleDefUrl);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in showViewFaultSeviceScreen() method in FaultServiceStartegyController ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return new ModelAndView(AppConstants.VIEW_FAULT_SERVICE);
	}
	
	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description This method is used to fetch Fault Origin values to populate
	 *              Fault Origin Drop down.
	 * 
	 */
	@RequestMapping(AppConstants.GET_FAULT_ORIGIN)
	public @ResponseBody
	Map<String, String> getFaultOrigin() throws RMDWebException {
		Map<String, String> faultOriginMap = new HashMap<String, String>();
		try {
			faultOriginMap = faultServiceStrategyService.getFaultOrigin();
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getFaultOrigin() method in FaultServiceStartegyController ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return faultOriginMap;
	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description This method is used to fetch Fault Code SubId's to populate
	 *              Fault SubId Drop down.
	 * 
	 */

	@RequestMapping(AppConstants.GET_FAULT_CODE_SUBID)
	public @ResponseBody
	Map<String, String> getFaultCodeSubId(
			@RequestParam(AppConstants.FAULT_CODE_ID) String faultCode,
			@RequestParam(AppConstants.FAULT_ORIGIN) String faultOrigin)
			throws RMDWebException {
		Map<String, String> faultCodeSubIdMap = new HashMap<String, String>();
		try {

			if (!RMDCommonUtility.isNullOrEmpty(faultCode)
					&& !RMDCommonUtility.isNullOrEmpty(faultOrigin)) {
				faultCodeSubIdMap = faultServiceStrategyService
						.getFaultCodeSubId(AppSecUtil.htmlEscaping(faultCode), faultOrigin);
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getFaultCodeSubId() method in FaultServiceStartegyController ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return faultCodeSubIdMap;
	}
	
	/**
	 * 
	 * @param
	 * @return List<String>
	 * @throws RMDWebException
	 * @Description This method is used to get Fault Code based upon Search
	 *              Criteria.
	 */
	@RequestMapping(value = AppConstants.GET_VIEW_FSS_FAULT_CODE)
	public @ResponseBody
	List<String> getViewFSSFaultCode(
			@RequestParam(AppConstants.FAULT_CODE_ID) String faultCode,
			@RequestParam(AppConstants.FAULT_ORIGIN) String faultOrigin)
			throws RMDWebException {
		List<String> faultCodeList = new ArrayList<String>();
		try {
			if (!RMDCommonUtility.isNullOrEmpty(faultCode)) {
				faultCodeList = faultServiceStrategyService
						.getViewFSSFaultCode(AppSecUtil.htmlEscaping(faultCode), faultOrigin);
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getViewFSSFaultCode() method in FaultServiceStartegyController ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return faultCodeList;
	}

	/**
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used to get Fault Code ObjId based upon
	 *              FaultCode,Fault SubID,Fault Origin
	 */
	@RequestMapping(value = AppConstants.GET_FAULT_STRATEGY_OBJID)
	public @ResponseBody
	String getFaultStrategyObjId(
			@RequestParam(AppConstants.FAULT_CODE_ID) String faultCode,
			@RequestParam(AppConstants.FAULT_ORIGIN) String faultOrigin,
			@RequestParam(AppConstants.FAULT_CODE_SUBID) String faultCodeSubId)
			throws RMDWebException {
		String faultStartObjId = AppConstants.FAILURE;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(faultCode)
					&& !RMDCommonUtility.isNullOrEmpty(faultOrigin)
					&& !RMDCommonUtility.isNullOrEmpty(faultCodeSubId)
					&& AppSecUtil.checkAlphaNumeric(faultCodeSubId)) {
				faultStartObjId = faultServiceStrategyService
						.getFaultStrategyObjId(AppSecUtil.htmlEscaping(faultCode), faultOrigin,
								faultCodeSubId);
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getFaultStartObjId() method in FaultServiceStartegyController ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return faultStartObjId;
	}
}