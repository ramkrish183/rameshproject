package com.ge.trans.rmd.cm.mvc.controller;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.PopUpListAdminService;
import com.ge.trans.rmd.cm.valueobjects.LookupSearchServiceVO;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.valueobjects.GetSysLookupVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
public class PopUpListAdminController extends RMDBaseController {
	@Autowired
	private PopUpListAdminService popUpListAdminService;
	@Autowired
       private org.springframework.cache.CacheManager cacheManager;

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@RequestMapping(AppConstants.REQ_URI_POP_UP_LIST_ADMIN)
	public ModelAndView popUpListAdminPage(final HttpServletRequest request)
			throws RMDWebException {
		rmdWebLogger
				.debug("Inside PopUpListAdmin Controller in popUpListAdminPage Method");
		try {
			HttpSession session = request.getSession(false);
			UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			request.setAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE,
					userVO.getIsCMPrivilege());

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in popUpListAdminPage() method in PopUpListAdminController ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return new ModelAndView(AppConstants.POP_UP_LIST_ADMIN);
	}

	/**
	 * 
	 * @param
	 * @return PopUpListAdminVO
	 * @throws Exception
	 * @Description * This method is used to get the Cases.
	 * 
	 */
	@RequestMapping(value = AppConstants.GET_SHOW_ALL, method = RequestMethod.POST)
	@ResponseBody public  List<GetSysLookupVO> getShowAll(
			final HttpServletRequest request) throws Exception {
		List<GetSysLookupVO> objGetSysLookupVOlst = new ArrayList<GetSysLookupVO>();
		LookupSearchServiceVO objLookupServiceSearch = new LookupSearchServiceVO();

		if (!RMDCommonUtility.isNullOrEmpty(request
				.getParameter(AppConstants.POPUPLISTADMIN_SEARCHBY))) {
			objLookupServiceSearch.setStrSearchBy(request
					.getParameter(AppConstants.POPUPLISTADMIN_SEARCHBY));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request
				.getParameter(AppConstants.POPUPLISTADMIN_CONDITION))) {
			objLookupServiceSearch.setStrSearchCondition(request
					.getParameter(AppConstants.POPUPLISTADMIN_CONDITION));
		}
		if (!RMDCommonUtility.isNullOrEmpty(request
				.getParameter(AppConstants.POPUPLISTADMIN_VALUE))) {
			objLookupServiceSearch.setStrValue(request
					.getParameter(AppConstants.POPUPLISTADMIN_VALUE));
		}

		objGetSysLookupVOlst = popUpListAdminService
				.getPopupList(objLookupServiceSearch);

		return objGetSysLookupVOlst;

	}

	/**
	 * @Author:
	 * @param :
	 * @return String
	 * @throws RMDWebException
	 * @Description: This method is used to insert the pop up details
	 */

	@RequestMapping(value = AppConstants.ADD_POPUP_LIST_VALUES, method = RequestMethod.POST)
	 @ResponseBody public String savePopupList(final HttpServletRequest request)
			throws RMDWebException {
		String uniquerecord = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);

		GetSysLookupVO sysvo = new GetSysLookupVO();
		try {
			String listName = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.POUP_LIST_NAME));
			String listDescription = EsapiUtil
					.stripXSSCharacters((String) (request
							.getParameter(AppConstants.POUP_LIST_DESCRIPTION)));

			sysvo.setListName(listName);
			sysvo.setListDescription(listDescription);
			sysvo.setStrUserName(EsapiUtil.stripXSSCharacters(userVO.getUserId()));

			uniquerecord = popUpListAdminService.savePopupList(sysvo);

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in savePopupList  method in PopUpListAdminController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return uniquerecord;
	}

	/**
	 * @Author:
	 * @param :
	 * @return String
	 * @throws RMDWebException
	 * @Description: This method is used to insert the pop up details
	 */

	@RequestMapping(value = AppConstants.UPDATE_POPUP_LIST, method = RequestMethod.POST)
	@ResponseBody public  String updatePopupList(final HttpServletRequest request)
			throws RMDWebException {
		String rowsUpdated = null;
		GetSysLookupVO sysvo = new GetSysLookupVO();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			String listName = request.getParameter(AppConstants.POUP_LIST_NAME);
			String listDescription = request
					.getParameter(AppConstants.POUP_LIST_DESCRIPTION);
			String oldListName = request
					.getParameter(AppConstants.OLD_LIST_NAME);
			sysvo.setListName(listName);
			sysvo.setListDescription(listDescription);
			sysvo.setOldListName(oldListName);
			sysvo.setStrUserName(userVO.getUserId());

			popUpListAdminService.updatePopupList(sysvo);

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in savePopupList  method in PopUpListAdminController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return rowsUpdated;

	}

	/**
	 * @Author:
	 * @param :
	 * @return String
	 * @throws RMDWebException
	 * @Description: This method is used to insert the pop up details
	 */
	@RequestMapping(value = AppConstants.DELETE_POPUP_LIST)
	@ResponseBody public  String deletePopUpList(final HttpServletRequest request)
			throws RMDWebException {
		String rowsUpdated = null;
		GetSysLookupVO sysvo = new GetSysLookupVO();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			String listName = request.getParameter(AppConstants.POUP_LIST_NAME);
			sysvo.setListName(listName);
			sysvo.setStrUserName(userVO.getUserId());

			popUpListAdminService.deletePopupList(sysvo);

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in savePopupList  method in PopUpListAdminController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return rowsUpdated;

	}

	/**
	 * @Author:
	 * @param :
	 * @return String
	 * @throws RMDWebException
	 * @Description: This method is used to insert the pop up details
	 */
	@RequestMapping(AppConstants.UPDATE_POPUP_LIST_VALUE)
	@ResponseBody public  String updatePopupListValues(
			@RequestParam(AppConstants.REQ_PARAM_LOOKUPVAL) String popuplistValues,
			final HttpServletRequest request) throws RMDWebException {
		String status = null;
		final ObjectMapper mapper = new ObjectMapper();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			String userId = EsapiUtil.stripXSSCharacters(userVO.getUserId());
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			GetSysLookupVO[] arrGetSysLookupVOs = mapper.readValue(
					EsapiUtil.stripXSSCharacters(popuplistValues), GetSysLookupVO[].class);
			List<GetSysLookupVO> arlSGetSysLookupVO = Arrays.asList(arrGetSysLookupVOs);
			status = popUpListAdminService.updatePopupListValues(
					arlSGetSysLookupVO, userId);
			cacheManager.getCache(AppConstants.LOOKUPVALUE_CACHE).clear();
		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("RMDWebException occured in updatePopupListValues() method - PopUpListAdminController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return status;
	}

	/**
	 * @Author:
	 * @param :
	 * @return String
	 * @throws RMDWebException
	 * @Description: This method is used to insert the pop up details
	 */

	@RequestMapping(value = AppConstants.ADD_POPUP_LOOK_VALUES, method = RequestMethod.POST)
	@ResponseBody public  String savePopupListlookvalue(
			final HttpServletRequest request) throws RMDWebException {

		String uniqueRecord = null;
		GetSysLookupVO sysVo = new GetSysLookupVO();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			String lookValue = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.POPUP_LOOKVALUE));
			String listName = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.POUP_LIST_NAME));
			String listDescription = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.POUP_LIST_DESCRIPTION));
			String toolTip = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.TOOLTIP));
			sysVo.setLookValue(lookValue);
			sysVo.setListName(listName);
			sysVo.setListDescription(listDescription);
			sysVo.setStrUserName(userVO.getUserId());
			sysVo.setLookValueDesc(toolTip);
			uniqueRecord = popUpListAdminService.savePopupListlookvalue(sysVo);
			cacheManager.getCache(AppConstants.LOOKUPVALUE_CACHE).clear();

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in savePopupListlookvalue  method in PopUpListAdminController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return uniqueRecord;

	}

	/**
	 * @Author:
	 * @param :
	 * @return String
	 * @throws RMDWebException
	 * @Description: This method is used to insert the pop up details
	 */

	@RequestMapping(value = AppConstants.REMOVE_POPUP_LOOK_VALUES, method = RequestMethod.POST)
	@ResponseBody public  String removePopupListlookvalue(
			final HttpServletRequest request) throws RMDWebException {

		String rowsUpdated = null;
		GetSysLookupVO sysvo = new GetSysLookupVO();
		try {
			String getSysLookupSeqId = request
					.getParameter(AppConstants.POPUP_SEQ_ID);
			String listName = request.getParameter(AppConstants.POUP_LIST_NAME);
			String sortOrder = request.getParameter(AppConstants.SORTORDER);
			sysvo.setGetSysLookupSeqId(Long.parseLong(getSysLookupSeqId));
			sysvo.setListName(listName);
			sysvo.setSortOrder(Long.parseLong(sortOrder));
			popUpListAdminService.removePopupListlookvalue(sysvo);
			cacheManager.getCache(AppConstants.LOOKUPVALUE_CACHE).clear();

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in removePopupListlookvalue  method in PopUpListAdminController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return rowsUpdated;

	}

	/**
	 * @Author:
	 * @param :
	 * @return String
	 * @throws RMDWebException
	 * @Description: This method is used to insert the pop up details
	 */

	@RequestMapping(value = AppConstants.GET_POPUP_LIST_VALUES, method = RequestMethod.POST)
	@ResponseBody public  List<GetSysLookupVO> getPopupListValues(
			final HttpServletRequest request) throws RMDWebException {
		List<GetSysLookupVO> objGetSysLookupVOlst = new ArrayList<GetSysLookupVO>();
		GetSysLookupVO sysvo = new GetSysLookupVO();
		try {
			String listName = request.getParameter(AppConstants.POUP_LIST_NAME);
			sysvo.setListName(listName);

			objGetSysLookupVOlst = popUpListAdminService
					.getPopupListValues(sysvo);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getPopupListValues  method in PopUpListAdminController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return objGetSysLookupVOlst;
	}

}
