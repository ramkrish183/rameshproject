/**
 * ============================================================
 * File : VisualizationService.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.cm.mvc.controller
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Feb 8, 2012
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.RxVisualizationPlotInfoVO;
import com.ge.trans.rmd.cm.valueobjects.VisualizationDataResponseVO;
import com.ge.trans.rmd.cm.valueobjects.VisualizationDetailsBean;
import com.ge.trans.rmd.cm.valueobjects.VisualizationEventDataVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.pp.beans.AssetBean;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.FaultCodeDetailsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.GraphDetailsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.MPParmDetailsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.RxVisualizationPlotInfoType;
import com.ge.trans.rmd.services.assets.valueobjects.VirtualParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.VisualizationDetailsRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.VisualizationDetailsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.VisualizationEventDataRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.VisualizationEventDataResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.VisualizationParmDetailsType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
/*******************************************************************************
 * 
 * @Author : iGATE
 * @Version : 1.0
 * @Date Created: July 21, 2011
 * @Date Modified : July 25, 2011
 * @Modified By :
 * @Contact :
 * @Description : Service implementation class for fetching the details related to visualization screen
 * @History :
 * 
 ******************************************************************************/
@Service
public class VisualizationServiceImpl extends RMDBaseServiceImpl implements
		VisualizationService {

	
	@Autowired
	WebServiceInvoker rsInvoker;

	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	
	
	/**
	 * @Author:
	 * @param
	 * @return Map<List<String> , ArrayList<ArrayList<ArrayList<Number>>>>
	 * @Description: This method will return the data needed to plot the chart
	 */
	public VisualizationDataResponseVO  getVisualizationDetails(
			final VisualizationDetailsBean objVisualizationBean)
			throws RMDWebException, Exception {

		final VisualizationDetailsRequestType objVisualizationDetailsRequestType = new VisualizationDetailsRequestType();
		Map<List<String>, ArrayList<ArrayList<ArrayList<Number>>>> chartData = new HashMap<List<String>, ArrayList<ArrayList<ArrayList<Number>>>>();
		VisualizationDataResponseVO objVisualizationDataResponseVO=new VisualizationDataResponseVO();
		try {
			String family=objVisualizationBean.getFamily();
			if (null != objVisualizationBean) {
				
				
				
				if (null != objVisualizationBean.getMpNumbers()
						&& !RMDCommonConstants.EMPTY_STRING
								.equalsIgnoreCase(objVisualizationBean
										.getMpNumbers())) {
					Map<String,Map<String,String>> virtualParmNumbers=getVizVirtualParameters(family, objVisualizationBean.getSource());
					Map<String,String> anomParameters=getLookUpValuesWithDescription(AppConstants.VISUALIZATION_ANOMALY_PARAMETERS);
					Map<String,String> virtualParameters=virtualParmNumbers.get(family);
					String mpNumers[] = objVisualizationBean.getMpNumbers()
							.split(RMDCommonConstants.COMMMA_SEPARATOR);
					List<String> lstMpNumbers = new ArrayList<String>();
					List<String> lstvirtualParms = new ArrayList<String>();
					List<String> lstanomParms = new ArrayList<String>();
					for (int k = 0; k < mpNumers.length; k++) {
						if(null!=virtualParameters&&virtualParameters.containsKey(mpNumers[k].trim().split("~")[0])){
							lstvirtualParms.add(mpNumers[k].trim());
						}else if(null!=anomParameters&&anomParameters.containsKey(mpNumers[k].trim().split("~")[0])){
							lstanomParms.add(mpNumers[k].trim());
						}else{
						lstMpNumbers.add(mpNumers[k].trim());
						}
					}
					objVisualizationDetailsRequestType
							.setMpNumbers(lstMpNumbers);
					objVisualizationDetailsRequestType.setVirtualParameters(lstvirtualParms);
					objVisualizationDetailsRequestType.setAnomParms(lstanomParms);
				}
				objVisualizationDetailsRequestType
						.setAssetGroupName(objVisualizationBean
								.getAssetGroupName());
				objVisualizationDetailsRequestType
						.setAssetNumber(objVisualizationBean.getAssetNumber());
				objVisualizationDetailsRequestType
						.setControllerCfg(objVisualizationBean
								.getControllerCfg());
				objVisualizationDetailsRequestType
						.setCustomerId(objVisualizationBean.getCustomerId());
				objVisualizationDetailsRequestType
						.setFromDate(objVisualizationBean.getFromDate());
				objVisualizationDetailsRequestType
						.setToDate(objVisualizationBean.getToDate());
				objVisualizationDetailsRequestType
						.setSource(objVisualizationBean.getSource());
				objVisualizationDetailsRequestType
						.setSourceType(objVisualizationBean.getSourceType());
				objVisualizationDetailsRequestType
						.setUserLanguage(objVisualizationBean.getUserLanguage());
				objVisualizationDetailsRequestType
				.setControllerType(objVisualizationBean.getControllerType());
				objVisualizationDetailsRequestType.setFaultCode(objVisualizationBean.getHidddenfaultCode());
				objVisualizationDetailsRequestType.setLocoState(objVisualizationBean.getLocoStateValue());
				objVisualizationDetailsRequestType.setAmbientTempOperator(objVisualizationBean.getAmbientTmpOp());
				objVisualizationDetailsRequestType.setAmbientTempValue1(objVisualizationBean.getAmbientTmpVal1());
				objVisualizationDetailsRequestType.setAmbientTempValue2(objVisualizationBean.getAmbientTmpVal2());
				objVisualizationDetailsRequestType.setEngineGHPOperator(objVisualizationBean.getEngGHPOp());
				objVisualizationDetailsRequestType.setEngineGHPValue1(objVisualizationBean.getEngGHPVal1());
				objVisualizationDetailsRequestType.setEngineGHPValue2(objVisualizationBean.getEngGHPVal2());
				objVisualizationDetailsRequestType.setNotchOperator(objVisualizationBean.getNotchOperator());
				objVisualizationDetailsRequestType.setNotchValue(objVisualizationBean.getNotchValue());
				objVisualizationDetailsRequestType.setEngineSpeedOperator(objVisualizationBean.getEngSpeedOp());
				objVisualizationDetailsRequestType.setEngineSpeedValue1(objVisualizationBean.getEngSpeedVal1());
				objVisualizationDetailsRequestType.setEngineSpeedValue2(objVisualizationBean.getEngSpeedVal2());
				objVisualizationDetailsRequestType.setSourceTypeCd(objVisualizationBean.getSourceTypeCd());
				objVisualizationDetailsRequestType.setFamily(objVisualizationBean.getFamily());
				objVisualizationDetailsRequestType.setAssetObjid(objVisualizationBean.getAssetObjid());
				
				objVisualizationDetailsRequestType.setOilInletOp(objVisualizationBean.getOilInletOp());
				objVisualizationDetailsRequestType.setOilInletValue1(objVisualizationBean.getOilInletVal1());
				objVisualizationDetailsRequestType.setOilInletValue2(objVisualizationBean.getOilInletVal2());
				
				objVisualizationDetailsRequestType.setBarometricPressOp(objVisualizationBean.getBarometricPressOp());
				objVisualizationDetailsRequestType.setBarometricPressValue1(objVisualizationBean.getBarometricPressVal1());
				objVisualizationDetailsRequestType.setBarometricPressValue2(objVisualizationBean.getBarometricPressVal2());
				
				objVisualizationDetailsRequestType.setHpAvailableOp(objVisualizationBean.getHpAvailableOp());
				objVisualizationDetailsRequestType.setHpAvailableValue1(objVisualizationBean.getHpAvailableVal1());
				objVisualizationDetailsRequestType.setHpAvailableValue2(objVisualizationBean.getHpAvailableVal2());
				objVisualizationDetailsRequestType.setNoOfDays(objVisualizationBean.getNoOfDays());
				
				VisualizationDetailsResponseType[] objVisualizationDetailsResponseType = (VisualizationDetailsResponseType[]) rsInvoker
						.post(ServiceConstants.GET_VISUALIZATION_DETAILS,
								objVisualizationDetailsRequestType,
								VisualizationDetailsResponseType[].class);

				List<String> mpParmdesc = new ArrayList<String>();
				List<String> stackOrder = new ArrayList<String>();
				List<String> assets=new ArrayList<String>();
				final String fromDate = objVisualizationBean.getFromDate();
				final String toDate = objVisualizationBean.getToDate();
				DateFormat formatter;
				Date date;
				formatter = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
							
				GregorianCalendar objGregorianCalendar = new GregorianCalendar();
				objGregorianCalendar.setTime(formatter.parse(fromDate));
				RMDCommonUtility.setZoneOffsetTime(
						objGregorianCalendar, RMDCommonConstants.DateConstants.GMT);
				final long frmDate = objGregorianCalendar.getTimeInMillis();
				
				GregorianCalendar objGregorianCalendarToDate = new GregorianCalendar();
				objGregorianCalendarToDate.setTime(formatter.parse(toDate));
				RMDCommonUtility.setZoneOffsetTime(
						objGregorianCalendarToDate, RMDCommonConstants.DateConstants.GMT);
				long todate = objGregorianCalendarToDate.getTimeInMillis();
				ArrayList<Number> entry = null;
				ArrayList<ArrayList<Number>> sub_temp_array = null;
				final ArrayList<ArrayList<ArrayList<Number>>> columnData = new ArrayList<ArrayList<ArrayList<Number>>>();
				Long time_entry = 0L;
				for (int i = 0; i < objVisualizationDetailsResponseType.length; i++) {

					mpParmdesc.add(objVisualizationDetailsResponseType[i]
							.getDisplayName());
					stackOrder.add(objVisualizationDetailsResponseType[i].getStackOrder());					
					assets.add(objVisualizationDetailsResponseType[i].getAsset());
					if (null == objVisualizationDetailsResponseType[i]
							.getLstParmDetails()
							|| objVisualizationDetailsResponseType[i]
									.getLstParmDetails().size() == 0) {
						sub_temp_array = new ArrayList<ArrayList<Number>>();
						entry = new ArrayList<Number>();
						entry.add(frmDate);
						entry.add(null);
						sub_temp_array.add(entry);
						entry = new ArrayList<Number>();
						entry.add(todate);
						entry.add(null);
						sub_temp_array.add(entry);
						columnData.add(sub_temp_array);
					} else {
						sub_temp_array = new ArrayList<ArrayList<Number>>();
						for (Iterator iterator = objVisualizationDetailsResponseType[i]
								.getLstParmDetails().iterator(); iterator
								.hasNext();) {

							VisualizationParmDetailsType objDetailsType = (VisualizationParmDetailsType) iterator
									.next();
							time_entry = 0L;
							
//							date = (Date) formatter.parse(objDetailsType
//									.getOccurTime());
//							time_entry = date.getTime();
							time_entry = objDetailsType
							.getOccurTime();
							
							entry = new ArrayList<Number>();
							entry.add(time_entry);
							if (null != objDetailsType.getParmValue()
									&& !RMDCommonConstants.EMPTY_STRING
											.equalsIgnoreCase(objDetailsType
													.getParmValue())) {
								entry.add(Float.parseFloat(objDetailsType
										.getParmValue()));
							} else {
								entry.add(null);
							}
							sub_temp_array.add(entry);
//							if(!iterator.hasNext()){
//								entry = new ArrayList<Number>();
//								entry.add(frmDate);
//								entry.add(null);
//								sub_temp_array.add(entry);
//								entry = new ArrayList<Number>();
//								entry.add(todate);
//								entry.add(null);
//								sub_temp_array.add(entry);
//							}
							

						}
						columnData.add(sub_temp_array);
					}

				}
				
				
				objVisualizationDataResponseVO.setColHeader(mpParmdesc);
				objVisualizationDataResponseVO.setColData(columnData);
				objVisualizationDataResponseVO.setStackOrder(stackOrder);
                objVisualizationDataResponseVO.setAssets(assets);
			}

			return objVisualizationDataResponseVO;

		} catch (Exception ex) {
			logger.error("Exception occured in VisualizationserviceImpl()", ex);
			throw ex;
		}

	}
	
	
	/**
	 * @Author:
	 * @param
	 * @return Map<String, Map<String, String>>
	 * @Description: This method used to fetch the graphNames based on source,sourceType and controllerCfg
	 */
	@Cacheable(value = { "graphNameCache" }, key = "#source")
	public Map<String, Map<String, String>> getGraphName(String controllerCfg,
			String source, String sourceType) throws RMDWebException, Exception {

		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		Map<String, String> graphMap = new LinkedHashMap<String, String>();
		final Map<String, Map<String, String>> graphMapDetails = new LinkedHashMap<String, Map<String, String>>();
		final Map<String,Map<String, String>> graphDetailsMap= new HashMap<String, Map<String, String>>();
		try {

			queryParamMap.put(AppConstants.VISUALIZATION_SOURCE_TYPE,
					sourceType);
			queryParamMap.put(AppConstants.DATASOURCE, source);
			queryParamMap.put(AppConstants.CONTROLLER_CONFIG, controllerCfg);

			final GraphDetailsResponseType[] graphDetailsResponseType = (GraphDetailsResponseType[]) rsInvoker
					.get(ServiceConstants.GET_VISUALIZATION_GRAPH_NAMES, null,
							queryParamMap, null,
							GraphDetailsResponseType[].class);

			for (int i = 0; i < graphDetailsResponseType.length; i++) {
				String graphName = graphDetailsResponseType[i].getGraphName();
				String mpParm = graphDetailsResponseType[i].getGraphMPNum();
				String cntrlCfg=graphDetailsResponseType[i].getControllerCfg();
				String srcType=graphDetailsResponseType[i].getSourceType();		
				String stackOrder=graphDetailsResponseType[i].getStackOrder();
				if (graphMapDetails.containsKey(cntrlCfg+RMDCommonConstants.UNDERSCORE+graphName+RMDCommonConstants.UNDERSCORE+srcType)) {	
					
					graphMap=graphMapDetails.get(cntrlCfg+RMDCommonConstants.UNDERSCORE+graphName+RMDCommonConstants.UNDERSCORE+srcType);
					if(graphMap.containsKey(graphName)){
						if(!graphMap.get(graphName).contains(mpParm+"~")){
						graphMap.put(graphName, graphMap.get(graphName)
								+ RMDCommonConstants.COMMMA_SEPARATOR + mpParm+"~"+stackOrder);
						}
					}
					graphMapDetails.put(cntrlCfg+RMDCommonConstants.UNDERSCORE+graphName+RMDCommonConstants.UNDERSCORE+srcType, graphMap);
				} else {
					graphMap = new LinkedHashMap<String, String>();					
					graphMap.put(graphName,mpParm+"~"+stackOrder);
					graphMapDetails.put(cntrlCfg+RMDCommonConstants.UNDERSCORE+graphName+RMDCommonConstants.UNDERSCORE+srcType,graphMap);
					
				}
				if(graphDetailsMap.containsKey(cntrlCfg+RMDCommonConstants.UNDERSCORE+srcType)){					
					Map<String,String> tempGraphMap=graphDetailsMap.get(cntrlCfg+RMDCommonConstants.UNDERSCORE+srcType);
					tempGraphMap.put(graphName, graphMapDetails.get(cntrlCfg+RMDCommonConstants.UNDERSCORE+graphName+RMDCommonConstants.UNDERSCORE+srcType).get(graphName));
					graphDetailsMap.put(cntrlCfg+RMDCommonConstants.UNDERSCORE+srcType,tempGraphMap);
				}else{
				graphDetailsMap.put(cntrlCfg+RMDCommonConstants.UNDERSCORE+srcType,graphMapDetails.get(cntrlCfg+RMDCommonConstants.UNDERSCORE+graphName+RMDCommonConstants.UNDERSCORE+srcType));
				}

			}

			
		} catch (Exception ex) {
			throw ex;
		}
		return graphDetailsMap;
	}

		
	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @Description: This method is used to fetch the visualization lookup values
	 */
	public Map<String, String> getVisualizationLookUps(String listName)
			throws RMDWebException, Exception {
		Map<String, String> listNameMap = null;
		Map<String, String> resultMap = new LinkedHashMap<String, String>();;
		try {
			listNameMap = new LinkedHashMap<String, String>();
			listNameMap.put(AppConstants.LIST_NAME, listName);

			ApplicationParametersResponseType[] applParamResponseType = getLookupValue(listNameMap);
			for (int i = 0; i < applParamResponseType.length; i++) {
				resultMap.put(applParamResponseType[i]
						.getLookupValue(),applParamResponseType[i].getLookupValue());
			}

		} catch (Exception ex) {
			throw ex;
		}
		return resultMap;

	}
	
	
	public Map<String, String> getFaultCode(String faultCode,String controllerCfg)
	throws RMDWebException, Exception {

		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		Map<String, String> faultCodeMap = new LinkedHashMap<String, String>();
		try {
			queryParamMap.put(AppConstants.CONTROLLER_CONFIG,
					controllerCfg);
			queryParamMap.put(AppConstants.OMD_VISUALIZATION_FAULT_CODE, faultCode);

			final FaultCodeDetailsResponseType[] objFaultCodeDetailsResponseType = (FaultCodeDetailsResponseType[]) rsInvoker
					.get(ServiceConstants.GET_FAULT_CODES, null,
							queryParamMap, null,
							FaultCodeDetailsResponseType[].class);
			
			for (int i = 0; i < objFaultCodeDetailsResponseType.length; i++) {				
				faultCodeMap.put(objFaultCodeDetailsResponseType[i].getFaultCode(), objFaultCodeDetailsResponseType[i].getFaultDetail());
			
			}

		} catch (Exception ex) {
			throw ex;
		}
		return faultCodeMap;

}
	
	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @Description: This method is used to fetch the visualization lookup values
	 */
	@Cacheable("logicalOperatorsCache")
	public Map<String, Map<String,String>> getLogicalOperators()
			throws RMDWebException, Exception {
		Map<String, String> listNameMap = null;
		Map<String,Map<String,String>> resultMap = new LinkedHashMap<String, Map<String,String>>();
		Map<String, String> logicalOperatorsMap = new LinkedHashMap<String, String>();
		try {
			listNameMap = new LinkedHashMap<String, String>();
			listNameMap.put(AppConstants.LIST_NAME, AppConstants.OMD_LOGICAL_OPERATORS);

			ApplicationParametersResponseType[] applParamResponseType = getLookupValue(listNameMap);
			for (int i = 0; i < applParamResponseType.length; i++) {
				if(resultMap.containsKey(applParamResponseType[i]
						.getListDescription())){
					logicalOperatorsMap=resultMap.get(applParamResponseType[i].getListDescription());
					logicalOperatorsMap.put(applParamResponseType[i]
						.getLookupValue(), applParamResponseType[i]
						.getLookupValue());
				resultMap.put(applParamResponseType[i]
						.getListDescription(),logicalOperatorsMap);
				}else{
					logicalOperatorsMap=new LinkedHashMap<String, String>();
					logicalOperatorsMap.put(applParamResponseType[i]
						.getLookupValue(), applParamResponseType[i]
						.getLookupValue());
					resultMap.put(applParamResponseType[i]
					            						.getListDescription(),logicalOperatorsMap);
				}
			}

		} catch (Exception ex) {
			throw ex;
		}
		return resultMap;

	}
	
	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @Description: This method is used to fetch the visualization lookup values
	 */
	public Map<String, String> getLookUpValuesWithDescription(String listName)
			throws RMDWebException, Exception {
		Map<String, String> listNameMap = null;
		Map<String, String> resultMap = new LinkedHashMap<String, String>();;
		try {
			listNameMap = new LinkedHashMap<String, String>();
			listNameMap.put(AppConstants.LIST_NAME, listName);

			ApplicationParametersResponseType[] applParamResponseType = getLookupValue(listNameMap);
			for (int i = 0; i < applParamResponseType.length; i++) {
				resultMap.put(applParamResponseType[i]
						.getLookupValue(),applParamResponseType[i].getListDescription());
			}

		} catch (Exception ex) {
			throw ex;
		}
		return resultMap;

	}
	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @Description: This method is used to fetch the visualization No Of days for Date Ranges
	 */
	public int getVisualizationNoOfDays(String listName)
			throws RMDWebException, Exception {
		Map<String, String> listNameMap = null;
		int numOfDays = 0;
		try {
			listNameMap = new LinkedHashMap<String, String>();
			listNameMap.put(AppConstants.LIST_NAME, listName);

			ApplicationParametersResponseType[] applParamResponseType = getLookupValue(listNameMap);
			if(applParamResponseType.length>0){
				numOfDays=Integer.parseInt(applParamResponseType[0].getLookupValue());
				
			}
			

		} catch (Exception ex) {
			throw ex;
		}
		return numOfDays;

	}
	
	
	
	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @Description: This method is used to fetch the visualization Default Values from lookup table
	 */
	public String getVisualizationDefaultValues(String listName)
			throws RMDWebException, Exception {
		Map<String, String> listNameMap = null;
		String defaultValue=RMDCommonConstants.EMPTY_STRING;
		try {
			listNameMap = new LinkedHashMap<String, String>();
			listNameMap.put(AppConstants.LIST_NAME, listName);

			ApplicationParametersResponseType[] applParamResponseType = getLookupValue(listNameMap);
			if(null!=applParamResponseType){
			for (int i = 0; i < applParamResponseType.length; i++) {
				defaultValue=applParamResponseType[0].getLookupValue();
			}
			}

		} catch (Exception ex) {
			throw ex;
		}
		return defaultValue;

	}
	/**
	 * @Author:
	 * @param
	 * @return Map<String, Map<String, String>>
	 * @Description: This method used to fetch the graphNames based on source,sourceType and controllerCfg
	 */
	@Cacheable(value = { "mpParmDetailsCache" }, key = "#sourceType")
	public Map<String,Map<String,String>> getVisualizationParmNumbers(
			final String source,final String sourceType,final String controllerCfg) throws RMDWebException, Exception {

		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		Map<String,Map<String,String>> parmDetailsMap=new LinkedHashMap<String, Map<String,String>>();
		 Map<String,String> parmDetails;
		try {
			queryParamMap.put(AppConstants.VISUALIZATION_SOURCE_TYPE,
					sourceType);
			queryParamMap.put(AppConstants.DATASOURCE, source);
			queryParamMap.put(AppConstants.CONTROLLER_CONFIG, controllerCfg);

			final MPParmDetailsResponseType[] mpParmDetailsResponseType = (MPParmDetailsResponseType[]) rsInvoker
					.get(ServiceConstants.GET_VISUALIZATION_PARM_NUMBERS, null,
							queryParamMap, null,
							MPParmDetailsResponseType[].class);

			for (int i = 0; i < mpParmDetailsResponseType.length; i++) {
				
				String ctrlCfg=mpParmDetailsResponseType[i].getControllerCfg();
				String parmNum=mpParmDetailsResponseType[i].getParmNumColName();
				String parmNumDesc=mpParmDetailsResponseType[i].getParmDescriptionName();
				String controllerType=mpParmDetailsResponseType[i].getControllerType();
				String columnName=mpParmDetailsResponseType[i].getColumnName();
				if(parmDetailsMap.containsKey(ctrlCfg)){
					parmDetails=parmDetailsMap.get(ctrlCfg);
					if(sourceType.equalsIgnoreCase(AppConstants.ENGINERECORDER)){						
						parmDetails.put(columnName, parmNumDesc);
						parmDetailsMap.put(controllerType, parmDetails);						
					}else{
						parmDetails.put(parmNum, parmNumDesc);						
					}
					parmDetailsMap.put(ctrlCfg, parmDetails);
					
				}else{
					parmDetails=new LinkedHashMap<String, String>();
					if(sourceType.equalsIgnoreCase(AppConstants.ENGINERECORDER)){
						
						parmDetails.put(columnName, parmNumDesc);										
						parmDetailsMap.put(controllerType, parmDetails);						
					}else{
						parmDetails.put(parmNum, parmNumDesc);
					}
					parmDetailsMap.put(ctrlCfg, parmDetails);	
				}

			}

			
		} catch (Exception ex) {
			throw ex;
		}
		return parmDetailsMap;
	}
	
	/**
	 * @Author:
	 * @param
	 * @return Map<List<String> , ArrayList<ArrayList<ArrayList<Number>>>>
	 * @Description: This method will return the data needed to plot the chart
	 */
	public List<VisualizationEventDataVO> getAssetVisualizationEventData(
			final VisualizationEventDataVO objVisualizationEventDataVO)
			throws RMDWebException, Exception {

		final VisualizationEventDataRequestType objVisualizationEventDataRequestType = new VisualizationEventDataRequestType();
		List<VisualizationEventDataVO> arlEventDataVO=new ArrayList<VisualizationEventDataVO>();
		VisualizationEventDataVO objEventDataVO=null;
		Map<String,String> eventTypeMap=new LinkedHashMap<String, String>();
		eventTypeMap=getLookUpValuesWithDescription(AppConstants.VISUALIZATION_EVENT_TYPES);
		try {
			if (null != objVisualizationEventDataVO) {
				
				objVisualizationEventDataRequestType
						.setAssetGroupName(objVisualizationEventDataVO
								.getAssetGroupName());
				objVisualizationEventDataRequestType
						.setAssetNumber(objVisualizationEventDataVO.getAssetNumber());
				objVisualizationEventDataRequestType
						.setControllerCfg(objVisualizationEventDataVO
								.getControllerCfg());
				objVisualizationEventDataRequestType
						.setCustomerId(objVisualizationEventDataVO.getCustomerId());
				objVisualizationEventDataRequestType
						.setFromDate(objVisualizationEventDataVO.getFromDate());
				objVisualizationEventDataRequestType
						.setToDate(objVisualizationEventDataVO.getToDate());
				objVisualizationEventDataRequestType
						.setUserLanguage(objVisualizationEventDataVO.getUserLanguage());
				objVisualizationEventDataRequestType.setNoOfDays(objVisualizationEventDataVO.getNoOfDays());
					
				VisualizationEventDataResponseType[] objVisualizationEventDataResponseType = (VisualizationEventDataResponseType[]) rsInvoker
						.post(ServiceConstants.GET_VISUALIZATION_EVENT_DATA,
								objVisualizationEventDataRequestType,
								VisualizationEventDataResponseType[].class);
				
				for (int i = 0; i < objVisualizationEventDataResponseType.length; i++) {	
					objEventDataVO = new VisualizationEventDataVO();
					String eventType=objVisualizationEventDataResponseType[i]
					                           							.getEventType();
					objEventDataVO
							.setEventDetails(ESAPI.encoder().decodeForHTML(objVisualizationEventDataResponseType[i]
									.getEventDetails()));
					
					objEventDataVO
					.setEventEndDate(objVisualizationEventDataResponseType[i]
							.getEventEndDate());
					
					objEventDataVO
					.setEventOccurDate(objVisualizationEventDataResponseType[i]
							.getEventOccurDate());
					
					objEventDataVO
					.setEventType(eventType);
					
					if(eventTypeMap.containsKey(eventType)){
						objEventDataVO
						.setEventTypeSymbol(eventTypeMap.get(eventType));
					}
					
					objEventDataVO
					.setEventSummary(ESAPI.encoder().decodeForHTML(objVisualizationEventDataResponseType[i]
							.getEventSummary()));
					
					objEventDataVO.setStrEvntOccurDt(objVisualizationEventDataResponseType[i]
							.getStrEventOccurDt());
					objEventDataVO.setStrEvntEndDt(objVisualizationEventDataResponseType[i]
					                                           							.getStrEventEndDt());
					arlEventDataVO
							.add(objEventDataVO);
				
					
				}

				
			}

			

		} catch (Exception ex) {
			logger.error("Exception occured in VisualizationserviceImpl()", ex);
			throw ex;
		}
		return arlEventDataVO;

	}
	
	/**
	 * @Author:
	 * @param
	 * @return Map<String, Map<String, String>>
	 * @Description: This method used to fetch the Asset family for fetching
	 *               virtual parameters
	 */

	public String getVizAssetFamily(String model) throws RMDWebException,
			Exception {

		final Map<String, String> pathParamMap = new LinkedHashMap<String, String>();
		String family = RMDCommonConstants.EMPTY_STRING;
		try {
			pathParamMap.put(AppConstants.MODEL, model);
			family = (String) rsInvoker.get(
					ServiceConstants.GET_VISUALIZATION_VIRTUAL_FAMILY,
					pathParamMap, null, null, String.class);

		} catch (Exception ex) {
			throw ex;
		}
		return family;
	}

	/**
	 * @Author:
	 * @param
	 * @return Map<String, Map<String, String>>
	 * @Description: This method used to fetch the virtualParameters based on
	 *               family
	 */
	@Cacheable(value = { "virtualParametersCache" }, key = "#family")
	public Map<String, Map<String, String>> getVizVirtualParameters(
			final String family, final String database) throws RMDWebException,
			Exception {

		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		Map<String, Map<String, String>> virtualParmDetailsMap = new LinkedHashMap<String, Map<String, String>>();
		Map<String, String> virtualParmDetails;
		try {
			queryParamMap.put(AppConstants.DATABASE, database);

			final VirtualParametersResponseType[] virtualParametersResponseType = (VirtualParametersResponseType[]) rsInvoker
					.get(ServiceConstants.GET_VISUALIZATION_VIRTUAL_PARAMETERS,
							null, queryParamMap, null,
							VirtualParametersResponseType[].class);

			for (int i = 0; i < virtualParametersResponseType.length; i++) {

				String strFamily = virtualParametersResponseType[i].getFamily();
				String virtualParmNum = virtualParametersResponseType[i]
						.getVirtualName();
				String virtualId = virtualParametersResponseType[i]
						.getVirtualId();

				if (virtualParmDetailsMap.containsKey(strFamily)) {
					virtualParmDetails = virtualParmDetailsMap.get(strFamily);
					virtualParmDetails.put(virtualId, virtualParmNum);
					virtualParmDetailsMap.put(strFamily, virtualParmDetails);

				} else {
					virtualParmDetails = new LinkedHashMap<String, String>();
					virtualParmDetails.put(virtualId, virtualParmNum);
					virtualParmDetailsMap.put(strFamily, virtualParmDetails);

				}

			}

		} catch (Exception ex) {
			throw ex;
		}
		return virtualParmDetailsMap;
	}
	
	
	/**
	 * This method will call web-service to return list of asset numbers for
	 * given keys like customerId, assetGroup and assetnumber
	 */
	public Map<String,String> getAssets(AssetBean assetBean) throws RMDWebException,
			Exception {

		AssetResponseType[] assetResponses = null;
		final Map<String, String> headerParams = getHeaderMap(assetBean);
		Map<String, String> mpAssets = new LinkedHashMap<String, String>();
		
		try {
			AssetsRequestType objAssetsReqType=new AssetsRequestType();
			objAssetsReqType.setLanguage(headerParams.get(AppConstants.USER_LANGUAGE));
			objAssetsReqType.setCustomerId(assetBean.getCustomerId());
			objAssetsReqType.setFleetId(assetBean.getFleetId());			
			assetResponses = (AssetResponseType[])rsInvoker
					.post(ServiceConstants.GET_ASSETS, objAssetsReqType, AssetResponseType[].class);

			for (int i = 0; i < assetResponses.length; i++) {
				mpAssets.put(assetResponses[i].getAssetNumber()+AppConstants.HYPHEN+assetResponses[i].getAssetGroupName()+AppConstants.NEGOTION_SYMBOL+assetResponses[i].getAssetId(), assetResponses[i].getAssetNumber()+RMDCommonConstants.HYPHEN_WITHSPACE+assetResponses[i].getAssetGroupName());
			}

		} catch (Exception ex) {
			throw ex;
		}
		return mpAssets;
	}
	
	
	/**
	 * @Author:
	 * @param
	 * @return Map<List<String> , ArrayList<ArrayList<ArrayList<Number>>>>
	 * @Description: This method will return the data needed to plot the chart
	 */
	public VisualizationDataResponseVO  getRxVizPlotData(
			final VisualizationDetailsBean objVisualizationBean)
			throws RMDWebException, Exception {

		final VisualizationDetailsRequestType objVisualizationDetailsRequestType = new VisualizationDetailsRequestType();
		Map<List<String>, ArrayList<ArrayList<ArrayList<Number>>>> chartData = new HashMap<List<String>, ArrayList<ArrayList<ArrayList<Number>>>>();
		VisualizationDataResponseVO objVisualizationDataResponseVO=new VisualizationDataResponseVO();
		try {
			if (null != objVisualizationBean) {
				
				objVisualizationDetailsRequestType
						.setAssetGroupName(objVisualizationBean
								.getAssetGroupName());
				objVisualizationDetailsRequestType
						.setAssetNumber(objVisualizationBean.getAssetNumber());				
				objVisualizationDetailsRequestType
						.setCustomerId(objVisualizationBean.getCustomerId());
				objVisualizationDetailsRequestType.setRxObjId(objVisualizationBean.getRxObjid());
								
				VisualizationDetailsResponseType[] objVisualizationDetailsResponseType = (VisualizationDetailsResponseType[]) rsInvoker
						.post(ServiceConstants.GET_RX_VISUALIZATION_DETAILS,
								objVisualizationDetailsRequestType,
								VisualizationDetailsResponseType[].class);
				List<String> mpParmdesc=new ArrayList<String>();
				List<String> lstAxisSide=new ArrayList<String>();
				
				final String fromDate = objVisualizationBean.getFromDate();
				final String toDate = objVisualizationBean.getToDate();
				DateFormat formatter;
				formatter = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
							
				GregorianCalendar objGregorianCalendar = new GregorianCalendar();
				objGregorianCalendar.setTime(formatter.parse(fromDate));
				RMDCommonUtility.setZoneOffsetTime(
						objGregorianCalendar, RMDCommonConstants.DateConstants.GMT);
				final long frmDate = objGregorianCalendar.getTimeInMillis();
				
				GregorianCalendar objGregorianCalendarToDate = new GregorianCalendar();
				objGregorianCalendarToDate.setTime(formatter.parse(toDate));
				RMDCommonUtility.setZoneOffsetTime(
						objGregorianCalendarToDate, RMDCommonConstants.DateConstants.GMT);
				long todate = objGregorianCalendarToDate.getTimeInMillis();
				ArrayList<Number> entry = null;
				ArrayList<ArrayList<Number>> sub_temp_array = null;
				final ArrayList<ArrayList<ArrayList<Number>>> columnData = new ArrayList<ArrayList<ArrayList<Number>>>();
				Long time_entry = 0L;
				for (int i = 0; i < objVisualizationDetailsResponseType.length; i++) {

					mpParmdesc.add(objVisualizationDetailsResponseType[i]
							.getDisplayName());
					lstAxisSide.add(objVisualizationDetailsResponseType[i]
							.getAxisSide());
					objVisualizationDataResponseVO.setRightDependentAxis(objVisualizationDetailsResponseType[i]
							.getRightDependentAxis());
					objVisualizationDataResponseVO.setLeftDependentAxis(objVisualizationDetailsResponseType[i]
							.getLeftDependentAxis());
					objVisualizationDataResponseVO.setInDependentAxis(objVisualizationDetailsResponseType[i]
							.getIndependentAxis());
					objVisualizationDataResponseVO.setTitle(objVisualizationDetailsResponseType[i]
							.getTitle());
					if (null == objVisualizationDetailsResponseType[i]
							.getLstParmDetails()
							|| objVisualizationDetailsResponseType[i]
									.getLstParmDetails().size() == 0) {
						sub_temp_array = new ArrayList<ArrayList<Number>>();
						entry = new ArrayList<Number>();
						entry.add(frmDate);
						entry.add(null);
						sub_temp_array.add(entry);
						entry = new ArrayList<Number>();
						entry.add(todate);
						entry.add(null);
						sub_temp_array.add(entry);
						columnData.add(sub_temp_array);
					} else {
						sub_temp_array = new ArrayList<ArrayList<Number>>();
						for (Iterator iterator = objVisualizationDetailsResponseType[i]
								.getLstParmDetails().iterator(); iterator
								.hasNext();) {

							VisualizationParmDetailsType objDetailsType = (VisualizationParmDetailsType) iterator
									.next();
							time_entry = objDetailsType
							.getOccurTime();
							
							entry = new ArrayList<Number>();
							entry.add(time_entry);
							if (null != objDetailsType.getParmValue()
									&& !RMDCommonConstants.EMPTY_STRING
											.equalsIgnoreCase(objDetailsType
													.getParmValue())) {
								entry.add(Float.parseFloat(objDetailsType
										.getParmValue()));
							} else {
								entry.add(null);
							}
							sub_temp_array.add(entry);

						}
						columnData.add(sub_temp_array);
					}

				}
	
				objVisualizationDataResponseVO.setColHeader(mpParmdesc);
				objVisualizationDataResponseVO.setColData(columnData);
				objVisualizationDataResponseVO.setLstAxisSide(lstAxisSide);
			}
			return objVisualizationDataResponseVO;

		} catch (Exception ex) {
			logger.error("Exception occured in VisualizationserviceImpl()", ex);
			throw ex;
		}

	}
	
	/**
	 * @Author:
	 * @param
	 * @return Map<String, Map<String, String>>
	 * @Description: This method used to fetch the Asset family for fetching
	 *               virtual parameters
	 */

	public RxVisualizationPlotInfoVO  getRxVizPlotInfo(
			String rxObjid) throws RMDWebException,
			Exception {
		final Map<String, String> pathParamMap = new LinkedHashMap<String, String>();
		RxVisualizationPlotInfoVO objRxVisualizationPlotInfoVO=null;
		try {
			pathParamMap.put(AppConstants.RX_OBJ_ID, rxObjid);
			RxVisualizationPlotInfoType  rxVisualizationPlotInfoType= (RxVisualizationPlotInfoType) rsInvoker.get(
					ServiceConstants.GET_RX_VISUALIZATION_PLOT_INFO,
					pathParamMap, null, null, RxVisualizationPlotInfoType.class);
			if(null!=rxVisualizationPlotInfoType){
				objRxVisualizationPlotInfoVO=new RxVisualizationPlotInfoVO();
				objRxVisualizationPlotInfoVO.setTitle(rxVisualizationPlotInfoType.getTitle());
				objRxVisualizationPlotInfoVO.setIndependentAxisLabel(rxVisualizationPlotInfoType.getIndependentAxisLabel());
				objRxVisualizationPlotInfoVO.setLeftDependentAxisLabel(rxVisualizationPlotInfoType.getLeftDependentAxisLabel());
				objRxVisualizationPlotInfoVO.setRightDependentAxisLabel(rxVisualizationPlotInfoType.getRightDependentAxisLabel());
				objRxVisualizationPlotInfoVO.setDataset1ParameterName(rxVisualizationPlotInfoType.getDataset1ParameterName());
				objRxVisualizationPlotInfoVO.setDataset1Label(rxVisualizationPlotInfoType.getDataset1Label());
				objRxVisualizationPlotInfoVO.setDataset1Axis(rxVisualizationPlotInfoType.getDataset1Axis());
				objRxVisualizationPlotInfoVO.setDataset2ParameterName(rxVisualizationPlotInfoType.getDataset2ParameterName());
				objRxVisualizationPlotInfoVO.setDataset2Label(rxVisualizationPlotInfoType.getDataset2Label());
				objRxVisualizationPlotInfoVO.setDataset2Axis(rxVisualizationPlotInfoType.getDataset2Axis());
				objRxVisualizationPlotInfoVO.setDataset3ParameterName(rxVisualizationPlotInfoType.getDataset3ParameterName());
				objRxVisualizationPlotInfoVO.setDataset3Label(rxVisualizationPlotInfoType.getDataset3Label());
				objRxVisualizationPlotInfoVO.setDataset3Axis(rxVisualizationPlotInfoType.getDataset3Axis());
				objRxVisualizationPlotInfoVO.setDataset4ParameterName(rxVisualizationPlotInfoType.getDataset4ParameterName());
				objRxVisualizationPlotInfoVO.setDataset4Label(rxVisualizationPlotInfoType.getDataset4Label());
				objRxVisualizationPlotInfoVO.setDataset4Axis(rxVisualizationPlotInfoType.getDataset4Axis());
			}

		} catch (Exception ex) {
			throw ex;
		}
		return objRxVisualizationPlotInfoVO;
	}
}
