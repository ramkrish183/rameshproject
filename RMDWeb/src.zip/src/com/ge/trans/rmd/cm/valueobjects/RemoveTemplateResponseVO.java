package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

public class RemoveTemplateResponseVO {

		private String status;

		private List<RemoveTemplateStatusDetails> details;

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public List<RemoveTemplateStatusDetails> getDetails() {
			return details;
		}

		public void setDetails(List<RemoveTemplateStatusDetails> details) {
			this.details = details;
		}

}
