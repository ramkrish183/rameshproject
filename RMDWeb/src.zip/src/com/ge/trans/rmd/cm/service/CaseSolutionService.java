package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;
import com.ge.trans.rmd.cm.valueobjects.CaseResponseVO;
import com.ge.trans.rmd.cm.valueobjects.ReCloseVO;
import com.ge.trans.rmd.cm.valueobjects.RepairCodeVO;
import com.ge.trans.rmd.common.beans.CaseAppendVO;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.beans.CaseSolutionVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.valueobjects.RxDetailsVO;
import com.ge.trans.rmd.services.cases.valueobjects.ToolOutputResponseType;

public interface CaseSolutionService {
	/**
	 * @throws RMDWebException
	 *             This is the method used for add RX through jquery ajax
	 * @param CaseSolutionVO
	 * @return
	 * @throws
	 */
	void addRXToCase(CaseSolutionVO caseBeanAddRx) throws RMDWebException;

	/**
	 * @throws RMDWebException
	 *             This is the method used for deliver Rx through jquery ajax
	 * @param CaseSolutionVO
	 * @return String
	 * @throws
	 */
	void deliverRXToCase(CaseSolutionVO caseBeanAddRx) throws RMDWebException;
	
	/**
	 * @return 
	 * @throws RMDWebException
	 *             This is the method used for deliver Rx through jquery ajax
	 * @param CaseSolutionVO
	 * @return String
	 * @throws
	 */
	String closeCase(CaseSolutionVO caseBeanAddRx) throws RMDWebException;

	/**
	 * @Author:
	 * @param:scoreAndCloseCaseVO
	 * @return:String
	 * @throws RMDWebException
	 * @Description: This method is used for saving the manual feedback
	 */
	String saveManualFeedback(CaseSolutionVO scoreAndCloseCaseVO)
			throws RMDWebException;
	/**
	 * @return 
	 * @param flag 
	 * @throws RMDWebException
	 *             This is the method used for score Rx and close through jquery ajax
	 * @param CaseSolutionVO
	 * @return String
	 * @throws
	 */
	
	Map<String, String> scoreRxAndCloseCase(CaseSolutionVO caseBeanAddRx, String isScoreFlag) throws RMDWebException;

	/**
	 * @throws RMDWebException
	 *             This is the method used for get the look up for score RX
	 * @return Map<String, String> 
	 * @throws
	 */
	Map<String, String> getlookupForRxScoring() throws RMDWebException;
	/**
	 * @throws RMDWebException
	 *             This is the method used for get Close out Repair Codes
	 * @return List<CaseSolutionVO> 
	 * @throws RMDWebException
	 */
	List<CaseSolutionVO> getCloseOutRepairCodes(String recomId)  throws RMDWebException;
	/**
	 * @throws RMDWebException
	 *             This is the method used for get case Repair Codes
	 * @return List<CaseSolutionVO> 
	 * @throws RMDWebException
	 */
	List<CaseSolutionVO> getCaseRepairCodes(String caseId) throws RMDWebException;
	/**
	 * @throws RMDWebException
	 *             This is the method used for get  Repair Codes
	 * @return List<CaseSolutionVO> 
	 * @throws RMDWebException
	 */
	Map<String, String> getRepairCodes(CaseSolutionVO getRepairCodeInputs) throws RMDWebException;

	/**
	 * @throws RMDWebException
	 *             This is the method used for get select by values
	 * @return  List<String>
	 * @throws RMDWebException
	 */
	List<String> getlookupForSelectBy() throws RMDWebException;
	/**
	 * @throws RMDWebException
	 *             This is the method used for add repair code
	 * @return  List<String>
	 * @throws RMDWebException
	 */
	void addRepairCodes(CaseSolutionVO caseRepairCodes) throws RMDWebException;
	/**
	 * @throws RMDWebException
	 *             This is the method used for remove repair code
	 * @return  List<String>
	 * @throws RMDWebException
	 */
	void removeRepairCodes(CaseSolutionVO caseRepairCodes) throws RMDWebException;

	void addAndClose(CaseSolutionVO caseRepairCodes) throws RMDWebException;
	/**
	 * @throws RMDWebException
	 *             This is the method used to append an Rx to another case
	 * @param CaseAppendVO
	 * @return
	 * @throws RMDWebException
	 */
	void appendRXToCase(CaseAppendVO caseAppendVO) throws RMDWebException;
	/**
	 * @throws RMDWebException
	 *             This is the method used to enable/disable Deliver,Append,Close buttons
	 * @param CaseAppendVO
	 * @return boolean 
	 * @throws RMDWebException
	 */


	boolean enableAppendClose(CaseAppendVO caseAppendVO) throws RMDWebException;


	/**
	 * @throws RMDWebException
	 * This is the method used to get count of Open FL work order and 
	 * will be called while closing the Case will return the open work order count from the eservices
	 * @return  List<String>
	 * @throws RMDWebException
	 */
	int getOpenFLCount(String lmsLocoId) throws RMDWebException;
	
	/**
	 * This method is used to fetch tooloutput
	 * @return
	 * @throws RMDWebException
	 */
	List<ToolOutputResponseType> getToolOutputDetails(String caseId,String userTimeZone) throws RMDWebException;
	
	/**
	 * @throws RMDWebException
	 * @return String
	 * @throws RMDWebException
	 */
	String getLmsLocoID(String caseId) throws RMDWebException;
	
	String getCaseTitle(String caseId) throws RMDWebException;

	String moveToolOutput(CaseBean caseBean) throws RMDWebException;
	
	public String getTORepairCodes(String repairCode) throws RMDWebException;
	
	public Map<String, List<String>> getEnabledUnitRxsDeliver(String customerId,
			String assetGroupName, String assetNumber, String caseId,String caseType,String currentUser) throws RMDWebException;
	public String getRepairCodeMiss4F() throws RMDWebException;
	public String getRepairCodeMiss4B() throws RMDWebException;
	public String getRepairCodesID(String repairCode) throws RMDWebException;
	/**
	 * @Author :
	 * @return :List<RepairCodeVO>
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method is used to get false alarm details in data
	 *               screen
	 * 
	 */
	public List<RepairCodeVO> getFalseAlarmDetails(String rxObjId)
			throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<RxDetailsVO>
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method is used to get false alarm details in data
	 *               screen
	 * 
	 */
	public List<RxDetailsVO> getRXFalseAlarmDetails(String rxObjId)
			throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<RepairCodeVO>
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method is used to get mdsc accurate details in data
	 *               screen
	 * 
	 */
	public List<RepairCodeVO> getMDSCAccurateDetails(String rxObjId)
			throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<CaseBean>
	 * @param : String,String
	 * @throws :RMDWebException
	 * @Description: This method is used to get mdsc accurate-case details in
	 *               data screen
	 * 
	 */
	public List<CaseBean> getCaseDetails(String rxObjId, String repObjId)
			throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<RxDetailsVO>
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method is used to get mdsc accurate-rx details in data
	 *               screen
	 * 
	 */
	public List<RxDetailsVO> getMDSCRxDetails(String repObjId)
			throws RMDWebException;
	

	public void ReCloseCase(ReCloseVO objReCloseVO) throws RMDWebException;

	/**
	 * @param timeZnoe 
	 * @Author :Mohamed
	 * @return :CaseResponseVO
	 * @param : caseBean
	 * @throws :RMDWebException
	 * @Description: This method is used to check whether the rx is closed or not
	 */
	public CaseResponseVO getRxDetailsForReClose(CaseBean caseBean, String timeZnoe) throws Exception;

	/**
	  
	 * @Author :Mohamed
	 * @return :
	 * @param : ReCloseVO
	 * @throws :RMDWebException
	 * @Description: This method is used to update the case close result
	 */
	public void updateCloseCaseResult(ReCloseVO objReCloseVO) throws Exception;

}
