package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.valueobjects.HealthCheckAvailableVO;
import com.ge.trans.rmd.cm.valueobjects.HealthCheckSubmitVO;
import com.ge.trans.rmd.cm.valueobjects.HealthCheckVO;
import com.ge.trans.rmd.cm.valueobjects.MessageHistoryResponseVO;
import com.ge.trans.rmd.cm.valueobjects.HealthCheckFaultsDataVO;
import com.ge.trans.rmd.cm.valueobjects.HealthCheckFaultsServiceVO;
import com.ge.trans.rmd.cm.valueobjects.RDRNotificationsResponseVO;
import com.ge.trans.rmd.services.assets.valueobjects.RDRNotificationsSubmitRequest;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.services.assets.valueobjects.HealthCheckResponseType;


public interface HealthCheckService {

	public Map<String, String> getAssetHCMPGroups(String strAssetId,
			String strCustomerId, String strGrpName,String requestType,String assetType,String deviceName) throws RMDWebException,
			Exception;

	public HealthCheckAvailableVO IsHCAvailable(String strAssetId, String strCustomerId,
			String strGrpName) throws RMDWebException, Exception;

	public String getHCAssetType(String strAssetId, String strCustomerId,
			String strGrpName) throws RMDWebException, Exception;
	
	// SOC - Raj.S(212687474)
	public RDRNotificationsResponseVO getRDRNotifications(String userID)
			throws RMDWebException, Exception;
	
	public boolean insertRDRNotification(RDRNotificationsSubmitRequest notification)
			throws RMDWebException, Exception;
	
	public boolean updateRDRNotification(RDRNotificationsSubmitRequest notification)
			throws RMDWebException, Exception;
	
	public HealthCheckFaultsDataVO getHCFaults(Map<String,String> pathParamsMap, Map<String,String> queryParamsMap, Map<String,String> headerParamsMap)
			throws RMDWebException, Exception;
	// EOC
	
	public Map<String,String> submitHealthCheckRequest(String strAssetId, String strCustomerId,
			String strGrpName,String strSampleRate,String noOfPostSamples, String mpNumber,String strCustomerName,HealthCheckResponseType hcResponseType,String device,String typeOfUser) throws RMDWebException, Exception;

	public HealthCheckResponseType getSendMessageAttributes(String strAssetId, String strCustomerId,
			String strGrpName,String strInput,String strAssetType, String typeOfUser,String device)throws RMDWebException, Exception;	
	
	public MessageHistoryResponseVO viewHCMessageHistory(String strAssetId, String strCustomerId,
			String strGrpName, String userTimeZone,String platform, String userCustomer,String autoHC,String internalPrivilege , String fromDate , String toDate) throws RMDWebException, Exception;

	public  String getHCLookup(String listName) throws Exception;
	
	public Map<String, String> submitEGAHealthCheckRequest(HealthCheckSubmitVO healthCheckSubmitVO) throws RMDWebException, Exception;

	/**
	 * @param :HealthCheckSubmitVO
	 * @return String
	 * @throws Exception
	 * @Description:This method fetches device information.
	 */
	public String getDeviceInfo(HealthCheckSubmitVO objHealthCheckSubmitVO)
			throws RMDWebException, Exception;
	/**
	 * @param :HealthCheckSubmitVO
	 * @return String
	 * @throws Exception
	 * @Description:This method validates EGA HC Request.
	 */
	public String validateEGAHC(HealthCheckSubmitVO objHealthCheckSubmitVO)
			throws RMDWebException, Exception;

	/**
	 * @param :HealthCheckSubmitVO
	 * @return String
	 * @throws Exception
	 * @Description:This method validates NT HC Request.
	 */
	public String validateNTHC(HealthCheckSubmitVO objHealthCheckSubmitVO)
			throws RMDWebException, Exception;

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, List<String>>
	 * @throws:RMDWebException,Exception
	 * @Description: This method is used for fetching the Customer Name and Road
	 *               Number Headers.
	 */
	public Map<String, List<String>> getCustNameRNH() throws RMDWebException,
			Exception;
} 