package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.PathParam;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.CaseResponseVO;
import com.ge.trans.rmd.cm.valueobjects.ReCloseVO;
import com.ge.trans.rmd.cm.valueobjects.RepairCodeVO;
import com.ge.trans.rmd.common.beans.CaseAppendVO;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.beans.CaseSolutionVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
//import com.ge.trans.rmd.common.constants.OMDConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.valueobjects.RxDetailsVO;
import com.ge.trans.rmd.services.cases.valueobjects.CaseInfoType;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.RxVehicleBomResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseSolutionRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.RepairCodeDetailsType;
import com.ge.trans.rmd.services.cases.valueobjects.RxDetailsType;
import com.ge.trans.rmd.services.cases.valueobjects.ReCloseRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.RxHistoryResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.ToolOutputResponseType;
import com.ge.trans.rmd.utilities.AppSecUtil;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class CaseSolutionServiceImpl extends RMDBaseServiceImpl implements
		CaseSolutionService {
	@Autowired
	WebServiceInvoker webServiceInvoker;
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	/**
	 * @throws RMDWebException
	 *             This is the method used for add RX through jquery ajax
	 * @param CaseSolutionVO
	 * @return
	 * @throws
	 */
	@Override
	public void addRXToCase(CaseSolutionVO caseBeanAddRx)
			throws RMDWebException {
		CaseSolutionRequestType addRXRequestType = new CaseSolutionRequestType();
		final Map<String, String> headerParams = getHeaderMap(caseBeanAddRx);
		try {
			addRXRequestType.setCaseID(caseBeanAddRx.getCaseId());
			addRXRequestType.setSolutionTitle(caseBeanAddRx.getSolutionTitle());
			addRXRequestType.setUserName(caseBeanAddRx.getUserId());
			addRXRequestType.setSolutionID(caseBeanAddRx.getSolutionId());
			webServiceInvoker.put(ServiceConstants.ADDRX_TO_CASE,
					addRXRequestType, headerParams);
		} catch (RMDWebException e) {
			rmdWebLogger.error("Exception occured in addRXToCase() method ", e);
			throw e;
		}catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in addRXToCase() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

	}

	/**
	 * @throws RMDWebException
	 * @throws RMDWebException
	 *             This is the method used for deliver Rx through jquery ajax
	 * @param CaseSolutionVO
	 * @return
	 * @throws
	 */
	@Override
	public void deliverRXToCase(CaseSolutionVO caseBeanDeliverRx)
			throws RMDWebException {

		CaseSolutionRequestType deliverRXRequestType = new CaseSolutionRequestType();
		final Map<String, String> headerParams = getHeaderMap(caseBeanDeliverRx);
		String url = null;
		try {
			deliverRXRequestType.setCaseID(caseBeanDeliverRx.getCaseId());
			deliverRXRequestType.setRxCaseID(caseBeanDeliverRx.getRxCaseId());
			deliverRXRequestType.setSolutionTitle(caseBeanDeliverRx
					.getSolutionTitle());
			deliverRXRequestType.setUserName(caseBeanDeliverRx.getUserId());
			deliverRXRequestType.setSolutionID(caseBeanDeliverRx
					.getSolutionId());
			deliverRXRequestType.setUrgRepair(caseBeanDeliverRx.getUrgency());
			deliverRXRequestType.setEstmRepTime(caseBeanDeliverRx
					.getEstRepairCode());
			deliverRXRequestType.setRecomNotes(caseBeanDeliverRx.getNotes());
			deliverRXRequestType.setSolutionTitle(caseBeanDeliverRx
					.getSolutionTitle());
			if (AppConstants.MODIFY.equalsIgnoreCase(caseBeanDeliverRx
					.getAction())) {
				url = ServiceConstants.MODIFYRX_TO_CASE;
			} else if (AppConstants.REPLACE.equalsIgnoreCase(caseBeanDeliverRx
					.getAction())) {
				url = ServiceConstants.REPLACERX_TO_CASE;
			} else {
				url = ServiceConstants.DELIVERRX_TO_CASE;
			}
			webServiceInvoker.put(url,
					deliverRXRequestType, headerParams);
		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"Exception occured in deliverRXToCase() method ", e);
			throw e;
		}catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in deliverRXToCase method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
	}

	/**
	 * @Author:
	 * @param:scoreAndCloseCaseVO
	 * @return:String
	 * @throws RMDWebException
	 * @Description: This method is used for saving the manual feedback
	 */
	@Override
	public String saveManualFeedback(CaseSolutionVO scoreAndCloseCaseVO)
			throws RMDWebException {
		RxDetailsType savemanualfeedbackInfo = new RxDetailsType();
		String responseMessage = null;
		final Map<String, String> headerParams = getHeaderMap(scoreAndCloseCaseVO);
		try {
			savemanualfeedbackInfo.setUserName(scoreAndCloseCaseVO.getUserId());
			savemanualfeedbackInfo.setRxCaseID(scoreAndCloseCaseVO
					.getRxCaseId());
			savemanualfeedbackInfo.setRxFeedBack(scoreAndCloseCaseVO
					.getRxFeedBack());
			savemanualfeedbackInfo.setRxScoreCode(scoreAndCloseCaseVO
					.getRxFeedBackCode());
			savemanualfeedbackInfo.setCaseID(scoreAndCloseCaseVO.getCaseId());
			savemanualfeedbackInfo.setEoaUserName(scoreAndCloseCaseVO
					.getUserAlias());
			savemanualfeedbackInfo.setRxnotes(scoreAndCloseCaseVO.getNotes());
			savemanualfeedbackInfo.setIsReissue(scoreAndCloseCaseVO
					.getIsReissue());
			if (null != scoreAndCloseCaseVO.getRepairCodeId()
					&& !scoreAndCloseCaseVO.getRepairCodeId().isEmpty()) {
				for (String repaircode : scoreAndCloseCaseVO.getRepairCodeId()
						.split(AppConstants.COMMA)) {
					savemanualfeedbackInfo.getRepaircodeList().add(
							Long.valueOf(repaircode));
				}
			}
			webServiceInvoker.put(ServiceConstants.SAVE_MANUAL_FEEDBACK,
					savemanualfeedbackInfo, headerParams);
		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"Exception occured in saveManualFeedback() method ", e);
			throw e;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in saveManualFeedback() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return responseMessage;
	}
	/**
	 * @Description: function to close case
	 **/
	@Override
	public String closeCase(CaseSolutionVO caseBeanAddRx)
			throws RMDWebException {
		String responseMessage = null;
		RxDetailsType closeCaseInfo = new RxDetailsType();
		final Map<String, String> headerParams = getHeaderMap(caseBeanAddRx);
		try {
			closeCaseInfo.setCaseID(caseBeanAddRx.getCaseId());
			closeCaseInfo.setUserName(caseBeanAddRx.getUserId());
			webServiceInvoker.put(ServiceConstants.CLOSE_CASE, closeCaseInfo,
					headerParams);
		} catch (RMDWebException e) {
			rmdWebLogger.error("Exception occured in closeCase() method ", e);
			if (AppConstants.EXCEPTION_RMD_206.equalsIgnoreCase(e
					.getErrorCode())) {
				responseMessage = AppConstants.EXCEPTION_RMD_206;
			} else if (AppConstants.EXCEPTION_RMD_209.equalsIgnoreCase(e
					.getErrorCode())) {
				responseMessage = AppConstants.EXCEPTION_RMD_209;
			} else {
				RMDWebErrorHandler.handleException(e);
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in closeCase method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return responseMessage;
	}

	/**
	 * @Description: function to score and close rx
	 **/
	@Override
	public Map<String, String> scoreRxAndCloseCase(
			CaseSolutionVO scoreAndCloseCaseVO, String isScoreFlag)
			throws RMDWebException {
		RxDetailsType scoreAndCloseInfo = new RxDetailsType();
		Map<String, String> responseMessage = new HashMap<String, String>();
		final Map<String, String> headerParams = getHeaderMap(scoreAndCloseCaseVO);
		try {
			scoreAndCloseInfo.setUserName(scoreAndCloseCaseVO.getUserId());
			scoreAndCloseInfo.setRxCaseID(scoreAndCloseCaseVO.getRxCaseId());
			scoreAndCloseInfo.setRxScoreCode(scoreAndCloseCaseVO
					.getRxFeedBackCode());
			scoreAndCloseInfo.setCaseID(scoreAndCloseCaseVO.getCaseId());
			scoreAndCloseInfo.setRxNote(scoreAndCloseCaseVO.getRxNote());
			scoreAndCloseInfo.setFdbkType(scoreAndCloseCaseVO.getFdbkType());
			if (AppConstants.SCORE_RX_FLAG.equals(isScoreFlag)) {
				scoreAndCloseInfo.setScoreRx(AppConstants.TRUE);
			}
			if (null != scoreAndCloseCaseVO.getRepairCodeId()
					&& !scoreAndCloseCaseVO.getRepairCodeId().isEmpty()) {
				for (String repaircode : scoreAndCloseCaseVO.getRepairCodeId()
						.split(AppConstants.COMMA)) {
					scoreAndCloseInfo.getRepaircodeList().add(
							Long.valueOf(repaircode));
				}
			}
			webServiceInvoker.put(ServiceConstants.SCORE_RX_CLOSE_CASE,
					scoreAndCloseInfo, headerParams);
		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_RMD_205.equalsIgnoreCase(e
					.getErrorCode())) {
				responseMessage.put(AppConstants.EXCEPTION_RMD_205,
						AppConstants.EXCEPTION_RMD_205);
			} else if (AppConstants.EXCEPTION_RMD_206.equalsIgnoreCase(e
					.getErrorCode())) {
				responseMessage.put(AppConstants.EXCEPTION_RMD_206,
						AppConstants.EXCEPTION_RMD_206);
			} else if (AppConstants.EXCEPTION_RMD_215.equalsIgnoreCase(e
					.getErrorCode())) {
				if (null != e.getMessage() && !e.getMessage().isEmpty()) {
					responseMessage.put(AppConstants.EXCEPTION_RMD_215,
							e.getMessage());
				} else {
					responseMessage.put(AppConstants.EXCEPTION_RMD_215,
							AppConstants.SCORE_RX_RTU_ERROR_MSG);
				}

			} else {
				RMDWebErrorHandler.handleException(e);
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in scoreRxAndCloseCase method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return responseMessage;
	}
	
	/**
	 * @Description:  Function to get the score codes
	 **/
	@Override
	public Map<String, String> getlookupForRxScoring() throws RMDWebException {
		rmdWebLogger
				.debug("Inside CaseSolutionServiceImpl in getlookupForRxScoring Method");

		Map<String, String> scoringCodes = new LinkedHashMap<String, String>();
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME, AppConstants.MANUAL_FDBK_SCORE_RX_CODES);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					String score = applParamResponseType[i].getLookupValue();
					scoringCodes.put(score, score);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getlookupForRxScoring method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return scoringCodes;
	}

	/**
	 * @throws RMDWebException
	 *             This is the method used for get Close out Repair Codes
	 * @return List<CaseSolutionVO>
	 * @throws RMDWebException
	 */
	@Override
	public List<CaseSolutionVO> getCloseOutRepairCodes(String recomId)
			throws RMDWebException {
		List<CaseSolutionVO> repairCodeList = new ArrayList<CaseSolutionVO>();
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		try {
			pathParams.put(AppConstants.RECOM_ID, recomId);
			RepairCodeDetailsType[] repairCodeResponse = (RepairCodeDetailsType[]) webServiceInvoker
					.get(AppConstants.GET_CLOSE_OUT_REPAIRCODE, pathParams,
							null, null, RepairCodeDetailsType[].class);
			for (RepairCodeDetailsType repairCodeType : repairCodeResponse) {
				CaseSolutionVO currentRepairCode = new CaseSolutionVO();
				currentRepairCode.setTaskId(repairCodeType.getTaskId());
				currentRepairCode.setRepairCode(repairCodeType.getRepairCode());
				currentRepairCode.setRepairCodeId(repairCodeType
						.getRepairCodeId());
				currentRepairCode.setTaskDesc(repairCodeType.getTaskDesc());
				currentRepairCode.setRepaidCodeDesc(repairCodeType
						.getRepaidCodeDesc());
				repairCodeList.add(currentRepairCode);
			}
		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"Exception occured in getCloseOutRepairCodes() method ", e);
			throw e;
		}catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getCloseOutRepairCodes() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return repairCodeList;
	}

	/**
	 * @throws RMDWebException
	 *             This is the method used for get case Repair Codes
	 * @return List<CaseSolutionVO>
	 * @throws RMDWebException
	 */
	@Override
	public List<CaseSolutionVO> getCaseRepairCodes(String caseId)
			throws RMDWebException {
		List<CaseSolutionVO> repairCodeList = new ArrayList<CaseSolutionVO>();
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		try {
			pathParams.put(AppConstants.CASE_ID, caseId);
			RepairCodeDetailsType[] repairCodeResponse = (RepairCodeDetailsType[]) webServiceInvoker
					.get(AppConstants.GET_CASE_REPAIRCODE, pathParams, null,
							null, RepairCodeDetailsType[].class);
			for (RepairCodeDetailsType repairCodeType : repairCodeResponse) {
				CaseSolutionVO currentRepairCode = new CaseSolutionVO();
				currentRepairCode.setRepairCode(repairCodeType.getRepairCode());
				currentRepairCode.setRepairCodeId(repairCodeType
						.getRepairCodeId());
				currentRepairCode.setRepaidCodeDesc(repairCodeType
						.getRepaidCodeDesc());
				repairCodeList.add(currentRepairCode);
			}
		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"Exception occured in getCaseRepairCodes() method ", e);
			throw e;
		}catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getCaseRepairCodes() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return repairCodeList;
	}

	/**
	 * @throws RMDWebException
	 *             This is the method used for get case Repair Codes
	 * @return List<CaseSolutionVO>
	 * @throws RMDWebException
	 */
	@Override
	public Map<String, String> getRepairCodes(CaseSolutionVO getRepairCodeInputs)
			throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		Map<String, String> repairCode = new LinkedHashMap<String, String>();
		try {
			queryParams.put(AppConstants.MODEL, getRepairCodeInputs.getModel());
			queryParams.put(AppConstants.SEARCH_BY,
					getRepairCodeInputs.getSearchBy());
			queryParams.put(AppConstants.VALUE,
					getRepairCodeInputs.getSearchValue());
			RepairCodeDetailsType[] repairCodeResponse = (RepairCodeDetailsType[]) webServiceInvoker
					.get(AppConstants.GET_REPAIRCODE, null, queryParams, null,
							RepairCodeDetailsType[].class);
			for (RepairCodeDetailsType repairCodeType : repairCodeResponse) {
				repairCode.put(
						repairCodeType.getRepairCodeId(),
						repairCodeType.getRepairCode()
								+ AppConstants.BLANK_STRING
								+ AppConstants.PIPE_SEPERATOR
								+ AppConstants.BLANK_STRING
								+ repairCodeType.getRepaidCodeDesc());
			}
		} catch (RMDWebException e) {
			rmdWebLogger.error("Exception occured in getRepairCodes() method ",
					e);
			throw e;
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getRepairCodes() method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return repairCode;
	}

	/**
	 * @throws RMDWebException
	 *             This is the method used for get select by values
	 * @return List<String>
	 * @throws RMDWebException
	 */
	@Override
	public List<String> getlookupForSelectBy() throws RMDWebException {

		rmdWebLogger
				.debug("Inside CaseSolutionServiceImpl in getlookupForRxScoring Method");

		List<String> selectByList = new ArrayList<String>();
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.REPAIR_CODE_SELECT_BY);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					String listvalue = applParamResponseType[i].getLookupValue();
					selectByList.add(listvalue);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getlookupForRxScoring method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return selectByList;
	}

	/**
	 * @throws RMDWebException
	 *             This is the method used for add repair codes
	 * @throws RMDWebException
	 */
	@Override
	public void addRepairCodes(CaseSolutionVO caseRepairCodes)
			throws RMDWebException {
		final Map<String, String> headerParams = getHeaderMap(caseRepairCodes);
		RepairCodeDetailsType addRepaircodeDetails = new RepairCodeDetailsType();
		List<String> repairCodes = new ArrayList<String>();
		try {
			repairCodes = Arrays.asList(caseRepairCodes.getRepairCodeId()
					.split(AppConstants.COMMA));
			addRepaircodeDetails.setCaseID(caseRepairCodes.getCaseId());
			addRepaircodeDetails.getRepaircodeList().addAll(repairCodes);
			webServiceInvoker.put(ServiceConstants.ADD_REPAIR_CODE,
					addRepaircodeDetails, headerParams);
		} catch (RMDWebException e) {
			rmdWebLogger.error("Exception occured in addRepairCodes() method ",
					e);
			throw e;
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in addRepairCodes() method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
	}

	/**
	 * @throws RMDWebException
	 *             This is the method used for remove repair codes
	 * @throws RMDWebException
	 */
	@Override
	public void removeRepairCodes(CaseSolutionVO caseRepairCodes)
			throws RMDWebException {
		final Map<String, String> headerParams = new LinkedHashMap<String, String>();
		RepairCodeDetailsType removeRepaircodeDetails = new RepairCodeDetailsType();
		List<String> repairCodes = new ArrayList<String>();
		try {
			repairCodes = Arrays.asList(caseRepairCodes.getRepairCodeId()
					.split(AppConstants.COMMA));
			removeRepaircodeDetails.setCaseID(caseRepairCodes.getCaseId());
			removeRepaircodeDetails.getRepaircodeList().addAll(repairCodes);
			webServiceInvoker.put(ServiceConstants.REMOVE_REPAIR_CODE,
					removeRepaircodeDetails, headerParams);
		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"Exception occured in removeRepairCodes() method ", e);
			throw e;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in removeRepairCodes() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
	}

	/**
	 * @throws RMDWebException
	 *             This is the method used for remove repair codes
	 * @throws RMDWebException
	 */
	@Override
	public void addAndClose(CaseSolutionVO caseRepairCodes)
			throws RMDWebException {
		final Map<String, String> headerParams = getHeaderMap(caseRepairCodes);
		RepairCodeDetailsType addRepaircodeDetails = new RepairCodeDetailsType();
		List<String> repairCodes = new ArrayList<String>();
		try {
			repairCodes = Arrays.asList(caseRepairCodes.getRepairCodeId()
					.split(AppConstants.COMMA));
			addRepaircodeDetails.setCaseID(caseRepairCodes.getCaseId());
			addRepaircodeDetails.getRepaircodeList().addAll(repairCodes);
			addRepaircodeDetails.setAddAndClose(AppConstants.TRUE);
			webServiceInvoker.put(ServiceConstants.ADD_REPAIR_CODE,
					addRepaircodeDetails, headerParams);
		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"Exception occured in removeRepairCodes() method ", e);
			throw e;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in removeRepairCodes() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
	}
	/** Added by Shikha
	 * @throws RMDWebException
	 * This is the method used to check if the Deliver, Close and Append radio buttons are enabled/disabled. 
	 * @param caseId
	 * @return boolean 
	 * @throws RMDWebException
	 */

	public boolean enableAppendClose(CaseAppendVO caseAppendVO)
				throws RMDWebException {
			CaseRequestType appendRXRequestType = new CaseRequestType();
			final Map<String, String> headerParams = getHeaderMap(caseAppendVO);
			try {
				appendRXRequestType.setCaseID(caseAppendVO.getCaseId());
				appendRXRequestType.setUserName(caseAppendVO.getUserId());
				webServiceInvoker.put(ServiceConstants.ENABLE_APPEND,
						appendRXRequestType, headerParams);
			} catch (RMDWebException e) {
				rmdWebLogger.error("Exception occured in enableAppend() method ", e);
				throw e;
			}catch (Exception ex) {
				rmdWebLogger.error(
						"Exception occured in enableAppend() method ", ex);
				RMDWebErrorHandler.handleException(ex);

			}			
        return true;	
   }
	/**Added by Shikha
	 * @throws RMDWebException
	 *             This is the method used to append an Rx to another case
	 * @return List<String>
	 * @throws RMDWebException
	 */

	@Override
	public void appendRXToCase(CaseAppendVO caseAppendRx)
			throws RMDWebException {
		CaseRequestType appendRXRequestType = new CaseRequestType();
		final Map<String, String> headerParams = getHeaderMap(caseAppendRx);
		try {
			appendRXRequestType.setCaseID(caseAppendRx.getCaseId());
			appendRXRequestType.setSolutionTitle(caseAppendRx.getSolutionTitle());
			appendRXRequestType.setUserName(caseAppendRx.getUserId());
		
			webServiceInvoker.put(ServiceConstants.APPEND_RX_TO_CASE,
					appendRXRequestType, headerParams);
		} catch (RMDWebException e) {
			rmdWebLogger.error("Exception occured in appendRXToCase() method ", e);
			throw e;
		}catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in appendRXToCase() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		
	}
	/**
	 * @throws RMDWebException
	 * This is the method used to get count of Open FL work order and 
	 * will be called while closing the Case will return the open work order count from the eservices
	 * @return  List<String>
	 * @throws RMDWebException
	 */
	public int getOpenFLCount(String lmsLocoId) throws RMDWebException{
		int openFLCount = 0;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		String strOpenFLCount = "";
		try {
			queryParams.put(AppConstants.Lms_Id, lmsLocoId);
			strOpenFLCount = (String) webServiceInvoker.get(
					ServiceConstants.GET_OPEN_FL_COUNT, null, queryParams,
					null, String.class);
			openFLCount = Integer.parseInt(strOpenFLCount);
		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"Exception occured in getOpenFLCount() method ", e);
			throw e;
		}catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getOpenFLCount() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return openFLCount;
	}
	
	
	/**
	 * @throws RMDWebException
	 * This is the method used to get LMS locoId
	 * @return  List<String>
	 * @throws RMDWebException
	 */
	public String getLmsLocoID(String caseId) throws RMDWebException{
		String lmsLocoId = AppConstants.EMPTY_STRING;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		try {
			queryParams.put(AppConstants.CASE_ID, caseId);
			lmsLocoId = (String) webServiceInvoker.get(
					ServiceConstants.GET_LMS_LOCO_ID, null, queryParams,
					null, String.class);
		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"Exception occured in getLmsLocoID() method ", e);
			throw e;
		}catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLmsLocoID() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lmsLocoId;
	}
	/**
	 * @throws RMDWebException
	 * This is the method used to get LMS locoId
	 * @return  List<String>
	 * @throws RMDWebException
	 */
	public String getCaseTitle(String caseId) throws RMDWebException{
		String caseTitle = AppConstants.EMPTY_STRING;
		
		CaseBean caseBean=new CaseBean();
		caseBean.setCaseId(caseId);
		final Map<String, String> pathParams = new HashMap<String, String>();
		final Map<String, String> queryParamsMap = new HashMap<String, String>();
		final Map<String, String> headerParams = getHeaderMap(caseBean);
		
	    
		
		try {
			
			rmdWebLogger.info("getting case titile");
					
			pathParams.put(AppConstants.CASE_Id, caseId);

			caseTitle = (String) 
								webServiceInvoker.get(
										ServiceConstants.GET_CASE_TITLE,
										pathParams,
										queryParamsMap,headerParams,
										String.class				
										); 
		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"Exception occured in getCaseTitle() method ", e);
			throw e;
		}catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getCaseTitle() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return caseTitle;
	}
	
	@Override
	/**
	 * @throws RMDWebException
	 * This is the method to display tooloutput
	 * @return  List<String>
	 * @throws RMDWebException
	 */
	public List<ToolOutputResponseType> getToolOutputDetails(String caseId,String userTimeZone)
			throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		List<ToolOutputResponseType> tooloutputResTypeList = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(caseId)) {
				queryParams.put(AppConstants.CASE_ID, caseId);				
				queryParams.put(AppConstants.ATTR_TIME_ZONE, userTimeZone);
				
				ToolOutputResponseType[] arrToolOutputResp = (ToolOutputResponseType[]) webServiceInvoker
						.get(ServiceConstants.GET_TOOL_OUTPUT, null,
								queryParams, null, ToolOutputResponseType[].class);
				if (arrToolOutputResp != null)
					tooloutputResTypeList = new ArrayList<ToolOutputResponseType>();
					for (ToolOutputResponseType tooloutputResType : arrToolOutputResp) {						
						tooloutputResTypeList.add(tooloutputResType);
					}

			}

		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"Exception occured in getToolOutputDetails() method ", e);
			throw e;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getToolOutputDetails() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return tooloutputResTypeList;
}
	/**
	 * @throws RMDWebException
	 * This is the method used to create case and move tooloutput
	 * @return  List<String>
	 * @throws RMDWebException
	 */
	public String moveToolOutput(CaseBean caseBean) throws RMDWebException{
		
		
		final Map<String, String> pathParams = new HashMap<String, String>();
		final Map<String, String> queryParamsMap = new HashMap<String, String>(); 
		final Map<String, String> headerParams = getHeaderMap(caseBean);
	    String response=null;
		String ruleDef=null;
		try {
			 if(caseBean.getRuleDefId()==null || caseBean.getRuleDefId().equals(AppConstants.EMPTY_STRING))
					ruleDef ="0"; 
			 else
				 ruleDef=caseBean.getRuleDefId();
			 
			 
			    pathParams.put(AppConstants.CASE_ID, caseBean.getCaseId()); 
			    pathParams.put(AppConstants.TO_CASE_ID, caseBean.getAppendToCaseId()); 
				pathParams.put(AppConstants.RX_ID, caseBean.getRxId());
				pathParams.put(AppConstants.USER_ID, caseBean.getUserId());
				pathParams.put(AppConstants.ASSET_GROUP_NAME, caseBean.getAssetGrpName());
				pathParams.put(AppConstants.ASSET_NUMBER, caseBean.getAssetNumber());
				pathParams.put(AppConstants.CUSTOMER_ID, caseBean.getCustomerId());
				pathParams.put(AppConstants.RULE_DEFINITION_ID, ruleDef);
				pathParams.put(AppConstants.TOOL_ID, caseBean.getToolId());
				pathParams.put(AppConstants.SKIP_COUNT_CLOSE, String.valueOf(caseBean.getSkipCount()));
				pathParams.put(AppConstants.RX_DELV, caseBean.getRxDelivery());
				pathParams.put(AppConstants.TOOL_OBJID, caseBean.getToolObjId());
				//pathParams.put(AppConstants.RX_DELV, caseBean.getRxDelivery());
				
				response = (String) 
							webServiceInvoker.get(
									ServiceConstants.MOVE_TOOL_OUTPUT,
									pathParams,
									queryParamsMap,headerParams,
									String.class				
									); 
		} catch (RMDWebException e) {
			
			rmdWebLogger.error(
					"Exception occured in moveToolOutput() method ", e);
			return AppConstants.FAILURE;
		}catch (Exception ex) {
			//rmdWebLogger.error(
					//"Exception occured in moveToolOutput() method ", ex);
			
			RMDWebErrorHandler.handleException(ex);
			return AppConstants.FAILURE;
		}
		return response;
	}
	/**
	 * @throws RMDWebException
	 *             This is the method used for get case Repair Codes
	 * @return Map
	 * @throws RMDWebException
	 */
	public String getTORepairCodes(String repairCode)
			throws RMDWebException {
		String repairCodeDesc = null;
		try {
			RepairCodeDetailsType[] repairCodeResponse = (RepairCodeDetailsType[]) webServiceInvoker
					.post(ServiceConstants.GET_TO_REPAIRCODE,repairCode,
							RepairCodeDetailsType[].class);			
			if(repairCodeResponse!=null){
				repairCodeDesc = repairCodeResponse[0].getRepaidCodeDesc();
			}
			
		} catch (RMDWebException e) {
			rmdWebLogger.error("Exception occured in getRepairCodes() method ",
					e);
			throw e;
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getRepairCodes() method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return repairCodeDesc;
	}
	
	/**
	 * @Author :
	 * @return :List<String>
	 * @param :caseBean
	 * @throws :RMDWebException
	 * @Description:This method is used for a fetching Rxs delivered against a Unit.
	 */
	@Override
	public Map<String, List<String>> getEnabledUnitRxsDeliver(String customerId,
			String assetGroupName, String assetNumber, String caseId,String caseType,String currentUser) throws RMDWebException{

		final Map<String, String> queryParams = new HashMap<String, String>();	    
	    RxVehicleBomResponseType objRxVehicleBomResponseType=null;
	    Map<String,List<String>> resultMap=null;
		
	    try {
			queryParams.put(AppConstants.CASE_Id, caseId);
			queryParams.put(AppConstants.ASSET_GROUP_NAME, assetGroupName);
			queryParams.put(AppConstants.ASSET_NUMBER, assetNumber);
			queryParams.put(AppConstants.CUSTOMER_ID, customerId);
			queryParams.put(AppConstants.CASETYPE, caseType);
			queryParams.put(AppConstants.USER_ID, currentUser);
					
			objRxVehicleBomResponseType = (RxVehicleBomResponseType) 
					webServiceInvoker.get(
							ServiceConstants.GET_ENABLED_UNIT_RXS_DELIVER,
							null,
							queryParams,null,
							RxVehicleBomResponseType.class				
							);

			if(null!=objRxVehicleBomResponseType){
			    resultMap = new LinkedHashMap<String, List<String>>();
			    resultMap.put(RMDCommonConstants.DISABLED_RX_LIST, objRxVehicleBomResponseType.getDisabledRxList());
			    resultMap.put(RMDCommonConstants.BOM_MISMATCH_RX_LIST, objRxVehicleBomResponseType.getBomMismatchRxList());
			}									
		} catch (RMDWebException e) {
			rmdWebLogger.error("Exception occured in getEnabledUnitRxsDeliver() method ",
					e);
			throw e;
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getEnabledUnitRxsDeliver() method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return resultMap;
	}
	
	
	/**
	 * This is the method used for fetching the Diagnostic Weight values through
	 * jquery call
	 * 
	 * @param
	 * @return List<String>
	 * @throws
	 */
	public String getRepairCodeMiss4F() throws RMDWebException {
		rmdWebLogger
				.debug("Inside CreateCasesServiceImpl in getRepairCodeMiss4F Method");
		String repairCodeMiss4F = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.MISS_4F_REPAIR_CODE);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					repairCodeMiss4F = applParamResponseType[i]
							.getLookupValue();
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getRepairCodeMiss4F method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return repairCodeMiss4F;
	}
	/**
	 * This is the method used for fetching the Diagnostic Weight values through
	 * jquery call
	 * 
	 * @param
	 * @return List<String>
	 * @throws
	 */
	public String getRepairCodeMiss4B() throws RMDWebException {
		rmdWebLogger
				.debug("Inside CreateCasesServiceImpl in getRepairCodeMiss4B Method");
		String repairCodeMissBF = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.MISS_4B_REPAIR_CODE);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					repairCodeMissBF = applParamResponseType[i]
							.getLookupValue();
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getRepairCodeMiss4B method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return repairCodeMissBF;
	}
	
	/**
	 * @throws RMDWebException
	 *             This is the method used for get case Repair Codes
	 * @return Map
	 * @throws RMDWebException
	 */
	public String getRepairCodesID(String repairCode)
			throws RMDWebException {
		String repairCodeId = null;
		try {
			RepairCodeDetailsType[] repairCodeResponse = (RepairCodeDetailsType[]) webServiceInvoker
					.post(ServiceConstants.GET_TO_REPAIRCODE,repairCode,
							RepairCodeDetailsType[].class);			
			if(repairCodeResponse!=null){
				repairCodeId = repairCodeResponse[0].getRepairCodeId();
			}
		} catch (RMDWebException e) {
			rmdWebLogger.error("Exception occured in getRepairCodesID() method ",
					e);
			throw e;
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getRepairCodesID() method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return repairCodeId;
	}

	/**
	 * @Author :
	 * @return :List<RepairCodeVO>
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method is used to get false alarm details in data
	 *               screen
	 * 
	 */
	@Override
	public List<RepairCodeVO> getFalseAlarmDetails(String rxObjId)
			throws RMDWebException {
		List<RepairCodeVO> falseAlarmList = new ArrayList<RepairCodeVO>();
		Map<String, String> pathParams = null;
		RepairCodeDetailsType[] objRepairCodeDetailsType = null;
		try {
			if (null != rxObjId
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(rxObjId)) {
				pathParams = new LinkedHashMap<String, String>();
				pathParams.put(AppConstants.RX_OBJ_ID, rxObjId);
				objRepairCodeDetailsType = (RepairCodeDetailsType[]) webServiceInvoker
						.get(ServiceConstants.FALSE_ALARM_DETAILS, pathParams,
								null, null, RepairCodeDetailsType[].class);
				if (null != objRepairCodeDetailsType
						&& objRepairCodeDetailsType.length > 0) {
					for (RepairCodeDetailsType falseAlarmDetails : objRepairCodeDetailsType) {
						RepairCodeVO objRepairCodeVO = new RepairCodeVO();
						objRepairCodeVO.setRepairCode(falseAlarmDetails
								.getRepairCode());
						objRepairCodeVO.setRepairDesc(falseAlarmDetails
								.getRepaidCodeDesc());
						objRepairCodeVO.setNoOfCases(falseAlarmDetails
								.getNoOfCases());
						falseAlarmList.add(objRepairCodeVO);
					}
				}
			}

		} catch (Exception e) {
			RMDWebErrorHandler.handleException(e);
		}
		return falseAlarmList;
	}

	/**
	 * @Author :
	 * @return :List<RxDetailsVO>
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method is used to get false alarm details in data
	 *               screen
	 * 
	 */
	@Override
	public List<RxDetailsVO> getRXFalseAlarmDetails(String rxObjId)
			throws RMDWebException {
		List<RxDetailsVO> falseAlarmList = new ArrayList<RxDetailsVO>();
		Map<String, String> pathParams = null;
		RxDetailsType[] objRxDetailsType = null;
		try {
			if (null != rxObjId
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(rxObjId)) {
				pathParams = new LinkedHashMap<String, String>();
				pathParams.put(AppConstants.RX_OBJ_ID, rxObjId);
				objRxDetailsType = (RxDetailsType[]) webServiceInvoker.get(
						ServiceConstants.RX_FALSE_ALARM_DETAILS, pathParams,
						null, null, RxDetailsType[].class);
				if (null != objRxDetailsType && objRxDetailsType.length > 0) {
					for (RxDetailsType obj : objRxDetailsType) {
						RxDetailsVO objRxDetailsVO = new RxDetailsVO();
						objRxDetailsVO.setRxTitle(obj.getRxTitle());
						objRxDetailsVO.setNoOfCases(obj.getNoOfCases());
						falseAlarmList.add(objRxDetailsVO);
					}
				}
			}
		} catch (Exception e) {
			RMDWebErrorHandler.handleException(e);
		}
		return falseAlarmList;
	}

	/**
	 * @Author :
	 * @return :List<RepairCodeVO>
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method is used to get mdsc accurate details in data
	 *               screen
	 * 
	 */
	@Override
	public List<RepairCodeVO> getMDSCAccurateDetails(String rxObjId)
			throws RMDWebException {
		List<RepairCodeVO> mdscAccurateList = new ArrayList<RepairCodeVO>();
		Map<String, String> pathParams = null;
		RepairCodeDetailsType[] objRepairCodeDetailsType = null;
		try {
			if (null != rxObjId
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(rxObjId)) {
				pathParams = new LinkedHashMap<String, String>();
				pathParams.put(AppConstants.RX_OBJ_ID, rxObjId);
				objRepairCodeDetailsType = (RepairCodeDetailsType[]) webServiceInvoker
						.get(ServiceConstants.MDSC_ACCURATE_DETAILS,
								pathParams, null, null,
								RepairCodeDetailsType[].class);
				if (null != objRepairCodeDetailsType
						&& objRepairCodeDetailsType.length > 0) {
					for (RepairCodeDetailsType falseAlarmDetails : objRepairCodeDetailsType) {
						RepairCodeVO objRepairCodeVO = new RepairCodeVO();
						objRepairCodeVO.setRepairCode(falseAlarmDetails
								.getRepairCode());
						objRepairCodeVO.setRepairDesc(falseAlarmDetails
								.getRepaidCodeDesc());
						objRepairCodeVO.setNoOfCases(falseAlarmDetails
								.getNoOfCases());
						mdscAccurateList.add(objRepairCodeVO);
					}
				}
			}

		} catch (Exception e) {
			RMDWebErrorHandler.handleException(e);
		}
		return mdscAccurateList;
	}

	/**
	 * @Author :
	 * @return :List<CaseBean>
	 * @param : String,String
	 * @throws :RMDWebException
	 * @Description: This method is used to get mdsc accurate-case details in
	 *               data screen
	 * 
	 */
	@Override
	public List<CaseBean> getCaseDetails(String rxObjId, String repObjId)
			throws RMDWebException {
		List<CaseBean> caseDetailsList = new ArrayList<CaseBean>();
		Map<String, String> queryParams = null;
		CaseRequestType[] objCaseRequestType = null;
		try {
			if (null != rxObjId
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(rxObjId)
					&& null != repObjId
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(repObjId)) {
				queryParams = new LinkedHashMap<String, String>();
				queryParams.put(AppConstants.RX_OBJ_ID, rxObjId);
				queryParams.put(AppConstants.REP_OBJ_ID, repObjId);
				objCaseRequestType = (CaseRequestType[]) webServiceInvoker.get(
						ServiceConstants.MDSC_ACCURATE_GET_CASE_DETAILS, null,
						queryParams, null, CaseRequestType[].class);
				if (null != objCaseRequestType && objCaseRequestType.length > 0) {
					for (CaseRequestType obj : objCaseRequestType) {
						CaseBean objCaseBean = new CaseBean();
						objCaseBean.setCaseId(obj.getCaseID());
						objCaseBean.setCaseTitle(obj.getCaseTitle());
						caseDetailsList.add(objCaseBean);
					}
				}
			}
		} catch (Exception e) {
			RMDWebErrorHandler.handleException(e);
		}
		return caseDetailsList;
	}

	/**
	 * @Author :
	 * @return :List<RxDetailsVO>
	 * @param : String
	 * @throws :RMDWebException
	 * @Description: This method is used to get mdsc accurate-rx details in data
	 *               screen
	 * 
	 */
	@Override
	public List<RxDetailsVO> getMDSCRxDetails(String repObjId)
			throws RMDWebException {
		List<RxDetailsVO> rxDetailsList = new ArrayList<RxDetailsVO>();
		Map<String, String> pathParams = null;
		RxDetailsType[] objRxDetailsType = null;
		try {
			if (null != repObjId
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(repObjId)) {
				pathParams = new LinkedHashMap<String, String>();
				pathParams.put(AppConstants.REP_OBJ_ID, repObjId);
				objRxDetailsType = (RxDetailsType[]) webServiceInvoker.get(
						ServiceConstants.MDSC_ACCURATE_GET_RX_DETAILS,
						pathParams, null, null, RxDetailsType[].class);
				if (null != objRxDetailsType && objRxDetailsType.length > 0) {
					for (RxDetailsType obj : objRxDetailsType) {
						RxDetailsVO objRxDetailsVO = new RxDetailsVO();
						objRxDetailsVO.setRxTitle(obj.getRxTitle());
						objRxDetailsVO.setMdscPerformance(obj
								.getMdscPerformance());
						rxDetailsList.add(objRxDetailsVO);
					}
				}
			}
		} catch (Exception e) {
			RMDWebErrorHandler.handleException(e);
		}
		return rxDetailsList;
	}
	

	/**
	 * @Author :Mohamed
	 * @return :
	 * @param : ReCloseVO
	 * @throws :RMDWebException
	 * @Description: This method is used to reset the fired faults
	 * 
	 */
	@Override
	public void ReCloseCase(final ReCloseVO objReCloseVO)
			throws RMDWebException {
		Map<String, String> responseMessage = new HashMap<String, String>();
		//final Map<String, String> headerParams = getHeaderMap(objReCloseVO);
		ReCloseRequestType requestType = new ReCloseRequestType();
		final Map<String, String> headerParams = null;
		try {
			requestType.setUserId(objReCloseVO.getUserId());
			requestType.setCaseId(objReCloseVO.getCaseId());
			webServiceInvoker.put(ServiceConstants.RECLOSE_RESET_FAULTS,
					requestType, headerParams);
		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_RMD_205.equalsIgnoreCase(e
					.getErrorCode())) {
				responseMessage.put(AppConstants.EXCEPTION_RMD_205,
						AppConstants.EXCEPTION_RMD_205);
			} else if (AppConstants.EXCEPTION_RMD_206.equalsIgnoreCase(e
					.getErrorCode())) {
				responseMessage.put(AppConstants.EXCEPTION_RMD_206,
						AppConstants.EXCEPTION_RMD_206);
			} else if (AppConstants.EXCEPTION_RMD_215.equalsIgnoreCase(e
					.getErrorCode())) {
				if (null != e.getMessage() && !e.getMessage().isEmpty()) {
					responseMessage.put(AppConstants.EXCEPTION_RMD_215,
							e.getMessage());
				} 

			} else {
				RMDWebErrorHandler.handleException(e);
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in ReCloseCase method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		
	}

	/**
	 * @Author :Mohamed
	 * @return :CaseResponseVO
	 * @param : caseBean
	 * @throws :RMDWebException
	 * @Description: This method is used to check whether the rx is closed or not
	 */
	@Override
	public CaseResponseVO getRxDetailsForReClose(CaseBean caseBean, String timeZone)
			throws Exception {
		Map<String, String> queryParams = null;
		CaseInfoType[] caseInfoResponseType = null;
		CaseResponseVO caseResponseVO = null;
		if (null != caseBean.getCaseId()
				&& !RMDCommonConstants.EMPTY_STRING
						.equalsIgnoreCase(caseBean.getCaseId())) {
			queryParams = new LinkedHashMap<String, String>();
			queryParams.put(AppConstants.CASE_Id, caseBean.getCaseId());
			caseInfoResponseType = (CaseInfoType[]) webServiceInvoker
					.get(ServiceConstants.GET_RX_DETAILS_FOR_RECLOSE, null, queryParams,
							null, CaseInfoType[].class);
			if (null != caseInfoResponseType
					&& caseInfoResponseType.length > 0) {
				caseResponseVO = new CaseResponseVO();
				caseResponseVO.setSolutionStatus(caseInfoResponseType[0].getCaseSolutionStatus());
			}
		}
		return caseResponseVO;
	}

	/**
	 * @param  
	 * @Author :Mohamed
	 * @return :
	 * @param : ReCloseVO
	 * @throws :RMDWebException
	 * @Description: This method is used to update the case close result
	 */	
	
	@Override
	public void updateCloseCaseResult(final ReCloseVO objReClose) throws Exception {
		final Map<String, String> headerParams = null;
		ReCloseRequestType objRequestType = new ReCloseRequestType();
		Map<String, String> responseMessage = new HashMap<String, String>();
		try {
			objRequestType.setUserId(objReClose.getUserId());		     
			objRequestType.setCaseId(objReClose.getCaseId());
			objRequestType.setReCloseAction(objReClose.getReCloseAction());
			objRequestType.setAppendCaseId(objReClose.getAppendCaseId());
			webServiceInvoker.put(ServiceConstants.CLOSE_CASE_RESULT,
					objRequestType, headerParams);
		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_RMD_205.equalsIgnoreCase(e
					.getErrorCode())) {
				responseMessage.put(AppConstants.EXCEPTION_RMD_205,
						AppConstants.EXCEPTION_RMD_205);
			} else if (AppConstants.EXCEPTION_RMD_206.equalsIgnoreCase(e
					.getErrorCode())) {
				responseMessage.put(AppConstants.EXCEPTION_RMD_206,
						AppConstants.EXCEPTION_RMD_206);
			} else if (AppConstants.EXCEPTION_RMD_215.equalsIgnoreCase(e
					.getErrorCode())) {
				if (null != e.getMessage() && !e.getMessage().isEmpty()) {
					responseMessage.put(AppConstants.EXCEPTION_RMD_215,
							e.getMessage());
				}
			} else {
				RMDWebErrorHandler.handleException(e);
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in updateCloseCaseResult method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		
	}


}
