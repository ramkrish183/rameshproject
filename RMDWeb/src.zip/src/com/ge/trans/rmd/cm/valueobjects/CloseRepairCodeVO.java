package com.ge.trans.rmd.cm.valueobjects;

public class CloseRepairCodeVO {
	String repairCodeId;
	String repairCode;
	String repairCodeDescription;
	public String getRepairCodeId() {
		return repairCodeId;
	}
	public void setRepairCodeId(String repairCodeId) {
		this.repairCodeId = repairCodeId;
	}
	public String getRepairCode() {
		return repairCode;
	}
	public void setRepairCode(String repairCode) {
		this.repairCode = repairCode;
	}
	public String getRepairCodeDescription() {
		return repairCodeDescription;
	}
	public void setRepairCodeDescription(String repairCodeDescription) {
		this.repairCodeDescription = repairCodeDescription;
	}
}
