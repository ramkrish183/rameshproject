package com.ge.trans.rmd.cm.valueobjects;

public class EDPParamDetailsVO {

	private String paramObjId;
	  private String paramNo;
	  private String ctrlName;
	  private String paramDesc;
	  private String uom;
	  private String usageRate;
	  private String destType;

	  public String getParamObjId()
	  {
	    return this.paramObjId;
	  }
	  public void setParamObjId(String paramObjId) {
	    this.paramObjId = paramObjId;
	  }
	  public String getParamNo() {
	    return this.paramNo;
	  }
	  public void setParamNo(String paramNo) {
	    this.paramNo = paramNo;
	  }
	  public String getCtrlName() {
	    return this.ctrlName;
	  }
	  public void setCtrlName(String ctrlName) {
	    this.ctrlName = ctrlName;
	  }
	  public String getParamDesc() {
	    return this.paramDesc;
	  }
	  public void setParamDesc(String paramDesc) {
	    this.paramDesc = paramDesc;
	  }
	  public String getUom() {
	    return this.uom;
	  }
	  public void setUom(String uom) {
	    this.uom = uom;
	  }
	  public String getUsageRate() {
	    return this.usageRate;
	  }
	  public void setUsageRate(String usageRate) {
	    this.usageRate = usageRate;
	  }
	  public String getDestType() {
	    return this.destType;
	  }
	  public void setDestType(String destType) {
	    this.destType = destType;
	  }
}
