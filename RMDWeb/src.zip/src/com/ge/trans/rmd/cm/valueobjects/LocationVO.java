package com.ge.trans.rmd.cm.valueobjects;

import com.ge.trans.rmd.common.vo.RMDBaseVO;

public class LocationVO extends RMDBaseVO {
	private String assetNumber;
	private String customerName;
	private String strGrpName;
	private String caseID;
	private String strLocationId;
	private String strLocationName;
	private String strLocationType;
	private String strCity;
	public String getStrCity() {
		return strCity;
	}
	public void setStrCity(String strCity) {
		this.strCity = strCity;
	}
	public String getStrState() {
		return strState;
	}
	public void setStrState(String strState) {
		this.strState = strState;
	}
	private String strState;
	/**
	 * @return the assetNumber
	 */
	public String getAssetNumber() {
		return assetNumber;
	}
	/**
	 * @param assetNumber the assetNumber to set
	 */
	public void setAssetNumber(String assetNumber) {
		this.assetNumber = assetNumber;
	}
	/**
	 * @return the customerName
	 */
	public String getCustomerName() {
		return customerName;
	}
	/**
	 * @param customerName the customerName to set
	 */
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	/**
	 * @return the strGrpName
	 */
	public String getStrGrpName() {
		return strGrpName;
	}
	/**
	 * @param strGrpName the strGrpName to set
	 */
	public void setStrGrpName(String strGrpName) {
		this.strGrpName = strGrpName;
	}
	/**
	 * @return the caseID
	 */
	public String getCaseID() {
		return caseID;
	}
	/**
	 * @param caseID the caseID to set
	 */
	public void setCaseID(String caseID) {
		this.caseID = caseID;
	}
	/**
	 * @return the strLocationId
	 */
	public String getStrLocationId() {
		return strLocationId;
	}
	/**
	 * @param strLocationId the strLocationId to set
	 */
	public void setStrLocationId(String strLocationId) {
		this.strLocationId = strLocationId;
	}
	/**
	 * @return the strLocation
	 */
	public String getStrLocationName() {
		return strLocationName;
	}
	/**
	 * @param strLocation the strLocation to set
	 */
	public void setStrLocationName(String strLocationName) {
		this.strLocationName = strLocationName;
	}
	/**
	 * @return the strLocationType
	 */
	public String getStrLocationType() {
		return strLocationType;
	}
	/**
	 * @param strLocationType the strLocationType to set
	 */
	public void setStrLocationType(String strLocationType) {
		this.strLocationType = strLocationType;
	}

}
