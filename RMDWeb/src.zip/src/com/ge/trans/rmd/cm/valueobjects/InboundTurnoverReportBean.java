package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

import com.ge.trans.rmd.common.valueobjects.BaseVO;
import com.ge.trans.rmd.common.vo.GenNotesVO;
import com.ge.trans.rmd.km.valueobjects.RxVO;

public class InboundTurnoverReportBean extends BaseVO {
	
	private static final long serialVersionUID = 1L;
	
	public List<InboundTurnoverBean> inboundTurnoverBean;
	public String inboundError = null;
	public List<ShipUnitDataVO> shipUnitDataVO;
	public List<InfancyUnitBean> infancyUnitBean;
	public String shipUnitError = null;
	public String infancyUnitError = null;
	public List<CaseTrendDataVO> openCommRXBean;
	public List<GenNotesVO> arlCommNotes;
	public String openCommRXError = null;
	public List<RxVO> repeatedRXBean;
	public String repeatedRXError = null;
	public CaseConversionBean caseConversionBean;
	public TopNoActionBean topNoActionBean;
	public String caseConversionError;
	public String caseConvPer=null;
	public CaseTrendStatisticsBean caseTrendStatistics;
	public List<OpenRXBean> openRXBean;
	public List<CaseTrendBean> caseTrendBean;
	public List<GenNotesVO> arlGenNotes;
	public String caseTrendError;
	public String commNotesError;
	public String generalNotesError;
	public String openRXError;
	public String caseTrendStatError;
	public String casePercentageError;
	public String topNoActionRXError;
	public CaseTrendBean caseTrend;
	//Added mu Murali C for call reports
	private CallLogReportBean callCountByLoc;
	private String callCountByLocErr;
	private CallLogReportBean custBrkDwnByMins;
	private String custBrkDwnByMinsError;
	private CallLogReportBean callCntByBusnsArea;
	private String callCntByBusnsAreaError;
	private CallLogReportBean weeklyCallCntByBusnsArea;
	private String weeklyCallCntByBusnsAreaError;
	private CallLogReportBean vehCallCntByBusnsArea;
	private String vehCallCntByBusnsAreaError;
	public String  manualCallCount;
	
	public List<InboundTurnoverBean> getInboundTurnoverBean() {
		return inboundTurnoverBean;
	}
	public void setInboundTurnoverBean(List<InboundTurnoverBean> inboundTurnoverBean) {
		this.inboundTurnoverBean = inboundTurnoverBean;
	}
	public String getInboundError() {
		return inboundError;
	}
	public void setInboundError(String inboundError) {
		this.inboundError = inboundError;
	}
	public List<ShipUnitDataVO> getShipUnitDataVO() {
		return shipUnitDataVO;
	}
	public void setShipUnitDataVO(List<ShipUnitDataVO> shipUnitDataVO) {
		this.shipUnitDataVO = shipUnitDataVO;
	}
	public String getShipUnitError() {
		return shipUnitError;
	}
	public void setShipUnitError(String shipUnitError) {
		this.shipUnitError = shipUnitError;
	}
	public String getInfancyUnitError() {
		return infancyUnitError;
	}
	public void setInfancyUnitError(String infancyUnitError) {
		this.infancyUnitError = infancyUnitError;
	}
	public List<CaseTrendDataVO> getOpenCommRXBean() {
		return openCommRXBean;
	}
	public void setOpenCommRXBean(List<CaseTrendDataVO> openCommRXBean) {
		this.openCommRXBean = openCommRXBean;
	}
	public List<GenNotesVO> getArlCommNotes() {
        return arlCommNotes;
    }
    public void setArlCommNotes(List<GenNotesVO> arlCommNotes) {
        this.arlCommNotes = arlCommNotes;
    }
    public String getOpenCommRXError() {
		return openCommRXError;
	}
	public void setOpenCommRXError(String openCommRXError) {
		this.openCommRXError = openCommRXError;
	}
	public String getCasePercentageError() {
		return casePercentageError;
	}
	public void setCasePercentageError(String casePercentageError) {
		this.casePercentageError = casePercentageError;
	}
	public List<RxVO> getRepeatedRXBean() {
		return repeatedRXBean;
	}
	public void setRepeatedRXBean(List<RxVO> repeatedRXBean) {
		this.repeatedRXBean = repeatedRXBean;
	}
	public String getRepeatedRXError() {
		return repeatedRXError;
	}
	public List<InfancyUnitBean> getInfancyUnitBean() {
		return infancyUnitBean;
	}
	public void setInfancyUnitBean(List<InfancyUnitBean> infancyUnitBean) {
		this.infancyUnitBean = infancyUnitBean;
	}
	public String getCommNotesError() {
		return commNotesError;
	}
	public void setCommNotesError(String commNotesError) {
		this.commNotesError = commNotesError;
	}
	public String getGeneralNotesError() {
		return generalNotesError;
	}
	public CaseTrendBean getCaseTrend() {
		return caseTrend;
	}
	public void setCaseTrend(CaseTrendBean caseTrend) {
		this.caseTrend = caseTrend;
	}
	public void setGeneralNotesError(String generalNotesError) {
		this.generalNotesError = generalNotesError;
	}
	public String getOpenRXError() {
		return openRXError;
	}
	public void setOpenRXError(String openRXError) {
		this.openRXError = openRXError;
	}
	public String getTopNoActionRXError() {
		return topNoActionRXError;
	}
	public void setTopNoActionRXError(String topNoActionRXError) {
		this.topNoActionRXError = topNoActionRXError;
	}
	public String getCaseTrendStatError() {
		return caseTrendStatError;
	}
	public void setCaseTrendStatError(String caseTrendStatError) {
		this.caseTrendStatError = caseTrendStatError;
	}
	public void setRepeatedRXError(String repeatedRXError) {
		this.repeatedRXError = repeatedRXError;
	}
	public CaseConversionBean getCaseConversionBean() {
		return caseConversionBean;
	}
	public void setCaseConversionBean(CaseConversionBean caseConversionBean) {
		this.caseConversionBean = caseConversionBean;
	}
	public String getCaseConvPer() {
		return caseConvPer;
	}
	public void setCaseConvPer(String caseConvPer) {
		this.caseConvPer = caseConvPer;
	}
	public CaseTrendStatisticsBean getCaseTrendStatistics() {
		return caseTrendStatistics;
	}
	public void setCaseTrendStatistics(CaseTrendStatisticsBean caseTrendStatistics) {
		this.caseTrendStatistics = caseTrendStatistics;
	}
	public String getCaseConversionError() {
		return caseConversionError;
	}
	public String getCaseTrendError() {
		return caseTrendError;
	}
	public void setCaseTrendError(String caseTrendError) {
		this.caseTrendError = caseTrendError;
	}
	public List<CaseTrendBean> getCaseTrendBean() {
		return caseTrendBean;
	}
	public void setCaseTrendBean(List<CaseTrendBean> caseTrendBean) {
		this.caseTrendBean = caseTrendBean;
	}
	public List<OpenRXBean> getOpenRXBean() {
		return openRXBean;
	}
	public void setOpenRXBean(List<OpenRXBean> openRXBean) {
		this.openRXBean = openRXBean;
	}
	public TopNoActionBean getTopNoActionBean() {
		return topNoActionBean;
	}
	public void setTopNoActionBean(TopNoActionBean topNoActionBean) {
		this.topNoActionBean = topNoActionBean;
	}
	public void setCaseConversionError(String caseConversionError) {
		this.caseConversionError = caseConversionError;
	}
    public List<GenNotesVO> getArlGenNotes() {
        return arlGenNotes;
    }
    public void setArlGenNotes(List<GenNotesVO> arlGenNotes) {
        this.arlGenNotes = arlGenNotes;
    }
    
    
    public CallLogReportBean getCustBrkDwnByMins() {
        return custBrkDwnByMins;
    }
    public void setCustBrkDwnByMins(CallLogReportBean custBrkDwnByMins) {
        this.custBrkDwnByMins = custBrkDwnByMins;
    }
    public String getCustBrkDwnByMinsError() {
        return custBrkDwnByMinsError;
    }
    public void setCustBrkDwnByMinsError(String custBrkDwnByMinsError) {
        this.custBrkDwnByMinsError = custBrkDwnByMinsError;
    }
    public String getCallCountByLocErr() {
        return callCountByLocErr;
    }
    public void setCallCountByLocErr(String callCountByLocErr) {
        this.callCountByLocErr = callCountByLocErr;
    }
    public CallLogReportBean getCallCountByLoc() {
        return callCountByLoc;
    }
    public void setCallCountByLoc(CallLogReportBean callCountByLoc) {
        this.callCountByLoc = callCountByLoc;
    }
    public CallLogReportBean getCallCntByBusnsArea() {
        return callCntByBusnsArea;
    }
    public void setCallCntByBusnsArea(CallLogReportBean callCntByBusnsArea) {
        this.callCntByBusnsArea = callCntByBusnsArea;
    }
    public String getCallCntByBusnsAreaError() {
        return callCntByBusnsAreaError;
    }
    public void setCallCntByBusnsAreaError(String callCntByBusnsAreaError) {
        this.callCntByBusnsAreaError = callCntByBusnsAreaError;
    }
    public CallLogReportBean getWeeklyCallCntByBusnsArea() {
        return weeklyCallCntByBusnsArea;
    }
    public void setWeeklyCallCntByBusnsArea(
            CallLogReportBean weeklyCallCntByBusnsArea) {
        this.weeklyCallCntByBusnsArea = weeklyCallCntByBusnsArea;
    }
    public String getWeeklyCallCntByBusnsAreaError() {
        return weeklyCallCntByBusnsAreaError;
    }
    public void setWeeklyCallCntByBusnsAreaError(
            String weeklyCallCntByBusnsAreaError) {
        this.weeklyCallCntByBusnsAreaError = weeklyCallCntByBusnsAreaError;
    }
    public CallLogReportBean getVehCallCntByBusnsArea() {
        return vehCallCntByBusnsArea;
    }
    public void setVehCallCntByBusnsArea(CallLogReportBean vehCallCntByBusnsArea) {
        this.vehCallCntByBusnsArea = vehCallCntByBusnsArea;
    }
    public String getVehCallCntByBusnsAreaError() {
        return vehCallCntByBusnsAreaError;
    }
    public void setVehCallCntByBusnsAreaError(String vehCallCntByBusnsAreaError) {
        this.vehCallCntByBusnsAreaError = vehCallCntByBusnsAreaError;
    }
    public String getManualCallCount() {
        return manualCallCount;
    }
    public void setManualCallCount(String manualCallCount) {
        this.manualCallCount = manualCallCount;
    }
    
    


}
