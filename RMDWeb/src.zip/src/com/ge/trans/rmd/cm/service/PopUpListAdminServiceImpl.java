package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.valueobjects.GetSysLookupVO;
import com.ge.trans.rmd.exception.RMDServiceException;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersRequestType;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;



@Service
public class PopUpListAdminServiceImpl extends RMDBaseServiceImpl implements PopUpListAdminService {
	
	private final  RMDWebLogger  rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	
	@Autowired
	private WebServiceInvoker webServiceInvoker;


	@Override
	public List<GetSysLookupVO> getPopupList(
			com.ge.trans.rmd.cm.valueobjects.LookupSearchServiceVO objLookupServiceSearch)
			throws RMDServiceException {
		
		List<GetSysLookupVO> objGetSysLookupVOlst = new ArrayList<GetSysLookupVO>();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		try {
			
			
			queryParams.put(AppConstants.POUP_SEARCHBY, objLookupServiceSearch.getStrSearchBy());
			queryParams.put(AppConstants.POUP_CONDITION, objLookupServiceSearch.getStrSearchCondition());
			queryParams.put(AppConstants.POUP_VALUE, objLookupServiceSearch.getStrValue());
			// Call web service for popup admin list
			final ApplicationParametersResponseType[] arrResponseType = (ApplicationParametersResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_SHOW_ALL,
							null,queryParams,null,
							ApplicationParametersResponseType[].class);
			
		
 
			if (null != arrResponseType) {
				for (ApplicationParametersResponseType objApplicationParametersResponseType : arrResponseType) {
					GetSysLookupVO objGetSysLookupVO = new GetSysLookupVO();
					objGetSysLookupVO.setListName(ESAPI.encoder().decodeForHTML(objApplicationParametersResponseType.getListName()));
					objGetSysLookupVO.setListDescription(ESAPI.encoder().decodeForHTML(objApplicationParametersResponseType.getListDescription()));			
					objGetSysLookupVOlst.add(objGetSysLookupVO);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getPopupList method ", ex);
		}
		return objGetSysLookupVOlst;
	}
	
	

	@Override
	public String updatePopupList(GetSysLookupVO sysvo) throws RMDWebException,
			Exception {
		ApplicationParametersRequestType reqobj = null;
		String returnStr = AppConstants.FAILURE;
		String exceptionString = "Exception occured in updatePopupList() method ";
		try {
			if (null != sysvo) {
				reqobj=new ApplicationParametersRequestType();
				reqobj.setListName(ESAPI.encoder().encodeForXML(sysvo.getListName()));
				reqobj.setListDescription(ESAPI.encoder().encodeForXML(sysvo.getListDescription()));
				reqobj.setOldListName(ESAPI.encoder().encodeForXML(sysvo.getOldListName()));
				reqobj.setUserName(sysvo.getStrUserName());
				webServiceInvoker.put(ServiceConstants.UPDATE_POPUP_LIST,
						reqobj, null);
				returnStr = AppConstants.SUCCESS;
			}
			} catch (RMDWebException e) {
				rmdWebLogger.error(exceptionString, e);
				if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
					returnStr = AppConstants.FAILURE;
				} else {
					throw e;
				}
			} catch (Exception e) {
				rmdWebLogger.error(exceptionString, e);

				throw e;

		}
		return returnStr;
	}

	@Override
	public String deletePopupList(GetSysLookupVO sysvo) throws RMDServiceException,
	Exception {
		ApplicationParametersRequestType reqobj = null;
		String returnStr = AppConstants.FAILURE;
		try {
			if (null != sysvo) {
				reqobj=new ApplicationParametersRequestType();
				reqobj.setUserName(sysvo.getStrUserName());
				reqobj.setListName(ESAPI.encoder().encodeForXML(sysvo.getListName()));
				webServiceInvoker.put(ServiceConstants.DELETE_POPUP_LIST,
						reqobj, null);
				returnStr = AppConstants.SUCCESS;
			}
			} catch (RMDWebException e) {
				rmdWebLogger.error("Exception occured in updatePopupList() method ", e);
				if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
					returnStr = AppConstants.FAILURE;
				} else {
					throw e;
				}
			} catch (Exception e) {
				rmdWebLogger.error("Exception occured in deletePopupList() method ", e);

				throw e;

		}
		return returnStr;
	}


	@Override
	public String savePopupListlookvalue(GetSysLookupVO sysvo)
			throws RMDWebException, Exception {
		ApplicationParametersRequestType reqobj = null;
		String uniquerecord = null;
		try {
			if (null != sysvo) {
				reqobj=new ApplicationParametersRequestType();
				reqobj.setLookupValue(ESAPI.encoder().encodeForXML(sysvo.getLookValue()));
				reqobj.setListName(ESAPI.encoder().encodeForXML(sysvo.getListName()));
				reqobj.setListDescription(ESAPI.encoder().encodeForXML(sysvo.getListDescription()));
				reqobj.setUserName(sysvo.getStrUserName());
				reqobj.setLookValueDesc(ESAPI.encoder().encodeForXML(sysvo.getLookValueDesc()));
				final String arrResponseType = (String) webServiceInvoker
						.post(ServiceConstants.ADD_POPUP_LOOK_VALUES, reqobj,String.class);
				
				if (null != arrResponseType) {			
						uniquerecord = arrResponseType;
					}
				}
			} catch (RMDWebException e) {
				rmdWebLogger.error("Exception occured in savePopupListlookvalue method ", e);
				if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
					uniquerecord = AppConstants.FAILURE;
				} else {
					throw e;
				}
			} catch (Exception e) {
				rmdWebLogger.error("Exception occured in savePopupListlookvalue method ", e);

				throw e;

		}
		return uniquerecord;
	}

	@Override
	public String removePopupListlookvalue(GetSysLookupVO sysvo)
			throws RMDServiceException, Exception {
		ApplicationParametersRequestType reqobj = null;
		String returnStr = AppConstants.FAILURE;
		try {
			if (null != sysvo) {
				reqobj=new ApplicationParametersRequestType();
				reqobj.setListName(ESAPI.encoder().encodeForXML(sysvo.getListName()));
				reqobj.setSysLookupSeqId(sysvo.getGetSysLookupSeqId());
				reqobj.setSortOrder(sysvo.getSortOrder());
				webServiceInvoker.put(ServiceConstants.REMOVE_POPUP_LOOK_VALUES,
						reqobj, null);
				returnStr = AppConstants.SUCCESS;
			}
			} catch (RMDWebException e) {
				rmdWebLogger.error("Exception occured in removePopupListlookvalue() method ", e);
				if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
					returnStr = AppConstants.FAILURE;
				} else {
					throw e;
				}
			} catch (Exception e) {
				rmdWebLogger.error("Exception occured in deletePopupList() method ", e);

				throw e;

		}
		return returnStr;
	}

	@Override
	public List<GetSysLookupVO> getPopupListValues(GetSysLookupVO sysvo)
			throws RMDServiceException {
		
		List<GetSysLookupVO> objGetSysLookupVOlst = new ArrayList<GetSysLookupVO>();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		try {
			queryParams.put(AppConstants.POUP_LIST_NAME, sysvo.getListName());
			// Call web service for popup admin list values in third table i.e;sortorder,value and state
			final ApplicationParametersResponseType[] arrResponseType = (ApplicationParametersResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_POPUP_LIST_VALUES,
							null,queryParams,null,
							ApplicationParametersResponseType[].class);
			
		
 
			if (null != arrResponseType) {
				for (ApplicationParametersResponseType objApplicationParametersResponseType : arrResponseType) {
					GetSysLookupVO objGetSysLookupVO = new GetSysLookupVO();
					objGetSysLookupVO.setGetSysLookupSeqId(objApplicationParametersResponseType.getSysLookupSeqId());
					objGetSysLookupVO.setListName(ESAPI.encoder().decodeForHTML(objApplicationParametersResponseType.getListName()));
					objGetSysLookupVO.setLookValue(ESAPI.encoder().decodeForHTML(objApplicationParametersResponseType.getLookupValue()));
					objGetSysLookupVO.setListDescription(ESAPI.encoder().decodeForHTML(objApplicationParametersResponseType.getListDescription()));
					objGetSysLookupVO.setLookState(objApplicationParametersResponseType.getLookupState());
					objGetSysLookupVO.setSortOrder(Long.parseLong(objApplicationParametersResponseType.getSortOrder()));
					objGetSysLookupVO.setLookValueDesc(ESAPI.encoder().decodeForHTML(objApplicationParametersResponseType.getLookValueDesc()));
					objGetSysLookupVOlst.add(objGetSysLookupVO);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getPopupList method ", ex);
		}
		return objGetSysLookupVOlst;
	}



	@Override
	public String savePopupList(GetSysLookupVO sysvo) throws RMDWebException,
			Exception {
		ApplicationParametersRequestType reqobj = null;
		String uniquerecord = null;
		try {
			if (null != sysvo) {
				reqobj=new ApplicationParametersRequestType();
				reqobj.setListName(ESAPI.encoder().encodeForXML(sysvo.getListName()));
				reqobj.setListDescription(ESAPI.encoder().encodeForXML(sysvo.getListDescription()));
				reqobj.setUserName(sysvo.getStrUserName());
				final String arrResponseType = (String) webServiceInvoker
						.post(ServiceConstants.ADD_POPUP_LIST_VALUES, reqobj,String.class);
				
				if (null != arrResponseType) {			
						uniquerecord = arrResponseType;
					}
				}
			} catch (Exception ex) {
				rmdWebLogger.error("Exception occured in savePopupList method ", ex);
				RMDWebErrorHandler.handleException(ex);

			}
		return uniquerecord;
	}


@Override
	public String updatePopupListValues(List<GetSysLookupVO> list, String userId)
			throws RMDServiceException, Exception {
		String status = AppConstants.FAILURE;
		ApplicationParametersRequestType rowList = new ApplicationParametersRequestType();
		List<ApplicationParametersRequestType> rowValues = new ArrayList<ApplicationParametersRequestType>();
		try {
			for (GetSysLookupVO objGetSysLookupVO : list) {
				ApplicationParametersRequestType objreqtype = new ApplicationParametersRequestType();
				if (!RMDCommonUtility.isNullOrEmpty(Long.toString(objGetSysLookupVO
						.getGetSysLookupSeqId()))) {
					objreqtype.setSysLookupSeqId(objGetSysLookupVO
							.getGetSysLookupSeqId());
				}
				if (!RMDCommonUtility.isNullOrEmpty(Long.toString(objGetSysLookupVO
						.getSortOrder()))) {
					objreqtype.setSortOrder(objGetSysLookupVO
							.getSortOrder());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objGetSysLookupVO
						.getLookValue())) {
					objreqtype.setLookupValue(ESAPI.encoder().encodeForXML(objGetSysLookupVO
							.getLookValue()));
				}
				if (!RMDCommonUtility.isNullOrEmpty(objGetSysLookupVO
						.getLookState())) {
					objreqtype.setLookupState(objGetSysLookupVO
							.getLookState());
				}
				if (!RMDCommonUtility.isNullOrEmpty(userId)) {
					objreqtype.setUserName(userId);
				}
				if (!RMDCommonUtility.isNullOrEmpty(objGetSysLookupVO
						.getLookValueDesc())) {
					objreqtype.setLookValueDesc(ESAPI.encoder().encodeForXML(objGetSysLookupVO
							.getLookValueDesc()));
				}
				rowValues.add(objreqtype);
				
			}
		
			rowList.setListpopupdetails(rowValues);
			status = (String) webServiceInvoker.post(
					ServiceConstants.UPDATE_POPUP_LIST_VALUE,
					rowList, String.class);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("Exception occured in updatePopupListValues method  method of PopUpListAdminServiceImpl ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return status;
	}



}
