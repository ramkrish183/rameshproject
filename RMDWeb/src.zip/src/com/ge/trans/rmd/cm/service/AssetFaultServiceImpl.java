/**
 * ============================================================
 * Classification: GE Confidential
 * File : AssetFaultServiceImpl.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.cm.service;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on : February 14, 2012
 * History
 * Modified By : iGATE
 *
 * Copyright (C) 2012 General Electric Company. All rights reserved
 *
 * ============================================================
 */ 
package com.ge.trans.rmd.cm.service;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.beans.AssetFaultDataBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.FaultDataDetailsResponseType;


@Service
public class AssetFaultServiceImpl extends RMDBaseServiceImpl implements AssetFaultService 
 {

	@Autowired
	private WebServiceInvoker webServiceInvoker;
	private final RMDWebLogger rmdWebLogger = RMDWebLogger.getLogger(getClass());
	/**
	 * @throws RMDWebException 
	 * This Method is used for calling Web Service and get list of FaultDataDetailsResponseType
	 * parameters passed in assetFaultDataBean
	 * 
	 * @param assetFaultDataBean
	 * @return FaultDataDetailsResponseType 
	 *
	 */
	@Override
	public FaultDataDetailsResponseType getAssetFaultDetails(final AssetFaultDataBean assetFaultDataBean, String userCustomer) throws RMDWebException, Exception  {
		final long startTime = System.currentTimeMillis();		
		FaultDataDetailsResponseType resultObj = null;
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		final Map<String, String> pathParamsPastDays = new LinkedHashMap<String, String>();
		final Map<String, String> queryParamsMap = new HashMap<String, String>();
		final Map<String, String> headerParams = getHeaderMap(assetFaultDataBean);		
		try {			
			pathParams.put(AppConstants.ASSET_NUMBER, assetFaultDataBean.getAssetNumber());            // Asset Number *  --
			pathParams.put(AppConstants.ASSET_GROUP_NAME, assetFaultDataBean.getAssetGrpName());       // Asset Group name * -- 
			pathParams.put(AppConstants.CUSTOMER_ID, assetFaultDataBean.getCustomerId());              // Customer ID *  --
			
			if (assetFaultDataBean.getStartRow() == null) {
				queryParamsMap.put(AppConstants.START_ROW, AppConstants.DEFAULT_START_ROW);            // Default Pagination start row
			} else {
				queryParamsMap.put(AppConstants.START_ROW, assetFaultDataBean.getStartRow());      	   // Pagination start row
			}
			if (assetFaultDataBean.isDieselDoctor()){
				queryParamsMap.put(AppConstants.SORT_OPTIONS, AppConstants.OCCUR_DATE);                // Diesel Doctor Sort Option				
			} else if (assetFaultDataBean.getSortOption() != null) {
				queryParamsMap.put(AppConstants.SORT_OPTIONS, assetFaultDataBean.getSortOption());     // Sort Option
			}
			
			queryParamsMap.put(AppConstants.ROLE_NAME, assetFaultDataBean.getRoleName());                // Diagnostic Doctor Sort Option				
			queryParamsMap.put(AppConstants.USER_CUSTOMER, userCustomer);
			queryParamsMap.put(AppConstants.USER_TIMEZONE, assetFaultDataBean.getUserTimeZone()); 
			queryParamsMap.put(AppConstants.USER_TIMEZONE_CODE, assetFaultDataBean.getUserTimeZoneCode()); 
			queryParamsMap.put(AppConstants.ENABLE_CUSTOM_COLUMNS, String.valueOf(assetFaultDataBean.isEnableCustomColumns())); 
			
			if (assetFaultDataBean.getDropdownDays() != null) {
				queryParamsMap.put(AppConstants.WS_PARAM_DAYS, assetFaultDataBean.getDropdownDays());  // No of Days * 
			} else if (assetFaultDataBean.getFromDate() != null && assetFaultDataBean.getToDate() != null) {
				queryParamsMap.put(AppConstants.FROM_DATE, assetFaultDataBean.getFromDate());          // From Date
				queryParamsMap.put(AppConstants.TO_DATE, assetFaultDataBean.getToDate());              // To Date 
			} else if (assetFaultDataBean.getDropdownDays() == null && assetFaultDataBean.getFromDate() == null
					&& assetFaultDataBean.getToDate() == null && assetFaultDataBean.getCaseId() == null) {
				pathParamsPastDays.put(AppConstants.LIST_NAME,AppConstants.DATA_SCREEN_DEFAULT_NO_OF_DAYS);
				final Map<String, String> dateMap = findDate(pathParamsPastDays,assetFaultDataBean);
				queryParamsMap.put(AppConstants.FROM_DATE, dateMap.get(AppConstants.FROM_DATE));       // Default From Date
				queryParamsMap.put(AppConstants.TO_DATE, dateMap.get(AppConstants.TO_DATE));           // default To Date 
			}
			if (assetFaultDataBean.isLimitedParam()) {
				queryParamsMap.put(AppConstants.IS_LIMITED_PARAM, AppConstants.YES_FLAG);              // Limited Param *						
			} else {
				queryParamsMap.put(AppConstants.IS_LIMITED_PARAM, AppConstants.NO_FLAG);
			}
			if (assetFaultDataBean.isHideL3Faults()) {
				queryParamsMap.put(AppConstants.IS_HIDE_L3, AppConstants.YES_FLAG);              	   // Hide L3 Faults *	
			}
			if (assetFaultDataBean.getInitLoad() != null) {
				queryParamsMap.put(AppConstants.INIT_LOAD, AppConstants.YES_FLAG);              	   // Init Load
			}
			if (assetFaultDataBean.getDataSet() != null && !assetFaultDataBean.getDataSet().trim().equals("")) {
				queryParamsMap.put(AppConstants.DATA_SCREEN, assetFaultDataBean.getDataSet());         // Screen Type 
			}
			if (assetFaultDataBean.getAllRecords() != null && !assetFaultDataBean.getAllRecords().trim().equals("")) {
				queryParamsMap.put(AppConstants.ALL_RECORDS, assetFaultDataBean.getAllRecords());      // All Records 
			}
			if (assetFaultDataBean.getNotch8() != null && !assetFaultDataBean.getNotch8().trim().equals("")) {
				queryParamsMap.put(AppConstants.NOTCH_8, assetFaultDataBean.getNotch8());              // Notch 8
			}
			if (assetFaultDataBean.getCaseId() != null && !assetFaultDataBean.getCaseId().trim().equals("")) {
				queryParamsMap.put(AppConstants.CASE_ID, assetFaultDataBean.getCaseId());              // Case ID
			}
			if (assetFaultDataBean.getCaseType() != null && !assetFaultDataBean.getCaseType().trim().equals("")) {
				queryParamsMap.put(AppConstants.CASE_TYPE, assetFaultDataBean.getCaseType());          // Case Type
			}
			if (assetFaultDataBean.getStrCaseFrom() != null && !assetFaultDataBean.getStrCaseFrom().trim().equals("")) {
				queryParamsMap.put(AppConstants.CASE_FROM, assetFaultDataBean.getStrCaseFrom());       // Case From
			}
			if (assetFaultDataBean.getRuleId() != null && !assetFaultDataBean.getRuleId().trim().equals("")) {
				queryParamsMap.put(AppConstants.RS_RULE_ID, assetFaultDataBean.getRuleId());           // Rule ID
			}
			if (assetFaultDataBean.getRuleType() != null && !assetFaultDataBean.getRuleType().trim().equals("")) {
				queryParamsMap.put(AppConstants.RULE_TYPE, assetFaultDataBean.getRuleType());          // Rule Type
			}
			if (assetFaultDataBean.getHealthCheck() != null && !assetFaultDataBean.getHealthCheck().trim().equals("")) {
				queryParamsMap.put(AppConstants.IS_HEALTH_CHECK, assetFaultDataBean.getHealthCheck()); // Health Check
			}			
			resultObj = (FaultDataDetailsResponseType) webServiceInvoker.get(
					ServiceConstants.ASSET_FAULT_DATA_SERVICE,
					pathParams,
					queryParamsMap,headerParams,
					FaultDataDetailsResponseType.class				
					);
		}
		catch (Exception ex) {
			rmdWebLogger.error(ex, ex);
			rmdWebLogger.error("Exception occured in AssetFaultServiceImpl.getAssetFaultDetails method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		final long endTime = System.currentTimeMillis();
		rmdWebLogger.debug("############ Class: AssetFaultServiceImpl - Method: getAssetFaultDetails() >> START TIME: "+startTime+"ms  END TIME: "+endTime+"ms 2nd WS(get Fault Data) Call Time Difference: "+(endTime-startTime)+"ms");
		return resultObj;
	}
	/**
	 * @throws Exception 
	 * This Method is used for finding from date after looking up the x-days from webservice call 
	 * parameters passed in assetFaultDataBean
	 * 
	 * @param Map<String, String> pathParamsPastDays
	 * @return Map<String, String> 
	 *
	 */

	public Map<String, String> findDate(final Map<String, String> pathParamsPastDays,final AssetFaultDataBean assetFaultDataBean) throws RMDWebException, Exception{
		
		final long startTime = System.currentTimeMillis();
		final Map<String, String> dateMap = new HashMap<String, String>();
		final SimpleDateFormat fromDateFormat = new SimpleDateFormat(AppConstants.FROM_DATE_FORMAT);
		final SimpleDateFormat toDateFormat = new SimpleDateFormat(AppConstants.TO_DATE_FORMAT);
		String numDaysBefore = null;
		String fromDate = null;
		String toDate = null;
		try{
		/* Added for diesel doctor story*/	
			
			
			if(null!=assetFaultDataBean.getDropdownDays()){
				numDaysBefore=assetFaultDataBean.getDropdownDays();
			}else{
				
			final ApplicationParametersResponseType[] applParamResponseType  = getLookupValue(pathParamsPastDays);
			if(applParamResponseType!=null){
				for(int i=0;i<applParamResponseType.length;i++){
					
				numDaysBefore = applParamResponseType[0].getLookupValue();
				}
			}}
			/* Added for diesel doctor story*/
			if(null!=assetFaultDataBean.getFromDate()&& null!=assetFaultDataBean.getToDate()){
				dateMap.put(AppConstants.FROM_DATE, assetFaultDataBean.getFromDate());
				dateMap.put(AppConstants.TO_DATE, assetFaultDataBean.getToDate());
			}else if(numDaysBefore!=null){
			final Date dateToday = new Date();
			final Calendar calendar = Calendar.getInstance();
			calendar.setTime(dateToday);
			calendar.add(Calendar.DATE,(Integer.parseInt(numDaysBefore)*(-1)));
			 final Date fromDateTemp = new Date(calendar.getTime().getTime());
			if(fromDateTemp!=null){
				fromDate = fromDateFormat.format(fromDateTemp);
				dateMap.put(AppConstants.FROM_DATE, fromDate);}
			if(dateToday!=null){
				toDate = toDateFormat.format(dateToday);
				dateMap.put(AppConstants.TO_DATE, toDate);}
			}
	    	
		}catch (RMDWebException rmdEx) {
			rmdWebLogger.error("RMDWebException occured in findDate() method ", rmdEx);
			throw rmdEx;
		}catch (Exception ex) {
			rmdWebLogger.error("Exception occured in findDate() method ", ex);
		}
		final long endTime = System.currentTimeMillis();
		rmdWebLogger.debug("############ Class: AssetFaultServiceImpl - Method: findDate() >> START TIME: "+startTime+"ms  END TIME: "+endTime+"ms   First WS (find X days) call time Difference: "+(endTime-startTime)+" ms");
		return dateMap;
	}
	
	/**
	 * @throws RMDWebException 
	 * This Method is used for calling Web Service and get list of FaultDataDetailsResponseType while we are passing Case ID and Rule ID
	 * parameters passed in assetFaultDataBean
	 * Story name Data Screen: Display Data dropdown 
	 * @author Rajesh,iGATE Patni
	 * @param assetFaultDataBean
	 * @return FaultDataDetailsResponseType 
	 *
	 */
	@Override
	public FaultDataDetailsResponseType getAssetFaultDetailsForCaseID(final AssetFaultDataBean assetFaultDataBean) throws RMDWebException, Exception  {
		final long startTime = System.currentTimeMillis();		
		FaultDataDetailsResponseType resultObj = null;
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		final Map<String, String> queryParamsMap = new HashMap<String, String>();
		final Map<String, String> headerParams = getHeaderMap(assetFaultDataBean);
		
		try{
			if(assetFaultDataBean.getSelectType().equals(AppConstants.STR_RULE)){

				queryParamsMap.put(AppConstants.RULE_DEFINITION_ID,assetFaultDataBean.getRuleId());
				queryParamsMap.put(AppConstants.JDPAD_RADIO,AppConstants.STR_JDPAD);
			}else if(assetFaultDataBean.getSelectType().equals(AppConstants.STR_CASE)){
				queryParamsMap.put(AppConstants.JDPAD_RADIO,AppConstants.STR_DAYS);
			}
			else {
				queryParamsMap.put(AppConstants.JDPAD_RADIO,AppConstants.STR_DAYS);
			}
			pathParams.put(AppConstants.WS_PARAM_CASEID,assetFaultDataBean.getCaseId());
			queryParamsMap.put(AppConstants.ASSET_NUMBER, assetFaultDataBean.getAssetNumber());
			queryParamsMap.put(AppConstants.ASSET_GROUP_NAME, assetFaultDataBean.getAssetGrpName());
			queryParamsMap.put(AppConstants.CUSTOMER_ID, assetFaultDataBean.getCustomerId());
			if (assetFaultDataBean.isLimitedParam()) {
				queryParamsMap.put(AppConstants.IS_LIMITED_PARAM,
						AppConstants.YES_FLAG);
			} else {
				queryParamsMap.put(AppConstants.IS_LIMITED_PARAM,
						AppConstants.NO_FLAG);
			}
			/*Added for diesel doctor story*/
			queryParamsMap.put(AppConstants.RMD_DD_LOOKUPVALUE, assetFaultDataBean.getDataSet());
			/*Added for diesel doctor story*/
			
			//Putting dropdown days and caseFrom in the query param map 
			if (null != assetFaultDataBean.getDropdownDays()) {
				queryParamsMap.put(AppConstants.WS_PARAM_DAYS,
						assetFaultDataBean.getDropdownDays());
			}
			if (null != assetFaultDataBean.getStrCaseFrom()) {
				queryParamsMap.put(AppConstants.CASE_FROM,
						assetFaultDataBean.getStrCaseFrom());
			}
			
			//datacsreen sort order change for DD role: Phase II Sprint 6 change - Start
			if(assetFaultDataBean.isDieselDoctor()){
				queryParamsMap.put(AppConstants.SORT_OPTIONS, AppConstants.OCCUR_TIME);
			}
			//datacsreen sort order change for DD role: Phase II Sprint 6 change - End
			queryParamsMap.put(AppConstants.START_ROW, AppConstants.DEFAULT_START_ROW);
			queryParamsMap.put(AppConstants.MIN_FAULT_ID, AppConstants.MIN_DEFAULT_SEQ_ID);
			queryParamsMap.put(AppConstants.MAX_FAULT_ID, AppConstants.MAX_DEFAULT_SEQ_ID);
			queryParamsMap.put(AppConstants.END_ROW, AppConstants.DEFAULT_END_ROW);
			queryParamsMap.put(AppConstants.CALENDER, AppConstants.CALENDER_MINUTES);
			resultObj = (FaultDataDetailsResponseType)webServiceInvoker.get(
					ServiceConstants.ASSET_FAULT_DATA_SERVICE,
					pathParams,
					queryParamsMap,headerParams,
					FaultDataDetailsResponseType.class				
					);

		}
		catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getAssetFaultDetailsForCaseID method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		final long endTime = System.currentTimeMillis();
		rmdWebLogger.debug("############ Class: AssetFaultServiceImpl - Method: getAssetFaultDetailsForCaseID() >> START TIME: "+startTime+"ms  END TIME: "+endTime+"ms 2nd WS(get Fault Data) Call Time Difference: "+(endTime-startTime)+"ms");
		return resultObj;
	}
}