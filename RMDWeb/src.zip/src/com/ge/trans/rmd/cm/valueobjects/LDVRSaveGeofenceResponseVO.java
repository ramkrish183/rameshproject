package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

public class LDVRSaveGeofenceResponseVO {
	private String status;
	private List<LDVRSaveGeofenceStatus> ldvrSaveGeofenceStatus;
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public List<LDVRSaveGeofenceStatus> getLdvrSaveGeofenceStatus() {
		return ldvrSaveGeofenceStatus;
	}
	public void setLdvrSaveGeofenceStatus(
			List<LDVRSaveGeofenceStatus> ldvrSaveGeofenceStatus) {
		this.ldvrSaveGeofenceStatus = ldvrSaveGeofenceStatus;
	}

	
}
