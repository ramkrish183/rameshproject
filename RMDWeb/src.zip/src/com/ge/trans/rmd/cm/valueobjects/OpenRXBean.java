package com.ge.trans.rmd.cm.valueobjects;

public class OpenRXBean {
	private String creationRXDate;
	private String day;
	private String count;
	private String problemDesc;
	private String customer;
	public String getCreationRXDate() {
		return creationRXDate;
	}
	public void setCreationRXDate(String creationRXDate) {
		this.creationRXDate = creationRXDate;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	public String getCount() {
		return count;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getProblemDesc() {
		return problemDesc;
	}
	public void setProblemDesc(String problemDesc) {
		this.problemDesc = problemDesc;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
}
