/**
 * ============================================================

 * Classification		: GE Confidential
 * File 				: QueueDetailsVO.java
 * Description 			:
 * Package 				: com.ge.trans.rmd.cm.valueobjects;
 * Author 				: iGATE Global Solutions Ltd.
 * Last Edited By 		:
 * Version 				: 1.0
 * Created on 			:
 * History				:
 * Modified By 			: Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */

package com.ge.trans.rmd.cm.valueobjects;

import java.util.ArrayList;
import java.util.List;

/*******************************************************************************
 * 
 * @Author 			:
 * @Version 		: 1.0
 * @Date Created	:
 * @Date Modified 	:
 * @Modified By 	:
 * @Contact 		:
 * @Description 	:This is plain POJO class which contains queueId,queueName
 *             		 Declarations along with their respective getters and setters.
 * @History 		:
 * 
 ******************************************************************************/


public class RecommDeliverVO {

private String strRxObjId;
private String caseId;
private String customerName;
private String recommNotes;
private String userName;
private int fdbkObjId;
private String urgency;
private String estRepairTime;
private String rxCaseId;
private String caseObjId;
private Long rxObjId;
private String fdbkStatus;
private String pendingFeedbackStatus;
private String rxTitle;
private String delvrdRxObjId;
private String isFromDeliver;
private SolutionDetailVO solutionDetailVO;
private String userId;
private List<RecommDelvDocVO> arlRecommDelDocVO=new ArrayList<RecommDelvDocVO>();

public List<RecommDelvDocVO> getArlRecommDelDocVO() {
		return arlRecommDelDocVO;
	}
	public void setArlRecommDelDocVO(List<RecommDelvDocVO> arlRecommDelDocVO) {
		this.arlRecommDelDocVO = arlRecommDelDocVO;
	}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getIsFromDeliver() {
	return isFromDeliver;
}
public void setIsFromDeliver(String isFromDeliver) {
	this.isFromDeliver = isFromDeliver;
}
public SolutionDetailVO getSolutionDetailVO() {
	return solutionDetailVO;
}
public void setSolutionDetailVO(SolutionDetailVO solutionDetailVO) {
	this.solutionDetailVO = solutionDetailVO;
}
public String getRxTitle() {
	return rxTitle;
}
public void setRxTitle(String rxTitle) {
	this.rxTitle = rxTitle;
}
public String getDelvrdRxObjId() {
	return delvrdRxObjId;
}
public void setDelvrdRxObjId(String delvrdRxObjId) {
	this.delvrdRxObjId = delvrdRxObjId;
}
public String getCaseTitle() {
	return rxTitle;
}
public void setCaseTitle(String caseTitle) {
	this.rxTitle = caseTitle;
}
public String getPendingFeedbackStatus() {
	return pendingFeedbackStatus;
}
public void setPendingFeedbackStatus(String pendingFeedbackStatus) {
	this.pendingFeedbackStatus = pendingFeedbackStatus;
}
public String getFdbkStatus() {
	return fdbkStatus;
}
public void setFdbkStatus(String fdbkStatus) {
	this.fdbkStatus = fdbkStatus;
}
public Long getRxObjId() {
	return rxObjId;
}
public void setRxObjId(Long lonRxObjId) {
	this.rxObjId = lonRxObjId;
}
public String getCaseObjId() {
	return caseObjId;
}
public void setCaseObjId(String caseObjId) {
	this.caseObjId = caseObjId;
}
public String getRxCaseId() {
	return rxCaseId;
}
public void setRxCaseId(String rxCaseId) {
	this.rxCaseId = rxCaseId;
}
public String getUrgency() {
	return urgency;
}
public void setUrgency(String urgency) {
	this.urgency = urgency;
}
public String getEstRepairTime() {
	return estRepairTime;
}
public void setEstRepairTime(String estRepairTime) {
	this.estRepairTime = estRepairTime;
}
public int getFdbkObjId() {
	return fdbkObjId;
}
public void setFdbkObjId(int fdbkObjId) {
	this.fdbkObjId = fdbkObjId;
}
public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getStrRxObjId() {
	return strRxObjId;
}
public void setStrRxObjId(String rxObjId) {
	this.strRxObjId = rxObjId;
}
public String getCaseId() {
	return caseId;
}
public void setCaseId(String caseId) {
	this.caseId = caseId;
}

public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getRecommNotes() {
	return recommNotes;
}
public void setRecommNotes(String recommNotes) {
	this.recommNotes = recommNotes;
}



	
}
