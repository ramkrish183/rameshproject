/*******************************************************************************
 * 
 * @Author : General Electric
 * @Version : 1.0
 * @Date Created:
 * @Date Modified :
 * @Modified By :
 * @Contact :
 * @Description : This is the service interface layer class which is used for
 *              GPOC turnover
 * @History :
 * 
 ******************************************************************************/
package com.ge.trans.rmd.cm.service;
import java.util.List;
import com.ge.trans.rmd.common.beans.GpocNotesBean;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.GenNotesVO;
import com.ge.trans.rmd.exception.RMDServiceException;

public interface GeneralNotesService {
		
		/**
		 * @Author:General Electric
		 * @param GpocNotesBean
		 * @return String
		 * @Description: method to add the general notes
		 */
		
		public String addGeneralNotes(GpocNotesBean gpocNotesBean) throws GenericAjaxException, RMDWebException;
		
		/**
		 * @Author:General Electric
		 * @param GpocNotesBean
		 * @return String
		 * @Description: method to remove the general notes
		 */
		public String removeGeneralNotes(List<GenNotesVO> generalnotesvo) throws RMDServiceException,Exception;
		
		
		/**
		 * @Author:General Electric
		 * @param GpocNotesBean
		 * @return List
		 * @Description: method to show all general notes
		 */
		
		List<GenNotesVO> showAllGeneralNotes(GpocNotesBean gpocNotesBean,String userTimeZone) throws RMDWebException, Exception;

		/**
	     * @Author:
	     * @param :List<GenNotesVO>
	     * @return String
	     * @throws RMDWebException
	     * @Description: This method is used to update the visibility flag of General/Comm notes
	     */
        public String updateGenOrCommNotes(List<GenNotesVO> objGenNotesVO) throws RMDWebException;;
		
	
}
