package com.ge.trans.rmd.cm.service;

import java.util.List;

import com.ge.trans.rmd.common.beans.GpocNotesBean;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.GenNotesVO;
import com.ge.trans.rmd.exception.RMDServiceException;

public interface CommNotesService {

	public String addCommNotes(GpocNotesBean gpocNotesBean)
			throws GenericAjaxException, RMDWebException;

	List<GenNotesVO> showAllCommNotes(GpocNotesBean gpocNotesBean,
			String userTimeZone) throws RMDWebException, Exception;

	public String removeCommNotes(List<GenNotesVO> commnotesvo)
			throws RMDServiceException, Exception;

}
