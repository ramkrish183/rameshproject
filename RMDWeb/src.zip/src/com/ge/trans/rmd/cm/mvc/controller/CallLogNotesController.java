/*******************************************************************************
 *
 * @Author 		: GE
 * @Version 	: 1.0
 * @Date Created: Jan 21, 2016
 * @Date Modified:
 * @Modified By : 
 * @Contact 	:
 * @Description : This class act as a controller to get call log data
 * 
 * @History		:
 *
 ******************************************************************************/
package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.AssetOverviewService;
import com.ge.trans.rmd.cm.service.CallLogNotesService;
import com.ge.trans.rmd.cm.valueobjects.CallLogNotesVO;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class CallLogNotesController extends RMDBaseController {
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private ApplicationContext appContext;
	
	@Autowired
	private CallLogNotesService callLogNotesService;
	
	@Autowired
	private AuthorizationService authorizationService;
	
	@Autowired
	private AssetOverviewService asstOvwService;
	
	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description: 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_CALLLOG, method = RequestMethod.GET)
	public ModelAndView getCallLogPage(final HttpServletRequest request)
			 throws RMDWebException {
		
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String strAssetNumber = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String strAssetGroup = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_GROUP_NAME));
		String strCustomerId = null;
		String fromDate = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FROM_DATE));          
		String toDate = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TO_DATE));
		
		final String strUserTimeZone = EsapiUtil.stripXSSCharacters(userVO.getTimeZone());		
		final String strUserLanguage = EsapiUtil.stripXSSCharacters(userVO.getStrUserLanguage());
		final SimpleDateFormat dateFormat = new SimpleDateFormat(AppConstants.TO_DATE_FORMAT);
	        final String defaultTimezone= EsapiUtil.stripXSSCharacters((String)request.getAttribute(AppConstants.DEFAULT_TIMEZONE));
		String applicationTimezone=EsapiUtil.stripXSSCharacters(RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone()));
		/*Begin of Changes for fetching customer Id from Webservices */
		try {
			strCustomerId=asstOvwService.getCustomerId(strAssetNumber, strAssetGroup);
		} catch (RMDWebException e) {
			RMDWebErrorHandler.handleException(e);
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCallLogPage() method while fetching customer Id",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		/*End of Changes*/
		request.setAttribute(AppConstants.REQ_PARAM_ASSTNUM, strAssetNumber);
		request.setAttribute(AppConstants.ASSET_GROUP_NAME, strAssetGroup);
		request.setAttribute(AppConstants.WS_PARAM_CUSTID, strCustomerId);
		
		String defaultDays = EsapiUtil.stripXSSCharacters(getDefaultDays());
		
		String controllerCfg = getControllerConfig(strAssetNumber, strCustomerId, strAssetGroup, strUserTimeZone, strUserLanguage);
		
		
		request.setAttribute(AppConstants.CALL_LOG_LOOKUP_DAYS, defaultDays);
		
		request.setAttribute(AppConstants.CONTROLLER_CONFIG, controllerCfg);
	
		rmdWebLogger.info("defaulttimezone in calllogcontroller "+defaultTimezone);
		rmdWebLogger.info("applicationtimezone in calllogcontroller "+applicationTimezone);
		rmdWebLogger.info("usertimezone in calllogcontroller "+userVO.getTimeZone());
		dateFormat.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
		if (fromDate == null && toDate == null) {	
			Calendar fromDtCal = Calendar.getInstance();
			fromDtCal.add(Calendar.DATE, -Integer.parseInt(defaultDays));
			//fromDtCal.set(Calendar.HOUR,dateFormat.getCalendar().get(Calendar.HOUR));
			fromDate = dateFormat.format(fromDtCal.getTime());
			rmdWebLogger.info("fromDate in calllogcontroller " + fromDate);
			toDate = dateFormat.format(new Date());
			rmdWebLogger.info("toDate in calllogcontroller " + toDate);
		}
		
		request.setAttribute(AppConstants.FROM_DATE, fromDate);
		request.setAttribute(AppConstants.TO_DATE, toDate);
		return new ModelAndView(AppConstants.VIEW_CALLLOG);

	}
	
	@RequestMapping(value = AppConstants.REQ_SEARCH_CALLLOG, method = RequestMethod.POST)
	public @ResponseBody List<CallLogNotesVO> getCallLogNotes(final HttpServletRequest request)
			 throws RMDWebException {
			rmdWebLogger
					.info("Inside CallLogNotesController in getCallLogNotes Method");
			final SimpleDateFormat dateFormat = new SimpleDateFormat(AppConstants.CALL_LOG_DATE_FORMAT);
			SimpleDateFormat sdfSource = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
			List<CallLogNotesVO> lstCallLogNotesVO = null;
			try {		
				final HttpSession session = request.getSession(false);
				final UserVO userVO = (UserVO) session
						.getAttribute(AppConstants.ATTR_USER_OBJECT);
				String fromDate = request.getParameter(AppConstants.FROM_DATE);
				String toDate = request.getParameter(EsapiUtil.stripXSSCharacters(AppConstants.TO_DATE));
				
				if(!RMDCommonUtility.isNull(fromDate)){						
					Date dFromDate = sdfSource.parse(fromDate);					
					fromDate = dateFormat.format(dFromDate);
				}
				if(!RMDCommonUtility.isNull(toDate)){
					Date dToDate = sdfSource.parse(toDate);		
					toDate = dateFormat.format(dToDate);
				}				
				String customerId = request.getParameter(EsapiUtil.stripXSSCharacters(AppConstants.CUSTOMER_ID));
				String assetNumber = request.getParameter(EsapiUtil.stripXSSCharacters(AppConstants.ASSET_NUMBER));
				String assetGroupName = request.getParameter(EsapiUtil.stripXSSCharacters(AppConstants.ASSET_GROUP_NAME));
				CallLogNotesVO callLogNotesVO = new CallLogNotesVO();
				callLogNotesVO.setFromDate(fromDate);
				callLogNotesVO.setToDate(toDate);
				callLogNotesVO.setCustomerId(customerId);				
				callLogNotesVO.setAssetNumber(assetNumber);	
				callLogNotesVO.setAssetGroupName(assetGroupName);
				lstCallLogNotesVO = callLogNotesService.getCallLogNotes(callLogNotesVO,userVO.getTimeZone());	
				rmdWebLogger.info("call log response ::: "+callLogNotesVO);					
			} catch (RMDWebException e) {

				RMDWebErrorHandler.handleException(e);

			} catch (Exception ex) {
				rmdWebLogger.error(
						"Exception occured in getCallLogNotes  method ", ex);
				RMDWebErrorHandler.handleException(ex);
			}
			return lstCallLogNotesVO;
	}
	/**
	 * @Author:
	 * @param:HttpServletRequest reques
	 * @return:List<CallLogVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for exporting call log notes to CSV
	 *               Format.
	 */

	@RequestMapping(AppConstants.EXPORT_CALLLOG_NOTES)
	public @ResponseBody
	void exportCallLogNotes(final HttpServletRequest request,final HttpServletResponse response,final Locale locale)
			throws RMDWebException, Exception {
		List<CallLogNotesVO> lstCallLogNotesVO = null;
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		String customerList="";
		try {		
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			if (!RMDCommonUtility.isNullOrEmpty(userVO.getCustomerId())) {
				customerList = getCustomerList(userVO.getCustomerList());
				userVO.setCustomerId(customerList);
			}
			final String strAssetNumber = request
					.getParameter(AppConstants.REQ_PARAM_ASSTNUM);
			lstCallLogNotesVO = getCallLogNotes(request);
			csvContent = convertToCSVQueueCases(lstCallLogNotesVO,strAssetNumber, locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.CALL_LOG_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);
			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);
			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
			.error("Exception occured in exportCallLogNotes method ", rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in exportCallLogNotes method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		}
		finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}
		
	}
/**
	 * @Description:This method is used convert Queue cases into csv format
	 * @return: String
	 * @param:List<QueueCaseVO> queuCasesList, Locale locale
	 */
	private String convertToCSVQueueCases(List<CallLogNotesVO> calllogList,String strAssetNumber,
			Locale locale) {
		String csvContent = null;
		StringBuilder strBufferAssetHeader = new StringBuilder();
		try {
			strBufferAssetHeader.append(appContext.getMessage(
					AppConstants.CALL_LOG_HEADER, null, locale));
			strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			for (CallLogNotesVO callLogVO : calllogList) {
				strBufferAssetHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE + callLogVO.getCustomerId()
						+ AppConstants.QUOTE);
						
						strBufferAssetHeader
						.append(RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE
						+ strAssetNumber
						+ AppConstants.QUOTE);
				
						strBufferAssetHeader
						.append(RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE
						+ callLogVO.getCallLogID()
						+ AppConstants.QUOTE);
									
						strBufferAssetHeader
						.append(RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE
						+ callLogVO.getCallerName()
						+ AppConstants.QUOTE);
						
						
						strBufferAssetHeader
						.append(RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE
						+ callLogVO.getCallType()
						+ AppConstants.QUOTE);
						
						if (null != callLogVO.getLocation()) {
							strBufferAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ callLogVO.getLocation()
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE);
						} else {
							strBufferAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ AppConstants.QUOTE);
						}
						
						
				if (null != callLogVO.getAgentSSO()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ callLogVO.getAgentSSO()
									+ AppConstants.QUOTE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}			
				strBufferAssetHeader
				.append(RMDCommonConstants.COMMMA_SEPARATOR
				+ AppConstants.QUOTE
				+ AppConstants.EMPTY_SPACE
				+ callLogVO.getAgentName()
				+ AppConstants.QUOTE);
				
				strBufferAssetHeader
				.append(RMDCommonConstants.COMMMA_SEPARATOR
				+ AppConstants.QUOTE
				+ AppConstants.EMPTY_SPACE
				+ callLogVO.getBusniessArea()
				+ AppConstants.QUOTE);
				
				strBufferAssetHeader
				.append(RMDCommonConstants.COMMMA_SEPARATOR
				+ AppConstants.QUOTE
				+ AppConstants.EMPTY_SPACE
				+ callLogVO.getIssueType()
				+ AppConstants.QUOTE);
				
				strBufferAssetHeader
				.append(RMDCommonConstants.COMMMA_SEPARATOR
				+ AppConstants.QUOTE
				+ AppConstants.EMPTY_SPACE
				+ callLogVO.getCreationDate()
				+ AppConstants.QUOTE);
				//Added for US276325    GPOC: SFDC - OMD Integration - Showing two additional columns in OMD call log screen
				if (null != callLogVO.getCallStartedOn()) {
                    strBufferAssetHeader
                    .append(RMDCommonConstants.COMMMA_SEPARATOR
                    + AppConstants.QUOTE
                    + AppConstants.EMPTY_SPACE
                    + callLogVO.getCallStartedOn()
                    + AppConstants.QUOTE);
                } else{
                    strBufferAssetHeader
                    .append(RMDCommonConstants.COMMMA_SEPARATOR
                            + AppConstants.QUOTE
                            + AppConstants.EMPTY_SPACE
                            + AppConstants.QUOTE);
                }   
				
				if (null != callLogVO.getCallEndedOn()) {
					strBufferAssetHeader
					.append(RMDCommonConstants.COMMMA_SEPARATOR
					+ AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE
					+ callLogVO.getCallEndedOn()
					+ AppConstants.QUOTE);
				} else{
					strBufferAssetHeader
					.append(RMDCommonConstants.COMMMA_SEPARATOR
							+ AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ AppConstants.QUOTE);
				}	
				
				
				if (null != callLogVO.getCallDurationSeconds()) {
					strBufferAssetHeader
					.append(RMDCommonConstants.COMMMA_SEPARATOR
					+ AppConstants.QUOTE
					+ AppConstants.EMPTY_SPACE
					+ callLogVO.getCallDurationSeconds()
					+ AppConstants.QUOTE);
				} else{
					strBufferAssetHeader
					.append(RMDCommonConstants.COMMMA_SEPARATOR
							+ AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ AppConstants.QUOTE);
				}	
				
				
				if (null != callLogVO.getNotes()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ callLogVO.getNotes() + AppConstants.QUOTE);
				} else {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}

				strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBufferAssetHeader.toString();
		} catch (Exception exception) {
			rmdWebLogger.error("Export to CSV call log List"
					+ exception);
		}
		return csvContent;
	}
	
	
	/**
	 * @param request
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description Function to retrieve the values from lookup.
	 */
	@RequestMapping(value = AppConstants.DEFAULT_CALLLOG, method = RequestMethod.GET)
	public @ResponseBody String getDefaultDays()
			throws RMDWebException {
		String defaultDate = null;
		String listName = AppConstants.CALL_LOG_DEFAULT_DATE;
		try {

			defaultDate = authorizationService.getLookUpValueForName(listName);
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getDefaultDays() method - Calllognotescontroller",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return defaultDate;
	}
	/**
	 * @param request
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description Function to retrieve the values from lookup.
	 */
	@RequestMapping(value = AppConstants.GET_CONTROLLER_CONFIG, method = RequestMethod.GET)
	public @ResponseBody String getControllerConfig(String strAssetNumber,String strCustomerId, String strAssetGroup, String strUserTimeZone, String strUserLanguage)
			throws RMDWebException {
		String controllerCfg = RMDCommonConstants.EMPTY_STRING;
		try {			
			AssetOverviewBean assetOverviewBean = new AssetOverviewBean();
			assetOverviewBean.setAsset(EsapiUtil.stripXSSCharacters(strAssetNumber));
			assetOverviewBean.setUserTimeZone(EsapiUtil.stripXSSCharacters(strUserTimeZone));
			assetOverviewBean.setUserLanguage(EsapiUtil.stripXSSCharacters(strUserLanguage));
			assetOverviewBean.setCustomer(EsapiUtil.stripXSSCharacters(strCustomerId));
			assetOverviewBean.setAssetGroup(EsapiUtil.stripXSSCharacters(strAssetGroup));
			assetOverviewBean = asstOvwService.getAssets(assetOverviewBean);
			controllerCfg = assetOverviewBean.getControllerConfig();			
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getHCLookup() method - HealthCheckController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return controllerCfg;
	}
	/**
	 * @param request
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description Function to get user preferred timezone date.
	 */
	@RequestMapping(value = AppConstants.GET_CURR_USER_PREF_TIME, method = RequestMethod.GET)
	public @ResponseBody String getCurrentUserPrefTime(final HttpServletRequest request) throws RMDWebException{ 
		String toDate = null;
		try {
			
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);			
			final SimpleDateFormat dateFormat = new SimpleDateFormat(AppConstants.TO_DATE_FORMAT);
			final String defaultTimezone=EsapiUtil.stripXSSCharacters((String)request.getAttribute(AppConstants.DEFAULT_TIMEZONE));
			String applicationTimezone=EsapiUtil.stripXSSCharacters(RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone()));
			dateFormat.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
			toDate = dateFormat.format(new Date());
			
		} catch (Exception ex) {
			rmdWebLogger
			.error("RMDWebException occured in getHCLookup() method - HealthCheckController",
					ex);
	RMDWebErrorHandler.handleException(ex);

		}
		return toDate;
	}
	
	
}
