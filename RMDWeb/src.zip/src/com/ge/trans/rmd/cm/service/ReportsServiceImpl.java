package com.ge.trans.rmd.cm.service;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.codehaus.jackson.JsonGenerator.Feature;
import org.codehaus.jackson.JsonNode;
import org.codehaus.jackson.JsonParser;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.node.ArrayNode;
import org.codehaus.jackson.node.ObjectNode;
import org.codehaus.jettison.json.JSONException;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BoxAndWhiskerRenderer;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.statistics.DefaultBoxAndWhiskerCategoryDataset;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.valueobjects.ComStatusVO;
import com.ge.trans.rmd.common.valueobjects.MineVO;
import com.ge.trans.rmd.common.valueobjects.ReportsRxVO;
import com.ge.trans.rmd.common.valueobjects.ReportsTimeSeriesVO;
import com.ge.trans.rmd.common.valueobjects.ReportsTruckEventsVO;
import com.ge.trans.rmd.common.valueobjects.TruckGraphVO;
import com.ge.trans.rmd.common.valueobjects.TruckVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.services.assets.valueobjects.ListWrapperResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ReportsComStatusResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ReportsGraphRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.ReportsListWrapper;
import com.ge.trans.rmd.services.assets.valueobjects.ReportsMineResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ReportsRxRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.ReportsRxResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ReportsTimeSeriesResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ReportsTruckEventsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ReportsTruckGraphResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ReportsTruckInfoResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ReportsTruckParamListResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class ReportsServiceImpl extends RMDBaseServiceImpl implements ReportsService {
	
	@Autowired
	private WebServiceInvoker rsInvoker;
	@Autowired
	private CachedService cachedService;
	private final RMDWebLogger logger = RMDWebLogger.getLogger(getClass());	
	
	@Value("${OHV_IMAGES_PATH}")
	private String ohvImgUrl;
	
	//String ohvImgUrl = "C:/murali/workspace/OMD_new/.metadata/.plugins/org.jboss.ide.eclipse.as.core/JBoss_AS_5.11517980955870/deploy/RMDWeb.war/";
	/*
	 * (non-Javadoc)
	 * @see com.ge.trans.rmd.cm.service.ReportsService#getMine(java.lang.String)
	 */
	@Override
	public MineVO getMine(String customerId, HttpServletRequest request)
			throws GenericAjaxException, RMDWebException {
		MineVO mine = null;
		Map<String, String> queryParamMap = new HashMap<String, String>();
		try{
			queryParamMap.put(AppConstants.CUSTOMER_ID, customerId);
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
			final DateFormat dateFormater = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
			final String defaultTimezone = (String) request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
			String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone());
			dateFormater.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
			
			Date toDate = new Date();
			DateFormat formatter = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
			formatter.setTimeZone(TimeZone.getTimeZone(RMDCommonConstants.DateConstants.EST_US));
			String toDateStr = formatter.format(toDate);
			String toDateReportStr = dateFormater.format(toDate);
			
			Calendar cal = Calendar.getInstance();
			cal.setTime(toDate);
			cal.add(Calendar.DATE, -Integer.valueOf(AppConstants.REPORTS_NUM_DAYS));
			Date fromDate = cal.getTime();
			String fromDateStr = formatter.format(fromDate);
			String fromDateReportStr = dateFormater.format(fromDate);
			
			queryParamMap.put(AppConstants.REPORTS_FROM_DATE, fromDateStr);
			queryParamMap.put(AppConstants.REPORTS_TO_DATE, toDateStr);
			ReportsMineResponseType mineResponse = (ReportsMineResponseType) rsInvoker
					.get(ServiceConstants.GET_REPORTS_MINE, null,
							queryParamMap, null,
							ReportsMineResponseType.class);
			
			if (null != mineResponse) {
				mine = new MineVO();
				mine.setCommStatus(mineResponse.getCommStatus());
				mine.setHeader(mineResponse.getHeader());
				mine.setHealthReport(mineResponse.getHealthReport());
				mine.setMessageReceived(mineResponse.getMessageReceived());
				mine.setMine(mineResponse.getMine());
				mine.setMineStatus(mineResponse.getMineStatus());
				mine.setFromDate(fromDateReportStr);
				mine.setToDate(toDateReportStr);
				List<TruckVO> trucks = new ArrayList<TruckVO>();
				for(ReportsTruckInfoResponseType truckResp :mineResponse.getTrucks()){
					TruckVO truck = new TruckVO();
					truck.setActiveTime(truckResp.getActiveTime());
					truck.setControllerConfig(truckResp.getControllerConfig());
					truck.setCustomerModel(truckResp.getCustomerModel());
					truck.setFleet(truckResp.getFleet());
					truck.setGeModel(truckResp.getGeModel());
					truck.setHeader(truckResp.getHeader());
					truck.setLoads(truckResp.getLoads());
					truck.setManufacturer(truckResp.getManufacturer());
					truck.setMine(truckResp.getMine());
					truck.setOpenRx(truckResp.getOpenRx());
					truck.setSoftware(truckResp.getSoftware());
					truck.setTruck(truckResp.getTruck());
					truck.setUrgency(truckResp.getUrgency());
					trucks.add(truck);
				}
				mine.setTrucks(trucks);
				Map<String, ReportsListWrapper> params = mineResponse.getMineParams();
				Map<String, List<String>> reportsParams = new LinkedHashMap<String, List<String>>();
				Iterator it = params.entrySet().iterator();
			    while (it.hasNext()) {
			        Map.Entry<String, ReportsListWrapper> pair = (Map.Entry<String, ReportsListWrapper>)it.next();
			        ReportsListWrapper wrapperList = pair.getValue();
			        List<String> listValues = null;
			        if(wrapperList != null)
			        	listValues = wrapperList.getList();
			        reportsParams.put(pair.getKey(), listValues);
			        it.remove();
			    }
				mine.setMineParam(reportsParams);
			}
		} catch (RMDWebException e) {
			logger.error(
					"Exception occured in getMine in ReportsServiceImpl:",e);
			RMDWebErrorHandler.handleException(e);
		}
		return mine;
	}
	
	/*
	 * Added by Koushik for OHV Reports
	 * (non-Javadoc)
	 * @see com.ge.trans.rmd.cm.service.ReportsService#getRx(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public List<ReportsRxVO> getReportsRx(String mineId, String truckId, 
			String rxType, String urgency, String preferredTimezone) throws GenericAjaxException, RMDWebException {
		
		Date toDate = new Date();
		DateFormat formatter = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
		formatter.setTimeZone(TimeZone.getTimeZone(RMDCommonConstants.DateConstants.EST_US));
		String toDateStr = formatter.format(toDate);
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(toDate);
		cal.add(Calendar.DATE, -Integer.valueOf(AppConstants.REPORTS_NUM_DAYS));
		Date fromDate = cal.getTime();
		String fromDateStr = formatter.format(fromDate);
		
		ReportsRxRequestType reportsRxRequest = new ReportsRxRequestType(mineId, truckId, rxType, urgency, fromDateStr, toDateStr);
		ReportsRxResponseType[] reportsRxResponse = null;
		List<ReportsRxVO> reportsRxResponseList = new ArrayList<ReportsRxVO>();
		try {
			reportsRxResponse = (ReportsRxResponseType[])(rsInvoker.post(
					ServiceConstants.GET_REPORTS_RX, reportsRxRequest,
					ReportsRxResponseType[].class));
			SimpleDateFormat formatter1=new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
			if(preferredTimezone != null)
				formatter1.setTimeZone(TimeZone.getTimeZone(preferredTimezone));
			if (null != reportsRxResponse
                    && reportsRxResponse.length > 0) {				
				for(ReportsRxResponseType reportsRxResp : reportsRxResponse) {
					ReportsRxVO reportsRxRespVO = new ReportsRxVO();
					reportsRxRespVO.setRxObjid(reportsRxResp.getRxObjid());
					reportsRxRespVO.setRxTitle(reportsRxResp.getRxTitle());
					reportsRxRespVO.setUrgency(reportsRxResp.getUrgency());
					reportsRxRespVO.setTruckId(reportsRxResp.getTruckId());					
					if(reportsRxResp.getRxDeliverDate() != null) {
						GregorianCalendar deliverDate = reportsRxResp.getRxDeliverDate().toGregorianCalendar();
						String delDate = formatter1.format(deliverDate.getTime());
						if(preferredTimezone != null) {
							delDate = delDate+' '+preferredTimezone;
						}
						reportsRxRespVO.setRxDeliverDate(delDate);
						String timeZone = reportsRxResp.getTimezone();
						String openAge = RMDCommonUtil.calculateAge(deliverDate, new GregorianCalendar(), timeZone);
						reportsRxRespVO.setRxOpenTime(openAge);
					}					
										
					if(reportsRxResp.getRxClosedDate() != null) {
						GregorianCalendar closedDate = reportsRxResp.getRxClosedDate().toGregorianCalendar();
						String closeDate = formatter1.format(closedDate.getTime());
						if(preferredTimezone != null)
							closeDate = closeDate+' '+preferredTimezone;
						reportsRxRespVO.setRxClosedDate(closeDate);
					}
					reportsRxRespVO.setCaseId(reportsRxResp.getCaseId());
					reportsRxRespVO.setEstmRepairTime(reportsRxResp.getEstmRepairTime());
					reportsRxRespVO.setLocoImpact(reportsRxResp.getLocoImpact());
					reportsRxResponseList.add(reportsRxRespVO);
				}
			}
		} catch (RMDWebException e) {
			logger.error(
					"Exception occured in getReportsRx in ReportsServiceImpl:",e);
			RMDWebErrorHandler.handleException(e);
		}
		return reportsRxResponseList;
	}

	@Override
	/*
	 * (non-Javadoc)
	 * @see com.ge.trans.rmd.cm.service.ReportsService#getReportsTruckEvents(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public List<ReportsTruckEventsVO> getReportsTruckEvents(String mineId, String truckId, String preferredTimezone)
			throws GenericAjaxException, RMDWebException {
		
		Date toDate = new Date();
		DateFormat formatter = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
		formatter.setTimeZone(TimeZone.getTimeZone(RMDCommonConstants.DateConstants.GMT));
		String toDateStr = formatter.format(toDate);
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(toDate);
		cal.add(Calendar.DATE, -Integer.valueOf(AppConstants.REPORTS_NUM_DAYS));
		Date fromDate = cal.getTime();
		String fromDateStr = formatter.format(fromDate);
		
		ReportsRxRequestType reportsRxRequest = new ReportsRxRequestType(mineId, truckId, null, null, fromDateStr, toDateStr);
		ReportsTruckEventsResponseType[] reportsTruckEventsResponse = null;
		List<ReportsTruckEventsVO> reportsTruckEventsList = new ArrayList<ReportsTruckEventsVO>();
		try {
			reportsTruckEventsResponse = (ReportsTruckEventsResponseType[])(rsInvoker.post(
					ServiceConstants.GET_REPORTS_TRUCK_EVENTS, reportsRxRequest,
					ReportsTruckEventsResponseType[].class));
			DateFormat formatter1 = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
			if(null != reportsTruckEventsResponse && reportsTruckEventsResponse.length > 0) {				
				for(ReportsTruckEventsResponseType truckEventResponse : reportsTruckEventsResponse) {
					ReportsTruckEventsVO reportsTruckEventsVO = new ReportsTruckEventsVO();
					reportsTruckEventsVO.setSubId(truckEventResponse.getSubId());
					reportsTruckEventsVO.setEventNumber(truckEventResponse.getEventNumber());
					reportsTruckEventsVO.setDescription(truckEventResponse.getDescription());
					if(truckEventResponse.getOccurTime() != null) {
						String occuDateInTimezone = RMDCommonUtility.convertDateFormatAndTimezone(truckEventResponse.getOccurTime(), RMDCommonConstants.DateConstants.MMddyyyyHHmmss, RMDCommonConstants.DateConstants.MMddyyyyHHmmss, RMDCommonConstants.DateConstants.GMT, preferredTimezone);
						reportsTruckEventsVO.setOccurTime(occuDateInTimezone);
					}
					
					if(truckEventResponse.getResetTime() != null) {
						String resetTimeInTimezone = RMDCommonUtility.convertDateFormatAndTimezone(truckEventResponse.getResetTime(), RMDCommonConstants.DateConstants.MMddyyyyHHmmss, RMDCommonConstants.DateConstants.MMddyyyyHHmmss, RMDCommonConstants.DateConstants.GMT, preferredTimezone);
						reportsTruckEventsVO.setResetTime(resetTimeInTimezone);
					}
					reportsTruckEventsList.add(reportsTruckEventsVO);
				}
			}
		} catch (RMDWebException e) {
			logger.error(
					"Exception occured in getReportsTruckEvents in ReportsServiceImpl:",e);
			RMDWebErrorHandler.handleException(e);
		} catch (Exception e) {
			logger.error(
					"General exception occured in getReportsTruckEvents in ReportsServiceImpl:",e);
			RMDWebErrorHandler.handleException(e);
		}
		return reportsTruckEventsList;
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.ge.trans.rmd.cm.service.ReportsService#getTruckInfo(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public TruckVO getTruckInfo(String mineId, String truckId, HttpServletRequest request)
			throws GenericAjaxException, RMDWebException {
		TruckVO truckInfo = new TruckVO();
		final HttpSession session = request.getSession(false);

		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final DateFormat dateFormater = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
		final String defaultTimezone = (String) request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone());
		dateFormater.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
		
		
		Date toDate = new Date();
		DateFormat formatter = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
		formatter.setTimeZone(TimeZone.getTimeZone(RMDCommonConstants.DateConstants.EST_US));
		String toDateStr = formatter.format(toDate);
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(toDate);
		cal.add(Calendar.DATE, -Integer.valueOf(AppConstants.REPORTS_NUM_DAYS));
		Date fromDate = cal.getTime();
		String fromDateStr = formatter.format(fromDate);
		String fromDateReportStr = dateFormater.format(fromDate);
		String toDateReportStr = dateFormater.format(toDate);
		
		
		ReportsRxRequestType reportsRequest = new ReportsRxRequestType(mineId, truckId, null, null, fromDateStr, toDateStr);
		try{
			ReportsTruckInfoResponseType truckInfoResponse = (ReportsTruckInfoResponseType)(rsInvoker.post(
					ServiceConstants.GET_REPORTS_TRUCK_INFO, reportsRequest,
					ReportsTruckInfoResponseType.class));
			if(null != truckInfoResponse) {
				truckInfo.setMine(truckInfoResponse.getMine());
				truckInfo.setTruck(truckInfoResponse.getTruck());
				truckInfo.setFleet(truckInfoResponse.getFleet());
				truckInfo.setHeader(truckInfoResponse.getHeader());
				truckInfo.setCustomerModel(truckInfoResponse.getCustomerModel());
				truckInfo.setGeModel(truckInfoResponse.getGeModel());
				truckInfo.setControllerConfig(truckInfoResponse.getControllerConfig());
				truckInfo.setSoftware(truckInfoResponse.getSoftware());
				truckInfo.setFromDate(fromDateReportStr);
				truckInfo.setToDate(toDateReportStr);
			}
		} catch (RMDWebException e) {
			logger.error("Exception occured in getTruckInfo in ReportsServiceImpl:",e);
			RMDWebErrorHandler.handleException(e);
		}
		return truckInfo;
	}
	
	/*
	 * (non-Javadoc)
	 * @see com.ge.trans.rmd.cm.service.ReportsService#getComStatus(java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public ComStatusVO getComStatus(String mineId, String truckId)
			throws GenericAjaxException, RMDWebException {
		ComStatusVO comStatus = new ComStatusVO();
		Date toDate = new Date();
		DateFormat formatter = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
		formatter.setTimeZone(TimeZone.getTimeZone(RMDCommonConstants.DateConstants.EST_US));
		String toDateStr = formatter.format(toDate);
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(toDate);
		cal.add(Calendar.DATE, -Integer.valueOf(AppConstants.REPORTS_NUM_DAYS));
		Date fromDate = cal.getTime();
		String fromDateStr = formatter.format(fromDate);
		
		ReportsRxRequestType reportsRequest = new ReportsRxRequestType(mineId, truckId, null, null, fromDateStr, toDateStr);
		try{
			ReportsComStatusResponseType comStatusResponse = (ReportsComStatusResponseType)(rsInvoker.post(
					ServiceConstants.GET_REPORTS_COM_STATUS, reportsRequest,
					ReportsComStatusResponseType.class));
			if(null != comStatusResponse) {
				comStatus.setEoaEquip(comStatusResponse.getEoaEquip());
				comStatus.setHealthReports(comStatusResponse.getHealthReports());
				comStatus.setMessageReceived(comStatusResponse.getMessageReceived());
			}
		} catch (RMDWebException e) {
			logger.error("Exception occured in getComStatus in ReportsServiceImpl:",e);
			RMDWebErrorHandler.handleException(e);
		}
		return comStatus;
	}

	/*
	 * (non-Javadoc)
	 * @see com.ge.trans.rmd.cm.service.ReportsService#getTopMineEvents(java.lang.String)
	 */
	@Override
	public List<ReportsTruckEventsVO> getTopMineEvents(String mineId , boolean geLevelReport)
			throws RMDWebException {
		Date toDate = new Date();
		DateFormat formatter = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
		formatter.setTimeZone(TimeZone.getTimeZone(RMDCommonConstants.DateConstants.EST_US));
		String toDateStr = formatter.format(toDate);
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(toDate);
		cal.add(Calendar.DATE, -Integer.valueOf(AppConstants.REPORTS_NUM_DAYS));
		Date fromDate = cal.getTime();
		String fromDateStr = formatter.format(fromDate);
		
		ReportsRxRequestType reportsRxRequest = new ReportsRxRequestType(mineId, geLevelReport, null , null, fromDateStr, toDateStr);
		ReportsTruckEventsResponseType[] reportsTruckEventsResponse = null;
		List<ReportsTruckEventsVO> reportsTruckEventsList = new ArrayList<ReportsTruckEventsVO>();
		try {
			reportsTruckEventsResponse = (ReportsTruckEventsResponseType[])(rsInvoker.post(
					ServiceConstants.GET_REPORTS_TOP_EVENTS, reportsRxRequest,
					ReportsTruckEventsResponseType[].class));
			if(null != reportsTruckEventsResponse && reportsTruckEventsResponse.length > 0) {
				for(ReportsTruckEventsResponseType truckEventResponse : reportsTruckEventsResponse) {
					ReportsTruckEventsVO reportsTruckEventsVO = new ReportsTruckEventsVO();
					reportsTruckEventsVO.setSubId(truckEventResponse.getSubId());
					reportsTruckEventsVO.setEventNumber(truckEventResponse.getEventNumber());
					reportsTruckEventsVO.setDescription(truckEventResponse.getDescription());
					reportsTruckEventsVO.setNumberOfOccurance(truckEventResponse.getNumberOfOccurance());
					reportsTruckEventsVO.setTrucksPerDay(truckEventResponse.getTrucksPerDay());
					reportsTruckEventsList.add(reportsTruckEventsVO);
				}
			}
		} catch (RMDWebException e) {
			logger.error(
					"Exception occured in getTopMineEvents in ReportsServiceImpl:",e);
			RMDWebErrorHandler.handleException(e);
		}
		return reportsTruckEventsList;
	}

	@Override
	public TruckGraphVO getTruckGraphData(String mineId, String truckId, int period, String preferredTimezone)
			throws RMDWebException {
		TruckGraphVO graphValues = new TruckGraphVO();
		ReportsGraphRequestType reportsRequest = new ReportsGraphRequestType(mineId, truckId, period);
		
		try {
			ReportsTruckGraphResponseType response = (ReportsTruckGraphResponseType)(rsInvoker.post(
					ServiceConstants.GET_REPORTS_TRUCK_GRAPH_DATA, reportsRequest,
					ReportsTruckGraphResponseType.class));
			if(response != null){
				SimpleDateFormat formatter1=new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
				if(preferredTimezone != null)
					formatter1.setTimeZone(TimeZone.getTimeZone(preferredTimezone));
				List<ReportsTimeSeriesResponseType> loadsReponse = response.getLoads();
				List<ReportsTimeSeriesVO> loads = new ArrayList<ReportsTimeSeriesVO>();
				if(loadsReponse != null) {
					for(ReportsTimeSeriesResponseType load: loadsReponse){
						ReportsTimeSeriesVO timeSeriesValue = new ReportsTimeSeriesVO();
						String timestamp = load.getTimestamp();
						if(timestamp != null)
							timestamp = formatter1.format(formatter1.parse(timestamp));
						timeSeriesValue.setTimestamp(timestamp);
						timeSeriesValue.setValue(load.getValue());
						loads.add(timeSeriesValue);
					}
				}
				graphValues.setLoads(loads);
				
				List<ReportsTimeSeriesResponseType> engineOpHrsReponse = response.getEngineOpHrs();
				List<ReportsTimeSeriesVO> engineOpHrs = new ArrayList<ReportsTimeSeriesVO>();
				if(engineOpHrsReponse != null) {
					for(ReportsTimeSeriesResponseType engineOpHr: engineOpHrsReponse){
						ReportsTimeSeriesVO timeSeriesValue = new ReportsTimeSeriesVO();
						String timestamp = engineOpHr.getTimestamp();
						if(timestamp != null)
							timestamp = formatter1.format(formatter1.parse(timestamp));
						timeSeriesValue.setTimestamp(timestamp);
						timeSeriesValue.setValue(engineOpHr.getValue());
						engineOpHrs.add(timeSeriesValue);
					}
				}
				graphValues.setEngineOpHrs(engineOpHrs);
				
				List<ReportsTimeSeriesResponseType> engineIdleReponse = response.getEngineIdleTime();
				List<ReportsTimeSeriesVO> engineIdleHrs = new ArrayList<ReportsTimeSeriesVO>();
				if(engineIdleReponse != null) {
					for(ReportsTimeSeriesResponseType engineIdle: engineIdleReponse){
						ReportsTimeSeriesVO timeSeriesValue = new ReportsTimeSeriesVO();
						String timestamp = engineIdle.getTimestamp();
						if(timestamp != null)
							timestamp = formatter1.format(formatter1.parse(timestamp));
						timeSeriesValue.setTimestamp(timestamp);
						timeSeriesValue.setValue(engineIdle.getValue());
						engineIdleHrs.add(timeSeriesValue);
					}
				}
				graphValues.setEngineIdleTime(engineIdleHrs);
				
				List<ReportsTimeSeriesResponseType> overloadsReponse = response.getOverloads();
				List<ReportsTimeSeriesVO> overloads = new ArrayList<ReportsTimeSeriesVO>();
				if(overloadsReponse != null) {
					for(ReportsTimeSeriesResponseType overload: overloadsReponse){
						ReportsTimeSeriesVO timeSeriesValue = new ReportsTimeSeriesVO();
						String timestamp = overload.getTimestamp();
						if(timestamp != null)
							timestamp = formatter1.format(formatter1.parse(timestamp));
						timeSeriesValue.setTimestamp(timestamp);
						timeSeriesValue.setValue(overload.getValue());
						overloads.add(timeSeriesValue);
					}
				}
				graphValues.setOverloads(overloads);
				
				List<ReportsTimeSeriesResponseType> avgHPReponse = response.getAverageHP();
				List<ReportsTimeSeriesVO> avgHPVals = new ArrayList<ReportsTimeSeriesVO>();
				if(avgHPReponse != null) {
					for(ReportsTimeSeriesResponseType avgHP: avgHPReponse){
						ReportsTimeSeriesVO timeSeriesValue = new ReportsTimeSeriesVO();
						String timestamp = avgHP.getTimestamp();
						if(timestamp != null)
							timestamp = formatter1.format(formatter1.parse(timestamp));
						timeSeriesValue.setTimestamp(timestamp);
						timeSeriesValue.setValue(avgHP.getValue());
						avgHPVals.add(timeSeriesValue);
					}
				}
				graphValues.setAverageHP(avgHPVals);
			}
		} catch (RMDWebException e) {
			logger.error(
					"Exception occured in getTopMineEvents in ReportsServiceImpl:",e);
			RMDWebErrorHandler.handleException(e);
		} catch (Exception e){
			logger.error(
					"General Exception occured in getTopMineEvents in ReportsServiceImpl:",e);
		}
		return graphValues;
	}
	
	/*
     * (non-Javadoc)
     * @see com.ge.trans.rmd.cm.service.ReportsService#getTruckVariablesParam( java.lang.String, java.lang.String)
     */
	@Override
     public List<String> getTruckVariablesParam(String mineId, String truckId, String fromDate, String toDate, boolean isAvgCalc)
                   throws GenericAjaxException, RMDWebException {
            List<String> truckParam = new ArrayList();
            ReportsRxRequestType reportsRequest = new ReportsRxRequestType( mineId, truckId, null, fromDate, toDate, isAvgCalc );
            try{
            	ListWrapperResponseType truckParamArr = (ListWrapperResponseType) rsInvoker.post(
                                ServiceConstants.GET_REPORTS_TRUCK_PARAM, reportsRequest,
                                ListWrapperResponseType.class);
            	
            	if(truckParamArr != null){
            		for(String param :truckParamArr.getElements()){
            			truckParam.add(param);
            		}
            	}
            } catch (RMDWebException e) {
                   logger.error(
                                "Exception occured in getTruckInfo in ReportsServiceImpl:",e);
                   RMDWebErrorHandler.handleException(e);
            }
            return truckParam;
     }
	
	
	@Override
    public Map<String, List<String>> getTruckVariablesParamList(String mineId, String truckId, boolean isAvgCalc) 
    		throws GenericAjaxException, RMDWebException {
		   Map<String, List<String>> truckVariableParams = null;
           try{
        	   truckVariableParams = new LinkedHashMap<String, List<String>>(
   					cachedService.getTruckVariablesParamList(mineId, truckId, isAvgCalc));
           } catch (RMDWebException e) {
                  logger.error(
                               "Exception occured in getTruckInfo in ReportsServiceImpl:",e);
                  RMDWebErrorHandler.handleException(e);
           }
           return truckVariableParams;
    }
	
	/*
     * (non-Javadoc)
     * @see com.ge.trans.rmd.cm.service.ReportsService#getTruckVariablesParam( java.lang.String, java.lang.String)
     */
	@Override
	public Map<String, List<String>> getTruckVariablesParamListScheduler(String mineId, String truckId, boolean isAvgCalc)
			throws GenericAjaxException, RMDWebException {
		ReportsRxRequestType reportsRequest = new ReportsRxRequestType( mineId, truckId, null, null, null, isAvgCalc );
		Map<String, List<String>> truckVariableParams = new HashMap<String, List<String>>();
		try {
			ReportsTruckParamListResponseType truckParamList = (ReportsTruckParamListResponseType) rsInvoker.post(
					ServiceConstants.GET_REPORTS_TRUCK_PARAM_LIST_SCHEDULER, reportsRequest,
					ReportsTruckParamListResponseType.class);

			if(truckParamList != null){
				Map<String, ReportsListWrapper> params = truckParamList.getTruckParamsList();
				for (Map.Entry<String, ReportsListWrapper> pair : params.entrySet()) {
					ReportsListWrapper wrapperList = pair.getValue();
					List<String> listValues = null;
					if(wrapperList != null){
						listValues = wrapperList.getList();
					}
					truckVariableParams.put(pair.getKey(), listValues);
				}
			}
		} catch (RMDWebException e) {
			logger.error(
					"Exception occured in getTruckInfo in ReportsServiceImpl:",e);
			RMDWebErrorHandler.handleException(e);
		}
		return truckVariableParams;
	}

	@Override
	public PDDocument getMinePdfDocument(PDDocument document, String jsonStr) throws GenericAjaxException, RMDWebException, IOException, JSONException {
		logger.info("getMinePdfDocument method start");
		// TODO Auto-generated method stub
		try{
			float h;
		//String fullPath = ohvImgUrl;
		//String fullPath = "C:/murali/workspace/OMD_new/.metadata/.plugins/org.jboss.ide.eclipse.as.core/JBoss_AS_5.11517980955870/deploy/RMDWeb.war/";
		//String mineStr = "{'mine':'Suncor Energy Inc.','header':'M084','messageReceived':'','mineStatus':'R','commStatus':'R','healthReport':'0','fromDate':'03/15/2018 05:38:31','trucks':[{'truck':'323','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'323','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'323','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'323','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'323','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'323','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'323','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'323','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'323','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'324','customerModel':'','loads':'','activeTime':'','openRx':'1','urgency':'B'},{'truck':'325','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'}],'eventsReport':[{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' }],'openRx':[]}";
	//	String mineStr1 = "{'mine':'Suncor Energy Inc.','header':'M084','messageReceived':'0','mineStatus':'Y','commStatus':'R','healthReport':'0','fromDate':'05/03/2018 03:24:11','trucks':[{'truck':'302','customerModel':'','loads':'','activeTime':'','openRx':'1','urgency':'B'},{'truck':'303','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'304','customerModel':'','loads':'','activeTime':'','openRx':'3','urgency':'Y'},{'truck':'305','customerModel':'','loads':'0','activeTime':'0.57','openRx':'0','urgency':'B'},{'truck':'306','customerModel':'','loads':'-3','activeTime':'-1.03','openRx':'1','urgency':'B'},{'truck':'307','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'308','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'309','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'310','customerModel':'','loads':'12','activeTime':'8.89','openRx':'0','urgency':'B'},{'truck':'311','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'312','customerModel':'','loads':'19','activeTime':'10.26','openRx':'0','urgency':'B'},{'truck':'313','customerModel':'980E','loads':'16','activeTime':'8.68','openRx':'0','urgency':'B'},{'truck':'314','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'315','customerModel':'','loads':'','activeTime':'','openRx':'1','urgency':'Y'},{'truck':'316','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'317','customerModel':'980E','loads':'45','activeTime':'25.75','openRx':'0','urgency':'B'},{'truck':'318','customerModel':'980E','loads':'49','activeTime':'28.54','openRx':'0','urgency':'B'},{'truck':'319','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'320','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'321','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'322','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'323','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'324','customerModel':'','loads':'','activeTime':'','openRx':'1','urgency':'B'},{'truck':'325','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'}],'boxPlot':[{'key':'Blue Status Trucks','value':[1,1]},{'key':'RXs Closed','value':[1,1,2,2,3,3,3,3,3,4,5,5,6,8,8,16]},{'key':'Red Status Trucks','value':[1,1]},{'key':'Average HP','value':[333.66,711.05,755.38,808.52,811.21,995.82,1096.65]},{'key':'Truck Parked','value':[-0.24,1.3,1.57,3.01,3.03,12.08,13.77]},{'key':'Engine Operating Hrs','value':[-1.53,2.11,12.5,13.64,15.3,43.89,48.43]},{'key':'Engine Idle Time','value':[-0.41,1.47,3.14,3.57,3.87,14.76,16.73]},{'key':'Yellow Status Trucks','value':[1,3,1,1]},{'key':'RXs Open','value':[1,1,1,1,1,1,1,3]},{'key':'Loads','value':[-3,0,12,16,19,45,49]}],'eventsReport':[{'description':'Diagnostic Event - Truck at Full Horsepower for 20 secs in Propel','eventNumber':'770','subId':'1','occurTime':null,'resetTime':null,'numberOfOccurance':'51','trucksPerDay':'6'},{'description':'Diagnostic Event - Engine Speed Overshoot','eventNumber':'770','subId':'3','occurTime':null,'resetTime':null,'numberOfOccurance':'50','trucksPerDay':'6'},{'description':'Diagnostic Event - Truck At Full Horspower in Retard','eventNumber':'770','subId':'2','occurTime':null,'resetTime':null,'numberOfOccurance':'30','trucksPerDay':'6'},{'description':'Service Brake applied higher than preset truck speed','eventNumber':'647','subId':'1','occurTime':null,'resetTime':null,'numberOfOccurance':'27','trucksPerDay':'6'},{'description':'Torque Delta Alert - Large Torque Swing Detected','eventNumber':'596','subId':'1','occurTime':null,'resetTime':null,'numberOfOccurance':'12','trucksPerDay':'4'}],'openRx':[{'rxClosedDate':null,'rxTitle':'testing again subsystem','urgency':'R','caseId':'S217842','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(52d 7hrs 48min)'},{'rxClosedDate':null,'rxTitle':'Engine CAN Network loss','urgency':'R','caseId':'T000543','rxObjid':'T000543-01','rxDeliverDate':'03/08/2018 12:42:11 GMT','estmRepairTime':'2','truckId':'301','locoImpact':'Mining - Speed Limit Low (Speed limit 5 MPH)','rxOpenTime':'(56d 14hrs 43min)'},{'rxClosedDate':null,'rxTitle':'Battery Boost Circuit Fail_Link V','urgency':'Y','caseId':'T002494','rxObjid':'T002494','rxDeliverDate':'03/08/2018 12:41:29 GMT','estmRepairTime':'1','truckId':'302','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(56d 14hrs 43min)'},{'rxClosedDate':null,'rxTitle':'Too Many non power up Boots  Multiple 654 Events','urgency':'W','caseId':'T002760','rxObjid':'T002760','rxDeliverDate':'03/15/2018 16:30:43 GMT','estmRepairTime':'2','truckId':'304','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(49d 10hrs 54min)'},{'rxClosedDate':null,'rxTitle':'Too Many non power up Boots  Multiple 654 Events','urgency':'W','caseId':'T002760','rxObjid':'T002760','rxDeliverDate':'03/15/2018 16:29:25 GMT','estmRepairTime':'2','truckId':'304','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(49d 10hrs 55min)'},{'rxClosedDate':null,'rxTitle':'Too Many non power up Boots  Multiple 654 Events','urgency':'W','caseId':'T002760','rxObjid':'T002760','rxDeliverDate':'03/15/2018 16:30:09 GMT','estmRepairTime':'2','truckId':'304','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(49d 10hrs 55min)'},{'rxClosedDate':null,'rxTitle':'Cell Modem Deactivation','urgency':'B','caseId':'T004984','rxObjid':'T004984','rxDeliverDate':'05/02/2018 13:32:13 GMT','estmRepairTime':'3','truckId':'306','locoImpact':'Lococomm: No Service Impact','rxOpenTime':'(1d 13hrs 53min)'},{'rxClosedDate':null,'rxTitle':'Conditional Warning, Unable Maintain Air Pressure','urgency':'W','caseId':'T000871','rxObjid':'T000871-01','rxDeliverDate':'03/15/2018 09:59:34 GMT','estmRepairTime':'3','truckId':'315','locoImpact':'Unit requires inspection','rxOpenTime':'(49d 17hrs 25min)'},{'rxClosedDate':null,'rxTitle':'Truck overloaded and speed limited','urgency':'Y','caseId':'T002636','rxObjid':'T002636','rxDeliverDate':'03/12/2018 19:40:10 GMT','estmRepairTime':'2','truckId':'324','locoImpact':'Mining - Speed Limit Low (Speed limit 5 MPH)','rxOpenTime':'(52d 7hrs 45min)'},{'rxClosedDate':null,'rxTitle':'Inverter 1 Phase B Pos and Neg IGBTs On (P11B- Turn ON) (OHV)','urgency':'B','caseId':'T002484','rxObjid':'T002484','rxDeliverDate':'03/07/2018 19:14:04 GMT','estmRepairTime':'3','truckId':'291','locoImpact':'Will not load','rxOpenTime':'(57d 8hrs 11min)'},{'rxClosedDate':null,'rxTitle':'testing again subsystem','urgency':'R','caseId':'S217842','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(52d 7hrs 48min)'},{'rxClosedDate':null,'rxTitle':'Engine CAN Network loss','urgency':'R','caseId':'T000543','rxObjid':'T000543-01','rxDeliverDate':'03/08/2018 12:42:11 GMT','estmRepairTime':'2','truckId':'301','locoImpact':'Mining - Speed Limit Low (Speed limit 5 MPH)','rxOpenTime':'(56d 14hrs 43min)'},{'rxClosedDate':null,'rxTitle':'Battery Boost Circuit Fail_Link V','urgency':'Y','caseId':'T002494','rxObjid':'T002494','rxDeliverDate':'03/08/2018 12:41:29 GMT','estmRepairTime':'1','truckId':'302','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(56d 14hrs 43min)'},{'rxClosedDate':null,'rxTitle':'Too Many non power up Boots  Multiple 654 Events','urgency':'W','caseId':'T002760','rxObjid':'T002760','rxDeliverDate':'03/15/2018 16:30:43 GMT','estmRepairTime':'2','truckId':'304','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(49d 10hrs 54min)'},{'rxClosedDate':null,'rxTitle':'Too Many non power up Boots  Multiple 654 Events','urgency':'W','caseId':'T002760','rxObjid':'T002760','rxDeliverDate':'03/15/2018 16:29:25 GMT','estmRepairTime':'2','truckId':'304','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(49d 10hrs 55min)'},{'rxClosedDate':null,'rxTitle':'Too Many non power up Boots  Multiple 654 Events','urgency':'W','caseId':'T002760','rxObjid':'T002760','rxDeliverDate':'03/15/2018 16:30:09 GMT','estmRepairTime':'2','truckId':'304','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(49d 10hrs 55min)'},{'rxClosedDate':null,'rxTitle':'Cell Modem Deactivation','urgency':'B','caseId':'T004984','rxObjid':'T004984','rxDeliverDate':'05/02/2018 13:32:13 GMT','estmRepairTime':'3','truckId':'306','locoImpact':'Lococomm: No Service Impact','rxOpenTime':'(1d 13hrs 53min)'},{'rxClosedDate':null,'rxTitle':'Conditional Warning, Unable Maintain Air Pressure','urgency':'W','caseId':'T000871','rxObjid':'T000871-01','rxDeliverDate':'03/15/2018 09:59:34 GMT','estmRepairTime':'3','truckId':'315','locoImpact':'Unit requires inspection','rxOpenTime':'(49d 17hrs 25min)'},{'rxClosedDate':null,'rxTitle':'Truck overloaded and speed limited','urgency':'Y','caseId':'T002636','rxObjid':'T002636','rxDeliverDate':'03/12/2018 19:40:10 GMT','estmRepairTime':'2','truckId':'324','locoImpact':'Mining - Speed Limit Low (Speed limit 5 MPH)','rxOpenTime':'(52d 7hrs 45min)'},{'rxClosedDate':null,'rxTitle':'Inverter 1 Phase B Pos and Neg IGBTs On (P11B- Turn ON) (OHV)','urgency':'B','caseId':'T002484','rxObjid':'T002484','rxDeliverDate':'03/07/2018 19:14:04 GMT','estmRepairTime':'3','truckId':'291','locoImpact':'Will not load','rxOpenTime':'(57d 8hrs 11min)'},{'rxClosedDate':null,'rxTitle':'Inverter 1 Phase B Pos and Neg IGBTs On (P11B- Turn ON) (OHV)','urgency':'B','caseId':'T002484','rxObjid':'T002484','rxDeliverDate':'03/07/2018 19:14:04 GMT','estmRepairTime':'3','truckId':'291','locoImpact':'Will not load','rxOpenTime':'(57d 8hrs 11min)'},{'rxClosedDate':null,'rxTitle':'Inverter 1 Phase B Pos and Neg IGBTs On (P11B- Turn ON) (OHV)','urgency':'B','caseId':'T002484','rxObjid':'T002484','rxDeliverDate':'03/07/2018 19:14:04 GMT','estmRepairTime':'3','truckId':'291','locoImpact':'Will not load','rxOpenTime':'(57d 8hrs 11min)'}]}";
	//	String mineStr2 = "{'mine':'Suncor Energy Inc.','header':'M084','messageReceived':'0','mineStatus':'Y','commStatus':'R','healthReport':'0','fromDate':'05/06/2018 09:53:56','trucks':[{'truck':'291','customerModel':'980','loads':'','activeTime':'','openRx':'1','urgency':'B'},{'truck':'300','customerModel':'980E4','loads':'','activeTime':'','openRx':'1','urgency':'R'},{'truck':'301','customerModel':'980E4','loads':'','activeTime':'','openRx':'1','urgency':'R'},{'truck':'302','customerModel':'','loads':'','activeTime':'','openRx':'1','urgency':'B'},{'truck':'303','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'304','customerModel':'','loads':'','activeTime':'','openRx':'3','urgency':'Y'},{'truck':'305','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'306','customerModel':'','loads':'','activeTime':'','openRx':'1','urgency':'B'},{'truck':'307','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'308','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'309','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'310','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'311','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'312','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'313','customerModel':'980E','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'314','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'315','customerModel':'','loads':'','activeTime':'','openRx':'1','urgency':'Y'},{'truck':'316','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'317','customerModel':'980E','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'318','customerModel':'980E','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'319','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'320','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'321','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'322','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'323','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'},{'truck':'324','customerModel':'','loads':'','activeTime':'','openRx':'1','urgency':'B'},{'truck':'325','customerModel':'','loads':'','activeTime':'','openRx':'0','urgency':'B'}],'boxPlot':[{'key':'Loads','value':[]},{'key':'Engine Idle Time','value':[]},{'key':'Engine Operating Hrs','value':[]},{'key':'Average HP','value':[]},{'key':'Truck Parked','value':[]},{'key':'RXs Open','value':[1,1,1,1,1,1,1,3]},{'key':'RXs Closed','value':[1,1,2,2,3,3,3,3,3,4,5,5,6,8,8,16]},{'key':'Red Status Trucks','value':[1,1]},{'key':'Yellow Status Trucks','value':[1,3,1,1]},{'key':'Blue Status Trucks','value':[1,1]},{'key':'Rx Closure Time','value':[0.01,0.01,0.01,0.04,0.04,0.04,0.05,0.07,0.07,0.08,0.08,0.09,0.13,0.16,0.18,0.25,0.25,0.26,0.27,0.29,0.33,1.91,2.19,18.11,18.37,23.89,23.9,24.6,63.29,95.93,95.94,95.96,96.25,96.27,96.29,124.33,207.55,214.44,214.47,214.48,214.57,214.59,214.6,308.51,309.54,359.01,365.51,365.53,366.8,366.87,367.76,368.25,368.26,368.32,539.88,789.51,1028.7,1177.2,1270.2,1282.54,1282.78,1282.91,1283.29,1305.61,1305.68,1305.69,1626.02,1626.04,1626.05,2402.66,2676.1,3648.59,3961.19]}],'eventsReport':[],'openRx':[{'rxClosedDate':null,'rxTitle':'testing again subsystem','urgency':'R','caseId':'S217842','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(55d 14hrs 17min)'},{'rxClosedDate':null,'rxTitle':'Engine CAN Network loss','urgency':'R','caseId':'T000543','rxObjid':'T000543-01','rxDeliverDate':'03/08/2018 12:42:11 GMT','estmRepairTime':'2','truckId':'301','locoImpact':'Mining - Speed Limit Low (Speed limit 5 MPH)','rxOpenTime':'(59d 21hrs 12min)'},{'rxClosedDate':null,'rxTitle':'Battery Boost Circuit Fail_Link V','urgency':'Y','caseId':'T002494','rxObjid':'T002494','rxDeliverDate':'03/08/2018 12:41:29 GMT','estmRepairTime':'1','truckId':'302','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(59d 21hrs 13min)'},{'rxClosedDate':null,'rxTitle':'Too Many non power up Boots  Multiple 654 Events','urgency':'W','caseId':'T002760','rxObjid':'T002760','rxDeliverDate':'03/15/2018 16:30:43 GMT','estmRepairTime':'2','truckId':'304','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(52d 17hrs 24min)'},{'rxClosedDate':null,'rxTitle':'Too Many non power up Boots  Multiple 654 Events','urgency':'W','caseId':'T002760','rxObjid':'T002760','rxDeliverDate':'03/15/2018 16:29:25 GMT','estmRepairTime':'2','truckId':'304','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(52d 17hrs 25min)'},{'rxClosedDate':null,'rxTitle':'Too Many non power up Boots  Multiple 654 Events','urgency':'W','caseId':'T002760','rxObjid':'T002760','rxDeliverDate':'03/15/2018 16:30:09 GMT','estmRepairTime':'2','truckId':'304','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(52d 17hrs 24min)'},{'rxClosedDate':null,'rxTitle':'Cell Modem Deactivation','urgency':'B','caseId':'T004984','rxObjid':'T004984','rxDeliverDate':'05/02/2018 13:32:13 GMT','estmRepairTime':'3','truckId':'306','locoImpact':'Lococomm: No Service Impact','rxOpenTime':'(4d 20hrs 22min)'},{'rxClosedDate':null,'rxTitle':'Conditional Warning, Unable Maintain Air Pressure','urgency':'W','caseId':'T000871','rxObjid':'T000871-01','rxDeliverDate':'03/15/2018 09:59:34 GMT','estmRepairTime':'3','truckId':'315','locoImpact':'Unit requires inspection','rxOpenTime':'(52d 23hrs 55min)'},{'rxClosedDate':null,'rxTitle':'Truck overloaded and speed limited','urgency':'Y','caseId':'T002636','rxObjid':'T002636','rxDeliverDate':'03/12/2018 19:40:10 GMT','estmRepairTime':'2','truckId':'324','locoImpact':'Mining - Speed Limit Low (Speed limit 5 MPH)','rxOpenTime':'(55d 14hrs 14min)'},{'rxClosedDate':null,'rxTitle':'Inverter 1 Phase B Pos and Neg IGBTs On (P11B- Turn ON) (OHV)','urgency':'B','caseId':'T002484','rxObjid':'T002484','rxDeliverDate':'03/07/2018 19:14:04 GMT','estmRepairTime':'3','truckId':'291','locoImpact':'Will not load','rxOpenTime':'(60d 14hrs 40min)'}],'rxType':'All'}";
		JsonNode mineVO = readJsonfile(jsonStr);
		String fromDate = mineVO.get(AppConstants.FROM_DATE).getTextValue()+"";
		PDPage page = new PDPage();
		PDPageContentStream contentStream = new PDPageContentStream(document, page);
		contentStream = addHeader(contentStream, document, fromDate,AppConstants.MINE_SMALL);
		contentStream = addTitle(contentStream,AppConstants.MINE_SMALL);
		contentStream = createRect(contentStream, document, mineVO);
		Map<String, Object> map = createOpenRXTable(contentStream,document, page, mineVO,fromDate);
		contentStream = (PDPageContentStream) map.get(AppConstants.CONTENT_STREAM);
		 h = (Float) map.get(AppConstants.PAGE_HEIGHT);
		page = (PDPage) map.get(AppConstants.PD_PAGE);
		//document = (PDDocument) map.get(AppConstants.PD_DOCUMENT);
		Map<String, Object> truckMap = TruckTable(contentStream, document, page, mineVO, h);
		document = (PDDocument) truckMap.get(AppConstants.PD_DOCUMENT);
		page = (PDPage) truckMap.get(AppConstants.PD_PAGE);
		h = (Float) truckMap.get(AppConstants.PAGE_HEIGHT);
		contentStream = (PDPageContentStream) truckMap.get(AppConstants.CONTENT_STREAM);
		map = plotGraph(contentStream, document, page, mineVO, h,fromDate);
		page = (PDPage) map.get(AppConstants.PD_PAGE);
		document = (PDDocument) map.get(AppConstants.PD_DOCUMENT);
		contentStream = (PDPageContentStream) map.get(AppConstants.CONTENT_STREAM);
		document.addPage(page);
		contentStream.close();
		}catch (IOException e) {
		            logger.error(
		                    "Exception occured in getMinePdfDocument in ReportsServiceImpl:",e);
		       RMDWebErrorHandler.handleException(e);
		}
		catch (Exception e) {
		            logger.error(
		                    "Exception occured in getMinePdfDocument in ReportsServiceImpl:",e);
		       RMDWebErrorHandler.handleException(e);
		}
		logger.info("getMinePdfDocument method end");
		return document;
	}

	private Map<String, Object> plotGraph(PDPageContentStream contentStream, PDDocument document, PDPage page, JsonNode mineVO, float h,
			String fromDate) throws IOException, GenericAjaxException, RMDWebException {
		// TODO Auto-generated method stub
		Map<String, Object> map = new HashMap<String, Object>();
		JsonNode plotVOs= mineVO.get("boxPlotList");
		float x = 60;
		float y = h-250;
		if(h<360 && plotVOs.size()>0){
			String imagePath = ohvImgUrl + AppConstants.GPOC_LOGO;
			File gpoc_logo = new File(imagePath);
			 PDImageXObject gpoc = PDImageXObject.createFromFileByContent(gpoc_logo, document);
			 contentStream.close();
			 document.addPage(page);
             page = new PDPage();
			  contentStream = new PDPageContentStream(document, page);
			  addHeader(contentStream, document,fromDate,AppConstants.MINE_SMALL);
			  y = 500;
			  x = 60;
			  contentStream.drawImage(gpoc, 280, 50, 50, 50);
	   }
			if(plotVOs.size()>0){
				boolean createNewpage = false;
				for (int i = 0; i < plotVOs.size(); i++) {
				 DefaultBoxAndWhiskerCategoryDataset dataset 
		            = new DefaultBoxAndWhiskerCategoryDataset();
				String plotName =  plotVOs.get(i).get("key").getTextValue();
				JsonNode values =  plotVOs.get(i).get("value");
				ObjectMapper mapper = new ObjectMapper();
				List<Number> list = mapper.readValue(values, ArrayList.class);
				List<Double> convertedList = new ArrayList<Double>();
				for(Number n: list){
				Double d =	n.doubleValue();
				convertedList.add(d);
				}
				if(list.size() > 4){
				 dataset.add(convertedList, "", "");
				 final CategoryAxis xAxis = new CategoryAxis(plotName);
		         NumberAxis yAxis = new NumberAxis("");
		         yAxis.setAutoRangeIncludesZero(true);
			        xAxis.setMaximumCategoryLabelWidthRatio(12f);
			         BoxAndWhiskerRenderer renderer = new BoxAndWhiskerRenderer();
			         renderer.setMeanVisible(false);
			         renderer.setMedianVisible(true);
			         renderer.setAutoPopulateSeriesOutlinePaint(true);
			         renderer.setSeriesPaint(0, Color.BLUE);
			         renderer.setSeriesPaint(1, Color.BLUE);
				   final CategoryPlot plot = new CategoryPlot(dataset, xAxis, yAxis, renderer);

			        final JFreeChart chart = new JFreeChart(
			            "",
			            plot
			        );
			       // chart.setBackgroundPaint(new Color(0));
			        //File lineGrpah_path = new File( "C:/murali/Boxplot1.png"); 
			        String imagePath = ohvImgUrl + AppConstants.PLOT_GRAPH;
					 File lineGrpah_path = new File(imagePath);
				    ChartUtilities.saveChartAsJPEG(lineGrpah_path, chart, 250 ,470);
					PDImageXObject line_graphObj = PDImageXObject.createFromFileByContent(lineGrpah_path, document);
			      contentStream.drawImage(line_graphObj, x, y, 150, 220);
			      x = x + 170;
				 if(y<300 && x > 400 && i < plotVOs.size()-1){
					 createNewpage = true;	    	  
				 }
			      if(x > 400){
			    	  y = y-250;
			    	  x = 60;
			      }
			     
				}
				if(createNewpage){
					createNewpage = false;
					 String imagePath = ohvImgUrl + AppConstants.GPOC_LOGO;
						File gpoc_logo = new File(imagePath);
						//File gpoc_path = new File("C:/murali/workspace/OMD_new/.metadata/.plugins/org.jboss.ide.eclipse.as.core/JBoss_AS_5.11517980955870/deploy/RMDWeb.war/img/app/gpoc_logo.png");
						 PDImageXObject gpoc = PDImageXObject.createFromFileByContent(gpoc_logo, document);
						 contentStream.close();
						 document.addPage(page);
			             page = new PDPage();
						  contentStream = new PDPageContentStream(document, page);
						  addHeader(contentStream, document,fromDate,AppConstants.MINE_SMALL);
						  y = 500;
						  x = 60;
						  contentStream.drawImage(gpoc, 280, 50, 50, 50);
				  }
				}
			}
			//contentStream.close();
		//}
		map.put(AppConstants.PD_PAGE, page);
		map.put(AppConstants.PD_DOCUMENT, document);
		map.put(AppConstants.CONTENT_STREAM, contentStream);
		return map;
		
	}

	private Map<String, Object> TruckTable(PDPageContentStream contentStream, PDDocument document, PDPage page,
			JsonNode mineVO, float h) throws IOException, GenericAjaxException, RMDWebException {
		logger.info("TruckTable method start");
		Map<String, Object> truckMap = new HashMap<String, Object>();
		// Image margins
		float height = h - 50;
		float x_image = 50;
		float x_image_bottom = height - 50;
		// box margines
		float box_top = height;
		float box_bottom = box_top - 50;
		float box_left = 100;
		float box_right = box_left + 60;
		try{
		JsonNode truckVOs = mineVO.get(AppConstants.TRUCKS);
		String fromDate = mineVO.get(AppConstants.FROM_DATE).getTextValue();
		if (truckVOs.size()>0) {
			String imagePath = null;
			if (x_image_bottom < 150) {
				imagePath = ohvImgUrl + AppConstants.GPOC_LOGO;
				File gpoc_logo = new File(imagePath);
				PDImageXObject gpoc = PDImageXObject.createFromFileByContent(gpoc_logo, document);
				contentStream.drawImage(gpoc, 280, 50, 50, 50);
				document.addPage(page);
				contentStream.close();
				page = new PDPage();
				contentStream = new PDPageContentStream(document, page);
				contentStream = addHeader(contentStream, document, fromDate,AppConstants.MINE_SMALL);
				x_image_bottom = 650;
				box_top = 700;
				box_bottom = box_top - 50;
				box_left = 100;
				box_right = box_left + 60;
				x_image = 50;
				contentStream.drawImage(gpoc, 280, 50, 50, 50);
			}
			
			for (int i = 0; i < truckVOs.size(); i++) {
			PDImageXObject pdImage = null;
			if (truckVOs.get(i).get(AppConstants.CREATCASE_WSPARAM_URGENCY).getTextValue().equalsIgnoreCase("B")) {
				 imagePath = ohvImgUrl + AppConstants.TRUCK_BLUE;
				File bule_truck = new File(imagePath);
				pdImage = PDImageXObject.createFromFileByContent(bule_truck, document);
			} else if (truckVOs.get(i).get(AppConstants.CREATCASE_WSPARAM_URGENCY).getTextValue().equalsIgnoreCase("R")) {
				 imagePath = ohvImgUrl +  AppConstants.TRUCK_RED;
				File red = new File(imagePath);
				pdImage = PDImageXObject.createFromFileByContent(red, document);
			} else if (truckVOs.get(i).get(AppConstants.CREATCASE_WSPARAM_URGENCY).getTextValue().equalsIgnoreCase("Y")) {
				 imagePath = ohvImgUrl +  AppConstants.TRUCK_YELLOW;
				File yellow = new File(imagePath);
				pdImage = PDImageXObject.createFromFileByContent(yellow, document);
			} else if (truckVOs.get(i).get(AppConstants.CREATCASE_WSPARAM_URGENCY).getTextValue().equalsIgnoreCase("G")) {
				imagePath = ohvImgUrl +  AppConstants.TRUCK_GREEN;
				File green = new File(imagePath);
				pdImage = PDImageXObject.createFromFileByContent(green, document);
			}else if (truckVOs.get(i).get(AppConstants.CREATCASE_WSPARAM_URGENCY).getTextValue().equalsIgnoreCase("BL")) {
				imagePath = ohvImgUrl +  AppConstants.TRUCK_BLACK;
				File green = new File(imagePath);
				pdImage = PDImageXObject.createFromFileByContent(green, document);
			}
			contentStream.drawImage(pdImage, x_image, x_image_bottom, 40, 40);
			contentStream.beginText();
			contentStream.newLineAtOffset(x_image + 5, x_image_bottom - 7);
			contentStream.setFont(PDType1Font.HELVETICA_BOLD, 7);
			contentStream.showText(truckVOs.get(i).get(AppConstants.TRUCK).getTextValue()+"");
			contentStream.endText();
			// draw boxes -rows
			contentStream.setLineWidth(1);
			contentStream.moveTo(box_left, box_top);
			contentStream.lineTo(box_right, box_top);
			contentStream.closeAndStroke();

			contentStream.setLineWidth(1);
			contentStream.moveTo(box_left, box_bottom);
			contentStream.lineTo(box_right, box_bottom);
			contentStream.closeAndStroke();

			contentStream.setLineWidth(1);
			contentStream.moveTo(box_left, box_top);
			contentStream.lineTo(box_left, box_bottom);
			contentStream.closeAndStroke();

			contentStream.setLineWidth(1);
			contentStream.moveTo(box_right, box_top);
			contentStream.lineTo(box_right, box_bottom);
			contentStream.closeAndStroke();

			createText(box_left + 2,box_top - 10,PDType1Font.HELVETICA,6,AppConstants.OHV_MODEL + truckVOs.get(i).get(AppConstants.CUSTOMERMODEL).getTextValue()+"",contentStream);
			createText(box_left + 2,box_top - 20,PDType1Font.HELVETICA,6,AppConstants.OHV_MODEL + truckVOs.get(i).get(AppConstants.CUSTOMERMODEL).getTextValue()+"",contentStream);
			createText(box_left + 2, box_top - 30,PDType1Font.HELVETICA,6,AppConstants.ACTIVE_TIME + truckVOs.get(i).get(AppConstants.ACTIVETIME).getTextValue()+"",contentStream);
			createText(box_left + 2, box_top - 40,PDType1Font.HELVETICA,6,AppConstants.OPEN_RXS + truckVOs.get(i).get(AppConstants.REPORTS_TRUCK_OPEN_RX).getTextValue()+"",contentStream);
			x_image = x_image + 130;
			box_left = box_left + 130;
			box_right = box_left + 60;
			if (box_left > 500) {
				box_left = 100;
				box_right = box_left + 60;
				x_image = 50;
				x_image_bottom = x_image_bottom - 70;
				box_top = box_top - 70;
				box_bottom = box_top - 50;
			}
			if (x_image_bottom < 150) {
				imagePath = ohvImgUrl + AppConstants.GPOC_LOGO;
				File gpoc_logo = new File(imagePath);
				PDImageXObject gpoc = PDImageXObject.createFromFileByContent(gpoc_logo, document);
				contentStream.drawImage(gpoc, 280, 50, 50, 50);
				document.addPage(page);
				contentStream.close();
				page = new PDPage();
				contentStream = new PDPageContentStream(document, page);
				contentStream = addHeader(contentStream, document, fromDate,AppConstants.MINE_SMALL);
				x_image_bottom = 650;
				box_top = 700;
				box_bottom = box_top - 50;
				box_left = 100;
				box_right = box_left + 60;
				x_image = 50;
				contentStream.drawImage(gpoc, 280, 50, 50, 50);
			}
			if(truckVOs.size() - 1 == i){
				if (x_image_bottom > 150) {
					if (box_left < 500){
						if (!(box_left == 100))
						   x_image_bottom = x_image_bottom - 70;
						imagePath = ohvImgUrl + AppConstants.GPOC_LOGO;
						File gpoc_logo = new File(imagePath);
						PDImageXObject gpoc = PDImageXObject.createFromFileByContent(gpoc_logo, document);
						contentStream.drawImage(gpoc, 280, 50, 60, 60);
						truckMap = createTopEvents(contentStream,document, page, x_image_bottom, mineVO,fromDate);
						contentStream = (PDPageContentStream) truckMap.get(AppConstants.CONTENT_STREAM);
						page = (PDPage) truckMap.get(AppConstants.PD_PAGE);
						h = (Float) truckMap.get(AppConstants.PAGE_HEIGHT);
					}
				}else{
					imagePath = ohvImgUrl + AppConstants.GPOC_LOGO;
					File gpoc_logo = new File(imagePath);
					PDImageXObject gpoc = PDImageXObject.createFromFileByContent(gpoc_logo, document);
					contentStream.drawImage(gpoc, 280, 50, 60, 60);
					document.addPage(page);
					contentStream.close();
					page = new PDPage();
					contentStream = new PDPageContentStream(document, page);
					contentStream = addHeader(contentStream, document, fromDate,AppConstants.MINE_SMALL);
					x_image_bottom = 700;
					box_top = 700;
					box_bottom = box_top - 50;
					box_left = 100;
					box_right = box_left + 60;
					x_image = 50;
					contentStream.drawImage(gpoc, 280, 50, 60, 60);
					truckMap = createTopEvents(contentStream, document, page, x_image_bottom, mineVO,fromDate);
					contentStream = (PDPageContentStream) truckMap.get(AppConstants.CONTENT_STREAM);
					page = (PDPage) truckMap.get(AppConstants.PD_PAGE);
					h = (Float) truckMap.get(AppConstants.PAGE_HEIGHT);
					}
					}
				 }
				}
			}catch (IOException e) {
	            logger.error(
	                    "Exception occured in TruckTable in ReportsServiceImpl:",e);
	       RMDWebErrorHandler.handleException(e);
	  }catch (Exception e) {
	    logger.error(
	            "Exception occured in TruckTable in ReportsServiceImpl:",e);
	RMDWebErrorHandler.handleException(e);
	}
		//contentStream.close();
		truckMap.put(AppConstants.CONTENT_STREAM, contentStream);
		truckMap.put(AppConstants.PD_DOCUMENT, document);
		truckMap.put(AppConstants.PD_PAGE, page);
		truckMap.put(AppConstants.PAGE_HEIGHT, h);
		logger.info("TruckTable method end");
		return truckMap;

	}

	private Map<String, Object> createTopEvents(PDPageContentStream contentStream,PDDocument document, PDPage page, float header,
			JsonNode mineVO,String fromDate) throws GenericAjaxException, RMDWebException, IOException {
		// TODO Auto-generated method stub
		logger.info("createTopEvents method start");
		Map<String, Object> map = new HashMap<String, Object>();
		float data_y = 0;
		float h = 0;
		String imagePath = ohvImgUrl + AppConstants.GPOC_LOGO;
		File gpoc_logo = new File(imagePath);
		 PDImageXObject gpoc = PDImageXObject.createFromFileByContent(gpoc_logo, document);
		try{
		float margin = 60;
			JsonNode evetVOs = mineVO.get(AppConstants.EVENTS_REPORT);
		if (evetVOs.size() == 0) {
			  if(header < 150){
					 contentStream.close();
					 document.addPage(page);
		             page = new PDPage();
					  contentStream = new PDPageContentStream(document, page);
					  addHeader(contentStream, document,fromDate,AppConstants.MINE_SMALL);
					  header = 680;
					  contentStream.drawImage(gpoc, 280, 50, 50, 50);
			  }
			 createText(280,header+10,PDType1Font.HELVETICA_BOLD,10,AppConstants.TOPEVENTS,contentStream);
			map = createEmptyEventTable(contentStream, page, header,margin,AppConstants.MINE_SMALL);
			h = (Float) map.get(AppConstants.PAGE_HEIGHT);
			return map;
		}else{
			  if(header < 250){
					 contentStream.close();
					 document.addPage(page);
		             page = new PDPage();
					  contentStream = new PDPageContentStream(document, page);
					  addHeader(contentStream, document,fromDate,AppConstants.MINE_SMALL);
					  header = 680;
					  contentStream.drawImage(gpoc, 280, 50, 50, 50);
			  }
			  createText(280,header+10,PDType1Font.HELVETICA_BOLD,10,AppConstants.TOPEVENTS,contentStream);
			   float xStart = 60;
			    float xEnd = 552;
		        float yStartAndEnd = header;
		        float yStart = header;
		        final float rowHeight = 20f;
		        ObjectMapper mapper = new ObjectMapper();
		         ArrayNode arrayNode = mapper.createArrayNode();
		         boolean flag = false;
		         for (int i = 0; i < evetVOs.size(); i++) {
		        	 drawLine(xStart,yStartAndEnd,xEnd,yStartAndEnd,contentStream);
		        	 yStartAndEnd -= rowHeight;
				     arrayNode.add(evetVOs.get(i));
				     if(yStartAndEnd < 150){
				    	 //contentStream.drawImage(gpoc, 280, 50, 50, 50);
				    	 if(arrayNode.size() > 0){
					        	drawLine(xStart,yStartAndEnd,xEnd,yStartAndEnd,contentStream);
					        	drawLine(xStart,yStartAndEnd-20,xEnd,yStartAndEnd-20,contentStream);
					        	 map = createMineEventColums(contentStream,arrayNode,yStart,yStartAndEnd-40,flag);
					        	 flag = true;
					        	}
				    	// yStart = (Float) map.get(AppConstants.PAGE_HEIGHT);
				    	 contentStream = (PDPageContentStream) map.get(AppConstants.CONTENT_STREAM);
			        	 contentStream.close();
			        	  arrayNode = mapper.createArrayNode();
			               document.addPage(page);
			               page = new PDPage();
						  contentStream = new PDPageContentStream(document, page);
						  addHeader(contentStream, document,fromDate,AppConstants.TRUCK);
						  contentStream.drawImage(gpoc, 280, 50, 50, 50);
						  yStartAndEnd = 700;
						  yStart = 700;
						  map.put(AppConstants.PAGE_HEIGHT, yStartAndEnd);
							
				     }
		         }
		         if(arrayNode.size() > 0){
		        		drawLine(xStart,yStartAndEnd,xEnd,yStartAndEnd,contentStream);
		            	drawLine(xStart,yStartAndEnd-20,xEnd,yStartAndEnd-20,contentStream);
			        map = createMineEventColums(contentStream,arrayNode,yStart,yStartAndEnd-40,flag);
			        flag = true;
		        	}
		         map.put(AppConstants.CONTENT_STREAM, contentStream);
		            map.put(AppConstants.PD_PAGE, page);
		            map.put(AppConstants.PD_DOCUMENT, document);
		      
		        
		        
		}
       
		}catch (IOException e) {
            logger.error(
                    "Exception occured in createTopEvents in ReportsServiceImpl:",e);
       RMDWebErrorHandler.handleException(e);
	  }catch (Exception e) {
	    logger.error(
	            "Exception occured in createTopEvents in ReportsServiceImpl:",e);
	RMDWebErrorHandler.handleException(e);
	}
		
		 logger.info("createTopEvents method end");
		
		return map;
	}

	private Map<String, Object> createMineEventColums(PDPageContentStream contentStream, ArrayNode evetVOs,
			float header, float yStartAndEnd, boolean flag) throws IOException {
		// TODO Auto-generated method stub
		Map<String, Object> map = new HashMap<String, Object>();
		if(header > 650 && flag == true){
			contentStream.beginText();
	        contentStream.newLineAtOffset(280, header+5);//615
	        contentStream.setFont(PDType1Font.HELVETICA_BOLD,12);
	        contentStream.showText(AppConstants.EVENTS_CONTINUE);
	        contentStream.endText();
			}
		
		float y = header;
		// drawing columns the columns
		float nextx = 70;
		float h = (int) yStartAndEnd + 20;
		float[] mlx = {60,120,170,425,490,552};
		for(int i = 0;i < mlx.length;i++){
			 drawLine(mlx[i],y,mlx[i],h,contentStream);
		}
		
		map.put(AppConstants.CONTENT_STREAM, contentStream);
		map.put(AppConstants.PAGE_HEIGHT, h);
		// now add Headers to table
		 createText(62,header - 10,PDType1Font.HELVETICA_BOLD,6,AppConstants.EVENT_NUMBER,contentStream);
		 createText(122,header - 10,PDType1Font.HELVETICA_BOLD,6,AppConstants.SUB_ID,contentStream);
		 createText(172,header - 10,PDType1Font.HELVETICA_BOLD,6,AppConstants.DESCRIPTION,contentStream);
		 createText(427,header - 10,PDType1Font.HELVETICA_BOLD,6,AppConstants.TOTAL_OCCURANCES,contentStream);
		 createText(492,header - 10,PDType1Font.HELVETICA_BOLD,6,AppConstants.TRUCKSPERDAY,contentStream);
		//insert data
        float data_y = header-30;//580
        float[] data_x = {62,122,172,427,492};
        for(int i=0;i<evetVOs.size();i++){
        	 createText(data_x[0],data_y,PDType1Font.HELVETICA,6,evetVOs.get(i).get("eventNumber").getTextValue()+"",contentStream);
        	 createText(data_x[1],data_y,PDType1Font.HELVETICA,6,evetVOs.get(i).get("subId").getTextValue()+"",contentStream);
 	       if(evetVOs.get(i).get("description").getTextValue().length() > 80){
 	    	  createText(data_x[2],data_y,PDType1Font.HELVETICA,6,evetVOs.get(i).get("description").getTextValue().substring(0, 80),contentStream);
 	    	 createText(data_x[2],data_y-8,PDType1Font.HELVETICA,6,evetVOs.get(i).get("description").getTextValue().substring(80),contentStream);
 	        }else{
 	        	 createText(data_x[2],data_y,PDType1Font.HELVETICA,6,evetVOs.get(i).get("description").getTextValue()+"",contentStream);
 	        }
 	      createText(data_x[3],data_y,PDType1Font.HELVETICA,6,evetVOs.get(i).get("numberOfOccurance").getTextValue()+"",contentStream);
 	      createText(data_x[4],data_y,PDType1Font.HELVETICA,6,evetVOs.get(i).get("trucksPerDay").getTextValue()+"",contentStream);
 	        data_y = data_y - 20;
        }
       
		return map;
	}

	private Map<String, Object> createEmptyEventTable(PDPageContentStream contentStream, PDPage page, float header,float margin,String pdfType)
			throws GenericAjaxException, RMDWebException, IOException {
		// TODO Auto-generated method stub
		logger.info("createEmptyEventTable method start");
		// margin = 50;
		// createText(280,header+10,PDType1Font.HELVETICA_BOLD,10,AppConstants.TOPEVENTS,contentStream);
		Map<String, Object> map = new HashMap<String, Object>();
		 float lastcolumn;
		 double width;
		 header  = header-5;
			float nexty = header - 5;
		 createText(62,header - 15,PDType1Font.HELVETICA_BOLD,6,AppConstants.EVENT_NUMBER,contentStream);
		 createText(122,header - 15,PDType1Font.HELVETICA_BOLD,6,AppConstants.SUB_ID,contentStream);
		 createText(172,header - 15,PDType1Font.HELVETICA_BOLD,6,AppConstants.DESCRIPTION,contentStream);
		if(pdfType.equalsIgnoreCase(AppConstants.MINE_SMALL)){
			 createText(427,header - 15,PDType1Font.HELVETICA_BOLD,6,AppConstants.TOTAL_OCCURANCES,contentStream);
			 createText(492,header - 15,PDType1Font.HELVETICA_BOLD,6,AppConstants.TRUCKSPERDAY,contentStream);
			 lastcolumn = 552;
			 width=2.0;
		}else{
			 createText(427,header - 15,PDType1Font.HELVETICA_BOLD,6,AppConstants.OCCUR_TIME_TRUCK,contentStream);
			 createText(492,header - 15,PDType1Font.HELVETICA_BOLD,6,AppConstants.RESET_TIME,contentStream);
			 lastcolumn = 572;
			 width=2.0;
		}
		// insert data into table
		 createText(230,header - 35,PDType1Font.HELVETICA_BOLD,6,AppConstants.NO_DATA_AVAILABLE,contentStream);
		final float rowHeight = 20f;
		 final float tableWidth = (float) (page.getMediaBox().getWidth() - (width * margin));
		// draw the rows
		try{
		for (int i = 0; i <= 2; i++) {
			contentStream.setLineWidth(1);
			contentStream.moveTo(margin, nexty);
			contentStream.lineTo(margin + tableWidth, nexty);
			contentStream.closeAndStroke();
			nexty -= rowHeight;
		}
		
		float y = header - 5;
		// drawing columns the columns
		float nextx = margin;
		float h = header - 45;
		float[] mlx = {120,170,425,490};
		float h_mid = header - 25;
		for(int i = 0;i < mlx.length;i++){
			 drawLine(mlx[i],y,mlx[i],h_mid,contentStream);
		}
		drawLine(nextx,y,nextx,h,contentStream);
		drawLine(lastcolumn,y,lastcolumn,h,contentStream);
		// now add Headers to table
		
		map.put(AppConstants.PAGE_HEIGHT, h);
		map.put(AppConstants.CONTENT_STREAM, contentStream);
		map.put(AppConstants.PD_PAGE, page);
		}catch (IOException e) {
            logger.error(
                    "Exception occured in createEmptyEventTable in ReportsServiceImpl:",e);
       RMDWebErrorHandler.handleException(e);
	  }catch (Exception e) {
	    logger.error(
	            "Exception occured in createEmptyEventTable in ReportsServiceImpl:",e);
	RMDWebErrorHandler.handleException(e);
	}
		logger.info("createEmptyEventTable method end");
		return map;

	}

	private Map<String, Object> createEmptyOpenRxTable(PDPageContentStream contentStream, PDPage page,
			Map<String, Object> map,float height,float margin,String pdfType) throws GenericAjaxException, RMDWebException {
		// TODO Auto-generated method stub
		logger.info("createEmptyOpenRxTable method start");
		final float rowHeight = 20f;
		 float tableWidth;
		 float lastcolumn;
		 try{
		if(pdfType.equalsIgnoreCase(AppConstants.MINE_SMALL)){
			  tableWidth = (float) (page.getMediaBox().getWidth() - (2.0 * margin));
			  lastcolumn = 552;
		}else{
			  tableWidth = (float) (page.getMediaBox().getWidth() - (2.0 * margin));
			  lastcolumn = 572;
		}
		// draw the rows
		float nexty = height - 5;
		for (int i = 0; i <= 2; i++) {
			contentStream.setLineWidth(1);
			contentStream.moveTo(margin, nexty);
			contentStream.lineTo(margin + tableWidth, nexty);
			contentStream.closeAndStroke();
			nexty -= rowHeight;
		}
		float y = height - 5;
		// drawing columns the columns
		float h =  (float)nexty + 20;
		float h_mid = h + 20;
		float[] mlx = {150,390,470,lastcolumn};
		for(int i = 0;i < mlx.length;i++){
			 drawLine(mlx[i],y,mlx[i],h_mid,contentStream);
		}
		drawLine(margin,y,margin,h,contentStream);
		drawLine(lastcolumn,y,lastcolumn,h,contentStream);
		// now add Headers to table
		if(pdfType.equalsIgnoreCase(AppConstants.MINE_SMALL)){
			 createText(margin+2,height - 15,PDType1Font.HELVETICA_BOLD,8,AppConstants.TRUCK_NUMBER,contentStream);
		}else{
			createText(margin+2,height - 15,PDType1Font.HELVETICA_BOLD,8,AppConstants.RX_NUMBER,contentStream);
		}
		createText(152,height - 15,PDType1Font.HELVETICA_BOLD,8,AppConstants.OHV_RX_TITLE,contentStream);
		createText(392,height - 15,PDType1Font.HELVETICA_BOLD,8,AppConstants.DELIVERED_DATE,contentStream);
		createText(472,height - 15,PDType1Font.HELVETICA_BOLD,8,AppConstants.OPEN_TIME,contentStream);
		createText(230,h + 7,PDType1Font.HELVETICA_BOLD,8,AppConstants.NO_DATA_AVAILABLE,contentStream);
		map.put(AppConstants.CONTENT_STREAM, contentStream);
		map.put(AppConstants.PAGE_HEIGHT, h);
		map.put(AppConstants.PD_PAGE, page);
		 }catch (IOException e) {
	            logger.error(
	                    "Exception occured in createEmptyOpenRxTable in ReportsServiceImpl:",e);
	       RMDWebErrorHandler.handleException(e);
		  }catch (Exception e) {
		    logger.error(
		            "Exception occured in createEmptyOpenRxTable in ReportsServiceImpl:",e);
		RMDWebErrorHandler.handleException(e);
		}
		logger.info("createEmptyOpenRxTable method end");
		return map;
	}

	private  PDPageContentStream addHeader(PDPageContentStream contentStream, PDDocument document,
			String fromDate,String pdfType) throws GenericAjaxException, RMDWebException {
		// TODO Auto-generated method stub
		 logger.info("addHeader method start");
		 try{
			 if(pdfType.equals(AppConstants.MINE_SMALL)){
			 createText(475,750,PDType1Font.HELVETICA,8,AppConstants.GE_TRANSPORTATION,contentStream);
			 createText(70,750,PDType1Font.HELVETICA,8,fromDate,contentStream);
			 drawLine(60,740,552,740,contentStream);
			String imagePath = ohvImgUrl + AppConstants.GE_LOGO;
			File ge_logo_path = new File(imagePath);
			PDImageXObject gelogo = PDImageXObject.createFromFileByContent(ge_logo_path, document);
			contentStream.drawImage(gelogo, 450, 745, 20, 20);
			 }else{
				 createText(495,750,PDType1Font.HELVETICA,8,AppConstants.GE_TRANSPORTATION,contentStream);
				 createText(60,750,PDType1Font.HELVETICA,8,fromDate,contentStream);
				 drawLine(40,740,572,740,contentStream);
				String imagePath = ohvImgUrl + AppConstants.GE_LOGO;
				File ge_logo_path = new File(imagePath);
				PDImageXObject gelogo = PDImageXObject.createFromFileByContent(ge_logo_path, document);
				contentStream.drawImage(gelogo, 470, 745, 20, 20);
			 }
		 }catch (IOException e) {
	            logger.error(
	                    "Exception occured in addHeader in ReportsServiceImpl:",e);
	       RMDWebErrorHandler.handleException(e);
		  }catch (Exception e) {
		    logger.error(
		            "Exception occured in addHeader in ReportsServiceImpl:",e);
		RMDWebErrorHandler.handleException(e);
		}
		logger.info("addHeader method end");
		return contentStream;
	}
	
	private PDPageContentStream createText(float tx,float ty,PDFont fontType,float fontSize,String text,PDPageContentStream contentStream) throws IOException{
		contentStream.beginText();
		contentStream.setFont(fontType, fontSize);
		contentStream.newLineAtOffset(tx, ty);
		contentStream.showText(text);
		contentStream.endText();
		return contentStream;
	}
	private PDPageContentStream drawLine(float mx,float my,float lx,float ly,PDPageContentStream contentStream) throws IOException{
		contentStream.setLineWidth(1);
		contentStream.moveTo(mx, my);
		contentStream.lineTo(lx, ly);
		contentStream.closeAndStroke();
		return contentStream;
		
	}

	private PDPageContentStream addTitle(PDPageContentStream contentStream,String pdfType) throws IOException, GenericAjaxException, RMDWebException {
		// TODO Auto-generated method stub
		logger.info("addTitle method start");
		try{
		createText(200,720,PDType1Font.TIMES_BOLD,12,AppConstants.TITLE_ONE,contentStream);
		createText(220,705,PDType1Font.TIMES_BOLD,12,AppConstants.TITLE_TWO,contentStream);
		if(pdfType.equalsIgnoreCase(AppConstants.MINE_SMALL)){
			createText(250,690,PDType1Font.TIMES_BOLD,12,AppConstants.TITLE_THREE_MINE,contentStream);
		}else{
			createText(250,690,PDType1Font.TIMES_BOLD,12,AppConstants.TITLE_THREE_TRUCK,contentStream);
		}
		}catch (IOException e) {
            logger.error(
                    "Exception occured in addTitle in ReportsServiceImpl:",e);
       RMDWebErrorHandler.handleException(e);
	  }catch (Exception e) {
	    logger.error(
	            "Exception occured in addTitle in ReportsServiceImpl:",e);
	RMDWebErrorHandler.handleException(e);
	}
		logger.info("addTitle method end");
		return contentStream;
	}

	private JsonNode readJsonfile(String jsonStr) throws IOException {
		// TODO Auto-generated method stub
		logger.info("readJsonfile method start");
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(Feature.AUTO_CLOSE_JSON_CONTENT, true);
		mapper.configure(JsonParser.Feature.ALLOW_SINGLE_QUOTES, true);
		JsonNode jsonNode= mapper.readTree(jsonStr);
		logger.info("readJsonfile method end");
		return jsonNode;
	}

	private  PDPageContentStream createRect(PDPageContentStream contentStream, PDDocument document,
			JsonNode mineVO) throws IOException, JSONException, GenericAjaxException, RMDWebException {
		// TODO Auto-generated method stub
		logger.info("createRect method start");
		 String imagePath = null;
		 try{
		 drawLine(200,680,450,680,contentStream);
		 drawLine(200,640,450,640,contentStream);
		 drawLine(200,680,200,640,contentStream);
		 drawLine(450,680,450,640,contentStream);
		 createText(202,670,PDType1Font.HELVETICA,7,AppConstants.MINE + mineVO.get(AppConstants.MINE_SMALL).getTextValue()+"",contentStream);
		 createText(290,670,PDType1Font.HELVETICA,7,AppConstants.MINE_STATUS,contentStream);
		  String mineStatus = null;
		  createText(60,620,PDType1Font.HELVETICA,7,"Notes: ",contentStream);
		  if(mineVO.get(AppConstants.MINESTATUS).getTextValue().equalsIgnoreCase("Y")){ mineStatus =
		  AppConstants.STATUS_YELLOW; 
		  createText(60,610,PDType1Font.HELVETICA,7,"*(Yellow) : "+AppConstants.REPORTS_OHV_MINE_STATUS_TOOLTIP_YELLOW,contentStream);
		  }/*else
		  if(mineVO.get(AppConstants.MINESTATUS).getTextValue().equalsIgnoreCase("B")){ mineStatus =
				  AppConstants.STATUS_BLUE; }*/else
		 if(mineVO.get(AppConstants.MINESTATUS).getTextValue().equalsIgnoreCase("R")){ mineStatus =
				 AppConstants.STATUS_RED;
		 createText(60,610,PDType1Font.HELVETICA,7,"*(Red) : "+AppConstants.REPORTS_OHV_MINE_STATUS_TOOLTIP_RED,contentStream);
		 }else
		if(mineVO.get(AppConstants.MINESTATUS).getTextValue().equalsIgnoreCase("G")){ mineStatus =
				 AppConstants.STATUS_GREEN;
		createText(60,610,PDType1Font.HELVETICA,7,"*(Green) : "+AppConstants.REPORTS_OHV_MINE_STATUS_TOOLTIP_GREEN,contentStream);
		}
		  createText(340,665,PDType1Font.HELVETICA,14,"*",contentStream);
		  
		  imagePath = ohvImgUrl + mineStatus;
			File mineStatus_path = new File(imagePath);
		  PDImageXObject pdImage =PDImageXObject.createFromFileByContent(mineStatus_path, document);
		  contentStream.drawImage(pdImage, 330, 667, 10, 10);
		 createText(350,670,PDType1Font.HELVETICA,7,AppConstants.COMMUNICATION_STATUS,contentStream);
		 String commStatus = null;
		  if(mineVO.get(AppConstants.COMMSTATUS).getTextValue().equalsIgnoreCase("Y")){ commStatus =
				  AppConstants.STATUS_YELLOW; 
		  createText(60,600,PDType1Font.HELVETICA,7,"**(Yellow) : "+AppConstants.REPORTS_OHV_MINE_COM_TOOLTIP_YELLOW,contentStream);
		  }else
		  if(mineVO.get(AppConstants.COMMSTATUS).getTextValue().equalsIgnoreCase("B")){ commStatus =
				  AppConstants.STATUS_BLUE;
		  createText(60,600,PDType1Font.HELVETICA,7,"**(Blue) : "+AppConstants.REPORTS_OHV_MINE_COM_TOOLTIP_BLUE,contentStream);
		  }else
		 if(mineVO.get(AppConstants.COMMSTATUS).getTextValue().equalsIgnoreCase("R")){ commStatus =
				 AppConstants.STATUS_RED; 
		 createText(60,600,PDType1Font.HELVETICA,7,"**(Red) : "+AppConstants.REPORTS_OHV_MINE_COM_TOOLTIP_RED,contentStream);
		 }/*else
		if(mineVO.get(AppConstants.COMMSTATUS).getTextValue().equalsIgnoreCase("G")){ commStatus =
				 AppConstants.STATUS_GREEN; }*/
		  createText(435,665,PDType1Font.HELVETICA,14,"**",contentStream);
		  imagePath = ohvImgUrl + commStatus;
			File commStatus_path = new File(imagePath);
		  PDImageXObject pdImage1 =PDImageXObject.createFromFileByContent(commStatus_path, document);
		  contentStream.drawImage(pdImage1, 425, 667, 10, 10);
		  
		createText(202,655,PDType1Font.HELVETICA,7,AppConstants.HEALTH_REPORTS + mineVO.get(AppConstants.OHV_HEALTH_REPORT).getTextValue()+"",contentStream);
		
		
		 }catch (IOException e) {
	            logger.error(
	                    "Exception occured in createRect in ReportsServiceImpl:",e);
	       RMDWebErrorHandler.handleException(e);
		  }catch (Exception e) {
		    logger.error(
		            "Exception occured in createRect in ReportsServiceImpl:",e);
		RMDWebErrorHandler.handleException(e);
		}
		logger.info("createRect method end");
		return contentStream;
	}

	private Map<String, Object> createOpenRXTable(PDPageContentStream contentStream, PDDocument document, PDPage page,
			JsonNode mineVO,String fromDate) throws IOException, GenericAjaxException, RMDWebException {
		// TODO Auto-generated method stub
		logger.info("createOpenRXTable method start");
		String imagePath = ohvImgUrl + AppConstants.GPOC_LOGO;
		File gpoc_logo = new File(imagePath);
		 PDImageXObject gpoc = PDImageXObject.createFromFileByContent(gpoc_logo, document);
		int height = 570;
		float margin = 60;
		Map<String, Object> map = new HashMap<String, Object>();
		JsonNode openRxVOs = mineVO.get(AppConstants.REPORTS_TRUCK_OPEN_RX);
		String rxType = mineVO.get(AppConstants.RX_TYPE).getTextValue();
		try{
			  if(rxType.equals(AppConstants.REPORTS_RX_ALL)){
				  createText(280,height+5,PDType1Font.HELVETICA_BOLD,12,AppConstants.OPEN_RXS,contentStream);
				    }else if(rxType.equals(AppConstants.RX_STATUS_RED)){
				    	 createText(280,height+5,PDType1Font.HELVETICA_BOLD,12,AppConstants.RED_RXS,contentStream);
				    }else{
				    	createText(280,height+5,PDType1Font.HELVETICA_BOLD,12,AppConstants.WHITE_RXS,contentStream);
				    }
		
		logger.info("openRxVOs.size()----------------  "+openRxVOs.size());
		if (openRxVOs.size() == 0) {
			map = createEmptyOpenRxTable(contentStream, page, map,height,margin,AppConstants.MINE_SMALL);
			return map;
		}else{
			 float xStart = 60;
		        float xEnd = 552;
		        float yStartAndEnd = 570;
		        float yStart = 570;
		        final float rowHeight = 20f;
		        ObjectMapper mapper = new ObjectMapper();
		         ArrayNode arrayNode = mapper.createArrayNode();
		         for (int i = 0; i < openRxVOs.size(); i++) {
		        	 drawLine(xStart,yStartAndEnd,xEnd,yStartAndEnd,contentStream);
		        	 yStartAndEnd -= rowHeight;
				     arrayNode.add(openRxVOs.get(i));
				     if(yStartAndEnd < 150){
				    	 contentStream.drawImage(gpoc, 280, 50, 50, 50);
				    	 if(arrayNode.size() > 0){
					        	drawLine(xStart,yStartAndEnd,xEnd,yStartAndEnd,contentStream);
					        	drawLine(xStart,yStartAndEnd-20,xEnd,yStartAndEnd-20,contentStream);
					        	 map = createMineRxColums(contentStream,arrayNode,yStart,yStartAndEnd-40,rxType);
					        	}
				    	 yStart = (Float) map.get(AppConstants.PAGE_HEIGHT);
				    	 contentStream = (PDPageContentStream) map.get(AppConstants.CONTENT_STREAM);
			        	 contentStream.close();
			        	  arrayNode = mapper.createArrayNode();
			               document.addPage(page);
			               page = new PDPage();
						  contentStream = new PDPageContentStream(document, page);
						  addHeader(contentStream, document,fromDate,AppConstants.MINE_SMALL);
						  yStartAndEnd = 700;
						  yStart = 700;
				     }
		         }
		     	if(arrayNode.size() > 0){
	        		drawLine(xStart,yStartAndEnd,xEnd,yStartAndEnd,contentStream);
	            	drawLine(xStart,yStartAndEnd-20,xEnd,yStartAndEnd-20,contentStream);
		        map = createMineRxColums(contentStream,arrayNode,yStart,yStartAndEnd-40,rxType);
	        	}
		     	map.put(AppConstants.CONTENT_STREAM, contentStream);
	            map.put(AppConstants.PD_PAGE, page);
	           // map.put(AppConstants.PD_DOCUMENT, document);
	     
		        
		}
	
		}catch (IOException e) {
            logger.error(
                    "Exception occured in createOpenRXTable in ReportsServiceImpl:",e);
       RMDWebErrorHandler.handleException(e);
	  }catch (Exception e) {
	    logger.error(
	            "Exception occured in createOpenRXTable in ReportsServiceImpl:",e);
	RMDWebErrorHandler.handleException(e);
	}
		logger.info("createOpenRXTable method start");
		return map;
	}
	
	private Map<String, Object> createMineRxColums(PDPageContentStream contentStream,
			ArrayNode openRxVOs, float height, float ystartAndEnd,String rxType) throws IOException {
		// TODO Auto-generated method stub
		Map<String, Object> map = new HashMap<String, Object>();
		if(height > 650){
			String rxTtile;
			  if(rxType.equals(AppConstants.REPORTS_RX_ALL)){
				  rxTtile = AppConstants.OPENRX_CONTINUE;
				    }else if(rxType.equals(AppConstants.RX_STATUS_RED)){
				    	 rxTtile = AppConstants.REDRX_CONTINUE;
				    }else{
				    	rxTtile = AppConstants.WHITERX_CONTINUE;
				    }
			contentStream.beginText();
	        contentStream.newLineAtOffset(280, height+5);//615
	        contentStream.setFont(PDType1Font.HELVETICA_BOLD,12);
	        contentStream.showText(rxTtile);
	        contentStream.endText();
			}
		float y = height;
		// drawing columns the columns
		float nextx = 90;
		float h = (float) ystartAndEnd + 20;
		float[] mlx = {60,120,355,480,552};
		for(int i = 0;i < mlx.length;i++){
			 drawLine(mlx[i],y,mlx[i],h,contentStream);
		}
		// now add Headers to table
		createText(62,height-15,PDType1Font.HELVETICA_BOLD,8,AppConstants.TRUCK_NUMBER,contentStream);
		createText(122,height-15,PDType1Font.HELVETICA_BOLD,8,AppConstants.OHV_RX_TITLE,contentStream);
		createText(357,height-15,PDType1Font.HELVETICA_BOLD,8,AppConstants.DELIVERED_DATE,contentStream);
		createText(482,height-15,PDType1Font.HELVETICA_BOLD,8,AppConstants.OPEN_TIME,contentStream);
		map.put(AppConstants.CONTENT_STREAM, contentStream);
		map.put(AppConstants.PAGE_HEIGHT, h);
		// insert Data
		float data_y = height-30;
		float[] data_x = { 62, 122, 357, 482 };
		for (int i = 0; i < openRxVOs.size(); i++) {
			createText(data_x[0],data_y,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.REPORTS_TRUCK_ID).getTextValue()+"",contentStream);
			if (openRxVOs.get(i).get(AppConstants.RXTITLE).size() > 80) {
				createText(data_x[1],data_y,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.RXTITLE).getTextValue().substring(0, 75),contentStream);
				createText(data_x[1],data_y-8,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.RXTITLE).getTextValue().substring(75),contentStream);
			} else {
				createText(data_x[1],data_y,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.RXTITLE).getTextValue()+"",contentStream);
			}
			
			if (openRxVOs.get(i).get(AppConstants.RX_DELIVERDATE).size() > 40) {
				createText(data_x[2],data_y,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.RX_DELIVERDATE).getTextValue().substring(0, 40),contentStream);
				createText(data_x[2],data_y-8,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.RX_DELIVERDATE).getTextValue().substring(40),contentStream);
			}else {
			createText(data_x[2],data_y,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.RX_DELIVERDATE).getTextValue()+"",contentStream);
			}
			createText(data_x[3],data_y,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.RX_OPENTIME).getTextValue()+"",contentStream);
			data_y = data_y - 20;
		}
		return map;
		
	}

	@Override
	public PDDocument getTruckPdfDocument(PDDocument document, String jsonStr) throws IOException, JSONException, GenericAjaxException, RMDWebException {
		// TODO Auto-generated method stub
		logger.info("getTruckPdfDocument method start");
		try{
	//		String strTruck = "{'rxType':'All','mine':'Suncor Energy Inc.','truck':'313','fleet':'SUN1','header':'M084','customerModel':'980E','geModel':'400AC-GDY108','controllerConfig':'INVERTEXII','fromDate':'03/22/2018 05:51:11','toDate':'03/23/2018 05:51:11','software':{'Inverter 2':'8.24','Inverter 1':'8.24','CPU':'5.50a'},'eoaEquip':'B2B','messageReceived':'','healthReports':'0','openRx':[{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'Y','caseId':'T002494','rxTitle':'Battery Boost Circuit Fail_Link V','rxObjid':'T002494','rxDeliverDate':'03/08/2018 12:41:29 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'302','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(7d 16hrs 57min)'},{'urgency':'W','caseId':'T002760','rxTitle':'Too Many non power up Boots  Multiple 654 Events','rxObjid':'T002760','rxDeliverDate':'03/15/2018 16:29:25 GMT','rxClosedDate':null,'estmRepairTime':'2','truckId':'304','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(0d 13hrs 10min)'},{'urgency':'W','caseId':'T002760','rxTitle':'Too Many non power up Boots  Multiple 654 Events','rxObjid':'T002760','rxDeliverDate':'03/15/2018 16:30:09 GMT','rxClosedDate':null,'estmRepairTime':'2','truckId':'304','locoImpact':'Mining - Propel System Caution (Speed limit 10/15 MPH)','rxOpenTime':'(0d 13hrs 9min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'},{'urgency':'R','caseId':'S217842','rxTitle':'testing again subsystem','rxObjid':'S217842-02','rxDeliverDate':'03/12/2018 19:36:58 GMT','rxClosedDate':null,'estmRepairTime':'1','truckId':'300','locoImpact':'Air compressor not operating (temporary)','rxOpenTime':'(3d 10hrs 2min)'}],'eventReports':[{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' },{ 'eventNumber':'T000848', 'subId':'001', 'description':'Test data', 'occurTime':'3:30', 'resetTime':'3:40', 'numberOfOccurance':'4', 'trucksPerDay':'340' }],'paramVariables':[{'paramName':'Control Power On','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'1363.55','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Engine Hours - (Meter)','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'0.38','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Engine Operating Hours','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'1360.68','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Engine Idle Time','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'408.63','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Truck Parked','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'297.41','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Propel Time','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'625.13','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Retard Time','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'221.83','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Warm Up Mode','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'5.20','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'No Retard','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'0.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'No Propel','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'5.62','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Speed Limit','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'0.28','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Inverter 1 Disable','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'0.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Inverter 2 Disable','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'0.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Retard Engine Speed Incr 1','paramUnit':'Times','lastMonthValue':'0','lastQtrValue':'0.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Retard Engine Speed Incr 2','paramUnit':'Times','lastMonthValue':'0','lastQtrValue':'0.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Distance Traveled','paramUnit':'Miles','lastMonthValue':'0','lastQtrValue':'16611.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Body Up','paramUnit':'Miles','lastMonthValue':'0','lastQtrValue':'1331.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Loads','paramUnit':'Number','lastMonthValue':'0','lastQtrValue':'1297.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Dispatch Messages','paramUnit':'Number','lastMonthValue':'0','lastQtrValue':'0.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'RP1 Pickup','paramUnit':'Times','lastMonthValue':'0','lastQtrValue':'55810.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'RP2 Pickup','paramUnit':'Times','lastMonthValue':'0','lastQtrValue':'38973.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'RP3 Pickup','paramUnit':'Times','lastMonthValue':'0','lastQtrValue':'20897.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'GF Contactor','paramUnit':'Times','lastMonthValue':'0','lastQtrValue':'552.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Parking Brake','paramUnit':'Times','lastMonthValue':'0','lastQtrValue':'1900.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Eng/Alternator Revolutions','paramUnit':'Number','lastMonthValue':'0','lastQtrValue':'6545920.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Alternator MW-Hrs','paramUnit':'MWh','lastMonthValue':'0','lastQtrValue':'0.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Overloads','paramUnit':'Number','lastMonthValue':'0','lastQtrValue':'18.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Pre-Shift Brake Tests','paramUnit':'Hours','lastMonthValue':'0','lastQtrValue':'208.00','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':'Healthcheck Failed','paramUnit':'Number','lastMonthValue':'0','lastQtrValue':'0','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':' Healthcheck Success','paramUnit':'Number','lastMonthValue':'0','lastQtrValue':'0','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':' Faultcheck Success','paramUnit':'Number','lastMonthValue':'0','lastQtrValue':'0','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':' Faultcheck Failed','paramUnit':'Number','lastMonthValue':'0','lastQtrValue':'0','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':' HC Files Received','paramUnit':'Number','lastMonthValue':'0','lastQtrValue':'0','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':' Fuel Saver 2 Enabled','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'0','oneDayValue':'0','thirtyDayAvgValue':'0'},{'paramName':' Continuous Retard','paramUnit':'Hrs','lastMonthValue':'0','lastQtrValue':'0','oneDayValue':'0','thirtyDayAvgValue':'0'}],'loads':[]}";
		//String newJson = jsonStr.replace('\"', '\'');
		JsonNode truckVO = readJsonfile(jsonStr);
		 JsonNode params = truckVO.get(AppConstants.PARAM_VARIABLES);
		 JsonNode graphPparams = truckVO.get(AppConstants.GRAPHDATA);
		 String fromDate = truckVO.get(AppConstants.FROM_DATE).getTextValue()+"";
		 PDPage page = new PDPage();
		 PDPageContentStream contentStream = new PDPageContentStream(document, page);
		 contentStream = addHeader(contentStream, document, fromDate,AppConstants.TRUCK);
		 contentStream = addTitle(contentStream,AppConstants.TRUCK);
		 truckDetails(contentStream,truckVO);
		 Map<String, Object> graphMap =createGraph(document,contentStream,truckVO);
		 document = (PDDocument) graphMap.get(AppConstants.PD_DOCUMENT);
		 contentStream = (PDPageContentStream) graphMap.get(AppConstants.CONTENT_STREAM);
		 Map<String, Object> map = createTruckOpenRxTable(document,contentStream, page, truckVO);
		 contentStream = (PDPageContentStream) map.get(AppConstants.CONTENT_STREAM);
		 float h = (Float) map.get(AppConstants.PAGE_HEIGHT);
		 page = (PDPage) map.get(AppConstants.PD_PAGE);
			Map<String, Object> map1 =	createParamsTable(contentStream,document,page,truckVO,h-20,fromDate);
			document = (PDDocument) map1.get(AppConstants.PD_DOCUMENT);
			page = (PDPage) map1.get(AppConstants.PD_PAGE);
		 contentStream.close();
		 document.addPage( page ); 
		}catch (IOException e) {
        logger.error(
                "Exception occured in getTruckPdfDocument in ReportsServiceImpl:",e);
        		RMDWebErrorHandler.handleException(e);
		}
		catch (Exception e) {
		        logger.error(
		                "Exception occured in getTruckPdfDocument in ReportsServiceImpl:",e);
		   RMDWebErrorHandler.handleException(e);
		}
		 logger.info("getTruckPdfDocument method end");
		return document;
	}	
	
	private  Map<String, Object> createGraph(PDDocument document,PDPageContentStream contentStream,
			JsonNode graphPparams) throws IOException, GenericAjaxException, RMDWebException {
		 logger.info("createGraph method Start");
		Map<String, Object> map = new HashMap<String, Object>();
		ArrayNode list = null;
		String y_value = null;
		String[] params = {"loads","engineOpHrs","engineIdleTime","overloads","averageHP"};
		try{
		Iterator<Entry<String,JsonNode>> itr = graphPparams.getFields();
		 while(itr.hasNext()){
			  Entry<String,JsonNode> entry= itr.next();
		for(int i=0;i < params.length;i++){
			  if (params[i].equals(entry.getKey()))
			    {
				  list =  (ArrayNode) graphPparams.get(params[i]);
					y_value = params[i];
			    }
		  }
		}
		// TODO Auto-generated method stub
		DefaultCategoryDataset line_chart_dataset = new DefaultCategoryDataset();
		if(list != null && list.size() > 0){
			List<Integer> yAxis = new ArrayList<Integer>();
		for(JsonNode param: list){
			yAxis.add(param.get("value").getIntValue());
			//line_chart_dataset.addValue(param.get("value").getValueAsDouble(), "Hours" , param.get("timestamp").getTextValue());
			line_chart_dataset.addValue(param.get("value").getValueAsDouble(), "Hours" , new LineChartColKey(param.get("timestamp").getTextValue()));
		}
		Collections.sort(yAxis);
		int i =yAxis.get(yAxis.size()-1) - yAxis.get(0);
		 JFreeChart lineChartObject = ChartFactory.createLineChart(
		         " ","Hours",
		         y_value,
		         line_chart_dataset,PlotOrientation.VERTICAL,
		         true,true,false);
		       if(i != 0){
		    	   lineChartObject.getCategoryPlot().getRangeAxis().setRange(yAxis.get(0)-i/5, yAxis.get(yAxis.size()-1)+i/5);
		       }
		       lineChartObject.getCategoryPlot().getRangeAxis().setVisible(true);
		       lineChartObject.getCategoryPlot().getDomainAxis().setVisible(false);
		       lineChartObject.getCategoryPlot().getDomainAxis().setCategoryLabelPositions(CategoryLabelPositions.createUpRotationLabelPositions(Math.PI/2));;//.setTickMarksVisible(true);
		       int width = 440;    /* Width of the image */
		       int height = 280;   /* Height of the image */ 
		         String imagePath = ohvImgUrl + AppConstants.LINE_GRAPH;
				 File lineGrpah_path = new File(imagePath);
				 ChartUtilities.saveChartAsJPEG(lineGrpah_path, lineChartObject, width ,height);
				PDImageXObject line_graphObj = PDImageXObject.createFromFileByContent(lineGrpah_path, document);
		      contentStream.drawImage(line_graphObj, 220, 580, 170, 100);
		      lineGrpah_path.delete();
		}else{
			createText(245,630,PDType1Font.HELVETICA_BOLD,8,AppConstants.NO_DATA_AVAILABLE_GRAPH,contentStream);
		}
		}catch (IOException e) {
	        logger.error(
	                "Exception occured in createGraph in ReportsServiceImpl:",e);
	        		RMDWebErrorHandler.handleException(e);
			}
			catch (Exception e) {
			        logger.error(
			                "Exception occured in createGraph in ReportsServiceImpl:",e);
			   RMDWebErrorHandler.handleException(e);
			}
		map.put(AppConstants.PD_DOCUMENT, document);
		map.put(AppConstants.CONTENT_STREAM, contentStream);
		 logger.info("createGraph method end");
		return map;
		
	}
	
	private void truckDetails(PDPageContentStream contentStream,JsonNode truckVO) throws IOException, GenericAjaxException, RMDWebException {
		// TODO Auto-generated method stub
		logger.info("truckDetails method Start");
		 contentStream.setLineWidth(1);
		 drawLine(40,680,190,680,contentStream);
		 drawLine(40,560,190,560,contentStream);
		 drawLine(40,680,40,560,contentStream);
		 drawLine(190,680,190,560,contentStream);
	      try{
		 createText(42,670,PDType1Font.HELVETICA,8,AppConstants.MINE+truckVO.get(AppConstants.MINE_SMALL).getTextValue()+"",contentStream);
		 createText(42,658,PDType1Font.HELVETICA,8,AppConstants.TRUCK_FIELD+truckVO.get(AppConstants.TRUCK).getTextValue()+"",contentStream);
		 createText(42,646,PDType1Font.HELVETICA,8,AppConstants.FLEET_FIELD+truckVO.get(AppConstants.FLEET).getTextValue()+"  "+AppConstants.HEADER_FIELD+truckVO.get(AppConstants.HEADER).getTextValue(),contentStream);
		 createText(42,634,PDType1Font.HELVETICA,8,AppConstants.CUSTOMER_MODEL+truckVO.get(AppConstants.CUSTOMERMODEL).getTextValue()+"",contentStream);
		 createText(42,622,PDType1Font.HELVETICA,8,AppConstants.GE_MODEL+truckVO.get(AppConstants.GEMODEL).getTextValue()+"",contentStream);
		 createText(42,610,PDType1Font.HELVETICA,8,AppConstants.CONTROLLER_CFG+truckVO.get(AppConstants.CONTROLLER_CONFIG).getTextValue()+"",contentStream);
	       
	        JsonNode node = (JsonNode) truckVO.get(AppConstants.SOFTWARE_VERSION);
	        ObjectMapper mapper = new ObjectMapper();
	        Map<String, String> softwareMap = mapper.convertValue(node, Map.class);
	        if(!softwareMap.isEmpty()){
	        	createText(42,598,PDType1Font.HELVETICA,8,AppConstants.SOFTWARE,contentStream);
	  	       int xy =598; 
	        for (Entry<String, String> entry : softwareMap.entrySet()) {
	        	createText(80,xy,PDType1Font.HELVETICA,8,entry.getKey()+" :"+entry.getValue(),contentStream);
	        	 xy = xy - 10;
	         }
	        }else{
	        	createText(42,598,PDType1Font.HELVETICA,8,AppConstants.SOFTWARE,contentStream);
	        }
          // right side box
	        drawLine(420,680,572,680,contentStream);
			 drawLine(420,560,572,560,contentStream);
			 drawLine(420,680,420,560,contentStream);
			 drawLine(572,680,572,560,contentStream);
			 
			 createText(422,670,PDType1Font.HELVETICA,8,AppConstants.EOA_EQUIPPED+truckVO.get(AppConstants.EOAEQUIP).getTextValue()+"",contentStream);
			 createText(422,655,PDType1Font.HELVETICA,8,AppConstants.MESSAGE_RECEIVED+truckVO.get(AppConstants.MESSAGERECEIVED).getTextValue()+"",contentStream);
			 createText(422,640,PDType1Font.HELVETICA,8,AppConstants.HEALTH_REPORTS+truckVO.get(AppConstants.HEALTHREPORTS).getTextValue()+"",contentStream);
	      }catch (IOException e) {
		        logger.error(
		                "Exception occured in createGraph in ReportsServiceImpl:",e);
		        		RMDWebErrorHandler.handleException(e);
				}
				catch (Exception e) {
				        logger.error(
				                "Exception occured in createGraph in ReportsServiceImpl:",e);
				   RMDWebErrorHandler.handleException(e);
				}
			 
			 logger.info("truckDetails method Start");
	}
	
	private Map<String, Object> createTruckOpenRxTable(PDDocument document,PDPageContentStream contentStream,PDPage page,JsonNode truckVO) throws IOException, GenericAjaxException, RMDWebException {
		// TODO Auto-generated method stub
		logger.info("createTruckOpenRxTable method start");
		JsonNode openRxVOs = truckVO.get(AppConstants.REPORTS_TRUCK_OPEN_RX);
		Map<String, Object> map = new HashMap<String, Object>();
		String imagePath = ohvImgUrl + AppConstants.GPOC_LOGO;
		 String fromDate = truckVO.get(AppConstants.FROM_DATE).getTextValue()+"";
		File gpoc_logo = new File(imagePath);
		 PDImageXObject gpoc = PDImageXObject.createFromFileByContent(gpoc_logo, document);
		    int height = 550;
		    float margin = 40;
		    if(truckVO.get(AppConstants.RX_TYPE).getTextValue().equals(AppConstants.STATUS_OPEN)){
	        createText(280,550,PDType1Font.HELVETICA_BOLD,12,AppConstants.OPEN_RXS,contentStream);
		    }else if(truckVO.get(AppConstants.RX_TYPE).getTextValue().equals(AppConstants.STATUS_CLOSED)){
		    	createText(280,550,PDType1Font.HELVETICA_BOLD,12,AppConstants.CLOSED_RXS,contentStream);
		    }else{
		    	createText(280,550,PDType1Font.HELVETICA_BOLD,12,AppConstants.ALL_RXS,contentStream);
		    }
	        try{
	        if(openRxVOs.size() == 0){
				map = createEmptyOpenRxTable(contentStream,page,map,height,margin,AppConstants.TRUCK);
				return map;
			}else{
				float xStart = 40;
		        float xEnd = 572;
		        float yStartAndEnd = 545;
		        float yStart = 545;
		        final float rowHeight = 20f;
		        ObjectMapper mapper = new ObjectMapper();
		         ArrayNode arrayNode = mapper.createArrayNode();
		         logger.info("openRxVOs.size()=============== "+openRxVOs.size());
		        for (int i = 0; i < openRxVOs.size(); i++) {
		        	 drawLine(xStart,yStartAndEnd,xEnd,yStartAndEnd,contentStream);
		        	 yStartAndEnd -= rowHeight;
				     arrayNode.add(openRxVOs.get(i));
				     if(yStartAndEnd < 150){
				    	 contentStream.drawImage(gpoc, 280, 50, 50, 50);
				    	 if(arrayNode.size() > 0){
					        	drawLine(xStart,yStartAndEnd,xEnd,yStartAndEnd,contentStream);
					        	drawLine(xStart,yStartAndEnd-20,xEnd,yStartAndEnd-20,contentStream);
					        	 map = createTruckRxColums(contentStream,arrayNode,yStart,yStartAndEnd-40);
					        	}
				    	 yStart = (Float) map.get(AppConstants.PAGE_HEIGHT);
				    	 contentStream = (PDPageContentStream) map.get(AppConstants.CONTENT_STREAM);
			        	 contentStream.close();
			        	  arrayNode = mapper.createArrayNode();
			               document.addPage(page);
			               page = new PDPage();
						  contentStream = new PDPageContentStream(document, page);
						  addHeader(contentStream, document,fromDate,AppConstants.TRUCK);
						  yStartAndEnd = 700;
						  yStart = 700;
				     }
		        }
		        
		        if(arrayNode.size() > 0){
	        		drawLine(xStart,yStartAndEnd,xEnd,yStartAndEnd,contentStream);
	            	drawLine(xStart,yStartAndEnd-20,xEnd,yStartAndEnd-20,contentStream);
		        map = createTruckRxColums(contentStream,arrayNode,yStart,yStartAndEnd-40);
	        	}
		     	map.put(AppConstants.CONTENT_STREAM, contentStream);
	            map.put(AppConstants.PD_PAGE, page);
			}
	      
	        }catch (IOException e) {
		        logger.error(
		                "Exception occured in createGraph in ReportsServiceImpl:",e);
		        		RMDWebErrorHandler.handleException(e);
				}
				catch (Exception e) {
				        logger.error(
				                "Exception occured in createGraph in ReportsServiceImpl:",e);
				   RMDWebErrorHandler.handleException(e);
				}
	        logger.info("createTruckOpenRxTable method end");
	        return map;
	}

	private Map<String, Object> createTruckRxColums(PDPageContentStream contentStream, ArrayNode openRxVOs,
			float height, float ystartAndEnd) throws IOException {
		// TODO Auto-generated method stub
		Map<String, Object> map = new HashMap<String, Object>();
		if(height > 650){
			contentStream.beginText();
	        contentStream.newLineAtOffset(280, height+5);//615
	        contentStream.setFont(PDType1Font.HELVETICA_BOLD,12);
	        contentStream.showText(AppConstants.OPENRX_CONTINUE);
	        contentStream.endText();
			}
		 float y = height;//610
	        //drawing columns the columns
	        float h = (float) ystartAndEnd+20;
	        float[] mlx = {40,90,345,500,572};
			for(int i = 0;i < mlx.length;i++){
				 drawLine(mlx[i],y,mlx[i],h,contentStream);
			}
	    //now add Headers to table
	        createText(42,height - 15,PDType1Font.HELVETICA_BOLD,8,AppConstants.RX_NUMBER,contentStream);
	        createText(92,height - 15,PDType1Font.HELVETICA_BOLD,8,AppConstants.OHV_RX_TITLE,contentStream);
	        createText(347,height - 15,PDType1Font.HELVETICA_BOLD,8,AppConstants.DELIVERED_DATE,contentStream);
	        createText(502,height - 15,PDType1Font.HELVETICA_BOLD,8,AppConstants.OPEN_TIME,contentStream);
	        map.put(AppConstants.CONTENT_STREAM, contentStream);
			map.put(AppConstants.PAGE_HEIGHT, h);
	        //insert Data
	        float data_y = height - 30;//580
	        float[] data_x = {42,92,347,502};
	        for(int i=0;i<openRxVOs.size();i++){
	 	       createText(data_x[0],data_y,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.WS_PARAM_CASEID_2).getTextValue()+"",contentStream);
	 	        if(openRxVOs.get(i).get(AppConstants.RXTITLE).getTextValue().length() > 80){
	 	        	 createText(data_x[1],data_y,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.RXTITLE).getTextValue().substring(0, 75),contentStream);
	 	        	 createText(data_x[1],data_y-8,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.RXTITLE).getTextValue().substring(75),contentStream);
	 	        	 
	 	        }else{
	 	        	createText(data_x[1],data_y,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.RXTITLE).getTextValue()+"",contentStream);
	 	        }
	 	        
				if (openRxVOs.get(i).get(AppConstants.RX_DELIVERDATE).size() > 40) {
					createText(data_x[2],data_y,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.RX_DELIVERDATE).getTextValue().substring(0, 40),contentStream);
					createText(data_x[2],data_y-8,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.RX_DELIVERDATE).getTextValue().substring(40),contentStream);
					
				}else {
					createText(data_x[2],data_y,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.RX_DELIVERDATE).getTextValue()+"",contentStream);
				}
				createText(data_x[3],data_y,PDType1Font.HELVETICA,6,openRxVOs.get(i).get(AppConstants.RX_OPENTIME).getTextValue()+"",contentStream);
	 	        data_y = data_y - 20;
	        }
		return map;
	}

	private  Map<String, Object> createParamsTable(PDPageContentStream contentStream,PDDocument document,PDPage page,JsonNode truckVO,float height,String fromDate) throws IOException, GenericAjaxException, RMDWebException {
		// TODO Auto-generated method stub
		 logger.info("createParamsTable method start");
		 Map<String, Object> map = new HashMap<String, Object>();
		 float margin = 40;
	        final float rowHeight = 20f;
	        final float tableWidth = (float) (page.getMediaBox().getWidth() - (2.0 * margin));
		 try{
		    String imagePath = ohvImgUrl + AppConstants.GPOC_LOGO;
			File gpoc_path = new File(imagePath);
			 PDImageXObject gpoc_logo = PDImageXObject.createFromFileByContent(gpoc_path, document);
		   JsonNode params = truckVO.get(AppConstants.PARAM_VARIABLES);
		   JsonNode eventsReports = truckVO.get("eventReports");
	        //draw the rows
	        float nexty = height-5;//610
	        ObjectMapper mapper = new ObjectMapper();
            ArrayNode arrayNode = mapper.createArrayNode();
            float f = nexty;
            if(height < 250){
            	 contentStream.drawImage(gpoc_logo, 280, 50, 50, 50);
            	 contentStream.close();
            	 document.addPage(page);
	               page = new PDPage();
				  contentStream = new PDPageContentStream(document, page);
				  contentStream.drawImage(gpoc_logo, 280, 50, 50, 50);
				  addHeader(contentStream, document,fromDate,AppConstants.TRUCK);
				  nexty = 700;
				  height = 705;
            }
            
            if(params !=null && params.size() > 0){
     	       createText(280,height,PDType1Font.HELVETICA_BOLD,12,AppConstants.STATS,contentStream);
     	      boolean flag = false;
	          for (int i = 0; i <params.size()+2; i++) {
	        	    contentStream.setLineWidth(1);
	 		        contentStream.moveTo(margin, nexty);
	 		        contentStream.lineTo(margin + tableWidth, nexty);
	 		        contentStream.closeAndStroke();
	 	            nexty -= rowHeight;
	 	            if(i <params.size()){
	                  arrayNode.add(params.get(i));
	 	            }
	            if(nexty < 150){
	            	   i = i-2;
	            	   arrayNode.remove(arrayNode.size()-1);
	            	   arrayNode.remove(arrayNode.size()-1);
		               contentStream.drawImage(gpoc_logo, 280, 50, 50, 50);
		               createColums(contentStream,nexty,height,arrayNode,flag);
		               flag = true;
		               contentStream.close();
		               arrayNode = mapper.createArrayNode();
		               document.addPage(page);
		               page = new PDPage();
					  contentStream = new PDPageContentStream(document, page);
					  contentStream.drawImage(gpoc_logo, 280, 50, 50, 50);
					  addHeader(contentStream, document,fromDate,AppConstants.TRUCK);
					  nexty = 700;
					  height = 705;
	            }
	        }
	       f =  createColums(contentStream,nexty,height,arrayNode,flag);
	       flag = true;
            }
	    map =  createTruckEvents(contentStream, page,document, f,eventsReports,fromDate);
	    document = (PDDocument) map.get(AppConstants.PD_DOCUMENT);
	    page = (PDPage) map.get(AppConstants.PD_PAGE);
		 }catch (IOException e) {
		        logger.error(
		                "Exception occured in createGraph in ReportsServiceImpl:",e);
		        		RMDWebErrorHandler.handleException(e);
				}
				catch (Exception e) {
				        logger.error(
				                "Exception occured in createGraph in ReportsServiceImpl:",e);
				   RMDWebErrorHandler.handleException(e);
				}
	      map.put(AppConstants.PD_DOCUMENT, document);
		  map.put(AppConstants.PD_PAGE, page);
		  logger.info("createParamsTable method end");
	        return map;
	}
	private float createColums(PDPageContentStream contentStream,float nexty,float height,ArrayNode params,boolean flag) throws IOException, GenericAjaxException, RMDWebException{
		 logger.info("createColums method start");
		if(height > 600 && flag == true){
		contentStream.beginText();
        contentStream.newLineAtOffset(280, height+5);//615
        contentStream.setFont(PDType1Font.HELVETICA_BOLD,12);
        contentStream.showText(AppConstants.STATS_CONTINUE);
        contentStream.endText();
		}
		float y = height-5;//610
        //drawing columns the columns
        float nextx = 50;
        int h = (int) nexty+20;
    	float[] mlx = {40,240,290,340,405,490,572};
    	try{
		for(int i = 0;i < mlx.length;i++){
			 drawLine(mlx[i],y,mlx[i],h,contentStream);
		}
    //now add Headers to table
        createText(42,height-20,PDType1Font.HELVETICA_BOLD,8,AppConstants.PARAMETER,contentStream);
        createText(242,height-20,PDType1Font.HELVETICA_BOLD,8,AppConstants.UNITS,contentStream);
        createText(292,height-20,PDType1Font.HELVETICA_BOLD,8,AppConstants.DAY,contentStream);
        createText(342,height-20,PDType1Font.HELVETICA_BOLD,8,AppConstants.THIRTY_DAYS,contentStream);
        createText(407,height-20,PDType1Font.HELVETICA_BOLD,8,AppConstants.LAST_MONTH,contentStream);
        createText(492,height-20,PDType1Font.HELVETICA_BOLD,8,AppConstants.LAST_QTR,contentStream);
        //insert data
        float data_y = height-35;
        float[] data_x = {42,242,292,342,407,492};
        if(params.size()>0){
        for(int i=0;i<params.size();i++){
        	if(!params.get(i).isNull()){
        	createText(data_x[0],data_y,PDType1Font.HELVETICA,6,params.get(i).get(AppConstants.PARAMNAME).getTextValue()+"",contentStream);
        	createText(data_x[1],data_y,PDType1Font.HELVETICA,6,params.get(i).get(AppConstants.PARAMUNIT).getTextValue()+"",contentStream);
        	createText(data_x[2],data_y,PDType1Font.HELVETICA,6,params.get(i).get(AppConstants.ONEDAYVALUE).getTextValue()+"",contentStream);
        	createText(data_x[3],data_y,PDType1Font.HELVETICA,6,params.get(i).get(AppConstants.THIRTYDAYAVGVALUE).getTextValue()+"",contentStream);
        	createText(data_x[4],data_y,PDType1Font.HELVETICA,6,params.get(i).get(AppConstants.LASTMONTHVALUE).getTextValue()+"",contentStream);
        	createText(data_x[5],data_y,PDType1Font.HELVETICA,6,params.get(i).get(AppConstants.LASTQTRVALUE).getTextValue()+"",contentStream);
 	        data_y = data_y - 20;
        	}
         }
        }
    	}catch (IOException e) {
	        logger.error(
	                "Exception occured in createGraph in ReportsServiceImpl:",e);
	        		RMDWebErrorHandler.handleException(e);
			}
			catch (Exception e) {
			        logger.error(
			                "Exception occured in createGraph in ReportsServiceImpl:",e);
			   RMDWebErrorHandler.handleException(e);
			}
        logger.info("createColums method end");
        return nexty;
	}
	
	private  Map<String, Object> createTruckEvents(PDPageContentStream contentStream,PDPage page,PDDocument document,float header,JsonNode eventsReports,String fromDate) throws IOException, GenericAjaxException, RMDWebException {
		    logger.info("createTruckEvents method start");
		    Map<String, Object> map = new HashMap<String, Object>();
	        float margin = 40;
	        final float tableWidth = (float) (page.getMediaBox().getWidth() - (2.0 * margin));
	        String imagePath = ohvImgUrl + AppConstants.GPOC_LOGO;
			File gpoc_logo = new File(imagePath);
			 PDImageXObject gpoc = PDImageXObject.createFromFileByContent(gpoc_logo, document);
	        try{
	        if (eventsReports.size() == 0) {
	        	 if(header < 150){
						 contentStream.close();
						 document.addPage(page);
			             page = new PDPage();
						  contentStream = new PDPageContentStream(document, page);
						  addHeader(contentStream, document,fromDate,AppConstants.MINE_SMALL);
						  header = 680;
						  contentStream.drawImage(gpoc, 280, 50, 50, 50);
				  }
	        	createText(280,header,PDType1Font.HELVETICA_BOLD,12,AppConstants.EVENTS,contentStream);
	        	map = createEmptyEventTable(contentStream, page, header,margin,AppConstants.TRUCK);
	        	 map.put(AppConstants.PD_DOCUMENT, document);
	        	return map;
	        	
			}else{
				 if(header < 250){
						 contentStream.close();
						 document.addPage(page);
			             page = new PDPage();
						  contentStream = new PDPageContentStream(document, page);
						  addHeader(contentStream, document,fromDate,AppConstants.MINE_SMALL);
						  header = 680;
						  contentStream.drawImage(gpoc, 280, 50, 50, 50);
				  }
				 createText(280,header,PDType1Font.HELVETICA_BOLD,12,AppConstants.EVENTS,contentStream);
				 
				 float xStart = 40;
				    float xEnd = 572;
			        float yStartAndEnd = (float)header-5;
			        float yStart = (float)header-5;
			        final float rowHeight = 20f;
			        ObjectMapper mapper = new ObjectMapper();
			         ArrayNode arrayNode = mapper.createArrayNode();
			         boolean flag = false;
			         for (int i = 0; i < eventsReports.size(); i++) {
			        	 drawLine(xStart,yStartAndEnd,xEnd,yStartAndEnd,contentStream);
			        	 yStartAndEnd -= rowHeight;
					     arrayNode.add(eventsReports.get(i));
					     if(yStartAndEnd < 150){
					    	 contentStream.drawImage(gpoc, 280, 50, 50, 50);
					    	 if(arrayNode.size() > 0){
						        	drawLine(xStart,yStartAndEnd,xEnd,yStartAndEnd,contentStream);
						        	drawLine(xStart,yStartAndEnd-20,xEnd,yStartAndEnd-20,contentStream);
						        	 map = createTruckEventColums(contentStream,arrayNode,yStart,yStartAndEnd-40,flag);
						        	 flag = true;
						        	}
					    	 yStart = (Float) map.get(AppConstants.PAGE_HEIGHT);
					    	 contentStream = (PDPageContentStream) map.get(AppConstants.CONTENT_STREAM);
				        	 contentStream.close();
				        	  arrayNode = mapper.createArrayNode();
				               document.addPage(page);
				               page = new PDPage();
							  contentStream = new PDPageContentStream(document, page);
							  addHeader(contentStream, document,fromDate,AppConstants.TRUCK);
							  contentStream.drawImage(gpoc, 280, 50, 50, 50);
							  yStartAndEnd = 700;
							  yStart = 700;
					    	 
					     }
			         }
			     	if(arrayNode.size() > 0){
		        		drawLine(xStart,yStartAndEnd,xEnd,yStartAndEnd,contentStream);
		            	drawLine(xStart,yStartAndEnd-20,xEnd,yStartAndEnd-20,contentStream);
			        map = createTruckEventColums(contentStream,arrayNode,yStart,yStartAndEnd-40,flag);
			        flag = true;
		        	}
			     	map.put(AppConstants.CONTENT_STREAM, contentStream);
		            map.put(AppConstants.PD_PAGE, page);
		            map.put(AppConstants.PD_DOCUMENT, document);
				
				
	        //draw the rows
	      
	       
	        
	        }
	        }catch (IOException e) {
		        logger.error(
		                "Exception occured in createGraph in ReportsServiceImpl:",e);
		        		RMDWebErrorHandler.handleException(e);
				}
				catch (Exception e) {
				        logger.error(
				                "Exception occured in createGraph in ReportsServiceImpl:",e);
				   RMDWebErrorHandler.handleException(e);
				}finally {
					  contentStream.close();
				}
			  map.put(AppConstants.PD_PAGE, page);
			  logger.info("createTruckEvents method end");
			  return map;
	      
	      
	}

	private Map<String, Object> createTruckEventColums(PDPageContentStream contentStream, ArrayNode eventsReports,
			float header, float yStartAndEnd,boolean flag) throws IOException {
		// TODO Auto-generated method stub
		 Map<String, Object> map = new HashMap<String, Object>();
		 
		 if(header > 650 && flag == true){
				contentStream.beginText();
		        contentStream.newLineAtOffset(280, header+5);//615
		        contentStream.setFont(PDType1Font.HELVETICA_BOLD,12);
		        contentStream.showText(AppConstants.EVENTS_CONTINUE);
		        contentStream.endText();
				}
		float y = header;
        //drawing columns the columns
        float h = (float) yStartAndEnd+20;
        float[] mlx = {40,90,120,360,465,572};
		for(int i = 0;i < mlx.length;i++){
			 drawLine(mlx[i],y,mlx[i],h,contentStream);
		}
		map.put(AppConstants.CONTENT_STREAM, contentStream);
		map.put(AppConstants.PAGE_HEIGHT, h);
		createText(42,header-10,PDType1Font.HELVETICA_BOLD,6,AppConstants.EVENT_NUMBER,contentStream);
		createText(92,header-10,PDType1Font.HELVETICA_BOLD,6,AppConstants.SUB_ID,contentStream);
		createText(122,header-10,PDType1Font.HELVETICA_BOLD,6,AppConstants.DESCRIPTION,contentStream);
		createText(362,header-10,PDType1Font.HELVETICA_BOLD,6,AppConstants.OCCUR_TIME_TRUCK,contentStream);
		createText(467,header-10,PDType1Font.HELVETICA_BOLD,6,AppConstants.RESET_TIME,contentStream);
        //insert data
        float data_y = header-30;//580
        float[] data_x = {42,92,122,362,467};
        for(int i=0;i<eventsReports.size();i++){
        	createText(data_x[0],data_y,PDType1Font.HELVETICA,6,eventsReports.get(i).get(AppConstants.EVENTNUMBER).getTextValue()+"",contentStream);
        	createText(data_x[1],data_y,PDType1Font.HELVETICA,6,eventsReports.get(i).get(AppConstants.SUBID).getTextValue()+"",contentStream);
 	       if(eventsReports.get(i).get(AppConstants.FLTDESCRIPTION).getTextValue().length() > 80){
 	    	   createText(data_x[2],data_y,PDType1Font.HELVETICA,6,eventsReports.get(i).get(AppConstants.FLTDESCRIPTION).getTextValue().substring(0, 80),contentStream);
	        	createText(data_x[2],data_y-8,PDType1Font.HELVETICA,6,eventsReports.get(i).get(AppConstants.FLTDESCRIPTION).getTextValue().substring(80),contentStream);
 	        }else{
 	        	createText(data_x[2],data_y,PDType1Font.HELVETICA,6,eventsReports.get(i).get(AppConstants.FLTDESCRIPTION).getTextValue()+"",contentStream);
 	        }
 	      createText(data_x[3],data_y,PDType1Font.HELVETICA,6,eventsReports.get(i).get(AppConstants.OCCURTIME).getTextValue()+"",contentStream);
 	     createText(data_x[4],data_y,PDType1Font.HELVETICA,6,eventsReports.get(i).get(AppConstants.RESETTIME).getTextValue()+"",contentStream);
 	        data_y = data_y - 20;
        }
		return map;
	}
}

class LineChartColKey implements Comparable<Object> {

	String key;

	public LineChartColKey(String str) {
	key = str;
	}

	public String toString() {
	return key;
	}

	public int compareTo(Object colKey) {
	return 1;
	}
	}
