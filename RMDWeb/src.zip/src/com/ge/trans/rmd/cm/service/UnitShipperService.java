package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.concurrent.Future;

import com.ge.trans.rmd.cm.valueobjects.InfancyUnitBean;
import com.ge.trans.rmd.cm.valueobjects.ShipUnitDataVO;
import com.ge.trans.rmd.cm.valueobjects.UnitShipDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.UnitShippersVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.pp.beans.AssetBean;

public interface UnitShipperService {

	/**
	 * @Author :
	 * @return :List<UnitShippersVO>
	 * @param :UnitShipDetailsVO objDetailsVO,String timeZone
	 * @throws :RMDWebException
	 * @Description: This Method Fetches the list of Units to be shipped.
	 * 
	 */

	public List<UnitShippersVO> getUnitsToBeShipped(
			UnitShipDetailsVO objDetailsVO,String timeZone,String defaultTimezone) throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<UnitShippersVO>
	 * @param :UnitShipDetailsVO objDetailsVO,String timeZone
	 * @throws :RMDWebException
	 * @Description: This Method Fetches the list of Units which are already
	 *               Shipped.
	 * 
	 */

	public List<UnitShippersVO> getLastShippedUnits(
			UnitShipDetailsVO objDetailsVO,String timeZone,String defaultTimezone) throws RMDWebException;

	/**
	 * @Author :
	 * @return :String
	 * @param :List<UnitShippersVO> arlShipperUnits
	 * @throws :RMDWebException
	 * @Description: This Method Fetches the list of Units to be shipped.
	 * 
	 */

	public String updateUnitsToBeShipped(List<UnitShippersVO> arlShipperUnits,String timeZone)
			throws RMDWebException;
	
	/**
	 * @Author :
	 * @return :String
	 * @param :List<UnitShippersVO> arlShipperUnits
	 * @throws :RMDWebException
	 * @Description: This Method Fetches the list of ASSET NUMBER which yrt to be shipped.
	 * 
	 */
	public List<String> getAssetNumbersForShipUnits(AssetBean assetBean) throws RMDWebException,Exception;
	/**
	 * @Author :
	 * @return :List<ShipUnitDataVO> arlShipperUnits
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This Method Fetches the list of ASSET NUMBERS shipped.
	 * 
	 */
	public Future<List<ShipUnitDataVO>> getShipUnitDetails()  throws RMDWebException;
	/**
	 * @Author :
	 * @return :List<ShipUnitDataVO>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This Method Fetches the infancy failure units for past 180 days.
	 * 
	 */
	public Future<List<InfancyUnitBean>> getInfancyFailureDetails() throws RMDWebException;

}
