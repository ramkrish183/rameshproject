package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.concurrent.Future;

import com.ge.trans.rmd.cm.valueobjects.CaseTrendBean;
import com.ge.trans.rmd.cm.valueobjects.CaseTrendDataVO;
import com.ge.trans.rmd.cm.valueobjects.CaseTrendStatisticsBean;
import com.ge.trans.rmd.cm.valueobjects.OpenRXBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.GenNotesVO;

public interface CaseTrendService {
	/**
	 * @Author:
	 * @param:
	 * @return:List<CaseTrendDataVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching delivered open rx count for past 8 days.
	 */
	public Future<List<OpenRXBean>> getOpenRXCount() throws RMDWebException;
	/**
	 * @Author:
	 * @param:
	 * @return:List<CaseTrendDataVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching created case type count for past 24 hours.
	 */
	public Future<CaseTrendBean> getCaseTrend() throws RMDWebException;
	/**
	 * @Author:
	 * @param:
	 * @return:List<CaseTrendDataVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching created case type count for past 7 days.
	 */
	public Future<CaseTrendStatisticsBean> getCaseTrendStatistics() throws RMDWebException;
	/**
	 * @Author:
	 * @param:
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching general note having the flag as Y.
	 */
	public List<GenNotesVO> getGeneralNotesDetails() throws RMDWebException;
}
