package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.beans.FLeetViewBean;
import com.ge.trans.rmd.cm.service.FleetServiceCallWrapper;
import com.ge.trans.rmd.cm.service.FleetViewService;
import com.ge.trans.rmd.cm.valueobjects.FleetViewVO;
import com.ge.trans.rmd.cm.valueobjects.ToolTipVO;
import com.ge.trans.rmd.common.beans.FavoriteFilterBean;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.km.mvc.controller.RxController;
import com.ge.trans.rmd.km.util.KMConstants;
import com.ge.trans.rmd.services.assets.valueobjects.AssetLocatorResponseType;
import com.ge.trans.rmd.utilities.AppSecUtil;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;


@Controller
public class FleetViewController extends RMDBaseController {
	private final RMDWebLogger logger = RMDWebLogger.getLogger(getClass());
	 
	@Autowired
	FleetViewService fleetViewObj;
	@Autowired
	private ApplicationContext appContext; 
	@Autowired
	private RxController rxController;
	@Autowired
	private AssetOverviewController assetOverviewController;
	@Autowired
	private FleetServiceCallWrapper fleetCallWrapper;
	@Autowired
	private AuthorizationService authService;
	
	@RequestMapping(AppConstants.REQ_URI_FLEET)
	public ModelAndView showFleetInfo (final HttpServletRequest request, final Model model) throws GenericAjaxException, RMDWebException {
		logger.debug("FleetViewController : Inside showFleetInfo() method:::START");
		request.setAttribute(AppConstants.FILTERFLAG, request.getParameter(AppConstants.FLAG));
		final HttpSession session=request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		/*For timezone issue*/
		final String defaultTimezone=(String)request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone=RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone());
		/*For timezone issue*/
		FLeetViewBean fleetViewBean=new FLeetViewBean();
		Map<String, FleetViewVO> collectiveResponse = null;
		String numDays=null;
		
		try{
				
			Map<String, String> componentList = new HashMap<String, String>();
			componentList.put(AppConstants.RX_FILTER_URGENCY_FLEET_PRIVILEGE,
					AppConstants.RX_FILTER_URGENCY);
			componentList.put(AppConstants.RX_FILTER_ESTREPTIME_FLEET_PRIVILEGE,
					AppConstants.RX_FILTER_ESTREPTIME);
			componentList.put(AppConstants.RX_FILTER_RXTITLES_FLEET_PRIVILEGE,
					AppConstants.RX_FILTER_APPROVEDRXTITLES);
			/*For case Type*/
			componentList.put(
					AppConstants.FILTER_CASETYPE_FLEET_PRIVILEGE,
					AppConstants.RX_FILTER_CASETYPE);
			/*For case Type*/
			//For Fleet
			componentList.put(AppConstants.RX_FILTER_FLEET_FLEET_PRIVILEGE,
					AppConstants.RX_FILTER_FLEET);
			//For Model
			componentList.put(AppConstants.RX_FILTER_MODEL_FLEET_PRIVILEGE,
					AppConstants.RX_FILTER_MODEL);
			componentList.put(AppConstants.DEFAULT_FILTER_FLEET_PRIVILEGE,
					AppConstants.DEFAULT_FILTER);
			componentList.put(AppConstants.RX_FILTER_ACTIONABLE_RXTYPE_FLEET_PRIVILEGE,
					AppConstants.RX_FILTER_ACTIONABLE_RXTYPE);
			
			fleetViewBean.setUserLanguage(userVO.getStrLanguage());
			fleetViewBean.setCustomerId(userVO.getCustomerId());
			fleetViewBean.setKpiName(AppConstants.DEFAULT_KPI_NAME);
			fleetViewBean.setNoteType(AppConstants.LOCOMOTIVE_NOTE);
			fleetViewBean.setTimezone(applicationTimezone);
			if(null!=userVO.getProducts()&& !userVO.getProducts().isEmpty()){
			fleetViewBean.setProducts(userVO.getProducts());
			}
			getComponentPrivilege(componentList,userVO,request);
			//adding for pagination
			request.setAttribute(
					AppConstants.FLEET_DEFAULT_RECORDS,
					findNumberOfRecords(AppConstants.FLEET_TABLE_DEFAULT_RECORDS));
			numDays = fleetCallWrapper.getKpiDaysLookupValue();
			//Added for favorite filter story
			Map<String,Object> componentMap =new HashMap<String,Object>();
			componentMap.put(AppConstants.URGENCY_FAV_FILTER, request.getAttribute(AppConstants.RX_FILTER_URGENCY));
			componentMap.put(AppConstants.EST_REPAIR_TIME, request.getAttribute(AppConstants.RX_FILTER_ESTREPTIME));
			componentMap.put(AppConstants.RX_TITLE, request.getAttribute(AppConstants.RX_FILTER_APPROVEDRXTITLES));
			componentMap.put(AppConstants.COMPONENT_CASE_TYPE, request.getAttribute(AppConstants.RX_FILTER_CASETYPE));
			componentMap.put(AppConstants.COMPONENT_FLEET, request.getAttribute(AppConstants.RX_FILTER_FLEET));
			componentMap.put(AppConstants.COMPONENT_MODEL, request.getAttribute(AppConstants.RX_FILTER_MODEL));
			componentMap.put(AppConstants.RX_ACTIONABLE_TYPE, request.getAttribute(AppConstants.RX_FILTER_ACTIONABLE_RXTYPE));
			String favoriteFilters=getFavoriteFilters(AppConstants.FLEETS,userVO,componentMap);
			if(null!=favoriteFilters && !favoriteFilters.equals(AppConstants.EMPTY_STRING) && (Boolean)request.getAttribute(AppConstants.DEFAULT_FILTER)){
				request.setAttribute(AppConstants.FAVORITE_FILTER, favoriteFilters);
			}
//			else{
//				if(null!=userVO.getProducts()&& !userVO.getProducts().isEmpty()){
//				collectiveResponse = fleetViewObj.getFleetView(fleetViewBean);
//				}
//				request.setAttribute(AppConstants.FLEET_VIEW_RESPONSE, collectiveResponse);
//				
//			}
			//added for Fleet refresh MISC change Phase II - Sprint 6 Start
			final String fleetRefreshTime = authService
					.getLookUpValueForName(AppConstants.FLEET_REFRESH_TIME);
			request.setAttribute(AppConstants.FLEET_REFRESH_TIME_VAL,
					fleetRefreshTime);
			//added for Fleet refresh MISC change Phase II - Sprint 6 End
		}catch(Exception e){
 			logger.error("FleetViewController :: Exception occured in showFleetInfo() method "+e.getMessage(), e);
		}
		logger.debug("FleetViewController : Inside showFleetInfo() method:::END");
		//Added for favorite filter story
		request.setAttribute(AppConstants.SELECTED_TAB, AppConstants.FLEETS);
		request.setAttribute(AppConstants.KPI_NUM_DAYS, numDays);
		return new ModelAndView(AppConstants.VIEW_FLEET);
	}

	/**
	 * Ajax call controller method to get filtered fleets for given urgency and
	 * estimated repair time
	 * 
	 * @param request
	 * @param urgency
	 * @param estRepTime
	 * @return Map<String, FleetViewVO> 
	 */
	@RequestMapping(method = RequestMethod.POST,value=AppConstants.REQ_URI_FLEET_FILTER)
	public @ResponseBody
	List<FleetViewVO> showFilteredFleetInfo(
			final HttpServletRequest request,
			@RequestParam(value = AppConstants.QUERY_PARAM_URGENCY, required = true) final String urgency,
			@RequestParam(value = AppConstants.QUERY_PARAM_ESTREPTIME, required = true) final String estRepTime,
			@RequestParam(value = AppConstants.QUERY_PARAM_RX_IDS, required = true) final String rxIds,
			@RequestParam(value = AppConstants.QUERY_PARAM_FAV_FILTER) final String favFilter,
			@RequestParam(value = AppConstants.CASE_TYPE) final String caseType,
			@RequestParam(value = AppConstants.FLEET) final String fleet,
			@RequestParam(value = AppConstants.MODEL) final String model,
			@RequestParam(value = AppConstants.RX_TYPE) final String rxType,
			@RequestParam(value = AppConstants.QUERY_PARAM_FILTER_CHANGED) final boolean filterChanged) throws GenericAjaxException, RMDWebException {
		logger.debug("FleetViewController : Inside showFilteredFleetInfo() method:::START");
		request.setAttribute(AppConstants.FILTERFLAG,
				request.getParameter(AppConstants.FLAG));
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		/* For timezone issue */
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		/* For timezone issue */
		FLeetViewBean fleetViewBean = new FLeetViewBean();
		FavoriteFilterBean favFilterBean=new FavoriteFilterBean();
		HashMap<String,String> columnTypes=new HashMap<String,String>();		
		HashMap<String,String> columnValues=new HashMap<String,String>();
		favFilterBean.setScreenName(AppConstants.FLEETS);
		Long linkUserRoleSeqId=null;
		Map<String, FleetViewVO> collectiveResponse = null;
		List<FleetViewVO> arlFleetViewVO=null;
		String filterId="";
		try {
			fleetViewBean.setUserLanguage(userVO.getStrLanguage());
			fleetViewBean.setCustomerId(userVO.getCustomerId());
			fleetViewBean.setKpiName(AppConstants.DEFAULT_KPI_NAME);
			fleetViewBean.setNoteType(AppConstants.LOCOMOTIVE_NOTE);
			fleetViewBean.setTimezone(applicationTimezone);
			fleetViewBean.setLastFalult(false);
			if(null!=userVO.getProducts()&& !userVO.getProducts().isEmpty()){
			fleetViewBean.setProducts(userVO.getProducts());
			}
			if (null != urgency
					&& !RMDCommonConstants.EMPTY_STRING.equals(urgency)){
				fleetViewBean.setUrgencies(EsapiUtil.stripXSSCharacters(urgency));
				//Adding urgency criteria information for favorite filter
				columnTypes.put(AppConstants.URGENCY_FAV_FILTER, AppConstants.TEXT);
				columnValues.put(AppConstants.URGENCY_FAV_FILTER, EsapiUtil.stripXSSCharacters(urgency));
				}
			if (null != estRepTime
					&& !RMDCommonConstants.EMPTY_STRING.equals(estRepTime)){
				fleetViewBean.setEstRepTime(EsapiUtil.stripXSSCharacters(estRepTime));
				//Adding Estimated repair time criteria information for favorite filter
				columnTypes.put(AppConstants.EST_REPAIR_TIME, AppConstants.NUMBER);
				columnValues.put(AppConstants.EST_REPAIR_TIME, EsapiUtil.stripXSSCharacters(estRepTime));
			}
			
			if (null != rxType
					&& !RMDCommonConstants.EMPTY_STRING.equals(rxType)&&!AppConstants.ZERO.equals(rxType)){
				fleetViewBean.setActionableRxType(EsapiUtil.stripXSSCharacters(rxType));
				//Adding rxType criteria information for favorite filter
				columnTypes.put(AppConstants.RX_TYPE_FAV_FILTER, AppConstants.NUMBER);
				columnValues.put(AppConstants.RX_TYPE_FAV_FILTER, EsapiUtil.stripXSSCharacters(rxType));
				}
			if (null != rxIds
					&& !RMDCommonConstants.EMPTY_STRING.equals(rxIds)){
				fleetViewBean.setRxIds(EsapiUtil.stripXSSCharacters(rxIds));
				//Adding RX Ids criteria information for favorite filter
				columnTypes.put(AppConstants.RX_TITLE, AppConstants.NUMBER);
				columnValues.put(AppConstants.RX_TITLE, EsapiUtil.stripXSSCharacters(rxIds));
			}
			
			if (null != caseType
					&& !RMDCommonConstants.EMPTY_STRING.equals(caseType)){
				fleetViewBean.setCaseType(EsapiUtil.stripXSSCharacters(caseType));
				//Adding Case Type criteria information for favorite filter
				columnTypes.put(AppConstants.COMPONENT_CASE_TYPE, AppConstants.NUMBER);
				columnValues.put(AppConstants.COMPONENT_CASE_TYPE, EsapiUtil.stripXSSCharacters(caseType));
			}
			if (null != fleet
					&& !RMDCommonConstants.EMPTY_STRING.equals(fleet)){
				fleetViewBean.setFleet(EsapiUtil.stripXSSCharacters(fleet));
				//Adding Case Type criteria information for favorite filter
				columnTypes.put(AppConstants.COMPONENT_FLEET, AppConstants.NUMBER);
				columnValues.put(AppConstants.COMPONENT_FLEET, EsapiUtil.stripXSSCharacters(fleet));
			}
			if (null != model
					&& !RMDCommonConstants.EMPTY_STRING.equals(model)){
				fleetViewBean.setModel(EsapiUtil.stripXSSCharacters(model));
				//Adding Case Type criteria information for favorite filter
				columnTypes.put(AppConstants.COMPONENT_MODEL, AppConstants.NUMBER);
				columnValues.put(AppConstants.COMPONENT_MODEL, EsapiUtil.stripXSSCharacters(model));
			}
			
			if (validateUserInputForRx(fleetViewBean,request).isEmpty()) {
				//Call generic favorite filter method if atleast one column available
				if(filterChanged){
				if (!columnTypes.isEmpty()) {
					favFilterBean.setColumnType(columnTypes);
					favFilterBean.setColumnValue(columnValues);
				}
				filterId=getFilterId(AppConstants.FLEETS, userVO);
				if(null!=filterId && !filterId.equals(AppConstants.EMPTY_STRING)){
				favFilterBean.setFilterId(filterId);
				}
				favFilterBean.setFavFilterFlag(favFilter + "");
				linkUserRoleSeqId = getLinkUsrRoleSeqId(
						userVO.getRolesVOLst(), userVO.getRoleId());
				favFilterBean.setLinkUserRoleSeqId(linkUserRoleSeqId);
				callFavoriteFilter(favFilterBean);
				setFavoriteFiltersToUserVO(AppConstants.FLEETS,userVO,favFilterBean,EsapiUtil.stripXSSCharacters(favFilter)+"");
				}
				if(null!=userVO.getProducts()&& !userVO.getProducts().isEmpty()){
				collectiveResponse = fleetViewObj
						.getFilteredFleetView(fleetViewBean, userVO.getCustomerId());
				arlFleetViewVO=new ArrayList<FleetViewVO>(collectiveResponse.values());
				Collections.sort(arlFleetViewVO, new Comparator<FleetViewVO>() {
					public int compare(FleetViewVO obj1,
							FleetViewVO obj2) {
						int result = 0;
						String assetNumber1 = obj1.getAssetNumber();
						String assetNumber2 = obj2.getAssetNumber();
						if (org.apache.commons.lang.StringUtils
								.isNumeric(assetNumber1)
								&& org.apache.commons.lang.StringUtils
										.isNumeric(assetNumber2)) {

							int assetNumber1int = Integer.parseInt(obj1
									.getAssetNumber());
							int assetNumber2int = Integer.parseInt(obj2
									.getAssetNumber());
							if (assetNumber1int == assetNumber2int) {
								result = 0;
							}
							result = (assetNumber1int < assetNumber2int) ? -1 : 1;

						} else {
							int assetNumber1int = Integer.parseInt(assetNumber1
									.replaceAll("[^0-9]", ""));
							int assetNumber2int = Integer.parseInt(assetNumber2
									.replaceAll("[^0-9]", ""));
							if (assetNumber1int == assetNumber2int) {
								if (!org.apache.commons.lang.StringUtils
										.isNumeric(assetNumber1)
										&& !org.apache.commons.lang.StringUtils
												.isNumeric(assetNumber2)) {
									result = assetNumber1
											.compareToIgnoreCase(assetNumber2);
								} else {

									result = (org.apache.commons.lang.StringUtils
											.isNumeric(assetNumber1)) ? -1 : 1;
								}
							} else {
								result = (assetNumber1int < assetNumber2int) ? -1
										: 1;
							}
						}

						return result;
					}

					

				});
				
				}
			}
			else
				collectiveResponse.put(AppConstants.INVALID_URGENCY_ESTREPTIME,
						null);


		} catch (Exception e) {
			logger.error("FleetViewController :: Exception occured in showFilteredFleetInfo() method "+e.getMessage());
			
		}
		logger.debug("FleetViewController : Inside showFilteredFleetInfo() method:::END");

		return arlFleetViewVO;
	}
	
	
	@RequestMapping(value=AppConstants.REQ_URI_FLEET_SAVENOTES,method = RequestMethod.POST)
	public @ResponseBody Map<String, String> fleetSaveNotes(final HttpServletRequest request) throws RMDWebException
	{
		final Map<String, String> resultMap = new HashMap<String, String>();
		final String assetNumber=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String groupName=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.WS_PARAM_ASSTGRP));
		final String customerId=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REQ_PARAM_CUSID));
		final String notes=EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REQ_PARAM_ASSTNOTES));//"Compose note...";
		final NotesBean notesBean = new NotesBean();
		String returnStr=AppConstants.FAILURE;

		try {
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			if (AppConstants.EMPTY_STRING.equals(notes)
					|| notes.equals(AppConstants.FLEET_DEFAULT_MSG)) {
				resultMap.put(AppConstants.FLEET_NOTES_MESSAGE, appContext
						.getMessage(AppConstants.FLEET_NOTES_ERR, null,
								userVO.getLocale()));
			} else if (RMDCommonUtility.isSpecialCharactersFound(notes)) {
				resultMap.put(AppConstants.FLEET_NOTES_MESSAGE, appContext
						.getMessage(AppConstants.FLEET_NOTES_ERR_SPL_CHAR,
								null, userVO.getLocale())+appContext
								.getMessage(AppConstants.FLEET_NOTES_ERR_SPL_MESG,
										null, userVO.getLocale()) );
			} else {

				final String htmlString = AppSecUtil.htmlEscaping(notes);
				notesBean.setAssetNumber(assetNumber);
				notesBean.setNoteDescription(htmlString);
				notesBean.setUserFirstName(userVO.getStrFirstName());
				notesBean.setUserLastName(userVO.getStrLastName());
				notesBean.setUserId(userVO.getUserId());
				notesBean.setUserLanguage(userVO.getStrUserLanguage());
				notesBean.setCustomerId(customerId);
				notesBean.setAssetGroup(groupName);

				returnStr = EsapiUtil.stripXSSCharacters(fleetViewObj.fleetSaveNotes(notesBean));
				resultMap.put(AppConstants.MESSAGE, returnStr);
			}
		}
        catch (Exception ex) {
			logger.error("Exception occured in fleetSaveNotes method ", ex);
			RMDWebErrorHandler.handleException(ex);
			
		}

		return resultMap;
	}
	
	
	
	@RequestMapping(value=AppConstants.REQ_URI_FLEET_VIEW_TOOLTIP,method = RequestMethod.GET)
	public @ResponseBody Map<String, List<ToolTipVO>> fleetTooltip(final HttpServletRequest request) throws RMDWebException
	{
		logger.debug("FleetViewController :: fleetTooltip()");
		Map<String, List<ToolTipVO>> resultMap = new HashMap<String, List<ToolTipVO>>();
		final HttpSession session=request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		FLeetViewBean fleetViewBean;
		try{
			fleetViewBean=new FLeetViewBean();
			//Added User language for RxMultilingual Title and locoimpact 
			fleetViewBean.setUserLanguage(userVO.getStrUserLanguage());
			fleetViewBean.setCustomerId(userVO.getCustomerId());
			if(null!=userVO.getProducts()&& !userVO.getProducts().isEmpty()){
				fleetViewBean.setProducts(userVO.getProducts());
				resultMap=fleetViewObj.getCases(fleetViewBean);
				}
			

		}
        catch (Exception ex) {
			logger.error("Exception occured in fleetTooltip method ", ex);
			RMDWebErrorHandler.handleException(ex);
			
		}
		request.setAttribute(AppConstants.RESULTMAP, resultMap);
		return resultMap;
	}
	public Map<String, String> validateUserInputForRx(final FLeetViewBean fleetBean, HttpServletRequest request){
		final Map<String, String> result = new HashMap<String, String>();
		try{
			
			 // urgency of repair
			 if(null != fleetBean.getUrgencies() && !fleetBean.getUrgencies().isEmpty()
					 && !fleetBean.getUrgencies().equalsIgnoreCase(KMConstants.SELECT)
						&& !fleetBean.getUrgencies().equalsIgnoreCase(AppConstants.UNDEFINED)){
				 // webservice call
				 final 		 Map<String, String> urgencyRepairMap = rxController.getUrgencyOfRepair();
				//convert map to list
				 final 		 List<String> urgencyRepairList = new ArrayList<String>(urgencyRepairMap.keySet()); 
				// input provided by user
				 final 		 List<String> userInputList = new ArrayList<String>(Arrays.asList(fleetBean.getUrgencies().split(",")));
				// compare lists
				if(!AppSecUtil.compareLists(urgencyRepairList, userInputList)){
					result.put(AppConstants.CREATCASE_URGOFREPAIR, KMConstants.INVALID);
				}
			 }
			 //estimated repair time
				if (null != fleetBean.getEstRepTime() && !fleetBean.getEstRepTime().isEmpty()
						&& !fleetBean.getEstRepTime().equalsIgnoreCase(KMConstants.SELECT)
						&& !fleetBean.getEstRepTime().equalsIgnoreCase(AppConstants.UNDEFINED)) {
					final 	Map<String, String> repairMap = rxController.getEstRepairTime();
					// convert map to list
					final 	List<String> repairList = new ArrayList<String>(repairMap.keySet());
					// input provided by user
					final 	String userInput = fleetBean.getEstRepTime();
					
					if(! AppSecUtil.isListContainsValue(userInput, repairList)){
						 result.put(KMConstants.ESTIMATED_REPAIR, KMConstants.INVALID);
					 }
				}
				//System.out.println("fleetBean.getActionableRxType().isEmpty() >>>> "+fleetBean.getActionableRxType());
			// Rx Title
			if (null != fleetBean.getRxIds()
					&& !fleetBean.getRxIds().isEmpty() && fleetBean.getActionableRxType().isEmpty() 
					&& !fleetBean.getRxIds().equalsIgnoreCase(KMConstants.SELECT)
					&& !fleetBean.getRxIds().equalsIgnoreCase(AppConstants.UNDEFINED)) {
				// webservice call
				final Map<String, String> rxTitleMap = rxController.getApprovedRxTitles(request);
				// convert map to list
				final List<String> rxTitleList = new ArrayList<String>(
						rxTitleMap.keySet());
				// input provided by user
				final List<String> userInputList = new ArrayList<String>(
						Arrays.asList(fleetBean.getRxIds().split(",")));
				// compare lists
				if (!AppSecUtil.compareLists(rxTitleList, userInputList)) {
					result.put(AppConstants.RXTITLE,
							KMConstants.INVALID);
				}
			}
			
			if (null != fleetBean.getCaseType() && !fleetBean.getCaseType().isEmpty()
					&& !fleetBean.getCaseType().equalsIgnoreCase(KMConstants.SELECT)
					&& !fleetBean.getCaseType().equalsIgnoreCase(AppConstants.UNDEFINED)) {
				// webservice call
				final Map<String, String> caseTypeMap = rxController
						.getCaseType();
				// convert map to list
				final List<String> caseTypeList = new ArrayList<String>(
						caseTypeMap.keySet());
				// input provided by user
				final List<String> userInputList = new ArrayList<String>(
						Arrays.asList(fleetBean.getCaseType().split(AppConstants.COMMA)));
				// compare lists
				if (!AppSecUtil.compareLists(caseTypeList, userInputList)) {
					result.put(AppConstants.ERR_CASE_TYPE, KMConstants.INVALID);
				}
			}
			if (null != fleetBean.getFleet()&& !fleetBean.getFleet().isEmpty()
					&& !fleetBean.getFleet().equalsIgnoreCase(KMConstants.SELECT)
					&& !fleetBean.getFleet().equalsIgnoreCase(AppConstants.UNDEFINED)) {
				// webservice call
				final Map<String, String> fleetMap = assetOverviewController.getFleets(request);
				// convert map to list
				final List<String> fleetList = new ArrayList<String>(
						fleetMap.keySet());
				// input provided by user
				final List<String> userInputList = new ArrayList<String>(
						Arrays.asList(fleetBean.getFleet().split(AppConstants.COMMA)));
				// compare lists
				if (!AppSecUtil.compareLists(fleetList, userInputList)) {
					result.put(AppConstants.ERR_FLEET, KMConstants.INVALID);
				}
			}
			 
			if (null != fleetBean.getModel()&& !fleetBean.getModel().isEmpty()
					&& !fleetBean.getModel().equalsIgnoreCase(KMConstants.SELECT)
					&& !fleetBean.getModel().equalsIgnoreCase(AppConstants.UNDEFINED)) {
				// webservice call
				final Map<String, String> modelMap = assetOverviewController.getModelsForFilter(request);
				// convert map to list
				final List<String> modelList = new ArrayList<String>(
						modelMap.keySet());
				// input provided by user
				final List<String> userInputList = new ArrayList<String>(
						Arrays.asList(fleetBean.getModel().split(AppConstants.COMMA)));
				// compare lists
				if (!AppSecUtil.compareLists(modelList, userInputList)) {
					result.put(AppConstants.ERR_FLEET, KMConstants.INVALID);
				}
			}
			 
			}catch (Exception exception) {
				logger.error(KMConstants.RX_VALIDATION_MESSAGE + exception.getMessage());
			}
		return result;
	}
	
	
	/**
	 * @Description:This method is used for calling the serviceImpl in turn
	 *                   which will call webservices and bring the records for
	 *                   download
	 * @return: void
	 * @param:HttpServletRequest request,HttpServletResponse response,Locale
	 *                           locale
	 */
	@RequestMapping(value = AppConstants.EXPORT_DATA_FLEETS, method = RequestMethod.POST)
	public void exportDataFleets(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws IOException {
		logger.debug("FleetViewController : Inside exportToCSVFleets() method:::START");
		request.setAttribute(AppConstants.FILTERFLAG,
				request.getParameter(AppConstants.FLAG));
		
		List<FleetViewVO> collectiveResponse = null;
		String urgency = RMDCommonConstants.EMPTY_STRING;
		String estRepTime = RMDCommonConstants.EMPTY_STRING;
		String rxIds=RMDCommonConstants.EMPTY_STRING;
		String caseType=RMDCommonConstants.EMPTY_STRING;
		String fleet=RMDCommonConstants.EMPTY_STRING;
		String model=RMDCommonConstants.EMPTY_STRING;
		
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		try {
			objServletOutputStream = response.getOutputStream();
			urgency = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.QUERY_PARAM_URGENCY));
			estRepTime = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.QUERY_PARAM_ESTREPTIME));
			rxIds=EsapiUtil.stripXSSCharacters(request
			.getParameter(AppConstants.QUERY_PARAM_RX_IDS));
			caseType=EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.ID_CASE_TYPE));
			fleet=EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.ID_FLEET));
			model=EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.ID_MODEL));
			
			collectiveResponse=showFilteredFleetInfo(request, urgency, estRepTime, rxIds,"",caseType,fleet,model,"",false);
			//calling convertToCSVFleets method to convert the listCaseResponseVO to comma seperated value	
			csvContent = convertToCSVFleets(collectiveResponse, locale);

			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.FLEETS_EXPORT_FILENAME);
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes(AppConstants.ENCODED_TYPE_ISO_8859_1));
			objBufferedInputStream = new BufferedInputStream(objByteArrayInputStream);

			objBufferedOutputStream = new BufferedOutputStream(objServletOutputStream);

			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0, byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}

		} catch (Exception e) {
			logger.error("FleetViewController :: Exception occured in exportToCSVFleets() method "+e.getMessage());
			
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}

	/**
	 * @Description:This method is used for looping through the list of fleet
	 *                   records and will covert to csv content
	 * @return: String
	 * @param:collectiveResponse,Locale locale
	 */
	private String convertToCSVFleets(
			List<FleetViewVO> collectiveResponse, Locale locale) {
		StringBuffer strBufferFleets = new StringBuffer();
		String csvContent = null;
		try {
			strBufferFleets.append(appContext.getMessage(
					AppConstants.FLEETS_HEADER, null, locale));
			strBufferFleets.append(RMDCommonConstants.NEWLINE);
			for (Iterator iterator = collectiveResponse.iterator(); iterator
					.hasNext();) {
				FleetViewVO objFleetViewVO = (FleetViewVO) iterator.next();
				strBufferFleets.append(RMDCommonConstants.EMPTY_STRING
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ RMDCommonUtil.removeHtmlandNullValues(objFleetViewVO.getCustomerId())
						+ RMDCommonConstants.COMMMA_SEPARATOR);
				strBufferFleets.append(RMDCommonUtil.removeHtmlandNullValues(objFleetViewVO.getAssetGrpName())
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ RMDCommonUtil.removeHtmlandNullValues(objFleetViewVO.getAssetNumber())
						+ RMDCommonConstants.COMMMA_SEPARATOR);
				strBufferFleets.append(RMDCommonUtil.removeHtmlandNullValues(objFleetViewVO.getModel())
						+ RMDCommonConstants.COMMMA_SEPARATOR);
				if (null != objFleetViewVO.getLatitude()
						&& !RMDCommonConstants.EMPTY_STRING
								.equalsIgnoreCase(objFleetViewVO.getLatitude())&&null != objFleetViewVO.getLongitude()
						&& !RMDCommonConstants.EMPTY_STRING
								.equalsIgnoreCase(objFleetViewVO.getLongitude())) {
					//strBufferFleets.append(objFleetViewVO.getLatitude()+AppConstants.DEGREE_SYMBOL + AppConstants.FRONT_SLASH+objFleetViewVO.getLongitude()+AppConstants.DEGREE_SYMBOL);
					strBufferFleets.append(AppConstants.QUOTE + AppConstants.EMPTY_SPACE + objFleetViewVO.getLatitude()+ AppConstants.FRONT_SLASH+objFleetViewVO.getLongitude() + AppConstants.QUOTE);

				}
				 else {
					strBufferFleets.append(RMDCommonConstants.EMPTY_STRING);
				}

				strBufferFleets.append(RMDCommonConstants.COMMMA_SEPARATOR
						+ RMDCommonUtil.removeHtmlandNullValues(objFleetViewVO.getDtLastFaultDate())
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ RMDCommonUtil.removeHtmlandNullValues(objFleetViewVO.getDtLastProcessedDate())
						+ RMDCommonConstants.COMMMA_SEPARATOR);
				strBufferFleets.append(RMDCommonUtil.removeNullValuesForLong(objFleetViewVO.getRedRx())
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ RMDCommonUtil.removeNullValuesForLong(objFleetViewVO.getYellowRx())
						+ RMDCommonConstants.COMMMA_SEPARATOR
						+ RMDCommonUtil.removeNullValuesForLong(objFleetViewVO.getWhiteRx())
						+ RMDCommonConstants.COMMMA_SEPARATOR);
				strBufferFleets.append(RMDCommonUtil.removeNullValuesForLong(objFleetViewVO.getBlueRx())
						+ RMDCommonConstants.COMMMA_SEPARATOR+RMDCommonUtil.convertQuotesandCommaInCSV(AppSecUtil.decodeString(objFleetViewVO.getNoteDescription())));
					
				strBufferFleets.append(RMDCommonConstants.NEWLINE);

			}
			csvContent = strBufferFleets.toString();
		} catch (Exception exception) {
			logger.error("Export to CSV Fleets" + exception.getMessage());
		}
		return csvContent;

	}
	
}
