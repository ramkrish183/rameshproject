package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.trans.rmd.common.vo.RMDBaseVO;
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class MapServiceVO extends RMDBaseVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String assetNumber;
	private String assetGrpName;
	private String customerId;
	private String worstUrgency;
	private String model;
	private String latitude;
	private String longitude;
	// Adding for map asset plot order story - Start
	/*
	 * We are setting the plotOrder for each asset based on their urgency
	 * and is used in ordering of assets
	 */
	private int assetPlotOrder;
	
	private String lastFaultTime;
	/*
	 * method returns assetPlotOrder
	 */
	public int getAssetPlotOrder() {
		return assetPlotOrder;
	}
	/*
	 * method sets assetPlotOrder
	 */
	public void setAssetPlotOrder(int assetPlotOrder) {
		this.assetPlotOrder = assetPlotOrder;
	}
	// Adding for map asset plot order story - End
	private  List<OpenRxVO> openRxList;
	public String getAssetNumber() {
		return assetNumber;
	}
	public void setAssetNumber(String assetNumber) {
		this.assetNumber = assetNumber;
	}
	public String getAssetGrpName() {
		return assetGrpName;
	}
	public void setAssetGrpName(String assetGrpName) {
		this.assetGrpName = assetGrpName;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getWorstUrgency() {
		return worstUrgency;
	}
	public void setWorstUrgency(String worstUrgency) {
		this.worstUrgency = worstUrgency;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getLatitude() {
		return latitude;
	}
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	public String getLongitude() {
		return longitude;
	}
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	public List<OpenRxVO> getOpenRxList() {
		return openRxList;
	}
	public void setOpenRxList(List<OpenRxVO> openRxList) {
		this.openRxList = openRxList;
	}
	public String getLastFaultTime() {
		return lastFaultTime;
	}
	public void setLastFaultTime(String lastFaultTime) {
		this.lastFaultTime = lastFaultTime;
	}
	
	
}
