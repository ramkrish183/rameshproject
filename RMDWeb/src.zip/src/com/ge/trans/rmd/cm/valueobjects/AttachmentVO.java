package com.ge.trans.rmd.cm.valueobjects;

public class AttachmentVO {
	
	private String docTitle;
	private String docPath;
	public String getDocTitle() {
		return docTitle;
	}
	public void setDocTitle(String docTitle) {
		this.docTitle = docTitle;
	}
	public String getDocPath() {
		return docPath;
	}
	public void setDocPath(String docPath) {
		this.docPath = docPath;
	}

}
