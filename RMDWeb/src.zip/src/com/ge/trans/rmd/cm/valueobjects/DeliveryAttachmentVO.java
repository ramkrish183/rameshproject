package com.ge.trans.rmd.cm.valueobjects;

import com.ge.trans.rmd.common.vo.RMDBaseVO;

public class DeliveryAttachmentVO extends RMDBaseVO {
	private static final long serialVersionUID = 1L;
	private String documentName;
	private String documentLocation;
	public String getDocumentName() {
		return documentName;
	}
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}
	public String getDocumentLocation() {
		return documentLocation;
	}
	public void setDocumentLocation(String documentLocation) {
		this.documentLocation = documentLocation;
	}
}
