/**
 * ============================================================
 * Classification: GE Confidential
 * File : RepairCodesMaintenanceController.java
 * Description :
 *
 * Package : com.ge.trans.rmd.cm.mvc.controller;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on :
 * History
 * Modified By : Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.mvc.controller;

import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import com.ge.trans.rmd.cm.service.RepairCodesMaintenanceService;
import com.ge.trans.rmd.cm.valueobjects.RepairCodeVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;

@Controller
@SessionAttributes
public class RepairCodesMaintenanceController {
	private final  RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private RepairCodesMaintenanceService repairCodesMaintenanceService;

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param : HttpServletRequest
	 * @throws :RMDWebException
	 * @Description: Displays the repair code maintenance page of the RMD
	 *               application when clicked on repaircodeMaintenance Tab in
	 *               View Page.
	 * 
	 */
	@RequestMapping(AppConstants.REQ_URI_REPAIRCODE_MAINTENANCE)
	public ModelAndView showRepairCodeMaintenance(
			final HttpServletRequest request) throws RMDWebException {
		return new ModelAndView(AppConstants.REPAIRCODE_MAINTENANCE);
	}

	/**
	 * @Author:
	 * @param :
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching values to populate select
	 *               by drop down.
	 */

	@RequestMapping(value = AppConstants.GET_REPAIRCODE_SELECT_BY_OPTIONS)
	public @ResponseBody
	Map<String, String> getRepairCodesSelectBy() throws RMDWebException {
		Map<String, String> selectByMap = null;
		try {
			selectByMap = repairCodesMaintenanceService
					.getRepairCodesSelectBy();
		} catch (Exception exception) {
			rmdWebLogger.error(
					"Exception occured in getRepairCodesSelectBy method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return selectByMap;
	}

	/**
	 * @Author:
	 * @param :
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching values to populate status
	 *               drop down.
	 */

	@RequestMapping(value = AppConstants.GET_REPAIRCODE_STATUS_OPTIONS)
	public @ResponseBody
	Map<String, String> getRepairCodesStatus() throws RMDWebException {
		Map<String, String> selectByMap = null;
		try {
			selectByMap = repairCodesMaintenanceService.getRepairCodesStatus();
		} catch (Exception exception) {
			rmdWebLogger.error(
					"Exception occured in getRepairCodesStatus method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return selectByMap;
	}
	
	/**
	 * @Author:
	 * @param :HttpServletRequest
	 * @return:List<RepairCodeVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching repair codes based on
	 *               search criteria
	 */

	@RequestMapping(value = AppConstants.GET_REPAIRCODE_LIST)
	public @ResponseBody
	List<RepairCodeVO> getRepairCodesList(final HttpServletRequest request)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("RepairCodesMaintenanceController : Inside getRepairCodesList() method:::::START ");
		List<RepairCodeVO> objRepairCodeVOList = null;
		String selectBy = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CREATCASE_WSPARAM_SELECTBY));
		String condition = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CREATCASE_WSPARAM_CONDITION));
		String status =EsapiUtil.stripXSSCharacters( request.getParameter(AppConstants.STATUS));
		String model =EsapiUtil.stripXSSCharacters( request
				.getParameter(AppConstants.CREATCASE_WSPARAM_MODELTYPE));
		String value = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.VALUE));
		try {
			if (null != selectBy && null != condition && null != status
					&& null != model && null != value)
				objRepairCodeVOList = repairCodesMaintenanceService
						.getRepairCodesList(selectBy, condition, status, model,
								value);
		} catch (Exception exception) {
			rmdWebLogger.error(
					"Exception occured in getRepairCodesList method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return objRepairCodeVOList;
	}

	/**
	 * @Author:
	 * @param :HttpServletRequest
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for validating the repair codes and
	 *               repair code description.
	 */

	@RequestMapping(value = AppConstants.REPAIRCODE_VALIDATIONS)
	public @ResponseBody
	String repairCodeValidations(final HttpServletRequest request)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("RepairCodesMaintenanceController : Inside repairCodeValidations() method:::::START ");
		String result = null;
		String repairCode = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REPAIR_CODE));
		String repairCodeDesc = EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(request
				.getParameter(AppConstants.REPAIR_CODE_DESC)));
		String flag = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG));
		try {
			if (null != repairCode && null != repairCodeDesc && null != flag)
				result = repairCodesMaintenanceService.repairCodeValidations(
						repairCode, repairCodeDesc, flag);
		} catch (Exception exception) {
			rmdWebLogger.error(
					"Exception occured in repairCodeValidations method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return result;
	}
	/**
	 * @Author:
	 * @param :HttpServletRequest
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for adding repair codes
	 */

	@RequestMapping(value = AppConstants.ADD_REPAIR_CODES)
	public @ResponseBody
	String addRepairCodes(final HttpServletRequest request)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("RepairCodesMaintenanceController : Inside addRepairCodes() method:::::START ");
		String result = null;
		String repairCode = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REPAIR_CODE));
		String repairCodeDesc = EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(request
				.getParameter(AppConstants.REPAIR_CODE_DESC)));
		String status = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.STATUS));
		String model = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CREATCASE_WSPARAM_MODELTYPE));
		try {
			if (null != repairCode && null != repairCodeDesc && null != status && null!=model)
				result = repairCodesMaintenanceService.addRepairCodes(
						repairCode, repairCodeDesc, status,model);
		} catch (Exception exception) {
			rmdWebLogger.error(
					"Exception occured in addRepairCodes method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return result;
	}
	
	/**
	 * @Author:
	 * @param :HttpServletRequest
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for adding repair codes
	 */

	@RequestMapping(value = AppConstants.UPDATE_REPAIR_CODES)
	public @ResponseBody
	String updateRepairCodes(final HttpServletRequest request)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("RepairCodesMaintenanceController : Inside updateRepairCodes() method:::::START ");
		String result = null;
		String repairCode = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REPAIR_CODE));
		String repairCodeDesc = EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(request
				.getParameter(AppConstants.REPAIR_CODE_DESC)));
		String status = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.STATUS));
		String model = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CREATCASE_WSPARAM_MODELTYPE));
		try {
			if (null != repairCode && null != repairCodeDesc && null != status && null!=model)
				result = repairCodesMaintenanceService.updateRepairCodes(
						repairCode, repairCodeDesc, status,model);
		} catch (Exception exception) {
			rmdWebLogger.error(
					"Exception occured in updateRepairCodes method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return result;
	}
	
	/**
	 * @Author:
	 * @param :
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching values to populate conditions
	 *               drop down.
	 */

	@RequestMapping(value = AppConstants.GET_REPAIRCODE_CONDITION_OPTIONS)
	public @ResponseBody
	Map<String, String> getRepairCodesConditions() throws RMDWebException {
		Map<String, String> selectByMap = null;
		try {
			selectByMap = repairCodesMaintenanceService.getRepairCodesConditions();
		} catch (Exception exception) {
			rmdWebLogger.error(
					"Exception occured in getRepairCodesConditions method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return selectByMap;
	}
	
}