package com.ge.trans.rmd.cm.service;


import java.util.List;
import java.util.Map;
import com.ge.trans.rmd.cm.valueobjects.AutoHCTemplateDetails;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface AutoHCTemplateService {

	
	public List<String> getTemplateDropDwn(String ctrlConfig ,String configFile)  throws GenericAjaxException, RMDWebException;
	public List<String> getFaultCodeRecTypeDropDwn(String ctrlConfig ,String configFile)  throws GenericAjaxException, RMDWebException;
	public List<String> getMessageDefIdDropDwn()  throws GenericAjaxException, RMDWebException;
	public String postAutoHCNewTemplate(AutoHCTemplateDetails autoHCTemplateDetails) throws GenericAjaxException, RMDWebException;
	public Map<String,String> getComAHCDetails(String templateNo,
			String versionNo, String ctrlCfgObjId) throws GenericAjaxException, RMDWebException;
}
