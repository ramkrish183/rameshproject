package com.ge.trans.rmd.cm.valueobjects;

public class VisualizationParmDetailsVO {
	
	  private String parmValue;
	  private String occurTime;
	public String getParmValue() {
		return parmValue;
	}
	public void setParmValue(String parmValue) {
		this.parmValue = parmValue;
	}
	public String getOccurTime() {
		return occurTime;
	}
	public void setOccurTime(String occurTime) {
		this.occurTime = occurTime;
	}
	  

}
