package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.portlet.ModelAndView;

import com.ge.trans.rmd.cm.service.CommNotesService;
import com.ge.trans.rmd.common.beans.GpocNotesBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.GenNotesVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
@Controller
public class CommNotesController extends RMDBaseController {
	
	@Autowired
	private CommNotesService commNotesService;
	@Autowired
       private org.springframework.cache.CacheManager cacheManager;
	@Autowired
	private ApplicationContext appContext;

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@RequestMapping(AppConstants.REQ_URI_COMML_NOTES)
	public ModelAndView commNotesPage(final HttpServletRequest request)
			throws RMDWebException {
		rmdWebLogger
				.debug("Inside commNotesPage Method");
		try {
			HttpSession session = request.getSession(false);
			UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			request.setAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE,
					userVO.getIsCMPrivilege());

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in commNotesPage() method in CommNotesController ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return new ModelAndView(AppConstants.COMM_NOTES);
	}
	
	
	
	@RequestMapping(value = AppConstants.COMMNOTES_SHOW_ALL, method = RequestMethod.GET)
	public @ResponseBody List<GenNotesVO> showAllCommNotes(
			final HttpServletRequest request) throws Exception {
			
		
		final HttpSession session = request.getSession(false);
		final GpocNotesBean objGpocNotesBean = new GpocNotesBean();
		List<GenNotesVO> objlst = new ArrayList<GenNotesVO>();
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			objGpocNotesBean.setLanguage(userVO.getStrLanguage());
			objlst = commNotesService.showAllCommNotes(objGpocNotesBean,userVO.getTimeZone());
		}
		catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getRoleManagementPage method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return objlst;

	}
	
	/**
	 * @Author:
	 * @param :
	 * @return String
	 * @throws RMDWebException
	 * @Description: This method is used to insert the comm notes
	 */
	@RequestMapping(value = AppConstants.ADD_COMM_NOTES,method = RequestMethod.POST)
	public @ResponseBody String addCommNotes(final HttpServletRequest request) throws RMDWebException {

		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String uniquerecord = null;
		GpocNotesBean gpocNotesBean = new GpocNotesBean();
		try {
			String notesdesc= EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.NOTES_DESC));
			String flag = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG));
			if (!RMDCommonUtility.isNullOrEmpty(notesdesc)) {
				gpocNotesBean.setNotesdesc(notesdesc);
			}
			if(!RMDCommonUtility.isNullOrEmpty(flag)){
                gpocNotesBean.setVisibilityFlag(flag);
            }else{
                gpocNotesBean.setVisibilityFlag(RMDCommonConstants.N_LETTER_UPPER);
            }
			gpocNotesBean.setEnteredby(userVO.getUserId());
			uniquerecord = commNotesService.addCommNotes(gpocNotesBean);

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in addCommNotes  method in CommNotesController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return uniquerecord;
	}
	
	/**
	 * @Description:This method is used to export the Comm notes under Turnover
	 * @return: void
	 * @param:HttpServletRequest request,HttpServletResponse response,Locale
	 *                           locale,
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 */
	 @RequestMapping(value = AppConstants.EXPORT_AT_COMM_NOTES, method = RequestMethod.POST)
	   public void exportCommNotes(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws IOException,GenericAjaxException, RMDWebException {
		 
		 final HttpSession session = request.getSession(false);
		 final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
		 final GpocNotesBean gpocBean = new GpocNotesBean();
		 List<GenNotesVO> arlgennotesvo = new ArrayList<GenNotesVO>();
		 
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;

		try {
			gpocBean.setUserLanguage(userVO.getStrUserLanguage());
			arlgennotesvo =  commNotesService.showAllCommNotes(gpocBean, userVO.getTimeZone());
			
			if (null != arlgennotesvo && !arlgennotesvo.isEmpty()) {
				csvContent = convertToCSVCommnotes(arlgennotesvo, locale);
				response.setContentType(AppConstants.CONTENT_TYPE);
				response.setHeader(AppConstants.CONTENT,
						AppConstants.ATTACH_FILENAME
								+ AppConstants.COMM_NOES_EXPORT_FILENAME);
				objServletOutputStream = response.getOutputStream();
				ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
						csvContent.getBytes());
				objBufferedInputStream = new BufferedInputStream(
						objByteArrayInputStream);

				objBufferedOutputStream = new BufferedOutputStream(
						objServletOutputStream);

				byte[] byteArr = new byte[2048];
				int bytesread;

				while ((bytesread = objBufferedInputStream.read(byteArr, 0,
						byteArr.length)) != -1) {
					objBufferedOutputStream.write(byteArr, 0, bytesread);
					objBufferedOutputStream.flush();
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in exportCommNotes method ", ex);
			RMDWebErrorHandler.handleException(ex);
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}
		}
	}
	 
	 /**
		 * @Description:This method is used convert General Notes List into csv format
		 * @return: String
		 * @param:List<GpocBean> gnStatus, Locale locale
		 */

	 private String convertToCSVCommnotes(List<GenNotesVO> arlgennotesvo, Locale locale){
			String csvContent = null;
			StringBuilder strBufferAssetHeader = new StringBuilder();
			try {
				strBufferAssetHeader.append(appContext.getMessage(
						AppConstants.COMM_NOTES_HEADER, null, locale));
				strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
				for (GenNotesVO gnList : arlgennotesvo) {
					if (null != gnList.getNotesdesc()) {
						strBufferAssetHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+gnList.getNotesdesc() + AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					} else {
						strBufferAssetHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					}
					if (null != gnList.getVisibilityFlag()) {
	                    strBufferAssetHeader.append(AppConstants.QUOTE
	                            + AppConstants.EMPTY_SPACE + gnList.getVisibilityFlag()
	                            + AppConstants.QUOTE
	                            + RMDCommonConstants.COMMMA_SEPARATOR);
	                } else {
	                    strBufferAssetHeader.append(AppConstants.QUOTE
	                            + AppConstants.EMPTY_SPACE + AppConstants.QUOTE
	                            + RMDCommonConstants.COMMMA_SEPARATOR);
	                }
					if (null != gnList.getEnteredby()) {
						strBufferAssetHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+ gnList.getEnteredby() + AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					} else {
						strBufferAssetHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					}
					if (null !=gnList.getLastUpdatedTime()) {
						strBufferAssetHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+gnList.getLastUpdatedTime() + AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					} else {
						strBufferAssetHeader.append(AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					}

					strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
				}
				csvContent = strBufferAssetHeader.toString();
			} catch (Exception exception) {
				rmdWebLogger.error("Export to CSV comm Notes"
						+ exception);
			}
			return csvContent;
		}
		
		
		
		
		/**
		 * @Author:
		 * @param :
		 * @return String
		 * @throws RMDWebException
		 * @Description: This method is used to delete notes in Comm notes sccreen.
		 */
		@RequestMapping(value = AppConstants.REMOVE_COMML_NOTES,method = RequestMethod.POST)
		@ResponseBody
		public String removeCommNotes(
				@RequestParam(value = AppConstants.GET_COMMSEQIDS_STRING) final String commnotesseqids,
				final HttpServletRequest request) throws RMDWebException {
			String status = AppConstants.FAILURE;
			List<GenNotesVO> objGenNotesVO = new ArrayList<GenNotesVO>();
			final ObjectMapper mapper = new ObjectMapper();
			try {
				mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
				GenNotesVO[] arrGenNotesVO = mapper.readValue(commnotesseqids,GenNotesVO[].class);
				objGenNotesVO = Arrays.asList(arrGenNotesVO);
				status = commNotesService.removeCommNotes(objGenNotesVO);

			

			} catch (Exception ex) {
				status = AppConstants.FAILURE;
				rmdWebLogger
						.error("RMDWebException occured in removeCommNotes() method - CommNotesController.java",
								ex);
				RMDWebErrorHandler.handleException(ex);
			}

			return status;

		}
}
