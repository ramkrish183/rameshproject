package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;

import javax.xml.datatype.XMLGregorianCalendar;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.AssetSearchVO;
import com.ge.trans.rmd.cm.valueobjects.CaseTypeBean;
import com.ge.trans.rmd.cm.valueobjects.CreateCasesVO;
import com.ge.trans.rmd.cm.valueobjects.FaultServiceStrategyVO;
import com.ge.trans.rmd.cm.valueobjects.FaultCodeVO;
import com.ge.trans.rmd.cm.valueobjects.ViewLogVO;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.beans.SolutionBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.km.util.KMConstants;
import com.ge.trans.rmd.pp.beans.AssetBean;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.Customer;
import com.ge.trans.rmd.services.assets.valueobjects.Fleet;
import com.ge.trans.rmd.services.assets.valueobjects.Model;
import com.ge.trans.rmd.services.cases.valueobjects.AssetHeaderResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseSolutionRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.ViewLogReponseType;
import com.ge.trans.rmd.services.notes.valueobjects.NotesInfo;
import com.ge.trans.rmd.services.notes.valueobjects.NotesRequestType;
import com.ge.trans.rmd.services.solutions.valueobjects.SolutionDetailType;
import com.ge.trans.rmd.services.solutions.valueobjects.SolutionResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.services.cases.valueobjects.FaultServiceStrategyResponseType;
import com.ge.trans.rmd.services.faultstrategy.valueobjects.FaultCodesResponseType;
import com.ge.trans.rmd.utilities.AppSecUtil;
import com.ge.trans.rmd.common.service.CachedService;

@Service
public class FaultServiceStrategyServiceImpl extends RMDBaseServiceImpl implements
FaultServiceStrategyService {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	WebServiceInvoker webServiceInvoker;

	@Autowired
	private AssetOverviewService assetOverviewService;

	@Autowired
	private CachedService cachedService;
	
	/**
	 * This is the method used for fetching the Diagnostic Weight values through
	 * jquery call
	 * 
	 * @param
	 * @return List<String>
	 * @throws
	 */
	public List<String> getDiagnosticWeight() throws RMDWebException {
		rmdWebLogger
				.debug("Inside CreateCasesServiceImpl in getDiagnosticWeight Method");

		List<String> diagnosticWeight = new ArrayList<String>();
		String strdiagnosticWeight = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.CREATCASE_DIAGNOSTIC_WEIGHT);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					strdiagnosticWeight = applParamResponseType[i]
							.getLookupValue();
					diagnosticWeight.add(strdiagnosticWeight);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getDiagnosticWeight method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return diagnosticWeight;
	}
	/**
	 * This is the method used for fetching the SubSys Weight values through
	 * jquery call
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */
	public List<String> getSubSysWeight()
			throws RMDWebException {
		rmdWebLogger
				.debug("Inside CreateCasesServiceImpl in getSubSysWeight Method");

		List<String> subSysWeight = new ArrayList<String>();
		String strsubSysWeight = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.CREATCASE_SUBSYS_WEIGHT);

			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					strsubSysWeight = applParamResponseType[i].getLookupValue();
					subSysWeight.add(strsubSysWeight);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getSubSysWeight method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return subSysWeight;
	}

	/**
	 * This is the method used for fetching the ModeRestriction values through
	 * jquery call
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */
	public Map<String, String> getModeRestriction() throws RMDWebException {
		rmdWebLogger
				.debug("Inside CreateCasesServiceImpl in getModeRestriction Method");

		Map<String, String> modeRestriction = new LinkedHashMap<String, String>();
		String strmodeRestriction = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.CREATCASE_MODE_RESTRICTION);

			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					strmodeRestriction = applParamResponseType[i]
							.getLookupValue();
					modeRestriction.put(strmodeRestriction, strmodeRestriction);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getModeRestriction method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return modeRestriction;
	}

	/**
	 * This is the method used for fetching the Fault Classification values
	 * through jquery call
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */
	public Map<String, String> getFaultClassification() throws RMDWebException {
		rmdWebLogger
				.debug("Inside CreateCasesServiceImpl in getFaultClassification Method");

		Map<String, String> faultClassification = new LinkedHashMap<String, String>();
		String strfaultClassification = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.CREATCASE_FAULT_CLASSIFICATION);

			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					strfaultClassification = applParamResponseType[i]
							.getLookupValue();
					faultClassification.put(strfaultClassification,
							strfaultClassification);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getFaultClassification method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return faultClassification;
	}

	/**
	 * This is the method used for fetching the Critical Flag values through
	 * jquery call
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */
	public Map<String, String> getCriticalFlag() throws RMDWebException {
		rmdWebLogger
				.debug("Inside CreateCasesServiceImpl in getCriticalFlag Method");

		Map<String, String> criticalFlag = new LinkedHashMap<String, String>();
		String strcriticalFlag = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.CREATCASE_CRITICAL_FLAG);

			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					strcriticalFlag = applParamResponseType[i].getLookupValue();
					criticalFlag.put(strcriticalFlag, strcriticalFlag);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCriticalFlag method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return criticalFlag;
	}

	/**
	 * @Author:
	 * @param :String caseId
	 * @return:CaseBean
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used for fetching the Fault Strategy
	 *               Details.It accepts fsObjId as an Input Parameter and
	 *               returns FaultServiceStrategyVO.
	 * 
	 * 
	 */
	@Override
	public FaultServiceStrategyVO getFaultStrategyDetails(String fsObjId,
			String timezone) throws RMDWebException {

		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		FaultServiceStrategyResponseType objFaultStrategyResponseType = null;
		final DateFormat zoneFormater = new SimpleDateFormat(
				AppConstants.DATE_FORMAT_24HRS);
		final TimeZone timeZone = TimeZone.getTimeZone(timezone);
		FaultServiceStrategyVO objFaultServiceStrategyVO = new FaultServiceStrategyVO();
		try {
			queryParams.put(AppConstants.FAULT_STRATEGY_OBJID, fsObjId);
			objFaultStrategyResponseType = (FaultServiceStrategyResponseType) webServiceInvoker
					.get(ServiceConstants.GET_FAULT_STRATEGY_DETAILS, null,
							queryParams, null,
							FaultServiceStrategyResponseType.class);
			if (null != objFaultStrategyResponseType) {
				objFaultServiceStrategyVO
						.setFltStart2FltCode(objFaultStrategyResponseType
								.getFltStart2FltCode());
				objFaultServiceStrategyVO
						.setFaultOrigin(objFaultStrategyResponseType
								.getFaultOrigin());
				objFaultServiceStrategyVO
						.setFaultCode(objFaultStrategyResponseType
								.getFaultCode());
				objFaultServiceStrategyVO
						.setFaultSubId(objFaultStrategyResponseType
								.getFaultSubId());
				objFaultServiceStrategyVO.setFaultDesc(AppSecUtil
						.decodeString(objFaultStrategyResponseType
								.getFaultDesc()));
				objFaultServiceStrategyVO
						.setFaultLabel(objFaultStrategyResponseType
								.getFaultLabel());
				objFaultServiceStrategyVO
						.setDiagnosticWeight(objFaultStrategyResponseType
								.getLstDiagnosticWeight());
				objFaultServiceStrategyVO
						.setSubSysWeight(objFaultStrategyResponseType
								.getLstSubSysWeight());
				objFaultServiceStrategyVO
						.setModeRestriction(objFaultStrategyResponseType
								.getLstModeRestriction());
				objFaultServiceStrategyVO
						.setFaultClassification(objFaultStrategyResponseType
								.getLstFaultClassification());
				objFaultServiceStrategyVO
						.setFaultCriticalFlag(objFaultStrategyResponseType
								.getFaultCriticalFlag());

				final XMLGregorianCalendar lastUpdatedDate = objFaultStrategyResponseType
						.getLastUpdatedDate();
				zoneFormater.setTimeZone(timeZone);
				if (null != objFaultStrategyResponseType.getLastUpdatedDate()) {
					objFaultServiceStrategyVO.setLastUpdatedDate(zoneFormater
							.format(lastUpdatedDate.toGregorianCalendar()
									.getTime()));
				}

				objFaultServiceStrategyVO
						.setLastUpdatedBy(objFaultStrategyResponseType
								.getLastUpdatedBy());
				objFaultServiceStrategyVO
						.setFaultLagTime(objFaultStrategyResponseType
								.getFaultLagTime());
				objFaultServiceStrategyVO.setFaultNotes(ESAPI.encoder().decodeForHTML(objFaultStrategyResponseType
								.getFaultNotes()));
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getFaultStrategyDetails() method - AssetCasesServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return objFaultServiceStrategyVO;
	}

	/**
	 * @Author:
	 * @param:String caseId
	 * @return:RecommDelVO
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching Fault Rule & Desc by
	 *               invoking web services getRuleDesc() method.
	 */
	@Override
	public List<FaultServiceStrategyVO> getRuleDesc(String faultCode)
			throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		List<FaultServiceStrategyVO> lstFaultServiceStrategyVO = new ArrayList<FaultServiceStrategyVO>();
		try {
			queryParams.put(AppConstants.FAULT_CODE_ID, faultCode);
			FaultServiceStrategyResponseType[] objFaultStrategyResponseType = (FaultServiceStrategyResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_RULE_DESC, null, queryParams,
							null, FaultServiceStrategyResponseType[].class);
			for (FaultServiceStrategyResponseType objFaultStrategySResponseType : objFaultStrategyResponseType) {
				FaultServiceStrategyVO objFaultServiceStrategyVO = new FaultServiceStrategyVO();
				objFaultServiceStrategyVO
						.setFaultRule(objFaultStrategySResponseType
								.getFaultRule());
				objFaultServiceStrategyVO
						.setFaultRuleDesc(objFaultStrategySResponseType
								.getFaultRuleDesc());
				lstFaultServiceStrategyVO.add(objFaultServiceStrategyVO);
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getRuleDesc method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lstFaultServiceStrategyVO;
	}

	/**
	 * @Author:
	 * @param:String caseId
	 * @return:RecommDelVO
	 * @throws:RMDWebException
	 * @Description: This method is used for updateing FaultServiceStrategy by
	 *               invoking web services updateFaultServiceStrategy() method.
	 */
	@Override
	public String updateFaultServiceStrategy(
			FaultServiceStrategyVO objFaultServiceStrategyVO)
			throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		List<FaultServiceStrategyVO> lstFaultServiceStrategyVO = new ArrayList<FaultServiceStrategyVO>();
		String responseMessage = null;
		try {
			FaultServiceStrategyResponseType objFaultStrategyResponseType = new FaultServiceStrategyResponseType();
			objFaultStrategyResponseType.setUserId(objFaultServiceStrategyVO
					.getUserId());
			objFaultStrategyResponseType
					.setCmAliasName(objFaultServiceStrategyVO.getCmAliasName());
			objFaultStrategyResponseType
					.setFltStart2FltCode(objFaultServiceStrategyVO
							.getFltStart2FltCode());
			objFaultStrategyResponseType.setFaultDesc(AppSecUtil
					.htmlEscaping(objFaultServiceStrategyVO.getFaultDesc()));
			objFaultStrategyResponseType
					.setLstDiagnosticWeight(objFaultServiceStrategyVO
							.getDiagnosticWeight());
			objFaultStrategyResponseType
					.setLstSubSysWeight(objFaultServiceStrategyVO
							.getSubSysWeight());
			objFaultStrategyResponseType
					.setLstModeRestriction(objFaultServiceStrategyVO
							.getModeRestriction());
			objFaultStrategyResponseType
					.setLstFaultClassification(objFaultServiceStrategyVO
							.getFaultClassification());
			objFaultStrategyResponseType
					.setFaultCriticalFlag(objFaultServiceStrategyVO
							.getFaultCriticalFlag());
			objFaultStrategyResponseType
					.setFaultLagTime(objFaultServiceStrategyVO
							.getFaultLagTime());
			objFaultStrategyResponseType.setFaultNotes(ESAPI
					.encoder()
					.encodeForXML(objFaultServiceStrategyVO.getFaultNotes()));
			objFaultStrategyResponseType.setFsObjId(objFaultServiceStrategyVO
					.getFsObjId());
			webServiceInvoker.put(
					ServiceConstants.UPDATE_FAULT_SERVICE_STRATEGY,
					objFaultStrategyResponseType, null);
			responseMessage = AppConstants.SUCCESS;
		} catch (Exception ex) {
			responseMessage = AppConstants.FAILURE;
			rmdWebLogger.error(
					"Exception occured in updateFaultServiceStrategy method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return responseMessage;
	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description This method is used to fetch Fault Origin values to populate
	 *              Fault Origin Drop down.
	 * 
	 */

	@Override
	public Map<String, String> getFaultOrigin() throws RMDWebException {
		Map<String, String> faultOriginMap = new LinkedHashMap<String, String>();
		try {
			faultOriginMap=cachedService.getFaultOrigin();
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getFaultOrigin method  of FaultServiceStrategySerrviceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return faultOriginMap;
	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description This method is used to fetch Fault Code SubId's to populate
	 *              Fault SubId Drop down.
	 * 
	 */
	
	@Override
	public Map<String, String> getFaultCodeSubId(String faultCode,
			String faultOrigin) throws RMDWebException {
		Map<String, String> faultCodeSubIdMap = new LinkedHashMap<String, String>();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		try {
			queryParams.put(AppConstants.FAULT_CODE_ID, faultCode);
			queryParams.put(AppConstants.FAULT_ORIGIN, faultOrigin);
			FaultCodesResponseType[] arrFaultCodesResponseType = (FaultCodesResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_FAULT_CODE_SUBID, null, queryParams,
							null, FaultCodesResponseType[].class);
			for (FaultCodesResponseType objFaultCodesResponseType : arrFaultCodesResponseType) {
				faultCodeSubIdMap.put(
						objFaultCodesResponseType.getFaultSubId(),
						objFaultCodesResponseType.getFaultSubId());
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getFaultCodeSubId method  of FaultServiceStrategyServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return faultCodeSubIdMap;
	}
	
	/**
	 * 
	 * @param
	 * @return List<FaultCodeVO>
	 * @throws RMDWebException
	 * @Description This method is used to get Fault Code based upon Search
	 *              Criteria.
	 */
	@Override
	public List<String> getViewFSSFaultCode(String faultCode, String faultOrigin)
			throws RMDWebException {
		List<String> arlFaultCodes = new ArrayList<String>();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		try {
			queryParams.put(AppConstants.FAULT_CODE_ID, faultCode);
			if (null != faultOrigin) {
				queryParams.put(AppConstants.FAULT_ORIGIN, faultOrigin);
			} else {
				queryParams.put(AppConstants.FAULT_ORIGIN,
						AppConstants.EMPTY_STRING);
			}
			FaultCodesResponseType[] arFaultCodesResponseTypes = (FaultCodesResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_VIEW_FSS_FAULT_CODE, null,
							queryParams, null, FaultCodesResponseType[].class);
				for (FaultCodesResponseType objFaultCodesResponseType : arFaultCodesResponseTypes) {

					String tmp = objFaultCodesResponseType.getFaultOrigin()
							+ AppConstants.EMPTY_SPACE
							+ AppConstants.SYMBOL_OR
							+ AppConstants.EMPTY_SPACE
							+ AppConstants.BOLD_TAG_START
							+ AppSecUtil.decodeString(objFaultCodesResponseType
									.getFaultCode())
							+ AppConstants.BOLD_TAG_END
							+ AppConstants.EMPTY_SPACE
							+ AppConstants.SYMBOL_OR
							+ AppConstants.EMPTY_SPACE
							+ ESAPI.encoder().decodeForHTML(
									objFaultCodesResponseType
											.getFaultDescription());
					arlFaultCodes.add(tmp);
				}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getViewFSSFaultCode method  of FaultServiceStrategySerrviceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlFaultCodes;
	}
	
	/**
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used to get Fault Code ObjId based upon
	 *              FaultCode,Fault SubID,Fault Origin
	 */
	@Override
	public String getFaultStrategyObjId(String faultCode, String faultOrigin,
			String faultCodeSubId) throws RMDWebException {
		String faultStrategyObjId = AppConstants.FAILURE;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		try {
			queryParams.put(AppConstants.FAULT_CODE_ID, faultCode);
			queryParams.put(AppConstants.FAULT_ORIGIN, faultOrigin);
			queryParams.put(AppConstants.FAULT_CODE_SUBID, faultCodeSubId);
			faultStrategyObjId = (String) webServiceInvoker.get(
					ServiceConstants.GET_FAULT_STRATEGY_OBJID, null, queryParams,
					null, String.class);

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getFaultStrategyObjId method  of FaultServiceStrategySerrviceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return faultStrategyObjId;
	}
}