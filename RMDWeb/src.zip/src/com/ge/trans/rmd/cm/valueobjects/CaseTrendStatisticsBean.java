package com.ge.trans.rmd.cm.valueobjects;

import java.util.Map;

public class CaseTrendStatisticsBean {
	
	private Map<String, Map<String, String>> caseTrendStatistics;

	public Map<String, Map<String, String>> getCaseTrendStatistics() {
		return caseTrendStatistics;
	}

	public void setCaseTrendStatistics(
			Map<String, Map<String, String>> caseTrendStatistics) {
		this.caseTrendStatistics = caseTrendStatistics;
	}

}
