package com.ge.trans.rmd.cm.valueobjects;

public class EDPHeaderDetailsVO {
	
	private String tempObjId;
	private String ctrlCfgObjId;
	private String cfgFileName;
	private String templateNo;
	private String vesrionNo;
	private String title;
	private String ctrlCfgName;
	private String status;
	
	public String getTempObjId() {
		return tempObjId;
	}
	public void setTempObjId(String tempObjId) {
		this.tempObjId = tempObjId;
	}
	public String getCtrlCfgObjId() {
		return ctrlCfgObjId;
	}
	public void setCtrlCfgObjId(String ctrlCfgObjId) {
		this.ctrlCfgObjId = ctrlCfgObjId;
	}
	public String getCfgFileName() {
		return cfgFileName;
	}
	public void setCfgFileName(String cfgFileName) {
		this.cfgFileName = cfgFileName;
	}
	public String getTemplateNo() {
		return templateNo;
	}
	public void setTemplateNo(String templateNo) {
		this.templateNo = templateNo;
	}
	public String getVesrionNo() {
		return vesrionNo;
	}
	public void setVesrionNo(String vesrionNo) {
		this.vesrionNo = vesrionNo;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCtrlCfgName() {
		return ctrlCfgName;
	}
	public void setCtrlCfgName(String ctrlCfgName) {
		this.ctrlCfgName = ctrlCfgName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	

}
