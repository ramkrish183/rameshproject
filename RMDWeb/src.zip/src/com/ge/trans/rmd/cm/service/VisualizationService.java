package com.ge.trans.rmd.cm.service;

/**
 * ============================================================
 * File : VisualizationServiceImpl.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.cm.mvc.controller
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Feb 8, 2012
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.valueobjects.RxVisualizationPlotInfoVO;
import com.ge.trans.rmd.cm.valueobjects.VisualizationDataResponseVO;
import com.ge.trans.rmd.cm.valueobjects.VisualizationDetailsBean;
import com.ge.trans.rmd.cm.valueobjects.VisualizationEventDataVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.pp.beans.AssetBean;

/*******************************************************************************
 * 
 * @Author : iGATE
 * @Version : 1.0
 * @Date Created: July 21, 2011
 * @Date Modified : July 25, 2011
 * @Modified By :
 * @Contact :
 * @Description : Service Interface class for fetching the details related to
 *              visualization screen
 * @History :
 * 
 ******************************************************************************/

public interface VisualizationService {
	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @Description: This method is used to fetch the visualization lookup
	 *               values
	 */
	public Map<String, String> getVisualizationLookUps(String listName)
			throws RMDWebException, Exception;

	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @Description: This method is used to fetch the visualization No Of days
	 *               for Date Ranges
	 */
	public int getVisualizationNoOfDays(String listName)
			throws RMDWebException, Exception;

	/**
	 * @Author:
	 * @param
	 * @return Map<String, Map<String, String>>
	 * @Description: This method used to fetch the graphNames based on
	 *               source,sourceType and controllerCfg
	 */

	public Map<String, Map<String, String>> getGraphName(String controllerCfg,
			String source, String sourceType) throws RMDWebException, Exception;

	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @Description: This method is used to fetch the visualization Default
	 *               Values from lookup table
	 */
	public String getVisualizationDefaultValues(String listName)
			throws RMDWebException, Exception;

	/**
	 * @Author:
	 * @param
	 * @return Map<List<String> , ArrayList<ArrayList<ArrayList<Number>>>>
	 * @Description: This method will return the data needed to plot the chart
	 */
	public VisualizationDataResponseVO getVisualizationDetails(
			final VisualizationDetailsBean objVisualizationBean)
			throws RMDWebException, Exception;

	/**
	 * @Author:
	 * @param
	 * @return Map<List<String> , ArrayList<ArrayList<ArrayList<Number>>>>
	 * @Description: This method will return the data needed to plot the chart
	 */
	public Map<String, Map<String, String>> getVisualizationParmNumbers(
			final String source, final String sourceType,
			final String controllerCfg) throws RMDWebException, Exception;

	/**
	 * @Author:
	 * @param
	 * @return Map<String, Map<String,String>>
	 * @Description: This method will return the logical operators from lookup
	 */

	public Map<String, Map<String, String>> getLogicalOperators()
			throws RMDWebException, Exception;

	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @Description: This method is used to fetch the visualization lookup
	 *               values
	 */
	public Map<String, String> getLookUpValuesWithDescription(String listName)
			throws RMDWebException, Exception;

	public Map<String, String> getFaultCode(String faultCode,
			String controllerCfg) throws RMDWebException, Exception;

	
	public List<VisualizationEventDataVO> getAssetVisualizationEventData(
			final VisualizationEventDataVO objVisualizationEventDataVO)
			throws RMDWebException, Exception;
	
	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @Description: This method is used to fetch the asset family visualization 
	 */
	public String getVizAssetFamily(String model)
			throws RMDWebException, Exception;
	
	public Map<String,Map<String,String>> getVizVirtualParameters(
			final String family,final String database) throws RMDWebException, Exception;

	Map<String, String> getAssets(AssetBean assetBean) throws RMDWebException,
			Exception;
	public VisualizationDataResponseVO  getRxVizPlotData(
			final VisualizationDetailsBean objVisualizationBean)
			throws RMDWebException, Exception;
	public RxVisualizationPlotInfoVO  getRxVizPlotInfo(
			String rxObjid)
			throws RMDWebException, Exception;

}
