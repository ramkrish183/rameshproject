/**
 * 
 */
package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.xml.datatype.XMLGregorianCalendar;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.FindNotesDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.StickyNotesDetailsVO;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.StickyNotesDetailsResponseType;
import com.ge.trans.rmd.services.notes.valueobjects.FindNotesResponseType;
import com.ge.trans.rmd.services.notes.valueobjects.NotesRequestType;

@Service
public class NotesServiceImpl extends RMDBaseServiceImpl implements
		NotesService {

	@Autowired
	private CachedService cachedService;
	@Autowired
	private WebServiceInvoker rsInvoker;

	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	/**
	 * @Author :
	 * @return :Map<String, String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This controller method will fetch the list of controllers.
	 * 
	 */
	@Override
	public Map<String, String> getAllControllers() throws RMDWebException {
		Map<String, String> sortedControllerMap = null;
		try {

			sortedControllerMap = new LinkedHashMap<String, String>(
					cachedService.getAllControllers());

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				logger.error("NotesServiceImpl :: No records found for getAllControllers() service "
						+ e.getMessage());
			} else {
				logger.error("NotesServiceImpl :: Exception occured in getAllControllers() method "
						+ e.getMessage());
				throw e;
			}
		} catch (Exception ex) {
			logger.error("Exception occured in getAllControllers method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return sortedControllerMap;
	}

	/**
	 * @Author :
	 * @return :Map<String, String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This controller method will fetch the list of Creators.
	 * 
	 */

	@Override
	public Map<String, String> getNotesCreatersList() throws RMDWebException {

		Map<String, String> controllerMap = null;
		try {
			controllerMap = new LinkedHashMap<String, String>(
					cachedService.getNotesCreatersList());
		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				logger.error("NotesServiceImpl :: No records found for getNotesCreatersList() service "
						+ e.getMessage());
			} else {
				logger.error("NotesServiceImpl :: Exception occured in getNotesCreatersList() method "
						+ e.getMessage());
				throw e;
			}
		} catch (Exception ex) {
			logger.error("Exception occured in getNotesCreatersList method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return controllerMap;
	}

	/**
	 * 
	 * @param
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Find Cases Search Options By drop down.
	 * 
	 */
	@Override
	public Map<String, String> getNoteTypes() throws RMDWebException {
		Map<String, String> allNoteTypeMap = new LinkedHashMap<String, String>();
		String noteType = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME, AppConstants.NOTE_TYPE_LIST);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					noteType = applParamResponseType[i].getLookupValue();
					allNoteTypeMap.put(noteType, noteType);
				}
			}
		} catch (Exception ex) {
			logger.error("Exception occured in getNoteTypes method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allNoteTypeMap;
	}

	/**
	 * @Author :
	 * @return :String
	 * @param :NotesBean
	 * @throws :RMDWebException
	 * @Description: This method adds the notes for the selected customer.
	 * 
	 */
	@Override
	public String addNotesToVehicle(NotesBean notesBean) throws RMDWebException {
		String status = null;
		NotesRequestType requestObj = null;
		try {

			if (null != notesBean) {
				requestObj = new NotesRequestType();
				requestObj.setCustomerID(notesBean.getCustomerId());
				requestObj.setSticky(notesBean.getSticky());
				requestObj.setFromRN(notesBean.getFromRN());
				requestObj.setToRN(notesBean.getToRN());
				requestObj.setModelId(notesBean.getModelId());
				requestObj.setCtrlId(notesBean.getCtrlId());
				requestObj.setFleetId(notesBean.getFleetId());
				requestObj.setNotes(notesBean.getNoteDescription());
				requestObj.setOverWriteFlag(notesBean.getOverWriteFlag());
				requestObj.setUserId(notesBean.getUserId());
				requestObj.setStickyObjId(notesBean.getStickyObjId());
				requestObj.setFromAssetList(notesBean.getAssetNumbersList());
				status = (String) (rsInvoker.post(
						ServiceConstants.ADD_NOTES_TO_VEHICLE, requestObj,
						String.class));
			}

		} catch (Exception e) {
			logger.error(
					"Exception occured in addNotesToVehicle   in NotesServiceImpl:",
					e);
			RMDWebErrorHandler.handleException(e);
		}
		return status;
	}

	/**
	 * @Author :
	 * @return :StickyNotesDetailsVO
	 * @param :customerId,fromRN,timeZone
	 * @throws :RMDWebException
	 * @throws :Exception
	 * @Description: This method adds the notes for the selected customer.
	 * 
	 */
	@Override
	public List<StickyNotesDetailsVO> fetchVehicleStickyDetails(
			String customerId, String fromRN, String noOfUnits, String timeZone)
			throws RMDWebException, Exception {
		List<StickyNotesDetailsVO> objStickyNotesDetailsVOList = new ArrayList<StickyNotesDetailsVO>();
		final DateFormat zoneFormater = new SimpleDateFormat(
				AppConstants.DATE_FORMAT_24HRS);
		final TimeZone timZone = TimeZone.getTimeZone(timeZone);
		StickyNotesDetailsVO objStickyNotesDetailsVO = null;
		try {
			final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
			queryParamMap.put(AppConstants.CUSTOMER_ID, customerId);
			queryParamMap.put(AppConstants.FROM_RN, fromRN);
			queryParamMap.put(AppConstants.NO_OF_UNITS, noOfUnits);
			StickyNotesDetailsResponseType[] notesDetails = (StickyNotesDetailsResponseType[]) rsInvoker
					.get(ServiceConstants.FETCH_VEHICLE_STICKY_DETAILS, null,
							queryParamMap, null,
							StickyNotesDetailsResponseType[].class);
			for (StickyNotesDetailsResponseType notes : notesDetails) {
				objStickyNotesDetailsVO = new StickyNotesDetailsVO();

				objStickyNotesDetailsVO.setCreatedBy(notes.getCreatedBy());
				objStickyNotesDetailsVO.setAdditionalInfo(ESAPI.encoder()
						.decodeForHTML(notes.getAdditionalInfo()));
				objStickyNotesDetailsVO.setObjId(notes.getObjId());
				final XMLGregorianCalendar entryTime = notes.getEntryTime();
				zoneFormater.setTimeZone(timZone);
				if (null != notes.getEntryTime()) {
					objStickyNotesDetailsVO.setEntryTime(zoneFormater
							.format(entryTime.toGregorianCalendar().getTime()));
				}
				objStickyNotesDetailsVO
						.setStickyAssets(notes.getStickyAssets());
				objStickyNotesDetailsVOList.add(objStickyNotesDetailsVO);
			}
		} catch (Exception e) {
			logger.error(
					"Exception occured in fetchStickyCaseNOtes in NotesServiceImpl:",
					e);
			RMDWebErrorHandler.handleException(e);
		}
		return objStickyNotesDetailsVOList;
	}

	/**
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Find Notes From Date default value.
	 */
	@Override
	public String getFindNotesLookBackDays() throws RMDWebException {

		String strFindNotesLookBackDays = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.FINDNOTES_LOOKBACK_DAYS);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					strFindNotesLookBackDays = applParamResponseType[i]
							.getLookupValue();
				}
			}
		} catch (Exception ex) {
			logger.error(
					"Exception occured in getFindNotesLookBakDays method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return strFindNotesLookBackDays;

	}

	/**
	 * @Author:
	 * @param:FindCasesDetailsVO
	 * @return:List<FindCasesDetailsVO>
	 * @throws:RMDWebException
	 * @Description: This method is used to get Find Notes Details.
	 */
	@Override
	public List<FindNotesDetailsVO> getFindNotes(NotesBean objNotesBean,
			String timeZone) throws RMDWebException {
		List<FindNotesDetailsVO> objFindNotesDetailsVOList = null;
		NotesRequestType objNotesRequestType = new NotesRequestType();
		FindNotesResponseType findNotesResponseType[] = null;
		FindNotesDetailsVO objFindNotesDetailsVO = null;
		DateFormat defaultZoneFomatter = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmm);
		defaultZoneFomatter.setTimeZone(TimeZone.getTimeZone(AppConstants.DEFAULT_TIME_ZONE));
		
		DateFormat userZoneFormatter = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmm);
		userZoneFormatter.setTimeZone(TimeZone.getTimeZone(timeZone));
		
		try {
			objNotesRequestType.setCustomerID(objNotesBean.getCustomerId());
			objNotesRequestType.setFromRN(objNotesBean.getFromRN());
			objNotesRequestType.setToRN(objNotesBean.getToRN());
			objNotesRequestType.setModelId(objNotesBean.getModelId());
			objNotesRequestType.setFleetId(objNotesBean.getFleetId());
			objNotesRequestType.setCtrlId(objNotesBean.getCtrlId());
			objNotesRequestType.setCreatedBy(objNotesBean.getCreatedBy());
			objNotesRequestType.setNoteType(objNotesBean.getNotesType());
			objNotesRequestType.setStartDate(objNotesBean.getStartDate());
			objNotesRequestType.setEndDate(objNotesBean.getEndDate());
			objNotesRequestType.setSearchKeyWord(objNotesBean
					.getSearchKeyWord());

			// Call web service for find Notes
			findNotesResponseType = (FindNotesResponseType[]) rsInvoker.post(
					ServiceConstants.GET_FIND_NOTES, objNotesRequestType,
					FindNotesResponseType[].class);

			if (null != findNotesResponseType) {

				objFindNotesDetailsVOList = new ArrayList<FindNotesDetailsVO>(
						findNotesResponseType.length);

				for (FindNotesResponseType objNotesDetailsResponseType : findNotesResponseType) {
					objFindNotesDetailsVO = new FindNotesDetailsVO();
					objFindNotesDetailsVO
							.setCustomerName(objNotesDetailsResponseType
									.getCustomerName());
					objFindNotesDetailsVO.setRn(objNotesDetailsResponseType
							.getAssetNumber());
					objFindNotesDetailsVO.setCaseId(objNotesDetailsResponseType
							.getCaseID());
					objFindNotesDetailsVO
							.setModelName(objNotesDetailsResponseType
									.getModel());
					objFindNotesDetailsVO
							.setCtrlName(objNotesDetailsResponseType
									.getCtrlName());
					if (null != objNotesDetailsResponseType.getCreationDate()) {
						
						if(timeZone.equals(AppConstants.DEFAULT_TIME_ZONE)) {
							objFindNotesDetailsVO.setDate(objNotesDetailsResponseType
											.getCreationDate());
						} else {
							objFindNotesDetailsVO.setDate(userZoneFormatter
								.format(defaultZoneFomatter.parse(objNotesDetailsResponseType
										.getCreationDate())));
						}
					}
					objFindNotesDetailsVO
							.setCreatedBy(objNotesDetailsResponseType
									.getCreatedBy());
					objFindNotesDetailsVO
							.setNoteType(objNotesDetailsResponseType
									.getNoteType());
					objFindNotesDetailsVO.setNoteDescription(ESAPI.encoder()
							.decodeForHTML(
									objNotesDetailsResponseType
											.getNoteDescription()));
					objFindNotesDetailsVO
							.setNoteObjId(objNotesDetailsResponseType
									.getNoteSeqID());
					objFindNotesDetailsVO
							.setStickyFlag(objNotesDetailsResponseType
									.getStickyFlag());
					objFindNotesDetailsVOList.add(objFindNotesDetailsVO);
				}
			}
			findNotesResponseType = null;
			objNotesRequestType = null;
			objFindNotesDetailsVO = null;
		} catch (Exception ex) {
			logger.error("Exception occured in getFindNotes method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return objFindNotesDetailsVOList;
	}

	/**
	 * @Author:
	 * @param :caseStickyObjId,unitStickyObjId
	 * @return:String
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used for removing a unit Level as well as
	 *               case Level Sticky Notes.
	 */
	@Override
	public String removeSticky(String unitStickyObjId, String caseStickyObjId)
			throws RMDWebException {
		String result = null;
		try {
			StickyNotesDetailsResponseType objStickyDetailsResponseType = new StickyNotesDetailsResponseType();
			objStickyDetailsResponseType.setCaseStickyObjId(caseStickyObjId);
			objStickyDetailsResponseType.setUnitStickyObjId(unitStickyObjId);
			result = (String) rsInvoker.post(
					ServiceConstants.FIND_NOTES_REMOVE_STICKY,
					objStickyDetailsResponseType, String.class);

		} catch (Exception e) {
			logger.error(
					"Exception occured in removeSticky in NotesServiceImpl:", e);
			RMDWebErrorHandler.handleException(e);
		}
		return result;
	}

}
