package com.ge.trans.rmd.cm.mvc.model;

public class DataModel {
	
	
	private String value;
	private String heatMapFlag;
	public String getValue() {
		return value;
	}
	public void setValue(final String value) {
		this.value = value; 
	}
	public String getHeatMapFlag() {
		return heatMapFlag;
	}
	public void setHeatMapFlag(final String heatMapFlag) {
		this.heatMapFlag = heatMapFlag;
	}
	
}
