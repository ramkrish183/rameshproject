package com.ge.trans.rmd.cm.valueobjects;

public class ConfigSearchVO extends LDVRAssetTemplateRequestVO{

	
	private String ctrlcfgObjId;
	private String vehicleObjId;
	private boolean isCaseMassApplyCFG;
	private String timeZone;
	private String defaultTimeZone;
	
	
	public String getCtrlcfgObjId() {
		return ctrlcfgObjId;
	}
	public void setCtrlcfgObjId(String ctrlcfgObjId) {
		this.ctrlcfgObjId = ctrlcfgObjId;
	}
	public String getVehicleObjId() {
		return vehicleObjId;
	}
	public void setVehicleObjId(String vehicleObjId) {
		this.vehicleObjId = vehicleObjId;
	}
	public boolean isCaseMassApplyCFG() {
		return isCaseMassApplyCFG;
	}
	public void setCaseMassApplyCFG(boolean isCaseMassApplyCFG) {
		this.isCaseMassApplyCFG = isCaseMassApplyCFG;
	}
	public String getTimeZone() {
		return timeZone;
	}
	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}
	public String getDefaultTimeZone() {
		return defaultTimeZone;
	}
	public void setDefaultTimeZone(String defaultTimeZone) {
		this.defaultTimeZone = defaultTimeZone;
	}
	
}
