package com.ge.trans.rmd.cm.valueobjects;

import java.util.Date;

public class LDVRStatusVO {
private String cameraNumber;
private Date startTime;
private String lat;
private String lon;
private String zeroSpeedStopped;
private String extDriveRemotelyStopped;
private String gpsSourceLoss;
private String recordingStatus;
private Date extDriveLatestFileTime;
private String preservationKBFree;
private String intDriveKBFree;
private String extDriveKBFree;
private String speedSourceLoss;



public String getSpeedSourceLoss() {
	return speedSourceLoss;
}
public void setSpeedSourceLoss(String speedSourceLoss) {
	this.speedSourceLoss = speedSourceLoss;
}
public String getZeroSpeedStopped() {
	return zeroSpeedStopped;
}
public void setZeroSpeedStopped(String zeroSpeedStopped) {
	this.zeroSpeedStopped = zeroSpeedStopped;
}
public String getExtDriveRemotelyStopped() {
	return extDriveRemotelyStopped;
}
public void setExtDriveRemotelyStopped(String extDriveRemotelyStopped) {
	this.extDriveRemotelyStopped = extDriveRemotelyStopped;
}
public String getGpsSourceLoss() {
	return gpsSourceLoss;
}
public void setGpsSourceLoss(String gpsSourceLoss) {
	this.gpsSourceLoss = gpsSourceLoss;
}
public Date getExtDriveLatestFileTime() {
	return extDriveLatestFileTime;
}
public void setExtDriveLatestFileTime(Date extDriveLatestFileTime) {
	this.extDriveLatestFileTime = extDriveLatestFileTime;
}
public String getCameraNumber() {
	return cameraNumber;
}
public void setCameraNumber(String cameraNumber) {
	this.cameraNumber = cameraNumber;
}
public Date getStartTime() {
	return startTime;
}
public void setStartTime(Date startTime) {
	this.startTime = startTime;
}
public String getLat() {
	return lat;
}
public void setLat(String lat) {
	this.lat = lat;
}
public String getLon() {
	return lon;
}
public void setLon(String lon) {
	this.lon = lon;
}

public String getRecordingStatus() {
	return recordingStatus;
}
public void setRecordingStatus(String recordingStatus) {
	this.recordingStatus = recordingStatus;
}

public String getPreservationKBFree() {
	return preservationKBFree;
}
public void setPreservationKBFree(String preservationKBFree) {
	this.preservationKBFree = preservationKBFree;
}
public String getIntDriveKBFree() {
	return intDriveKBFree;
}
public void setIntDriveKBFree(String intDriveKBFree) {
	this.intDriveKBFree = intDriveKBFree;
}
public String getExtDriveKBFree() {
	return extDriveKBFree;
}
public void setExtDriveKBFree(String extDriveKBFree) {
	this.extDriveKBFree = extDriveKBFree;
}

}
