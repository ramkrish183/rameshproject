package com.ge.trans.rmd.cm.valueobjects;

public class CaseScoreRepairCodeVO 
{
	
	private String repairCode ;
	private String description;
	private String repairCodeId;
	
	
	public String getRepairCode() {
		return repairCode;
	}
	public void setRepairCode(String repairCode) {
		this.repairCode = repairCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRepairCodeId() {
		return repairCodeId;
	}
	public void setRepairCodeId(String repairCodeId) {
		this.repairCodeId = repairCodeId;
	}
	
	
}
