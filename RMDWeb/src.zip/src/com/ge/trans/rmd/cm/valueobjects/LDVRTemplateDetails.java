package com.ge.trans.rmd.cm.valueobjects;
import java.util.List;

import com.ge.trans.rmd.services.locovision.valueobjects.LDVRSaveTemplateGeofenceType;


/**
 * This pojo contains all the possible values to the corresponding templates
 */

public class LDVRTemplateDetails {

	// 8360 LDVR Template Related parameters
	private List<Integer> cameraList = null;
	private String requestedEndTime = null;
	private Long importance = null;
	private Long deletionType = null;
	private LDVRTimeFrameVO timeframe = null;
	private LDVRSaveTemplateGeofenceVO geoZone = null;
	private LDVREventVO event = null;

	public List<Integer> getCameraList() {
		return cameraList;
	}

	public void setCameraList(List<Integer> cameraList) {
		this.cameraList = cameraList;
	}

	public String getRequestedEndTime() {
		return requestedEndTime;
	}

	public void setRequestedEndTime(String requestedEndTime) {
		this.requestedEndTime = requestedEndTime;
	}

	public Long getImportance() {
		return importance;
	}

	public void setImportance(Long importance) {
		this.importance = importance;
	}

	public Long getDeletionType() {
		return deletionType;
	}

	public void setDeletionType(Long deletionType) {
		this.deletionType = deletionType;
	}

	public LDVRTimeFrameVO getTimeframe() {
		return timeframe;
	}

	public void setTimeframe(LDVRTimeFrameVO timeframe) {
		this.timeframe = timeframe;
	}

	public LDVREventVO getEvent() {
		return event;
	}

	public void setEvent(LDVREventVO event) {
		this.event = event;
	}

	/**
	 * @return the geoZone
	 */
	public LDVRSaveTemplateGeofenceVO getGeoZone() {
		return geoZone;
	}

	/**
	 * @param geoZone the geoZone to set
	 */
	public void setGeoZone(LDVRSaveTemplateGeofenceVO geoZone) {
		this.geoZone = geoZone;
	}

	
}
