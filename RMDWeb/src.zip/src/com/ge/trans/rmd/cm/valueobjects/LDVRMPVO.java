package com.ge.trans.rmd.cm.valueobjects;
/**
 * This pojo contains all the possible values to the corresponding templates
 * Mp based
 */

public class LDVRMPVO {

	private Long mpParams = null;
	private Long mpOperator = null;
	private String mpValue = null;

	public Long getMpParams() {
		return mpParams;
	}

	public void setMpParams(Long mpParams) {
		this.mpParams = mpParams;
	}

	public Long getMpOperator() {
		return mpOperator;
	}

	public void setMpOperator(Long mpOperator) {
		this.mpOperator = mpOperator;
	}

	public String getMpValue() {
		return mpValue;
	}

	public void setMpValue(String mpValue) {
		this.mpValue = mpValue;
	}

}
