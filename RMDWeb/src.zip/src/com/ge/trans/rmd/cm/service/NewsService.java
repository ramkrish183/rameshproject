package com.ge.trans.rmd.cm.service;

import java.util.List;
import com.ge.trans.rmd.cm.valueobjects.InsertNewsVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.NewsAllVO;

public interface NewsService {

	public String saveNews(InsertNewsVO insertNewsVO)
            throws RMDWebException;
	public List<NewsAllVO> getAllNews(String userId,String isAdminPage,String customerId)
			throws RMDWebException;
	
	public String deleteNews(String objId)
			throws RMDWebException;
	public String getBackgroundImage(String customerId)
            throws RMDWebException;
	public String updateReadFlag(String objId)
			throws RMDWebException;
}
