package com.ge.trans.rmd.cm.valueobjects;

public class BOMMaintenanceVO {

	private String objid;
	private String configList;
	public String getObjid() {
		return objid;
	}
	public void setObjid(String objid) {
		this.objid = objid;
	}
	public String getConfigList() {
		return configList;
	}

	public void setConfigList(String configList) {
		this.configList = configList;
	}
}
