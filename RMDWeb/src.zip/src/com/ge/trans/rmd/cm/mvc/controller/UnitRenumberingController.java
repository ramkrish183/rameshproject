package com.ge.trans.rmd.cm.mvc.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.ParseException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.CreateCasesService;
import com.ge.trans.rmd.cm.service.UnitRenumberingService;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.valueobjects.UnitRoadHeaderUpdateVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.pp.beans.AssetBean;

@Controller
@SessionAttributes
public class UnitRenumberingController extends RMDBaseController {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	UnitRenumberingService unitRenumberingService;
	@RequestMapping(value = AppConstants.REQ_URI_UNIT_RENUMBER, method = RequestMethod.GET)
	public ModelAndView getUnitRenumberingPage(final HttpServletRequest request)
			throws RMDWebException {
		return new ModelAndView(AppConstants.VIEW_UNIT_RENUMBER);
	}
	
	@RequestMapping(value = AppConstants.UPDATE_UNIT_NUMBER)
	@ResponseBody
	public String updateUnitNumber(
			@RequestParam(value = AppConstants.UNIT_CUSTOMER_ID) final String customerId,
			@RequestParam(value = AppConstants.UNIT_VEHICLE_HEADER) final String vehicleHeader,
			@RequestParam(value = AppConstants.FROM_UNIT) final String fromUnit,
			@RequestParam(value = AppConstants.TO_UNIT) final String toUnit,
			final HttpServletRequest request) throws RMDWebException {
		String response = null;
		try{
			rmdWebLogger.info("Inside RMDWeb Controller:"+vehicleHeader+":"+fromUnit+":"+toUnit);
			response = unitRenumberingService.updateUnitNumber(EsapiUtil.stripXSSCharacters(fromUnit), EsapiUtil.stripXSSCharacters(toUnit), EsapiUtil.stripXSSCharacters(vehicleHeader), EsapiUtil.stripXSSCharacters(customerId));
		} catch (Exception ex) {
			rmdWebLogger
			.error("Exception occured in updateUnitNumber  method in UnitRenumberController",
					ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return response;
	}
	
	@RequestMapping(value = AppConstants.UPDATE_UNIT_HEADER, method = RequestMethod.POST)
	@ResponseBody
	public String updateRoadHeader(HttpServletRequest request) throws RMDWebException {
		final ObjectMapper mapper = new ObjectMapper();
		String response = null;
		try {
			UnitRoadHeaderUpdateVO unitRoadHeaderUpdate = mapper.readValue(EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.PARAM_STRING)), UnitRoadHeaderUpdateVO.class);
			response = unitRenumberingService.updateUnitHeader(unitRoadHeaderUpdate);
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in updateRoadHeader method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return response;
	}
	
	/**
	 * 
	 * @param customerId
	 * @param assetGroup
	 * @param assetNumber
	 * @param request
	 * @param model
	 * @return
	 * @Description This method will return the list of asset numbers for given
	 *              keys like customerId, assetGroup and asset number
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GETSOLASSETNUM_UNITRENUM, method = RequestMethod.GET)
	public @ResponseBody
	java.util.List<String> getAssetNumbers(
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId,
			@RequestParam(value = AppConstants.CREATCASE_ASSTGRP, required = true) final String assetGroup,
			@RequestParam(value = AppConstants.ASSET_NUMBER, required = true) final String assetNumber,
			@RequestParam(value = AppConstants.FLEET) final String fleet,
			final HttpServletRequest request, final Model model) throws RMDWebException {
		rmdWebLogger
		.debug("Inside CreateCaseController in getAssetNumbers Method");
		List<String> assetNumbers = null;
		AssetBean assetBean;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
		.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {

			assetBean = new AssetBean();
			assetBean.setUserFirstName(userVO.getStrFirstName());
			assetBean.setUserLastName(userVO.getStrLastName());
			assetBean.setUserId(userVO.getUserId());
			assetBean.setUserLanguage(userVO.getStrUserLanguage());
			assetBean.setCustomerId(customerId);
			assetBean.setAssetGroup(assetGroup);
			assetBean.setAssetNumber(assetNumber);
			assetBean.setFleetId(fleet);
			assetNumbers = unitRenumberingService.getAssets(assetBean);

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getAssetNumbers method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return assetNumbers;

	}
}

