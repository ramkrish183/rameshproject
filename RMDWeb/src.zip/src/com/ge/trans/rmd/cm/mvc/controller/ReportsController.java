package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.ReportsService;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.valueobjects.ComStatusVO;
import com.ge.trans.rmd.common.valueobjects.MineVO;
import com.ge.trans.rmd.common.valueobjects.ReportsRxVO;
import com.ge.trans.rmd.common.valueobjects.ReportsTruckEventsVO;
import com.ge.trans.rmd.common.valueobjects.TruckGraphVO;
import com.ge.trans.rmd.common.valueobjects.TruckParamVO;
import com.ge.trans.rmd.common.valueobjects.TruckVO;
import com.ge.trans.rmd.common.vo.UserVO;

@Controller
@SessionAttributes
public class ReportsController extends RMDBaseController{
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	
	@Autowired
	ReportsService reportsService;
	@Autowired
	private ApplicationContext appContext;
	@RequestMapping(AppConstants.REQ_URI_TRUCK)
    public ModelAndView truckReportPage(final HttpServletRequest request)
    		throws RMDWebException {
    	rmdWebLogger
    	.debug("Inside ReportsController in truckReportPage Method");
    	try {
    		HttpSession session = request.getSession(false);
    		UserVO userVO = (UserVO) session
    				.getAttribute(AppConstants.ATTR_USER_OBJECT);
    		request.setAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE,
    				userVO.getIsCMPrivilege());
    		rmdWebLogger.info("TruckId::"+request.getAttribute("truckId"));
    	} catch (Exception ex) {
    		rmdWebLogger
    		.error("Exception occured in truckReportPage() method in ReportsController ",
    				ex);
    		RMDWebErrorHandler.handleException(ex);
    	}
    	return new ModelAndView(AppConstants.TRUCK_REPORT);
    }
    
    @RequestMapping(AppConstants.REQ_URI_MINE)
    public ModelAndView mineReportPage(final HttpServletRequest request)
    		throws RMDWebException {
    	rmdWebLogger
    	.debug("Inside ReportsController in mineReportPage Method");
    	MineVO mine = null;
    	try {
    		HttpSession session = request.getSession(false);    		
    		UserVO userVO = (UserVO) session
    				.getAttribute(AppConstants.ATTR_USER_OBJECT);
    		request.setAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE,
    				userVO.getIsCMPrivilege());
    		final String defaultCustomer = userVO.getCustomerId();
    		boolean geLevelReport = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.SUBMENU_OHV_MINE_GE_LEVEL_REPORTS);
    		request.setAttribute("geLevelReport", geLevelReport);
    		if(defaultCustomer != null) {
	    		rmdWebLogger.info("Default from UserVO: "+userVO.getCustomerId());
	    		mine = reportsService.getMine(defaultCustomer , request);
	    		if(mine == null || mine.getTrucks().isEmpty()) {
	    			request.setAttribute("error", AppConstants.REPORT_NO_TRUCK_ERROR);
	    		} else {
		    		mine.setMine(userVO.getCustomerName());
		    		request.setAttribute("mine", mine);
	    		}
    		} else {
    			request.setAttribute("error", AppConstants.REPORT_DEFAULT_CUST_ERROR);
    		}
    	} catch (Exception ex) {
    		rmdWebLogger
    		.error("Exception occured in mineReportPage() method in ReportsController ",
    				ex);
    		RMDWebErrorHandler.handleException(ex);
    	}    	
    	return new ModelAndView(AppConstants.MINE_REPORT);
    }

    
	
	@RequestMapping(value = AppConstants.OHV_REPORTS_GET_RX)
	@ResponseBody
	public List<ReportsRxVO> getRx(
			@RequestParam(value = AppConstants.REPORTS_CUSTOMER_ID) final String customerId,
			@RequestParam(value = AppConstants.REPORTS_TRUCK_ID) final String truckId,
			@RequestParam(value = AppConstants.REPORTS_RX_TYPE) final String rxType,
			@RequestParam(value = AppConstants.REPORTS_RX_URGENCY) final String urgency,
			final HttpServletRequest request) throws RMDWebException {
		List<ReportsRxVO> reportsRxVOList = new ArrayList<ReportsRxVO>();
		try{
			HttpSession session = request.getSession(false);
    		UserVO userVO = (UserVO) session
    				.getAttribute(AppConstants.ATTR_USER_OBJECT);
    		final String defaultTimezone = (String) request
    				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
			String preferredTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
					userVO.getTimeZone());
			reportsRxVOList = reportsService.getReportsRx(EsapiUtil.stripXSSCharacters(customerId), EsapiUtil.stripXSSCharacters(truckId), EsapiUtil.stripXSSCharacters(rxType),EsapiUtil.stripXSSCharacters(urgency), preferredTimezone);
			//request.setAttribute(AppConstants.REPORTS_RX_VO_LIST, reportsRxVOList);
		} catch (Exception ex) {
			rmdWebLogger
			.error("Exception occured in getRx  method in ReportController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return reportsRxVOList;
	}
	
	@RequestMapping(value = AppConstants.OHV_REPORTS_TRUCK_EVENTS)
	@ResponseBody
	public List<ReportsTruckEventsVO> getTruckEvents(
			@RequestParam(value = AppConstants.REPORTS_CUSTOMER_ID) final String customerId,
			@RequestParam(value = AppConstants.REPORTS_TRUCK_ID) final String truckId,
			final HttpServletRequest request) throws RMDWebException {
		List<ReportsTruckEventsVO> reportsTruckEventsVOList = new ArrayList<ReportsTruckEventsVO>();
		try{
			HttpSession session = request.getSession(false);
    		UserVO userVO = (UserVO) session
    				.getAttribute(AppConstants.ATTR_USER_OBJECT);
    		final String defaultTimezone = (String) request
    				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
			String preferredTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
					userVO.getTimeZone());
			reportsTruckEventsVOList = reportsService.getReportsTruckEvents(EsapiUtil.stripXSSCharacters(customerId), EsapiUtil.stripXSSCharacters(truckId), preferredTimezone);
		} catch (Exception ex) {
			rmdWebLogger
			.error("Exception occured in getTruckEvents  method in ReportController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return reportsTruckEventsVOList;
	}
	
	@RequestMapping(value = AppConstants.OHV_REPORTS_TRUCK_INFO)
	@ResponseBody
	public TruckVO getTruckInfo(
			@RequestParam(value = AppConstants.REPORTS_MINE_ID) final String mineId,
			@RequestParam(value = AppConstants.REPORTS_TRUCK_ID) final String truckId,
			final HttpServletRequest request) throws RMDWebException {
		TruckVO truckInfo = null;
		try{
			truckInfo = reportsService.getTruckInfo(EsapiUtil.stripXSSCharacters(mineId), EsapiUtil.stripXSSCharacters(truckId), request);
		} catch (Exception ex) {
			rmdWebLogger
			.error("Exception occured in getTruckInfo  method in ReportController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return truckInfo;
	}
	
	@RequestMapping(value = AppConstants.OHV_REPORTS_COM_STATUS)
	@ResponseBody
	public ComStatusVO getComStatus(
			@RequestParam(value = AppConstants.REPORTS_MINE_ID) final String mineId,
			@RequestParam(value = AppConstants.REPORTS_TRUCK_ID) final String truckId,
			final HttpServletRequest request) throws RMDWebException {
		ComStatusVO comStatus = null;
		try{
			comStatus = reportsService.getComStatus(EsapiUtil.stripXSSCharacters(mineId), EsapiUtil.stripXSSCharacters(truckId));
		} catch (Exception ex) {
			rmdWebLogger
			.error("Exception occured in getComStatus  method in ReportController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return comStatus;
	}
	
	@RequestMapping(value = AppConstants.OHV_REPORTS_TOP_EVENTS)
	@ResponseBody
	public List<ReportsTruckEventsVO> getTopMineEvents(
			final HttpServletRequest request) throws RMDWebException {
		List<ReportsTruckEventsVO> reportsTruckEventsVOList = new ArrayList<ReportsTruckEventsVO>();
		boolean geLevelReport = false;
		try{
			HttpSession session = request.getSession(false);
			UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
			geLevelReport = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.SUBMENU_OHV_MINE_GE_LEVEL_REPORTS);
			reportsTruckEventsVOList = reportsService.getTopMineEvents(EsapiUtil.stripXSSCharacters(userVO.getCustomerId()), geLevelReport);
		} catch (Exception ex) {
			rmdWebLogger
			.error("Exception occured in getTruckEvents  method in ReportController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return reportsTruckEventsVOList;
	}
	
	@RequestMapping(value = AppConstants.OHV_REPORTS_GRAPH_DATA)
	@ResponseBody
	public TruckGraphVO getTruckGraphData(@RequestParam(value = AppConstants.REPORTS_MINE_ID) final String mineId,
			@RequestParam(value = AppConstants.REPORTS_TRUCK_ID) final String truckId, final int period,
			final HttpServletRequest request) throws RMDWebException {
		TruckGraphVO graphParamData = new TruckGraphVO();
		try{
			HttpSession session = request.getSession(false);
    		UserVO userVO = (UserVO) session
    				.getAttribute(AppConstants.ATTR_USER_OBJECT);
    		final String defaultTimezone = (String) request
    				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
			String preferredTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
					userVO.getTimeZone());
			graphParamData = reportsService.getTruckGraphData(mineId, truckId, period, preferredTimezone);
		} catch (Exception ex) {
			rmdWebLogger
			.error("Exception occured in getTruckEvents  method in ReportController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return graphParamData;
	}
	
	@RequestMapping(value = AppConstants.OHV_REPORTS_TRUCK_VARIABLES_PARAM)
    @ResponseBody
    public List<TruckParamVO> getTruckVariablesParam(
    		@RequestParam(value = AppConstants.REPORTS_MINE_ID) final String mineId,
    		@RequestParam(value = AppConstants.REPORTS_TRUCK_ID) final String truckId,
    		final HttpServletRequest request) throws RMDWebException {
		List<TruckParamVO> truckParam = new ArrayList <TruckParamVO> ();
		String paramName = AppConstants.PARAM_NAME;
		String unitName = AppConstants.UNIT_NAME;
		List<String> paramNameList = Arrays.asList(paramName.split(","));
		List<String> unitNameList = Arrays.asList(unitName.split(","));
		try{

			Date toDate = new Date();
			DateFormat formatter = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
			formatter.setTimeZone(TimeZone.getTimeZone(RMDCommonConstants.DateConstants.EST_US));
			String toDateStr = formatter.format(toDate);
			Calendar cal = Calendar.getInstance();
			cal.setTime(toDate);
			cal.add(Calendar.DATE, -AppConstants.REPORTS_NUM_DAYS);
			Date fromDate = cal.getTime();
			String fromDateStr = formatter.format(fromDate);
			String xSSMineId = EsapiUtil.stripXSSCharacters(mineId);
			String xSSTruckId = EsapiUtil.stripXSSCharacters(truckId);
			List<String> truckParamOneDay = reportsService.getTruckVariablesParam(xSSMineId, 
					xSSTruckId, fromDateStr, toDateStr, false);
			/*
			Map<String, List<String>> truckVariablesList = reportsService.getTruckVariablesParamList(xSSMineId, xSSTruckId, false);
			List<String> truckParamLastMonth = truckVariablesList.get("LAST_MONTH");
			List<String> truckParamLastQtr = truckVariablesList.get("LAST_QUARTER");
			
			cal.setTime(new Date());
			cal.add(Calendar.DATE, -AppConstants.REPORTS_THIRTY_DAYS);
			fromDateStr = formatter.format(cal.getTime());
			List<String> truckParamThirtyDayAvg = reportsService.getTruckVariablesParam(xSSMineId, 
					xSSTruckId, fromDateStr, toDateStr, true );
			*/
			
			Map<String, List<String>> truckVariablesListScheduler = reportsService.getTruckVariablesParamListScheduler(xSSMineId, xSSTruckId, false);
			List<String> truckParamLastMonth = truckVariablesListScheduler.get("LAST_MONTH");
			List<String> truckParamLastQtr = truckVariablesListScheduler.get("LAST_QUARTER");
			List<String> truckParamThirtyDayAvg = truckVariablesListScheduler.get("THIRTY_DAY_AVG");

			int i = 0;
			for(String param : paramNameList){
				TruckParamVO truckParamVO = new TruckParamVO();
				truckParamVO.setParamName(param);
				truckParamVO.setParamUnit(unitNameList.get(i));
				truckParamVO.setOneDayValue(truckParamOneDay.get(i));
				truckParamVO.setThirtyDayAvgValue(truckParamThirtyDayAvg.get(i));
				truckParamVO.setLastMonthValue(truckParamLastMonth.get(i));
				truckParamVO.setLastQtrValue(truckParamLastQtr.get(i));
				truckParam.add(truckParamVO);
				i++;
			}

		} catch (Exception ex) {
			rmdWebLogger
			.error("Exception occured in getTruckInfo  method in ReportController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return truckParam;
	}
	
	@RequestMapping(AppConstants.EXPORT_TRUCK_EVENTS)
	@ResponseBody public  void exportTruckEvents(
			final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws RMDWebException, Exception {
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;		
		try {
			
			HttpSession session = request.getSession(false);
    		UserVO userVO = (UserVO) session
    				.getAttribute(AppConstants.ATTR_USER_OBJECT);
    		final String defaultTimezone = (String) request
    				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
			String preferredTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
					userVO.getTimeZone());
			List<ReportsTruckEventsVO> reportsEventsList = new ArrayList<ReportsTruckEventsVO>();
			final String mineId = request.getParameter("mineId");
			final String truckId = request.getParameter("truckId");
			reportsEventsList = reportsService.getReportsTruckEvents(EsapiUtil.stripXSSCharacters(mineId), EsapiUtil.stripXSSCharacters(truckId), preferredTimezone);

			csvContent = convertToCSVTruckEvents(
					reportsEventsList,
					locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.TRUCK_EVENT_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);
			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);
			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"Exception occured in exportTruckEvents method ", rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in exportTruckEvents method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}
	
	private String convertToCSVTruckEvents(
			List<ReportsTruckEventsVO> truckEventList,
			Locale locale) throws RMDWebException {
		String csvContent = null;
		StringBuilder strBuilderAssetHeader = new StringBuilder();
		try {
			strBuilderAssetHeader.append(appContext.getMessage(
					AppConstants.TRUCK_EVENT_HEADER, null, locale));

			strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);
			
			if (truckEventList != null){

			for (ReportsTruckEventsVO truckEvent : truckEventList) {
				
				
			
				if (truckEvent.getEventNumber() != null) {
					strBuilderAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + truckEvent.getEventNumber()
							+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (truckEvent.getSubId() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+truckEvent.getSubId()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				
				if (truckEvent.getDescription() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+truckEvent.getDescription()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				
				if (truckEvent.getOccurTime() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ truckEvent.getOccurTime()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (truckEvent.getResetTime() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ truckEvent.getResetTime()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				
				strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);
			}

				
			}
			csvContent = strBuilderAssetHeader.toString();
		} catch (Exception exception) {
			rmdWebLogger.error("Export to CSV Manage LDVR Request List"
					+ exception.getMessage());
			RMDWebErrorHandler.handleException(exception);
		}
		return csvContent;
	}
	
	@RequestMapping(AppConstants.EXPORT_TRUCK_RX)
	@ResponseBody public  void exportTruckRx(
			final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws RMDWebException, Exception {
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;		
		try {
			
			HttpSession session = request.getSession(false);
    		UserVO userVO = (UserVO) session
    				.getAttribute(AppConstants.ATTR_USER_OBJECT);
    		final String defaultTimezone = (String) request
    				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
			String preferredTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
					userVO.getTimeZone());
			List<ReportsRxVO> reportsRxVOList = new ArrayList<ReportsRxVO>();
			final String mineId = request.getParameter("mineId");
			final String truckId = request.getParameter("truckId");
			reportsRxVOList = reportsService.getReportsRx(EsapiUtil.stripXSSCharacters(mineId), EsapiUtil.stripXSSCharacters(truckId),"All", "All", preferredTimezone);
			csvContent = convertToCSVTruckRx(
					reportsRxVOList,
					locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.TRUCK_RX_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);
			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);
			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"Exception occured in exportTruckEvents method ", rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in exportTruckEvents method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}
	
	private String convertToCSVTruckRx(
			List<ReportsRxVO> truckRxList,
			Locale locale) throws RMDWebException {
		String csvContent = null;
		StringBuilder strBuilderAssetHeader = new StringBuilder();
		try {
			strBuilderAssetHeader.append(appContext.getMessage(
					AppConstants.TRUCK_RX_HEADER, null, locale));

			strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);
			
			if (truckRxList != null){

			for (ReportsRxVO truckRx : truckRxList) {
				
				
			
				if (truckRx.getRxObjid() != null) {
					strBuilderAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + truckRx.getRxObjid()
							+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (truckRx.getRxTitle() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+truckRx.getRxTitle()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				
				if (truckRx.getRxDeliverDate() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+truckRx.getRxDeliverDate()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				
				if (truckRx.getRxClosedDate() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ truckRx.getRxClosedDate()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}				
				
				strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);
			}

				
			}
			csvContent = strBuilderAssetHeader.toString();
		} catch (Exception exception) {
			rmdWebLogger.error("Export to CSV Manage LDVR Request List"
					+ exception.getMessage());
			RMDWebErrorHandler.handleException(exception);
		}
		return csvContent;
	}
	
	@RequestMapping(AppConstants.EXPORT_TRUCK_VARIABLES)
	@ResponseBody public  void exportTruckVariables(
			final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws RMDWebException, Exception {
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;		
		try {
			final String mineId = request.getParameter("mineId");
			final String truckId = request.getParameter("truckId");
			
			List<TruckParamVO> truckParam = new ArrayList <TruckParamVO> ();
			String paramName = AppConstants.PARAM_NAME;
			String unitName = AppConstants.UNIT_NAME;
			List<String> paramNameList = Arrays.asList(paramName.split(","));
			List<String> unitNameList = Arrays.asList(unitName.split(","));
		
			Date toDate = new Date();
			DateFormat formatter = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
			formatter.setTimeZone(TimeZone.getTimeZone(RMDCommonConstants.DateConstants.EST_US));
			String toDateStr = formatter.format(toDate);
			Calendar cal = Calendar.getInstance();
			cal.setTime(toDate);
			cal.add(Calendar.DATE, -AppConstants.REPORTS_NUM_DAYS);
			Date fromDate = cal.getTime();
			String fromDateStr = formatter.format(fromDate);
			String xSSMineId = EsapiUtil.stripXSSCharacters(mineId);
			String xSSTruckId = EsapiUtil.stripXSSCharacters(truckId);
			List<String> truckParamOneDay = reportsService.getTruckVariablesParam(xSSMineId, 
					xSSTruckId, fromDateStr, toDateStr, false);
			
			/*Map<String, List<String>> truckVariablesList = reportsService.getTruckVariablesParamList(xSSMineId, xSSTruckId, false);
			List<String> truckParamLastMonth = truckVariablesList.get("LAST_MONTH");
			List<String> truckParamLastQtr = truckVariablesList.get("LAST_QUARTER");
			
			cal.setTime(new Date());
			cal.add(Calendar.DATE, -AppConstants.REPORTS_THIRTY_DAYS);
			fromDateStr = formatter.format(cal.getTime());
			List<String> truckParamThirtyDayAvg = reportsService.getTruckVariablesParam(xSSMineId, 
					xSSTruckId, fromDateStr, toDateStr, true );*/
			
			Map<String, List<String>> truckVariablesListScheduler = reportsService.getTruckVariablesParamListScheduler(xSSMineId, xSSTruckId, false);
			List<String> truckParamLastMonth = truckVariablesListScheduler.get("LAST_MONTH");
			List<String> truckParamLastQtr = truckVariablesListScheduler.get("LAST_QUARTER");
			List<String> truckParamThirtyDayAvg = truckVariablesListScheduler.get("THIRTY_DAY_AVG");

			int i = 0;
			for(String param : paramNameList){
				TruckParamVO truckParamVO = new TruckParamVO();
				truckParamVO.setParamName(param);
				truckParamVO.setParamUnit(unitNameList.get(i));
				truckParamVO.setOneDayValue(truckParamOneDay.get(i));
				truckParamVO.setThirtyDayAvgValue(truckParamThirtyDayAvg.get(i));
				truckParamVO.setLastMonthValue(truckParamLastMonth.get(i));
				truckParamVO.setLastQtrValue(truckParamLastQtr.get(i));
				truckParam.add(truckParamVO);
				i++;
			}
			
			csvContent = convertToCSVTruckVariables(
					truckParam,
					locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.TRUCK_VARIABLES_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);
			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);
			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"Exception occured in exportTruckEvents method ", rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in exportTruckEvents method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}
	
	private String convertToCSVTruckVariables(
			List<TruckParamVO> truckVariablesList,
			Locale locale) throws RMDWebException {
		String csvContent = null;
		StringBuilder strBuilderAssetHeader = new StringBuilder();
		try {
			strBuilderAssetHeader.append(appContext.getMessage(
					AppConstants.TRUCK_VARIABLES_HEADER, null, locale));

			strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);
			
			if (truckVariablesList != null){

			for (TruckParamVO truckVariable : truckVariablesList) {
				
				
			
				if (truckVariable.getParamName() != null) {
					strBuilderAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + truckVariable.getParamName()
							+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (truckVariable.getParamUnit() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+truckVariable.getParamUnit()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				
				if (truckVariable.getOneDayValue() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+truckVariable.getOneDayValue()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				
				if (truckVariable.getThirtyDayAvgValue() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ truckVariable.getThirtyDayAvgValue()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (truckVariable.getLastMonthValue() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ truckVariable.getLastMonthValue()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}	
				if (truckVariable.getLastQtrValue() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ truckVariable.getLastQtrValue()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (truckVariable.getLifeTimeValue() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ truckVariable.getLifeTimeValue()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}				
				strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);
			}

				
			}
			csvContent = strBuilderAssetHeader.toString();
		} catch (Exception exception) {
			rmdWebLogger.error("Export to CSV Manage LDVR Request List"
					+ exception.getMessage());
			RMDWebErrorHandler.handleException(exception);
		}
		return csvContent;
	}

	@RequestMapping(value=AppConstants.EXPORT_PDF, method=RequestMethod.POST)
	@ResponseBody
	public ResponseEntity<byte[]> exportPDF(@RequestBody String mine) throws RMDWebException, UnsupportedEncodingException 
	{
		ResponseEntity<byte[]> response = null;
		 PDDocument document = new PDDocument();
		final String decoded = URLDecoder.decode(mine, "UTF-8");
		try
		{
			/*Add content*/
			document = reportsService.getMinePdfDocument(document,decoded);	
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			document.save(out);		
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.parseMediaType("application/pdf"));
			headers.add("Access-Control-Allow-Origin", "*");
			headers.add("Access-Control-Allow-Methods", "GET, POST, PUT");
			headers.add("Access-Control-Allow-Headers", "Content-Type");
			headers.add("Content-Disposition", "attachment; filename=\"Mine_Report.pdf\"");
			headers.add("Cache-Control", "no-cache, no-store, must-revalidate,max-age=30");
			 headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			 headers.add("content-Transfer-Encoding", "base64");
			headers.add("Pragma", "no-cache");
			headers.add("Expires", "0");
			headers.setContentLength(out.size());
			response = new ResponseEntity<byte[]>(out.toByteArray(), headers,HttpStatus.OK);
		}
		catch (IOException ioEx)
		{
			rmdWebLogger.error("Exception occured while creating the PDF report for Mine Report "+ioEx.getMessage());
			RMDWebErrorHandler.handleException(ioEx);
		} catch (Exception e) {
			rmdWebLogger.error("COSVisitorException occured while creating the PDF report for Mine Report "+e.getMessage());
			RMDWebErrorHandler.handleException(e);
		} finally {
			try {
				document.close();
			} catch (IOException e) {
				RMDWebErrorHandler.handleException(e);
			}
		}
		return response;
	}
	

	@RequestMapping(value="/exportTruckPdf", method=RequestMethod.POST)
	public ResponseEntity<byte[]> exportTruckPdf(@RequestBody String truck) throws RMDWebException, UnsupportedEncodingException 
	{
		
		ResponseEntity<byte[]> response = null;
		 PDDocument document = new PDDocument();
		final String decoded = URLDecoder.decode(truck, "UTF-8");
		rmdWebLogger.info("Json ::"+decoded);		
		try
		{
			rmdWebLogger.info("exportTruckPdf method start");
			/*Add content*/
			document = reportsService.getTruckPdfDocument(document,decoded);	
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			document.save(out);		
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.parseMediaType("application/pdf"));
			headers.add("Access-Control-Allow-Origin", "*");
			headers.add("Access-Control-Allow-Methods", "GET, POST, PUT");
			headers.add("Access-Control-Allow-Headers", "Content-Type");
			headers.add("Content-Disposition", "attachment; filename=\"Mine_Report.pdf\"");
			headers.add("Cache-Control", "no-cache, no-store, must-revalidate,max-age=30");
			 headers.setCacheControl("must-revalidate, post-check=0, pre-check=0");
			 headers.add("content-Transfer-Encoding", "base64");
			headers.add("Pragma", "no-cache");
			headers.add("Expires", "0");
			headers.setContentLength(out.size());
			response = new ResponseEntity<byte[]>(out.toByteArray(), headers,HttpStatus.OK);
			rmdWebLogger.info("exportTruckPdf method end");
		}
		catch (IOException ioEx)
		{
			rmdWebLogger.error("Exception occured while creating the PDF report for Mine Report "+ioEx.getMessage());
			RMDWebErrorHandler.handleException(ioEx);
		} catch (Exception e) {
			rmdWebLogger.error("COSVisitorException occured while creating the PDF report for Mine Report "+e.getMessage());
			RMDWebErrorHandler.handleException(e);
		} finally {
			try {
				document.close();
			} catch (IOException e) {
				RMDWebErrorHandler.handleException(e);
			}
		}
		return response;
	}

	

}
