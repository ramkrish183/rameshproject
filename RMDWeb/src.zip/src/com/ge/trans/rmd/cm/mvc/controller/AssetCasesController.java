package com.ge.trans.rmd.cm.mvc.controller;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.Future;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.map.MultiValueMap;
import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.beans.OpenCasesBean;
import com.ge.trans.rmd.cm.service.AssetCasesService;
import com.ge.trans.rmd.cm.service.AssetOverviewService;
import com.ge.trans.rmd.cm.service.CaseSolutionService;
import com.ge.trans.rmd.cm.service.CreateCasesService;
import com.ge.trans.rmd.cm.service.OpenCasesService;
import com.ge.trans.rmd.cm.valueobjects.AppendSummaryVO;
import com.ge.trans.rmd.cm.valueobjects.AssetInstalledProductVO;
import com.ge.trans.rmd.cm.valueobjects.AssetLocatorResponseVO;
import com.ge.trans.rmd.cm.valueobjects.CaseActionVO;
import com.ge.trans.rmd.cm.valueobjects.CaseHistoryVO;
import com.ge.trans.rmd.cm.valueobjects.CaseMgmtUsersDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.CaseScoreRepairCodeVO;
import com.ge.trans.rmd.cm.valueobjects.CaseTypeBean;
import com.ge.trans.rmd.cm.valueobjects.CloseOutRepairCodeVO;
import com.ge.trans.rmd.cm.valueobjects.CloseSummaryVO;
import com.ge.trans.rmd.cm.valueobjects.CreateCasesVO;
import com.ge.trans.rmd.cm.valueobjects.CustomerFdbkVO;
import com.ge.trans.rmd.cm.valueobjects.DeliverSummaryVO;
import com.ge.trans.rmd.cm.valueobjects.MaterialUsageVO;
import com.ge.trans.rmd.cm.valueobjects.QueueDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.RecommDeliverVO;
import com.ge.trans.rmd.cm.valueobjects.RxDeliveryAttachmentVO;
import com.ge.trans.rmd.cm.valueobjects.RxDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.RxHistoryVO;
import com.ge.trans.rmd.cm.valueobjects.RxStatusHistoryVO;
import com.ge.trans.rmd.cm.valueobjects.SolutionDetailVO;
import com.ge.trans.rmd.cm.valueobjects.StickyNotesDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.SummaryResponseVO;
import com.ge.trans.rmd.cm.valueobjects.ToolOutputCaseAppendVO;
import com.ge.trans.rmd.cm.valueobjects.ToolOutputCaseCloseVO;
import com.ge.trans.rmd.cm.valueobjects.ToolOutputCaseMergeVO;
import com.ge.trans.rmd.cm.valueobjects.ToolOutputDeliverVO;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.beans.CaseHistoryBean;
import com.ge.trans.rmd.common.beans.CaseSolutionVO;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.beans.SolutionBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.ResourceVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.AppSecUtil;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class AssetCasesController extends RMDBaseController {
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private AssetCasesService assetCasesService;
	@Autowired
	private CaseSolutionService CaseSolutionService;
	@Autowired
	private AssetOverviewService asstOvwService;

	@Autowired
	OpenCasesService openCasesService;
	@Autowired
	private CreateCasesService objcreateCasesService;

	@Value("${" + AppConstants.ESERVICES_URL + "}")
	String eServicesUrl;

	/**
	 * @Author:
	 * @param request
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description: Retrieve the case details for open and set the case details
	 *               in the CaseBean. return list of CaseBean to the view.
	 */
	@RequestMapping(AppConstants.REQ_URI_ASSETCASES)
	public ModelAndView getAssetCases(final HttpServletRequest request)
			throws RMDWebException, Exception {

		rmdWebLogger.debug(" AssetCases Controller getAssetCases():::START");
		Future<AssetOverviewBean> futureGetAssetsList = null;
		Future<AssetLocatorResponseVO> futureLastFaultList = null;
		Future<AssetInstalledProductVO> futureInstalledProductList = null;
		Future<List<CaseTypeBean>> futureCaseTypeList = null;
		AssetOverviewBean futureGetAssets = new AssetOverviewBean();
		AssetInstalledProductVO futureAssetInstalledProduct = new AssetInstalledProductVO();
		AssetLocatorResponseVO futureLastFault = new AssetLocatorResponseVO();
		AssetOverviewBean assetBean = new AssetOverviewBean();
		List<CaseTypeBean> futureCaseTypeBean = new ArrayList<CaseTypeBean>();
		String customerID = null;
		// Get the asset ID, customer id and asset group name from request
		final String assetNumber = request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM);
		final String assetGrpName = request
				.getParameter(AppConstants.ASSET_GROUP_NAME);
		StringBuilder businessKeys = new StringBuilder();
		businessKeys.append("Asset Number : "+assetNumber);
        businessKeys.append(" Asset Grp Name : "+assetGrpName);
		final HttpSession session = request.getSession(false);
		// Get UserVO from session for using logged user's TimeZone
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);

		// Set Filter flag
		request.setAttribute(AppConstants.FILTERFLAG,
				request.getParameter(AppConstants.FLAG));
		/* For timezone issue */
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		/* For timezone issue */
		Map<String, String> componentList = new HashMap<String, String>();
		boolean isAssetCasesAssetDetails = false, isAssetCasesCommSection = false,isRunToolsNow=false;
		Map<String, List<ResourceVO>> secNavMap = new LinkedHashMap<String, List<ResourceVO>>();
		try {
			TimeZone timezone = TimeZone.getTimeZone(applicationTimezone);
			/* Begin of Changes for fetching customer Id from Webservices */
			customerID = asstOvwService
					.getCustomerId(assetNumber, assetGrpName);
			/* End of Changes */

			// Now get the default/lookBack days from lookup.
			List<String> caseLookBackDays = assetCasesService
					.getCaseListLookBackDays(AppConstants.ASSET_CASE_LOOKBACK_DAYS);
			componentList.put(AppConstants.ASSET_CASES_ADD_NOTES,
					AppConstants.ASSET_CASES_NOTES);
			componentList.put(AppConstants.ASSET_CASES_ASSET_DETAILS,
					AppConstants.IS_ASSET_CASES_ASSET_DETAILS);
			componentList.put(AppConstants.ASSET_CASES_COMM_SECTION,
					AppConstants.IS_ASSET_CASES_COMM_SECTION);
			componentList.put(AppConstants.RUN_TOOLS_NOW,
					AppConstants.IS_RUN_TOOLS_NOW);
			getComponentPrivilege(componentList, userVO, request);
			isAssetCasesAssetDetails = (Boolean) request
					.getAttribute(AppConstants.IS_ASSET_CASES_ASSET_DETAILS);
			isAssetCasesCommSection = (Boolean) request
					.getAttribute(AppConstants.IS_ASSET_CASES_COMM_SECTION);
			isRunToolsNow= (Boolean) request
					.getAttribute(AppConstants.IS_RUN_TOOLS_NOW);
			assetBean.setAsset(assetNumber);
			assetBean.setAssetGroup(assetGrpName);
			assetBean.setCustomer(customerID);
			assetBean.setUserLanguage(userVO.getStrUserLanguage());
			assetBean.setUserTimeZone(applicationTimezone);
			assetBean.setUserLanguage(userVO.getStrUserLanguage());
			assetBean.setDefaultTimeZone(defaultTimezone);
			// Now call the vehicle comm webservices.
			// if (isAssetCasesCommSection) {

			// futureLastFaultList =
			// assetCasesService.getLastFaultAndAssetLocation(assetBean);
			// Common section data for asset case - Added by mohamed
			futureLastFaultList = assetCasesService
					.getAssetCaseCommSection(assetBean);
			// }
			// Now asset details are populated...
			// if (isAssetCasesAssetDetails) {
			futureGetAssetsList = assetCasesService.getAssets(assetBean);
			// }
			futureInstalledProductList = assetCasesService
					.getAssetInstalledProduct(assetBean);

			futureCaseTypeList = assetCasesService.getCaseType();

			if (null != futureLastFaultList) {
				futureLastFault = futureLastFaultList.get();
			}
			if (null != futureGetAssetsList) {
				futureGetAssets = futureGetAssetsList.get();
			}

			if (null != futureInstalledProductList) {
				futureAssetInstalledProduct = futureInstalledProductList.get();
			}
			if (null != futureCaseTypeList) {
				futureCaseTypeBean = futureCaseTypeList.get();
			}

			boolean ppBtnResult = RMDCommonConstants.FALSE;
			if (null != futureGetAssets.getBadActor()
					&& !futureGetAssets.getBadActor().equalsIgnoreCase(
							RMDCommonConstants.EMPTY_STRING)) {
				String applicationName = assetCasesService
						.displayPPAssetHistoryBtn(futureGetAssets
								.getVehicleObjId());
				boolean isATS = RMDCommonConstants.FALSE;
				if (!applicationName
						.equalsIgnoreCase(RMDCommonConstants.STRING_NULL)) {
					isATS = RMDCommonConstants.TRUE;
				}

				if (futureGetAssets.getControllerConfig().equalsIgnoreCase(
						RMDCommonConstants.PINPOINTFLG)
						|| isATS) {
					ppBtnResult = RMDCommonConstants.TRUE;
				} else {
					ppBtnResult = RMDCommonConstants.FALSE;
				}
			}
			
			 secNavMap = (Map<String, List<ResourceVO>>) session
	                    .getAttribute(AppConstants.ATTR_SEC_MAP);
	            if (null != secNavMap.get(RMDCommonConstants.FIND)) {
	                List<ResourceVO> listVO = secNavMap.get(RMDCommonConstants.FIND);
	                for (ResourceVO obj : listVO) {
	                    if (RMDCommonConstants.PREV_SUBMENU_FIND_NOTES
	                            .equalsIgnoreCase(obj.getResourceId())) {
	                        request.setAttribute(
	                                AppConstants.HAS_FIND_NOTES_ACCESS,
	                                RMDCommonConstants.TRUE);
	                        break;
	                    }
	                }

	            }
			
			request.setAttribute(AppConstants.ASSET_CASE_DEFAULT_LOOKBACK_DAYS,
					caseLookBackDays.get(0));
			caseLookBackDays.clear();
			caseLookBackDays.addAll(assetCasesService
					.getCaseListLookBackDays(AppConstants.CASE_LOOKBACK_DAYS));
			request.setAttribute(AppConstants.ASSET_CASE_LOOKBACK_DAYS_LIST,
					caseLookBackDays);
			// Set the request params
			String nonCriticalActivities = getLookUpValueForName(AppConstants.NON_CRITICAL_ACTIVITIES);
			String nonCriticalActivitiesUsers = getLookUpValueForName(AppConstants.NON_CRITICAL_ACTIVITIES_USERS);
			request.setAttribute(AppConstants.ASSET_OV_BEAN, futureGetAssets);
			request.setAttribute("AssetVehHdrNo", futureGetAssets.getAssetGrpHdrNo());
			request.setAttribute(AppConstants.ASSET_LASTFAULT_BEAN,
					futureLastFault);
			request.setAttribute(AppConstants.WS_PARAM_ASSTNUM, assetNumber);
			request.setAttribute(AppConstants.CUSTOMER_ID, customerID);
			request.setAttribute(AppConstants.ASSET_GROUP_NAME, assetGrpName);
			request.setAttribute(AppConstants.ASSET_OBJID,
					futureGetAssets.getAssetObjid());
			request.setAttribute(AppConstants.ESERVICES_LOCO_ID,
					futureGetAssets.getLmsLocoId());
			request.setAttribute(AppConstants.CUSTOMER_NAME,
					futureGetAssets.getCustomer());
			request.setAttribute(AppConstants.ASSET_INSTALLED_PROD,
					futureAssetInstalledProduct);
			request.setAttribute(AppConstants.ASSET_CASE_TYPE_LIST,
					futureCaseTypeBean);
			request.setAttribute(AppConstants.STR_ESERVICES_URL, eServicesUrl);
			request.setAttribute(AppConstants.REQ_NON_CRITICAL_ACTIVITIES,
					nonCriticalActivities);
			request.setAttribute(
					AppConstants.REQ_NON_CRITICAL_ACTIVITIES_USERS,
					nonCriticalActivitiesUsers);
			// adding for pagination
			request.setAttribute(
					AppConstants.ASSETCASES_DEFAULT_RECORDS,
					findNumberOfRecords(AppConstants.ASSETCASES_TABLE_DEFAULT_RECORDS));
			request.setAttribute(AppConstants.PP_ASSET_HST_BTN_DISPLAY,
					ppBtnResult);
			// Material Usage lookup days - Added by mohamed
			List<String> materialUsageLookBackDays = assetCasesService
					.getCaseListLookBackDays(AppConstants.MATERIAL_USAGE_LOOKBACK_DAYS);
			request.setAttribute(
					AppConstants.MATERIAL_USAGE_DEFAULT_LOOKBACK_DAYS,
					materialUsageLookBackDays.get(0));
			request.setAttribute(
					AppConstants.MATERIAL_USAGE_LOOKBACK_DAYS_LIST,
					materialUsageLookBackDays);
			request.setAttribute(AppConstants.IS_RUN_TOOLS_NOW,
					isRunToolsNow);
			request.setAttribute("offSetTime", timezone.getOffset(Calendar.ZONE_OFFSET));
			rmdWebLogger.debug("AssetCases Controller getAssetCases():::END");
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getAssetCases() method ",
							rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			RMDWebErrorHandler.handleException(rmdEx);
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getAssetCases method ", ex);
			persistException(userVO.getUserId(), "Get Asset Cases", businessKeys.toString(), ex);
			request.setAttribute(AppConstants.ERRORMSG, AppConstants.UNKNOWN_EXCEPTION);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
				.debug("AssetCases Controller : getAssetCases() method Ends");
		return new ModelAndView(AppConstants.VIEW_ASSETCASES);
	}

	@RequestMapping("populateAssetCaseList")
	public @ResponseBody List<CaseBean> populateAssetCaseList(
			final HttpServletRequest request) throws RMDWebException, Exception {

		// Get the asset ID, customer id and asset group name from request
		final String assetNumber = request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM);
		final String customerID = request
				.getParameter(AppConstants.CUSTOMER_ID);
		final String assetGrpName = request
				.getParameter(AppConstants.ASSET_GROUP_NAME);
		final String appendFlag = request
				.getParameter(AppConstants.APPEND_FLAG);
		String lookBackDays = request.getParameter("lookBackDays");
		String caseType = request.getParameter("caseType");

		String caseId = request.getParameter(AppConstants.WS_PARAM_CASEID_2);
		List<CaseBean> arlCases = new ArrayList<CaseBean>();
		CaseBean caseBean = new CaseBean();
		caseBean.setAssetNumber(assetNumber);
		caseBean.setCustomerId(customerID);
		caseBean.setAssetGrpName(assetGrpName);
		caseBean.setCaseType(caseType);
		caseBean.setCaseId(caseId);

		caseBean.setAppendFlag(appendFlag);

		// When the page loads for the first time , lookBackDays is default , 90
		// days.
		if (lookBackDays == null || lookBackDays.equals("")) {
			// Now get the default/lookBack days from lookup.
			if (RMDCommonUtility.isNullOrEmpty(caseId)) {
				List<String> caseLookBackDays = assetCasesService
						.getCaseListLookBackDays(AppConstants.ASSET_CASE_LOOKBACK_DAYS);
				lookBackDays = caseLookBackDays.get(0);
			}
		}
		
        if (RMDCommonConstants.LETTER_Y.equals(appendFlag)) {
              List<String> caseTypeList = assetCasesService
                        .getCaseListLookBackDays(caseType+RMDCommonConstants.APPEND_CASE_TYPES);
              if(RMDCommonUtility.isCollectionNotEmpty(caseTypeList)){
                  caseBean.setCaseType(caseTypeList.get(0));
              }
        }

		
		caseBean.setNoOfDays(lookBackDays);
		final HttpSession session = request.getSession(false);
		// Get UserVO from session for using logged user's TimeZone
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);

		/* For timezone issue */
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		caseBean.setTimeZone(applicationTimezone);
		arlCases = assetCasesService.getAssetCases(caseBean);

		// Get the open case information of asset

		return arlCases;
	}

	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description: get the notes data for requested asset number.
	 * 
	 *               1) Retrieve the list of alternate solutions for given case
	 *               id and set.
	 * 
	 * 
	 *               2) return List of SolutionBean.
	 * 
	 * 
	 */
	@RequestMapping(AppConstants.REQ_URI_ASSETCASES
			+ AppConstants.REQ_URI_SOLNS)
	public @ResponseBody List<SolutionBean> getAlternateSolutions(
			final HttpServletRequest request) throws RMDWebException, Exception {
		final String caseId = request
				.getParameter(AppConstants.REQ_PARAM_CASEID);
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final CaseBean caseBean = new CaseBean();
		List<SolutionBean> solutionsList = new ArrayList<SolutionBean>();
		try {
			caseBean.setCaseId(caseId);
			caseBean.setUserLanguage(userVO.getStrUserLanguage());
			caseBean.setTimeZone(userVO.getTimeZone());
			caseBean.setUserLanguage(userVO.getStrUserLanguage());
			solutionsList = assetCasesService.getAlternateSolutions(caseBean);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAlternateSolutions method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		rmdWebLogger
				.debug("AssetCases Controller : getAlternateSolutions() method Ends");

		return solutionsList;

	}

	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description: get the notes data for requested asset number.
	 * 
	 *               1) Retrieve the list of case histories for given case id
	 *               and set.
	 * 
	 * 
	 *               2) return List of NotesBean.
	 * 
	 * 
	 */
	@RequestMapping(AppConstants.REQ_URI_ASSETCASES
			+ AppConstants.REQ_URI_CASEHISTRY)
	public @ResponseBody CaseHistoryBean getCaseHistory(
			final HttpServletRequest request) throws RMDWebException, Exception {
		final String caseId = request
				.getParameter(AppConstants.REQ_PARAM_CASEID);
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final CaseBean caseBean = new CaseBean();
		CaseHistoryBean caseHistory = null;
		AssetOverviewBean assetOverviewBean = new AssetOverviewBean();
		StringBuilder businessKeys = new StringBuilder();
		try {
			String assetNumber = (String) request.getParameter("assetNumber");
			String assetGrpName = (String) request.getParameter("assetGrpName");
			String customerId = EsapiUtil.stripXSSCharacters((String) request.getParameter("customerId"));
			businessKeys.append("Customer Id : "+customerId);
			businessKeys.append(" Asset Number : "+assetNumber);
	        businessKeys.append(" Asset Grp Name : "+assetGrpName);
			assetOverviewBean.setAsset(assetNumber);
			assetOverviewBean.setAssetGroup(assetGrpName);
			assetOverviewBean.setCustomer(customerId);
			assetOverviewBean = asstOvwService.getAssets(assetOverviewBean);
			caseBean.setCaseId(caseId);
			caseBean.setTimeZone(userVO.getTimeZone());
			caseBean.setUserLanguage(userVO.getStrUserLanguage());
			caseHistory = assetCasesService.getCaseHistory(caseBean);
			caseHistory.setModel(assetOverviewBean.getModel());
		}

		catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCaseHistory method ", ex);
			persistException(userVO.getUserId(), "Get Case History", businessKeys.toString(), ex);
			RMDWebErrorHandler.handleException(ex);

		}
		rmdWebLogger.debug("AssetCases Controller: getCaseHistory() method Ends");
		return caseHistory;

	}

	@RequestMapping(value = AppConstants.ACCEPT)
	public @ResponseBody String acceptCase(
			@RequestParam(value = AppConstants.CASE_ID) String caseId,
			@RequestParam(value = AppConstants.CURRENT_OWNER) String currentOwner,
			final HttpServletRequest request) throws RMDWebException {
		String result = AppConstants.FAILURE;
		final OpenCasesBean openCaseBean = new OpenCasesBean();
		CaseBean objCaseBean = new CaseBean();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		StringBuilder businessKeys = new StringBuilder();
		businessKeys.append("Case Id : "+caseId);
        businessKeys.append(" Current Owner : "+currentOwner);
		try {
			openCaseBean.setUserId(userVO.getUserId());
			openCaseBean.setLanguage(userVO.getStrLanguage());
			openCaseBean.setUserFirstName(userVO.getStrFirstName());
			openCaseBean.setUserLastName(userVO.getStrLastName());
			openCaseBean.setCaseId(request
					.getParameter(AppConstants.WS_PARAM_CASEID_2));
			openCaseBean.setCurrentOwner(currentOwner);
			objCaseBean = getCaseCurrentOwnerDetails(caseId);
			if (null != userVO.getCmAliasName()) {
				if (!objCaseBean.getCondition().equalsIgnoreCase(
						RMDCommonConstants.CLOSED)
						&& (null != objCaseBean.getQueueName()
								&& !objCaseBean
										.getQueueName()
										.equalsIgnoreCase(
												RMDCommonConstants.EMPTY_STRING)
								&& !objCaseBean.getQueueName().isEmpty() && !objCaseBean
								.getQueueName().equalsIgnoreCase(
										RMDCommonConstants.ZERO_STRING))) {

					result = openCasesService.takeOwnerShip(openCaseBean);

				} else {
					result = RMDCommonConstants.NOT_CURRENT_OWNER;

				}
			} else {
				result = AppConstants.NO_EOA_USER;
			}

		} catch (RMDWebException ex) {
			persistException(userVO.getUserId(), "Accept Case", businessKeys.toString(), ex);
			if (AppConstants.TAKE_OWNERSHIP_RTU_FAILED_CODE.equals(ex.getErrorCode())) {
				result = AppConstants.TAKE_OWNERSHIP_RTU_FAILED_CODE;
			} else {
				rmdWebLogger.error("Exception occured in takeOwnership method ", ex);
				RMDWebErrorHandler.handleException(ex);
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in takeOwnership method ", ex);
			persistException(userVO.getUserId(), "Accept Case", businessKeys.toString(), ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	@RequestMapping(value = AppConstants.YANK)
	public @ResponseBody String yankCase(
			@RequestParam(value = AppConstants.CASE_ID) String caseId,
			@RequestParam(value = AppConstants.CURRENT_OWNER) String currentOwner,
			final HttpServletRequest request) throws RMDWebException {
		String result = AppConstants.FAILURE;
		final OpenCasesBean openCaseBean = new OpenCasesBean();
		CaseBean objCaseBean = new CaseBean();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		StringBuilder businessKeys = new StringBuilder();
		businessKeys.append("Case Id : "+caseId);
        businessKeys.append(" Current Owner : "+currentOwner);
		try {
			openCaseBean.setUserId(userVO.getUserId());
			openCaseBean.setLanguage(userVO.getStrLanguage());
			openCaseBean.setUserFirstName(userVO.getStrFirstName());
			openCaseBean.setUserLastName(userVO.getStrLastName());
			openCaseBean.setCaseId(request
					.getParameter(AppConstants.WS_PARAM_CASEID_2));
			openCaseBean.setCurrentOwner(currentOwner);
			objCaseBean = getCaseCurrentOwnerDetails(caseId);
			if (null != userVO.getCmAliasName()) {
				if (!objCaseBean.getCondition().equalsIgnoreCase(
						RMDCommonConstants.CLOSED)
						&& (null == objCaseBean.getQueueName()
								|| objCaseBean.getQueueName().equalsIgnoreCase(
										RMDCommonConstants.EMPTY_STRING)
								|| objCaseBean.getQueueName().isEmpty() || objCaseBean
								.getQueueName().equalsIgnoreCase(
										RMDCommonConstants.ZERO_STRING))) {
					if (!objCaseBean.getOwner().equalsIgnoreCase(
							RMDCommonConstants.EMPTY_STRING)
							&& objCaseBean.getOwner() != null
							&& !objCaseBean.getOwner().equalsIgnoreCase(
									currentOwner)) {
						result = openCasesService.yankCase(openCaseBean);
					} else {
						result = RMDCommonConstants.NOT_CURRENT_OWNER;
					}
				} else {
					result = RMDCommonConstants.NOT_CURRENT_OWNER;
				}
			} else {
				result = AppConstants.NO_EOA_USER;
			}

		} catch (RMDWebException ex) {
			persistException(userVO.getUserId(), "Yank Case", businessKeys.toString(), ex);
			if (AppConstants.TAKE_OWNERSHIP_RTU_FAILED_CODE.equals(ex.getErrorCode())) {
				result = AppConstants.TAKE_OWNERSHIP_RTU_FAILED_CODE;
			} else {
				rmdWebLogger.error("Exception occured in takeOwnership method ", ex);
				RMDWebErrorHandler.handleException(ex);
			}
		} catch (Exception ex) {
			persistException(userVO.getUserId(), "Yank Case", businessKeys.toString(), ex);
			rmdWebLogger.error("Exception occured in takeOwnership method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:List<CaseMgmtUsersDetailsVO>
	 * @throws RMDWebException
	 * @Description:This method is used to fetch the user names by invoking the
	 *                   assetCasesService.getCaseMgmtUsersDetails() method.
	 */
	@RequestMapping(value = AppConstants.GET_CASE_MGMT_USER_NAMES)
	public @ResponseBody List<CaseMgmtUsersDetailsVO> getCaseMgmtUsersDetails()
			throws RMDWebException {
		List<CaseMgmtUsersDetailsVO> objUsersList = null;
		try {

			objUsersList = assetCasesService.getCaseMgmtUsersDetails();

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getCaseMgmtUsersDetails method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return objUsersList;
	}

	/**
	 * @Author:
	 * @param:caseId
	 * @return: List<CaseHistoryVO>
	 * @throws RMDWebException
	 * @Description: This method fetches the set of activities based on case id
	 *               by invoking assetCasesService.getCaseHistory() method.
	 */
	@RequestMapping(value = AppConstants.CASE_HISTORY)
	public @ResponseBody List<CaseHistoryVO> getCaseHistory(
			@RequestParam(value = AppConstants.CASE_ID) final String caseId,
			final HttpServletRequest request) throws RMDWebException {
		List<CaseHistoryVO> caseActivityLogList = null;
		List<CaseHistoryVO> caseHistoryVOList = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		StringBuilder businessKeys = new StringBuilder();
		businessKeys.append("Case Id : "+caseId);
		businessKeys.append(" TimeZone : "+userVO.getTimeZone());
		try {

			if (AppSecUtil.checkAlphaNumeric(caseId)) {
				caseActivityLogList = assetCasesService.getCaseHistory(caseId,
						userVO.getTimeZone());
				if (null != caseActivityLogList) {
					caseHistoryVOList = new ArrayList<CaseHistoryVO>();
					for (CaseHistoryVO caseHistoryVO : caseActivityLogList) {
						StringBuffer description = new StringBuffer("");
						String notes = "", desc = "", history = "                               ", history2 = "                             ";
						if (caseHistoryVO.getActivity().indexOf("Create") != -1) {
							notes = "CASE CREATE";
						} else {
							notes = "NOTES";
						}
						if (caseHistoryVO.getActivityType() == null) {
							if (caseHistoryVO.getDescription() == null)
								caseHistoryVO.setActivityType("");
							else
								caseHistoryVO.setActivityType("Action Type: "
										+ "");
						} else {
							caseHistoryVO.setActivityType("Action Type: "
									+ caseHistoryVO.getActivityType());
						}
						description = description.append("***" + notes + " "
								+ caseHistoryVO.getCreateDate().toString()
								+ " " + caseHistoryVO.getUser() + " "
								+ caseHistoryVO.getActivityType()
								+ "               ");
						description
								.append(caseHistoryVO.getDescription() == null ? ""
										: caseHistoryVO.getDescription());
						desc = description.toString();
						desc = desc.trim();
						if (desc.contains("Action Type: Manager review")) {
							history = desc.substring(0,
									desc.lastIndexOf("Manager review") + 14);
							history2 = desc.substring(
									desc.lastIndexOf("Manager review") + 14,
									desc.length());
						} else if (desc.contains("Action Type: Incoming call")) {
							history = desc
									.substring(
											0,
											desc.lastIndexOf("Action Type: Incoming call") + 26);
							history2 = desc
									.substring(
											desc.lastIndexOf("Action Type: Incoming call") + 26,
											desc.length());
						} else if (desc.contains("Action Type")) {
							history = desc.substring(0,
									desc.lastIndexOf("Action Type") + 12);
							history2 = desc.substring(
									desc.lastIndexOf("Action Type") + 12,
									desc.length());
						} else {
							history = desc;
						}
						// description.append(history+""+history2);
						caseHistoryVO.setDescription(history + " " + history2);
						caseHistoryVOList.add(caseHistoryVO);
					}
				}
			}
		}

		catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getActivityLog method ", ex);
			persistException(userVO.getUserId(), "Case History", businessKeys.toString(), ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return caseActivityLogList;
	}

	/**
	 * @Author:
	 * @param:userId,caseId
	 * @return:String
	 * @throws RMDWebException
	 * @Description: This method assigns case to the particular user id by
	 *               invoking assetCasesService.assignCaseToUser() method
	 */

	@RequestMapping(value = AppConstants.ASSIGN_TO_USER)
	public @ResponseBody String assignCaseToUser(
			@RequestParam(value = AppConstants.USER_ID) final String userId,
			@RequestParam(value = AppConstants.CASE_ID) final String caseId,
			final HttpServletRequest request) throws RMDWebException {
		String result = AppConstants.FAILURE;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		StringBuilder businessKeys = new StringBuilder();
		businessKeys.append("Case Id : "+caseId);
		businessKeys.append(" User Id : "+userId);
		try {
			if (AppSecUtil.checkAlphaNumeric(caseId)) {
				CaseBean objCaseBean = new CaseBean();
				objCaseBean = getCaseCurrentOwnerDetails(caseId);
				if (null != userVO.getCmAliasName()) {
					if (!objCaseBean.getCondition().equalsIgnoreCase(
							RMDCommonConstants.CLOSED)
							&& (null == objCaseBean.getQueueName()
									|| objCaseBean
											.getQueueName()
											.equalsIgnoreCase(
													RMDCommonConstants.EMPTY_STRING)
									|| objCaseBean.getQueueName().isEmpty() || objCaseBean
									.getQueueName().equalsIgnoreCase(
											RMDCommonConstants.ZERO_STRING))) {
						if ((!objCaseBean.getOwner().equalsIgnoreCase(
								RMDCommonConstants.EMPTY_STRING) || objCaseBean
								.getOwner() != null)
								&& objCaseBean.getOwner().equalsIgnoreCase(
										userVO.getCmAliasName())) {
							result = assetCasesService.assignCaseToUser(EsapiUtil.stripXSSCharacters(userId),
									EsapiUtil.stripXSSCharacters(caseId));
						} else {
							result = RMDCommonConstants.NOT_CURRENT_OWNER;
						}
					} else {
						result = RMDCommonConstants.NOT_CURRENT_OWNER;

					}
				} else {
					result = AppConstants.NO_EOA_USER;
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in assignCaseToUser method ", ex);
			persistException(userVO.getUserId(), "Assign Case To User", businessKeys.toString(), ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return result;

	}

	/**
	 * @Author:
	 * @param:caseId
	 * @return:String
	 * @throws RMDWebException
	 * @Description: This method fetches the owner for particular case id by
	 *               invoking assetCasesService.getOwnerForCase()method.
	 */

	@RequestMapping(value = AppConstants.GET_OWNER_FOR_CASE)
	public @ResponseBody CaseBean getCaseCurrentOwnerDetails(
			@RequestParam(value = AppConstants.CASE_ID) final String caseId)
			throws RMDWebException {
		CaseBean objCaseBean = new CaseBean();
		try {
			if (AppSecUtil.checkAlphaNumeric(caseId)) {
				objCaseBean = assetCasesService
						.getCaseCurrentOwnerDetails(caseId);

			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getOwnerForCase method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return objCaseBean;

	}

	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description: post the new notes information for requested asset number.
	 * 
	 * 
	 *               1) put the notes to the service call with required params
	 *               like assetNumber,notes and user name 2) return a String for
	 *               successful post of notes.
	 * 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_ASSETCASES
			+ AppConstants.REQ_URI_POSTNOTES, method = RequestMethod.GET)
	public @ResponseBody Map<String, String> postCaseNotes(
			final HttpServletRequest request) throws RMDWebException, Exception {
		rmdWebLogger
				.debug("AssetCases Controller : postCaseNotes() method Starts");
		// Get the asset number from request
		final String assetNumber = request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM);
		final String groupName = request
				.getParameter(AppConstants.WS_PARAM_ASSTGRP);
		final String customerId = request
				.getParameter(AppConstants.REQ_PARAM_CUSID);
		final String notes = request
				.getParameter(AppConstants.REQ_PARAM_ASSTNOTES);
		final String caseId = request
				.getParameter(AppConstants.WS_PARAM_CASEID_1);
		String returnStr = AppConstants.FAILURE;
		final NotesBean notesBean = new NotesBean();

		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		if (notes != null) {
			try {
				notesBean.setAssetNumber(assetNumber);
				notesBean.setNoteDescription(AppSecUtil.htmlEscaping(notes));
				notesBean.setUserFirstName(userVO.getStrFirstName());
				notesBean.setUserLastName(userVO.getStrLastName());
				notesBean.setUserId(userVO.getUserId());
				notesBean.setUserLanguage(userVO.getStrUserLanguage());
				notesBean.setCustomerId(customerId);
				notesBean.setAssetGroup(groupName);
				notesBean.setCaseID(caseId);
				returnStr = assetCasesService.postNotes(notesBean);
			} catch (Exception ex) {
				rmdWebLogger.error(
						"Exception occured in postCaseNotes method ", ex);
				RMDWebErrorHandler.handleException(ex);
			}
		} else {
			returnStr = AppConstants.NOTEMPTY;

		}

		rmdWebLogger
				.debug("AssetOverview Controller : postCaseNotes() method Ends");
		return Collections.singletonMap(AppConstants.MESSAGE, returnStr);
	}

	/**
	 * @Author:
	 * @param assetNumber
	 * @param queueName
	 * @param status
	 * @param userVO
	 * @return CaseBean
	 * @Description: Returns CaseBean populated with asset num, queue name, case
	 *               status, language and time zone
	 */
	private CaseBean returnInputBean(final String assetNumber,
			final String queueName, final String status, final UserVO userVO,
			final String customerID, final String assetGrpName,
			String applicationTimezone) {
		final CaseBean caseBean = new CaseBean();

		caseBean.setUserLanguage(userVO.getStrUserLanguage());
		caseBean.setTimeZone(applicationTimezone);
		caseBean.setAssetNumber(assetNumber);
		if (queueName != null) {
			caseBean.setQueueName(queueName);
		}
		caseBean.setCustomerId(customerID);
		caseBean.setAssetGrpName(assetGrpName);
		if (status != null) {
			caseBean.setCaseStatus(status);
		}
		return caseBean;
	}

	/**
	 * @Author:
	 * @param case id
	 * @return CaseBean
	 * @Description: return the list of all the rx associated with the case
	 */
	@RequestMapping(value = AppConstants.FETCH_CASE_RX_HISTORY)
	public @ResponseBody List<SolutionDetailVO> getCaseRxHistory(
			@RequestParam(value = AppConstants.CASE_ID) String caseId,
			HttpServletRequest request) throws RMDWebException {
		List<SolutionDetailVO> resultList = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {

			resultList = assetCasesService.getCaseRxHistory(caseId,
					userVO.getTimeZone());
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCaseRxHistory method ",
					ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return resultList;
	}

	/**
	 * @Author :
	 * @return :List<QueueDetailsVO>
	 * @param : caseId, caseType
	 * @throws :RMDWebException
	 * @Description:This method is used for fetching a list of Dynamic work
	 *                   QueueNames from Data Base.This is done by Invoking
	 *                   getQueueNames() method of AssestCaseServiceImpl Layer.
	 */
	@RequestMapping(value = AppConstants.GET_QUEUE_NAMES)
	public @ResponseBody List<QueueDetailsVO> getQueueNames(
			@RequestParam(value = AppConstants.CASE_ID) final String caseId)
			throws RMDWebException {
		List<QueueDetailsVO> queueList = null;

		try {

			queueList = assetCasesService.getQueueNames(caseId);

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getQueueNames method in AssetCaseController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return queueList;
	}

	/**
	 * @Author :
	 * @return :String
	 * @param :queueId,caseId,userId
	 * @throws :RMDWebException
	 * @Description:This method is used for a dispatching case to dynamic work
	 *                   queues selected by the user.This is done by Invoking
	 *                   dispatchCaseToQueue() method of AssestCaseServiceImpl
	 *                   Layer.
	 */
	@RequestMapping(value = AppConstants.DISPATCH_CASE_TO_QUEUE)
	public @ResponseBody String dispatchCaseToWorkQueue(
			@RequestParam(value = AppConstants.QUEUE_ID) final String queueId,
			@RequestParam(value = AppConstants.CASE_ID) final String caseId,
			@RequestParam(value = AppConstants.USER_ID) final String userId,
			final HttpServletRequest request) throws RMDWebException {
		String result = AppConstants.FAILURE;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		CaseBean objCaseBean = new CaseBean();
		long longQueueId = 0L;
		if (queueId != null) {
			longQueueId = Long.parseLong(queueId);
		}
		try {
			if (null != userVO.getCmAliasName()) {
				if (AppSecUtil.checkAlphaNumeric(userId)
						&& AppSecUtil.checkAlphaNumeric(caseId)) {
					objCaseBean = getCaseCurrentOwnerDetails(EsapiUtil.stripXSSCharacters(caseId));
					if (!objCaseBean.getCondition().equalsIgnoreCase(
							RMDCommonConstants.CLOSED)
							&& (null == objCaseBean.getQueueName()
									|| objCaseBean
											.getQueueName()
											.equalsIgnoreCase(
													RMDCommonConstants.EMPTY_STRING)
									|| objCaseBean.getQueueName().isEmpty() || objCaseBean
									.getQueueName().equalsIgnoreCase(
											RMDCommonConstants.ZERO_STRING))) {
						if ((!objCaseBean.getOwner().equalsIgnoreCase(
								RMDCommonConstants.EMPTY_STRING) || objCaseBean
								.getOwner() != null)
								&& objCaseBean.getOwner().equalsIgnoreCase(
										userVO.getCmAliasName())) {
							result = assetCasesService.dispatchCaseToWorkQueue(
									longQueueId, EsapiUtil.stripXSSCharacters(caseId), EsapiUtil.stripXSSCharacters(userId));
						} else {
							result = RMDCommonConstants.NOT_CURRENT_OWNER;
						}
					} else {
						result = RMDCommonConstants.NOT_CURRENT_OWNER;
					}
				}
			} else {
				result = AppConstants.NO_EOA_USER;
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in dispatchCaseToQueue method in AssetCaseController ",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return result;
	}

	/**
	 * @Author :
	 * @return :String
	 * @param :AddNotesEoaServiceVO
	 * @throws :RMDWebException
	 * @Description:This method is used for adding Case notes for a given
	 *                   case.This is done by Invoking addNotesToCase() method
	 *                   of AssestCaseServiceImpl Layer.
	 */

	@RequestMapping(value = AppConstants.ADD_NOTES_TO_CASE)
	public @ResponseBody String addNotesToCase(
			@RequestParam(value = AppConstants.CASE_ID) final String caseId,
			@RequestParam(value = AppConstants.NOTE_DESCRIPTION) final String noteDescription,
			@RequestParam(value = AppConstants.APPLY_LEVEL) final String applyLevel,
			@RequestParam(value = AppConstants.STICKY) final String sticky,
			@RequestParam(value = AppConstants.USER_ID) final String userId,
			final HttpServletRequest request) throws RMDWebException {

		String result = AppConstants.FAILURE;
		NotesBean notesbean = new NotesBean();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			if (null != userVO.getCmAliasName()) {
				if (AppSecUtil.checkAlphaNumeric(userId)
						&& AppSecUtil.checkAlphaNumeric(caseId)) {
					notesbean.setCaseID(caseId);
					notesbean.setNoteDescription(noteDescription);
					notesbean.setApplyLevel(applyLevel);
					notesbean.setSticky(sticky);
					notesbean.setUserId(userId);
					result = assetCasesService.addNotesToCase(notesbean);
				}
			} else {

				result = AppConstants.NO_EOA_USER;
			}

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in addNotesToCase  method in AssetCaseController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return result;
	}

	/**
	 * @Author:
	 * @param :caseId
	 * @return StickyNotesDetailsVO
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 * @Description: This method is used fetching unit Sticky notes details for
	 *               a given case.This is done by Invoking
	 *               fetchStickyUnitNotes() method of AssestCaseServiceImpl
	 *               Layer.
	 */
	@RequestMapping(value = AppConstants.FETCH_UNIT_STICKY_DETAILS)
	public @ResponseBody StickyNotesDetailsVO fetchStickyUnitNotes(
			@RequestParam(value = AppConstants.ADD_NOTES_CASE_ID) final String caseId,
			HttpServletRequest request) throws GenericAjaxException,
			RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		StickyNotesDetailsVO stickyNotes = null;
		try {
			if (AppSecUtil.checkAlphaNumeric(EsapiUtil.stripXSSCharacters(caseId))) {
				stickyNotes = assetCasesService.fetchStickyUnitNotes(EsapiUtil.stripXSSCharacters(caseId),
						userVO.getTimeZone());
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured fetchStickyUnit method in AssetCaseController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return stickyNotes;
	}

	/**
	 * @Author:
	 * @param :caseId
	 * @return StickyNotesDetailsVO
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 * @Description: This method is used fetching case Sticky notes details for
	 *               a given case.This is done by Invoking
	 *               fetchStickyCaseNotes() method of AssestCaseServiceImpl
	 *               Layer.
	 */

	@RequestMapping(value = AppConstants.FETCH_CASE_STICKY_DETAILS)
	public @ResponseBody StickyNotesDetailsVO fetchStickyCaseNotes(
			@RequestParam(value = AppConstants.ADD_NOTES_CASE_ID) final String caseId,
			HttpServletRequest request) throws RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		StickyNotesDetailsVO stickyNotes = null;
		try {

			if (AppSecUtil.checkAlphaNumeric(caseId)) {
				stickyNotes = assetCasesService.fetchStickyCaseNotes(caseId,
						EsapiUtil.stripXSSCharacters(userVO.getTimeZone()));
			}
		}

		catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in fetch Case Sticky method in AssetCaseController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return stickyNotes;
	}

	/**
	 * @Author:
	 * @param :caseId,applylevel
	 * @return:String
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used for removing a unit Level as well as
	 *               case Level Sticky Notes for a given case.This is done by
	 *               Invoking fetchStickyCaseNotes() method of
	 *               AssestCaseServiceImpl Layer.
	 */

	@RequestMapping(value = AppConstants.REMOVE_STICKY_NOTES)
	public @ResponseBody String removeStickyNotes(
			@RequestParam(value = AppConstants.APPLY_LEVEL) final String applyLevel,
			@RequestParam(value = AppConstants.UNIT_STICKY_OBJID) final String unitStickyObjId,
			@RequestParam(value = AppConstants.CASE_STICKY_OBJID) final String caseStickyObjId)
			throws RMDWebException {

		String result = AppConstants.FAILURE;
		try {
			if (null != applyLevel) {
				result = assetCasesService.removeStickyNotes(EsapiUtil.stripXSSCharacters(unitStickyObjId),
						EsapiUtil.stripXSSCharacters(caseStickyObjId), EsapiUtil.stripXSSCharacters(applyLevel));
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in remove Sticky Notes method in AssetCaseController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	@RequestMapping(value = AppConstants.UPDATE_CASE_DETAILS)
	public @ResponseBody String updateCaseDetails(
			@RequestParam(value = AppConstants.CASETYPE) final String caseType,
			@RequestParam(value = AppConstants.CASE_TITLE) final String caseTitle,
			@RequestParam(value = AppConstants.ADD_NOTES_CASE_ID) final String caseId,
			final HttpServletRequest request) throws RMDWebException {
		String result = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);

		try {
			if (null != userVO.getCmAliasName()) {
				result = assetCasesService.updateCaseDetails(EsapiUtil.stripXSSCharacters(caseType),
						EsapiUtil.stripXSSCharacters(caseTitle), EsapiUtil.stripXSSCharacters(caseId));
			} else {
				result = AppConstants.NO_EOA_USER;
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in remove Sticky Notes method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return result;

	}

	@RequestMapping(value = AppConstants.GET_CASE_TYPES)
	public @ResponseBody List<CaseTypeBean> getCaseTypes(
			HttpServletRequest request) throws RMDWebException {
		List<CaseTypeBean> resultList = null;
		try {

			resultList = assetCasesService.getCaseTypes();
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCaseRxHistory method ",
					ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return resultList;
	}

	/**
	 * @Author:
	 * @param :
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used to fetch the values from lookup table
	 *               to populate the AddRx selected By dropdown.
	 */

	@RequestMapping(value = AppConstants.GET_SOLUTION_SELECTBY)
	public @ResponseBody Map<String, String> getSolSelectBy()
			throws RMDWebException {
		Map<String, String> selectByList = null;
		try {
			selectByList = objcreateCasesService.getSolSelectBy();
		} catch (Exception exception) {
			rmdWebLogger.error("Exception occured in getSolSelectBy method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return selectByList;
	}

	/**
	 * @Author:
	 * @param :
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used to fetch the values from lookup table
	 *               to populate the AddRx Condition dropdown.
	 */
	@RequestMapping(value = AppConstants.GET_SOLUTION_CONDITION)
	public @ResponseBody Map<String, String> getSolCondition()
			throws RMDWebException {
		Map<String, String> solConditionList = null;
		try {
			solConditionList = objcreateCasesService.getSolCondition();
		} catch (Exception exception) {
			rmdWebLogger.error("Exception occured in getSolCondition method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return solConditionList;

	}

	/**
	 * @Author:
	 * @param :
	 * @return:List <CaseBean>
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used to fetch the solutions for a given
	 *               case.
	 */
	@RequestMapping(value = AppConstants.GET_SOLUTIONS_FOR_CASE)
	public @ResponseBody List<CaseBean> getSolutionsForCase(
			@RequestParam(value = AppConstants.CASE_OBJID) final String caseObjId,
			HttpServletRequest request) throws RMDWebException {
		List<CaseBean> solutionsList = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);

		try {
			if (!RMDCommonUtility.isNullOrEmpty(caseObjId)) {

				solutionsList = assetCasesService.getSolutionsForCase(
						caseObjId, EsapiUtil.stripXSSCharacters(userVO.getTimeZone()));
			}
		} catch (Exception exception) {
			rmdWebLogger.error(
					"Exception occured in getSolutionsForCase method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return solutionsList;
	}

	/**
	 * @Author:
	 * @param :
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used to get values from lookup to populate
	 *               the subsystem drop downlist of AddRx modal.
	 */
	@RequestMapping(value = AppConstants.GET_SUBSYSTEM)
	public @ResponseBody Map<String, String> getSubSystem()
			throws RMDWebException {
		Map<String, String> subSystemMap = null;
		try {
			subSystemMap = assetCasesService.getSubSystem();
		} catch (Exception exception) {
			rmdWebLogger.error(
					"Exception occured in getSolutionsForCase method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return subSystemMap;
	}

	/**
	 * @Author:
	 * @param :
	 * @return:List<CreateCasesVO>
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used to get solutions for a particular Case
	 *               based upon the given search criteria.
	 */

	@RequestMapping(value = AppConstants.GET_SOLUTIONS)
	public @ResponseBody List<CreateCasesVO> getSolSearchResults(
			@RequestParam(value = AppConstants.CREATCASE_WSPARAM_CONDITION) final String condition,
			@RequestParam(value = AppConstants.CREATCASE_WSPARAM_SELECTBY) final String selectBy,
			@RequestParam(value = AppConstants.VALUE) final String value,
			@RequestParam(value = AppConstants.GET_SUB_SYSTEM) final String subSystem,
			@RequestParam(value = AppConstants.RX_TYPE) final String rxType,
			@RequestParam(value = AppConstants.MODEL) final String model,
			@RequestParam(value = AppConstants.CUSTOMER) final String customer,
            @RequestParam(value = AppConstants.RNH) final String rnh,
            @RequestParam(value = AppConstants.ROAD_NUMBER) final String rn,
			final HttpServletRequest request) throws RMDWebException {
		List<CreateCasesVO> solutionsList = new ArrayList<CreateCasesVO>();
		try {
			if (!RMDCommonUtility.isNullOrEmpty(condition)
					&& !RMDCommonUtility.isNullOrEmpty(selectBy)
					&& null != subSystem
					&& !RMDCommonUtility.isNullOrEmpty(rxType)) {
				SolutionBean objSolutionBean = new SolutionBean();
				objSolutionBean.setSolCondition(condition);
				objSolutionBean.setSolSelectBy(selectBy);
				objSolutionBean.setSolValue(value);
				objSolutionBean.setSolSubSystem(subSystem);
				objSolutionBean.setSolutionType(rxType);
				objSolutionBean.setModel(model);
				objSolutionBean.setCustomer(customer);
				objSolutionBean.setRnh(rnh);
				objSolutionBean.setAssets(rn);
				if (!RMDCommonUtility.isNullOrEmpty(rxType)
						&& AppConstants.RX_TYPE_STANDARD
								.equalsIgnoreCase(rxType)) {
					objSolutionBean.setSolutionStatus(AppConstants.APPROVED);
				}
				objSolutionBean.setAddRxApply(AppConstants.YES_FLAG);
				solutionsList = objcreateCasesService.getSolSearchResults(
						objSolutionBean, AppConstants.STR_N);
			}
		} catch (Exception exception) {
			rmdWebLogger.error(
					"Exception occured in getSolSearchResults() method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}

		return solutionsList;
	}

	/**
	 * @Author:
	 * @param :
	 * @return:String
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used to add a recommendation to a given
	 *               Case.
	 * 
	 */

	@RequestMapping(value = AppConstants.ADD_RX_FOR_CASE, method = {
			RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody String addRxToCase(
			@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString,
			final HttpServletRequest request) throws RMDWebException {

		String result = AppConstants.FAILURE;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			final CaseBean objBean = mapper.readValue(parameterString,
					CaseBean.class);

			if (null != userVO.getCmAliasName()) {
				if (AppSecUtil.checkAlphaNumeric(objBean.getCaseId())) {
					CaseBean objCaseBean = getCaseCurrentOwnerDetails(objBean
							.getCaseId());

					if ((!AppConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseBean.getOwner()) || null != objCaseBean
							.getOwner())
							&& objCaseBean.getOwner().equalsIgnoreCase(
									userVO.getCmAliasName())) {
						result = assetCasesService.addRxForCase(objBean);
					} else {
						result = RMDCommonConstants.NOT_CURRENT_OWNER;
					}
				}
			} else {
				result = AppConstants.NO_EOA_USER;
			}

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in addRxForCase() method in AssetCaseController ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;

	}

	/**
	 * @Author:
	 * @param :
	 * @return:String
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used to delete a recommendation to a given
	 *               Case.
	 * 
	 */
	@RequestMapping(AppConstants.DELETE_RX_FOR_CASE)
	public @ResponseBody String deleteRxForCase(
			@RequestParam(value = AppConstants.RX_OBJ_ID) final String rxObjId,
			@RequestParam(value = AppConstants.CASE_OBJID) final String caseObjId,
			@RequestParam(value = AppConstants.CASE_Id) final String caseId,
			final HttpServletRequest request) throws RMDWebException {
		String result = AppConstants.FAILURE;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		CaseBean objCaseBean = new CaseBean();
		try {
			if (null != userVO.getCmAliasName()) {
				if (AppSecUtil.checkAlphaNumeric(caseId)) {
					objCaseBean = getCaseCurrentOwnerDetails(caseId);
					if ((!AppConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseBean.getOwner()) || null != objCaseBean
							.getOwner())
							&& objCaseBean.getOwner().equalsIgnoreCase(
									userVO.getCmAliasName())) {
						if (AppSecUtil.checkAlphaNumeric(caseObjId)
								&& AppSecUtil.checkAlphaNumeric(rxObjId)) {
							CaseBean objBean = new CaseBean();
							objBean.setRxObjId(Long.parseLong(rxObjId));
							objBean.setCaseObjid(Long.parseLong(caseObjId));
							result = assetCasesService.deleteRxForCase(objBean);
						}
					} else {
						result = RMDCommonConstants.NOT_CURRENT_OWNER;
					}
				}
			} else {
				result = AppConstants.NO_EOA_USER;
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in deleteRxForCase method in AssetCaseController ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @Author:
	 * @param :String caseId
	 * @return:CaseBean
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used for fetching the case Information.It
	 *               accepts caseId as an Input Parameter and returns caseBean
	 *               List.
	 * 
	 */
	@RequestMapping(AppConstants.GET_CASE_INFO)
	public @ResponseBody CaseBean getCaseInfo(
			@RequestParam(value = AppConstants.CASE_Id) final String caseId,
			final HttpServletRequest request) throws RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		CaseBean objCaseBean = null;
		try {
			if (AppSecUtil.checkAlphaNumeric(caseId)) {
				objCaseBean = assetCasesService.getCaseInfo(caseId,
						EsapiUtil.stripXSSCharacters(userVO.getTimeZone()));
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getCaseInfo() method in AssetCaseController ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return objCaseBean;
	}

	/**
	 * @Author:
	 * @param:caseId,caseObjid,userName
	 * @return:String
	 * @throws RMDWebException
	 * @Description: This method reOpens a particular case by invoking
	 *               assetCasesService.reOpenCase() method
	 */

	@RequestMapping(value = AppConstants.RE_OPEN_CASE)
	public @ResponseBody String reOpenCase(
			@RequestParam(value = AppConstants.CASE_ID) final String caseId,
			final HttpServletRequest request) throws RMDWebException {
		String result = AppConstants.FAILURE;
		String userId;
		OpenCasesBean objOpenCasesBean;
		try {
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			userId = userVO.getUserId();
			if (AppSecUtil.checkAlphaNumeric(caseId)) {
				CaseBean objCaseBean = new CaseBean();
				objCaseBean = getCaseCurrentOwnerDetails(EsapiUtil.stripXSSCharacters(caseId));
				if (objCaseBean.getCondition().equalsIgnoreCase(
						RMDCommonConstants.CLOSED)) {
					objOpenCasesBean = new OpenCasesBean();
					objOpenCasesBean.setCaseId(EsapiUtil.stripXSSCharacters(caseId));
					objOpenCasesBean.setUserId(EsapiUtil.stripXSSCharacters(userId));
					result = openCasesService.reOpenCase(objOpenCasesBean);
				} else {
					result = RMDCommonConstants.CASE_ALREADY_OPENED;
				}
			} else {
				result = RMDCommonConstants.NOT_CURRENT_OWNER;
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in reOpenCase method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @Author:
	 * @param:caseObjId
	 * @return:List<RxHistoryVO>
	 * @throws RMDWebException
	 * @Description: This method fetches Rx History by invoking
	 *               assetCasesService.getRxHistory()method.
	 */
	@RequestMapping(value = AppConstants.GET_RX_HISTORY)
	public @ResponseBody List<RxHistoryVO> getRxHistory(
			@RequestParam(value = AppConstants.VIEW_CLOSURE_CASEOBJID) final String caseObjId,
			HttpServletRequest request) throws RMDWebException {
		List<RxHistoryVO> rxHistoryVOList = new ArrayList<RxHistoryVO>();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			if (!RMDCommonUtility.isNullOrEmpty(caseObjId)) {
				rxHistoryVOList = assetCasesService.getRxHistory(caseObjId,
						EsapiUtil.stripXSSCharacters(userVO.getTimeZone()));
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getRxHistory method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return rxHistoryVOList;
	}

	/**
	 * @Author:
	 * @param:caseObjId
	 * @return:List<RxStatusHistoryVO>
	 * @throws RMDWebException
	 * @Description: This method fetches RxStatus History by invoking
	 *               assetCasesService.getRxstatusHistory()method.
	 */
	@RequestMapping(value = AppConstants.GET_RX_STATUS_HISTORY)
	public @ResponseBody List<RxStatusHistoryVO> getRxstatusHistory(
			@RequestParam(value = AppConstants.SERVICE_REQ_ID) final String serviceReqId,
			HttpServletRequest request) throws RMDWebException {
		List<RxStatusHistoryVO> rxStatusHistoryVOList = new ArrayList<RxStatusHistoryVO>();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			if (!RMDCommonUtility.isNullOrEmpty(serviceReqId)) {
				rxStatusHistoryVOList = assetCasesService.getRxstatusHistory(
						serviceReqId, EsapiUtil.stripXSSCharacters(userVO.getTimeZone()));
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getRxstatusHistory method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return rxStatusHistoryVOList;
	}

	/**
	 * @Author:
	 * @param:caseObjId
	 * @return:String
	 * @throws RMDWebException
	 * @Description: This method fetches Good Feedback by invoking
	 *               assetCasesService.getClosureFdbk()method.
	 */
	@RequestMapping(value = AppConstants.getClosureFdbk)
	public @ResponseBody String getClosureFdbk(
			@RequestParam(value = AppConstants.RX_CASE_ID) final String rxCaseId)
			throws RMDWebException {
		String closureFdbk = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(rxCaseId)) {
				closureFdbk = assetCasesService.getClosureFdbk(EsapiUtil.stripXSSCharacters(rxCaseId));
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getClosureFdbk method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return closureFdbk;
	}

	/**
	 * @Author:
	 * @param:caseObjId
	 * @return:List<CloseOutRepairCodeVO>
	 * @throws RMDWebException
	 * @Description: This method fetches CloseOut Repair Codes by invoking
	 *               assetCasesService.getCloseOutRepairCode()method.
	 */
	@RequestMapping(value = AppConstants.GET_CLOSEOUT_REPAIR_CODE)
	public @ResponseBody List<CloseOutRepairCodeVO> getCloseOutRepairCode(
			@RequestParam(value = AppConstants.SERVICE_REQ_ID) final String serviceReqId,
			@RequestParam(value = AppConstants.CUST_FDBK_OBJ_ID) final String custFdbkObjId)
			throws RMDWebException {
		List<CloseOutRepairCodeVO> closeOutRepairCodesVOList = new ArrayList<CloseOutRepairCodeVO>();
		try {
			if (!RMDCommonUtility.isNullOrEmpty(custFdbkObjId)) {
				closeOutRepairCodesVOList = assetCasesService
						.getCloseOutRepairCode(custFdbkObjId, serviceReqId);
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getCloseOutRepairCode method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return closeOutRepairCodesVOList;
	}

	/**
	 * @Author:
	 * @param:caseId
	 * @return:List<CloseOutRepairCodeVO>
	 * @throws RMDWebException
	 * @Description: This method fetches Attached details by invoking
	 *               assetCasesService.getAttachedDetails()method.
	 */
	@RequestMapping(value = AppConstants.GET_ATTACHED_DETAILS)
	public @ResponseBody List<CloseOutRepairCodeVO> getAttachedDetails(
			@RequestParam(value = AppConstants.VIEW_CLOSURE_CASE_ID) final String caseId)
			throws RMDWebException {
		List<CloseOutRepairCodeVO> attachedDetailsList = new ArrayList<CloseOutRepairCodeVO>();
		try {
			if (!RMDCommonUtility.isNullOrEmpty(caseId)) {
				attachedDetailsList = assetCasesService
						.getAttachedDetails(caseId);
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAttachedDetails method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return attachedDetailsList;
	}

	/**
	 * @Author:
	 * @param:caseObjId
	 * @return:String
	 * @throws RMDWebException
	 * @Description: This method fetches Rx Note by invoking
	 *               assetCasesService.getRxNote()method.
	 */
	@RequestMapping(value = AppConstants.GET_RX_NOTE)
	public @ResponseBody String getRxNote(
			@RequestParam(value = AppConstants.VIEW_CLOSURE_CASE_OBJ_ID) final String caseObjId)
			throws RMDWebException {
		String rxNote = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(caseObjId)) {
				rxNote = assetCasesService.getRxNote(EsapiUtil.stripXSSCharacters(caseObjId));
				if (!RMDCommonUtility.isNullOrEmpty(rxNote)) {
					rxNote = ESAPI.encoder().decodeForHTML(rxNote);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getRxNotes method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return rxNote;
	}

	/**
	 * @Author:
	 * @param:caseObjId
	 * @return:List<CustomerFdbkVO>
	 * @throws RMDWebException
	 * @Description: This method fetches ServiceReqId & CustFdbkObjId by
	 *               invoking assetCasesService.getServiceReqId()method.
	 */
	@RequestMapping(value = AppConstants.GET_SERVICE_REQ_ID)
	public @ResponseBody List<CustomerFdbkVO> getServiceReqId(String caseObjId)
			throws RMDWebException {
		List<CustomerFdbkVO> customerFdbkList = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(caseObjId)) {
				customerFdbkList = assetCasesService.getServiceReqId(caseObjId);
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getRxNotes method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return customerFdbkList;
	}

	/**
	 * @Author:
	 * @param:caseId,rxObjid,userName,customerName,recomNotes,timeToRepair,urgency
	 * @return:String
	 * @throws GenericAjaxException
	 * @throws RMDWebException
	 * @Description: This method delivers an Recommendation by invoking web
	 *               services deliverRx() method.
	 */
	@RequestMapping(value = AppConstants.DELIVER_RX)
	public @ResponseBody String deliverRx(
			@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString,
			HttpServletRequest request) throws GenericAjaxException,
			RMDWebException {
		String result = AppConstants.FAILURE;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final ObjectMapper mapper = new ObjectMapper();
		CaseBean objCaseBean = new CaseBean();
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			RecommDeliverVO objRecommDeliverVO = mapper.readValue(
					parameterString, RecommDeliverVO.class);
			if (AppSecUtil.checkAlphaNumeric(objRecommDeliverVO.getCaseId())) {
				objCaseBean = getCaseCurrentOwnerDetails(objRecommDeliverVO
						.getCaseId());
			}
			if (!RMDCommonConstants.CLOSED.equalsIgnoreCase(objCaseBean
					.getCondition())
					&& (RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseBean.getQueueName())
							|| null == objCaseBean.getQueueName()
							|| objCaseBean.getQueueName().isEmpty() || RMDCommonConstants.ZERO_STRING
								.equalsIgnoreCase(objCaseBean.getQueueName()))) {
				if ((!RMDCommonConstants.EMPTY_STRING
						.equalsIgnoreCase(objCaseBean.getOwner()) || null != objCaseBean
						.getOwner())
						&& objCaseBean.getOwner().equalsIgnoreCase(
								userVO.getCmAliasName())) {
					result = assetCasesService.deliverRx(objRecommDeliverVO);
				} else {
					result = RMDCommonConstants.NOT_CURRENT_OWNER;
				}
			} else {
				result = RMDCommonConstants.NOT_CURRENT_OWNER;
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in deliverRx method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @Author:
	 * @param:caseId,rxObjid,userName,customerName,recomNotes,timeToRepair,urgency
	 * @return:String
	 * @throws GenericAjaxException
	 * @throws RMDWebException
	 * @Description: This method modifies a recommendation by invoking web
	 *               services modifyRx() method.
	 */
	@RequestMapping(value = AppConstants.MODIFY_RX_TO_CASE)
	public @ResponseBody String modifyRx(
			@RequestParam(value = AppConstants.CASE_Id) String caseId,
			@RequestParam(value = AppConstants.RX_OBJ_ID) String rxObjId,
			@RequestParam(value = AppConstants.USERNAME) String userName,
			@RequestParam(value = AppConstants.CUSTOMER_NAME) String customerName,
			@RequestParam(value = AppConstants.CREATCASE_RECOMNOTES) String recomNotes,
			@RequestParam(value = AppConstants.URGENCY) String urgency,
			@RequestParam(value = AppConstants.ESTIMATED_REPAIR_TIME) String estRepairTime,
			@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString,
			HttpServletRequest request) throws GenericAjaxException,
			RMDWebException {
		String result = AppConstants.FAILURE;
		CaseBean objCaseBean = new CaseBean();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			RecommDeliverVO objRecommDeliverVO = mapper.readValue(
					parameterString, RecommDeliverVO.class);
			if (AppSecUtil.checkAlphaNumeric(caseId)) {
				objCaseBean = getCaseCurrentOwnerDetails(caseId);
			}
			if (!RMDCommonConstants.CLOSED.equalsIgnoreCase(objCaseBean
					.getCondition())
					&& (RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseBean.getQueueName())
							|| null == objCaseBean.getQueueName()
							|| objCaseBean.getQueueName().isEmpty() || RMDCommonConstants.ZERO_STRING
								.equalsIgnoreCase(objCaseBean.getQueueName()))) {
				if ((!RMDCommonConstants.EMPTY_STRING
						.equalsIgnoreCase(objCaseBean.getOwner()) || null != objCaseBean
						.getOwner())
						&& objCaseBean.getOwner().equalsIgnoreCase(
								userVO.getCmAliasName())) {
					if (!RMDCommonUtility.isNullOrEmpty(customerName)
							&& !RMDCommonUtility.isNullOrEmpty(rxObjId)
							&& RMDCommonUtility.isNumeric(rxObjId)
							&& !RMDCommonUtility.isNullOrEmpty(userName)
							&& !RMDCommonUtility.isNullOrEmpty(urgency)
							&& !RMDCommonUtility.isNullOrEmpty(estRepairTime)) {
						
						objRecommDeliverVO.setCustomerName(customerName);
						objRecommDeliverVO.setStrRxObjId(rxObjId);
						objRecommDeliverVO.setCaseId(caseId);
						objRecommDeliverVO.setUserName(userName);
						objRecommDeliverVO.setRecommNotes(AppSecUtil
								.htmlEscaping(recomNotes));
						objRecommDeliverVO.setUrgency(urgency);
						objRecommDeliverVO.setEstRepairTime(estRepairTime);
						RecommDeliverVO objResponseVO = assetCasesService
								.getPendingRcommendation(caseId);
						if (0 != objResponseVO.getFdbkObjId()) {
							objRecommDeliverVO.setFdbkObjId(objResponseVO
									.getFdbkObjId());
							String requestIdStatus = assetCasesService
									.getServiceReqIdStatus(String
											.valueOf(objResponseVO
													.getFdbkObjId()));
							if (!AppConstants.OPEN
									.equalsIgnoreCase(requestIdStatus)) {
								result = assetCasesService
										.modifyRx(objRecommDeliverVO);
							} else {
								result = AppConstants.SERVICE_STATUS_IS_OPEN;
							}
						}
					}
				} else {
					result = RMDCommonConstants.NOT_CURRENT_OWNER;
				}
			} else {
				result = RMDCommonConstants.NOT_CURRENT_OWNER;
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in modifyRx method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @Author:
	 * @param:caseId,rxObjid,userName,customerName,recomNotes,timeToRepair,urgency
	 * @return:String
	 * @throws GenericAjaxException
	 * @throws RMDWebException
	 * @Description: This method replaces a recommendation by invoking web
	 *               services replaceRx() method.
	 */
	@RequestMapping(value = AppConstants.REPLACE_RX_TO_CASE)
	public @ResponseBody String replaceRx(
			@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString,
			HttpServletRequest request) throws GenericAjaxException,
			RMDWebException {
		String result = AppConstants.FAILURE;
		final ObjectMapper mapper = new ObjectMapper();
		CaseBean objCaseBean = new CaseBean();
		try {
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			RecommDeliverVO objRecommDeliverVO = mapper.readValue(
					parameterString, RecommDeliverVO.class);
			if (AppSecUtil.checkAlphaNumeric(objRecommDeliverVO.getCaseId())) {
				objCaseBean = getCaseCurrentOwnerDetails(objRecommDeliverVO
						.getCaseId());
			}
			if (!RMDCommonConstants.CLOSED.equalsIgnoreCase(objCaseBean
					.getCondition())
					&& (RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseBean.getQueueName())
							|| null == objCaseBean.getQueueName()
							|| objCaseBean.getQueueName().isEmpty() || RMDCommonConstants.ZERO_STRING
								.equalsIgnoreCase(objCaseBean.getQueueName()))) {
				if ((!RMDCommonConstants.EMPTY_STRING
						.equalsIgnoreCase(objCaseBean.getOwner()) || null != objCaseBean
						.getOwner())
						&& objCaseBean.getOwner().equalsIgnoreCase(
								userVO.getCmAliasName())) {
					RecommDeliverVO objResponseVO = assetCasesService
							.getPendingRcommendation(objRecommDeliverVO
									.getCaseId());
					if (0 != objResponseVO.getFdbkObjId()
							&& !RMDCommonUtility.isNullOrEmpty(objResponseVO
									.getStrRxObjId())) {
						objRecommDeliverVO.setDelvrdRxObjId(objResponseVO
								.getStrRxObjId());
						objRecommDeliverVO.setFdbkObjId(objResponseVO
								.getFdbkObjId());

						String requestIdStatus = assetCasesService
								.getServiceReqIdStatus(String
										.valueOf(objResponseVO.getFdbkObjId()));
						if (!AppConstants.OPEN
								.equalsIgnoreCase(requestIdStatus)) {
							objRecommDeliverVO.setUserId(userVO.getUserId());
							result = assetCasesService
									.replaceRx(objRecommDeliverVO);
						} else {
							result = AppConstants.SERVICE_STATUS_IS_OPEN;
						}
					}
				} else {
					result = RMDCommonConstants.NOT_CURRENT_OWNER;
				}
			} else {
				result = RMDCommonConstants.NOT_CURRENT_OWNER;
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in replaceRx method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @Author:
	 * @param:String caseObjid
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method fetches Unit Ship Details by invoking web
	 *               services getUnitShipDetails() method.
	 */
	@RequestMapping(value = AppConstants.GET_UNIT_SHIP_DETAILS)
	public @ResponseBody String getUnitShipDetails(
			@RequestParam(value = AppConstants.CASE_OBJ_ID) String caseObjid)
			throws RMDWebException {
		String unitShipDetails = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(caseObjid)
					&& RMDCommonUtility.isNumeric(caseObjid))
				unitShipDetails = assetCasesService
						.getUnitShipDetails(EsapiUtil.stripXSSCharacters(caseObjid));
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getUnitShipDetails method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return unitShipDetails;
	}

	/**
	 * @Author:
	 * @param:RecommDelVO objRecommDelVo
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used to check several conditions In oder to
	 *               deliver an Recommendation. 1.To check Whether Customer has
	 *               Delivery Mechanism are not. 2.To check Whether Eservices
	 *               status is open. 3.To check Whether Recommendation is ready
	 *               to deliver are not. 4.To check pending feedback status.
	 *               5.To check Whether previously delivered Recommendation is
	 *               same as the currently selected recommendation.
	 */
	@RequestMapping(value = AppConstants.VALIDATE_DELIVER_RX)
	public @ResponseBody String validateDeliverRx(
			@RequestParam(value = AppConstants.CASE_Id) String caseId,
			@RequestParam(value = AppConstants.RX_OBJ_ID) String rxObjId,
			@RequestParam(value = AppConstants.CUSTOMER_NAME) String customerName,
			@RequestParam(value = AppConstants.CASE_OBJ_ID) String caseObjId,
			HttpServletRequest request) throws RMDWebException {
		CaseBean objCaseBean = new CaseBean();
		try {
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			if (AppSecUtil.checkAlphaNumeric(caseId)) {
				objCaseBean = getCaseCurrentOwnerDetails(caseId);
			}
			if (!RMDCommonConstants.CLOSED.equalsIgnoreCase(objCaseBean
					.getCondition())
					&& (RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseBean.getQueueName())
							|| null == objCaseBean.getQueueName()
							|| objCaseBean.getQueueName().isEmpty() || RMDCommonConstants.ZERO_STRING
								.equalsIgnoreCase(objCaseBean.getQueueName()))) {
				if ((!RMDCommonConstants.EMPTY_STRING
						.equalsIgnoreCase(objCaseBean.getOwner()) || null != objCaseBean
						.getOwner())
						&& objCaseBean.getOwner().equalsIgnoreCase(
								userVO.getCmAliasName())) {
					if (RMDCommonUtility.isAlphaNumeric(caseId)
							&& !RMDCommonUtility.isNullOrEmpty(caseId)
							&& !RMDCommonUtility.isNullOrEmpty(rxObjId)
							&& RMDCommonUtility.isNumeric(rxObjId)
							&& !RMDCommonUtility.isNullOrEmpty(customerName)
							&& !RMDCommonUtility.isNullOrEmpty(caseObjId)
							&& RMDCommonUtility.isNumeric(caseObjId)) {
						/*
						 * String contorllerConfig = assetCasesService
						 * .checkForContollerConfig(rxObjId);
						 */
						String deliveryMechnism = assetCasesService
								.checkForDelvMechanism(customerName);
						if (AppConstants.STR_N
								.equalsIgnoreCase(deliveryMechnism)) {
							return AppConstants.DELIVERY_MECHANISM_NOT_PRESENT;
						}
						String t2Request = assetCasesService.getT2Req(caseId);
						if (AppConstants.STR_N.equalsIgnoreCase(t2Request)) {
							return AppConstants.TRANSACTION_NOT_ALLOWED;
						}
						List<RecommDeliverVO> arlDeliverVO = assetCasesService
								.getCaseScore(caseId);
						if (!(arlDeliverVO.size() > 0)) {

							if (!AppConstants.STR_Y
									.equalsIgnoreCase(deliveryMechnism)
									&& !RMDCommonUtility
											.isNullOrEmpty(deliveryMechnism)) {
								String readyTodeliver = assetCasesService
										.getReadyToDelv(rxObjId);
								if (AppConstants.CUST_VERSION_NOT_EXIST
										.equalsIgnoreCase(readyTodeliver)) {
									return AppConstants.CUST_VERSION_NOT_EXIST;
								} else if (AppConstants.STR_N
										.equalsIgnoreCase(readyTodeliver)) {
									return AppConstants.RX_IS_NOT_READY_TO_DELV;
								}
							}
							List<RecommDeliverVO> arlPendingFeedback = assetCasesService
									.pendingFdbkServiceStatus(caseId);
							int pendingFeedbackSize = arlPendingFeedback.size();
							if (pendingFeedbackSize == 0) {
								return AppConstants.DELIVER;
							} else if (pendingFeedbackSize == 1) {
								String serviceSheetStatus = arlPendingFeedback
										.get(0).getFdbkStatus();
								String deliveredRxObjid = arlPendingFeedback
										.get(0).getRxObjId().toString();
								if (AppConstants.OPEN
										.equalsIgnoreCase(serviceSheetStatus)) {
									return AppConstants.SERVICE_SHEET_IS_OPEN;
								} else {

									if (deliveredRxObjid
											.equalsIgnoreCase(rxObjId)) {
										return AppConstants.REISSUE;
									} else {
										return AppConstants.REPLACE;
									}
								}
							} else if (pendingFeedbackSize >= 2) {
								return AppConstants.HAS_MORE_THAN_TWO_RX_WITH_PENDING_FDBK;
							}

						} else {
							return AppConstants.RX_NOT_SCORED;
						}
					}
				} else {
					return RMDCommonConstants.NOT_CURRENT_OWNER;
				}
			} else {
				return RMDCommonConstants.NOT_CURRENT_OWNER;
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in validateDeliverRx method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return AppConstants.FAILURE;
	}

	/**
	 * @Author:
	 * @param:String caseObjid,String rxObjid,String fromScreen,String custFdbkObjId
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching Msdc Notes for the
	 *               Recommendation by invoking web services getMsdcNotes()
	 *               method.
	 */
	@RequestMapping(value = AppConstants.GET_MSDC_NOTES)
	public @ResponseBody String getMsdcNotes(
			@RequestParam(value = AppConstants.RX_OBJ_ID) String rxObjid,
			@RequestParam(value = AppConstants.CASE_OBJ_ID) String caseObjid,
			@RequestParam(value = AppConstants.FROM_SCREEN) String fromScreen,
			@RequestParam(value = AppConstants.CUST_FDBK_OBJ_ID) String custFdbkObjId)
			throws RMDWebException {
		String msdcNotes = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(caseObjid)
					&& (!RMDCommonUtility.isNullOrEmpty(rxObjid) ||(RMDCommonConstants.CLOSURE_SCREEN.equalsIgnoreCase(fromScreen)&&!RMDCommonUtility.isNullOrEmpty(custFdbkObjId))))
				msdcNotes = assetCasesService.getMsdcNotes(EsapiUtil.stripXSSCharacters(caseObjid), EsapiUtil.stripXSSCharacters(rxObjid),EsapiUtil.stripXSSCharacters(fromScreen),EsapiUtil.stripXSSCharacters(custFdbkObjId));
			if (!RMDCommonUtility.isNullOrEmpty(msdcNotes)) {
				msdcNotes = EsapiUtil.resumeSpecialChars(msdcNotes);
				//msdcNotes=msdcNotes.replace(AppConstants.HASH_SYMBLE, " ");
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getMsdcNotes method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return msdcNotes;
	}

	/**
	 * @Author:
	 * @param:caseObjId
	 * @return:CustomerFdbkVO
	 * @throws RMDWebException
	 * @Description: This method fetches closure details invoking
	 *               assetCasesService.getClosureDetails()method.
	 */
	@RequestMapping(value = AppConstants.GET_CLOSURE_DETAILS)
	public @ResponseBody CustomerFdbkVO getClosureDetails(String caseObjId)
			throws RMDWebException {
		CustomerFdbkVO objCustomerFdbk = new CustomerFdbkVO();
		try {
			if (!RMDCommonUtility.isNullOrEmpty(caseObjId)) {
				objCustomerFdbk = assetCasesService
						.getClosureDetails(caseObjId);
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getClosure method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return objCustomerFdbk;
	}

	/**
	 * @Author:
	 * @param:HttpServletRequest
	 * @return:String
	 * @throws RMDWebException
	 * @Description: This method does eservice validation invoking
	 *               assetCasesService.doEserviceValidation()method.
	 */
	@RequestMapping(value = AppConstants.DO_ESERVICE_VALIDATION)
	public @ResponseBody String doEserviceValidation(
			final HttpServletRequest request) throws RMDWebException {
		String caseObjId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CASE_OBJID));
		String rxCaseId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.RX_CASE_ID));
		String result = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(caseObjId)
					&& !RMDCommonUtility.isNullOrEmpty(rxCaseId)) {
				result = assetCasesService.doEserviceValidation(caseObjId,
						rxCaseId);
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in doEserviceValidation method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @Author:
	 * @param:rxObjId,caseObjId,model
	 * @return:String
	 * @throws RMDWebException
	 * @Description: This method is used to check for Controller Configuration
	 *               for the given Recommendation.
	 */

	@RequestMapping(value = AppConstants.CHECK_FOR_CONTOLLER_CONFIG)
	public @ResponseBody String checkForContollerConfig(
			@RequestParam(value = AppConstants.RX_OBJ_ID) final String rxObjId,
			@RequestParam(value = AppConstants.CASE_OBJID) final String caseObjId,
			@RequestParam(value = AppConstants.MODEL) final String model)
			throws RMDWebException {
		String result = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(caseObjId)
					&& !RMDCommonUtility.isNullOrEmpty(rxObjId)
					&& !RMDCommonUtility.isNullOrEmpty(model)) {
				result = assetCasesService.checkForContollerConfig(EsapiUtil.stripXSSCharacters(caseObjId),
						EsapiUtil.stripXSSCharacters(rxObjId), EsapiUtil.stripXSSCharacters(model));
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in checkForContollerConfig method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * This method is used to send the Rx list to enable and disable the append
	 * and close buttons
	 **/
	@RequestMapping("/getEnabledRxs")
	public @ResponseBody String[] getEnabledRxs(final HttpServletRequest request)
			throws RMDWebException, Exception {

		final String caseId = request.getParameter(AppConstants.CASE_ID);

		String caseType = request.getParameter("caseType");
		List<String> arlCases = new ArrayList<String>();
		CaseBean caseBean = new CaseBean();
		caseBean.setCaseId(caseId);
		caseBean.setCaseType(caseType);

		final HttpSession session = request.getSession(false);
		// Get UserVO from session for using logged user's TimeZone
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		caseBean.setUserId(userVO.getCmAliasName());
		/* For timezone issue */
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		caseBean.setTimeZone(applicationTimezone);
		arlCases = assetCasesService.getEnabledRxs(caseBean);
		String[] enabledArr = null;
		if (!userVO.getIsCMPrivilege())
			arlCases.add("ALL");
		enabledArr = new String[arlCases.size()];

		for (int i = 0; i < arlCases.size(); i++) {
			enabledArr[i] = arlCases.get(i);
			rmdWebLogger.debug("enabledArr[i]" + enabledArr[i]);

		}
		// Get the open case information of asset
		rmdWebLogger.debug("enabledArr" + enabledArr);
		return enabledArr;
	}

	@RequestMapping(value = AppConstants.TOOLOUTPUT_SUBMIT)
	public @ResponseBody SummaryResponseVO submitToolOutput(
			@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString,
			@RequestParam(AppConstants.CASE_ID) String caseID,
			final HttpServletRequest request) throws RMDWebException, Exception {

		final ObjectMapper mapper = new ObjectMapper();
		List<ToolOutputDeliverVO> deliverVOList = new ArrayList<ToolOutputDeliverVO>();
		List<ToolOutputCaseCloseVO> closeVOList = new ArrayList<ToolOutputCaseCloseVO>();
		List<ToolOutputCaseAppendVO> appendVOList = new ArrayList<ToolOutputCaseAppendVO>();
		List<ToolOutputCaseMergeVO> mergeVOList = new ArrayList<ToolOutputCaseMergeVO>();
		String appendToCaseId = null;
		String appendFromCaseId = null;
		String customerId = null;
		String assetGrpName = null;
		String assetNumber = null;
		String ruleDefId = null;
		String rxIdStr = null;
		String toolId = null;
		String errMessage = null;

		// String caseTitle=null;
		String message = null;
		long rxId = 0;
		String caseType = null;
		String newCaseIdForClose = null;
		SummaryResponseVO summReVO = new SummaryResponseVO();
		List<AppendSummaryVO> appendSummaryVOList = new ArrayList<AppendSummaryVO>();
		List<CloseSummaryVO> closeSummaryVOList = new ArrayList<CloseSummaryVO>();
		List<DeliverSummaryVO> deliverSummaryVOList = new ArrayList<DeliverSummaryVO>();
		//
		// CloseSummaryVO closeSummaryVO = new CloseSummaryVO();
		String rxDelivery = AppConstants.NO_FLAG;
		String rxClose = AppConstants.NO_FLAG;
		String rxAppend = AppConstants.NO_FLAG;
		String rxMerge = AppConstants.NO_FLAG;
		ToolOutputCaseAppendVO updateTitleappendVO = null;
		StringBuilder businessKeys = new StringBuilder();
		businessKeys.append("CaseId : "+caseID);
        businessKeys.append(" parameterString : "+parameterString);
        final HttpSession session = request.getSession();
        final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			rmdWebLogger.debug("getUserId :" + userVO.getUserId());
			rmdWebLogger.debug("getCmAliasName :" + userVO.getCmAliasName());
			/* Start of Changes by Vamshi For Checking Case Current Owner */
			CaseBean objCaseBean = getCaseCurrentOwnerDetails(caseID);
		
			if ((!objCaseBean.getOwner().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING) 
					|| objCaseBean.getOwner() != null) && objCaseBean.getOwner().equalsIgnoreCase(userVO.getCmAliasName())) {
			/* End of Changes */
					
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			CaseActionVO objCaseActionVO = mapper.readValue(parameterString, CaseActionVO.class);
			objCaseActionVO.setUserId(userVO.getUserId());
			objCaseActionVO.setUserName(userVO.getCmAliasName());
			objCaseActionVO.setUserLanguage(userVO.getStrUserLanguage());
			deliverVOList = objCaseActionVO.getDeliverVO();
			closeVOList = objCaseActionVO.getCaseCloseVO();
			appendVOList = objCaseActionVO.getCaseAppendVO();
			/**
			 * Added for Case Merge
			 */
			mergeVOList = objCaseActionVO.getCaseMergeVO();
			MultiValueMap mergeVOMap = getMergeRxs(mergeVOList);
			rmdWebLogger.info("MultiValueMap size ::: " + mergeVOMap.size());
			objCaseActionVO.setMergeVOMap(mergeVOMap);

			String activeRxFlag = request.getParameter(AppConstants.ACTIVE_RX_FLAG);
			if (activeRxFlag != null && activeRxFlag.equalsIgnoreCase(AppConstants.YES_FLAG)) {
				rxDelivery = "Y";
			}
			if (null != deliverVOList && !deliverVOList.isEmpty()) {
				rxDelivery = AppConstants.YES_FLAG;
				deliverSummaryVOList = assetCasesService.toolOutputDeliver(objCaseActionVO);
				if (deliverSummaryVOList == null || deliverSummaryVOList.isEmpty()) {
					errMessage = AppConstants.TOOL_UNEXPECTED_ERR;
					summReVO.setError(errMessage);
				}
				message = "success";
				summReVO.setLstDelVO(deliverSummaryVOList);
			}
			if (null != closeVOList && !closeVOList.isEmpty()) {
				rxClose = AppConstants.YES_FLAG;
			}
			if (null != appendVOList && !appendVOList.isEmpty()) {
				rxAppend = AppConstants.YES_FLAG;
				updateTitleappendVO = appendVOList.get(appendVOList.size() - 1);
			}

			if (null != mergeVOList && !mergeVOList.isEmpty()) {
				rxMerge = AppConstants.YES_FLAG;
			}

			/****************** Close Case *************************/
			boolean ruleForClose = false;
			boolean skipCloseUpdate = false;
			boolean newCaseCreated = false;
			int cnt = 0;// Remove after Testing
			if (null != closeVOList && !closeVOList.isEmpty()) {

				for (ToolOutputCaseCloseVO closeVO : closeVOList) {
					cnt++;
					CloseSummaryVO closeSummaryVO = new CloseSummaryVO();
					CaseBean caseCloseBean = new CaseBean();
					String rxTitle = closeVO.getRxTitle();

					rmdWebLogger.debug("rxTitle: " + rxTitle);
					caseCloseBean.setUserId(userVO.getCmAliasName());
					caseCloseBean.setUserLanguage(userVO.getStrLanguage());
					caseCloseBean.setUserFirstName(userVO.getStrFirstName());
					caseCloseBean.setUserLastName(userVO.getStrLastName());
					caseCloseBean.setCustomerId(closeVO.getCustomerId());
					caseCloseBean.setAssetNumber(closeVO.getAssetnumber());
					caseCloseBean.setAssetGrpName(closeVO.getGroupName());
					caseCloseBean.setRxDelivery(rxDelivery);
					caseCloseBean.setRequestfromToolOutput(true);
					caseCloseBean.setCloseOption(closeVO.getCloseoption());
					caseCloseBean.setRuleDefId(closeVO.getRuleDefId());
					caseCloseBean.setRxId(closeVO.getRxId());
					caseCloseBean.setToolId(closeVO.getToolid());
					caseCloseBean.setCaseId(closeVO.getCaseId());
					caseCloseBean.setToolObjId(closeVO.getToolObjId());

					rmdWebLogger.debug("Printing Close Record Number: " + cnt);
					rmdWebLogger.debug("User cm alias :" + userVO.getCmAliasName());
					rmdWebLogger.debug("AssetNumber :" + closeVO.getAssetnumber());
					rmdWebLogger.debug("AssetGroupName :" + closeVO.getGroupName());
					rmdWebLogger.debug("CaseID :" + closeVO.getCaseId());
					rmdWebLogger.debug("Customer ID:" + closeVO.getCustomerId());
					rmdWebLogger.debug("Close Type:" + closeVO.getCloseoption());
					rmdWebLogger.debug("RuleDedfId:" + closeVO.getRuleDefId());
					rmdWebLogger.debug("RxId:" + closeVO.getRxId());
					rmdWebLogger.info("TOOLIDCLOSE:" + closeVO.getToolid());
					rmdWebLogger.info("rxtitle_close:" + closeVO.getRxTitle());
					rmdWebLogger.debug("RXDELV:" + rxDelivery);
					String activeRx = assetCasesService.activeRxExistsInCase(closeVO.getCaseId());
					rmdWebLogger.debug("activeRx:" + activeRx);
					if (activeRx != null && activeRx.equalsIgnoreCase(AppConstants.YES_FLAG)) {
						rmdWebLogger.debug("activeRx:" + activeRx);
						rxDelivery = "Y";
					}
					// Create a new case for each Rx and add the new case id & Title to SummaryVO
					rmdWebLogger.debug("rxDelivery:" + rxDelivery);
					rmdWebLogger.debug("cnt:" + cnt);
					// Create Case and Move Rx from old case to new case
					// If no Rx is selected for Delivery, the first tooloutput
					// will be retained in current case, no new case created
					// and current case will be closed

					if (closeVO.getToolid() != null && !closeVO.getToolid().equalsIgnoreCase("Fault")) {
						if (cnt == 1 && rxDelivery != null && !rxDelivery.equalsIgnoreCase("Y")){
							// Setting old case to close
							rmdWebLogger.debug("Skipping first tooloutput...");
							newCaseIdForClose = closeVO.getCaseId();
						} else {
							newCaseIdForClose = CaseSolutionService.moveToolOutput(caseCloseBean);
							rmdWebLogger.debug("Moved Tool out to newly created case "+ newCaseIdForClose);
							newCaseCreated = true;
						}

					} else if (closeVO.getToolid() != null && closeVO.getToolid().equalsIgnoreCase("Fault")) {

						if (rxDelivery != null && !rxDelivery.equalsIgnoreCase("Y")){
							// Setting old case to close
							rmdWebLogger.debug("Setting case to be cloased as current case...");
							newCaseIdForClose = closeVO.getCaseId();
						} else {

							rmdWebLogger.debug("Moving Tooloutput from  :" + closeVO.getCaseId());
							newCaseIdForClose = CaseSolutionService.moveToolOutput(caseCloseBean);
							rmdWebLogger.debug("Moved Tool out to newly created case " + newCaseIdForClose);
							newCaseCreated = true;
						}
					}
					try {
						rmdWebLogger.debug("InewCaseCreated" + newCaseCreated);
						// Attach repair code to new case in case of new case
						// being created else attach to current case.
						if (newCaseIdForClose != null && !newCaseIdForClose.equalsIgnoreCase(AppConstants.FAILURE)) {
							rmdWebLogger.debug("INSIDE newCaseIdForClose........" + newCaseIdForClose);
							CaseSolutionVO caseRepairCodes = new CaseSolutionVO();
							caseRepairCodes.setCaseId(newCaseIdForClose);
							/* Added by Vamshi for Adding Repair Code Prod issue */
							String repairCodeObjId = CaseSolutionService.getRepairCodesID(closeVO.getCloseoption());
							caseRepairCodes.setRepairCodeId(repairCodeObjId);

							caseRepairCodes.setUserId(userVO.getUserId());
							rmdWebLogger.debug("caseRepairCodes "+ closeVO.getCloseoption());
							CaseSolutionService.addRepairCodes(caseRepairCodes);
							rmdWebLogger.debug("Added repair codes");

							/* End of Changes */

							// Close new case

							final CaseSolutionVO caseBeanCloseRx = new CaseSolutionVO();
							String status = null;
							// CaseBean objCaseBean = new CaseBean();
							caseBeanCloseRx.setUserId(userVO.getUserId());
							caseBeanCloseRx.setCmAliasName(userVO.getCmAliasName());
							caseBeanCloseRx.setCaseId(newCaseIdForClose);
							String caseTitleClose = CaseSolutionService.getCaseTitle(caseBeanCloseRx.getCaseId());

							rmdWebLogger.debug("Closing Case Id :" + caseBeanCloseRx.getCaseId());
							status = CaseSolutionService.closeCase(caseBeanCloseRx);
							if (!rxAppend.equalsIgnoreCase(AppConstants.YES_FLAG)) {
								if (newCaseCreated || rxDelivery.equalsIgnoreCase("N")) {
									rmdWebLogger.debug("Inside update");
									if (closeVO.getToolid() != null && !closeVO.getToolid().equalsIgnoreCase("Fault")) {
										// Updating title for rules
										rmdWebLogger.debug("Updating title for rules");
										ruleForClose = true;
										if (rxTitle != null && rxTitle.length() >= 69)
											rxTitle = rxTitle.substring(0, 69);
										caseTitleClose = rxTitle + ", No Action";
										caseBeanCloseRx.setCaseTitle(caseTitleClose);
									} else if (closeVO.getToolid() != null && closeVO.getToolid().equalsIgnoreCase("Fault")) {
										rmdWebLogger.debug("Updating title for fault");
										if (caseBeanCloseRx.getCaseId() != null
												&& !caseBeanCloseRx.getCaseId().equalsIgnoreCase(closeVO.getCaseId())) {

											caseTitleClose = "Critical Fault, No Action";
											caseBeanCloseRx.setCaseTitle(caseTitleClose);
										} else {
											if (ruleForClose)
												skipCloseUpdate = true;
											if (!skipCloseUpdate) {
												caseTitleClose = "Critical Fault, No Action";
												caseBeanCloseRx.setCaseTitle(caseTitleClose);
											}
										}
									}

									if (!skipCloseUpdate)
										assetCasesService.updateCaseTitle(caseBeanCloseRx);
								}
							} else if (rxAppend.equalsIgnoreCase(AppConstants.YES_FLAG) ) {
								if (newCaseCreated == true) {
									rmdWebLogger.debug("Inside update");
									if (closeVO.getToolid() != null && !closeVO.getToolid().equalsIgnoreCase("Fault")) {
										// Updating title for rules
										rmdWebLogger.debug("Updating title for rules");
										ruleForClose = true;
										if (rxTitle != null && rxTitle.length() >= 69)
											rxTitle = rxTitle.substring(0, 69);
										caseTitleClose = rxTitle + ", No Action";
										caseBeanCloseRx.setCaseTitle(caseTitleClose);

									} else if (closeVO.getToolid() != null
											&& closeVO.getToolid().equalsIgnoreCase("Fault")) {
										rmdWebLogger.debug("Updating title for fault");
										if (caseBeanCloseRx.getCaseId() != null
												&& !caseBeanCloseRx.getCaseId().equalsIgnoreCase(closeVO.getCaseId())) {
											caseTitleClose = "Critical Fault, No Action";
											caseBeanCloseRx.setCaseTitle(caseTitleClose);
										} else {
											if (ruleForClose)
												skipCloseUpdate = true;
											if (!skipCloseUpdate) {
												caseTitleClose = "Critical Fault, No Action";
												caseBeanCloseRx.setCaseTitle(caseTitleClose);
											}
										}
									}

									if (!skipCloseUpdate)
										assetCasesService.updateCaseTitle(caseBeanCloseRx);
								}
							}
							closeSummaryVO.setCaseId(caseBeanCloseRx.getCaseId());
							closeSummaryVO.setCaseTitle(caseTitleClose);
							closeSummaryVO.setToolId(closeVO.getToolid());
							closeSummaryVO.setRxTitle(closeVO.getRxTitle());
							closeSummaryVO.setRepairCode(closeVO.getCloseoption());
							closeSummaryVOList.add(closeSummaryVO);
							summReVO.setLstCloseVO(closeSummaryVOList);
							if (newCaseCreated == true) {
								// merge code is getting called if new case is created
								rmdWebLogger.info("********Tooloutput merge for close operation starts*******");

								if (null != mergeVOMap && !mergeVOMap.isEmpty()) {
									String rxIdOfClosingCase = closeVO.getRxId();
									// call merge method if any Rx which is tagged with current case
									if (mergeVOMap.containsKey(rxIdOfClosingCase)) {
										rmdWebLogger.info("Inside if condition TooloutputMerge RxId's matched");
										List<ToolOutputCaseMergeVO> toolOutputCaseMergeVOList = (List<ToolOutputCaseMergeVO>) mergeVOMap
												.get(rxIdOfClosingCase);

										for (ToolOutputCaseMergeVO toolOutputCaseMergeVO : toolOutputCaseMergeVOList) {
											String mergedToRxId = toolOutputCaseMergeVO.getMergedTo();
											rmdWebLogger.info("TooloutputMerge ::::Inside mergedTo===rxId check");
											CaseBean caseBean = new CaseBean();
											caseBean.setCaseId(toolOutputCaseMergeVO.getCaseId());
											caseBean.setAppendToCaseId(newCaseIdForClose);
											caseBean.setRuleDefId(toolOutputCaseMergeVO.getRuleDefId());
											caseBean.setAssetGrpName(toolOutputCaseMergeVO.getGroupName());
											caseBean.setAssetNumber(toolOutputCaseMergeVO.getAssetnumber());
											caseBean.setCustomerId(toolOutputCaseMergeVO.getCustomerId());
											caseBean.setToolId(toolOutputCaseMergeVO.getToolid());
											caseBean.setRxObjId(Long.valueOf(toolOutputCaseMergeVO.getRxId()));
											caseBean.setUserId(userVO.getUserId());
											caseBean.setToolObjId(toolOutputCaseMergeVO.getToolObjId());
											caseBean.setMergedTo(Long.valueOf(mergedToRxId));
											assetCasesService.mergeRx(caseBean);
										}
									}
								}
							}

						} else {
							rmdWebLogger.debug("Movetooloutput Failure");
							errMessage = AppConstants.TOOL_UNEXPECTED_ERR;
							summReVO.setError(errMessage);
						}
					} catch (Exception ex) {
						rmdWebLogger.error("Exception occured in Closing Case ", ex);
						errMessage = AppConstants.TOOL_UNEXPECTED_ERR;
						summReVO.setError(errMessage);

					}

				}

			}

			/****************** Append Case *************************/

			try {
				int cnta = 0;
				for (ToolOutputCaseAppendVO appendVO : appendVOList) {
					cnta++;
					AppendSummaryVO appendSummaryVO = new AppendSummaryVO();
					rmdWebLogger.debug("Printing appendVO Record: " + cnta);
					rmdWebLogger.debug("AssetNumber :"+ appendVO.getAssetnumber());
					rmdWebLogger.debug("AssetGroupName :"+ appendVO.getGroupName());
					rmdWebLogger.debug("CaseID :" + appendVO.getCaseId());
					rmdWebLogger.debug("CustomerID:" + appendVO.getCustomerId());
					rmdWebLogger.debug("Case Type :" + appendVO.getCaseType());
					rmdWebLogger.debug("RxId :" + appendVO.getRxId());
					rmdWebLogger.debug("Append To Case :"+ appendVO.getPreviouscases());
					rmdWebLogger.debug("RuleDefId :" + appendVO.getRuleDefId());
					rmdWebLogger.info("TOOLID :" + appendVO.getToolid());
					rmdWebLogger.info("title :" + appendVO.getRxTitle());

					appendToCaseId = appendVO.getPreviouscases();
					appendFromCaseId = appendVO.getCaseId();
					customerId = appendVO.getCustomerId();
					assetGrpName = appendVO.getGroupName();
					assetNumber = appendVO.getAssetnumber();
					ruleDefId = appendVO.getRuleDefId();
					rxIdStr = appendVO.getRxId();
					caseType = appendVO.getCaseType();
					rxId = Long.parseLong(rxIdStr);
					toolId = appendVO.getToolid();
					rmdWebLogger.debug("appendFromCaseId" + appendFromCaseId);
					rmdWebLogger.debug("appendToCaseId" + appendToCaseId);
					// Remove after UI validation
					if (appendToCaseId == null || appendToCaseId.equals(AppConstants.EMPTY_STRING)
							|| appendFromCaseId == null || appendFromCaseId.equals(AppConstants.EMPTY_STRING)
							|| customerId == null || customerId.equals(AppConstants.EMPTY_STRING)
							|| assetGrpName == null || assetGrpName.equals(AppConstants.EMPTY_STRING)
							|| assetNumber == null || assetNumber.equals(AppConstants.EMPTY_STRING) 
							|| caseType == null || caseType.equals(AppConstants.EMPTY_STRING)
							|| rxId == 0) {

						rmdWebLogger.error("One or more Input Params are null in Case Append");
						errMessage = AppConstants.TOOL_UNEXPECTED_ERR;
						summReVO.setError(errMessage);

					}else {
						CaseBean caseBean = new CaseBean();
						caseBean.setCaseId(appendFromCaseId);
						caseBean.setAppendToCaseId(appendToCaseId);
						caseBean.setRuleDefId(ruleDefId);
						caseBean.setAssetGrpName(assetGrpName);
						caseBean.setAssetNumber(assetNumber);
						caseBean.setCustomerId(customerId);
						caseBean.setAppendToCaseId(appendToCaseId);
						caseBean.setToolId(toolId);
						caseBean.setRxObjId(rxId);
						caseBean.setUserId(userVO.getUserId());
						caseBean.setToolObjId(appendVO.getToolObjId());

						message = assetCasesService.appendRx(caseBean);
						if (message != null && message.equalsIgnoreCase(AppConstants.FAILURE)) {
							errMessage = AppConstants.TOOL_UNEXPECTED_ERR;
							summReVO.setError(errMessage);
						} else {
							rmdWebLogger.info("Addding to Append List" + appendToCaseId);
							if (cnta == appendVOList.size() && (rxDelivery != null && !rxDelivery.equalsIgnoreCase(AppConstants.YES_FLAG))) {
								// Getting caseTitle to be appended
								if (updateTitleappendVO != null) {
									String appendedCaseId = updateTitleappendVO.getPreviouscases();
									String AppendedToCaseTitle = CaseSolutionService.getCaseTitle(appendedCaseId);
									AppendedToCaseTitle = AppendedToCaseTitle
											.replaceAll(", No Action", RMDCommonConstants.EMPTY_STRING).trim();
									if (AppendedToCaseTitle.contains(RMDCommonConstants.SYMBOL_ATRATE)) {
										AppendedToCaseTitle = AppendedToCaseTitle
												.substring(0, AppendedToCaseTitle.indexOf(RMDCommonConstants.SYMBOL_ATRATE)).trim();
									}
									int appendCaseTitleLen = AppendedToCaseTitle.length() + appendedCaseId.length();
									rmdWebLogger.debug(" AppendedToCaseTitle.length()+appendedCaseId.length() " + appendCaseTitleLen);
									int maxCaseTitleLen = 78;
									if (appendCaseTitleLen > maxCaseTitleLen) {
										AppendedToCaseTitle = AppendedToCaseTitle
												.substring(0, AppendedToCaseTitle.length() - (appendCaseTitleLen - maxCaseTitleLen));
									}
									CaseSolutionVO caseSolutionVO = new CaseSolutionVO();
									caseSolutionVO.setCaseId(updateTitleappendVO.getCaseId());
									caseSolutionVO.setCaseTitle(AppendedToCaseTitle
													+ " "
													+ RMDCommonConstants.SYMBOL_ATRATE
													+ appendedCaseId);
									rmdWebLogger.debug(" AppendedToCaseTitle.length() "	+ caseSolutionVO.getCaseTitle().length());
									assetCasesService.updateCaseTitle(caseSolutionVO);
								}
							}
							appendSummaryVO.setCaseId(appendToCaseId);
							appendSummaryVO.setCaseTitle(CaseSolutionService.getCaseTitle(appendToCaseId));
							appendSummaryVO.setToolId(toolId);
							appendSummaryVO.setRxTitle(appendVO.getRxTitle());
							if (message != null && message.equalsIgnoreCase("Reopened"))
								appendSummaryVO.setType("Closed Case");
							else
								appendSummaryVO.setType("Open Case");
							
							appendSummaryVOList.add(appendSummaryVO);
							summReVO.setLstAppVO(appendSummaryVOList);

							// Case Merge for Append starts
							rmdWebLogger.info("Case merge code starts for Append operation");

							if (null != mergeVOMap && !mergeVOMap.isEmpty()) {
								// AppendToRxId
								String rxIdOfAppendCase = appendVO.getRxId();
								if (mergeVOMap.containsKey(rxIdOfAppendCase)) {
									rmdWebLogger.info("Inside if condition TooloutputMerge RxId's matched");
									// ToolOutputCaseMergeVO
									// toolOutputCaseMergeVO =
									// mergeVOMap.get(rxIdOfClosingCase);
									List<ToolOutputCaseMergeVO> toolOutputCaseMergeVOList = (ArrayList) mergeVOMap.get(rxIdOfAppendCase);
									for (ToolOutputCaseMergeVO toolOutputCaseMergeVO : toolOutputCaseMergeVOList) {
										String rxIdString = toolOutputCaseMergeVO.getRxId();
										rxId = Long.parseLong(rxIdString);
										String mergedToRxId = toolOutputCaseMergeVO.getMergedTo();
										rmdWebLogger.info("TooloutputMerge ::::Inside mergedTo===rxId check");

										CaseBean caseMergeBean = new CaseBean();
										caseMergeBean.setCaseId(appendFromCaseId);
										caseMergeBean.setAppendToCaseId(appendToCaseId);
										caseMergeBean.setRuleDefId(toolOutputCaseMergeVO.getRuleDefId());
										caseMergeBean.setAssetGrpName(toolOutputCaseMergeVO.getGroupName());
										caseMergeBean.setAssetNumber(toolOutputCaseMergeVO.getAssetnumber());
										caseMergeBean.setCustomerId(toolOutputCaseMergeVO.getCustomerId());
										caseMergeBean.setToolId(toolOutputCaseMergeVO.getToolid());
										caseMergeBean.setUserId(userVO.getUserId());
										caseMergeBean.setToolObjId(toolOutputCaseMergeVO.getToolObjId());
										caseMergeBean.setRxObjId(rxId);
										caseMergeBean.setMergedTo(Long.valueOf(mergedToRxId));
										assetCasesService.mergeRx(caseMergeBean);
									}

								}// ends
							}

						}
					}
					if (!rxDelivery.equals(AppConstants.YES_FLAG)) {
						if (cnta > 0 && summReVO != null && summReVO.getLstAppVO() != null
								&& summReVO.getLstAppVO().size() > 0 && rxDelivery != null) {
							
							rmdWebLogger.debug("appendFromCaseId" + appendFromCaseId);
							String activeRx = assetCasesService.activeRxExistsInCase(appendFromCaseId);
							rmdWebLogger.debug("activeRx:" + activeRx);
							if (activeRx == null || !activeRx.equalsIgnoreCase(AppConstants.YES_FLAG)) {
								final CaseSolutionVO caseBeanCloseRx = new CaseSolutionVO();
								caseBeanCloseRx.setUserId(userVO.getUserId());
								caseBeanCloseRx.setCmAliasName(userVO.getCmAliasName());
								caseBeanCloseRx.setCaseId(appendFromCaseId);
								rmdWebLogger.debug("Closing Case Id :"+ appendFromCaseId);
								CaseSolutionService.closeCase(caseBeanCloseRx);
								rmdWebLogger.debug("Closed Case Id :"+ appendFromCaseId);
							}
						}
					}

				}
				
			} catch (Exception ex) {
				rmdWebLogger.error("Exception occured in Appending Case ", ex);
				persistException(userVO.getUserId(), "Submit ToolOutput", businessKeys.toString(), ex);
				// RMDWebErrorHandler.handleException(ex);
				errMessage = AppConstants.TOOL_UNEXPECTED_ERR;
				summReVO.setError(errMessage);
			}
			} else {
				summReVO.setError(RMDCommonConstants.NOT_CURRENT_OWNER);
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in submitToolOutput method ", ex);
			persistException(userVO.getUserId(), "Submit ToolOutput", businessKeys.toString(), ex);
			errMessage = AppConstants.TOOL_UNEXPECTED_ERR;
			summReVO.setError(errMessage);
			RMDWebErrorHandler.handleException(ex);
		}
		return summReVO;

	}

	/**
	 * This method is used to check for any activeRx exist in a Case
	 * 
	 * @param request
	 * @return
	 * @throws RMDWebException7
	 * @throws Exception
	 */
	@RequestMapping(value = AppConstants.ACTIVE_RX_EXISTS_IN_CASE)
	public @ResponseBody String activeRxExistsInCase(
			final HttpServletRequest request) throws RMDWebException, Exception {
		String isActiveRxPresent = RMDCommonConstants.EMPTY_STRING;
		try {
			final String caseId = request.getParameter(AppConstants.CASE_ID);
			if (!RMDCommonUtility.isNullOrEmpty(caseId)) {
				isActiveRxPresent = assetCasesService
						.activeRxExistsInCase(caseId);
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in AssetCasesController activeRxExistsInCase method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return isActiveRxPresent;
	}

	/**
	 * This method is used to check for any activeRx exist in a Case
	 * 
	 * @param request
	 * @return
	 * @throws RMDWebException7
	 * @throws Exception
	 */
	@RequestMapping(value = AppConstants.GET_CLOSE_OPTION)
	public @ResponseBody Map<String, String> getCloseOption(
			final HttpServletRequest request) throws RMDWebException, Exception {

		Map<String, String> closeOptionMap = new HashMap<String, String>();

		try {
			closeOptionMap = assetCasesService
					.getCloseOption(AppConstants.CLOSE_OPTION_LIST);

		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getCloseOption() method - AssetCasesController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return closeOptionMap;
	}

	/**
	 * @Author :
	 * @return :RxDetailsVO
	 * @param : caseObjId,vehicleObjId
	 * @throws :RMDWebException
	 * @Description: This method is used to get Rx Details of the Case.
	 * 
	 */

	@RequestMapping(value = AppConstants.GET_RX_DETAILS)
	public @ResponseBody RxDetailsVO getRxDetails(
			@RequestParam(AppConstants.CASE_OBJID) String caseObjId,
			@RequestParam(AppConstants.VEHICLE_OBJID) String vehicleObjId)
			throws RMDWebException {
		RxDetailsVO objRxDetailsVO = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(caseObjId)
					&& !RMDCommonUtility.isNullOrEmpty(vehicleObjId)) {
				objRxDetailsVO = assetCasesService.getRxDetails(caseObjId,
						vehicleObjId);
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getRxDetails() method - AssetCasesController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return objRxDetailsVO;
	}

	/**
	 * @Author:
	 * @param:String vehicleObjId
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used check whether PP Asset History Button
	 *               Has to Disable or Enable.
	 */
	@RequestMapping(value = AppConstants.GET_PP_ASSET_HST_BTN_DETAILS)
	public @ResponseBody String displayPPAssetHistoryBtn(
			@RequestParam(AppConstants.VEHICLE_OBJID) String vehicleObjId)
			throws RMDWebException {
		String result = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(vehicleObjId)) {
				result = assetCasesService
						.displayPPAssetHistoryBtn(EsapiUtil.stripXSSCharacters(vehicleObjId));
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in displayPPAssetHistoryBtn method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @Author :Mohamed
	 * @return :List<MaterialUsageVO>
	 * @param : serviceReqId,lookUpDays
	 * @throws :RMDWebException
	 * @Description: This method is used to get list of parts for particular
	 *               case.
	 * 
	 */

	@RequestMapping(value = AppConstants.GET_MATERIAL_USAGE)
	public @ResponseBody List<MaterialUsageVO> getMaterialUsage(
			@RequestParam(AppConstants.SERVICE_REQ_ID) String serviceReqId,
			@RequestParam(AppConstants.MATERIAL_USAGE_LOOKUP_DAYS) String lookUpDays,
			HttpServletRequest request) throws RMDWebException {
		List<MaterialUsageVO> materialUsageVOList = new ArrayList<MaterialUsageVO>();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			if (!RMDCommonUtility.isNullOrEmpty(serviceReqId)
					&& !RMDCommonUtility.isNullOrEmpty(lookUpDays)) {
				materialUsageVOList = assetCasesService.getMaterialUsage(
						serviceReqId, lookUpDays, EsapiUtil.stripXSSCharacters(userVO.getTimeZone()));
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getRxstatusHistory method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return materialUsageVOList;
	}

	public MultiValueMap getMergeRxs(List<ToolOutputCaseMergeVO> mergeVOList) {
		// Map<String,ToolOutputCaseMergeVO> mergeRxMap = new
		// HashMap<String,ToolOutputCaseMergeVO>();
		MultiValueMap mergeRxMap = new MultiValueMap();
		if (mergeVOList != null && !mergeVOList.isEmpty()) {
			for (ToolOutputCaseMergeVO toolOutputCaseMergeVO : mergeVOList) {
				mergeRxMap.put(toolOutputCaseMergeVO.getMergedTo(),
						toolOutputCaseMergeVO);
			}
		}
		return mergeRxMap;

	}

	/**
	 * @Author :
	 * @return :String
	 * @param :AddNotesEoaServiceVO
	 * @throws :RMDWebException
	 * @Description:This method is used for adding unit notes .
	 */

	@RequestMapping(value = AppConstants.ADD_NOTES_TO_UNIT)
	public @ResponseBody String addNotesToUnit(
			@RequestParam(value = AppConstants.ASSET_NUMBER) final String assetNumber,
			@RequestParam(value = AppConstants.CUSTOMER_ID) final String customerId,
			@RequestParam(value = AppConstants.ASSET_GROUP_NAME) final String assetGrpName,
			@RequestParam(value = AppConstants.NOTE_DESCRIPTION) final String noteDescription,
			@RequestParam(value = AppConstants.APPLY_LEVEL) final String applyLevel,
			@RequestParam(value = AppConstants.STICKY) final String sticky,
			@RequestParam(value = AppConstants.USER_ID) final String userId,
			final HttpServletRequest request) throws RMDWebException {

		String result = AppConstants.FAILURE;
		NotesBean notesbean = new NotesBean();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			if (null != userVO.getCmAliasName()) {
				if (AppSecUtil.checkAlphaNumeric(userId)) {
					notesbean.setAssetNumber(assetNumber);
					notesbean.setCustomerId(customerId);
					notesbean.setAssetGroup(assetGrpName);
					notesbean.setNoteDescription(noteDescription);
					notesbean.setApplyLevel(applyLevel);
					notesbean.setSticky(sticky);
					notesbean.setUserId(userId);
					result = assetCasesService.addNotesToUnit(notesbean);
				}
			} else {

				result = AppConstants.NO_EOA_USER;
			}

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in addNotesToUnit  method in AssetCaseController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return result;
	}

	/**
	 * @Author:
	 * @param :caseId
	 * @return StickyNotesDetailsVO
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 * @Description: This method is used fetching unit Sticky notes details for
	 *               a given case.This is done by Invoking
	 *               fetchStickyUnitNotes() method of AssestCaseServiceImpl
	 *               Layer.
	 */
	@RequestMapping(value = AppConstants.FETCH_UNIT_LEVEL_STICKY_DETAILS)
	public @ResponseBody StickyNotesDetailsVO fetchStickyUnitLevelNotes(
			@RequestParam(value = AppConstants.ASSET_NUMBER) final String assetNumber,
			@RequestParam(value = AppConstants.CUSTOMER_ID) final String customerId,
			@RequestParam(value = AppConstants.ASSET_GROUP_NAME) final String assetGrpName,
			final HttpServletRequest request) throws GenericAjaxException,
			RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		StickyNotesDetailsVO stickyNotes = null;
		try {
			if (null != assetNumber && null != customerId
					&& null != assetGrpName) {
				stickyNotes = assetCasesService.fetchStickyUnitLevelNotes(
						assetNumber, customerId, assetGrpName,
						EsapiUtil.stripXSSCharacters(userVO.getTimeZone()));
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured fetchStickyUnit method in AssetCaseController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return stickyNotes;
	}

	/**
	 * @Author:
	 * @param :
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 * @Description: This method is used for fetching GPOC Smart Shop Votes.
	 */

	@RequestMapping(value = AppConstants.GET_GPOC_SMART_SHOP_VOTES)
	public @ResponseBody Map<String, String> getGPOCSmartShopVotes()
			throws RMDWebException {
		Map<String, String> smartShopeVotesMap = null;
		try {
			smartShopeVotesMap = assetCasesService.getGPOCSmartShopVotes();
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured getGPOCSmartShopVotes method in AssetCaseController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return smartShopeVotesMap;
	}

	/**
	 * @Author :Vamshi
	 * @return :String
	 * @param :CaseSolutionVO objCaseSolutionVO
	 * @throws :RMDWebException
	 * @Description:This method is responsible for Casting the GPOC Users Vote.
	 */
	@RequestMapping(value = AppConstants.CAST_GPOC_VOTE)
	public @ResponseBody String castGPOCVote(
			@RequestParam(value = AppConstants.CASE_ID, required = true) final String caseId,
			@RequestParam(value = AppConstants.REPAIR_CODE) final String repairCode,
			final HttpServletRequest request) throws RMDWebException {
		CaseSolutionVO caseRepairCodes = new CaseSolutionVO();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String responseMsg = null;
		try {
			CaseBean objCaseBean = new CaseBean();
			objCaseBean = getCaseCurrentOwnerDetails(caseId);
			if (!objCaseBean.getCondition().equalsIgnoreCase(
					RMDCommonConstants.CLOSED)
					&& (null == objCaseBean.getQueueName()
							|| objCaseBean.getQueueName().equalsIgnoreCase(
									RMDCommonConstants.EMPTY_STRING)
							|| objCaseBean.getQueueName().isEmpty() || objCaseBean
							.getQueueName().equalsIgnoreCase(
									RMDCommonConstants.ZERO_STRING))) {
				if ((!objCaseBean.getOwner().equalsIgnoreCase(
						RMDCommonConstants.EMPTY_STRING) || objCaseBean
						.getOwner() != null)
						&& objCaseBean.getOwner().equalsIgnoreCase(
								userVO.getCmAliasName())) {
					if (!RMDCommonUtility.isNullOrEmpty(repairCode)) {
						caseRepairCodes.setCaseId(caseId);
						caseRepairCodes.setRepairCode(repairCode);
						caseRepairCodes.setUserId(userVO.getUserId());
						responseMsg = assetCasesService
								.castGPOCVote(caseRepairCodes);
					} else {
						responseMsg = AppConstants.REPAIR_CODE_REQUIRED;
					}
				} else {
					responseMsg = RMDCommonConstants.NOT_CURRENT_OWNER;
				}
			} else {
				responseMsg = RMDCommonConstants.CASE_CLOSED;
			}
		} catch (RMDWebException e) {
			responseMsg = AppConstants.FAILURE;
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in castGPOCVote()  method  of AssetCasesController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return responseMsg;
	}

	/**
	 * @Author :Vamsee
	 * @return :String
	 * @param :CaseSolutionVO objCaseSolutionVO
	 * @throws :RMDWebException
	 * @Description:This method is responsible for fetching previously Casted
	 *                   vote.
	 */
	@RequestMapping(value = AppConstants.GET_PREVIOUS_VOTE)
	public @ResponseBody String getPreviousVote(
			@RequestParam(value = AppConstants.CASE_OBJID) String caseObjId)
			throws RMDWebException {
		String previousVote = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(caseObjId)) {
				previousVote = assetCasesService.getPreviousVote(EsapiUtil.stripXSSCharacters(caseObjId));
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured getPreviousVote() method in AssetCaseController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return previousVote;
	}
	/**
	 * @Author:
	 * @param request
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description: Retrieve the comm area details from database
	 */
	@RequestMapping(AppConstants.REQ_URI_ASSETCASES_COMM_SECTION)
	@ResponseBody public  AssetLocatorResponseVO getAssetCasesCommSection(final HttpServletRequest request)
			throws RMDWebException, Exception {

		rmdWebLogger.debug(" AssetCases Controller getAssetCasesCommSection():::START");
		Future<AssetLocatorResponseVO> futureLastFaultList = null;
		AssetLocatorResponseVO futureLastFault = new AssetLocatorResponseVO();
		AssetOverviewBean assetBean = new AssetOverviewBean();
		String customerID = null;
		final String assetNumber = request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM);
		final String assetGrpName = request
				.getParameter(AppConstants.ASSET_GROUP_NAME);

		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		request.setAttribute(AppConstants.FILTERFLAG,
				request.getParameter(AppConstants.FLAG));
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		try {
			customerID = asstOvwService
					.getCustomerId(assetNumber, assetGrpName);
			assetBean.setAsset(assetNumber);
			assetBean.setAssetGroup(assetGrpName);
			assetBean.setCustomer(customerID);
			assetBean.setUserLanguage(userVO.getStrUserLanguage());
			assetBean.setUserTimeZone(applicationTimezone);
			assetBean.setUserLanguage(userVO.getStrUserLanguage());
			futureLastFaultList = assetCasesService
					.getAssetCaseCommSection(assetBean);

			if (null != futureLastFaultList) {
				futureLastFault = futureLastFaultList.get();
			}
			rmdWebLogger.debug("AssetCases Controller getAssetCasesCommSection():::END");
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getAssetCasesCommSection() method ",
							rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			RMDWebErrorHandler.handleException(rmdEx);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getAssetCasesCommSection method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			RMDWebErrorHandler.handleException(ex);
		}
		finally
		{
			futureLastFaultList=null;
			
		}
		rmdWebLogger
				.debug("AssetCases Controller : getAssetCasesCommSection() method Ends");
		return futureLastFault;
	}
	

    @RequestMapping(value = AppConstants.GET_ADD_REP_CODE_DETAILS)
    public @ResponseBody String getAddRepCodeDetails(
            @RequestParam(value = AppConstants.VIEW_CLOSURE_CASE_ID) final String caseId)
                    throws RMDWebException {
        String retValue = AppConstants.TRUE_STRING;
        try {
            if (!RMDCommonUtility.isNullOrEmpty(caseId)) {
                retValue = assetCasesService.getAddRepCodeDetails(caseId);
            }
        } catch (Exception ex) {
            rmdWebLogger.error(
                    "Exception occured in getAddRepCodeDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return retValue;
    }

    @RequestMapping(value = AppConstants.GET_LOOKUP_ADD_REP_CODE_DETAILS)
    public @ResponseBody String getLookUpRepCodeDetails(
            @RequestParam(value = AppConstants.REPAIRCODE_LIST) final String repairCodeList)
                    throws RMDWebException {
        String retValue = AppConstants.TRUE_STRING;
        try {
            if (!RMDCommonUtility.isNullOrEmpty(repairCodeList)) {
                retValue = assetCasesService
                        .getLookUpRepCodeDetails(repairCodeList);
            }
        } catch (Exception ex) {
            rmdWebLogger.error(
                    "Exception occured in getLookUpRepCodeDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return retValue;
    }
    
    @RequestMapping(value = AppConstants.GET_CASESCORE_REPAIR_CODE)
	public @ResponseBody List<CaseScoreRepairCodeVO> getCaseScoreRepairCodes(
			@RequestParam(value = AppConstants.RX_CASE_ID) final String rxCaseId)
			throws RMDWebException {
		List<CaseScoreRepairCodeVO> closeOutRepairCodesVOList = new ArrayList<CaseScoreRepairCodeVO>();
		try {
			if (!RMDCommonUtility.isNullOrEmpty(rxCaseId)) {
				closeOutRepairCodesVOList = assetCasesService
						.getCaseScoreRepairCodes(rxCaseId);
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getCloseOutRepairCode method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return closeOutRepairCodesVOList;
	}
    
    /**
     * @Author:
     * @param:String customerName
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching Msdc Notes for the
     *               Recommendation by invoking web services getMsdcNotes()
     *               method.
     */
     @RequestMapping(value = AppConstants.CHECK_TOOL_OUTPUT_DELV_MACHANISM)
     @ResponseBody 
     public String checkToolOutputDelvMachanism(
             @RequestParam(value = AppConstants.CUSTOMER_NAME) String customerName) throws RMDWebException {
        String deliveryMechnism = AppConstants.STR_N;
        try { 
            if(!RMDCommonUtility.isNullOrEmpty(customerName)){
                deliveryMechnism = assetCasesService
                        .checkForDelvMechanism(EsapiUtil.stripXSSCharacters(customerName));
            }               
           
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getMsdcNotes method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return deliveryMechnism;
    }
     
     @RequestMapping(value = AppConstants.VALIDATE_VEH_BOMS)
     @ResponseBody 
     public List<String> validateVehBoms(
             @RequestParam(value = AppConstants.CUSTOMER_NAME) String customerName,
             @RequestParam(value = AppConstants.RNH) String rnh,
             @RequestParam(value = AppConstants.ROAD_NUMBER) String rn,
             @RequestParam(value = AppConstants.RX_OBJ_ID) String rxObjId,
             @RequestParam(value = AppConstants.FROM_SCREEN,required=false) String fromScreen) throws RMDWebException {
        List<String> assetList = null;
        try { 
            if(!RMDCommonUtility.isNullOrEmpty(customerName) && !RMDCommonUtility.isNullOrEmpty(rnh) 
                    && !RMDCommonUtility.isNullOrEmpty(rn) && !RMDCommonUtility.isNullOrEmpty(rxObjId)){
                assetList = assetCasesService
                        .validateVehBoms(EsapiUtil.stripXSSCharacters(customerName),EsapiUtil.stripXSSCharacters(rnh)
                                ,EsapiUtil.stripXSSCharacters(rn),EsapiUtil.stripXSSCharacters(rxObjId),EsapiUtil.stripXSSCharacters(fromScreen));
            }               
           
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in validateVehBom method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return assetList;
    }
     
     
     /**
 	 * @Author:
 	 * @param:String caseObjid,String rxObjid,String fromScreen,String custFdbkObjId
 	 * @return:String
 	 * @throws:RMDWebException
 	 * @Description: This method is used for fetching Msdc Notes for the
 	 *               Recommendation by invoking web services getMsdcNotes()
 	 *               method.
 	 */
 	@RequestMapping(value = AppConstants.GET_RX_DELIVERY_ATTACHMENTS)
 	public @ResponseBody List<RxDeliveryAttachmentVO> getRxDeliveryAttachments(
 			@RequestParam(value = AppConstants.RX_OBJ_ID) String rxObjid,
 			@RequestParam(value = AppConstants.CASE_OBJ_ID) String caseObjid 			
 			)
 			throws RMDWebException {
 		List<RxDeliveryAttachmentVO> arlAttachmentVO=new ArrayList<RxDeliveryAttachmentVO>();
 		try {
 			if (!RMDCommonUtility.isNullOrEmpty(caseObjid)
 					&& (!RMDCommonUtility.isNullOrEmpty(rxObjid)))
 				arlAttachmentVO = assetCasesService.getRxDeliveryAttachments(EsapiUtil.stripXSSCharacters(caseObjid), EsapiUtil.stripXSSCharacters(rxObjid));
 			
 		} catch (Exception ex) {
 			rmdWebLogger.error("Exception occured in getMsdcNotes method ", ex);
 			RMDWebErrorHandler.handleException(ex);
 		}
 		return arlAttachmentVO;
 	}
 	
 	/**
	 * @Author :
	 * @return :RxDetailsVO
	 * @param : caseObjId,vehicleObjId
	 * @throws :RMDWebException
	 * @Description: This method is used to get Rx Details of the Case.
	 * 
	 */

	@RequestMapping(value = AppConstants.GET_CASE_RX_DELV_DETAILS)
	public @ResponseBody String getCaseRxDelvDetails(
			@RequestParam(AppConstants.CASE_ID) String caseId
			)
			throws RMDWebException {
		String rxObjid = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(caseId)) {
				rxObjid = assetCasesService.getCaseRxDelvDetails(caseId);
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getCaseRxDelvDetails() method - AssetCasesController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return rxObjid;
	}
}
