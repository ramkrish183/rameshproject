/**
 * ============================================================
 * File 			: KPITotalCountResponseTypeVO.java
 * Description 		: Value Object for KPI Total RxCount Display  
 * Package 			: com.ge.trans.rmd.cm.valueobjects
 * Author 			: UST
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		: April 30, 2012
 * History
 * Modified By 		: Initial Release
 * Copyright (C) 2012 General Electric Company. All rights reserved
 * ============================================================
 */

package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

public class KPITotalCountResponseTypeVO {

	private String customerId;
	private String kpiName;
	private String totalCount;
	protected List<KpiInfoTypeVO> parameter;
	private String  lastFourWeekAvg;
	private String  lastQuarterAvg;
	private String  currentYearAvg;
	private String lastUpdatedDate;
	private int index = -1;
	
	

	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getLastFourWeekAvg() {
		return lastFourWeekAvg;
	}

	public void setLastFourWeekAvg(String lastFourWeekAvg) {
		this.lastFourWeekAvg = lastFourWeekAvg;
	}

	public String getLastQuarterAvg() {
		return lastQuarterAvg;
	}

	public void setLastQuarterAvg(String lastQuarterAvg) {
		this.lastQuarterAvg = lastQuarterAvg;
	}

	public String getCurrentYearAvg() {
		return currentYearAvg;
	}

	public void setCurrentYearAvg(String currentYearAvg) {
		this.currentYearAvg = currentYearAvg;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getKpiName() {
		return kpiName;
	}

	public void setKpiName(String kpiName) {
		this.kpiName = kpiName;
	}

	public String getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;
	}

	public List<KpiInfoTypeVO> getParameter() {
		return parameter;
	}

	public void setParameter(List<KpiInfoTypeVO> parameter) {
		this.parameter = parameter;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	
}
