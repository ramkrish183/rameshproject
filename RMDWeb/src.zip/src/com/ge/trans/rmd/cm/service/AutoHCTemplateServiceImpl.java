package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.AutoHCTemplateDetails;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.assets.valueobjects.AutoHCDetailsOfTempResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ListWrapperResponseType;


@Service
public class AutoHCTemplateServiceImpl extends RMDBaseServiceImpl implements
		AutoHCTemplateService {
	
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private WebServiceInvoker rsInvoker;
	
	@Autowired
	WebServiceInvoker webServiceInvoker;
	
	private final RMDWebLogger logger = RMDWebLogger.getLogger(getClass());	
	
	@Override
	public List<String> getTemplateDropDwn(String ctrlConfig, String configFile)
			throws GenericAjaxException, RMDWebException {
		List<String> stringListdata = new ArrayList<String>();
		Map<String,String> templateRequestMap = new HashMap<String, String>();
		templateRequestMap.put("ctrlConfig", ctrlConfig);
		templateRequestMap.put("configFile", configFile);
		try{
			ListWrapperResponseType truckInfo = (ListWrapperResponseType)(webServiceInvoker.get(
					ServiceConstants.GET_TEMPLATES_DATA,null, templateRequestMap,null,
					ListWrapperResponseType.class));
			stringListdata = truckInfo.getElements();
		} catch (RMDWebException e) {
			logger.error(
					"Exception occured in getTemplateDropDwn in AutoHCTemplateServiceImpl:",e);
			RMDWebErrorHandler.handleException(e);
		}
		return stringListdata;
	}
	
	@Override
	public List<String> getFaultCodeRecTypeDropDwn(String ctrlConfig, String configFile)
			throws GenericAjaxException, RMDWebException {
		List<String> stringListdata = new ArrayList<String>();
		Map<String,String> dataRequestMap = new HashMap<String, String>();
		dataRequestMap.put("ctrlConfig", ctrlConfig);
		dataRequestMap.put("configFile", configFile);
		try{
			ListWrapperResponseType truckInfo = (ListWrapperResponseType)(webServiceInvoker.get(
					ServiceConstants.GET_FAULT_CODE_REC_TYPE_DATA,null, dataRequestMap,null,
					ListWrapperResponseType.class));
			stringListdata = truckInfo.getElements();
		} catch (RMDWebException e) {
			logger.error(
					"Exception occured in getFaultCodeRecTypeDropDwn in AutoHCTemplateServiceImpl:",e);
			RMDWebErrorHandler.handleException(e);
		}
		return stringListdata;
	}
	
	@Override
	public List<String> getMessageDefIdDropDwn()
			throws GenericAjaxException, RMDWebException {
		List<String> stringListdata = new ArrayList<String>();
		
		try{
			ListWrapperResponseType truckInfo = (ListWrapperResponseType)(webServiceInvoker.get(
					ServiceConstants.GET_MESSAGE_DEF_ID_DATA,null, null,null,
					ListWrapperResponseType.class));
			stringListdata = truckInfo.getElements();
		} catch (RMDWebException e) {
			logger.error(
					"Exception occured in getMessageDefIdDropDwn in AutoHCTemplateServiceImpl:",e);
			RMDWebErrorHandler.handleException(e);
		}
		return stringListdata;
	}

	@Override
	public String postAutoHCNewTemplate(
			AutoHCTemplateDetails autoHCTemplateDetails)
			throws GenericAjaxException, RMDWebException {
		Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		String result = new String();
		try{
			queryParamMap.put(AppConstants.AH_TEMPLATE_OBJ_ID, autoHCTemplateDetails.getTempObjId());
			queryParamMap.put(AppConstants.AH_SAMPLE_RATE, autoHCTemplateDetails.getSampleRate());
			queryParamMap.put(AppConstants.AH_POST_SAMPLES, autoHCTemplateDetails.getPostSamples());
			queryParamMap.put(AppConstants.AH_FREQUENCY, autoHCTemplateDetails.getFrequency());
			queryParamMap.put(AppConstants.AH_FCRT_OBJID, autoHCTemplateDetails.getFcrtObjid());
			queryParamMap.put(AppConstants.AH_TEMPLATE_NO, autoHCTemplateDetails.getTemplateNo());
			queryParamMap.put(AppConstants.AH_VERSION_NO, autoHCTemplateDetails.getVersionNo());
			queryParamMap.put(AppConstants.AH_TITLE, autoHCTemplateDetails.getTitle());
			queryParamMap.put(AppConstants.AH_STATUS, autoHCTemplateDetails.getStatus());
			queryParamMap.put(AppConstants.AH_CTRL_CONFIG_OBJID, autoHCTemplateDetails.getConfigCtrlObjid());
			
			result = (String)webServiceInvoker.get(
					ServiceConstants.POST_NEW_TEMPLATE_DATA,null, queryParamMap,null,
					String.class);
		}
		catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in postAutoHCNewTemplate() method of AutoHCTemplateServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	@Override
	public Map<String, String> getComAHCDetails(String templateNo,
			String versionNo, String ctrlCfgObjId) throws GenericAjaxException,
			RMDWebException {
		Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		Map<String, String> result = new LinkedHashMap<String, String>();
				//new LinkedHashMap<String, String>();
		try{
			
			queryParamMap.put(AppConstants.AH_TEMPLATE_NO,templateNo );
			queryParamMap.put(AppConstants.AH_VERSION_NO, versionNo);
			queryParamMap.put(AppConstants.AH_CTRL_CONFIG_OBJID,ctrlCfgObjId);
			
			AutoHCDetailsOfTempResponseType[] autoHCDetailsOfTempResponseType = (AutoHCDetailsOfTempResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_AUTO_HC_COMPLETE_DETAILS, null,
							queryParamMap, null,AutoHCDetailsOfTempResponseType[].class);
			if (null != autoHCDetailsOfTempResponseType) {
				for (int i = 0; i < autoHCDetailsOfTempResponseType.length; i++) {
					result.put(
							autoHCDetailsOfTempResponseType[i].getId(),
							autoHCDetailsOfTempResponseType[i].getIdValue());
				}
			}
			autoHCDetailsOfTempResponseType = null;
	}
		catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in postAutoHCNewTemplate() method of AutoHCTemplateServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}
	
	

}
