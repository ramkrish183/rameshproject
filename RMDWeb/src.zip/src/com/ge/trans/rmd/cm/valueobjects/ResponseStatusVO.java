/**
 * 
 */
package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

/**
 * @author MSHIRAJUDDIN
 *
 */
public class ResponseStatusVO {
	private String status;
	private List<DetailsVO> details;
	
	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return the details
	 */
	public List<DetailsVO> getDetails() {
		return details;
	}
	/**
	 * @param details the details to set
	 */
	public void setDetails(List<DetailsVO> details) {
		this.details = details;
	}


}
