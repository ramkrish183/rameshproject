package com.ge.trans.rmd.cm.valueobjects;

public class CameraDetailsResponseVO {
	private String assetOwnerId;
	private String roadInitial;
	private String roadNumber;
	private String device;
	private int numOfCameras;
	private String isDefault = "N";
	public String getAssetOwnerId() {
		return assetOwnerId;
	}
	public void setAssetOwnerId(String assetOwnerId) {
		this.assetOwnerId = assetOwnerId;
	}
	public String getRoadInitial() {
		return roadInitial;
	}
	public void setRoadInitial(String roadInitial) {
		this.roadInitial = roadInitial;
	}
	public String getRoadNumber() {
		return roadNumber;
	}
	public void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}
	public String getDevice() {
		return device;
	}
	public void setDevice(String device) {
		this.device = device;
	}
	public int getNumOfCameras() {
		return numOfCameras;
	}
	public void setNumOfCameras(int numOfCameras) {
		this.numOfCameras = numOfCameras;
	}
	public String getIsDefault() {
		return isDefault;
	}
	public void setIsDefault(String isDefault) {
		this.isDefault = isDefault;
	}
	
	
	
}
