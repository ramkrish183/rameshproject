package com.ge.trans.rmd.cm.valueobjects;

import com.ge.trans.rmd.common.beans.RMDBaseBean;

public class HealthCheckSubmitVO extends RMDBaseBean{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String customerID;
	private String roadIntial;
	private Long roadNumber;
	private String assetType;
	private Long mpGroupId;
	private String mpGroupName; 
	private Long sampleRate;
	private Long postSamples;
	private String platform;
	private String mpNum;
	private String assetId;
	private String typeOfUser;
	//private String userId;
	private String device;
	
	public String getDevice() {
		return device;
	}
	public void setDevice(String device) {
		this.device = device;
	}
	public String getTypeOfUser() {
		return typeOfUser;
	}
	public void setTypeOfUser(String typeOfUser) {
		this.typeOfUser = typeOfUser;
	}
	public String getAssetId() {
		return assetId;
	}
	public void setAssetId(String assetId) {
		this.assetId = assetId;
	}
	/**
	 * @return the customerID
	 */
	public String getCustomerID() {
		return customerID;
	}
	/**
	 * @return the mpNum
	 */
	public String getMpNum() {
		return mpNum;
	}
	/**
	 * @param mpNum the mpNum to set
	 */
	public void setMpNum(String mpNum) {
		this.mpNum = mpNum;
	}
	/**
	 * @return the userId
	 *//*
	public String getUserId() {
		return userId;
	}
	*//**
	 * @param userId the userId to set
	 *//*
	public void setUserId(String userId) {
		this.userId = userId;
	}*/
	/**
	 * @param customerID the customerID to set
	 */
	public void setCustomerID(String customerID) {
		this.customerID = customerID;
	}
	/**
	 * @return the roadIntial
	 */
	public String getRoadIntial() {
		return roadIntial;
	}
	/**
	 * @param roadIntial the roadIntial to set
	 */
	public void setRoadIntial(String roadIntial) {
		this.roadIntial = roadIntial;
	}
	/**
	 * @return the roadNumber
	 */
	public Long getRoadNumber() {
		return roadNumber;
	}
	/**
	 * @param roadNumber the roadNumber to set
	 */
	public void setRoadNumber(Long roadNumber) {
		this.roadNumber = roadNumber;
	}
	/**
	 * @return the assetType
	 */
	public String getAssetType() {
		return assetType;
	}
	/**
	 * @param assetType the assetType to set
	 */
	public void setAssetType(String assetType) {
		this.assetType = assetType;
	}
	/**
	 * @return the mpGroupId
	 */
	public Long getMpGroupId() {
		return mpGroupId;
	}
	/**
	 * @param mpGroupId the mpGroupId to set
	 */
	public void setMpGroupId(Long mpGroupId) {
		this.mpGroupId = mpGroupId;
	}
	/**
	 * @return the mpGroupName
	 */
	public String getMpGroupName() {
		return mpGroupName;
	}
	/**
	 * @param mpGroupName the mpGroupName to set
	 */
	public void setMpGroupName(String mpGroupName) {
		this.mpGroupName = mpGroupName;
	}
	/**
	 * @return the sampleRate
	 */
	public Long getSampleRate() {
		return sampleRate;
	}
	/**
	 * @param sampleRate the sampleRate to set
	 */
	public void setSampleRate(Long sampleRate) {
		this.sampleRate = sampleRate;
	}
	/**
	 * @return the postSamples
	 */
	public Long getPostSamples() {
		return postSamples;
	}
	/**
	 * @param postSamples the postSamples to set
	 */
	public void setPostSamples(Long postSamples) {
		this.postSamples = postSamples;
	}
	/**
	 * @return the platform
	 */
	public String getPlatform() {
		return platform;
	}
	/**
	 * @param platform the platform to set
	 */
	public void setPlatform(String platform) {
		this.platform = platform;
	}

}
