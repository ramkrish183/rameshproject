package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.NotesService;
import com.ge.trans.rmd.cm.valueobjects.FindNotesDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.StickyNotesDetailsVO;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.AppSecUtil;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.ResourceVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
@Controller
public class NotesController extends RMDBaseController {

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	NotesService notesService;
	@Autowired
	ApplicationContext appContext;
	
	@RequestMapping(AppConstants.REQ_URI_NOTES)
	public ModelAndView showNotes(final HttpServletRequest request) {
		request.setAttribute(AppConstants.FILTERFLAG,
				EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG)));
		return new ModelAndView(AppConstants.VIEW_NOTES);
	}

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param :
	 * @throws :Exception
	 * @Description: Displays the Add Notes page of the RMD application when
	 *               clicked on Add Notes Tab in View Page.
	 * 
	 */

    @SuppressWarnings("unchecked")
    @RequestMapping(value = AppConstants.REQ_URI_ADD_NOTES)
    public ModelAndView viewAddNotesPage(final HttpServletRequest request)
            throws Exception {
        rmdWebLogger.debug("Inside NotesController in viewAddNotesPage Method");
        final HttpSession session = request.getSession(false);
        Map<String, List<ResourceVO>> secNavMap = new LinkedHashMap<String, List<ResourceVO>>();
        try {
            secNavMap = (Map<String, List<ResourceVO>>) session
                    .getAttribute(AppConstants.ATTR_SEC_MAP);

            if (null != secNavMap.get(RMDCommonConstants.FIND)) {
                List<ResourceVO> listVO = secNavMap.get(RMDCommonConstants.FIND);
                for (ResourceVO obj : listVO) {
                    if (RMDCommonConstants.PREV_SUBMENU_FIND_NOTES
                            .equalsIgnoreCase(obj.getResourceId())) {
                        request.setAttribute(
                                AppConstants.HAS_FIND_NOTES_ACCESS,
                                RMDCommonConstants.TRUE);
                        break;
                    }
                }

            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in viewAddNotesPage method ",
                    ex);
            RMDWebErrorHandler.handleException(ex);
        }

        return new ModelAndView(AppConstants.ADD_NOTES);
    }

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param :
	 * @throws :Exception
	 * @Description: Displays the Find Notes page of the RMD application when
	 *               clicked on Find Notes Tab in View Page.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_FIND_NOTES, method = RequestMethod.GET)
	public String viewFindNotesPage(final HttpServletRequest request)
			throws Exception {
		rmdWebLogger
				.debug("Inside NotesController Controller in viewFindNotesPage Method");
		Calendar cal = Calendar.getInstance();
		final SimpleDateFormat fromDateFormat = new SimpleDateFormat(
				AppConstants.DATE_FORMAT_24HRS);
		String previousDate = null;
		String previousDateRange = null;
		String currentDate = null;
		cal.set(Calendar.HOUR_OF_DAY,cal.getTime().getHours());
		cal.set(Calendar.MINUTE, cal.getTime().getMinutes());
		cal.set(Calendar.SECOND,  cal.getTime().getSeconds());
		currentDate = fromDateFormat.format(cal.getTime());
		previousDateRange = notesService.getFindNotesLookBackDays();
		previousDateRange = AppConstants.SYMBOL_MINUS + previousDateRange;
		cal.add(Calendar.MONTH, Integer.parseInt(previousDateRange));
		cal.set(Calendar.HOUR_OF_DAY, 0);
		cal.set(Calendar.MINUTE, 0);
		cal.set(Calendar.SECOND, 0);
		previousDate = fromDateFormat.format(cal.getTime());
		request.setAttribute(AppConstants.PP_CURRENT_DATE, currentDate);
		request.setAttribute(AppConstants.FIND_NOTES_PREVOIUSDATE, previousDate);
		request.setAttribute(
				AppConstants.NOTES_DEFAULT_RECORDS,
				findNumberOfRecords(AppConstants.FIND_NOTES_TABLE_DEFAULT_RECORDS));
		
		return AppConstants.FIND_NOTES;
	}
	
	/**
	 * @Author :
	 * @return :Map<String, String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This controller method will fetch the list of controllers
	 * 
	 */
	@RequestMapping(value = AppConstants.GET_ALL_CONTROLLERS, method = RequestMethod.GET)
	public @ResponseBody
	Map<String, String> getAllControllers(final Model model,
			final HttpServletRequest request) throws RMDWebException {

		rmdWebLogger
				.debug("Inside UserManagementController  in getCustomers Method");
		Map<String, String> controllersMap = new LinkedHashMap<String, String>();
		try {
			controllersMap = notesService.getAllControllers();
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAllControllers method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return controllersMap;
	}

	/**
	 * @Author :
	 * @return :Map<String, String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This controller method will fetch the list of Notes
	 *               Creators in OMD
	 * 
	 */
	@RequestMapping(value = AppConstants.GET_ALL_CREATORS, method = RequestMethod.GET)
	public @ResponseBody
	Map<String, String> getNotesCreatersList(final Model model,
			final HttpServletRequest request) throws RMDWebException {

		rmdWebLogger
				.debug("Inside UserManagementController  in getCustomers Method");
		Map<String, String> creatorsMap = new LinkedHashMap<String, String>();
		try {
			creatorsMap = notesService.getNotesCreatersList();
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getNotesCreatersList method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return creatorsMap;
	}

	/**
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Find Notes Note Type Options By drop down.
	 */
	@RequestMapping(value = AppConstants.GET_NOTE_TYPES)
	public @ResponseBody
	Map<String, String> getNoteTypes() throws RMDWebException {
		Map<String, String> allNoteTypeMap = new LinkedHashMap<String, String>();
		try {
			allNoteTypeMap = notesService.getNoteTypes();
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getNoteTypes method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allNoteTypeMap;
	}

	/**
	 * @Author:
	 * @param :customerId,fromRN
	 * @return StickyNotesDetailsVO
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 * @Description: This method is used fetching unit Sticky notes details for
	 *               a customer and road number.This is done by Invoking
	 *               fetchVehicleStickyDetails() method of NotesServiceImpl
	 *               Layer.
	 */
	@RequestMapping(value = AppConstants.FETCH_VEHICLE_STICKY_DETAILS, method = RequestMethod.GET)
	@ResponseBody public 
	List<StickyNotesDetailsVO> fetchVehicleStickyDetails(
			@RequestParam(value = AppConstants.CUSTOMER_ID) String customerId,
			@RequestParam(value = AppConstants.FROM_RN) String fromRN,
			HttpServletRequest request) throws GenericAjaxException,RMDWebException {
		fromRN = EsapiUtil.stripXSSCharacters((String)(request.getParameter(AppConstants.FROM_RN)));
		customerId = EsapiUtil.stripXSSCharacters((String)(request.getParameter(AppConstants.CUSTOMER_ID)));
		List<StickyNotesDetailsVO> stickyNotesDetailsVOList = new ArrayList<StickyNotesDetailsVO>();
		StickyNotesDetailsVO objStickyNotesDetailsVO = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		List<String> listRn = Arrays.asList(fromRN
				.split(RMDCommonConstants.COMMMA_SEPARATOR));
		String noOfUnits = String.valueOf(listRn.size());
		try {
			List<StickyNotesDetailsVO> objStickyNotesDetailsVOList = notesService
					.fetchVehicleStickyDetails(EsapiUtil.stripXSSCharacters(customerId), EsapiUtil.stripXSSCharacters(fromRN), EsapiUtil.stripXSSCharacters(noOfUnits),
							EsapiUtil.stripXSSCharacters(userVO.getTimeZone()));
			for (StickyNotesDetailsVO stickyNotesDetailsVODetails : objStickyNotesDetailsVOList) {
				if (null != stickyNotesDetailsVODetails.getAdditionalInfo()
						&& null != stickyNotesDetailsVODetails.getObjId()
						&& null != stickyNotesDetailsVODetails.getCreatedBy()
						&& null != stickyNotesDetailsVODetails.getEntryTime()) {
					stickyNotesDetailsVOList = objStickyNotesDetailsVOList;
				} else {
					objStickyNotesDetailsVO = new StickyNotesDetailsVO();
					List<String> allAssets =new LinkedList<String>( Arrays.asList(fromRN
							.split(RMDCommonConstants.COMMMA_SEPARATOR)));
					System.out.println("The list of all assets is"+allAssets);
					List<String> stickyAssets = stickyNotesDetailsVODetails
							.getStickyAssets();
					allAssets.removeAll(stickyAssets);
					objStickyNotesDetailsVO.setNonStickyAssets(allAssets);
					objStickyNotesDetailsVO.setStickyAssets(stickyNotesDetailsVODetails.getStickyAssets());
					stickyNotesDetailsVOList.add(objStickyNotesDetailsVO);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured fetchStickyUnit method in AssetCaseController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return stickyNotesDetailsVOList;

	}
	/**
	 * @Author:
	 * @param :
	 * @return String
	 * @throws RMDWebException
	 * @Description: This method is used to insert the notes
	 */
	@RequestMapping(value = AppConstants.ADD_NOTES_TO_VEHICLE)
	public @ResponseBody
	String addNotesToVehicle(
			@RequestParam(value = AppConstants.CUSTOMER_ID) final String customerId,
			@RequestParam(value = AppConstants.STICKY) final String sticky,
			@RequestParam(value = AppConstants.FROM_RN) final String fromRN,
			@RequestParam(value = AppConstants.TO_RN) final String toRN,
			@RequestParam(value = AppConstants.MODEL_ID) final String modelId,
			@RequestParam(value = AppConstants.CONTROLLER_ID) final String ctrlId,
			@RequestParam(value = AppConstants.FLEET_ID) final String fleetId,
			@RequestParam(value = AppConstants.NOTE_DESCRIPTION) final String noteDescription,
			@RequestParam(value = AppConstants.OVERWRITE_FLAG) final String overWriteFlag,
			@RequestParam(value = AppConstants.USER_ID) final String userId,
			@RequestParam(value = AppConstants.STICKY_EXIST_OBJID) final String objId,
			@RequestParam(value = AppConstants.ASSETNUMBER) final String assetNumbers,
			final HttpServletRequest request) throws RMDWebException {

		String status = null;
		NotesBean notesBean = new NotesBean();
		// final HttpSession session = request.getSession(false);
		try {
			if (!RMDCommonUtility.isNullOrEmpty(customerId)) {
				notesBean.setCustomerId(customerId);
			}
			if (!RMDCommonUtility.isNullOrEmpty(sticky)) {
				notesBean.setSticky(sticky);
			}
			if (!RMDCommonUtility.isNullOrEmpty(fromRN)) {
				notesBean.setFromRN(fromRN);
			}
			if (!RMDCommonUtility.isNullOrEmpty(toRN)) {
				notesBean.setToRN(toRN);
			}
			if (!RMDCommonUtility.isNullOrEmpty(modelId)) {
				notesBean.setModelId(modelId);
			}
			if (!RMDCommonUtility.isNullOrEmpty(ctrlId)) {
				notesBean.setCtrlId(ctrlId);
			}
			if (!RMDCommonUtility.isNullOrEmpty(fleetId)) {
				notesBean.setFleetId(fleetId);
			}
			if (!RMDCommonUtility.isNullOrEmpty(noteDescription)) {
				notesBean.setNoteDescription(ESAPI.encoder().encodeForXML(noteDescription));
			}
			if (!RMDCommonUtility.isNullOrEmpty(overWriteFlag)) {
				notesBean.setOverWriteFlag(overWriteFlag);
			}
			if (!RMDCommonUtility.isNullOrEmpty(userId)) {
				notesBean.setUserId(userId);
			}
			if (!RMDCommonUtility.isNullOrEmpty(objId)) {
				notesBean.setStickyObjId(objId);
			}
			if (!RMDCommonUtility.isNullOrEmpty(assetNumbers)) {
				notesBean.setAssetNumbersList(Arrays.asList(assetNumbers
						.split(RMDCommonConstants.COMMMA_SEPARATOR)));
			}
			status = notesService.addNotesToVehicle(notesBean);

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in addNotesToVehicle  method in NotesController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}

		return status;
	}

	/**
	 * 
	 * @param
	 * @return FindCasesDetailsVO
	 * @throws Exception
	 * @Description This method is used to get the Notes.
	 * 
	 */
	@RequestMapping(value = AppConstants.GET_FIND_NOTES, method = RequestMethod.POST)
	public @ResponseBody
	List<FindNotesDetailsVO> getFindNotes(final HttpServletRequest request)
			throws Exception {
		String strError = null;
		List<FindNotesDetailsVO> objFindNotesDetailsVOlst = new ArrayList<FindNotesDetailsVO>();
		NotesBean objNotesBean = new NotesBean();
		FindNotesDetailsVO objFindNotesDetailsVO = new FindNotesDetailsVO();
		Map<String, String> findNotesErr = new HashMap<String, String>(2);
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		// validation
		strError = checkDateValidation(request);
		try {
			if (RMDCommonUtility.isNullOrEmpty(strError)) {
				if (!RMDCommonUtility.isNullOrEmpty(request
						.getParameter(AppConstants.CUSTOMER_ID))) {
					objNotesBean.setCustomerId(request
							.getParameter(AppConstants.CUSTOMER_ID));
				}
				if (!RMDCommonUtility.isNullOrEmpty(request
						.getParameter(AppConstants.FROM_RN))) {
					objNotesBean.setFromRN(request
							.getParameter(AppConstants.FROM_RN));
				}
				if (!RMDCommonUtility.isNullOrEmpty(request
						.getParameter(AppConstants.TO_RN))) {
					objNotesBean.setToRN(request
							.getParameter(AppConstants.TO_RN));
				}
				if (!RMDCommonUtility.isNullOrEmpty(request
						.getParameter(AppConstants.MODEL_ID))) {
					objNotesBean.setModelId(request
							.getParameter(AppConstants.MODEL_ID));
				}
				if (!RMDCommonUtility.isNullOrEmpty(request
						.getParameter(AppConstants.FLEET_ID))) {
					objNotesBean.setFleetId(request
							.getParameter(AppConstants.FLEET_ID));
				}
				if (!RMDCommonUtility.isNullOrEmpty(request
						.getParameter(AppConstants.CONTROLLER_ID))) {
					objNotesBean.setCtrlId(request
							.getParameter(AppConstants.CONTROLLER_ID));
				}
				if (!RMDCommonUtility.isNullOrEmpty(request
						.getParameter(AppConstants.CREATED_BY))) {
					objNotesBean.setCreatedBy(request
							.getParameter(AppConstants.CREATED_BY));
				}
				if (!RMDCommonUtility.isNullOrEmpty(request
						.getParameter(AppConstants.NOTE_TYPE))) {
					objNotesBean.setNotesType(request
							.getParameter(AppConstants.NOTE_TYPE));
				}
				if (!RMDCommonUtility.isNullOrEmpty(request
						.getParameter(AppConstants.FINDNOTES_START_DATE))) {
					objNotesBean.setStartDate(request
							.getParameter(AppConstants.FINDNOTES_START_DATE));
				}
				if (!RMDCommonUtility.isNullOrEmpty(request
						.getParameter(AppConstants.FINDNOTES_END_DATE))) {
					objNotesBean.setEndDate(request
							.getParameter(AppConstants.FINDNOTES_END_DATE));
				}
				if (!RMDCommonUtility.isNullOrEmpty(request
						.getParameter(AppConstants.FINDNOTES_KEYWORD))) {
					objNotesBean.setSearchKeyWord(request
							.getParameter(AppConstants.FINDNOTES_KEYWORD));
				}
				objFindNotesDetailsVOlst = notesService.getFindNotes(
						objNotesBean, userVO.getTimeZone());
			} else {
				findNotesErr.put(strError, strError);
				objFindNotesDetailsVO.setFindNoteErr(findNotesErr);
				objFindNotesDetailsVOlst.add(objFindNotesDetailsVO);
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getFindNotes  method in NotesController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		} finally {
			objNotesBean = null;
			findNotesErr = null;
			objFindNotesDetailsVO = null;
		}
		return objFindNotesDetailsVOlst;
	}

	/**
	 * @Author:
	 * @param :caseStickyObjId,unitStickyObjId
	 * @return:String
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used for removing a unit Level as well as
	 *               case Level Sticky Notes.
	 */

	@RequestMapping(value = AppConstants.FIND_NOTES_REMOVE_STICKY)
	public @ResponseBody
	String removeSticky(
			@RequestParam(value = AppConstants.UNIT_STICKY_OBJID) String unitStickyObjId,
			@RequestParam(value = AppConstants.CASE_STICKY_OBJID) String caseStickyObjId,HttpServletRequest request)
			throws RMDWebException {
		unitStickyObjId = EsapiUtil.stripXSSCharacters((String) (request.getParameter(AppConstants.UNIT_STICKY_OBJID)));
		caseStickyObjId = EsapiUtil.stripXSSCharacters((String) (request.getParameter(AppConstants.CASE_STICKY_OBJID)));
        String result = AppConstants.FAILURE;
		try {
			result = notesService
					.removeSticky(unitStickyObjId, caseStickyObjId);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in remove removeStickymethod in NotesController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}
	
	/**
	 * 
	 * @param
	 * @return String
	 * @Description * This method is used for Validations.
	 * 
	 */
	public String checkDateValidation(final HttpServletRequest request)
			throws Exception {
		String strError = null;
		Date fromdate = null, todate = null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
				AppConstants.DATE_FORMAT_24HRS);
		String strFromDt = null;
		String strToDt = null;
		Date sysdate = new Date();
		try {
			strFromDt = request.getParameter(AppConstants.FINDNOTES_START_DATE);
			strToDt = request.getParameter(AppConstants.FINDNOTES_END_DATE);
			if ((null != strFromDt && !strFromDt.isEmpty())) {
				fromdate = simpleDateFormat.parse(strFromDt);
				if ((null != strToDt && !strToDt.isEmpty())) {
					todate = simpleDateFormat.parse(strToDt);
					if (todate.getTime() - fromdate.getTime() < 0) {
						strError = AppConstants.FINDNOTES_END_DATE_ERROR;
					}
				}
				if (sysdate.getTime() - fromdate.getTime() < 0) {
					strError = AppConstants.FINDNOTES_START_FUTURE_DATE;
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in checkDateValidation method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return strError;
	}
	
	/**
	 * 
	 * @param
	 * @return
	 * @Description * This method is used for export selected data.
	 * 
	 */
	@RequestMapping(value = AppConstants.EXPORT_FINDNOTES, method = RequestMethod.POST)
	public void exportFindCasesReport(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws Exception {
		List<FindNotesDetailsVO> objFindNotesDetailsVOlst = null;
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		try {
			objFindNotesDetailsVOlst = getFindNotes(request);
			if (null != objFindNotesDetailsVOlst && !objFindNotesDetailsVOlst.isEmpty()) {
				csvContent = convertToCSVFindNotesReport(objFindNotesDetailsVOlst,
						locale);
				response.setContentType(AppConstants.CONTENT_TYPE);
				response.setHeader(AppConstants.CONTENT,
						AppConstants.ATTACH_FILENAME
								+ AppConstants.FINDNOTES_EXPORT_FILENAME);
				objServletOutputStream = response.getOutputStream();
				ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
						csvContent.getBytes());
				objBufferedInputStream = new BufferedInputStream(
						objByteArrayInputStream);
				objBufferedOutputStream = new BufferedOutputStream(
						objServletOutputStream);
				byte[] byteArr = new byte[2048];
				int bytesread;
				while ((bytesread = objBufferedInputStream.read(byteArr, 0,
						byteArr.length)) != -1) {
					objBufferedOutputStream.write(byteArr, 0, bytesread);
					objBufferedOutputStream.flush();
				}
			}
		} catch (Exception e) {
			rmdWebLogger.error(
					"Exception occured in exportFindNotesReport method ", e);
			RMDWebErrorHandler.handleException(e);
		} finally {
			if (null != objBufferedInputStream) {
				objBufferedInputStream.close();
			}
			if (null != objBufferedOutputStream) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}
		}
	}
	
	/**
	 * @param
	 * @Description:This method is used for looping through the list of Find
	 *                   Notes records and will covert to csv content
	 * @return: String
	 * @param:collectiveResponse,Locale locale
	 */
	private String convertToCSVFindNotesReport(
			List<FindNotesDetailsVO> listFindNotesDetailsReport, Locale locale) {
		StringBuffer strTechCasesBuffer = new StringBuffer();
		String csvContent = null;
		try {

			strTechCasesBuffer.append(appContext.getMessage(
					AppConstants.FINDNOTES_REPORT_HEADER, null, locale));

			strTechCasesBuffer.append(RMDCommonConstants.NEWLINE);
			if (RMDCommonUtility
					.isCollectionNotEmpty(listFindNotesDetailsReport)) {
				for (FindNotesDetailsVO objFindCasesDetailsVO : listFindNotesDetailsReport) {

					strTechCasesBuffer
							.append(RMDCommonUtil
									.removeHtmlandNullValues(objFindCasesDetailsVO
											.getCustomerName())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getRn())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getCaseId())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getDate())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getModelName())
									+ RMDCommonConstants.COMMMA_SEPARATOR);
					strTechCasesBuffer
							.append(RMDCommonUtil
									.removeHtmlandNullValues(objFindCasesDetailsVO
											.getCtrlName())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getCreatedBy())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getNoteType())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objFindCasesDetailsVO
													.getNoteDescription()));
									
					strTechCasesBuffer.append(RMDCommonConstants.NEWLINE);
				}

			}

			csvContent = strTechCasesBuffer.toString();
		} catch (Exception ex) {
			rmdWebLogger.error("Export to CSV convertToCSVFindCasesReport"
					+ ex.getMessage());
		}
		return csvContent;
	}

}
