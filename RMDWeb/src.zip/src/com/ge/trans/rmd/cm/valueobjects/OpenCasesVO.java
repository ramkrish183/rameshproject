package com.ge.trans.rmd.cm.valueobjects;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.trans.rmd.common.vo.RMDBaseVO;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class OpenCasesVO extends RMDBaseVO{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String assetNumber; 
	private String caseStatus;
	private String age;
	private String caseID;
	private String caseTitle;
	private String owner;
	private String createdDate;
	private String priority;
	private String customerName;
	private String strGrpName;
	private Integer rowVersion;
	private String caseType;
	private String caseReason;
	private String ownerName;
	private String customerId;
	private String caseCondition;
	
	private String queueName;
	private String closeDate;
	private Long caseObjId;
	private String append;
	private String cssClass;
	
	
	public String getCssClass() {
		return cssClass;
	}
	public void setCssClass(String cssClass) {
		this.cssClass = cssClass;
	}
	public String getQueueName() {
		return queueName;
	}
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	public String getCloseDate() {
		return closeDate;
	}
	public void setCloseDate(String closeDate) {
		this.closeDate = closeDate;
	}
	public Long getCaseObjId() {
		return caseObjId;
	}
	public void setCaseObjId(Long caseObjId) {
		this.caseObjId = caseObjId;
	}
	public String getAppend() {
		return append;
	}
	public void setAppend(String append) {
		this.append = append;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getCaseCondition() {
		return caseCondition;
	}
	public void setCaseCondition(String caseCondition) {
		this.caseCondition = caseCondition;
	}
	/**
	 * @return the customerId
	 */
	public String getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getCaseReason() {
		return caseReason;
	}
	public void setCaseReason(String caseReason) {
		this.caseReason = caseReason;
	}
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public Integer getRowVersion() {
		return rowVersion;
	}
	public void setRowVersion(final Integer rowVersion) {
		this.rowVersion = rowVersion;
	}
	public String getAssetNumber() {
		return assetNumber;
	}
	public void setAssetNumber(final String assetNumber) {
		this.assetNumber = assetNumber;
	}
	public String getCaseStatus() {
		return caseStatus;
	}
	public void setCaseStatus(final String caseStatus) {
		this.caseStatus = caseStatus;
	}
	public String getAge() {
		return age;
	}
	public void setAge(final String age) {
		this.age = age;
	}
	public String getCaseID() {
		return caseID;
	}
	public void setCaseID(final String caseID) {
		this.caseID = caseID;
	}
	public String getCaseTitle() {
		return caseTitle;
	}
	public void setCaseTitle(final String caseTitle) {
		this.caseTitle = caseTitle;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(final String owner) {
		this.owner = owner;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(final String createdDate) {
		this.createdDate = createdDate;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(final String priority) {
		this.priority = priority;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(final String customerName) {
		this.customerName = customerName;
	}
	public String getStrGrpName() {
		return strGrpName;
	}
	public void setStrGrpName(final String strGrpName) {
		this.strGrpName = strGrpName;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	
	
}
