package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map.Entry;
import java.util.SortedSet;

import com.ge.trans.rmd.cm.beans.OpenCasesBean;
import com.ge.trans.rmd.cm.valueobjects.OpenCasesVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.exception.RMDServiceException;


public interface OpenCasesService {
	
	public List<OpenCasesVO> fetchOpenCases(OpenCasesBean openCaseBean) throws RMDWebException,Exception;
	public SortedSet<Entry<String, String>> getDropDownValues() throws RMDWebException,Exception;
	/*
	 * This method is use for take the ownership for particular case.
	 */
	public String takeOwnerShip(OpenCasesBean openCaseBean) throws RMDWebException,Exception;
	String reOpenCase(OpenCasesBean openCaseBean) throws RMDWebException,
			Exception;
	/*
	 * This method is used for real time check of the owner of the case from eoa and omd 
	 */
	public String getCurrentOwnership(OpenCasesBean openCaseBean) throws RMDWebException;
	
	/*
	 * @param openCaseBean 
	 * @return List<OpenCasesVO> 
	 * @throws RMDWebException
	 * @Description: Method to call the function to fetch cases related to a
	 * user.
	 */
	public List<OpenCasesVO> getUserCases(final OpenCasesBean openCaseBean)
			throws RMDWebException, Exception;
	
	public String yankCase(OpenCasesBean openCaseBean) throws RMDWebException,Exception;

}