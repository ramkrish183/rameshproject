/**
 * ============================================================
 * File : CaseSolutionController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.cm.mvc.controller
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Oct 15, 2013
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.mvc.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ge.trans.rmd.cm.service.CaseSolutionService;
import com.ge.trans.rmd.cm.service.CreateCasesService;
import com.ge.trans.rmd.cm.valueobjects.CaseResponseVO;
import com.ge.trans.rmd.cm.valueobjects.CloseOutRepairCodeVO;
import com.ge.trans.rmd.cm.valueobjects.ReCloseVO;
import com.ge.trans.rmd.cm.valueobjects.RepairCodeVO;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.beans.CaseSolutionVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.valueobjects.RxDetailsVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.services.cases.valueobjects.ToolOutputResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class CaseSolutionController extends RMDBaseController {
    final private RMDWebLogger rmdWebLogger = RMDWebLogger.getLogger(getClass());

    @Autowired
    private CaseSolutionService caseSolutionService;
    @Autowired
    private AssetCasesController assetCasesController;
    @Autowired
    private CreateCasesService createCasesService;
    @Autowired
    private AuthorizationService authService;

    /**
     * @param request
     * @return String
     * @throws RMDWebException
     * @Description * This method is used for adding Rx to case
     */

    @RequestMapping(value = AppConstants.ADD_RX_TO_CASE)
    public @ResponseBody String addRXToCase(final HttpServletRequest request) throws RMDWebException {

        rmdWebLogger.debug("Inside CreateCasesController in addRXToCase Method");
        final CaseSolutionVO caseBeanAddRx = new CaseSolutionVO();
        String status = AppConstants.SUCCESS_FLAG;
        try {

            final HttpSession session = request.getSession(false);
            final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
            caseBeanAddRx.setSolutionId(request.getParameter(AppConstants.CREATCASE_SOLNID));
            caseBeanAddRx.setSolutionTitle(request.getParameter(AppConstants.ADDRX_SOLN_TITLE));
            caseBeanAddRx.setUserId(userVO.getUserId());
            caseBeanAddRx.setCaseId(request.getParameter(AppConstants.ADDRX_CASE_ID));
            caseSolutionService.addRXToCase(caseBeanAddRx);

        } catch (RMDWebException e) {
            if (AppConstants.EXCEPTION_EOA_3027.equals(e.getErrorCode())) {
                status = AppConstants.EXCEPTION_EOA_3027;
            } else {
                rmdWebLogger.error("Exception occured in addRXToCase() method ", e);
                RMDWebErrorHandler.handleException(e);
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in addRXToCase method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return status;

    }

    /**
     * @param request
     * @return string
     * @throws RMDWebException
     * @Description This method is used for delivering Rx
     */

    @RequestMapping(value = AppConstants.DELIVER_RX_TO_CASE, method = RequestMethod.POST)
    public @ResponseBody String deliverRXToCase(final HttpServletRequest request) throws RMDWebException {
        String status = AppConstants.SUCCESS_FLAG;
        rmdWebLogger.debug("Inside CreateCasesController in addRXToCase Method");
        final CaseSolutionVO caseBeanDeliverRx = new CaseSolutionVO();
        try {

            final HttpSession session = request.getSession(false);
            final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);

            if (RMDCommonUtility.isSpecialCharactersFound(request.getParameter(AppConstants.RMD_NOTES))) {
                status = AppConstants.SPECIAL_CHARACTER_FOUND;
            } else {
                caseBeanDeliverRx.setRxCaseId(request.getParameter(AppConstants.RX_CASE_ID));
                caseBeanDeliverRx.setSolutionId(request.getParameter(AppConstants.CREATCASE_SOLNID));
                caseBeanDeliverRx.setUrgency(request.getParameter(AppConstants.URGENCY));
                caseBeanDeliverRx.setEstRepairCode(request.getParameter(AppConstants.ESTIMATED_REPAIR));
                caseBeanDeliverRx.setUserId(userVO.getUserId());
                caseBeanDeliverRx.setCmAliasName(userVO.getCmAliasName());
                caseBeanDeliverRx.setCaseId(request.getParameter(AppConstants.ADDRX_CASE_ID));
                caseBeanDeliverRx.setNotes(request.getParameter(AppConstants.RMD_NOTES));
                caseBeanDeliverRx.setSolutionTitle(request.getParameter(AppConstants.ADDRX_SOLN_TITLE));
                caseBeanDeliverRx.setAction(request.getParameter(AppConstants.ACTION));
                caseSolutionService.deliverRXToCase(caseBeanDeliverRx);
            }
        } catch (RMDWebException e) {
            if (AppConstants.EXCEPTION_EOA_3031.equals(e.getErrorCode())) {
                status = AppConstants.EXCEPTION_EOA_3031;
            } else if (AppConstants.EXCEPTION_RMD_207.equals(e.getErrorCode())) {
                status = AppConstants.EXCEPTION_RMD_207;
            } else if (AppConstants.EXCEPTION_RMD_204.equals(e.getErrorCode())) {
                status = AppConstants.EXCEPTION_RMD_204;
            } else if (AppConstants.EXCEPTION_RMD_210.equals(e.getErrorCode())) {
                status = AppConstants.EXCEPTION_RMD_210;
            } else {
                rmdWebLogger.error("Exception occured in deliverRXToCase() method ", e);
                RMDWebErrorHandler.handleException(e);
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in deliverRXToCase method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return status;
    }

    /**
     * @param request
     * @return String
     * @throws RMDWebException
     * @Description * This method is used for close case
     */
    @RequestMapping(value = AppConstants.CLOSE_CASE)
    public @ResponseBody String closeCase(final HttpServletRequest request) throws RMDWebException {
        rmdWebLogger.debug("Inside CaseSolutionController in closeCase Method");
        final CaseSolutionVO caseBeanAddRx = new CaseSolutionVO();
        String status = null;
        final HttpSession session = request.getSession(false);
        List<CloseOutRepairCodeVO> attachedDetailsList = new ArrayList<CloseOutRepairCodeVO>();
        final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
        try {
            CaseBean objCaseBean = new CaseBean();
            objCaseBean = assetCasesController.getCaseCurrentOwnerDetails(request
                    .getParameter(AppConstants.ADDRX_CASE_ID));
            if (!objCaseBean.getCondition().equalsIgnoreCase(RMDCommonConstants.CLOSED)
                    && (null == objCaseBean.getQueueName()
                            || objCaseBean.getQueueName().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)
                            || objCaseBean.getQueueName().isEmpty() || objCaseBean.getQueueName().equalsIgnoreCase(
                            RMDCommonConstants.ZERO_STRING))) {
                if ((!objCaseBean.getOwner().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING) || objCaseBean
                        .getOwner() != null) && objCaseBean.getOwner().equalsIgnoreCase(userVO.getCmAliasName())) {
                    caseBeanAddRx.setUserId(userVO.getUserId());
                    if (null != request.getParameter(AppConstants.ADDRX_CASE_ID)) {
                        caseBeanAddRx.setCmAliasName(userVO.getCmAliasName());
                        caseBeanAddRx.setCaseId(request.getParameter(AppConstants.ADDRX_CASE_ID));
                    }
                    attachedDetailsList = assetCasesController.getAttachedDetails(request
                            .getParameter(AppConstants.ADDRX_CASE_ID));
                    if (RMDCommonUtility.isCollectionNotEmpty(attachedDetailsList)) {
                        if (AppConstants.TRUE_STRING
                                .equals(assetCasesController
                                        .getAddRepCodeDetails(request
                                                .getParameter(AppConstants.ADDRX_CASE_ID)))) {
                            status = caseSolutionService.closeCase(caseBeanAddRx);
                        } else {
                            status = AppConstants.REPAIR_CODE_REQUIRED;
                        }
                        
                    } else {
                        status = AppConstants.REPAIR_CODE_REQUIRED;
                    }
                } else {
                    status = RMDCommonConstants.NOT_CURRENT_OWNER;
                }
            }
        } catch (RMDWebException e) {

            RMDWebErrorHandler.handleException(e);

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in closeCase method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return status;
    }
    /**
     * @Author:
     * @param:feedback,feedbackcode
     * @return:boolean
     * @Description: This method is used for validating the input
     */
    public String inputValidation(String feedback, String feedbackcode) {
        String validationMessage = AppConstants.SUCCESS;
        if (null == feedback) {
            validationMessage = AppConstants.MANUAL_FEEDBACK_EMPTY_MSG;
        } else if (feedback.length() > AppConstants.TWO_THOUSAND) {
            validationMessage = AppConstants.MANUAL_FEEDBACK_MAXLIMIT;
        }
        if (null == feedbackcode || feedbackcode.equals(AppConstants.SELECT)) {
            validationMessage = AppConstants.MANUAL_FEEDBACK_CODE_ERRORMSG;
        }
        return validationMessage;
    }

    /**
     * @Author:
     * @param:request
     * @return:String
     * @throws RMDWebException
     * @Description: This method is used for saving the manual feedback
     */
    @RequestMapping(value = AppConstants.SAVE_MANUAL_FEEDBACK)
    public @ResponseBody String saveManualFeedback(final HttpServletRequest request) throws RMDWebException {
        rmdWebLogger.debug("Inside CaseSolutionController in save manual feedback Method");
        final CaseSolutionVO scoreRXandCloseCaseVO = new CaseSolutionVO();
        String responseMessage = null;
        String feedback = null;
        String feedbackcode = null;
        String rxNotes = null;
        String isReissue = null;
        String validationMessage;
        String repaircodeList = null;
        final HttpSession session = request.getSession(false);
        final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
        CaseBean objCaseBean = new CaseBean();
        objCaseBean = assetCasesController.getCaseCurrentOwnerDetails(request.getParameter(AppConstants.ADDRX_CASE_ID));
        List<CloseOutRepairCodeVO> attachedDetailsList = new ArrayList<CloseOutRepairCodeVO>();
        try {
            if (!objCaseBean.getCondition().equalsIgnoreCase(RMDCommonConstants.CLOSED)
                    && (null == objCaseBean.getQueueName()
                            || objCaseBean.getQueueName().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)
                            || objCaseBean.getQueueName().isEmpty() || objCaseBean.getQueueName().equalsIgnoreCase(
                            RMDCommonConstants.ZERO_STRING))) {
                if ((!objCaseBean.getOwner().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING) || objCaseBean
                        .getOwner() != null) && objCaseBean.getOwner().equalsIgnoreCase(userVO.getCmAliasName())) {
                    feedback = request.getParameter(AppConstants.RX_FEEDBACK);
                    feedbackcode = request.getParameter(AppConstants.RX_FEEDBACK_CODE);
                    rxNotes = request.getParameter(AppConstants.RX_NOTES);
                    isReissue = request.getParameter(AppConstants.RE_ISSUE);
                    validationMessage = inputValidation(feedback, feedbackcode);
                    repaircodeList = request.getParameter(AppConstants.REPAIRCODE_LIST);
                    if (validationMessage.equalsIgnoreCase(AppConstants.SUCCESS)) {
                        if (null != userVO.getCmAliasName()) {
                            scoreRXandCloseCaseVO.setUserAlias(userVO.getCmAliasName());
                        }
                        if (null != userVO.getUserId()) {
                            scoreRXandCloseCaseVO.setUserId(userVO.getUserId());
                        }
                        if (null != request.getParameter(AppConstants.CASE_ID)) {
                            scoreRXandCloseCaseVO.setCaseId(request.getParameter(AppConstants.CASE_ID));
                        }
                        if (null != request.getParameter(AppConstants.RX_CASE_ID)) {
                            scoreRXandCloseCaseVO.setRxCaseId(request.getParameter(AppConstants.RX_CASE_ID));
                        }
                        if (null != feedback) {
                            scoreRXandCloseCaseVO.setRxFeedBack(feedback);
                        }
                        if (null != rxNotes) {
                            scoreRXandCloseCaseVO.setNotes(rxNotes);
                        }
                        if (null != isReissue) {
                            scoreRXandCloseCaseVO.setIsReissue(isReissue);
                        }
                        if (null != repaircodeList) {
                            scoreRXandCloseCaseVO.setRepairCodeId(repaircodeList);
                        }
                        
                        if (null != feedbackcode) {
                            
                            String addRepLookUpResult = null;
                            String addRepCodeResult = null;
                            
                            scoreRXandCloseCaseVO.setRxFeedBackCode(feedbackcode);
                            
                            attachedDetailsList = assetCasesController.getAttachedDetails(request
                                    .getParameter(AppConstants.ADDRX_CASE_ID));
                            
                            if(RMDCommonUtility.isCollectionNotEmpty(attachedDetailsList)){
                                addRepCodeResult = assetCasesController
                                    .getAddRepCodeDetails(request
                                            .getParameter(AppConstants.ADDRX_CASE_ID));
                            }
                            
                            if (!RMDCommonUtility.isNullOrEmpty(repaircodeList)) {
                                addRepLookUpResult = assetCasesController
                                        .getLookUpRepCodeDetails(
                                                repaircodeList);
                            }
                            
                           
                            if (RMDCommonUtility.isNullOrEmpty(repaircodeList)) {
                                
                                if (RMDCommonUtility.isCollectionNotEmpty(attachedDetailsList)) {
                                    if (AppConstants.TRUE_STRING
                                            .equals(addRepCodeResult)) {
                                        responseMessage = caseSolutionService
                                                .saveManualFeedback(scoreRXandCloseCaseVO);
                                    } else {
                                        responseMessage = AppConstants.REPAIR_CODE_REQUIRED;
                                    }
                                    } else {
                                    responseMessage = AppConstants.REPAIR_CODE_REQUIRED;
                                }
                            }else {
                                  
                                if (AppConstants.TRUE_STRING.equals(addRepLookUpResult) || AppConstants.TRUE_STRING
                                        .equals(addRepCodeResult)) {
                                    responseMessage = caseSolutionService
                                            .saveManualFeedback(scoreRXandCloseCaseVO);
                                }  else if ( AppConstants.FALSE_STRING.equals(addRepLookUpResult) && AppConstants.TRUE_STRING
                                        .equals(addRepCodeResult)) {
                                    responseMessage = caseSolutionService
                                            .saveManualFeedback(scoreRXandCloseCaseVO);
                                } else if (AppConstants.TRUE_STRING.equals(addRepLookUpResult) && AppConstants.FALSE_STRING
                                        .equals(addRepCodeResult)) {
                                    responseMessage = caseSolutionService
                                            .saveManualFeedback(scoreRXandCloseCaseVO);
                                }
                                else {
                                    responseMessage = AppConstants.REPAIR_CODE_REQUIRED;
                                }
                             }
                        }
                } else {
                        responseMessage = validationMessage;
                    }
                } else {
                    responseMessage = RMDCommonConstants.NOT_CURRENT_OWNER;
                }
            } else {
                responseMessage = RMDCommonConstants.NOT_CURRENT_OWNER;
            }
        } catch (RMDWebException e) {

            if (AppConstants.EXCEPTION_RMD_211.equalsIgnoreCase(e.getErrorCode())) {
                responseMessage = AppConstants.EXCEPTION_RMD_211;
            } else if (AppConstants.EXCEPTION_RMD_212.equalsIgnoreCase(e.getErrorCode())) {
                responseMessage = AppConstants.EXCEPTION_RMD_212;
            } else {
                rmdWebLogger.error("Exception occured in deliverRXToCase() method ", e);
                RMDWebErrorHandler.handleException(e);
            }

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in Manual Feedback method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return responseMessage;

    }

    /**
     * @param request
     * @return String
     * @throws RMDWebException
     * @Description * This method is used for score rx and close case
     */
    @RequestMapping(value = AppConstants.SCORERX_CLOSE_CASE, method = RequestMethod.POST)
    public @ResponseBody Map<String, String> scoreRxAndCloseCase(final HttpServletRequest request)
            throws RMDWebException {
        rmdWebLogger.debug("Inside CaseSolutionController in scoreRxAndCloseCase Method");
        final CaseSolutionVO scoreRXandCloseCaseVO = new CaseSolutionVO();
        String isScoreFlag = null;
        Map<String, String> responseMessage = new HashMap<String, String>();
        final HttpSession session = request.getSession(false);
        String technicianFlag=request.getParameter(AppConstants.TECHNICIAN_FLAG);
        boolean ownerFlag=false;
        boolean technicianScoreFlag=false;
        final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
        CaseBean objCaseBean = new CaseBean();
        objCaseBean = assetCasesController.getCaseCurrentOwnerDetails(request.getParameter(AppConstants.ADDRX_CASE_ID));
        List<CloseOutRepairCodeVO> attachedDetailsList = new ArrayList<CloseOutRepairCodeVO>();
        String repairCode = null;
        String repairCodeID = null;
        String allRepairCodeID = null;
        String addRepLookUpResult = null;
        String addRepCodeResult = null;
        
        try {
        	
        	if(AppConstants.TRUE_STRING.equals(technicianFlag))
        	{
        		ownerFlag=true;
        		technicianScoreFlag=true;
        	}else{
        		ownerFlag=objCaseBean.getOwner().equalsIgnoreCase(userVO.getCmAliasName());
        	}
            if (!objCaseBean.getCondition().equalsIgnoreCase(RMDCommonConstants.CLOSED)
                    && (null == objCaseBean.getQueueName()
                            || objCaseBean.getQueueName().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)	
                            || objCaseBean.getQueueName().isEmpty() || objCaseBean.getQueueName().equalsIgnoreCase(
                            RMDCommonConstants.ZERO_STRING))||ownerFlag) {
            	
                if ((!objCaseBean.getOwner().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING) || objCaseBean
                        .getOwner() != null) && ownerFlag) {
                    if (null != request.getParameter(AppConstants.FLAG)) {
                        isScoreFlag = request.getParameter(EsapiUtil.stripXSSCharacters(AppConstants.FLAG));
                    }
                    if (null != request.getParameter(AppConstants.RX_CASE_ID)) {
                        scoreRXandCloseCaseVO.setRxCaseId(request.getParameter(EsapiUtil.stripXSSCharacters(AppConstants.RX_CASE_ID)));
                    }
                    if (null != request.getParameter(AppConstants.RX_FEEDBACK)) {
                        scoreRXandCloseCaseVO.setRxFeedBack(
                                request.getParameter(AppConstants.RX_FEEDBACK));
                    }
                    if (null != request.getParameter(AppConstants.RX_FEEDBACK_CODE)) {
                        scoreRXandCloseCaseVO.setRxFeedBackCode(request.getParameter(EsapiUtil.stripXSSCharacters(AppConstants.RX_FEEDBACK_CODE)));
                    }
                    if (null != request.getParameter(AppConstants.ADDRX_CASE_ID)) {
                        scoreRXandCloseCaseVO.setCaseId(request.getParameter(EsapiUtil.stripXSSCharacters(AppConstants.ADDRX_CASE_ID)));
                    }
                    scoreRXandCloseCaseVO.setUserId(userVO.getUserId());
                    scoreRXandCloseCaseVO.setCmAliasName(userVO.getCmAliasName());
                    allRepairCodeID = request.getParameter(EsapiUtil.stripXSSCharacters(AppConstants.REPAIRCODE_LIST));
                    if(!technicianScoreFlag){
                    if (scoreRXandCloseCaseVO.getRxFeedBackCode().equalsIgnoreCase(AppConstants.MISS4F)) {
                        repairCode = caseSolutionService.getRepairCodeMiss4F();
                        repairCodeID = caseSolutionService.getRepairCodesID(repairCode);
                        allRepairCodeID = allRepairCodeID + repairCodeID + AppConstants.COMMA;
                    }
                    if (scoreRXandCloseCaseVO.getRxFeedBackCode().equalsIgnoreCase(AppConstants.MISS4B)) {
                        repairCode = caseSolutionService.getRepairCodeMiss4B();
                        repairCodeID = caseSolutionService.getRepairCodesID(repairCode);
                        allRepairCodeID = allRepairCodeID + repairCodeID + AppConstants.COMMA;
                    }
                    }else{
                    	if (scoreRXandCloseCaseVO.getRxFeedBackCode().equalsIgnoreCase(AppConstants.MISS4A))
                    	{
                    		allRepairCodeID=allRepairCodeID+request.getParameter(EsapiUtil.stripXSSCharacters(AppConstants.REPAIRCODE_ID))+AppConstants.COMMA;
                    	}
                    	if (scoreRXandCloseCaseVO.getRxFeedBackCode().equalsIgnoreCase(AppConstants.MISS4B))
                    	{
                    		allRepairCodeID=allRepairCodeID+request.getParameter(EsapiUtil.stripXSSCharacters(AppConstants.REPAIRCODE_ID))+AppConstants.COMMA;
                    	}
                    	if (scoreRXandCloseCaseVO.getRxFeedBackCode().equalsIgnoreCase(AppConstants.MISS4F))
                    	{
                    		allRepairCodeID=allRepairCodeID+request.getParameter(EsapiUtil.stripXSSCharacters(AppConstants.REPAIRCODE_ID))+AppConstants.COMMA;
                    	}
                    }
                    scoreRXandCloseCaseVO.setRepairCodeId(allRepairCodeID);
                    scoreRXandCloseCaseVO
                            .setRxNote(EsapiUtil.resumeSpecialChars(request.getParameter(AppConstants.RX_NOTE)));
                    scoreRXandCloseCaseVO.setFdbkType(request.getParameter(AppConstants.FDBK_TYPE));
                    
                    attachedDetailsList = assetCasesController.getAttachedDetails(request
                            .getParameter(AppConstants.ADDRX_CASE_ID));
                    
                    if(RMDCommonUtility.isCollectionNotEmpty(attachedDetailsList)){
                        addRepCodeResult = assetCasesController
                            .getAddRepCodeDetails(request
                                    .getParameter(AppConstants.ADDRX_CASE_ID));
                    }
                    
                    if (!RMDCommonUtility.isNullOrEmpty(scoreRXandCloseCaseVO.getRepairCodeId())) {
                        addRepLookUpResult = assetCasesController
                                .getLookUpRepCodeDetails(
                                        scoreRXandCloseCaseVO.getRepairCodeId());
                    }
                    
                   
                    if (RMDCommonUtility.isNullOrEmpty(scoreRXandCloseCaseVO.getRepairCodeId())) {
                        
                        if (RMDCommonUtility.isCollectionNotEmpty(attachedDetailsList)) {
                            if (AppConstants.TRUE_STRING
                                    .equals(addRepCodeResult)) {
                                responseMessage = caseSolutionService.scoreRxAndCloseCase(scoreRXandCloseCaseVO,
                                        isScoreFlag);
                            } else {
                                responseMessage.put(AppConstants.REPAIR_CODE_REQUIRED, AppConstants.REPAIR_CODE_REQUIRED);
                            }
                            } else {
                                responseMessage.put(AppConstants.REPAIR_CODE_REQUIRED, AppConstants.REPAIR_CODE_REQUIRED);
                        }
                    }else {
                          
                        if (AppConstants.TRUE_STRING.equals(addRepLookUpResult) || AppConstants.TRUE_STRING
                                .equals(addRepCodeResult)) {
                            responseMessage = caseSolutionService.scoreRxAndCloseCase(scoreRXandCloseCaseVO,
                                    isScoreFlag);
                        }  else if ( AppConstants.FALSE_STRING.equals(addRepLookUpResult) && AppConstants.TRUE_STRING
                                .equals(addRepCodeResult)) {
                            responseMessage = caseSolutionService.scoreRxAndCloseCase(scoreRXandCloseCaseVO,
                                    isScoreFlag);
                        } else if (AppConstants.TRUE_STRING.equals(addRepLookUpResult) && AppConstants.FALSE_STRING
                                .equals(addRepCodeResult)) {
                            responseMessage = caseSolutionService.scoreRxAndCloseCase(scoreRXandCloseCaseVO,
                                    isScoreFlag);
                        }
                        else {
                            responseMessage.put(AppConstants.REPAIR_CODE_REQUIRED, AppConstants.REPAIR_CODE_REQUIRED);
                        }
                     }
                    
                    
                } else {
                    responseMessage.put(RMDCommonConstants.NOT_CURRENT_OWNER, RMDCommonConstants.NOT_CURRENT_OWNER);
                }
            } else {
                responseMessage.put(RMDCommonConstants.NOT_CURRENT_OWNER, RMDCommonConstants.NOT_CURRENT_OWNER);
            }
        } catch (RMDWebException e) {
            RMDWebErrorHandler.handleException(e);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in scoreRxAndCloseCase method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return responseMessage;
    }

    /**
     * @throws RMDWebException
     *             This is the method used for get the look up for score RX
     * @return Map<String, String>
     * @throws
     */
    @RequestMapping(value = AppConstants.GET_SCORING_LOOKUP)
    public @ResponseBody Map<String, String> getlookupForRxScoring(HttpServletRequest request) throws RMDWebException {

        rmdWebLogger.debug("Inside CaseSolutionController in getlookupForRxScoring Method");
        Map<String, String> scoringCodes = new HashMap<String, String>();
        try {
            scoringCodes = caseSolutionService.getlookupForRxScoring();

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getlookupForRxScoring method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return scoringCodes;
    }

    /**
     * @throws RMDWebException
     *             This is the method used for get Close out Repair Codes
     * @return List<CaseSolutionVO>
     * @throws RMDWebException
     */
    @RequestMapping(value = AppConstants.GET_CLOSE_OUT_REPAIR_CODE)
    public @ResponseBody List<CaseSolutionVO> getCloseOutRepairCodes(
            @RequestParam(value = AppConstants.RECOM_ID, required = true) final String recomid,
            final HttpServletRequest request) throws RMDWebException {
        rmdWebLogger.debug("Inside CaseSolutionController in getCloseOutRepairCodes Method");
        List<CaseSolutionVO> repairCodeList = null;
        try {
            repairCodeList = caseSolutionService.getCloseOutRepairCodes(EsapiUtil.stripXSSCharacters(recomid));
        } catch (RMDWebException e) {
            RMDWebErrorHandler.handleException(e);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getCloseOutRepairCodes  method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return repairCodeList;
    }

    /**
     * @throws RMDWebException
     *             This is the method used for get case Repair Codes
     * @return List<CaseSolutionVO>
     * @throws RMDWebException
     */
    @RequestMapping(value = AppConstants.GET_CASE_REPAIR_CODE)
    public @ResponseBody List<CaseSolutionVO> getCaseRepairCodes(
            @RequestParam(value = AppConstants.CASE_ID, required = true) final String caseId) throws RMDWebException {

        rmdWebLogger.debug("Inside CaseSolutionController in getCaseRepairCodes Method");
        List<CaseSolutionVO> repairCodeList = null;
        try {
            repairCodeList = caseSolutionService.getCaseRepairCodes(EsapiUtil.stripXSSCharacters(caseId));

        } catch (RMDWebException e) {

            RMDWebErrorHandler.handleException(e);

        } catch (Exception ex) {
            rmdWebLogger.error(AppConstants.EXCEPTION_IN_GETCASEREPAIRCODES, ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return repairCodeList;

    }

    /**
     * @throws RMDWebException
     *             This is the method used for add Repair Codes
     * @return List<CaseSolutionVO>
     * @throws RMDWebException
     */
    @RequestMapping(value = AppConstants.ADD_CASE_REPAIR_CODE)
    public @ResponseBody String addRepairCodes(
            @RequestParam(value = AppConstants.CASE_ID, required = true) final String caseId,
            @RequestParam(value = AppConstants.REPAIRCODE_LIST) final String strRepairCodeList,
            final HttpServletRequest request) throws RMDWebException {
        rmdWebLogger.debug("Inside CaseSolutionController in addRepairCodes Method");
        CaseSolutionVO caseRepairCodes = new CaseSolutionVO();
        final HttpSession session = request.getSession(false);
        final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
        try {
            CaseBean objCaseBean = new CaseBean();
            objCaseBean = assetCasesController.getCaseCurrentOwnerDetails(caseId);
            if (!objCaseBean.getCondition().equalsIgnoreCase(RMDCommonConstants.CLOSED)
                    && (null == objCaseBean.getQueueName()
                            || objCaseBean.getQueueName().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)
                            || objCaseBean.getQueueName().isEmpty() || objCaseBean.getQueueName().equalsIgnoreCase(
                            RMDCommonConstants.ZERO_STRING))) {
                if ((!objCaseBean.getOwner().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING) || objCaseBean
                        .getOwner() != null) && objCaseBean.getOwner().equalsIgnoreCase(userVO.getCmAliasName())) {
                    caseRepairCodes.setCaseId(caseId);
                    if (null != strRepairCodeList && !strRepairCodeList.isEmpty()) {
                        caseRepairCodes.setRepairCodeId(strRepairCodeList);
                        caseRepairCodes.setUserId(userVO.getUserId());
                        caseSolutionService.addRepairCodes(caseRepairCodes);
                    } else {
                        return AppConstants.REPAIRCODE_LIST;
                    }
                } else {
                    return RMDCommonConstants.NOT_CURRENT_OWNER;
                }
            } else {
                return RMDCommonConstants.NOT_CURRENT_OWNER;
            }
        } catch (RMDWebException e) {
            rmdWebLogger.error(e);
            return AppConstants.FAILURE;

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in addRepairCodes  method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return AppConstants.SUCCESS;
    }

    /**
     * @throws RMDWebException
     *             This is the method used for add Repair Codes
     * @return String
     * @throws RMDWebException
     */
    @RequestMapping(value = AppConstants.REMOVE_CASE_REPAIR_CODE)
    public @ResponseBody String removeRepairCodes(
            @RequestParam(value = AppConstants.CASE_ID, required = true) final String caseId,
            @RequestParam(value = AppConstants.REPAIRCODE_LIST) final String strRepairCodeList,
            HttpServletRequest request) throws RMDWebException {
        rmdWebLogger.debug("Inside CaseSolutionController in removeRepairCodes Method");
        CaseSolutionVO caseRepairCodes = new CaseSolutionVO();
        final HttpSession session = request.getSession(false);
        final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
        try {
            CaseBean objCaseBean = new CaseBean();
            objCaseBean = assetCasesController.getCaseCurrentOwnerDetails(caseId);
            if (!objCaseBean.getCondition().equalsIgnoreCase(RMDCommonConstants.CLOSED)
                    && (null == objCaseBean.getQueueName()
                            || objCaseBean.getQueueName().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)
                            || objCaseBean.getQueueName().isEmpty() || objCaseBean.getQueueName().equalsIgnoreCase(
                            RMDCommonConstants.ZERO_STRING))) {
                if ((!objCaseBean.getOwner().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING) || objCaseBean
                        .getOwner() != null) && objCaseBean.getOwner().equalsIgnoreCase(userVO.getCmAliasName())) {
                    caseRepairCodes.setCaseId(caseId);
                    if (null != strRepairCodeList && !strRepairCodeList.isEmpty()) {
                        caseRepairCodes.setRepairCodeId(strRepairCodeList);
                    } else {
                        return AppConstants.REPAIRCODE_LIST;
                    }
                    caseSolutionService.removeRepairCodes(caseRepairCodes);
                } else {
                    return RMDCommonConstants.NOT_CURRENT_OWNER;
                }
            } else {
                return RMDCommonConstants.NOT_CURRENT_OWNER;
            }
        } catch (RMDWebException e) {
            rmdWebLogger.error(e);
            return AppConstants.FAILURE;
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in removeRepairCodes  method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return AppConstants.SUCCESS;
    }

    /**
     * @throws RMDWebException
     *             This is the method used for get case Repair Codes
     * @return Map<String, String>
     * @throws RMDWebException
     */
    @RequestMapping(value = AppConstants.GET_REPAIR_CODE, method = RequestMethod.POST)
    public @ResponseBody Map<String, String> getRepairCodes(final HttpServletRequest request) throws RMDWebException {
        CaseSolutionVO getRepairCodeInputs = new CaseSolutionVO();
        rmdWebLogger.debug("Inside CaseSolutionController in getCaseRepairCodes Method");
        Map<String, String> repairCode = new LinkedHashMap<String, String>();
        try {
            if (null != EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MODEL))
                    && !EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MODEL)).isEmpty()) {
                getRepairCodeInputs.setModel(EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MODEL)));
                repairCode = caseSolutionService.getRepairCodes(getRepairCodeInputs);
            }
        } catch (RMDWebException e) {
            RMDWebErrorHandler.handleException(e);
        } catch (Exception ex) {
            rmdWebLogger.error(AppConstants.EXCEPTION_IN_GETCASEREPAIRCODES, ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return repairCode;
    }

    /**
     * @throws RMDWebException
     *             This is the method used for get select by values
     * @return List<String>
     * @throws RMDWebException
     */
    @RequestMapping(value = AppConstants.GET_SELECT_BY_LOOKUP)
    public @ResponseBody List<String> getlookupForSelectBy() throws RMDWebException {
        rmdWebLogger.debug("Inside CaseSolutionController in getlookupForSelectBy Method");
        List<String> selectByList = null;
        try {
            selectByList = caseSolutionService.getlookupForSelectBy();
        } catch (RMDWebException e) {
            RMDWebErrorHandler.handleException(e);
        } catch (Exception ex) {
            rmdWebLogger.error(AppConstants.EXCEPTION_IN_GETCASEREPAIRCODES, ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return selectByList;
    }

    /**
     * @param request
     * @return
     */
    private String isValidRepairCodeInput(HttpServletRequest request) {
        if (null == request.getParameter(AppConstants.VALUE)
                || AppConstants.EMPTY_STRING.equals(request.getParameter(AppConstants.VALUE))) {
            return AppConstants.VALUE;
        }
        if (RMDCommonUtility.isSpecialCharactersFound(request.getParameter(AppConstants.VALUE))) {
            return AppConstants.INVALID_SPECIAL_CHARACTER;
        }
        return AppConstants.TRUE_STRING;
    }

    /**
     * @throws RMDWebException
     *             This is the method used for add Repair Codes and Close the case.
     * @return String
     * @throws RMDWebException
     */
    @RequestMapping(value = AppConstants.ADD_AND_CLOSE)
    public @ResponseBody String addAndClose(
            @RequestParam(value = AppConstants.CASE_ID, required = true) final String caseId,
            @RequestParam(value = AppConstants.REPAIRCODE_LIST) final String strRepairCodeList,
            HttpServletRequest request) throws RMDWebException {
        rmdWebLogger.debug("Inside CaseSolutionController in addAndClose Method");
        CaseSolutionVO caseRepairCodes = new CaseSolutionVO();
        try {
            final HttpSession session = request.getSession(false);
            final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
            CaseBean objCaseBean = new CaseBean();
            objCaseBean = assetCasesController.getCaseCurrentOwnerDetails(caseId);
            if (!objCaseBean.getCondition().equalsIgnoreCase(RMDCommonConstants.CLOSED)
                    && (null == objCaseBean.getQueueName()
                            || objCaseBean.getQueueName().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)
                            || objCaseBean.getQueueName().isEmpty() || objCaseBean.getQueueName().equalsIgnoreCase(
                            RMDCommonConstants.ZERO_STRING))) {
                if ((!objCaseBean.getOwner().equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING) || objCaseBean
                        .getOwner() != null) && objCaseBean.getOwner().equalsIgnoreCase(userVO.getCmAliasName())) {
                    caseRepairCodes.setCaseId(caseId);
                    caseRepairCodes.setCmAliasName(userVO.getCmAliasName());
                    caseRepairCodes.setUserId(userVO.getUserId());
                    if (null != strRepairCodeList && !strRepairCodeList.isEmpty()) {
                        caseRepairCodes.setRepairCodeId(strRepairCodeList);
                    } else {
                        return AppConstants.REPAIRCODE_LIST;
                    }
                    caseSolutionService.addAndClose(caseRepairCodes);
                } else {
                    return RMDCommonConstants.NOT_CURRENT_OWNER;
                }
            } else {
                return RMDCommonConstants.NOT_CURRENT_OWNER;
            }
        } catch (RMDWebException e) {
            rmdWebLogger.error(e);
            return AppConstants.FAILURE;

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in addAndClose  method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return AppConstants.SUCCESS;
    }

    @RequestMapping(value = AppConstants.GET_OPEN_FL_COUNT)
    public @ResponseBody int getOpenFLCount(
            @RequestParam(value = AppConstants.CASE_ID, required = true) final String caseId,
            final HttpServletRequest request) throws RMDWebException {
        rmdWebLogger.debug("Inside CaseSolutionController in getOpenFLCount Method");
        int openFlCount = 0;
        try {
            String lmsLocoId = caseSolutionService.getLmsLocoID(caseId);
            if (!RMDCommonUtility.isNullOrEmpty(lmsLocoId)) {
                openFlCount = caseSolutionService.getOpenFLCount(lmsLocoId);
            }

        } catch (RMDWebException e) {

            RMDWebErrorHandler.handleException(e);

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getOpenFLCount  method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return openFlCount;
    }
    @RequestMapping(value = AppConstants.GET_TOOL_OUTPUT)
    public @ResponseBody List<ToolOutputResponseType> getToolOutputDetails(HttpServletRequest request)
            throws RMDWebException {
        rmdWebLogger.info("Inside CaseSolutionController in getToolOutputDetails Method");
        List<ToolOutputResponseType> tooloutputResType = null;
        try {
            String caseId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CASE_ID));
            final HttpSession session = request.getSession(false);
            final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
            rmdWebLogger.info("case" + caseId);

            if (caseId != null) {
                tooloutputResType = caseSolutionService.getToolOutputDetails(caseId,
                        EsapiUtil.stripXSSCharacters(userVO.getTimeZone()));
                rmdWebLogger.info("tooloutputResType" + tooloutputResType);

            }
        } catch (RMDWebException e) {

            RMDWebErrorHandler.handleException(e);

        } catch (Exception ex) {
            rmdWebLogger.error(AppConstants.EXCEPTION_IN_GETTOOLOUTPUTDETAILS, ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return tooloutputResType;
    }

    /**
     * @Author:
     * @param :
     * @return:List<ViewLogVO>
     * @throws:RMDWebException
     * @Description:This Method is used for creating cases
     */

    @RequestMapping(value = AppConstants.TOOLOUTPUT_CREATE_CASE)
    public @ResponseBody String createToolOuptut(final HttpServletRequest request) throws RMDWebException {

        final HttpSession session = request.getSession();
        final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
        final CaseBean caseBean = new CaseBean();
        String newCaseId = null;

        try {
            final String currCaseId = request.getParameter(AppConstants.CASE_ID);
            final String strAssetId = request.getParameter(AppConstants.ASSET_NUMBER);
            final String strCustomerId = request.getParameter(AppConstants.CUSTOMER_ID);
            final String strGrpName = request.getParameter(AppConstants.ASSET_GROUP_NAME);

            if (RMDCommonUtility.isNullOrEmpty(currCaseId)) {
                caseBean.setUserFirstName(userVO.getStrFirstName());
                caseBean.setUserLastName(userVO.getStrLastName());
                caseBean.setUserId(userVO.getUserId());
                caseBean.setUserLanguage(userVO.getStrUserLanguage());
                caseBean.setCustomerId(strCustomerId);
                caseBean.setAssetGrpName(strGrpName);
                caseBean.setCustomerName(strCustomerId);
                caseBean.setRequestfromToolOutput(true);
                caseBean.setAssetNumber(strAssetId);
                newCaseId = createCasesService.createCases(caseBean);
            }

        } catch (RMDWebException e) {

            RMDWebErrorHandler.handleException(e);

        } catch (Exception ex) {
            rmdWebLogger.error(AppConstants.EXCEPTION_IN_GETTOOLOUTPUTDETAILS, ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return newCaseId;
    }
    /**
     * @Author:
     * @param :
     * @return:List<ViewLogVO>
     * @throws:RMDWebException
     * @Description:This Method is used for closing Rx from tooloutput
     */

    @RequestMapping(value = AppConstants.TOOLOUTPUT_CLOSE_CASE)
    public @ResponseBody List<ToolOutputResponseType> closeToolOutput(final HttpServletRequest request)
            throws RMDWebException {

        final HttpSession session = request.getSession();
        final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
        final CaseBean caseBean = new CaseBean();
        String newCaseId = null;
        String repairCode = null;
        String caseTitle = null;
        List<ToolOutputResponseType> toolResponseList = new ArrayList<ToolOutputResponseType>();
        ToolOutputResponseType toolResponse = new ToolOutputResponseType();
        ArrayList<String> rxList = null;
        ArrayList<String> fcList = null;
        try {
            final String currCaseId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CASE_ID));
            final String assetNumber = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_NUMBER));
            final String strCustomerId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CUSTOMER_ID));
            final String assetGrpName = EsapiUtil.stripXSSCharacters(request
                    .getParameter(AppConstants.ASSET_GROUP_NAME));
            final String[] rxListForClose = request.getParameterValues(AppConstants.RX_LIST_FOR_CLOSE);
            final String[] fcListForClose = request.getParameterValues(AppConstants.FC_LIST_FOR_CLOSE);

            final String ruleDefId = request.getParameter(AppConstants.RULE_DEFINITION_ID);
            final String toolId = request.getParameter(AppConstants.TOOL_ID);

            final String isRxDelv = request.getParameter(AppConstants.IS_RX_DELIVERY);

            final String closeReason = request.getParameter(AppConstants.CLOSE_REASON);

            rxList = new ArrayList<String>(Arrays.asList(rxListForClose));
            fcList = new ArrayList<String>(Arrays.asList(fcListForClose));

            if (closeReason != null && closeReason.equals(AppConstants.EMPTY_STRING)) {

                rmdWebLogger.info("Reason for Closing NULL");
                throw new RMDWebException();

            }
            rmdWebLogger.info("currCaseId " + currCaseId);
            rmdWebLogger.info("strCustomerId " + strCustomerId);
            rmdWebLogger.info("assetGrpName  " + assetGrpName);
            rmdWebLogger.info("rxListForClose" + rxListForClose);
            rmdWebLogger.info("fcListForClose " + fcListForClose);
            rmdWebLogger.info("ruleDefId " + ruleDefId);
            rmdWebLogger.info("toolId " + toolId);
            rmdWebLogger.info("closeReason " + closeReason);

            // Creating a new case for Each Rx OR FC
            if (rxList != null || fcList != null) {
                if (currCaseId == null) {
                    rmdWebLogger.info("Current Case Id is null");
                    throw new RMDWebException();
                }

                caseBean.setUserFirstName(userVO.getStrFirstName());
                caseBean.setUserLastName(userVO.getStrLastName());
                caseBean.setUserId(userVO.getUserId());
                caseBean.setUserLanguage(userVO.getStrUserLanguage());
                caseBean.setCustomerId(strCustomerId);
                caseBean.setAssetGrpName(assetGrpName);
                caseBean.setAssetNumber(assetNumber);
                caseBean.setCustomerName(strCustomerId);
                caseBean.setRequestfromToolOutput(true);

                // Fetch Current case attributes for setting in new Case

                caseTitle = caseSolutionService.getCaseTitle(currCaseId);
                caseBean.setCaseTitle(caseTitle);

                rmdWebLogger.info("Case Title: " + caseTitle);

                // fetch case type-pending
                // Create a new case for each Rx and add the new case id & Title to toolResponseVO
                for (String rxId : rxList) {
                    newCaseId = createCasesService.createCases(caseBean);
                    rmdWebLogger.info("New Case created: " + newCaseId);
                    toolResponse.setSolutionID(newCaseId);
                    toolResponse.setSolutionTitle(caseTitle);
                    toolResponseList.add(toolResponse);

                    // Create Case and Move Rx from old case to new case
                    caseBean.setRxObjId(Long.parseLong(rxId));
                    caseBean.setAppendToCaseId(currCaseId);
                    caseBean.setCaseId(newCaseId);
                    caseBean.setRuleDefId(ruleDefId);
                    caseBean.setToolId(toolId);
                    caseSolutionService.moveToolOutput(caseBean);

                    // Attach repair code to new case
                    rmdWebLogger.info("Adding Reapir Codes....");
                    CaseSolutionVO caseRepairCodes = new CaseSolutionVO();
                    caseRepairCodes.setCaseId(newCaseId);
                    if (closeReason != null && closeReason.equalsIgnoreCase(AppConstants.NO_SUPP_DATA))
                        caseRepairCodes.setRepairCodeId(AppConstants.NO_SUPP_DATA_CODE);
                    else if (closeReason != null && closeReason.equalsIgnoreCase(AppConstants.IN_SHOP))
                        caseRepairCodes.setRepairCodeId(AppConstants.IN_SHOP_CODE);
                    caseRepairCodes.setUserId(userVO.getUserId());
                    caseSolutionService.addRepairCodes(caseRepairCodes);
                    rmdWebLogger.info("Added Reapir Codes....");

                    // Close new case
                    rmdWebLogger.info("Closing new case: " + newCaseId);
                    final CaseSolutionVO caseBeanCloseRx = new CaseSolutionVO();
                    String status = null;
                    CaseBean objCaseBean = new CaseBean();
                    caseBeanCloseRx.setUserId(userVO.getUserId());
                    if (null != request.getParameter(AppConstants.ADDRX_CASE_ID)) {
                        caseBeanCloseRx.setCmAliasName(userVO.getCmAliasName());
                        caseBeanCloseRx.setCaseId(newCaseId);
                    }
                    status = caseSolutionService.closeCase(caseBeanCloseRx);
                    rmdWebLogger.info("Closed Case:" + status);
                }

            }

        } catch (RMDWebException e) {

            RMDWebErrorHandler.handleException(e);

        } catch (Exception ex) {
            rmdWebLogger.error(AppConstants.EXCEPTION_IN_GETTOOLOUTPUTDETAILS, ex);
            RMDWebErrorHandler.handleException(ex);

        }
        return toolResponseList;
    }

    /**
     * @Author:
     * @param :
     * @return:List<ViewLogVO>
     * @throws:RMDWebException
     * @Description:This Method is used for closing Rx from tooloutput
     */

    @RequestMapping(value = AppConstants.GET_TO_COLOR_CODING_VALUES)
    public @ResponseBody Map<String, Float> getTOColorCodingValues(final HttpServletRequest request)
            throws RMDWebException {
        rmdWebLogger.info("CaseSolutionController : Inside getTOColorCodingValues() method:::::START ");
        Map<String, Float> mapValues = new HashMap<String, Float>();
        try {
            float ToolProbGreen = RMDCommonUtility.getFloatValue(authService.getLookUpValueForName("ToolProbGreen"));
            float ToolProbYellow = RMDCommonUtility.getFloatValue(authService.getLookUpValueForName("ToolProbYellow"));

            float ToolFalseAlarmYellow = RMDCommonUtility.getFloatValue(authService
                    .getLookUpValueForName("ToolFalseAlarmYellow"));
            float ToolFalseAlarmGreen = RMDCommonUtility.getFloatValue(authService
                    .getLookUpValueForName("ToolFalseAlarmGreen"));

            float ToolCoverageGreen = RMDCommonUtility.getFloatValue(authService
                    .getLookUpValueForName("ToolCoverageGreen"));
            float ToolCoverageYellow = RMDCommonUtility.getFloatValue(authService
                    .getLookUpValueForName("ToolCoverageYellow"));

            float MDSCPerformanceGreen = RMDCommonUtility.getFloatValue(authService
                    .getLookUpValueForName("MDSCPerformanceGreen"));
            float MDSCPerformanceYellow = RMDCommonUtility.getFloatValue(authService
                    .getLookUpValueForName("MDSCPerformanceYellow"));
            mapValues.put(AppConstants.ToolProbGreen, ToolProbGreen);
            mapValues.put(AppConstants.ToolProbYellow, ToolProbYellow);
            mapValues.put(AppConstants.ToolFalseAlarmYellow, ToolFalseAlarmYellow);
            mapValues.put(AppConstants.ToolFalseAlarmGreen, ToolFalseAlarmGreen);
            mapValues.put(AppConstants.ToolCoverageGreen, ToolCoverageGreen);
            mapValues.put(AppConstants.ToolCoverageYellow, ToolCoverageYellow);
            mapValues.put(AppConstants.MDSCPerformanceGreen, MDSCPerformanceGreen);
            mapValues.put(AppConstants.MDSCPerformanceYellow, MDSCPerformanceYellow);

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getTOColorCodingValues method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }

        rmdWebLogger.info("CaseSolutionController : Inside getTOColorCodingValues() method:::::End ");
        return mapValues;
    }
    /**
     * This method is used to send the Rx list to enable and disable the deliver radio button
     **/
    @RequestMapping(value = AppConstants.ENABLED_UNIT_DELIVER_RX)
    public @ResponseBody Map<String, List<String>> getEnabledUnitRxsDeliver(final HttpServletRequest request) throws RMDWebException,
            Exception {
        rmdWebLogger.info("CaseSolutionController : Inside getEnabledUnitRxsDeliver() method:::::START ");
        Map<String, List<String>> resultMap=null;
        String currentUser = RMDCommonConstants.NOT_A_CM_USER;
        try {
            final String caseId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CASE_ID));
            final String assetNumber = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_NUMBER));
            final String customerId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CUSTOMER_ID));
            final String assetGroupName = EsapiUtil.stripXSSCharacters(request
                    .getParameter(AppConstants.ASSET_GROUP_NAME));
            final String caseType = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CASE_TYPE));
            final HttpSession session = request.getSession(false);
            final UserVO userVO = (UserVO) session
                    .getAttribute(AppConstants.ATTR_USER_OBJECT);
            if(userVO.getIsCMPrivilege()){
                currentUser=userVO.getCmAliasName();
            }
            resultMap = caseSolutionService.getEnabledUnitRxsDeliver(customerId, assetGroupName, assetNumber,
                    caseId, caseType,currentUser);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getEnabledUnitRxsDeliver method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }

        return resultMap;
    }

    /**
     * @Author:
     * @param:HttpServletRequest
     * @return:List<RepairCodeVO>
     * @throws RMDWebException
     * @Description: This method used for fetching false alarm details in data screen.
     */
    @RequestMapping(value = AppConstants.FALSE_ALARM_DETAILS)
    public @ResponseBody List<RepairCodeVO> getFalseAlarmDetails(final HttpServletRequest request)
            throws RMDWebException {
        rmdWebLogger.debug("CaseSolutionController : getFalseAlarmDetails() method Starts");
        final String rxObjId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.RX_OBJ_ID));
        List<RepairCodeVO> falseAlarmList = null;
        try {
            if (null != rxObjId && !RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(rxObjId)) {

                falseAlarmList = caseSolutionService.getFalseAlarmDetails(rxObjId);
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getFalseAlarmDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return falseAlarmList;
    }

    /**
     * @Author:
     * @param:HttpServletRequest
     * @return:List<RxDetailsVO>
     * @throws RMDWebException
     * @Description: This method used for fetching false alarm details in data screen.
     */
    @RequestMapping(value = AppConstants.RX_FALSE_ALARM_DETAILS)
    public @ResponseBody List<RxDetailsVO> getRXFalseAlarmDetails(final HttpServletRequest request)
            throws RMDWebException {
        rmdWebLogger.debug("CaseSolutionController : getRXFalseAlarmDetails() method Starts");
        final String rxObjId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.RX_OBJ_ID));
        List<RxDetailsVO> falseAlarmList = null;
        try {
            if (null != rxObjId && !RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(rxObjId)) {
                falseAlarmList = caseSolutionService.getRXFalseAlarmDetails(rxObjId);
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getRXFalseAlarmDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return falseAlarmList;
    }

    /**
     * @Author:
     * @param:HttpServletRequest
     * @return:List<RepairCodeVO>
     * @throws RMDWebException
     * @Description: This method used for fetching mdsc accuarate details in data screen.
     */
    @RequestMapping(value = AppConstants.MDSC_ACCURATE_DETAILS)
    public @ResponseBody List<RepairCodeVO> getMDSCAccurateDetails(final HttpServletRequest request)
            throws RMDWebException {
        rmdWebLogger.debug("CaseSolutionController : getMDSCAccurateDetails() method Starts");
        final String rxObjId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.RX_OBJ_ID));
        List<RepairCodeVO> mdscAccurateList = null;
        try {
            if (null != rxObjId && !RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(rxObjId)) {
                mdscAccurateList = caseSolutionService.getMDSCAccurateDetails(rxObjId);
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getMDSCAccuarteDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return mdscAccurateList;
    }

    /**
     * @Author:
     * @param:HttpServletRequest
     * @return:List<CaseBean>
     * @throws RMDWebException
     * @Description: This method used for fetching mdsc accuarate- cases details in data screen.
     */
    @RequestMapping(value = AppConstants.MDSC_ACCURATE_GET_CASE_DETAILS)
    public @ResponseBody List<CaseBean> getCaseDetails(final HttpServletRequest request) throws RMDWebException {
        rmdWebLogger.debug("CaseSolutionController : getCaseDetails() method Starts");
        final String rxObjId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.RX_OBJ_ID));
        final String repObjId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REP_OBJ_ID));
        List<CaseBean> caseDetailsList = null;
        try {
            if (null != rxObjId && !RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(rxObjId) && null != repObjId
                    && !RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(repObjId)) {
                caseDetailsList = caseSolutionService.getCaseDetails(rxObjId, repObjId);
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getCaseDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return caseDetailsList;
    }

    /**
     * @Author:
     * @param:HttpServletRequest
     * @return:List<RxDetailsVO>
     * @throws RMDWebException
     * @Description: This method used for fetching mdsc accuarate- rx details in data screen.
     */
    @RequestMapping(value = AppConstants.MDSC_ACCURATE_GET_RX_DETAILS)
    public @ResponseBody List<RxDetailsVO> getMDSCRxDetails(final HttpServletRequest request) throws RMDWebException {
        rmdWebLogger.debug("CaseSolutionController : getMDSCRxDetails() method Starts");
        final String repObjId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REP_OBJ_ID));
        List<RxDetailsVO> rxDetailsList = null;
        try {
            if (null != repObjId && !RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(repObjId)) {
                rxDetailsList = caseSolutionService.getMDSCRxDetails(repObjId);
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getMDSCRxDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return rxDetailsList;
    }

    /**
     * @Author:Mohamed
     * @param:HttpServletRequest
     * @return:boolean
     * @throws RMDWebException
     * @Description: This method used for fetching rx delever details for reclose
     */
    @RequestMapping(value = AppConstants.ENABLED_RECLOSE_BUTTON)
    public @ResponseBody boolean getEnableRecloseButton(final HttpServletRequest request) throws RMDWebException,
            Exception {
        rmdWebLogger.info("CaseSolutionController : Inside getEnableRecloseButton() method:::::START ");
        boolean isRXClose = false;
        HttpSession session = request.getSession(false);
        UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
        CaseBean caseBean = new CaseBean();
        CaseResponseVO caseResponseVO = new CaseResponseVO();
        try {
            final String caseId = request.getParameter(AppConstants.CASE_ID);
            if (null != caseId && !"".equals(caseId.trim())) {
                caseBean.setCaseId(caseId);
                caseResponseVO = caseSolutionService.getRxDetailsForReClose(caseBean, userVO.getTimeZone());
                if (null != caseResponseVO) {
                    if (null != caseResponseVO.getSolutionStatus()
                            && AppConstants.STATUS_CLOSED.equalsIgnoreCase(caseResponseVO.getSolutionStatus())) {
                        isRXClose = true;
                    }
                }
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getEnableRecloseButton method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }

        return isRXClose;
    }

    /**
     * @Author:Mohamed
     * @param:HttpServletRequest
     * @return:String
     * @throws RMDWebException
     * @Description: This method used to re close the case
     */
    @RequestMapping(value = AppConstants.RECLOSE_CASE)
    public @ResponseBody String ReCloseCase(final HttpServletRequest request) throws RMDWebException {
        rmdWebLogger.info("Asset Data scree Controller : ReCloseCase() method Starts");
        final HttpSession session = request.getSession(false);
        final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
        ReCloseVO objReCloseVO = null;
        CaseSolutionVO caseBeanCloseRx = null;
        try {
            String caseId = request.getParameter(AppConstants.CASE_ID);
            String caseType = request.getParameter(AppConstants.CASE_TYPE);
            String superClose = request.getParameter(AppConstants.SUPER_CLOSE);
            if (null != caseId && !RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(caseId)) {
                objReCloseVO = new ReCloseVO();
                objReCloseVO.setUserId(userVO.getUserId());
                objReCloseVO.setCaseId(caseId);
                objReCloseVO.setReCloseAction(AppConstants.NO_ACTION);
                objReCloseVO.setAppendCaseId(AppConstants.EMPTY_STRING);
                caseSolutionService.updateCloseCaseResult(objReCloseVO);
                if (null != caseType
                        && (caseType.equalsIgnoreCase(RMDCommonConstants.PINPOINT_PROBLEM)
                                || caseType.equalsIgnoreCase(RMDCommonConstants.RMD_Equipment) || caseType
                                    .equalsIgnoreCase(RMDCommonConstants.QNX_EQUIPMENT))) {
                    caseSolutionService.ReCloseCase(objReCloseVO);
                }
                if (null != superClose && !RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(superClose)
                        && RMDCommonConstants.OTHERS_STRING.equalsIgnoreCase(superClose)) {
                    caseBeanCloseRx = new CaseSolutionVO();
                    caseBeanCloseRx.setUserId(userVO.getUserId());
                    caseBeanCloseRx.setCmAliasName(userVO.getCmAliasName());
                    caseBeanCloseRx.setCaseId(caseId);
                    caseSolutionService.closeCase(caseBeanCloseRx);
                }
            }

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in ReCloseCase method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return AppConstants.SUCCESS;

    }

}
