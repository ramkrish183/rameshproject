/**
 * ============================================================

 * Classification		: GE Confidential
 * File 				: MassApplyCfgServiceImpl.java
 * Description 			:
 * Package 				: com.ge.trans.rmd.cm.valueobjects;
 * Author 				: Capgemini India.
 * Last Edited By 		:
 * Version 				: 1.0
 * Created on 			:
 * History				:
 * Modified By 			: Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpSession;

import org.apache.xerces.impl.dv.util.Base64;
import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.ApplyCfgTemplateVO;
import com.ge.trans.rmd.cm.valueobjects.ApplyEFICfgVO;
import com.ge.trans.rmd.cm.valueobjects.AssetSearchVO;
import com.ge.trans.rmd.cm.valueobjects.CfgAssetSearchVO;
import com.ge.trans.rmd.cm.valueobjects.ConfigSearchVO;
import com.ge.trans.rmd.cm.valueobjects.MassApplyCfgVO;
import com.ge.trans.rmd.cm.valueobjects.VerifyCfgTemplateVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ApplyCfgTemplateRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.ApplyEFICfgRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetNumberResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.CfgAssetSearchRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.LogMessagesResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.MassApplyCfgResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.SoftwareVersionReponseType;
import com.ge.trans.rmd.services.assets.valueobjects.TemplateVersionResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.VerifyCfgTemplatesRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.VerifyCfgTemplatesResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class MassApplyCfgServiceImpl extends RMDBaseServiceImpl implements
		MassApplyCfgService {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	WebServiceInvoker webServiceInvoker;
	@Autowired
	CachedService cachedService;
	@Autowired
	AGTTemplateService aGTTemplateService;

	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching controller Configs.
	 * 
	 */
	@Override
	public Map<String, String> getControllerConfigs() throws RMDWebException {

		Map<String, String> controllerConfigMap = null;
		try {
			controllerConfigMap = cachedService.getControllerConfigs();
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getControllerConfigs() method - VehicleCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return controllerConfigMap;
	}

	/**
	 * @Author :
	 * @return :List<MassApplyCfgVO>
	 * @param :ConfigSearchVO objConfigSearchVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Type EDP.
	 * 
	 */

	@Override
	public List<MassApplyCfgVO> getEDPConfigs(ConfigSearchVO objConfigSearchVO)
			throws RMDWebException {

		List<MassApplyCfgVO> arlEDPConfigs = null;
		MassApplyCfgVO objApplyCfgVO = null;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		final DateFormat nonESTZoneFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		final TimeZone firstTime = TimeZone.getTimeZone(objConfigSearchVO.getTimeZone());
		nonESTZoneFormat.setTimeZone(firstTime);
		String userTimeZone = firstTime.getID();
		String defaulTimeZone = objConfigSearchVO.getDefaultTimeZone();
		Date vehicleStatusDate = null;
		try {

			if (!RMDCommonUtility.isNullOrEmpty(objConfigSearchVO
					.getCtrlcfgObjId())) {

				queryParams.put(AppConstants.CTRL_CFG_OBJID,
						objConfigSearchVO.getCtrlcfgObjId());
			}

			if (!RMDCommonUtility.isNullOrEmpty(objConfigSearchVO
					.getVehicleObjId())) {

				queryParams.put(AppConstants.VEHICLE_OBJID,
						objConfigSearchVO.getVehicleObjId());
			}
			queryParams
					.put(AppConstants.IS_CASE_MASS_APPLY_CFG, objConfigSearchVO
							.isCaseMassApplyCFG() ? AppConstants.YES_FLAG
							: AppConstants.NO_FLAG);

			MassApplyCfgResponseType[] arrEDPCfgResponseTypes = (MassApplyCfgResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_EDP_CONFIGS, null, queryParams,
							null, MassApplyCfgResponseType[].class);
			if (null != arrEDPCfgResponseTypes
					&& arrEDPCfgResponseTypes.length > 0) {
				arlEDPConfigs = new ArrayList<MassApplyCfgVO>(
						arrEDPCfgResponseTypes.length);
				for (MassApplyCfgResponseType objMassApplyCfgResponseType : arrEDPCfgResponseTypes) {

					objApplyCfgVO = new MassApplyCfgVO();
					objApplyCfgVO.setObjId(objMassApplyCfgResponseType
							.getObjId());
					objApplyCfgVO.setTemplate(objMassApplyCfgResponseType
							.getTemplate());
					objApplyCfgVO.setTitle(ESAPI.encoder().decodeForHTML(
							objMassApplyCfgResponseType.getTitle()));
					objApplyCfgVO.setVersion(objMassApplyCfgResponseType
							.getVersion());

					if (objConfigSearchVO.isCaseMassApplyCFG()) {
						objApplyCfgVO.setCfgStatus(objMassApplyCfgResponseType
								.getCfgStatus());
						objApplyCfgVO
								.setVehicleStatus(objMassApplyCfgResponseType
										.getVehicleStatus());
						if (userTimeZone.equals(AppConstants.EST_TIMEZONE)
								&& defaulTimeZone
										.equals(AppConstants.TIMEZONE_EASTERN)) {
							if (!RMDCommonUtility
									.isNullOrEmpty(objMassApplyCfgResponseType
											.getVehicleStatusDate())) {
								objApplyCfgVO
										.setVehicleStatusDate(objMassApplyCfgResponseType
												.getVehicleStatusDate());
							}

						} else {
							if (!RMDCommonUtility
									.isNullOrEmpty(objMassApplyCfgResponseType
											.getVehicleStatusDate())) {
								vehicleStatusDate = RMDCommonUtility
										.stringToUSESTDate(
												objMassApplyCfgResponseType
														.getVehicleStatusDate(),
												RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
								objApplyCfgVO
										.setVehicleStatusDate(nonESTZoneFormat
												.format(vehicleStatusDate));
							}
						}
					}
					arlEDPConfigs.add(objApplyCfgVO);
				}
			}
			arrEDPCfgResponseTypes = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getEDPConfigs() method - VehicleCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return arlEDPConfigs;
	}

	/**
	 * @Author :
	 * @return :List<MassApplyCfgVO>
	 * @param :String ctrlCfgObjId,String vehicleObjId
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Type FFD.
	 * 
	 */
	@Override
	public List<MassApplyCfgVO> getFFDConfigs(ConfigSearchVO objConfigSearchVO)
			throws RMDWebException {
		List<MassApplyCfgVO> arlFFDConfigs = null;
		MassApplyCfgVO objApplyCfgVO = null;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		final DateFormat nonESTZoneFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		final TimeZone firstTime = TimeZone.getTimeZone(objConfigSearchVO.getTimeZone());
		nonESTZoneFormat.setTimeZone(firstTime);
		String userTimeZone = firstTime.getID();
		String defaulTimeZone = objConfigSearchVO.getDefaultTimeZone();
		Date vehicleStatusDate = null;
		try {

			if (!RMDCommonUtility.isNullOrEmpty(objConfigSearchVO
					.getCtrlcfgObjId())) {

				queryParams.put(AppConstants.CTRL_CFG_OBJID,
						objConfigSearchVO.getCtrlcfgObjId());
			}

			if (!RMDCommonUtility.isNullOrEmpty(objConfigSearchVO
					.getVehicleObjId())) {

				queryParams.put(AppConstants.VEHICLE_OBJID,
						objConfigSearchVO.getVehicleObjId());
			}
			queryParams
					.put(AppConstants.IS_CASE_MASS_APPLY_CFG, objConfigSearchVO
							.isCaseMassApplyCFG() ? AppConstants.YES_FLAG
							: AppConstants.NO_FLAG);

			MassApplyCfgResponseType[] arrFFDCfgResponseTypes = (MassApplyCfgResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_FFD_CONFIGS, null, queryParams,
							null, MassApplyCfgResponseType[].class);
			if (null != arrFFDCfgResponseTypes
					&& arrFFDCfgResponseTypes.length > 0) {
				arlFFDConfigs = new ArrayList<MassApplyCfgVO>(
						arrFFDCfgResponseTypes.length);
				for (MassApplyCfgResponseType objMassApplyCfgResponseType : arrFFDCfgResponseTypes) {

					objApplyCfgVO = new MassApplyCfgVO();
					objApplyCfgVO.setObjId(objMassApplyCfgResponseType
							.getObjId());
					objApplyCfgVO.setTemplate(objMassApplyCfgResponseType
							.getTemplate());
					objApplyCfgVO.setTitle(ESAPI.encoder().decodeForHTML(
							objMassApplyCfgResponseType.getTitle()));
					objApplyCfgVO.setVersion(objMassApplyCfgResponseType
							.getVersion());

					if (objConfigSearchVO.isCaseMassApplyCFG()) {
						objApplyCfgVO.setCfgStatus(objMassApplyCfgResponseType
								.getCfgStatus());
						objApplyCfgVO
								.setVehicleStatus(objMassApplyCfgResponseType
										.getVehicleStatus());
						if (userTimeZone.equals(AppConstants.EST_TIMEZONE)
								&& defaulTimeZone
										.equals(AppConstants.TIMEZONE_EASTERN)) {
							if (!RMDCommonUtility
									.isNullOrEmpty(objMassApplyCfgResponseType
											.getVehicleStatusDate())) {
								objApplyCfgVO
										.setVehicleStatusDate(objMassApplyCfgResponseType
												.getVehicleStatusDate());
							}

						} else {
							if (!RMDCommonUtility
									.isNullOrEmpty(objMassApplyCfgResponseType
											.getVehicleStatusDate())) {
								vehicleStatusDate = RMDCommonUtility
										.stringToUSESTDate(
												objMassApplyCfgResponseType
														.getVehicleStatusDate(),
												RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
								objApplyCfgVO
										.setVehicleStatusDate(nonESTZoneFormat
												.format(vehicleStatusDate));
							}
						}
					}
					arlFFDConfigs.add(objApplyCfgVO);
				}
			}
			arrFFDCfgResponseTypes = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getFFDConfigs() method - MassApplyCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return arlFFDConfigs;
	}

	/**
	 * @Author :
	 * @return :List<MassApplyCfgVO>
	 * @param :String ctrlCfgObjId,String vehicleObjId
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Type FRD.
	 * 
	 */

	@Override
	public List<MassApplyCfgVO> getFRDConfigs(ConfigSearchVO objConfigSearchVO)
			throws RMDWebException {
		List<MassApplyCfgVO> arlFRDConfigs = null;
		MassApplyCfgVO objApplyCfgVO = null;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		final DateFormat nonESTZoneFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		final TimeZone firstTime = TimeZone.getTimeZone(objConfigSearchVO.getTimeZone());
		nonESTZoneFormat.setTimeZone(firstTime);
		String userTimeZone = firstTime.getID();
		String defaulTimeZone = objConfigSearchVO.getDefaultTimeZone();
		Date vehicleStatusDate = null;
		try {

			if (!RMDCommonUtility.isNullOrEmpty(objConfigSearchVO
					.getCtrlcfgObjId())) {

				queryParams.put(AppConstants.CTRL_CFG_OBJID,
						objConfigSearchVO.getCtrlcfgObjId());
			}

			if (!RMDCommonUtility.isNullOrEmpty(objConfigSearchVO
					.getVehicleObjId())) {

				queryParams.put(AppConstants.VEHICLE_OBJID,
						objConfigSearchVO.getVehicleObjId());
			}
			queryParams
					.put(AppConstants.IS_CASE_MASS_APPLY_CFG, objConfigSearchVO
							.isCaseMassApplyCFG() ? AppConstants.YES_FLAG
							: AppConstants.NO_FLAG);

			MassApplyCfgResponseType[] arrFRDCfgResponseTypes = (MassApplyCfgResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_FRD_CONFIGS, null, queryParams,
							null, MassApplyCfgResponseType[].class);
			if (null != arrFRDCfgResponseTypes
					&& arrFRDCfgResponseTypes.length > 0) {
				arlFRDConfigs = new ArrayList<MassApplyCfgVO>(
						arrFRDCfgResponseTypes.length);

				for (MassApplyCfgResponseType objMassApplyCfgResponseType : arrFRDCfgResponseTypes) {

					objApplyCfgVO = new MassApplyCfgVO();
					objApplyCfgVO.setObjId(objMassApplyCfgResponseType
							.getObjId());
					objApplyCfgVO.setTemplate(objMassApplyCfgResponseType
							.getTemplate());
					objApplyCfgVO.setTitle(ESAPI.encoder().decodeForHTML(
							objMassApplyCfgResponseType.getTitle()));
					objApplyCfgVO.setVersion(objMassApplyCfgResponseType
							.getVersion());

					if (objConfigSearchVO.isCaseMassApplyCFG()) {
						objApplyCfgVO.setCfgStatus(objMassApplyCfgResponseType
								.getCfgStatus());
						objApplyCfgVO
								.setVehicleStatus(objMassApplyCfgResponseType
										.getVehicleStatus());
						if (userTimeZone.equals(AppConstants.EST_TIMEZONE)
								&& defaulTimeZone
										.equals(AppConstants.TIMEZONE_EASTERN)) {
							if (!RMDCommonUtility
									.isNullOrEmpty(objMassApplyCfgResponseType
											.getVehicleStatusDate())) {
								objApplyCfgVO
										.setVehicleStatusDate(objMassApplyCfgResponseType
												.getVehicleStatusDate());
							}

						} else {
							if (!RMDCommonUtility
									.isNullOrEmpty(objMassApplyCfgResponseType
											.getVehicleStatusDate())) {
								vehicleStatusDate = RMDCommonUtility
										.stringToUSESTDate(
												objMassApplyCfgResponseType
														.getVehicleStatusDate(),
												RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
								objApplyCfgVO
										.setVehicleStatusDate(nonESTZoneFormat
												.format(vehicleStatusDate));
							}
						}
					}
					arlFRDConfigs.add(objApplyCfgVO);
				}
			}
			arrFRDCfgResponseTypes = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getFRDConfigs() method - MassApplyCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return arlFRDConfigs;
	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Types.
	 * 
	 */
	@Override
	public List<String> getMassApplyCfgList() throws RMDWebException {
		final Map<String, String> pathParamsPastDays = new LinkedHashMap<String, String>();
		List<String> cfgList = null;
		try {
			pathParamsPastDays.put(AppConstants.LIST_NAME,
					AppConstants.MASS_APPLY_CFG_LIST);
			ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParamsPastDays);
			if (null != applParamResponseType
					&& applParamResponseType.length > 0) {
				cfgList = new ArrayList<String>(applParamResponseType.length);
				for (ApplicationParametersResponseType objApplicationParametersResponseType : applParamResponseType) {
					cfgList.add(objApplicationParametersResponseType
							.getLookupValue());
				}
			}
			applParamResponseType = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getMassApplyCfgList() method - MassApplyCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}

		return cfgList;
	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Mass Apply Cfg
	 *               Users List.
	 * 
	 * 
	 */

	@Override
	public List<String> getMassApplyCfgUsers() throws RMDWebException {
		final Map<String, String> pathParamsPastDays = new LinkedHashMap<String, String>();
		List<String> usersList = null;
		try {
			pathParamsPastDays.put(AppConstants.LIST_NAME,
					AppConstants.MassApplyCfg_Owners);
			ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParamsPastDays);
			if (null != applParamResponseType
					&& applParamResponseType.length > 0) {
				usersList = new ArrayList<String>(applParamResponseType.length);
				for (ApplicationParametersResponseType objApplicationParametersResponseType : applParamResponseType) {
					usersList.add(objApplicationParametersResponseType
							.getLookupValue());
				}
			}
			applParamResponseType = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getMassApplyCfgUsers() method - MassApplyCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return usersList;
	}

	/**
	 * @Author :
	 * @return :List<VerifyCfgTempaltesVO>
	 * @param :String edpObjId, String ffdObjId, String frdObjId,String efiObjId,String ahcObjId
	 * @throws :RMDServiceException
	 * @Description: This method is Responsible for fetching selected
	 *               Configurations for applying.
	 */

	@Override
	public List<VerifyCfgTemplateVO> verifyConfigTemplates(String edpObjId,
			String ffdObjId, String frdObjId, String efiObjId,String ahcObjId,String rciObjId,String agtObjId,String timeZone)
			throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		List<VerifyCfgTemplateVO> arlVerifyCfgTemplateVOs =  new ArrayList<VerifyCfgTemplateVO>();
		VerifyCfgTemplateVO objCfgTemplateVO = null;
		VerifyCfgTemplateVO agtobjCfgTemplateVO = null;
		try {
		    
			if (!RMDCommonUtility.isNullOrEmpty(edpObjId)) {
				queryParams.put(AppConstants.EDP_OBJID, edpObjId);
			}
			if (!RMDCommonUtility.isNullOrEmpty(ffdObjId)) {
				queryParams.put(AppConstants.FFD_OBJID, ffdObjId);
			}
			if (!RMDCommonUtility.isNullOrEmpty(frdObjId)) {
				queryParams.put(AppConstants.FRD_OBJID, frdObjId);
			}
			if (!RMDCommonUtility.isNullOrEmpty(efiObjId)) {
				queryParams.put(AppConstants.EFI_OBJID, efiObjId);
			}
			if (!RMDCommonUtility.isNullOrEmpty(ahcObjId)) {
                queryParams.put(AppConstants.AHC_OBJID, ahcObjId);
            }
			if (!RMDCommonUtility.isNullOrEmpty(rciObjId)) {
                queryParams.put(AppConstants.RCI_OBJID, rciObjId);
            }
			if (!RMDCommonUtility.isNullOrEmpty(agtObjId)) {
			    agtobjCfgTemplateVO=aGTTemplateService.getSelectedAGTTemplate(agtObjId,timeZone);
			    if(null!=agtobjCfgTemplateVO)
			        arlVerifyCfgTemplateVOs.add(agtobjCfgTemplateVO);
			}
			
			VerifyCfgTemplatesResponseType[] arrVerifiyCfgTemplatesResponseTypes = (VerifyCfgTemplatesResponseType[]) webServiceInvoker
					.get(ServiceConstants.VERIFY_CFG_TEMPLATES, null,
							queryParams, null,
							VerifyCfgTemplatesResponseType[].class);
			if (null != arrVerifiyCfgTemplatesResponseTypes
					&& arrVerifiyCfgTemplatesResponseTypes.length > 0) {
				for (VerifyCfgTemplatesResponseType objCfgTemplatesResponseType : arrVerifiyCfgTemplatesResponseTypes) {
					objCfgTemplateVO = new VerifyCfgTemplateVO();
					objCfgTemplateVO.setCfgType(objCfgTemplatesResponseType
							.getCfgType());
					objCfgTemplateVO.setConfigFile(objCfgTemplatesResponseType
							.getCfgFile());
					objCfgTemplateVO.setCustomer(objCfgTemplatesResponseType
							.getCustomer());
					objCfgTemplateVO.setObjid(objCfgTemplatesResponseType
							.getObjid());
					objCfgTemplateVO.setTemplate(objCfgTemplatesResponseType
							.getTemplate());
					objCfgTemplateVO.setTitle(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(
							objCfgTemplatesResponseType.getTitle())));
					objCfgTemplateVO.setVersion(objCfgTemplatesResponseType
							.getVersion());
					objCfgTemplateVO.setStatus(objCfgTemplatesResponseType
							.getStatus());
					objCfgTemplateVO.setFaultCode(objCfgTemplatesResponseType
                            .getFaultCode());
					objCfgTemplateVO.setFileName(objCfgTemplatesResponseType
                            .getFileName());
					if(null!=objCfgTemplatesResponseType
                            .getFileContent()){
                        objCfgTemplateVO.setFileContent(
                                        new String(Base64
                                                .decode(objCfgTemplatesResponseType
                                                        .getFileContent())));
					}
					arlVerifyCfgTemplateVOs.add(objCfgTemplateVO);
				}
			}
			arrVerifiyCfgTemplatesResponseTypes = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in verifyConfigTemplates() method - MassApplyCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return arlVerifyCfgTemplateVOs;
	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :String ctrlCfgObjId
	 * @throws :RMDServiceException
	 * @Description: This method is Responsible for fetching software Versions.
	 * 
	 */

	@Override
	public List<String> getOnboardSoftwareVersion(String ctrlCfgObjId)
			throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		List<String> arlSoftwareVersions = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(ctrlCfgObjId)) {
				queryParams.put(AppConstants.CTRL_CFG_OBJID, ctrlCfgObjId);
			}
			SoftwareVersionReponseType objSoftwareVersionReponseType = (SoftwareVersionReponseType) webServiceInvoker
					.get(ServiceConstants.GET_ONBOARD_SOFTWARE_VERSION, null,
							queryParams, null, SoftwareVersionReponseType.class);

			if (null != objSoftwareVersionReponseType
					&& !objSoftwareVersionReponseType.getSoftwareVersionList()
							.isEmpty()) {
				arlSoftwareVersions = new ArrayList<String>(
						objSoftwareVersionReponseType.getSoftwareVersionList()
								.size());
				arlSoftwareVersions.addAll(objSoftwareVersionReponseType
						.getSoftwareVersionList());
			}
			objSoftwareVersionReponseType = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getOnboardSoftwareVersion() method - MassApplyCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return arlSoftwareVersions;
	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :String cfgType, String templateObjId, String ctrlCfgObjId
	 * @throws :RMDServiceException
	 * @Description: This method is Responsible for fetching template versions.
	 * 
	 */
	@Override
	public List<String> getCfgTemplateVersions(String cfgType, String template,
			String ctrlCfgObjId) throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		List<String> arlTemplateVersions = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(cfgType)) {
				queryParams.put(AppConstants.CFG_FILE, cfgType);
			}
			if (!RMDCommonUtility.isNullOrEmpty(template)) {
				queryParams.put(AppConstants.TEMPLATE, template);
			}
			if (!RMDCommonUtility.isNullOrEmpty(ctrlCfgObjId)) {
				queryParams.put(AppConstants.CTRL_CFG_OBJID, ctrlCfgObjId);
			}
			TemplateVersionResponseType objResponseType = (TemplateVersionResponseType) webServiceInvoker
					.get(ServiceConstants.GET_CONFIG_TEMPLATE_VERSION, null,
							queryParams, null,
							TemplateVersionResponseType.class);
			if (null != objResponseType
					&& null != objResponseType.getTemplateVersionList()
					&& !objResponseType.getTemplateVersionList().isEmpty()) {
				arlTemplateVersions = new ArrayList<String>(objResponseType
						.getTemplateVersionList().size());
				arlTemplateVersions = objResponseType.getTemplateVersionList();
			}
			objResponseType = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getCfgTemplateVersions() method - MassApplyCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return arlTemplateVersions;
	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :AssetSearchVO objAssetSearchVO
	 * @throws :RMDServiceException
	 * @Description: This method is Responsible for fetching specific
	 *               assetNumbers
	 * 
	 */

	@Override
	public List<String> getSpecificAssetNumbers(AssetSearchVO objAssetSearchVO)
			throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		List<String> arlAssetNumbers = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(objAssetSearchVO
					.getAssetGroupName())) {
				queryParams.put(AppConstants.ASSET_GROUP_NAME,
						objAssetSearchVO.getAssetGroupName());
			}
			if (!RMDCommonUtility
					.isNullOrEmpty(objAssetSearchVO.getAssetFrom())) {
				queryParams.put(AppConstants.WS_PARAM_ASSTNUMFROM,
						objAssetSearchVO.getAssetFrom());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objAssetSearchVO.getAssetTo())) {
				queryParams.put(AppConstants.WS_PARAM_ASSTNUMTO,
						objAssetSearchVO.getAssetTo());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objAssetSearchVO
					.getCtrlCfgObjId())) {
				queryParams.put(AppConstants.CTRL_CFG_OBJID,
						objAssetSearchVO.getCtrlCfgObjId());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objAssetSearchVO
					.getCustomerId())) {
				queryParams.put(AppConstants.CUSTOMER_ID,
						objAssetSearchVO.getCustomerId());
			}

			AssetNumberResponseType objResponseType = (AssetNumberResponseType) webServiceInvoker
					.get(ServiceConstants.GET_SPECIFIC_ASSET_NUMBERS, null,
							queryParams, null, AssetNumberResponseType.class);
			if (null != objResponseType
					&& null != objResponseType.getArlAssetNumbers()
					&& ! objResponseType.getArlAssetNumbers().isEmpty()) {
				arlAssetNumbers = new ArrayList<String>(objResponseType
						.getArlAssetNumbers().size());
				arlAssetNumbers = objResponseType.getArlAssetNumbers();
			}
			objResponseType = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getSpecificAssetNumbers() method - MassApplyCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return arlAssetNumbers;
	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :ApplyCfgTemplateVO objApplyCfgTemplateVO
	 * @throws :RMDServiceException
	 * @Description: This method is Responsible for applying the config
	 *               templates to the selected assets.
	 * 
	 */

	@Override
	public List<String> applyCfgTemplates(
			ApplyCfgTemplateVO objApplyCfgTemplateVO) throws RMDWebException {
		List<String> arlLogMessages = new ArrayList<String>();
		List<VerifyCfgTemplatesRequestType> arlVerifyCfgTemplatesRequestTypes = null;
		List<VerifyCfgTemplatesRequestType> arlAGTVerifyCfgTemplatesRequestTypes = null;
		ApplyCfgTemplateRequestType objApplyCfgTemplateRequestType = null;
		VerifyCfgTemplatesRequestType objVerifyCfgTemplatesRequestType = null;
		List<CfgAssetSearchRequestType> arlAssetSearchRequestTypes = null;
		CfgAssetSearchRequestType objAssetSearchRequestType = null;
		String agtApplyResult=RMDCommonConstants.EMPTY_STRING;
		LogMessagesResponseType objLogMessagesResponseType =null;

		try {

			objApplyCfgTemplateRequestType = new ApplyCfgTemplateRequestType();

			if (!RMDCommonUtility.isNullOrEmpty(objApplyCfgTemplateVO
					.getCtrlCfgObjId())) {
				objApplyCfgTemplateRequestType
						.setCtrlCfgObjId(objApplyCfgTemplateVO
								.getCtrlCfgObjId());
			}

			if (!RMDCommonUtility.isNullOrEmpty(objApplyCfgTemplateVO
					.getUserName())) {
				objApplyCfgTemplateRequestType
						.setUserName(objApplyCfgTemplateVO.getUserName());
			}

			if (!RMDCommonUtility.isNullOrEmpty(objApplyCfgTemplateVO
					.getSearchType())) {
				objApplyCfgTemplateRequestType
						.setSearchCriteria(objApplyCfgTemplateVO
								.getSearchType());
			}

			if (!RMDCommonUtility.isNullOrEmpty(objApplyCfgTemplateVO
					.getCtrlCfgName())) {
				objApplyCfgTemplateRequestType
						.setCtrlCfgName(objApplyCfgTemplateVO.getCtrlCfgName());
			}

			objApplyCfgTemplateRequestType.setDeleteCfg(objApplyCfgTemplateVO
					.isDeleteCfgAction());
			

			if (null != objApplyCfgTemplateVO.getCfgTemplateList()
					&& ! objApplyCfgTemplateVO.getCfgTemplateList().isEmpty()) {
				arlVerifyCfgTemplatesRequestTypes = new ArrayList<VerifyCfgTemplatesRequestType>(
						objApplyCfgTemplateVO.getCfgTemplateList().size());
				arlAGTVerifyCfgTemplatesRequestTypes = new ArrayList<VerifyCfgTemplatesRequestType>();
				for (VerifyCfgTemplateVO objCfgTemplateVO : objApplyCfgTemplateVO
						.getCfgTemplateList()) {
					objVerifyCfgTemplatesRequestType = new VerifyCfgTemplatesRequestType();
					objVerifyCfgTemplatesRequestType
							.setCfgFile(objCfgTemplateVO.getConfigFile());
					objVerifyCfgTemplatesRequestType
							.setCfgType(objCfgTemplateVO.getCfgType());
					objVerifyCfgTemplatesRequestType
							.setCustomer(objCfgTemplateVO.getCustomer());
					objVerifyCfgTemplatesRequestType.setObjid(objCfgTemplateVO
							.getObjid());
					objVerifyCfgTemplatesRequestType
							.setTemplate(objCfgTemplateVO.getTemplate());
					objVerifyCfgTemplatesRequestType.setTitle(objCfgTemplateVO
							.getTitle());
					objVerifyCfgTemplatesRequestType
							.setVersion(objCfgTemplateVO.getVersion());
					objVerifyCfgTemplatesRequestType.setStatus(objCfgTemplateVO
							.getStatus());
					objVerifyCfgTemplatesRequestType.setDevice(objCfgTemplateVO.getDevice());
					//Modified for AGT
					if(RMDCommonConstants.AGT_TEMPLATE.equals(objCfgTemplateVO.getConfigFile())){
					    arlAGTVerifyCfgTemplatesRequestTypes.add(objVerifyCfgTemplatesRequestType);
					}else{
					    arlVerifyCfgTemplatesRequestTypes
							.add(objVerifyCfgTemplatesRequestType);
					}
				}
				objApplyCfgTemplateRequestType
						.setCfgTemplateList(arlVerifyCfgTemplatesRequestTypes);
				//Added for AGT
				objApplyCfgTemplateRequestType
                        .setCfgAGTTemplateList(arlAGTVerifyCfgTemplatesRequestTypes);
			}

			if (null != objApplyCfgTemplateVO.getArlAssetSearchVOs()
					&& ! objApplyCfgTemplateVO.getArlAssetSearchVOs().isEmpty()) {
				arlAssetSearchRequestTypes = new ArrayList<CfgAssetSearchRequestType>(
						objApplyCfgTemplateVO.getArlAssetSearchVOs().size());
				for (CfgAssetSearchVO objCfgAssetSearchVO : objApplyCfgTemplateVO
						.getArlAssetSearchVOs()) {
					objAssetSearchRequestType = new CfgAssetSearchRequestType();
					objAssetSearchRequestType
							.setAssetGrpName(objCfgAssetSearchVO
									.getAssetGrpName());
					objAssetSearchRequestType
							.setAssetNumbers(objCfgAssetSearchVO
									.getAssetNumbers());
					objAssetSearchRequestType.setCustomer(objCfgAssetSearchVO
							.getCustomer());
					objAssetSearchRequestType.setFleet(objCfgAssetSearchVO
							.getFleet());
					objAssetSearchRequestType.setModel(objCfgAssetSearchVO
							.getModel());
					objAssetSearchRequestType
							.setOnboardSWVersion(objCfgAssetSearchVO
									.getOnboardSWVersion());
					objAssetSearchRequestType.setToVersion(objCfgAssetSearchVO
							.getToVersion());
					objAssetSearchRequestType
							.setFromVersion(objCfgAssetSearchVO
									.getFromVersion());
					objAssetSearchRequestType.setSearchType(objCfgAssetSearchVO
							.getSearchType());
					arlAssetSearchRequestTypes.add(objAssetSearchRequestType);
				}
				objApplyCfgTemplateRequestType
						.setArlAssetSearchRequestTypes(arlAssetSearchRequestTypes);
			}
			//Added for AGT
			if(RMDCommonUtility.isCollectionNotEmpty(arlAGTVerifyCfgTemplatesRequestTypes)){
			    
			    objApplyCfgTemplateRequestType.setUserId(objApplyCfgTemplateVO
	                    .getUserId());
	            objApplyCfgTemplateRequestType.setVehHdrNo(objApplyCfgTemplateVO
	                    .getVehHdrNo());
	            objApplyCfgTemplateRequestType.setCustomerId(objApplyCfgTemplateVO
	                    .getCustomerId());
	            
	            if(RMDCommonUtility.isNullOrEmpty(objApplyCfgTemplateVO
                        .getDevice())){
	                agtApplyResult="AGT APPLY :: Error :: No device is selected to Apply";
	            }else{
	                objApplyCfgTemplateRequestType.setDevice(objApplyCfgTemplateVO
	                        .getDevice());
	                agtApplyResult=aGTTemplateService.applyAGTTemplate(objApplyCfgTemplateRequestType);
	            }   
			    arlLogMessages.add(agtApplyResult);
			}
			if(RMDCommonUtility.isCollectionNotEmpty(objApplyCfgTemplateRequestType.getCfgTemplateList())){
    			 objLogMessagesResponseType = (LogMessagesResponseType) webServiceInvoker
    					.post(ServiceConstants.APPLY_CONFIG_TEMPLATES,
    							objApplyCfgTemplateRequestType,
    							LogMessagesResponseType.class);
			}	 

			if (null != objLogMessagesResponseType) {
				arlLogMessages.addAll(objLogMessagesResponseType.getArlLogMessages());
			}
			arlVerifyCfgTemplatesRequestTypes = null;
			objApplyCfgTemplateRequestType = null;
			objLogMessagesResponseType = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in applyCfgTemplates() method - MassApplyCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		} finally {
			objApplyCfgTemplateVO = null;
		}
		return arlLogMessages;
	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :ApplyCfgTemplateVO objApplyCfgTemplateVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for applying the EFI config
	 *               templates to the selected assets.
	 * 
	 */
	@Override
	public List<String> applyEFICfg(ApplyEFICfgVO objApplyEFICfgVO)
			throws RMDWebException {

		ApplyEFICfgRequestType objApplyEFICfgRequestType = new ApplyEFICfgRequestType();
		List<String> arlLogMessages = null;
		VerifyCfgTemplatesRequestType objCfgTemplatesRequestType = null;
		try {

			if (!RMDCommonUtility.isNullOrEmpty(objApplyEFICfgVO.getCustomer())) {
				objApplyEFICfgRequestType.setCustomer(objApplyEFICfgVO
						.getCustomer());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objApplyEFICfgVO
					.getAssetGrpName())) {
				objApplyEFICfgRequestType.setAssetGrpName(objApplyEFICfgVO
						.getAssetGrpName());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objApplyEFICfgVO
					.getFromAssetNumber())) {
				objApplyEFICfgRequestType.setFromAssetNumber(objApplyEFICfgVO
						.getFromAssetNumber());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objApplyEFICfgVO
					.getToAssetNumber())) {
				objApplyEFICfgRequestType.setToAssetNumber(objApplyEFICfgVO
						.getToAssetNumber());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objApplyEFICfgVO.getUserName())) {
				objApplyEFICfgRequestType.setUserName(objApplyEFICfgVO
						.getUserName());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objApplyEFICfgVO
					.getFromVersion())) {
				objApplyEFICfgRequestType.setFromVersion(objApplyEFICfgVO
						.getFromVersion());
			}
			objApplyEFICfgRequestType.setChangeVersion(objApplyEFICfgVO
					.isChangeVersion());
			if (null != objApplyEFICfgVO.getObjVerifyCfgTemplateVO()) {
				objCfgTemplatesRequestType = new VerifyCfgTemplatesRequestType();
				objCfgTemplatesRequestType.setCfgFile(objApplyEFICfgVO
						.getObjVerifyCfgTemplateVO().getConfigFile());
				objCfgTemplatesRequestType.setObjid(objApplyEFICfgVO
						.getObjVerifyCfgTemplateVO().getObjid());
				objCfgTemplatesRequestType.setTemplate(objApplyEFICfgVO
						.getObjVerifyCfgTemplateVO().getTemplate());
				objCfgTemplatesRequestType.setVersion(objApplyEFICfgVO
						.getObjVerifyCfgTemplateVO().getVersion());
				objApplyEFICfgRequestType
						.setObjVerifyCfgTemplatesRequestType(objCfgTemplatesRequestType);
			}
			LogMessagesResponseType objLogMessagesResponseType = (LogMessagesResponseType) webServiceInvoker
					.post(ServiceConstants.APPLY_EFI_CONFIG,
							objApplyEFICfgRequestType,
							LogMessagesResponseType.class);

			if (null != objLogMessagesResponseType) {
				arlLogMessages = objLogMessagesResponseType.getArlLogMessages();
			}
			objLogMessagesResponseType = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in applyEFICfg() method - MassApplyCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		} finally {
			objApplyEFICfgRequestType = null;
			objCfgTemplatesRequestType = null;
		}
		return arlLogMessages;
	}
	
	/**
     * @Author :
     * @return :List<MassApplyCfgVO>
     * @param :String ctrlCfgObjId,String vehicleObjId
     * @throws :RMDWebException
     * @Description: This method is Responsible for fetching Configurations of
     *               Type FRD.
     * 
     */

    @Override
    public List<MassApplyCfgVO> getAHCConfigs(ConfigSearchVO objConfigSearchVO)
            throws RMDWebException {
        List<MassApplyCfgVO> arlAHCConfigs = null;
        MassApplyCfgVO objApplyCfgVO = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        final DateFormat nonESTZoneFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
        final TimeZone firstTime = TimeZone.getTimeZone(objConfigSearchVO.getTimeZone());
        nonESTZoneFormat.setTimeZone(firstTime);
        String userTimeZone = firstTime.getID();
        String defaulTimeZone = objConfigSearchVO.getDefaultTimeZone();
        Date vehicleStatusDate = null;
        try {

            if (!RMDCommonUtility.isNullOrEmpty(objConfigSearchVO
                    .getCtrlcfgObjId())) {

                queryParams.put(AppConstants.CTRL_CFG_OBJID,
                        objConfigSearchVO.getCtrlcfgObjId());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objConfigSearchVO
                    .getVehicleObjId())) {

                queryParams.put(AppConstants.VEHICLE_OBJID,
                        objConfigSearchVO.getVehicleObjId());
            }
            queryParams
                    .put(AppConstants.IS_CASE_MASS_APPLY_CFG, objConfigSearchVO
                            .isCaseMassApplyCFG() ? AppConstants.YES_FLAG
                            : AppConstants.NO_FLAG);

            MassApplyCfgResponseType[] arrAHCCfgResponseTypes = (MassApplyCfgResponseType[]) webServiceInvoker
                    .get(ServiceConstants.GET_AHC_CONFIGS, null, queryParams,
                            null, MassApplyCfgResponseType[].class);
            if (null != arrAHCCfgResponseTypes
                    && arrAHCCfgResponseTypes.length > 0) {
                arlAHCConfigs = new ArrayList<MassApplyCfgVO>(
                        arrAHCCfgResponseTypes.length);

                for (MassApplyCfgResponseType objMassApplyCfgResponseType : arrAHCCfgResponseTypes) {

                    objApplyCfgVO = new MassApplyCfgVO();
                    objApplyCfgVO.setObjId(objMassApplyCfgResponseType
                            .getObjId());
                    objApplyCfgVO.setTemplate(objMassApplyCfgResponseType
                            .getTemplate());
                    objApplyCfgVO.setTitle(ESAPI.encoder().decodeForHTML(
                            objMassApplyCfgResponseType.getTitle()));
                    objApplyCfgVO.setVersion(objMassApplyCfgResponseType
                            .getVersion());

                    if (objConfigSearchVO.isCaseMassApplyCFG()) {
                        objApplyCfgVO.setCfgStatus(objMassApplyCfgResponseType
                                .getCfgStatus());
                        objApplyCfgVO
                                .setVehicleStatus(objMassApplyCfgResponseType
                                        .getVehicleStatus());
                        if (userTimeZone.equals(AppConstants.EST_TIMEZONE)
                                && defaulTimeZone
                                        .equals(AppConstants.TIMEZONE_EASTERN)) {
                            if (!RMDCommonUtility
                                    .isNullOrEmpty(objMassApplyCfgResponseType
                                            .getVehicleStatusDate())) {
                                objApplyCfgVO
                                        .setVehicleStatusDate(objMassApplyCfgResponseType
                                                .getVehicleStatusDate());
                            }

                        } else {
                            if (!RMDCommonUtility
                                    .isNullOrEmpty(objMassApplyCfgResponseType
                                            .getVehicleStatusDate())) {
                                vehicleStatusDate = RMDCommonUtility
                                        .stringToUSESTDate(
                                                objMassApplyCfgResponseType
                                                        .getVehicleStatusDate(),
                                                RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
                                objApplyCfgVO
                                        .setVehicleStatusDate(nonESTZoneFormat
                                                .format(vehicleStatusDate));
                            }
                        }
                    }
                    arlAHCConfigs.add(objApplyCfgVO);
                }
            }
            arrAHCCfgResponseTypes = null;
        } catch (Exception rmdEx) {
            rmdWebLogger
                    .error("RMDWebException occured in getAHCConfigs() method - MassApplyCfgServiceImpl",
                            rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }
        return arlAHCConfigs;
    }
    /**
	 * @Author :
	 * @return :List<MassApplyCfgVO>
	 * @param :ConfigSearchVO objConfigSearchVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Configurations of
	 *               Type RCI.
	 * 
	 */

	@Override
	public List<MassApplyCfgVO> getRCIConfigs(ConfigSearchVO objConfigSearchVO)
			throws RMDWebException {

		List<MassApplyCfgVO> arlRCIConfigs = null;
		MassApplyCfgVO objApplyCfgVO = null;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		final DateFormat nonESTZoneFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		final TimeZone firstTime = TimeZone.getTimeZone(objConfigSearchVO.getTimeZone());
		nonESTZoneFormat.setTimeZone(firstTime);
		String userTimeZone = firstTime.getID();
		String defaulTimeZone = objConfigSearchVO.getDefaultTimeZone();
		Date onBoardStatusDate = null;
		try {

			if (!RMDCommonUtility.isNullOrEmpty(objConfigSearchVO
					.getCtrlcfgObjId())) {

				queryParams.put(AppConstants.CTRL_CFG_OBJID,
						objConfigSearchVO.getCtrlcfgObjId());
			}

			if (!RMDCommonUtility.isNullOrEmpty(objConfigSearchVO
					.getVehicleObjId())) {

				queryParams.put(AppConstants.VEHICLE_OBJID,
						objConfigSearchVO.getVehicleObjId());
			}
			queryParams
					.put(AppConstants.IS_CASE_MASS_APPLY_CFG, objConfigSearchVO
							.isCaseMassApplyCFG() ? AppConstants.YES_FLAG
							: AppConstants.NO_FLAG);

			MassApplyCfgResponseType[] arrRCICfgResponseTypes = (MassApplyCfgResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_RCI_CONFIGS, null, queryParams,
							null, MassApplyCfgResponseType[].class);
			if (null != arrRCICfgResponseTypes
					&& arrRCICfgResponseTypes.length > 0) {
				arlRCIConfigs = new ArrayList<MassApplyCfgVO>(
						arrRCICfgResponseTypes.length);
				for (MassApplyCfgResponseType objMassApplyCfgResponseType : arrRCICfgResponseTypes) {

					objApplyCfgVO = new MassApplyCfgVO();
					objApplyCfgVO.setObjId(objMassApplyCfgResponseType
							.getObjId());
					objApplyCfgVO.setTemplate(objMassApplyCfgResponseType
							.getTemplate());
					objApplyCfgVO.setTitle(ESAPI.encoder().decodeForHTML(
							objMassApplyCfgResponseType.getTitle()));
					objApplyCfgVO.setVersion(objMassApplyCfgResponseType
							.getVersion());

					if (objConfigSearchVO.isCaseMassApplyCFG()) {
						objApplyCfgVO.setCfgStatus(objMassApplyCfgResponseType
								.getCfgStatus());
						objApplyCfgVO
								.setOffboardStatus(objMassApplyCfgResponseType
										.getOffboardStatus());
						objApplyCfgVO
                                .setOnBoardStatus(objMassApplyCfgResponseType
                                        .getOnBoardStatus());

						if (userTimeZone.equals(AppConstants.EST_TIMEZONE)
								&& defaulTimeZone
										.equals(AppConstants.TIMEZONE_EASTERN)) {
							if (!RMDCommonUtility
									.isNullOrEmpty(objMassApplyCfgResponseType
											.getOnBoardStatusDate())) {
								objApplyCfgVO
										    .setOnBoardStatusDate(objMassApplyCfgResponseType
												.getOnBoardStatusDate());
							}

						} else {
							if (!RMDCommonUtility
									.isNullOrEmpty(objMassApplyCfgResponseType
											.getOnBoardStatusDate())) {
								onBoardStatusDate = RMDCommonUtility
										.stringToUSESTDate(
												objMassApplyCfgResponseType
														.getOnBoardStatusDate(),
												RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
								objApplyCfgVO
										.setOnBoardStatusDate(nonESTZoneFormat
												.format(onBoardStatusDate));
							}
						}
					}
					arlRCIConfigs.add(objApplyCfgVO);
				}
			}
			arrRCICfgResponseTypes = null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getRCIConfigs() method - VehicleCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return arlRCIConfigs;
	}
	
	/**
     * @Author :
     * @return :List<String>
     * @param :
     * @throws :RMDWebException
     * @Description: This method is Responsible for fetching Configurations of
     *               Types.
     * 
     */
    @Override
    public List<String> getAGTDeviceList() throws RMDWebException {
        final Map<String, String> pathParamsPastDays = new LinkedHashMap<String, String>();
        List<String> cfgList = null;
        try {
            pathParamsPastDays.put(AppConstants.LIST_NAME,
                    AppConstants.AGT_DEVICE_LIST);
            ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParamsPastDays);
            if (null != applParamResponseType
                    && applParamResponseType.length > 0) {
                cfgList = new ArrayList<String>(applParamResponseType.length);
                for (ApplicationParametersResponseType objApplicationParametersResponseType : applParamResponseType) {
                    cfgList.add(objApplicationParametersResponseType
                            .getLookupValue());
                }
            }
            applParamResponseType = null;
        } catch (Exception rmdEx) {
            rmdWebLogger
                    .error("RMDWebException occured in getAGTDeviceList() method - MassApplyCfgServiceImpl",
                            rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }

        return cfgList;
    }
}
