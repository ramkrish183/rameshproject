package com.ge.trans.rmd.cm.valueobjects;

public class RxStatusHistoryVO 
{
	private String rxStatusDate;
	private String status;
	private String comments;

	
	public String getRxStatusDate() {
		return rxStatusDate;
	}
	public void setRxStatusDate(String rxStatusDate) {
		this.rxStatusDate = rxStatusDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	
	
}
