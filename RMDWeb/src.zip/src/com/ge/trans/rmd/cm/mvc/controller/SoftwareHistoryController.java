package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.SoftwareHistoryService;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.valueobjects.SoftwareHistoryVO;

@Controller
public class SoftwareHistoryController extends RMDBaseController  {
	
	@Autowired
	SoftwareHistoryService softwareHistoryService;
	@Autowired
	private ApplicationContext appContext;

	
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@RequestMapping(AppConstants.REQ_URI_SOFTWARE_HISTORY)
	public ModelAndView showSoftwareHistory(final HttpServletRequest request) throws RMDWebException, Exception {
		//request.setAttribute(AppConstants.FILTERFLAG, EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG)));
		try{
		final String strAssetId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_NUMBER));
		final String strCustomerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CUSTOMER_ID));
		final String strAssetGroup = request
				.getParameter(AppConstants.ASSET_GROUP_NAME);
		rmdWebLogger.info("strAssetId.............#### "+strAssetId+"strCustomerId.......... "+strCustomerId);
		request.setAttribute(AppConstants.REQ_PARAM_ASSTNUM, strAssetId);
		request.setAttribute(AppConstants.WS_PARAM_ASSTGRP, strAssetGroup);
		request.setAttribute(AppConstants.WS_PARAM_CUSTID, strCustomerId);
		
		 List<SoftwareHistoryVO> historyVOs = softwareHistoryService.viewSoftwareHistory(strAssetId, strCustomerId);
		 request.setAttribute(AppConstants.SOFTWARE_HISTORY_VO, historyVOs);
		}catch (Exception ex) {
			rmdWebLogger
			.error("Exception occured in showSoftwareHistory  method in SoftwareHistoryController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return new ModelAndView(AppConstants.VIEW_SOFTWARE_HISTORY);
	}

	
	@RequestMapping(value = AppConstants.EXPORT_SOFTWARE_HISTORY, method = RequestMethod.GET)
	public void exportsoftwareHistoryManagementPage(@RequestParam(value = AppConstants.EXPORTTYPE) final String exportType,@RequestParam(value = AppConstants.WS_PARAM_ASSTNUM) final String assetNumber,
			@RequestParam(value = AppConstants.REPORTS_CUSTOMER_ID) final String customerId,final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws IOException, GenericAjaxException, RMDWebException {
		List<SoftwareHistoryVO> historyVOs = new ArrayList<SoftwareHistoryVO>();
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		
		 String strAssetId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_NUMBER));
		 String strCustomerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CUSTOMER_ID));
		strAssetId = (String) request.getAttribute(AppConstants.REQ_PARAM_ASSTNUM);
		strCustomerId = (String) request.getAttribute(AppConstants.WS_PARAM_CUSTID);
		

		try {
			 historyVOs = softwareHistoryService.viewSoftwareHistory(assetNumber, customerId);
			csvContent = convertToCSVUsers(historyVOs, locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.SOFTWARE_HISTORY_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);

			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);

			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in exportsoftwareHistoryManagementPage method in SoftwareHistoryController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}
		}
	}
	
	/**
	 * @Description:This method is used convert User management List into csv format
	 * @return: String
	 * @param:List<UserManagementBean> userMgmntBeanList, Locale locale
	 */
	private String convertToCSVUsers(
			List<SoftwareHistoryVO> softwareHistoryList, Locale locale) {
		String csvContent = null;
		StringBuffer strBufferAssetHeader = new StringBuffer();
		try {
			strBufferAssetHeader.append(appContext.getMessage(
					AppConstants.SOFTWARE_HISTORY_MANAGEMENT_HEADER, null, locale));
			strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			for (SoftwareHistoryVO softwareHistoryVO : softwareHistoryList) {
				strBufferAssetHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE + softwareHistoryVO.getDataSyncHdr()
						+ AppConstants.QUOTE
						+ RMDCommonConstants.COMMMA_SEPARATOR);
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ softwareHistoryVO.getDataSyncRd()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				if (null != softwareHistoryVO.getDeviceReporting()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ softwareHistoryVO.getDeviceReporting()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != softwareHistoryVO.getSdisVersion()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ softwareHistoryVO.getSdisVersion()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != softwareHistoryVO.getDataSoftwarewasReported()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ softwareHistoryVO.getDataSoftwarewasReported()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != softwareHistoryVO.getActive()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ softwareHistoryVO.getActive()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != softwareHistoryVO.getConfigurationFile()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ softwareHistoryVO.getConfigurationFile()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				if (null != softwareHistoryVO.getUpdatedBy()) {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ softwareHistoryVO.getUpdatedBy()
							+ AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				} else {
					strBufferAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + AppConstants.QUOTE
							+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
				strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBufferAssetHeader.toString();
		} catch (Exception exception) {
			rmdWebLogger.error("Export to CSV Software History"
					+ exception.getMessage());
		}
		return csvContent;
	}
	
	/*@RequestMapping(value = AppConstants.REQ_URI_VIEW_SOFTWARE_HISTORY_DETAILS, method = RequestMethod.GET)
	@ResponseBody
	public List<SoftwareHistoryVO> softwareHistoryDetails(
			final HttpServletRequest request) throws Exception {
		rmdWebLogger
				.debug("SoftwareHistoryController : Inside softwareHistoryDetails() method:::::START ");
		
		final HttpSession session = request.getSession(false);
		final String strAssetId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_NUMBER));
		final String strCustomerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CUSTOMER_ID));
		rmdWebLogger.info("strAssetId.............#### "+strAssetId+"strCustomerId.......... "+strCustomerId);
		
		//rmdWebLogger.info("assetNumber.............#### "+assetNumber+"customerId.......... "+customerId);
		//SoftwareHistoryServiceDetailsImpl softwareHistoryService = new SoftwareHistoryServiceDetailsImpl();
		List<SoftwareHistoryVO> historyVOs = softwareHistoryService.viewSoftwareHistory(strAssetId, strCustomerId);
		return historyVOs;
	}*/
}
