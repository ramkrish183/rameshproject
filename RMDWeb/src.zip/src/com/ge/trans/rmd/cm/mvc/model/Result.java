package com.ge.trans.rmd.cm.mvc.model;

import java.util.List;

public class Result<T> {
	
	private List<String> colNames;
	private List<T> colModels;
	
	public List<String> getColNames() {
		return colNames;
	}
	public void setColNames(final List<String> colNames) {
		this.colNames = colNames;
	}
	public List<T> getColModels() {
		return colModels;
	}
	public void setColModels(final List<T> colModels) {
		this.colModels = colModels;
	}
}
