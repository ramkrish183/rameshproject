/**
 * 
 */
package com.ge.trans.rmd.cm.valueobjects;

/**
 * @author 212338353
 *
 */
public class LDVRTemplateRequestTimeVO {
	
	private String requestStartTime;
	
	private String requestEndTime;

	/**
	 * @return the requestStartTime
	 */
	public String getRequestStartTime() {
		return requestStartTime;
	}

	/**
	 * @param requestStartTime the requestStartTime to set
	 */
	public void setRequestStartTime(String requestStartTime) {
		this.requestStartTime = requestStartTime;
	}

	/**
	 * @return the requestEndTime
	 */
	public String getRequestEndTime() {
		return requestEndTime;
	}

	/**
	 * @param requestEndTime the requestEndTime to set
	 */
	public void setRequestEndTime(String requestEndTime) {
		this.requestEndTime = requestEndTime;
	}
	
	

}
