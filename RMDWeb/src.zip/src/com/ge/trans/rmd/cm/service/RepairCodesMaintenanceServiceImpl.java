/**
 * ============================================================
 * Classification: GE Confidential
 * File : RepairCodesMaintenanceServiceImpl.java
 * Description :
 *
 * Package : com.ge.trans.rmd.cm.service;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on :
 * History
 * Modified By : Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.RepairCodeVO;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.Model;
import com.ge.trans.rmd.services.cases.valueobjects.RepairCodeDetailsType;


@Service
public class RepairCodesMaintenanceServiceImpl extends RMDBaseServiceImpl implements RepairCodesMaintenanceService {

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
	.getLogger(getClass());
	
	@Autowired
	WebServiceInvoker webServiceInvoker;

	
	/**
	 * @Author:
	 * @param :
	 * @return:Map<String, String>
	 * @throws:RMDWebException,Exception
	 * @Description: This method is used for fetching values to populate select
	 *               by drop down.
	 */
	@Override
	public Map<String, String> getRepairCodesSelectBy() throws RMDWebException,
			Exception {
		Map<String, String> selectByMap = new HashMap<String, String>();
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		try {
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.REPAIRCODE_SELECT_BY_OPTIONS);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			for (int i = 0; i < applParamResponseType.length; i++) {
				String selectBy = applParamResponseType[i].getLookupValue();
				selectByMap.put(selectBy, selectBy);
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getRepairCodesSelectBy() method - RepairCodesMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return selectByMap;
	}

	/**
	 * @Author:
	 * @param :
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching values to populate status
	 *               drop down.
	 */
	@Override
	public Map<String, String> getRepairCodesStatus() throws RMDWebException,
			Exception {
		Map<String, String> selectByMap = new LinkedHashMap<String, String>();
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		try {
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.REPAIRCODE_STATUS_OPTIONS);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			for (int i = 0; i < applParamResponseType.length; i++) {
				String selectBy = applParamResponseType[i].getLookupValue();
				selectByMap.put(selectBy, selectBy);
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getRepairCodesStatus() method - RepairCodesMaintenanceServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return selectByMap;
	}

	/**
	 * @Author:
	 * @param:String selectBy, String condition, String status, String model,
	 *               String value
	 * @return:List<RepairCodeVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching repair codes based on
	 *               search criteria
	 */
	@Override
	public List<RepairCodeVO> getRepairCodesList(String selectBy,
			String condition, String status, String model, String value)
			throws RMDWebException, Exception {
		rmdWebLogger
				.debug("RepairCodesMaintenanceServiceImpl : Inside getRepairCodesList() method:::::START");
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		RepairCodeDetailsType[] objRepairCodeDetailsTypeList = null;
		List<RepairCodeVO> objRepairCodeVOList = new ArrayList<RepairCodeVO>();
		RepairCodeVO objRepairCodeVO = null;
		try {
			queryParamsMap.put(AppConstants.CREATCASE_WSPARAM_SELECTBY,
					selectBy);
			queryParamsMap.put(AppConstants.CREATCASE_WSPARAM_CONDITION,
					condition);
			queryParamsMap.put(AppConstants.STATUS, status);
			queryParamsMap.put(AppConstants.CREATCASE_WSPARAM_MODELTYPE, model);
			queryParamsMap.put(AppConstants.VALUE, value);
			objRepairCodeDetailsTypeList = (RepairCodeDetailsType[]) webServiceInvoker
					.get(ServiceConstants.GET_REPAIRCODE_LIST, null,
							queryParamsMap, null, RepairCodeDetailsType[].class);
			for (RepairCodeDetailsType objRepairCodeDetailsType : objRepairCodeDetailsTypeList) {
				objRepairCodeVO = new RepairCodeVO();
				objRepairCodeVO.setRepairCode(objRepairCodeDetailsType
						.getRepairCode());
				objRepairCodeVO.setRepairDesc(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(objRepairCodeDetailsType
						.getRepaidCodeDesc())));
				objRepairCodeVO.setStatus(objRepairCodeDetailsType.getStatus());
				objRepairCodeVO.setModels(objRepairCodeDetailsType.getModels());
				objRepairCodeVOList.add(objRepairCodeVO);
			}
			objRepairCodeDetailsTypeList=null;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getRepairCodesList method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return objRepairCodeVOList;
	}

	/**
	 * @Author:
	 * @param :String repairCode, String repairCodeDesc, String flag
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for validating the repair codes and
	 *               repair code description.
	 */
	@Override
	public String repairCodeValidations(String repairCode,
			String repairCodeDesc, String flag) throws RMDWebException,
			Exception {
		rmdWebLogger
				.debug("RepairCodesMaintenanceServiceImpl : Inside repairCodeValidations() method:::::START");
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		String result = null;
		try {
			queryParamsMap.put(AppConstants.REPAIR_CODE, repairCode);
			queryParamsMap.put(AppConstants.REPAIR_CODE_DESC, repairCodeDesc);
			queryParamsMap.put(AppConstants.FLAG, flag);
			result = (String) webServiceInvoker.get(
					ServiceConstants.REPAIRCODE_VALIDATIONS, null,
					queryParamsMap, null, String.class);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in repairCodeValidations method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	@Override
	public String addRepairCodes(String repairCode, String repairCodeDesc,
			String status, String model) throws RMDWebException, Exception {
				rmdWebLogger
				.debug("RepairCodesMaintenanceServiceImpl : Inside addRepairCodes() method:::::START");
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		String result=null;
		try {
			queryParamsMap.put(AppConstants.REPAIR_CODE,
					repairCode);
			queryParamsMap.put(AppConstants.REPAIR_CODE_DESC,
					repairCodeDesc);
			queryParamsMap.put(AppConstants.STATUS, status);
			queryParamsMap.put(AppConstants.CREATCASE_WSPARAM_MODELTYPE, model);
			result = (String) webServiceInvoker
					.get(ServiceConstants.ADD_REPAIR_CODES, null,
							queryParamsMap, null, String.class);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in addRepairCodes method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		
		return result;
			}

	@Override
	public String updateRepairCodes(String repairCode, String repairCodeDesc,
			String status, String model) throws RMDWebException, Exception {
				rmdWebLogger
				.debug("RepairCodesMaintenanceServiceImpl : Inside updateRepairCodes() method:::::START");
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		String result=null;
		try {
			queryParamsMap.put(AppConstants.REPAIR_CODE,
					repairCode);
			queryParamsMap.put(AppConstants.REPAIR_CODE_DESC,
					repairCodeDesc);
			queryParamsMap.put(AppConstants.STATUS, status);
			queryParamsMap.put(AppConstants.CREATCASE_WSPARAM_MODELTYPE, model);
			result = (String) webServiceInvoker
					.get(ServiceConstants.UPDATE_REPAIR_CODES, null,
							queryParamsMap, null, String.class);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in updateRepairCodes method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		
		return result;
	}
		@Override
		public Map<String, String> getRepairCodesConditions()
				throws RMDWebException, Exception {
			Map<String, String> selectByMap = new LinkedHashMap<String, String>();
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			try {
				pathParams.put(AppConstants.LIST_NAME,
						AppConstants.REPAIRCODE_CONDITION_OPTIONS);
				final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
				for (int i = 0; i < applParamResponseType.length; i++) {
					String selectBy = applParamResponseType[i].getLookupValue();
					selectByMap.put(selectBy, selectBy);
				}
			} catch (Exception rmdEx) {
				rmdWebLogger
						.error("RMDWebException occured in getRepairCodesConditions() method - RepairCodesMaintenanceServiceImpl",
								rmdEx);
				RMDWebErrorHandler.handleException(rmdEx);
			}
			return selectByMap;
		}
		
}
