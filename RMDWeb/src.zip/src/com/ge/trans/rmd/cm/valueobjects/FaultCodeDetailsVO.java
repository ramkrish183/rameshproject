package com.ge.trans.rmd.cm.valueobjects;


public class FaultCodeDetailsVO {

	
	 private String controllerConfig;
	 private String faultCode;
	 private String faultDesc;
	 private String faultDetail;
	 private String faultCodeObjid;
	 
	public String getControllerConfig() {
		return controllerConfig;
	}
	public void setControllerConfig(String controllerConfig) {
		this.controllerConfig = controllerConfig;
	}
	public String getFaultCode() {
		return faultCode;
	}
	public void setFaultCode(String faultCode) {
		this.faultCode = faultCode;
	}
	public String getFaultDesc() {
		return faultDesc;
	}
	public void setFaultDesc(String faultDesc) {
		this.faultDesc = faultDesc;
	}
	public String getFaultDetail() {
		return faultDetail;
	}
	public void setFaultDetail(String faultDetail) {
		this.faultDetail = faultDetail;
	}
	/**
	 * @return the faultCodeObjid
	 */
	public String getFaultCodeObjid() {
		return faultCodeObjid;
	}
	/**
	 * @param faultCodeObjid the faultCodeObjid to set
	 */
	public void setFaultCodeObjid(String faultCodeObjid) {
		this.faultCodeObjid = faultCodeObjid;
	}
	
	 
	 
}
