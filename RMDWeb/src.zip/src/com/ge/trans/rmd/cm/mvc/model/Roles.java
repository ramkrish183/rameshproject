package com.ge.trans.rmd.cm.mvc.model;

public class Roles {
 
	private String ruleDefId;

	public String getRuleDefId() {
		return ruleDefId;
	}

	public void setRuleDefId(final String ruleDefId) {
		this.ruleDefId = ruleDefId;
	}
}
