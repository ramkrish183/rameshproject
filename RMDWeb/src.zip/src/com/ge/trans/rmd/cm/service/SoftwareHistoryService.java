package com.ge.trans.rmd.cm.service;

import java.util.List;

import com.ge.trans.rmd.cm.valueobjects.MessageHistoryResponseVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.valueobjects.SoftwareHistoryVO;

public interface SoftwareHistoryService {
	
	public List<SoftwareHistoryVO> viewSoftwareHistory(String strAssetId, String strCustomerId) throws RMDWebException, Exception;


}
