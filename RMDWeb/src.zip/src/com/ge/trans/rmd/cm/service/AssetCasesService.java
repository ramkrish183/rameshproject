package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import com.ge.trans.rmd.cm.valueobjects.CaseScoreRepairCodeVO;
import com.ge.trans.rmd.cm.valueobjects.AssetInstalledProductVO;
import com.ge.trans.rmd.cm.valueobjects.AssetLastFaultStatusVO;
import com.ge.trans.rmd.cm.valueobjects.AssetLocatorResponseVO;
import com.ge.trans.rmd.cm.valueobjects.CaseActionVO;
import com.ge.trans.rmd.cm.valueobjects.CaseConversionBean;
import com.ge.trans.rmd.cm.valueobjects.CaseHistoryVO;
import com.ge.trans.rmd.cm.valueobjects.CaseMgmtUsersDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.CaseTrendDataVO;
import com.ge.trans.rmd.cm.valueobjects.CaseTypeBean;
import com.ge.trans.rmd.cm.valueobjects.CloseOutRepairCodeVO;
import com.ge.trans.rmd.cm.valueobjects.CustomerFdbkVO;
import com.ge.trans.rmd.cm.valueobjects.DeliverSummaryVO;
import com.ge.trans.rmd.cm.valueobjects.MaterialUsageVO;
import com.ge.trans.rmd.cm.valueobjects.QueueDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.RecommDeliverVO;
import com.ge.trans.rmd.cm.valueobjects.RxDeliveryAttachmentVO;
import com.ge.trans.rmd.cm.valueobjects.RxDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.RxHistoryVO;
import com.ge.trans.rmd.cm.valueobjects.RxStatusHistoryVO;
import com.ge.trans.rmd.cm.valueobjects.SolutionDetailVO;
import com.ge.trans.rmd.cm.valueobjects.StickyNotesDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.TopNoActionBean;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.beans.CaseHistoryBean;
import com.ge.trans.rmd.common.beans.CaseSolutionVO;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.beans.SolutionBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.GenNotesVO;

public interface AssetCasesService {
    /**
     * @author IgatePatni
     * @param CaseBean
     * @return List<CaseBean>
     * @throws RMDWebException
     * @throws Exception
     * @Description:
     */
    Future<List<CaseBean>> getCases(CaseBean caseBean, String lookBackDays) throws RMDWebException, Exception;
    List<SolutionBean> getAlternateSolutions(CaseBean caseBean) throws RMDWebException, Exception;
    CaseHistoryBean getCaseHistory(CaseBean caseBean) throws RMDWebException, Exception;
    String postNotes(NotesBean notesBean) throws RMDWebException, Exception;
    List<String> getCaseListLookBackDays(String listName) throws RMDWebException, Exception;
    /**
     * @author IgatePatni
     * @param assetNumber
     * @param userVO
     * @param assetOverviewBean
     * @return
     * @throws RMDWebException
     * @throws Exception
     */
    public Future<AssetOverviewBean> getVehicleCommStatus(final AssetOverviewBean assetOverviewBean)
            throws RMDWebException, Exception;
    /**
     * @author GE
     * @param assetOverviewBean
     * @return
     * @throws RMDWebException
     * @throws Exception
     */
    public Future<AssetLastFaultStatusVO> getLastFaultStatus(final AssetOverviewBean assetOverviewBean)
            throws RMDWebException, Exception;

    /**
     * @author IgatePatni
     * @param assetNumber
     * @return
     * @throws RMDWebException
     * @throws Exception
     */
    public Future<AssetOverviewBean> getAssets(final AssetOverviewBean assetOverviewBean) throws RMDWebException,
            Exception;
    /**
     * @param caseid
     *            ,timezone
     * @Author:
     * @param case id
     * @return CaseBean
     * @Description: return the list of all the rx associated with the case
     */
    List<SolutionDetailVO> getCaseRxHistory(String caseId, String timezone) throws RMDWebException, Exception;
    
    Future<AssetInstalledProductVO> getAssetInstalledProduct(AssetOverviewBean overviewBean) throws RMDWebException,
            Exception;

    Future<List<CaseTypeBean>> getCaseType() throws RMDWebException, Exception;
    /**
     * @Author :
     * @return :List<QueueDetailsVO>
     * @param : caseId
     * @throws :RMDWebException
     * @Description:This method is used for fetching a list of Dynamic work QueueNames from Data
     *                   Base.
     */

    public List<QueueDetailsVO> getQueueNames(String caseId) throws RMDWebException, Exception;

    /**
     * @Author :
     * @return :String
     * @param :queueId,caseId,userId
     * @throws :RMDWebException
     * @Description:This method is used for a dispatching case to dynamic work queues selected by
     *                   the user.
     */
    public String dispatchCaseToWorkQueue(final long queueId, final String caseId, final String userId)
            throws RMDWebException, Exception;

    /**
     * @Author :
     * @return :String
     * @param :AddNotesEoaServiceVO
     * @throws : RMDWebException
     * @Description:This method is used for adding Case notes for a given case.
     */
    public String addNotesToCase(final NotesBean bean) throws RMDWebException, Exception;

    /**
     * @param string
     * @Author :
     * @return :StickyNotesDetailsVO
     * @param :caseId
     * @throws :RMDWebException,Exception
     * @Description:This method is used fetching case Sticky notes details for a given case.
     */
    public StickyNotesDetailsVO fetchStickyCaseNotes(final String caseId, String timezone) throws RMDWebException,
            Exception;
    /**
     * @Author :
     * @return :StickyNotesDetailsVO
     * @param :caseId
     * @throws :RMDWebException,Exception
     * @Description:This method is used fetching unit Sticky notes details for a given case.
     */
    public StickyNotesDetailsVO fetchStickyUnitNotes(final String caseId, String timezone) throws RMDWebException,
            Exception;

    /**
     * @Author:
     * @param:
     * @return:List<CaseMgmtUsersDetailsVO>
     * @throws:RMDWebException
     * @Description: This method fetches the users by invoking web services getUserNames() method.
     */

    List<CaseMgmtUsersDetailsVO> getCaseMgmtUsersDetails() throws RMDWebException;
    /**
     * @Author:
     * @param:userId ,caseId
     * @return:String
     * @throws:RMDWebException
     * @Description: This method assigns case to the user by invoking web services getOwnerForCase()
     *               method.
     */
    String assignCaseToUser(final String userId, final String caseId) throws RMDWebException;
    /**
     * @Author:
     * @param:caseId
     * @return:String
     * @throws:RMDWebException
     * @Description: This method fetches the owner for respective case id by invoking web services
     *               getOwnerForCase() method.
     */
    CaseBean getCaseCurrentOwnerDetails(final String caseId) throws RMDWebException;
    /**
     * @Author:
     * @param:caseId
     * @return:List<CaseHistoryVO>
     * @throws:RMDWebException
     * @Description: This method fetches the set of activities based on case id by invoking web
     *               services getCaseHistory() method.
     */
    List<CaseHistoryVO> getCaseHistory(final String caseId, String timezone) throws RMDWebException;
    List<CaseBean> getAssetCases(CaseBean caseBean) throws RMDWebException, Exception;
    /**
     * @Author :
     * @return :String
     * @param :caseStickyObjId,unitStickyObjId,applyLevel
     * @throws :RMDWebException,Exception
     * @Description:This method is used for removing a unit Level as well as case Level Sticky Notes
     *                   for a given case.
     */
    public String removeStickyNotes(final String unitStickyObjId, final String caseStickyObjId, final String applyLevel)
            throws RMDWebException, Exception;

    /**
     * @Author:
     * @param :
     * @return:List <CaseBean>
     * @throws:RMDWebException
     * @throws:GenericAjaxException
     * @Description: This method is used to fetching CaseTypes for a given case.
     */
    List<CaseTypeBean> getCaseTypes() throws RMDWebException, Exception;

    /**
     * @Author:
     * @param :
     * @return:List <CaseBean>
     * @throws:RMDWebException
     * @throws:GenericAjaxException
     * @Description: This method is used to update the Case Details.
     */
    String updateCaseDetails(String caseType, String caseTitle, String caseId) throws RMDWebException;

    /**
     * @Author:
     * @param :
     * @return:Map<String, String>
     * @throws:RMDWebException
     * @throws:GenericAjaxException
     * @Description: This method is used to get values from lookup to populate the subsystem drop
     *               downlist.
     */
    public Map<String, String> getSubSystem() throws RMDWebException;

    /**
     * @Author:
     * @param :
     * @return:List <CaseBean>
     * @throws:RMDWebException
     * @throws:GenericAjaxException
     * @Description: This method is used to fetch the solutions for given case.
     */
    public List<CaseBean> getSolutionsForCase(String caseObjId, String timeZone) throws RMDWebException;

    /**
     * @Author:
     * @param :String caseObjId
     * @return:String
     * @throws:RMDWebException
     * @throws:GenericAjaxException
     * @Description: This method is used to add a recommendation to a given Case.
     */
    public String addRxForCase(CaseBean objcaseBean) throws RMDWebException;
    /**
     * @Author:
     * @param :CaseBean objcaseBean
     * @return:String
     * @throws:RMDWebException
     * @throws:GenericAjaxException
     * @Description: This method is used to delete a recommendation from a given Case.
     */
    public String deleteRxForCase(CaseBean objcaseBean) throws RMDWebException;

    /**
     * @Author:
     * @param :String caseId
     * @return:CaseBean
     * @throws:RMDWebException
     * @throws:GenericAjaxException
     * @Description: This method is used for fetching the case Information.It accepts caseId as an
     *               Input Parameter and returns caseBean List.
     */

    public CaseBean getCaseInfo(String caseId, String timeZone) throws RMDWebException;

    /**
     * @Author:
     * @param:caseId,caseObjid,userName
     * @return:String
     * @throws:RMDWebException
     * @Description: This method reOpenCase by invoking web services reOpenCase() method.
     */

    public String reOpenCase(String caseId, String caseObjid, String userName) throws RMDWebException;

    /**
     * @Author :
     * @return :List<RxHistoryVO>
     * @param :caseObjId, timezone
     * @throws :RMDWebException
     * @Description:This method fetches the Rx History based on caseObj id by invoking web services
     *                   getRxHistory() method.
     */
    List<RxHistoryVO> getRxHistory(String caseObjId, String timezone) throws RMDWebException;
    /**
     * @Author :
     * @return :List<RxStatusHistoryVO>
     * @param :caseObjId, timezone
     * @throws :RMDWebException
     * @Description:This method fetches the RxStatus History based on servicerReq id by invoking web
     *                   services getRxstatusHistory() method.
     */
    List<RxStatusHistoryVO> getRxstatusHistory(String servicerReqId, String timezone) throws RMDWebException;
    /**
     * @Author :
     * @return :String
     * @param :caseObjId
     * @throws :RMDWebException
     * @Description:This method fetches the Good Feedback based on rxCaseId id by invoking web
     *                   services getClosureFdbk() method.
     */
    String getClosureFdbk(String rxCaseId) throws RMDWebException;
    /**
     * @Author :
     * @return :List<CloseOutRepairCodeVO>
     * @param :custFdbkObjId , serviceReqId
     * @throws :RMDWebException
     * @Description:This method fetches the CloseOut Repair Codes based on custFdbkObj id &
     *                   serviceReqId by invoking web services getCloseOutRepairCode() method.
     */
    List<CloseOutRepairCodeVO> getCloseOutRepairCode(String custFdbkObjId, String serviceReqId) throws RMDWebException;
    /**
     * @Author :
     * @return :List<CloseOutRepairCodeVO>
     * @param :caseId
     * @throws :RMDWebException
     * @Description:This method fetches the Attached Details based on case id by invoking web
     *                   services getAttachedDetails() method.
     */
    List<CloseOutRepairCodeVO> getAttachedDetails(String caseId) throws RMDWebException;
    /**
     * @Author :
     * @return :String
     * @param :caseObjId
     * @throws :RMDWebException
     * @Description:This method fetches the Rx Notes based on caseObj id by invoking web services
     *                   getRxNote() method.
     */
    String getRxNote(String caseObjId) throws RMDWebException;
    /**
     * @Author :
     * @return :List<CustomerFdbkVO>
     * @param :caseObjId
     * @throws :RMDWebException
     * @Description:This method fetches the ServiceReqId & CustFdbkObjId based on caseObj id by
     *                   invoking web services getServiceReqId() method.
     */
    List<CustomerFdbkVO> getServiceReqId(String caseObjId) throws RMDWebException;

    /**
     * @Author:
     * @param:RecommDelVO objDelVO
     * @return:String
     * @throws:RMDWebException
     * @Description: This method delivers an Recommendation by invoking web services deliverRx()
     *               method.
     */
    public String deliverRx(RecommDeliverVO objDelVO) throws RMDWebException;

    /**
     * @Author:
     * @param:caseId,caseObjid,userName
     * @return:String
     * @throws:RMDWebException
     * @Description: This method modifies a recommendation by invoking web services modifyRx()
     *               method.
     */
    public String modifyRx(RecommDeliverVO objDelVO) throws RMDWebException;

    /**
     * @Author:
     * @param:caseId,caseObjid,userName
     * @return:String
     * @throws:RMDWebException
     * @Description: This method replaces a recommendation by invoking web services replaceRx()
     *               method.
     */
    public String replaceRx(RecommDeliverVO objDelVO) throws RMDWebException;

    /**
     * @Author:
     * @param:String caseId
     * @return:RecommDelVO
     * @throws:RMDWebException
     * @Description: This method is used for fetching pendingFdbkServiceStatus by invoking web
     *               services pendingFdbkServiceStatus() method.
     */
    public List<RecommDeliverVO> pendingFdbkServiceStatus(String caseId) throws RMDWebException;

    /**
     * @Author:
     * @param:String fdbkObjid
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching ServiceReqId by invoking web services
     *               getServiceReqIdStatus() method.
     */

    public String getServiceReqIdStatus(String fdbkObjid) throws RMDWebException;

    /**
     * @Author:
     * @param:String caseObjid,String rxObjid
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching DeliveryDate by invoking web services
     *               getDelvDateForRx() method.
     */

    public String getDelvDateForRx(String caseObjid, String rxObjid) throws RMDWebException;

    /**
     * @Author:
     * @param:String caseObjid,String rxObjid,String fromScreen,String custFdbkObjId
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching Msdc Notes by invoking web services
     *               getMsdcNotes() method.
     */
    public String getMsdcNotes(String caseObjid, String rxObjid, String fromScreen,String custFdbkObjId) throws RMDWebException;

    /**
     * @Author:
     * @param:String caseId
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching requestId by invoking web services getT2Req()
     *               method.
     */

    public String getT2Req(String caseId) throws RMDWebException;

    /**
     * @Author:
     * @param:String caseObjid
     * @return:String
     * @throws:RMDWebException
     * @Description: This method fetches Unit Ship Details by invoking web services
     *               getUnitShipDetails() method.
     */

    public String getUnitShipDetails(String caseObjid) throws RMDWebException;

    /**
     * @Author:
     * @param:String caseid
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching case Score by invoking web services
     *               getCaseScore() method.
     */

    public List<RecommDeliverVO> getCaseScore(String caseId) throws RMDWebException;

    /**
     * @Author:
     * @param:String rxObjid
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching readyToDeliver date by invoking web services
     *               getReadyToDelv() method.
     */

    public String getReadyToDelv(String rxObjid) throws RMDWebException;

    /**
     * @Author:
     * @param:RecommDeliverVOe
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching pendingRx Details Id by invoking web services
     *               getPendingRcommendation() method.
     */

    public RecommDeliverVO getPendingRcommendation(String caseId) throws RMDWebException;

    /**
     * @Author:
     * @param:String customerName
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for checking Whether delivery mechanism is present for
     *               particular Customer are not by invoking web services checkForDelvMechanism()
     *               method.
     */

    public String checkForDelvMechanism(String customerName) throws RMDWebException;
    /**
     * @Author :
     * @return :CustomerFdbkVO
     * @param :caseObjId
     * @throws :RMDWebException
     * @Description:This method fetches the Closure Details based on caseObj id by invoking web
     *                   services getClosureDetails() method.
     */
    public CustomerFdbkVO getClosureDetails(String caseObjId) throws RMDWebException;
    /**
     * @Author :
     * @return :String
     * @param :caseObjId,rxCaseId
     * @throws :RMDWebException
     * @Description: This method does eservice validation invoking doEserviceValidation()method in
     *               web services.
     */
    public String doEserviceValidation(String caseObjId, String rxCaseId) throws RMDWebException;
    public String checkForContollerConfig(String CaseObjId, String rxObjId, String model) throws RMDWebException;
    /**
     * @Author :
     * @return :String
     * @param : caseBean
     * @throws :RMDWebException
     * @Description: This method is used to get the enabled Rx ids for a case for close and append.
     */
    public List<String> getEnabledRxs(CaseBean caseBean) throws RMDWebException, Exception;
    /**
     * @Author :
     * @return :String
     * @param : caseBean
     * @throws :RMDWebException
     * @Description: This method is used to append rx to a case
     */
    public String appendRx(CaseBean caseBean) throws RMDWebException, Exception;

    /**
     * @Author :
     * @return :String
     * @param : caseBean
     * @throws :RMDWebException
     * @Description: This method is used to merge rx to a case
     */

    public String mergeRx(CaseBean caseBean) throws RMDWebException, Exception;

    public List<DeliverSummaryVO> toolOutputDeliver(CaseActionVO objCaseActionVO) throws RMDWebException, Exception;

    /**
     * @Author :
     * @return :String
     * @param : caseBean
     * @throws :RMDWebException
     * @Description: This method is used to check for active Rxs
     */
    public String activeRxExistsInCase(String appendFromCaseId) throws RMDWebException, Exception;
    String updateCaseTitle(CaseSolutionVO caseBeanCloseRx) throws RMDWebException, Exception;

    /**
     * @Author :
     * @return :String
     * @param : listName
     * @throws :RMDWebException
     * @Description: This method is used to get close option
     */
    public Map<String, String> getCloseOption(String listName) throws RMDWebException, Exception;

    /**
     * @Author :
     * @return :RxDetailsVO
     * @param : caseObjId,vehicleObjId
     * @throws :RMDWebException
     * @Description: This method is used to get Rx Details of the Case.
     */
    public RxDetailsVO getRxDetails(String caseObjId, String vehicleObjId) throws RMDWebException;
    /**
     * @Author:
     * @param:String vehicleObjId
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used check whether PP Asset History Button Has to Disable or
     *               Enable.
     */
    public String displayPPAssetHistoryBtn(String vehicleObjId) throws RMDWebException;

    /**
     * @Author :
     * @return :List<MaterialUsageVO>
     * @param :serviceReqId, lookUpDays,timezone
     * @throws :RMDWebException
     * @Description:This method fetches the list of material of the case based on servicerReq id,
     *                   lookUpDays by invoking web services getMaterialUsage() method.
     */
    public List<MaterialUsageVO> getMaterialUsage(String serviceReqId, String lookUpDays, String timeZone)
            throws RMDWebException;

    /**
     * @Author :Mohamed
     * @return :Future<AssetLocatorResponseVO>
     * @param :AssetOverviewBean assetBean
     * @throws Exception
     * @throws :RMDWebException
     * @Description:This method fetches the common section of the asset case by invoking web
     *                   services getAssetCaseCommSection() method.
     */
    Future<AssetLocatorResponseVO> getAssetCaseCommSection(final AssetOverviewBean assetBean) throws RMDWebException,
            Exception;
    public String addNotesToUnit(NotesBean notesbean) throws RMDWebException;
    public StickyNotesDetailsVO fetchStickyUnitLevelNotes(String assetNumber, String customerId, String assetGrpName,
            String timeZone) throws RMDWebException;

    /**
     * @Author :Vamsee
     * @return :Map<String,String>
     * @param :
     * @throws :RMDWebException
     * @Description:This method fetches list of GPOC Smart Shop Votes.
     */
    public Map<String, String> getGPOCSmartShopVotes() throws RMDWebException;

    /**
     * @Author :Vamshi
     * @return :String
     * @param :CaseSolutionVO objCaseSolutionVO
     * @throws :RMDWebException
     * @Description:This method is responsible for Casting the GPOC Users Vote.
     */

    public String castGPOCVote(CaseSolutionVO objCaseSolutionVO) throws RMDWebException;

    /**
     * @Author :Vamshi
     * @return :String
     * @param :String caseObjId
     * @throws :RMDWebException
     * @Description:This method is responsible for fetching previously Casted vote.
     */

    public String getPreviousVote(String caseObjId) throws RMDWebException;
    public Future<List<CaseTrendDataVO>> getOpenCommRXDetails() throws RMDWebException;
    public Future<CaseConversionBean> getCaseConversionDetails() throws RMDWebException;
    public String getCaseConversionPercentage() throws RMDWebException;
    public Future<TopNoActionBean> getTopNoActionRXDetails() throws RMDWebException;
    public List<GenNotesVO> getCommNotesDetails() throws RMDWebException;

    public String getAddRepCodeDetails(String caseId) throws RMDWebException;

    public String getLookUpRepCodeDetails(String repairCodeList) throws RMDWebException;
    
    List<CaseScoreRepairCodeVO> getCaseScoreRepairCodes(String rxCaseId) throws RMDWebException;
    public List<String> validateVehBoms(String customer,
            String rnh, String rn,
            String rxObjId,String fromScreen) throws RMDWebException;
    
    public List<RxDeliveryAttachmentVO> getRxDeliveryAttachments(String caseObjid, String rxObjid) throws RMDWebException;
    /**
     * @Author :
     * @return :RxDetailsVO
     * @param : caseObjId,vehicleObjId
     * @throws :RMDWebException
     * @Description: This method is used to get Rx Details of the Case.
     */
    public String getCaseRxDelvDetails(String caseId) throws RMDWebException;
    
}
