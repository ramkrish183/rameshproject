/**
 * ============================================================

 * Classification		: GE Confidential
 * File 				: QueueDetailsVO.java
 * Description 			:
 * Package 				: com.ge.trans.rmd.cm.valueobjects;
 * Author 				: iGATE Global Solutions Ltd.
 * Last Edited By 		:
 * Version 				: 1.0
 * Created on 			:
 * History				:
 * Modified By 			: Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */

package com.ge.trans.rmd.cm.valueobjects;

/*******************************************************************************
 * 
 * @Author 			:
 * @Version 		: 1.0
 * @Date Created	:
 * @Date Modified 	:
 * @Modified By 	:
 * @Contact 		:
 * @Description 	:This is plain POJO class which contains queueId,queueName
 *             		 Declarations along with their respective getters and setters.
 * @History 		:
 * 
 ******************************************************************************/
public class QueueDetailsVO {

	private String queueId;
	private String queueName;
	private String caseOwner;
	
	
	public String getCaseOwner() {
		return caseOwner;
	}

	public void setCaseOwner(String caseOwner) {
		this.caseOwner = caseOwner;
	}

	public String getQueueId() {
		return queueId;
	}

	public void setQueueId(String queueId) {
		this.queueId = queueId;
	}

	public String getQueueName() {
		return queueName;
	}

	public QueueDetailsVO() {
		super();

	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	

}
