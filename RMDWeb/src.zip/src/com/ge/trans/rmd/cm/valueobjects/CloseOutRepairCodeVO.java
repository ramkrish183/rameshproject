package com.ge.trans.rmd.cm.valueobjects;

import java.util.ArrayList;
import java.util.List;

public class CloseOutRepairCodeVO 
{
	private String id;
	private String task;
	private String feedback;
	private String repairCode ;
	private String description;
	private String repairCodeId;
	List<CloseRepairCodeVO> repairCodes;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTask() {
		return task;
	}
	public void setTask(String task) {
		this.task = task;
	}
	public String getFeedback() {
		return feedback;
	}
	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}
	public String getRepairCode() {
		return repairCode;
	}
	public void setRepairCode(String repairCode) {
		this.repairCode = repairCode;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getRepairCodeId() {
		return repairCodeId;
	}
	public void setRepairCodeId(String repairCodeId) {
		this.repairCodeId = repairCodeId;
	}
	public List<CloseRepairCodeVO> getRepairCodes() {
		return repairCodes;
	}

	public void setRepairCodes(List<CloseRepairCodeVO> repairCodes) {
		this.repairCodes = repairCodes;
	}
	public void addRepairCodes(CloseRepairCodeVO repairCode) {
		if(this.repairCodes == null){
			this.repairCodes = new ArrayList<CloseRepairCodeVO>();
		}
		this.repairCodes.add(repairCode);
	}
	
}
