/**
 * 
 */
package com.ge.trans.rmd.cm.valueobjects;

/**
 * @author MSHIRAJUDDIN
 *
 */
public class DataSetVO {
	
 private String dataSetName;
 private String parentSetName;
 
 private DataVO[] data;

/**
 * @return the dataSetName
 */
public String getDataSetName() {
	return dataSetName;
}

/**
 * @param dataSetName the dataSetName to set
 */
public void setDataSetName(String dataSetName) {
	this.dataSetName = dataSetName;
}

/**
 * @return the parentSetName
 */
public String getParentSetName() {
	return parentSetName;
}

/**
 * @param parentSetName the parentSetName to set
 */
public void setParentSetName(String parentSetName) {
	this.parentSetName = parentSetName;
}

/**
 * @return the data
 */
public DataVO[] getData() {
	return data;
}

/**
 * @param data the data to set
 */
public void setData(DataVO[] data) {
	this.data = data;
}



}
