package com.ge.trans.rmd.cm.valueobjects;

import com.ge.trans.rmd.common.beans.RMDBaseBean;

public class CaseSolutionVO extends RMDBaseBean  {
	
	String userId;
	String customerId;
	String assetGrpName;
	String assetNumber;	
	String urgency;
	String estRepairCode;
	String caseType;
	String solutionId;
	String solutionTitle;
	String caseId;
	String notes;
	String rxCaseId;
	String rxFeedBack;
	String rxFeedBackCode;
	String caseTitle;
	String userAlias;
	String action;
	String recomId;
	String taskDesc;
	String repairCodeId;
	String repairCode;
	String model;
	String searchBy;
	String SearchValue;
	String taskId;
	String errorString;
	String priority;
	String isReissue;
	
	public String getIsReissue() {
		return isReissue;
	}

	public void setIsReissue(String isReissue) {
		this.isReissue = isReissue;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getRepaidCodeDesc() {
		return repaidCodeDesc;
	}
	
	public String getErrorString() {
		return errorString;
	}
	public void setErrorString(String errorString) {
		this.errorString = errorString;
	}
	public void setRepaidCodeDesc(String repaidCodeDesc) {
		this.repaidCodeDesc = repaidCodeDesc;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public String getSearchBy() {
		return searchBy;
	}
	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}
	public String getSearchValue() {
		return SearchValue;
	}
	public void setSearchValue(String searchValue) {
		SearchValue = searchValue;
	}
	public String getTaskDesc() {
		return taskDesc;
	}
	public void setTaskDesc(String taskDesc) {
		this.taskDesc = taskDesc;
	}
	public String getRepairCodeId() {
		return repairCodeId;
	}
	public void setRepairCodeId(String repairCodeId) {
		this.repairCodeId = repairCodeId;
	}
	public String getRepairCode() {
		return repairCode;
	}
	public void setRepairCode(String repairCode) {
		this.repairCode = repairCode;
	}
	String repaidCodeDesc;

	
	public String getRecomId() {
		return recomId;
	}
	public void setRecomId(String recomId) {
		this.recomId = recomId;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	public String getCaseTitle() {
		return caseTitle;
	}
	public void setCaseTitle(String caseTitle) {
		this.caseTitle = caseTitle;
	}
	public String getRxCaseId() {
		return rxCaseId;
	}
	public void setRxCaseId(String rxCaseId) {
		this.rxCaseId = rxCaseId;
	}
	public String getRxFeedBack() {
		return rxFeedBack;
	}
	public void setRxFeedBack(String rxFeedBack) {
		this.rxFeedBack = rxFeedBack;
	}
	public String getRxFeedBackCode() {
		return rxFeedBackCode;
	}
	public void setRxFeedBackCode(String rxFeedBackCode) {
		this.rxFeedBackCode = rxFeedBackCode;
	}
	boolean isRxDelivered;
	boolean isCaseCreationSucess;
	public boolean isRxDelivered() {
		return isRxDelivered;
	}
	public void setRxDelivered(boolean isRxDelivered) {
		this.isRxDelivered = isRxDelivered;
	}
	public boolean isCaseCreationSucess() {
		return isCaseCreationSucess;
	}
	public void setCaseCreationSucess(boolean isCaseCreationSucess) {
		this.isCaseCreationSucess = isCaseCreationSucess;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public String getSolutionTitle() {
		return solutionTitle;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public void setSolutionTitle(String solutionTitle) {
		this.solutionTitle = solutionTitle;
	}
	public String getSolutionId() {
		return solutionId;
	}
	public void setSolutionId(String solutionId) {
		this.solutionId = solutionId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getAssetGrpName() {
		return assetGrpName;
	}
	public void setAssetGrpName(String assetGrpName) {
		this.assetGrpName = assetGrpName;
	}
	public String getAssetNumber() {
		return assetNumber;
	}
	public void setAssetNumber(String assetNumber) {
		this.assetNumber = assetNumber;
	}
	public String getUrgency() {
		return urgency;
	}
	public void setUrgency(String urgency) {
		this.urgency = urgency;
	}
	public String getEstRepairCode() {
		return estRepairCode;
	}
	public void setEstRepairCode(String estRepairCode) {
		this.estRepairCode = estRepairCode;
	}
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public String getUserAlias() {
		return userAlias;
	}
	public void setUserAlias(String userAlias) {
		this.userAlias = userAlias;
	}
}
