/**
 * ============================================================
 * File 			: KPIService.java
 * Description 		: Service interface for KPIService
 * Package 			: com.ge.trans.rmd.cm.service
 * Author 			: UST
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		: April 30, 2012
 * History
 * Modified By 		: Initial Release
 * Copyright (C) 2012 General Electric Company. All rights reserved
 * ============================================================
 */

package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.beans.KPIBean;
import com.ge.trans.rmd.cm.beans.OpenCasesBean;
import com.ge.trans.rmd.cm.valueobjects.KPITotalCountResponseTypeVO;

public interface KPIService {

	/**
	 * This method is used to fetch RxCount to be displayed in the KPI pie
	 * charts
	 * 
	 * @param openCaseBean
	 * @return
	 */
	public List<KPITotalCountResponseTypeVO> getRxKPIValues(
			final List<KPIBean> kpiNameList, final OpenCasesBean openCaseBean, final String userCustomer);

	/**
	 * This method is used to fetch default no.of days for each graph in the KPI
	 * pie charts
	 * 
	 * @param kpiDefaultLookupList
	 * @return
	 */
	public Map<String, Long> findDefaultNumberOfDays(
			List<String> kpiDefaultLookupList);

	/**
	 * This method is used get values for drop down values in the KPI pie charts
	 * 
	 * @param kpiLookupList
	 * @return
	 */
	public Map<String, List<String>> getDaysFromLookUp(
			List<String> kpiLookupList);
}
