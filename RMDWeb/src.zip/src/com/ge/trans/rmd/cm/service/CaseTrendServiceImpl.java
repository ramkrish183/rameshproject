package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.CaseTrendBean;
import com.ge.trans.rmd.cm.valueobjects.CaseTrendDataVO;
import com.ge.trans.rmd.cm.valueobjects.CaseTrendStatisticsBean;
import com.ge.trans.rmd.cm.valueobjects.OpenRXBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.vo.GenNotesVO;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseTrendResponseType;
import com.ge.trans.rmd.services.gpocnotes.valueobjects.GeneralNotesResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class CaseTrendServiceImpl implements CaseTrendService {

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	WebServiceInvoker webServiceInvoker;
	@Autowired
	CachedService cachedService;

	/**
	 * @Author:
	 * @param:
	 * @return:List<CaseTrendDataVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching delivered open rx count
	 *               for past 8 days.
	 */
	@Override
	public Future<List<OpenRXBean>> getOpenRXCount() {
		Map<String, String> queryParams = new LinkedHashMap<String, String>();
		CaseTrendResponseType[] caseTrendResponseType = null;
		OpenRXBean openRXBean = null;
		List<OpenRXBean> openRXBeanList = new ArrayList<OpenRXBean>();
		try {
			caseTrendResponseType = (CaseTrendResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_TOTAL_OPEN_RX_COUNT, null,
							queryParams, null, CaseTrendResponseType[].class);
			if (null != caseTrendResponseType
					&& caseTrendResponseType.length > 0) {
				for (CaseTrendResponseType objCaseTrendResponseType : caseTrendResponseType) {
					openRXBean = new OpenRXBean();
					openRXBean.setCreationRXDate(objCaseTrendResponseType
							.getCreationRXDate());
					openRXBean.setDay(objCaseTrendResponseType.getDay().trim());
					openRXBean.setCount(objCaseTrendResponseType
							.getRxCount());
					openRXBeanList.add(openRXBean);

				}
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getOpenRXCount() method of CaseTrendServiceImpl",
							ex);
		} finally {
			queryParams = null;
			caseTrendResponseType = null;
		}
		return new AsyncResult<List<OpenRXBean>>(openRXBeanList);
	}

	/**
	 * @Author:
	 * @param:
	 * @return:List<CaseTrendDataVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching created case type count
	 *               for past 24 hours.
	 */
	@Override
	public Future<CaseTrendBean> getCaseTrend() {
		Map<String, String> queryParams = new LinkedHashMap<String, String>();
		CaseTrendResponseType[] caseTrendResponseType = null;
		CaseTrendBean caseTrendDataVO = new CaseTrendBean();
		Map<String,Integer> caseTrend = new LinkedHashMap<String, Integer>();
		int count =0;
		int totalCount =0;
		try {
			caseTrendResponseType = (CaseTrendResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_TOTAL_CASE_TREND_COUNT, null,
							queryParams, null, CaseTrendResponseType[].class);
			if (null != caseTrendResponseType
					&& caseTrendResponseType.length > 0) {
				for (CaseTrendResponseType objCaseTrendResponseType : caseTrendResponseType) {
					
					if(caseTrend.containsKey(objCaseTrendResponseType
							.getProblemDesc())){
						count = caseTrend.get(objCaseTrendResponseType
							.getProblemDesc());
						totalCount = count + RMDCommonUtility.convertStringToInt(objCaseTrendResponseType
								.getRxCount());
						caseTrend.put(objCaseTrendResponseType
							.getProblemDesc(), totalCount);
						
					}
					else
					{
						caseTrend.put(objCaseTrendResponseType
							.getProblemDesc(), RMDCommonUtility.convertStringToInt(objCaseTrendResponseType
							.getRxCount()));
					}
					
				}
				
			}
			caseTrendDataVO.setCaseTrend(caseTrend);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getCaseTrend() method of CaseTrendServiceImpl",
							ex);
		} finally {
			queryParams = null;
			caseTrendResponseType = null;
		}
		return new AsyncResult<CaseTrendBean>(caseTrendDataVO);
	}

	/**
	 * @Author:
	 * @param:
	 * @return:List<CaseTrendDataVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching created case type count
	 *               for past 7 days.
	 */
	@Override
	public Future<CaseTrendStatisticsBean> getCaseTrendStatistics() {
		Map<String, String> queryParams = new LinkedHashMap<String, String>();
		CaseTrendResponseType[] caseTrendResponseType = null;
		CaseTrendDataVO caseTrendDataVO = null;
		List<CaseTrendDataVO> caseTrendDataVOList = new ArrayList<CaseTrendDataVO>();
		List<CaseTrendDataVO> arlGetCaseTrend = null;
		Map<String, Map<String, String>> hashMap = new LinkedHashMap<String, Map<String, String>>();
		Map<String, String> arlMap = null;
		List<ApplicationParametersResponseType> applParamResponseTypeList = null;
		List<String> arlcaseType = new ArrayList<String>();
		String previousDate = "";
		CaseTrendStatisticsBean beanMap = new CaseTrendStatisticsBean();
		try {
			applParamResponseTypeList = cachedService.getAllLookupValues().get(
					AppConstants.CASE_TREND_GRAPH_CASE_TYPES);
			if (applParamResponseTypeList != null
					&& !applParamResponseTypeList.isEmpty()) {

				for (ApplicationParametersResponseType objResponse : applParamResponseTypeList) {
					arlcaseType.add(objResponse.getLookupValue());
				}
			}
			caseTrendResponseType = (CaseTrendResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_TOTAL_CASE_TREND_STAT_COUNT,
							null, queryParams, null,
							CaseTrendResponseType[].class);
			if (null != caseTrendResponseType
					&& caseTrendResponseType.length > 0) {
				for (CaseTrendResponseType objCaseTrendResponseType : caseTrendResponseType) {
					caseTrendDataVO = new CaseTrendDataVO();
					caseTrendDataVO.setCreationRXDate(objCaseTrendResponseType
							.getCreationRXDate());
					caseTrendDataVO.setCount(objCaseTrendResponseType
							.getRxCount());
					caseTrendDataVO.setProblemDesc(objCaseTrendResponseType
							.getProblemDesc());
					caseTrendDataVOList.add(caseTrendDataVO);

				}
			}
			if (caseTrendDataVOList != null && !caseTrendDataVOList.isEmpty()) {
				for (int i = 0; i < caseTrendDataVOList.size(); i++) {

					arlMap = hashMap.get(caseTrendDataVOList.get(i)
							.getCreationRXDate());
					if (null == arlMap) {
						arlMap = new HashMap<String, String>();
					}
					arlMap.put(caseTrendDataVOList.get(i).getProblemDesc(),
							caseTrendDataVOList.get(i).getCount());

					hashMap.put(caseTrendDataVOList.get(i).getCreationRXDate(),
							arlMap);

					if (!previousDate.equals(AppConstants.EMPTY_STRING)
							&& !previousDate.equals(caseTrendDataVOList.get(i)
									.getCreationRXDate())
							&& hashMap.get(previousDate).size() != 3) {

						Iterator<String> item = arlcaseType.iterator();
						while (item.hasNext()) {
							String caseType = item.next();
							if (!hashMap.get(previousDate)
									.containsKey(caseType)) {
								hashMap.get(previousDate).put(caseType, AppConstants.ZERO);
							}
						}

					}

					if (caseTrendDataVOList.size() - 1 == i) {

						Iterator<String> item = arlcaseType.iterator();
						while (item.hasNext()) {
							String caseType = item.next();
							if (!hashMap.get(previousDate)
									.containsKey(caseType)) {
								hashMap.get(previousDate).put(caseType, AppConstants.ZERO);
							}
						}

					}
					previousDate = caseTrendDataVOList.get(i).getCreationRXDate();

				}
			}
			beanMap.setCaseTrendStatistics(hashMap);
			
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getCaseTrend() method of getCaseTrendStatistics",
							ex);
		} finally {
			queryParams = null;
			caseTrendResponseType = null;
		}
		return new AsyncResult<CaseTrendStatisticsBean>(beanMap);
	}

	@Override
    public List<GenNotesVO> getGeneralNotesDetails() throws RMDWebException {
        List<GenNotesVO> arlGenNotesVO = null;
        GenNotesVO objGenNotesVO = null;
        GeneralNotesResponseType[] arGeneralNotesResponseType = null;
        String notes=null;
        try {
            arGeneralNotesResponseType = (GeneralNotesResponseType[]) webServiceInvoker.get(
                    ServiceConstants.GET_GENERAL_NOTES_DETAILS, null, null,
                    null, GeneralNotesResponseType[].class);
            if (arGeneralNotesResponseType != null
                    && arGeneralNotesResponseType.length > 0) {
                arlGenNotesVO = new ArrayList<GenNotesVO>(arGeneralNotesResponseType.length);
                for (GeneralNotesResponseType gnRespType : arGeneralNotesResponseType) {
                    objGenNotesVO = new GenNotesVO();
                    if(!RMDCommonUtility.isNull(gnRespType.getNotesdesc())){
                        notes = EsapiUtil.resumeSpecialChars(gnRespType.getNotesdesc());
                        objGenNotesVO.setNotesdesc(notes.replace(RMDCommonConstants.GREATER_THAN_SYMBOL, RMDCommonConstants.GRTTHAN).replace(RMDCommonConstants.LESS_THAN_SYMBOL, RMDCommonConstants.LESSTHAN));
                    }
                    objGenNotesVO.setEnteredby(gnRespType.getEnteredby());
                    arlGenNotesVO.add(objGenNotesVO);
                }
            }
            
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getGeneralNotesDetails() method of AssetCasesServiceImpl.java",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return arlGenNotesVO;
    }

}
