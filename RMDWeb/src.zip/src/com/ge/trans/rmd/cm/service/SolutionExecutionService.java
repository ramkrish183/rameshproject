/**
 * ============================================================
 * File : SolutionExecutionService.java
 * Description 		: Service interface for Technician Cases and Rx Case Execution Details
 * Package 			: com.ge.trans.rmd.cm.service
 * Author 			: UST
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		: April 3, 2012
 * History
 * Modified By 		: Initial Release
 * Copyright (C) 2012 General Electric Company. All rights reserved
 * ============================================================
 */
package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;
import com.ge.trans.rmd.cm.beans.OpenCasesBean;
import com.ge.trans.rmd.cm.valueobjects.CaseResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LocationVO;
import com.ge.trans.rmd.cm.valueobjects.SolutionExecutionResponseVO;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface SolutionExecutionService {

	public List<CaseResponseVO> getCases(String queueNameValue, String solutionStatusValue,
			OpenCasesBean openCasesBean,CaseResponseVO objCaseResponseVO);
	
	public List<CaseResponseVO> getCasesLite(String queueNameValue, String solutionStatusValue,
			OpenCasesBean openCasesBean,CaseResponseVO objCaseResponseVO, String userCustomer);
	

	public SolutionExecutionResponseVO getSolutionExecutionDetails(
			OpenCasesBean openCaseBean) ;

	public void saveSolutionExecutionDetails(
			SolutionExecutionResponseVO solutionExecutionResponseVO,
			OpenCasesBean openCasesBean) throws Exception;

	public void submitSolutionExecutionDetails(
			SolutionExecutionResponseVO solutionExecutionResponseVO,
			OpenCasesBean openCasesBean) throws Exception;
	
	public List<LocationVO> getRXEXLocations(OpenCasesBean openCasesBean)
	throws RMDWebException, Exception;

	public Map<String, String> getNoOfDays(String listName)
	throws Exception;

	public String getDeliverRxURL(String caseId) throws Exception;
	public String validateURL(String caseId,String fileName,String taskID) throws RMDWebException;

}
