package com.ge.trans.rmd.cm.mvc.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.BOMService;
import com.ge.trans.rmd.cm.valueobjects.BOMConfigVO;
import com.ge.trans.rmd.cm.valueobjects.VehicleCfgVO;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class BOMController extends RMDBaseController {
	@Autowired
	private BOMService bomService;
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	/**
	 * @Author :
	 * @return :ModelAndView
	 * @param :
	 * @throws :RMDWebException
	 * @Description: Displays the BOM Maintenance page of the RMD application
	 *               when clicked on BOM Maintenanace Tab in Edit Page.
	 * 
	 */
	@RequestMapping(AppConstants.REQ_URI_VIEW_BOM_MAINTENANCE)
	public ModelAndView viewBOMMaintanence(final HttpServletRequest request)
			throws RMDWebException {
		return new ModelAndView(AppConstants.BOM_MAINTENANCE);
	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description * This method is used for fetching Config Controller list.
	 *              This method will be invoked through ajax call.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_BOM_CONFIG_LIST)
	public @ResponseBody
	java.util.Map<String, String> getConfigList() throws RMDWebException {
		Map<String, String> configList = null;
		Map<String, String> sortConfigList = new LinkedHashMap<String, String>();
		try {
			configList = bomService.getConfigList();
			sortConfigList = SortMapKey(configList);
		} catch (Exception e) {
			rmdWebLogger.error(
					"Exception occured in getConfigList method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		finally
		{
			configList=null;
		}
		return sortConfigList;

	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description * This method is used for fetching Config Controller details.
	 *              This method will be invoked through ajax call.
	 * 
	 */
	@RequestMapping(value = AppConstants.POPULATE_CONFIG_DETAILS)
	public @ResponseBody
	java.util.List<BOMConfigVO> populateConfigDetails(
			final HttpServletRequest request) throws RMDWebException {
		String configId = request.getParameter("config_id");
		List<BOMConfigVO> bOMConfigVO = new ArrayList<BOMConfigVO>();
		try {
			if (configId != null && configId != "") {
				bOMConfigVO = bomService.populateConfigDetails(configId);
			}
		} catch (Exception e) {
			rmdWebLogger.error(
					"Exception occured in populateConfigDetails method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return bOMConfigVO;

	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description * This method is used for fetching Config item list from
	 *              lookup table. This method will be invoked through ajax call.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_BOM_CONFIG_ITEMS)
	public @ResponseBody
	java.util.Map<String, String> getConfigItemsList() throws RMDWebException {
		Map<String, String> configItemsList = null;
		Map<String, String> sortConfigItemsList = new LinkedHashMap<String, String>();
		try {
			configItemsList = bomService.getConfigItemsList();
			sortConfigItemsList = SortMapValues(configItemsList);
		} catch (Exception e) {
			rmdWebLogger.error(
					"Exception occured in getConfigItemsList method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		finally
		{
			configItemsList=null;
		}
		return sortConfigItemsList;

	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description * This method is used for fetching Parameter details from
	 *              Master Table. This method will be invoked through ajax call.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_PARAMETER_LIST)
	public @ResponseBody
	java.util.Map<String, String> getParameterList(
			final HttpServletRequest request) throws RMDWebException {
		Map<String, String> parameterList = null;
		Map<String, String> sortParameterList = new LinkedHashMap<String, String>();
		String configId = EsapiUtil.stripXSSCharacters(request.getParameter("config_id"));
		try {
			parameterList = bomService.getParameterList(configId);
			sortParameterList = SortMapKey(parameterList);
		} catch (Exception e) {
			rmdWebLogger.error(
					"Exception occured in getParameterList method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return sortParameterList;

	}

	/**
	 * @Author :
	 * @return :String
	 * @param : ParameterString,HttpServletRequest request
	 * @throws :RMDWebException
	 * @Description: This method is used to Add and Update Bom Configuration
	 *               information
	 * 
	 */

	@RequestMapping(AppConstants.REQ_URI_SAVE_BOM_DETAILS)
	public @ResponseBody
	String saveBOMDetails(
			@RequestParam(value = AppConstants.GET_PARAMETER_STRING) final String parameterString,
			final HttpServletRequest request) throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<BOMConfigVO> bOMConfigVOList = new ArrayList<BOMConfigVO>();
		final ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			BOMConfigVO[] arrBOMConfigVO = mapper.readValue(parameterString,
					BOMConfigVO[].class);
			bOMConfigVOList = Arrays.asList(arrBOMConfigVO);
			status = bomService.saveBOMDetails(bOMConfigVOList);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("RMDWebException occured in saveBOMDetails() method - BOMController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return status;

	}

}
