/**
 * 
 */
package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

/**
 * @author MSHIRAJUDDIN
 *
 */
public class LDVRApplyTemplateRequestVO {
	
	private List<Long> templateObjid;
	private List<AssetsVO> assets;
	private String device;
	private String userId;
	private String messagePriority;
	
	

	/**
	 * @return the assets
	 */
	public List<AssetsVO> getAssets() {
		return assets;
	}
	/**
	 * @param assets the assets to set
	 */
	public void setAssets(List<AssetsVO> assets) {
		this.assets = assets;
	}
	/**
	 * @return the device
	 */
	public String getDevice() {
		return device;
	}
	/**
	 * @param device the device to set
	 */
	public void setDevice(String device) {
		this.device = device;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the messagePriority
	 */
	public String getMessagePriority() {
		return messagePriority;
	}
	/**
	 * @param messagePriority the messagePriority to set
	 */
	public void setMessagePriority(String messagePriority) {
		this.messagePriority = messagePriority;
	}
	/**
	 * @return the templateObjid
	 */
	public List<Long> getTemplateObjid() {
		return templateObjid;
	}
	/**
	 * @param templateObjid the templateObjid to set
	 */
	public void setTemplateObjid(List<Long> templateObjid) {
		this.templateObjid = templateObjid;
	}
	
}
