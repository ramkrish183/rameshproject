/**
 * ============================================================
 * File : HealthCheckController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.cm.mvc.controller
 * Author : GE
 * Last Edited By :
 * Version : 1.0
 * Created on : Apr 02, 2014
 * History
 * Modified By : Initial Release
 * Classification : GE Sensitive
 * Copyright (C) 2014 General Electric Company. All rights reserved
 *
 * ============================================================
 */

package com.ge.trans.rmd.cm.mvc.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.portlet.ModelAndView;

import com.ge.trans.rmd.cm.beans.AssetFaultDataBean;
import com.ge.trans.rmd.cm.service.AssetOverviewService;
import com.ge.trans.rmd.cm.service.HealthCheckService;
import com.ge.trans.rmd.cm.valueobjects.HealthCheckAvailableVO;
import com.ge.trans.rmd.cm.valueobjects.HealthCheckSubmitVO;
import com.ge.trans.rmd.cm.valueobjects.HealthCheckVO;
import com.ge.trans.rmd.cm.valueobjects.HealthCheckFaultsDataVO;
import com.ge.trans.rmd.cm.valueobjects.HealthCheckFaultsServiceVO;
import com.ge.trans.rmd.cm.valueobjects.MessageHistoryResponseVO;
import com.ge.trans.rmd.cm.valueobjects.RDRNotificationsResponseVO;
import com.ge.trans.rmd.cm.valueobjects.RDRNotificationsSubmitRequestVO;
import com.ge.trans.rmd.cm.valueobjects.RDRNotificationsVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.services.assets.valueobjects.HealthCheckResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.RDRNotificationsSubmitRequest;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class HealthCheckController extends RMDBaseController {

	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private AuthorizationService authService;

	@Autowired
	private HealthCheckService healthCheckService;
	
	@Autowired
	private AssetOverviewService asstOvwService;

	@RequestMapping(value = AppConstants.REQ_URI_HC_REQUEST_TYPE, method = RequestMethod.GET)
	public @ResponseBody
	List<String> getHCRequestType(final HttpServletRequest request)
			throws RMDWebException, Exception {
		String requestHCType = null;
		List<String> lstHCReqType = new ArrayList<String>();
		try {
			requestHCType = authService
					.getLookUpValueForName(AppConstants.HEALTHCHECK_REQUEST_TYPE_LIST);
			lstHCReqType.add(requestHCType);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getRequestType method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lstHCReqType;
	}
	
	//SOC - Raj.S(212687474)
	@RequestMapping(value = AppConstants.GET_RDR_NOTIFICATIONS, method = RequestMethod.GET)
	public @ResponseBody List<RDRNotificationsVO> getRDRNotifications(
			final HttpServletRequest request) throws Exception{
		rmdWebLogger
		.debug("HealthCheckController : Inside getRDRNotifications() method:::::START ");
		final UserVO userVO = (UserVO) request.getSession(false).getAttribute(
				AppConstants.ATTR_USER_OBJECT);
		RDRNotificationsResponseVO response = null;
		String userId = userVO.getUserId();
		try {
			response = healthCheckService.getRDRNotifications(userId);
		}
		catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getHCFaults method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
		.debug("HealthCheckController : Inside getRDRNotifications() method:::::End ");
		if(response==null) {
			return null;
		}
		return response.getNotifications();
	}
	
	@RequestMapping(value = AppConstants.SUBMIT_RDR_NOTIFICATIONS, method = RequestMethod.POST)
	public @ResponseBody boolean submitRDRNotification(
			final HttpServletRequest request) throws Exception {
		rmdWebLogger.debug("HealthCheckController: Inside submitRDRNotification() method::::::START ");
		final UserVO userVO = (UserVO) request.getSession(false).getAttribute(
				AppConstants.ATTR_USER_OBJECT);
		String userId = userVO.getUserId();
		boolean status = false;
		RDRNotificationsSubmitRequest submitRequest = new RDRNotificationsSubmitRequest();
		submitRequest.setAssetNumber(request.getParameter(AppConstants.HC_PARAM_ASSETNUM));
		submitRequest.setAssetGrpName(request.getParameter(AppConstants.HC_PARAM_ASSETGRPNAME));
		submitRequest.setCustomerID(request.getParameter(AppConstants.HC_PARAM_CUSTID));
		submitRequest.setFromDate(request.getParameter(AppConstants.HC_PARAM_FROMDATE));
		submitRequest.setToDate(request.getParameter(AppConstants.HC_PARAM_TODATE));
		submitRequest.setStatus(request.getParameter(AppConstants.HC_PARAM_STATUS));
		submitRequest.setUserID(userId);
		try {
			status = healthCheckService.insertRDRNotification(submitRequest);
		}
		catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in submitRDRNotification method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return status;
	}
	
	@RequestMapping(value = AppConstants.UPDATE_RDR_NOTIFICATIONS, method = RequestMethod.POST)
	public @ResponseBody boolean updateRDRNotification(
			final HttpServletRequest request) throws Exception {
		rmdWebLogger.debug("HealthCheckController: Inside updateRDRNotification() method::::::START ");
		final UserVO userVO = (UserVO) request.getSession(false).getAttribute(
				AppConstants.ATTR_USER_OBJECT);
		String userId = userVO.getUserId();
		boolean status = false;
		RDRNotificationsSubmitRequest submitRequest = new RDRNotificationsSubmitRequest();
		submitRequest.setAssetNumber(request.getParameter(AppConstants.HC_PARAM_ASSETNUM));
		submitRequest.setAssetGrpName(request.getParameter(AppConstants.HC_PARAM_ASSETGRPNAME));
		submitRequest.setCustomerID(request.getParameter(AppConstants.HC_PARAM_CUSTID));
		submitRequest.setFromDate(request.getParameter(AppConstants.HC_PARAM_FROMDATE));
		submitRequest.setToDate(request.getParameter(AppConstants.HC_PARAM_TODATE));
		submitRequest.setStatus(request.getParameter(AppConstants.HC_PARAM_STATUS));
		submitRequest.setUserID(userId);
		try {
			status = healthCheckService.updateRDRNotification(submitRequest);
		}
		catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in updateRDRNotification method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return status;
	}
	
	@RequestMapping(value = AppConstants.GET_HC_FAULTS, method = RequestMethod.GET)
	public @ResponseBody HealthCheckFaultsDataVO getHCFaults(
			final HttpServletRequest request) throws Exception {
		rmdWebLogger
		.debug("HealthCheckController : Inside getHCFaults() method:::::START ");
		final UserVO userVO = (UserVO) request.getSession(false).getAttribute(
				AppConstants.ATTR_USER_OBJECT);
		Map<String, String> headerMap = new HashMap<String, String>();
		if (null != userVO.getStrLanguage()) {
			headerMap.put(AppConstants.LANGUAGE, userVO.getStrLanguage());
		}
		if (null != userVO.getStrUserLanguage()) {
			headerMap.put(AppConstants.USER_LANGUAGE,
					userVO.getStrUserLanguage());
		}
		if (null != userVO.getUserId()) {
			headerMap.put(AppConstants.GENERAL_PARAM_USER_ID,
					userVO.getUserId());
		}
		if (null != userVO.getStrFirstName()) {
			headerMap.put(AppConstants.GENERAL_PARAM_USER_FNAME,
					userVO.getStrFirstName());
		}
		if (null != userVO.getStrLastName()) {
			headerMap.put(AppConstants.GENERAL_PARAM_USER_LNAME,
					userVO.getStrLastName());
		}
		if (null != userVO.getCmAliasName()) {
			headerMap.put(AppConstants.CM_ALIAS_NAME,
					userVO.getCmAliasName());
		}
		HealthCheckFaultsDataVO hcfaults = null;
		Map<String,String> pathParams = new LinkedHashMap<String,String>();
		Map<String,String> queryParams = new HashMap<String,String>();
		final String assetNum = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.HC_PARAM_ASSETNUM));
		final String assetGrpName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.HC_PARAM_ASSETGRPNAME));
		final String custID =EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.HC_PARAM_CUSTID));
		pathParams.put(AppConstants.HC_PARAM_ASSETNUM,assetNum);
		pathParams.put(AppConstants.HC_PARAM_ASSETGRPNAME,assetGrpName);
		pathParams.put(AppConstants.HC_PARAM_CUSTID,custID);
		final String sortOptions = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.HC_PARAM_SORTOPT));
		String fromDateStr = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.HC_PARAM_FROMDATE));
		String toDateStr = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.HC_PARAM_TODATE));
		final String isLimitedParam = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.HC_PARAM_ISLIMITEDPARAM));
		final String dataScreen = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.HC_PARAM_DATA_SCREEN));
		final String allRecords = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.HC_PARAM_ALL_RECORDS));
		final String isMobileRequest = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.HC_PARAM_ISMOBILEREQUEST));
		final DateFormat dateFormater = new SimpleDateFormat(AppConstants.FROM_DATE_FORMAT);
		final String defaultTimezone = (String) request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String userTimezone = RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone());
		dateFormater.setTimeZone(TimeZone.getTimeZone(userTimezone));
		Date fromDate = new Date(Long.parseLong(fromDateStr));
		Date toDate = new Date(Long.parseLong(toDateStr));
		fromDateStr = dateFormater.format(fromDate);
		toDateStr = dateFormater.format(toDate);
		fromDateStr = RMDCommonUtility.convertDateFormatAndTimezone(fromDateStr, AppConstants.FROM_DATE_FORMAT, 
					AppConstants.DATE_FORMAT_24HRS, userTimezone, RMDCommonConstants.DateConstants.EST_US);
		toDateStr = RMDCommonUtility.convertDateFormatAndTimezone(toDateStr, AppConstants.FROM_DATE_FORMAT, 
					AppConstants.DATE_FORMAT_24HRS, userTimezone, RMDCommonConstants.DateConstants.EST_US);
		queryParams.put(AppConstants.HC_PARAM_SORTOPT,sortOptions);
		queryParams.put(AppConstants.HC_PARAM_FROMDATE,fromDateStr);
		queryParams.put(AppConstants.HC_PARAM_TODATE,toDateStr);
		queryParams.put(AppConstants.HC_PARAM_ISLIMITEDPARAM,isLimitedParam);
		queryParams.put(AppConstants.HC_PARAM_DATA_SCREEN,dataScreen);
		queryParams.put(AppConstants.HC_PARAM_ALL_RECORDS,allRecords);
		queryParams.put(AppConstants.HC_PARAM_ISMOBILEREQUEST,isMobileRequest);
		try {
			hcfaults = healthCheckService.getHCFaults(pathParams, queryParams,headerMap);
		}
		catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getHCFaults method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
		.debug("HealthCheckController : Inside getHCFaults() method:::::End ");
		return hcfaults;
	}

	@RequestMapping(value = AppConstants.REQ_URI_HC_MP_GROUPS, method = RequestMethod.GET)
	public @ResponseBody
	java.util.Map<String, String> getAssetHCMPGroups(
			final HttpServletRequest request) throws Exception {
		Map<String, String> mapAssetHCMP = new HashMap<String, String>();
		rmdWebLogger
		.debug("HealthCheckController : Inside getAssetHCMPGroups() method:::::START ");
		final String strAssetId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_NUMBER));
		final String strCustomerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CUSTOMER_ID));
		final String strGrpName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_GROUP_NAME));
		final String requestType = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQUEST_TYPE_HC));
		final String assetType = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_TYPE));
		final String deviceName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.DEVICE_NAME));
		try {
			mapAssetHCMP = healthCheckService.getAssetHCMPGroups(strAssetId,
					strCustomerId, strGrpName,requestType,assetType,deviceName);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAssetHCMPGroups method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
		.debug("HealthCheckController : Inside getAssetHCMPGroups() method:::::End ");
		return mapAssetHCMP;
	}

	@RequestMapping(value = AppConstants.REQ_URI_HC_AVAILBABLE, method = RequestMethod.GET)	
	public @ResponseBody
	HealthCheckAvailableVO  IsHCAvailable(final HttpServletRequest request) throws Exception {
		rmdWebLogger
		.debug("HealthCheckController : Inside getIsHCAvailable() method:::::START ");
		HealthCheckAvailableVO hcAvailable = null;
		final String strAssetId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_NUMBER));
		final String strCustomerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CUSTOMER_ID));
		final String strGrpName =EsapiUtil.stripXSSCharacters( request
				.getParameter(AppConstants.ASSET_GROUP_NAME));
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		boolean isInternal = false;
		String internalPrivilege = null;
		try {
			hcAvailable = healthCheckService.IsHCAvailable(strAssetId,
					strCustomerId, strGrpName);
			internalPrivilege = authService
					.getLookUpValueForName(AppConstants.HEALTHCHECK_PRIVILEGE);
			isInternal = RMDCommonUtil.componentValue(userVO.getComponentList(),internalPrivilege);
			if (null != hcAvailable) {
				if (isInternal) {
					hcAvailable.setIsInternal(AppConstants.YES_FLAG);
				} else {
					hcAvailable.setIsInternal(AppConstants.NO_FLAG);
				}
			}
			
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getIsHCAvailable method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
		.debug("HealthCheckController : Inside getIsHCAvailable() method:::::End ");
		return hcAvailable;
	}
	
	@RequestMapping(value = AppConstants.REQ_URI_HC_ASSET_TYPE, method = RequestMethod.GET)	
	public @ResponseBody
	List<String>  getHCAssetType(final HttpServletRequest request) throws Exception {
		rmdWebLogger
		.debug("HealthCheckController : Inside getHCAssetType() method:::::START ");
		List <String> lstAssetType = new ArrayList<String>();
		String assetType = null;
		final String strAssetId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_NUMBER));
		final String strCustomerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CUSTOMER_ID));
		final String strGrpName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_GROUP_NAME));
		try {
			assetType = healthCheckService.getHCAssetType(strAssetId,
					strCustomerId, strGrpName);
			lstAssetType.add(assetType);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getHCAssetType method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
		.debug("HealthCheckController : Inside getHCAssetType() method:::::End ");
		return lstAssetType;
	}

	/**
	 * @param HttpServletRequest
	 * @return Map<String, String>
	 * @throws Exception
	 * @Description:This method submits a healthCheck request
	 */
	@RequestMapping(value = AppConstants.REQ_URI_HC_SUBMIT_REQUEST, method = RequestMethod.POST)
	public @ResponseBody
	Map<String, String> submitHealthCheckRequest(final HttpServletRequest request) throws Exception {
		
		rmdWebLogger.debug("HealthCheckController : Inside submitHealthCheckRequest() method:::::START ");
		HealthCheckResponseType hcRepType = null;
		
		final HttpSession session = request.getSession(false);
		final String strAssetId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_NUMBER));
		final String strCustomerId =EsapiUtil.stripXSSCharacters( request.getParameter(AppConstants.CUSTOMER_ID));
		final String strGrpName = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_GROUP_NAME));
		String strSampleRate = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.SAMPLE_RATE));
		final String strNoofPostSamples = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.NO_OF_POST_SAMPLES));
		String strMpNum = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MP_NUMBERS));
		final String strAssetType = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_TYPE));
		Map<String, String> mapResponse = new HashMap<String, String>();
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String device = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.DEVICE));
		String typeOfUser = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.IS_INTERNAL));
		try {
			if (null != strSampleRate) {
				strSampleRate = strSampleRate.trim();
			}
			final Map<String, String> result = validateUserInput(strSampleRate,
					strNoofPostSamples, strMpNum, strAssetType, device);
			if (null != result && !result.isEmpty()) {
				return result;
			} else {
				hcRepType = healthCheckService.getSendMessageAttributes(
						strAssetId, strCustomerId, strGrpName, strMpNum,
						strAssetType,typeOfUser,device);
				if (hcRepType != null) {
					if (device.equalsIgnoreCase(AppConstants.DEVICE_EGA)) {
						HealthCheckSubmitVO healthCheckSubmitVO = new HealthCheckSubmitVO();
						healthCheckSubmitVO.setMpNum(hcRepType.getMpReqNum());
						healthCheckSubmitVO.setUserId(userVO.getUserId());
						healthCheckSubmitVO.setCustomerID(strCustomerId);
						healthCheckSubmitVO.setRoadIntial(strGrpName);
						healthCheckSubmitVO.setRoadNumber(RMDCommonUtility.convertObjectToLong(strAssetId));
						healthCheckSubmitVO.setAssetType(strAssetType);
						healthCheckSubmitVO.setMpGroupId((RMDCommonUtility.convertObjectToLong(strMpNum)));
						healthCheckSubmitVO.setMpGroupName(EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MP_NAME)));
						healthCheckSubmitVO.setSampleRate(RMDCommonUtility.convertObjectToLong(strSampleRate));
						healthCheckSubmitVO.setPostSamples(RMDCommonUtility.convertObjectToLong(strNoofPostSamples));
						healthCheckSubmitVO.setPlatform(device);
						healthCheckSubmitVO.setTypeOfUser(typeOfUser);
						mapResponse = healthCheckService.submitEGAHealthCheckRequest(healthCheckSubmitVO);
					} else {
						mapResponse = healthCheckService
								.submitHealthCheckRequest(strAssetId, strCustomerId, strGrpName,
												strSampleRate, strNoofPostSamples, strMpNum, 
												EsapiUtil.stripXSSCharacters(userVO.getUserId()),
												hcRepType, device, typeOfUser);
					}
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in submitHealthCheckRequest method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger.debug("HealthCheckController : Inside submitHealthCheckRequest() method:::::End ");
		return mapResponse;
	}
	/**
	 * @Author:GE
	 * @param 
	 * @return Map<String,String>
	 * @throws
	 * @Description * This method is used for Validating user input for request healthcheck page
	 *              
	 */

	public Map<String, String> validateUserInput(String strSampleRate,
			String strNoofPostSamples, String strMpNum,String strAssetType,String device) {
		final Map<String, String> result = new HashMap<String, String>();
		rmdWebLogger
		.debug("HealthCheckController : Inside validateUserInput() method:::::Start ");
		try {
			if (strSampleRate==null ||
					!RMDCommonUtility.isNumeric(strSampleRate)) {
				result.put(AppConstants.SAMPLE_RATE, AppConstants.INVALID);
			}
			if (strNoofPostSamples.isEmpty()
					|| !RMDCommonUtility
					.isNumeric(strNoofPostSamples)) {
				result.put(AppConstants.NO_OF_POST_SAMPLES,
						AppConstants.INVALID);
			}

			if (RMDCommonConstants.HC_ASSET_TYPE_EVO.equalsIgnoreCase(strAssetType) && strMpNum.isEmpty()
					|| RMDCommonUtility.isSpecialCharactersFound(strMpNum)) {
				result.put(AppConstants.MP_NUMBERS, AppConstants.INVALID);
			}
			if (device == null
					|| device.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {
				result.put(AppConstants.DEVICE, AppConstants.INVALID);
			}

		} catch (Exception exception) {
			rmdWebLogger.error("Error occured in validateUserInput"
					+ exception);
		}
		rmdWebLogger
		.debug("HealthCheckController : Inside validateUserInput() method:::::End ");
		return result;
	}

	/**
	 * @param request
	 * @return
	 * @throws Exception
	 * @Description Funtion to retrieve the message history details
	 */
	@RequestMapping(value = AppConstants.REQ_URI_VIEW_HC_REQUEST_HISTORY, method = RequestMethod.GET)
	public ModelAndView viewHCRequestHistory(final HttpServletRequest request)
			throws Exception {
		rmdWebLogger
		.debug("HealthCheckController : Inside viewHCRequestHistory() method:::::START ");
		final HttpSession session = request.getSession(false);
		final String strAssetId =  EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_NUMBER));
		String strCustomerId = null;
		final String strGrpName = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_GROUP_NAME));
		List<HealthCheckVO> messageHistList = null;
		String userTimeZone = null;
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		HealthCheckAvailableVO healthCheckAvailableVO = null;
		String internalPrivilege = null;
		boolean isInternal;
		String autoHc = null;
		HealthCheckSubmitVO objHealthCheckSubmitVO=null;
		String defaultDevice=null;
		MessageHistoryResponseVO messageHistoryResponseVO =null;
		List<String> devicesList=new ArrayList<String>();
		final DateFormat dateFormater = new SimpleDateFormat(AppConstants.FROM_DATE_FORMAT);
		final String defaultTimezone = (String) request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone());
		dateFormater.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
		try {
			/*Begin of Changes for fetching customer Id from Webservices */
			strCustomerId=asstOvwService.getCustomerId(strAssetId, strGrpName);
			 /*End of Changes*/
			internalPrivilege = authService.getLookUpValueForName(AppConstants.HEALTHCHECK_PRIVILEGE);
			isInternal = RMDCommonUtil.componentValue(userVO.getComponentList(), internalPrivilege);
			if (isInternal) {
				internalPrivilege = AppConstants.YES_FLAG;
			} else {
				internalPrivilege = AppConstants.NO_FLAG;
			}
			userTimeZone = RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone());
			healthCheckAvailableVO = healthCheckService.IsHCAvailable(strAssetId, strCustomerId, strGrpName);
			objHealthCheckSubmitVO = new HealthCheckSubmitVO();		
			objHealthCheckSubmitVO.setAssetId(strAssetId);
			objHealthCheckSubmitVO.setCustomerID(strCustomerId);
			objHealthCheckSubmitVO.setRoadIntial(strGrpName);
			objHealthCheckSubmitVO.setTypeOfUser(AppConstants.YES_FLAG);
			defaultDevice=healthCheckService.getDeviceInfo(objHealthCheckSubmitVO)+AppConstants.GE_USER;
			objHealthCheckSubmitVO.setTypeOfUser(AppConstants.NO_FLAG);
			String externalDevice=healthCheckService.getDeviceInfo(objHealthCheckSubmitVO)+AppConstants.EXTERNAL_USER;
			if(!defaultDevice.equalsIgnoreCase(AppConstants.FAILURE_GE))
			{
				devicesList.add(defaultDevice);
			}
			if(!externalDevice.equalsIgnoreCase(AppConstants.FAILURE_CUSTOMER))
			{
				devicesList.add(externalDevice);
			}
			if (isInternal) {
			request.setAttribute(AppConstants.DEFAULT_DEVICE,defaultDevice);
			} else {
			request.setAttribute(AppConstants.DEFAULT_DEVICE,externalDevice);
			}
			request.setAttribute(AppConstants.DEVICES_LIST,
					RMDCommonUtil
					.convertArrayToString(devicesList));
			request.setAttribute(AppConstants.IS_HC_ENABLED,
					healthCheckAvailableVO.getHcEnabled());
			request.setAttribute(AppConstants.DEFAULT_TIMEZONE, defaultTimezone);
			request.setAttribute(AppConstants.ASSET_NUMBER, strAssetId);
			request.setAttribute(AppConstants.CUSTOMER_ID, strCustomerId);
			request.setAttribute(AppConstants.ASSET_GROUP_NAME, strGrpName);
			
			Calendar fromDtCal = Calendar.getInstance();
			fromDtCal.add(Calendar.MINUTE, -360);
			String fromDate = dateFormater.format(fromDtCal.getTime());
			String toDate = dateFormater.format(new Date());
			request.setAttribute(AppConstants.FROM_DATE, fromDate);
			request.setAttribute(AppConstants.TO_DATE, toDate);
			
			int index=defaultDevice.indexOf("-");
			String device=defaultDevice.substring(0,index);
			int index1=externalDevice.indexOf("-");
			String externaldevice=externalDevice.substring(0,index1);
			if (AppConstants.YES_FLAG.equals(healthCheckAvailableVO
					.getHcEnabled())) {
				if (internalPrivilege.equalsIgnoreCase(AppConstants.YES_FLAG)) {
					autoHc = AppConstants.STR_TRUE;
					messageHistoryResponseVO = healthCheckService.viewHCMessageHistory(
							strAssetId, strCustomerId, strGrpName,
							userTimeZone, defaultDevice, userVO.getCustomerId(),
							autoHc, internalPrivilege , fromDate , toDate );
				} else {
					autoHc = AppConstants.STR_FALSE;
					messageHistoryResponseVO = healthCheckService.viewHCMessageHistory(
							strAssetId, strCustomerId, strGrpName,
							userTimeZone, externalDevice, userVO.getCustomerId(),
							autoHc, internalPrivilege , fromDate , toDate);
				}
			}
			request.setAttribute(AppConstants.MESSAGE_HISTORY_VO,
					messageHistoryResponseVO);
			request.setAttribute(AppConstants.IS_INTERNAL, internalPrivilege);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in viewHCRequestHistory method ", ex);
			RMDWebErrorHandler.handleException(ex);
		} finally {
			messageHistoryResponseVO = null;
		}
		rmdWebLogger
		.debug("HealthCheckController : Inside submitHealthCheckRequest() method:::::End ");
		return new ModelAndView(AppConstants.VIEW_REQUEST_HISTORY);
	}

	
	/**
	 * @param request
	 * @return
	 * @throws Exception
	 * @Description Funtion to retrieve the message history details
	 */
	@RequestMapping(value = AppConstants.REQ_URI_VIEW_HC_REQUEST_HISTORY_DETAILS, method = RequestMethod.GET)
	public @ResponseBody
	MessageHistoryResponseVO viewHCRequestHistoryDetails(
			final HttpServletRequest request) throws Exception {

		rmdWebLogger
				.debug("HealthCheckController : Inside viewHCRequestHistory() method:::::START ");
		final HttpSession session = request.getSession(false);
		final String strAssetId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_NUMBER));
		final String strCustomerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CUSTOMER_ID));
		final String strGrpName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_GROUP_NAME));
		String device = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.DEVICE));
		List<HealthCheckVO> messageHistList = null;
		MessageHistoryResponseVO messageHistoryResponseVO =null;
		String userTimeZone = null;
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String defaultTimezone = EsapiUtil.stripXSSCharacters((String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE));
		final String autoHC = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.AUTO_HC));
		final String fromDateParam = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FROM_DATE));
		final String toDateParam = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TO_DATE));
		String internalPrivilege = null;
		boolean isInternal;
		final DateFormat dateFormater = new SimpleDateFormat(AppConstants.FROM_DATE_FORMAT);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone());
		dateFormater.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
		try {
			internalPrivilege = authService.getLookUpValueForName(AppConstants.HEALTHCHECK_PRIVILEGE);
			isInternal = RMDCommonUtil.componentValue(userVO.getComponentList(), internalPrivilege);
			if (isInternal) {
				internalPrivilege = AppConstants.YES_FLAG;
			} else {
				internalPrivilege = AppConstants.NO_FLAG;
			}
			userTimeZone = RMDCommonUtil.getTimezone(defaultTimezone,EsapiUtil.stripXSSCharacters(userVO.getTimeZone()));
			String fromDate = dateFormater.format(dateFormater.parse(fromDateParam));
			String toDate = dateFormater.format(dateFormater.parse(toDateParam));
			messageHistoryResponseVO = healthCheckService
					.viewHCMessageHistory(strAssetId, strCustomerId,
							strGrpName, userTimeZone, device,
							EsapiUtil.stripXSSCharacters(userVO.getCustomerId()), autoHC, internalPrivilege,fromDate , toDate);

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in viewHCRequestHistory method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
				.debug("HealthCheckController : Inside viewHCRequestHistory() method:::::End ");
		return messageHistoryResponseVO;
	
	}
	
	/**
	 * @param request
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description Funtion to retrieve the values from lookup.
	 */
	@RequestMapping(value = AppConstants.GET_HC_LOOKUP)
	public @ResponseBody
	Map<String, String> getHCLookup(final HttpServletRequest request)
			throws RMDWebException {

		Map<String, String> result = new LinkedHashMap<String, String>();
		String noOfPostSamples = null, sampleRate = null;
		String listName = AppConstants.EMPTY_STRING;

		try {
			listName = AppConstants.HEALH_CHECK_NO_OF_SAMPLES_LOOKUP;
			noOfPostSamples = healthCheckService.getHCLookup(listName);
			result.put(AppConstants.NO_OF_SAMPLES, noOfPostSamples);
			listName = AppConstants.HEALH_CHECK_SAMPLE_RATE_LOOKUP;
			sampleRate = healthCheckService.getHCLookup(listName);
			result.put(AppConstants.SAMPLE_RATE, sampleRate);
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getHCLookup() method - HealthCheckController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return result;
	}
	

	/**
	 * @param HttpServletRequest
	 * @return HealthCheckAvailableVO
	 * @throws Exception
	 * @Description:This method fetches device information.
	 */
	@RequestMapping(value = AppConstants.GET_DEVICE_INFO, method = RequestMethod.GET)
	public @ResponseBody
	HealthCheckAvailableVO getDeviceInfo(final HttpServletRequest request)
			throws Exception {
		rmdWebLogger.debug("HealthCheckController : Inside getDeviceInfo() method:::::START ");
		final String strAssetId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_NUMBER));
		final String strCustomerId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CUSTOMER_ID));
		final String strGrpName = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_GROUP_NAME));
		String result = null;
		HealthCheckAvailableVO objHealthCheckAvailableVO = new HealthCheckAvailableVO();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String internalPrivilege = null;
		// SOC - Raj Shah (212687474)
		String revampedPrivilege = null;
		// EOC
		try {
			if (null != strAssetId	&& !strAssetId.equals(RMDCommonConstants.EMPTY_STRING)
					&& null != strCustomerId && !strCustomerId.equals(RMDCommonConstants.EMPTY_STRING)
					&& null != strGrpName	&& !strGrpName.equals(RMDCommonConstants.EMPTY_STRING)) {
				HealthCheckSubmitVO objHealthCheckSubmitVO = new HealthCheckSubmitVO();
				internalPrivilege = authService.getLookUpValueForName(AppConstants.HEALTHCHECK_PRIVILEGE);
				
				boolean isInternal = RMDCommonUtil.componentValue(userVO.getComponentList(),internalPrivilege);
				
				// SOC - Raj Shah (212687474)
				revampedPrivilege = authService.getLookUpValueForName(AppConstants.SHOW_REMOTE_DATA_RESPONSE_REVAMPED);
				boolean hasRevampedPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), revampedPrivilege);
				if(hasRevampedPrivilege) {
					objHealthCheckAvailableVO.setHasRevampedPrivilege(AppConstants.YES_FLAG);
				}else {
					objHealthCheckAvailableVO.setHasRevampedPrivilege(AppConstants.NO_FLAG);
				}
				// EOC
				
				objHealthCheckSubmitVO.setAssetId(strAssetId);
				objHealthCheckSubmitVO.setCustomerID(strCustomerId);
				objHealthCheckSubmitVO.setRoadIntial(strGrpName);
				if (isInternal) {
					objHealthCheckSubmitVO.setTypeOfUser(AppConstants.YES_FLAG);
					objHealthCheckAvailableVO.setIsInternal(AppConstants.YES_FLAG);
				} else {
					objHealthCheckSubmitVO.setTypeOfUser(AppConstants.NO_FLAG);
					objHealthCheckAvailableVO.setIsInternal(AppConstants.NO_FLAG);
				}
				result = healthCheckService.getDeviceInfo(objHealthCheckSubmitVO);
				objHealthCheckAvailableVO.setDevice(result);
			} else {
				result = AppConstants.INVALID_PARAMETERS;
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getDeviceInfo method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger.debug("HealthCheckController : Inside getDeviceInfo() method:::::End ");
		return objHealthCheckAvailableVO;
	}
	/**
	 * @param HttpServletRequest
	 * @return String
	 * @throws Exception
	 * @Description:This method validates EGA HC request.
	 */
	@RequestMapping(value = AppConstants.VALIDATE_EGA_HC, method = RequestMethod.GET)
	public @ResponseBody
	String validateEGAHC(final HttpServletRequest request) throws Exception {
		rmdWebLogger
				.debug("HealthCheckController : Inside validateEGAHC() method:::::START ");
		final String strAssetId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_NUMBER));
		final String strCustomerId =EsapiUtil.stripXSSCharacters( request
				.getParameter(AppConstants.CUSTOMER_ID));
		final String strGrpName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_GROUP_NAME));
		String result = null;
		HealthCheckSubmitVO objHealthCheckSubmitVO = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		String internalPrivilege = null;
		try {
			if (null != strAssetId
					&& !strAssetId
							.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)
					&& null != strCustomerId
					&& !strCustomerId
							.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)
					&& null != strGrpName
					&& !strGrpName
							.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {
				objHealthCheckSubmitVO = new HealthCheckSubmitVO();
				internalPrivilege = authService
						.getLookUpValueForName(AppConstants.HEALTHCHECK_PRIVILEGE);
				boolean isInternal = RMDCommonUtil.componentValue(
						userVO.getComponentList(), internalPrivilege);
				objHealthCheckSubmitVO.setAssetId(strAssetId);
				objHealthCheckSubmitVO.setCustomerID(strCustomerId);
				objHealthCheckSubmitVO.setRoadIntial(strGrpName);
				if (isInternal) {
					objHealthCheckSubmitVO.setTypeOfUser(AppConstants.YES_FLAG);
				} else {
					objHealthCheckSubmitVO.setTypeOfUser(AppConstants.NO_FLAG);
				}
				result = healthCheckService
						.validateEGAHC(objHealthCheckSubmitVO);
			} else {
				result = AppConstants.INVALID_PARAMETERS;
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in validateEGAHC method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
				.debug("HealthCheckController : Inside validateEGAHC() method:::::End ");
		return result;
	}
	
	/**
	 * @param HttpServletRequest
	 * @return String
	 * @throws Exception
	 * @Description:This method validates NT HC request.
	 */
	@RequestMapping(value = AppConstants.VALIDATE_NT_HC, method = RequestMethod.GET)
	public @ResponseBody
	String validateNTHC(final HttpServletRequest request) throws Exception {
		rmdWebLogger
				.debug("HealthCheckController : Inside validateNTHC() method:::::START ");
		final String strAssetId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_NUMBER));
		final String strCustomerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CUSTOMER_ID));
		final String strGrpName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_GROUP_NAME));
		String result = null;
		HealthCheckSubmitVO objHealthCheckSubmitVO = null;
		try {
			if (null != strAssetId
					&& !strAssetId
							.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)
					&& null != strCustomerId
					&& !strCustomerId
							.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)
					&& null != strGrpName
					&& !strGrpName
							.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {
				objHealthCheckSubmitVO = new HealthCheckSubmitVO();
				objHealthCheckSubmitVO.setAssetId(strAssetId);
				objHealthCheckSubmitVO.setCustomerID(strCustomerId);
				objHealthCheckSubmitVO.setRoadIntial(strGrpName);
				result = healthCheckService
						.validateNTHC(objHealthCheckSubmitVO);
			} else {
				result = AppConstants.INVALID_PARAMETERS;
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in validateNTHC method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		rmdWebLogger
				.debug("HealthCheckController : Inside validateNTHC() method:::::End ");
		return result;
	}

	/**
	 * @param HttpServletRequest
	 * @return ModelAndView
	 * @throws Exception
	 * @Description:This method used for displaying the health check request
	 *                   page
	 */
	@RequestMapping(value = AppConstants.REQ_URI_VIEW_HC)
	public ModelAndView viewHealthCheckRequestPage(
			final HttpServletRequest request) throws Exception {
		rmdWebLogger
				.debug("Inside HealthCheckController in viewHealthCheckRequestPage Method");
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		boolean isInternal = false;
		String internalPrivilege = null;
		internalPrivilege = authService
				.getLookUpValueForName(AppConstants.HEALTHCHECK_PRIVILEGE);
		isInternal = RMDCommonUtil.componentValue(userVO.getComponentList(),
				internalPrivilege);
		if (isInternal) {
			request.setAttribute(AppConstants.IS_INTERNAL,
					AppConstants.STR_TRUE);
			request.setAttribute(AppConstants.REQUEST_TYPE_HC,
					AppConstants.INTERNAL_HC);
		} else {
			request.setAttribute(AppConstants.IS_INTERNAL,
					AppConstants.STR_FALSE);
			request.setAttribute(AppConstants.REQUEST_TYPE_HC,
					AppConstants.EXTERNAL_HC);
		}
		return new ModelAndView(AppConstants.VIEW_HC);
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, List<String>>
	 * @throws:RMDWebException
	 * @Description: This method is   used for fetching the Customer Name and Road
	 *               Number Headers.
	 */
	@RequestMapping(value = AppConstants.GET_CUSTOMER_RNH_VALUES)
	public @ResponseBody Map<String, List<String>> getCustNameRNHValues()
			throws RMDWebException {
		Map<String, List<String>> custNameRNHMap = new LinkedHashMap<String, List<String>>();
		try {
			custNameRNHMap = healthCheckService.getCustNameRNH();
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getCustNameRNH() method - HealthCheckController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return custNameRNHMap;
	}
}
