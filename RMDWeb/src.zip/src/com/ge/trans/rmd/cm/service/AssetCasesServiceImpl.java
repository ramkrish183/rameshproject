package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.Future;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.collections.map.MultiValueMap;
import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.AssetInstalledProductVO;
import com.ge.trans.rmd.cm.valueobjects.AssetLastFaultStatusVO;
import com.ge.trans.rmd.cm.valueobjects.AssetLocatorResponseVO;
import com.ge.trans.rmd.cm.valueobjects.CaseActionVO;
import com.ge.trans.rmd.cm.valueobjects.CaseConversionBean;
import com.ge.trans.rmd.cm.valueobjects.CaseHistoryVO;
import com.ge.trans.rmd.cm.valueobjects.CaseMgmtUsersDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.CaseScoreRepairCodeVO;
import com.ge.trans.rmd.cm.valueobjects.CaseTrendDataVO;
import com.ge.trans.rmd.cm.valueobjects.CaseTypeBean;
import com.ge.trans.rmd.cm.valueobjects.CloseOutRepairCodeVO;
import com.ge.trans.rmd.cm.valueobjects.CloseRepairCodeVO;
import com.ge.trans.rmd.cm.valueobjects.CustomerFdbkVO;
import com.ge.trans.rmd.cm.valueobjects.DeliverSummaryVO;
import com.ge.trans.rmd.cm.valueobjects.MaterialUsageVO;
import com.ge.trans.rmd.cm.valueobjects.QueueDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.RecommDeliverVO;
import com.ge.trans.rmd.cm.valueobjects.RecommDelvDocVO;
import com.ge.trans.rmd.cm.valueobjects.RxDeliveryAttachmentVO;
import com.ge.trans.rmd.cm.valueobjects.RxDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.RxHistoryVO;
import com.ge.trans.rmd.cm.valueobjects.RxStatusHistoryVO;
import com.ge.trans.rmd.cm.valueobjects.SolutionDetailVO;
import com.ge.trans.rmd.cm.valueobjects.StickyNotesDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.ToolOutputCaseMergeVO;
import com.ge.trans.rmd.cm.valueobjects.ToolOutputDeliverVO;
import com.ge.trans.rmd.cm.valueobjects.TopNoActionBean;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.beans.CaseHistoryBean;
import com.ge.trans.rmd.common.beans.CaseSolutionVO;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.beans.SolutionBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.vo.GenNotesVO;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetInstalledProductResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetLocRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetLocatorResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.LastFaultStatusResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.RxVehicleBomResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.VehicleCommStatusResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseConversionResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseDetailsResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseHistoryResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseHistoryType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseInfoType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseMgmtUsersResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseRxDetailsResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseScoreRepairCodesResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseSolutionRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseTrendResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseTypeResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CasesRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.CloseOutRepairCodesResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CustomerFeedbackResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.MaterialUsageResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.QueueDetailsResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.RepairCodeDetailsType;
import com.ge.trans.rmd.services.cases.valueobjects.RxDelvDocType;
import com.ge.trans.rmd.services.cases.valueobjects.RxDetailsResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.RxHistoryResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.RxStatusHistoryResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.SolutionInfoType;
import com.ge.trans.rmd.services.cases.valueobjects.StickyNotesDetailsResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.ToolOutputActEntry;
import com.ge.trans.rmd.services.cases.valueobjects.ToolOutputDetailsResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.ViewCaseResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.ViewLogReponseType;
import com.ge.trans.rmd.services.gpocnotes.valueobjects.GeneralNotesResponseType;
import com.ge.trans.rmd.services.notes.valueobjects.NotesInfo;
import com.ge.trans.rmd.services.notes.valueobjects.NotesRequestType;
import com.ge.trans.rmd.services.solutions.valueobjects.LookupResponseType;
import com.ge.trans.rmd.services.solutions.valueobjects.RepairCodeType;
import com.ge.trans.rmd.services.solutions.valueobjects.RxDeliveryAttachmentResponse;
import com.ge.trans.rmd.services.solutions.valueobjects.SolutionDetailType;
import com.ge.trans.rmd.services.solutions.valueobjects.SolutionExecutionResponseType;
import com.ge.trans.rmd.utilities.AppSecUtil;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class AssetCasesServiceImpl extends RMDBaseServiceImpl implements AssetCasesService {
    private final RMDWebLogger rmdWebLogger = RMDWebLogger.getLogger(getClass());
    @Autowired
    WebServiceInvoker webServiceInvoker;

    @Autowired
    private CachedService cachedService;

    /**
     * @Author : IgatePatni
     * @param : assetNumber, queue name, case status, customer id and asset group name
     * @return : casesList
     * @throws RMDWebException
     * @throws Exception
     * @Description: This method invokes the web service to get the cases information of given
     *               status of asset id . Convert the web service response(JAXB) to caseBean which
     *               will contain the details about the priority,caseId,caseTitle,owner,create
     *               date,close date.
     */
    @Override
    public Future<List<CaseBean>> getCases(final CaseBean caseBean, String lookbackDays) throws RMDWebException,
            Exception {
        rmdWebLogger.debug("AssetCasesServiceImpl : Inside getCases() method:::STARTT");

        /* final Map<String, String> qParamAsset = new LinkedHashMap<String, String>(); */
        final Map<String, String> headerParams = getHeaderMap(caseBean);
        List<CaseBean> casesList = new ArrayList<CaseBean>();
        CasesRequestType objCasesReqType = new CasesRequestType();
        try {

            CaseResponseType[] caseResponseType = null;
            objCasesReqType.setAssetNumber(caseBean.getAssetNumber());
            objCasesReqType.setAssetGrName(caseBean.getAssetGrpName());
            objCasesReqType.setCustomerId(caseBean.getCustomerId());
            objCasesReqType.setNoDays(lookbackDays);
            // Call web service for open cases

            if (AppConstants.QUEUE_WORK.equalsIgnoreCase(caseBean.getQueueName())) {
                objCasesReqType.setDwq(AppConstants.OPENCASES_WS_VALUE);
                caseResponseType = (CaseResponseType[]) webServiceInvoker.post(
                        ServiceConstants.CASES_SERVICE_LITE_GETASSTCASES, objCasesReqType, CaseResponseType[].class);
                casesList = populateCaseBean(caseResponseType, caseBean);
            } else {
                if (AppConstants.QUEUE_DELIVERED.equalsIgnoreCase(caseBean.getQueueName())) {
                    objCasesReqType.setQueueName(caseBean.getQueueName());
                }
                if (AppConstants.STATUS_CLOSED.equalsIgnoreCase(caseBean.getCaseStatus())) {
                    objCasesReqType.setCaseStatus(caseBean.getCaseStatus());
                }
                caseResponseType = (CaseResponseType[]) webServiceInvoker.post(
                        ServiceConstants.CASES_SERVICE_LITE_GETASSTCASES, objCasesReqType, CaseResponseType[].class);

                casesList = populateCaseBean(caseResponseType, caseBean);
            }
        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error("RMDWebException occured in getCases() method ", rmdEx);

            if (!AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(rmdEx.getMessage())) {
                rmdWebLogger.info("No record found");
            } else {
                throw rmdEx;
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getCases() method ", ex);
            throw ex;
        }
        rmdWebLogger.debug("AssetCasesServiceImpl : Inside getCases() method:::END");
        return new AsyncResult<List<CaseBean>>(casesList);
    }

    /**
     * @Author : IgatePatni
     * @param : CaseResponseType[],CaseBean
     * @return : casesList
     * @throws RMDWebException
     * @throws Exception
     * @Description: This method converts the web service response(JAXB) to caseBean which will
     *               contain the details about the caseId,caseTitle,owner,create date,close date.
     */
    private List<CaseBean> populateCaseBean(final CaseResponseType[] caseResTypeArr, final CaseBean caseBeanInput) {
        final List<CaseBean> casesList = new ArrayList<CaseBean>();
        CaseBean caseBean;
        final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
        for (CaseResponseType caseResponseType : caseResTypeArr) {

            caseBean = new CaseBean();

            final TimeZone firstTime = TimeZone.getTimeZone(caseBeanInput.getTimeZone());
            zoneFormater.setTimeZone(firstTime);

            caseBean.setAssetNumber(caseResponseType.getAssetNumber());
            caseBean.setCaseStatus(caseResponseType.getCaseInfo().getCaseStatus());
            if (caseResponseType.getCaseInfo() != null) {

                caseBean.setCaseId(caseResponseType.getCaseInfo().getCaseID());
                caseBean.setRowVersion(RMDCommonUtility.convertObjectToInt(caseResponseType.getRowVersion()));
                caseBean.setCaseTitle(caseResponseType.getCaseInfo().getCaseTitle());
                caseBean.setOwner(caseResponseType.getCaseInfo().getOwner());
                caseBean.setQueueName(caseResponseType.getCaseInfo().getQueueName());
                caseBean.setReason(caseResponseType.getCaseInfo().getReason());
                caseBean.setCaseType(caseResponseType.getCaseInfo().getCaseType());
                caseBean.setCurrentSolutionStatus(caseResponseType.getCaseInfo().getCurrentRxStatus());
                caseBean.setCurrentSolutionDelvId(caseResponseType.getCaseInfo().getCurrentRxDelvId());
                caseBean.setOwnerName(caseResponseType.getCaseInfo().getOwnerName());
                if (caseResponseType.getCaseInfo().getCreatedDate() != null) {
                    // calculate age=current date- create date
                    final String age = RMDCommonUtil.calculateAge(caseResponseType.getCaseInfo().getCreatedDate()
                            .toGregorianCalendar(), new GregorianCalendar(), caseBeanInput.getTimeZone());

                    caseBean.setAge(age);
                    final String creationDate = zoneFormater.format(caseResponseType.getCaseInfo().getCreatedDate()
                            .toGregorianCalendar().getTime());
                    caseBean.setCreatedDate(creationDate);
                }
            }
            caseBean.setPriority(caseResponseType.getCaseInfo().getPriority());
            if (caseResponseType.getCaseInfo().getClosedDate() != null) {
                final String closedDate = zoneFormater.format(caseResponseType.getCaseInfo().getClosedDate()
                        .toGregorianCalendar().getTime());
                caseBean.setClosedDate(closedDate);
            }
            casesList.add(caseBean);
        }
        return casesList;
    }

    /**
     * @Author : IgatePatni
     * @param : caseBean
     * @return : solutionlst
     * @throws RMDWebException
     * @throws Exception
     * @Description: This method invokes the web service to get the alternate solutions information
     *               of given case ID . Convert the web service response(JAXB) to SolutionBean which
     *               will contain the details about the
     *               solutionId,solutionTitle,falseAlarm,rxAccuracy,rmdAccurate.
     */
    @Override
    public List<SolutionBean> getAlternateSolutions(final CaseBean caseBean) throws RMDWebException, Exception {
        rmdWebLogger.debug("AssetCasesServiceImpl : Inside getAlternateSolutions() method:::STARTT");
        final Map<String, String> qParamAsset = new LinkedHashMap<String, String>();
        final Map<String, String> headerParams = getHeaderMap(caseBean);
        List<SolutionBean> solutionlst = null;
        final Map<String, SolutionBean> resultMap = new HashMap<String, SolutionBean>();

        try {

            // This method gets the tool output.
            getAlternateSolutionsList(caseBean, resultMap);
            // This method gets list of added rx.
            getAddedRXList(caseBean, resultMap);
            solutionlst = new ArrayList<SolutionBean>(resultMap.values());

            //
        } catch (Exception ex) {
            RMDWebErrorHandler.handleException(ex);

        }

        return solutionlst;
    }

    private void getAddedRXList(CaseBean caseBean, Map<String, SolutionBean> resultMap) throws Exception {
        final Map<String, String> qParamAsset = new LinkedHashMap<String, String>();
        final Map<String, String> headerParams = getHeaderMap(caseBean);
        SolutionBean solutionBean;
        qParamAsset.put(AppConstants.WS_PARAM_CASEID_2, caseBean.getCaseId());
        CaseRxDetailsResponseType objCaseRxDetailsResponseType;
        final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
        final TimeZone timeZone = TimeZone.getTimeZone(caseBean.getTimeZone());
        /**
         * if the same Rx is already present in tool output , then Delv Date � (in user preferred
         * time zone) Urgency Est.Time to Repair Rev No. Service Req ID<Place holder> Reissue
         */

        try {
            objCaseRxDetailsResponseType = (CaseRxDetailsResponseType) webServiceInvoker.get(
                    ServiceConstants.GET_CASE_RX_DEATILS, qParamAsset, null, headerParams,
                    CaseRxDetailsResponseType.class);
            if (null != objCaseRxDetailsResponseType) {
                List<SolutionInfoType> addedRXList = objCaseRxDetailsResponseType.getSolutionInfo();
                // iterate resultsMap , get the solution bean object and set the
                // details.addedRXType
                for (SolutionInfoType addedRXType : addedRXList) {
                    // Start
                    final XMLGregorianCalendar creationDate = addedRXType.getSolutionDelvDate();
                    zoneFormater.setTimeZone(timeZone);
                    if (resultMap.containsKey(addedRXType.getSolutionOBJID())) {
                        SolutionBean toolOutPutSolnBean = (SolutionBean) resultMap.get(addedRXType.getSolutionOBJID());
                        if (null != addedRXType.getUrgency()) {
                            toolOutPutSolnBean.setUrgency(addedRXType.getUrgency());
                        } else {
                            toolOutPutSolnBean.setUrgency(AppConstants.HYPHEN);
                        }
                        if (null != addedRXType.getEstmRepTime()) {
                            toolOutPutSolnBean.setSolEstRepairTime(addedRXType.getEstmRepTime());
                        } else {
                            toolOutPutSolnBean.setSolEstRepairTime(AppConstants.HYPHEN);
                        }
                        if (null != addedRXType.getSolutionDelvDate()) {
                            toolOutPutSolnBean.setDelvDate(zoneFormater.format(creationDate.toGregorianCalendar()
                                    .getTime()));
                        } else {
                            toolOutPutSolnBean.setDelvDate(AppConstants.HYPHEN);
                        }
                        // now set versionNumber , serviceReqId , reissueFlag.
                        if (null != addedRXType.getSolutionVersion()) {
                            toolOutPutSolnBean.setVersion(addedRXType.getSolutionVersion());
                        } else {
                            toolOutPutSolnBean.setVersion(AppConstants.HYPHEN);
                        }
                        if (null != addedRXType.getSolutionServiceReqId()) {
                            toolOutPutSolnBean.setServiceReqId(addedRXType.getSolutionServiceReqId());
                        } else {
                            toolOutPutSolnBean.setServiceReqId(AppConstants.HYPHEN);
                        }
                        if (null != addedRXType.getSolutionReIssueFlag()) {
                            toolOutPutSolnBean.setReissueFlag(addedRXType.getSolutionReIssueFlag());
                        } else {
                            toolOutPutSolnBean.setReissueFlag(AppConstants.HYPHEN);
                        }
                        toolOutPutSolnBean.setCurrentRxId(addedRXType.getCurrentRxId());
                    } else {
                        solutionBean = new SolutionBean();
                        solutionBean.setSolutionTitle(addedRXType.getSolutionTitle());
                        solutionBean.setSolutionId(addedRXType.getSolutionOBJID());
                        if (null != addedRXType.getUrgency()) {
                            solutionBean.setUrgency(addedRXType.getUrgency());
                        } else {
                            solutionBean.setUrgency(AppConstants.HYPHEN);
                        }
                        if (null != addedRXType.getEstmRepTime()) {
                            solutionBean.setSolEstRepairTime(addedRXType.getEstmRepTime());
                        } else {
                            solutionBean.setSolEstRepairTime(AppConstants.HYPHEN);
                        }
                        solutionBean.setToolOutputFlag(AppConstants.NO_FLAG);
                        // added for setting the hyphen value to null value
                        solutionBean.setFalseAlarm(AppConstants.HYPHEN);
                        solutionBean.setRxAccuracy(AppConstants.HYPHEN);
                        solutionBean.setRmdAccurate(AppConstants.HYPHEN);
                        if (null != addedRXType.getSolutionDelvDate()) {

                            solutionBean.setDelvDate(zoneFormater.format(creationDate.toGregorianCalendar().getTime()));
                        } else {
                            solutionBean.setDelvDate(AppConstants.HYPHEN);
                        }
                        if (null != addedRXType.getSolutionVersion()) {
                            solutionBean.setVersion(addedRXType.getSolutionVersion());
                        } else {
                            solutionBean.setVersion(AppConstants.HYPHEN);
                        }
                        if (null != addedRXType.getSolutionServiceReqId()) {
                            solutionBean.setServiceReqId(addedRXType.getSolutionServiceReqId());
                        } else {
                            solutionBean.setServiceReqId(AppConstants.HYPHEN);
                        }
                        if (null != addedRXType.getSolutionReIssueFlag()) {
                            solutionBean.setReissueFlag(addedRXType.getSolutionReIssueFlag());
                        } else {
                            solutionBean.setReissueFlag(AppConstants.HYPHEN);
                        }
                        solutionBean.setCurrentRxId(addedRXType.getCurrentRxId());
                        resultMap.put(addedRXType.getSolutionOBJID(), solutionBean);
                    }

                    // End

                }
            }
        } catch (RMDWebException e) {
            rmdWebLogger.error("In AssetCasesServiceImpl : exception occured in getAddedRXList method "
                    + e.getMessage());
            if (!AppConstants.NO_RECORD_FOUND.equalsIgnoreCase(e.getMessage())) {
                rmdWebLogger.info("No record found");

            } else {
                throw e;
            }

        } catch (Exception ex) {
            rmdWebLogger.error("In AssetCasesServiceImpl : exception occured in getAddedRXList method "
                    + ex.getMessage());
            RMDWebErrorHandler.handleException(ex);

        }

    }

    private void getAlternateSolutionsList(CaseBean caseBean, Map<String, SolutionBean> resultMap)
            throws GenericAjaxException, RMDWebException {
        final Map<String, String> qParamAsset = new LinkedHashMap<String, String>();
        final Map<String, String> headerParams = getHeaderMap(caseBean);
        SolutionBean solutionBean;
        qParamAsset.put(AppConstants.WS_PARAM_CASEID_2, caseBean.getCaseId());
        ToolOutputDetailsResponseType[] solnResArr;
        try {
            solnResArr = (ToolOutputDetailsResponseType[]) webServiceInvoker.get(
                    ServiceConstants.GET_ALTERNATE_SOLUTIONS, null, qParamAsset, headerParams,
                    ToolOutputDetailsResponseType[].class);

            for (ToolOutputDetailsResponseType toolOutputDetailsResponseType : solnResArr) {
                solutionBean = new SolutionBean();
                solutionBean.setSolutionId(toolOutputDetailsResponseType.getSolutionID());
                solutionBean.setSolutionTitle(toolOutputDetailsResponseType.getSolutionTitle());
                solutionBean.setSolEstRepairTime(toolOutputDetailsResponseType.getEstRepairTime());
                solutionBean.setUrgency(toolOutputDetailsResponseType.getUrgency());
                solutionBean.setToolOutputFlag(AppConstants.YES_FLAG);
                // added for setting the hyphen value to null values
                if (null != toolOutputDetailsResponseType.getFalseAlarmPct()) {
                    solutionBean.setFalseAlarm(toolOutputDetailsResponseType.getFalseAlarmPct().toString());
                } else {
                    solutionBean.setFalseAlarm(AppConstants.HYPHEN);

                }
                if (null != toolOutputDetailsResponseType.getToolCovgPct()) {
                    solutionBean.setRxAccuracy(toolOutputDetailsResponseType.getToolCovgPct().toString());
                } else {
                    solutionBean.setRxAccuracy(AppConstants.HYPHEN);
                }
                if (null != toolOutputDetailsResponseType.getMdscPerfPct()) {
                    solutionBean.setRmdAccurate(toolOutputDetailsResponseType.getMdscPerfPct().toString());
                } else {
                    solutionBean.setRmdAccurate(AppConstants.HYPHEN);
                }
                solutionBean.setDelvDate(AppConstants.HYPHEN);
                solutionBean.setVersion(AppConstants.HYPHEN);
                solutionBean.setServiceReqId(AppConstants.HYPHEN);
                solutionBean.setReissueFlag(AppConstants.HYPHEN);
                resultMap.put(toolOutputDetailsResponseType.getSolutionID(), solutionBean);
            }
        } catch (RMDWebException ex) {
            rmdWebLogger.error("In AssetCasesServiceImpl : Exception occured in getAlternateSolutionsList method "
                    + ex.getMessage());
            RMDWebErrorHandler.handleException(ex);

        }

    }

    /**
     * @Author : IgatePatni
     * @param : caseBean
     * @return : caseHistorylst
     * @throws RMDWebException
     * @throws Exception
     * @Description: This method invokes the web service to get the history / notes information of
     *               given case ID . Convert the web service response(JAXB) to NotesBean which will
     *               contain the details about the notes description,posted date, author of note.
     */
    @Override
    public CaseHistoryBean getCaseHistory(final CaseBean caseBean) throws RMDWebException, Exception {
        rmdWebLogger.debug("AssetCasesServiceImpl : Inside getCaseHistory() method:::::START");
        final Map<String, String> qParamAsset = new LinkedHashMap<String, String>();
        final Map<String, String> headerParams = getHeaderMap(caseBean);
        final List<NotesBean> caseHistorylst = new ArrayList<NotesBean>();
        CaseHistoryBean caseHistoryBean = new CaseHistoryBean();
        try {

            qParamAsset.put(AppConstants.WS_PARAM_CASEID_1, caseBean.getCaseId());

            final CaseDetailsResponseType casesRes = (CaseDetailsResponseType) webServiceInvoker.get(
                    ServiceConstants.GET_CASES_HISTORY, null, qParamAsset, headerParams, CaseDetailsResponseType.class);
            NotesBean notesBean;
            final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
            final TimeZone firstTime = TimeZone.getTimeZone(caseBean.getTimeZone());
            if (casesRes != null) {
                caseHistoryBean.setNotesList(caseHistorylst);
                final List<CaseHistoryType> caseInfo = casesRes.getCaseHistory();
                final List<CaseInfoType> caseTypeInfo = casesRes.getCaseInfo();
                for (int i = 0; i < caseInfo.size(); i++) {
                    if (null != caseInfo.get(i)) {
                        notesBean = new NotesBean();
                        notesBean.setNoteDescription(AppSecUtil.revertEncode(caseInfo.get(i).getActivityDesc()));
                        notesBean.setCreatedBy(caseInfo.get(i).getWho());
                        if (null != caseInfo.get(i).getActivityDate()) {
                            final XMLGregorianCalendar creationDate = caseInfo.get(i).getActivityDate();
                            zoneFormater.setTimeZone(firstTime);
                            notesBean
                                    .setCreationDate(zoneFormater.format(creationDate.toGregorianCalendar().getTime()));
                        }
                        notesBean.setDescriptionURL(caseInfo.get(i).getDescriptionURL());
                        caseHistorylst.add(notesBean);
                    }
                }
                if (null != caseTypeInfo && null != caseTypeInfo.get(0)) {
                    caseHistoryBean.setCaseCondition(caseTypeInfo.get(0).getCondition());
                    caseHistoryBean.setCurrentRxStatus(caseTypeInfo.get(0).getCurrentRxStatus());
                    caseHistoryBean.setCurrentRxCaseId(caseTypeInfo.get(0).getCurrentRxDelvId());
                    caseHistoryBean.setCurrentSolutionId(caseTypeInfo.get(0).getCurrentRxId());
                    caseHistoryBean.setCurrentRecomNotes(caseTypeInfo.get(0).getCurrentRxNotes());
                }
            }

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getCaseHistory method ", ex);
            throw ex;

        }
        rmdWebLogger.debug("AssetCasesServiceImpl : Inside getCaseHistory() method:::::END");
        return caseHistoryBean;
    }
    /**
     * @Author : IgatePatni
     * @param : notesBean
     * @return : String
     * @throws RMDWebException
     * @throws Exception
     * @Description: This method invokes the web service to put the information of notes of asset
     *               number's case.
     */
    @Override
    public String postNotes(final NotesBean notesBean) throws RMDWebException, Exception {

        final Map<String, String> headerParams = getHeaderMap(notesBean);
        final NotesRequestType notesRequestType = new NotesRequestType();
        final NotesInfo notesInfo = new NotesInfo();
        String returnStr = AppConstants.FAILURE;
        try {

            notesInfo.setCaseID(notesBean.getCaseID());
            notesRequestType.setFromPage(AppConstants.CASE);
            notesRequestType.setSticky(AppConstants.NO);
            notesRequestType.setFromAsset(notesBean.getAssetNumber());
            notesRequestType.setToAsset(notesBean.getAssetNumber());
            notesRequestType.setNotes(notesBean.getNoteDescription());
            notesRequestType.setNotesInfo(notesInfo);
            notesRequestType.setAssetGrpName(notesBean.getAssetGroup());
            notesRequestType.setCustomerID(notesBean.getCustomerId());

            webServiceInvoker.put(ServiceConstants.POST_NOTES, notesRequestType, headerParams);
            returnStr = AppConstants.SUCCESS;
        } catch (RMDWebException e) {
            rmdWebLogger.error("Exception occured in postNotes() method ", e);
            if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
                returnStr = AppConstants.FAILURE;
            } else {
                throw e;
            }
        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in postNotes() method ", e);

            throw e;

        }

        return returnStr;

    }

    public List<String> getCaseListLookBackDays(String listName) throws RMDWebException, Exception {

        List<String> caseListLookBackDays = new ArrayList<String>();

        final Map<String, String> pathParamsPastDays = new LinkedHashMap<String, String>();
        pathParamsPastDays.put(AppConstants.LIST_NAME, listName);

        final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParamsPastDays);
        for (int i = 0; i < applParamResponseType.length; i++) {
            caseListLookBackDays.add(applParamResponseType[i].getLookupValue());
        }

        return caseListLookBackDays;
    }

    /**
     * @Author : IgatePatni
     * @param : assetNumber
     * @return : assetOverviewBean
     * @throws RMDWebException
     * @throws Exception
     * @Description: This method invokes the web service to get the asset information. Convert the
     *               web service response(JAXB) to assetOverviewBean which will contain the details
     *               about the asset,customer,model,fleet,roadIntial.
     */
    @Override
    public Future<AssetOverviewBean> getAssets(final AssetOverviewBean assetOverviewBean) throws RMDWebException,
            Exception {
        rmdWebLogger.debug("AssetOverviewServiceImpl : Inside getAssets() method::START");
        final Map<String, String> qParamAsset = new LinkedHashMap<String, String>();
        final Map<String, String> headerParams = getHeaderMap(assetOverviewBean);
        AssetOverviewBean objAssetOverviewBean = null;
        try {
            AssetsRequestType objAssetsReqType = new AssetsRequestType();
            objAssetsReqType.setLanguage(headerParams.get(AppConstants.USER_LANGUAGE));
            objAssetsReqType.setCustomerId(assetOverviewBean.getCustomer());
            objAssetsReqType.setAssetNumber(assetOverviewBean.getAsset());
            objAssetsReqType.setAssetGrpName(assetOverviewBean.getAssetGroup());
            final AssetResponseType[] assetResponseType = (AssetResponseType[]) webServiceInvoker.post(
                    ServiceConstants.GET_ASSETS, objAssetsReqType, AssetResponseType[].class);
            if (null != assetResponseType && assetResponseType.length > 0) {

                for (AssetResponseType assetResponse : assetResponseType) {
                    if (assetResponse.getAssetNumber().equalsIgnoreCase(assetOverviewBean.getAsset())
                            && assetResponse.getCustomerID().equalsIgnoreCase(assetOverviewBean.getCustomer())
                            && assetResponse.getAssetGroupName().equalsIgnoreCase(assetOverviewBean.getAssetGroup())) {
                        objAssetOverviewBean = new AssetOverviewBean();
                        objAssetOverviewBean.setRoadIntial(assetResponse.getAssetGroupName());
                        objAssetOverviewBean.setCustomer(assetResponse.getCustomerName());
                        objAssetOverviewBean.setAsset(assetResponse.getAssetNumber());
                        objAssetOverviewBean.setModel(assetResponse.getModel());
                        objAssetOverviewBean.setFleet(assetResponse.getFleet());
                        objAssetOverviewBean.setDsControllerConfig(assetResponse.getDsControllerConfig());
                        objAssetOverviewBean.setControllerConfig(assetResponse.getControllerCfg());
                        objAssetOverviewBean.setAssetObjid(assetResponse.getAssetObjid());
                        objAssetOverviewBean.setLmsLocoId(assetResponse.getLmsLocoId());
                        objAssetOverviewBean.setBadActor(assetResponse.getBadActor());
                        objAssetOverviewBean.setVehicleObjId(assetResponse.getSourceObjid());
                        objAssetOverviewBean.setAssetGrpHdrNo(assetResponse.getAssetGroupNumber());
                        break;
                    }
                }
            }

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getAssets method ", ex);
            RMDWebErrorHandler.handleException(ex);

        }
        rmdWebLogger.debug("AssetOverviewServiceImpl : Inside getAssets() method::END");
        return new AsyncResult<AssetOverviewBean>(objAssetOverviewBean);
    }
    /**
     * @Author : GE
     * @param :
     * @return : AssetLastFaultStatusVO
     * @throws RMDWebException
     * @Description: This method will fetch the last fault status of the asset
     */
    @Override
    public Future<AssetLastFaultStatusVO> getLastFaultStatus(final AssetOverviewBean assetOverviewBean)
            throws RMDWebException, Exception {
        rmdWebLogger.debug("AssetOverviewServiceImpl : Inside getLstFaultStatus() method::START");
        final AssetLastFaultStatusVO lstFaultStatVO = new AssetLastFaultStatusVO();
        final Map<String, String> queryParamsMap = new HashMap<String, String>();
        try {
            if (null != assetOverviewBean) {

                queryParamsMap.put(AppConstants.ASSET_NUMBER, assetOverviewBean.getAsset());
                queryParamsMap.put(AppConstants.CUSTOMER_ID, assetOverviewBean.getCustomer());
                queryParamsMap.put(AppConstants.ASSET_GROUP_NAME, assetOverviewBean.getAssetGroup());
            }

            final LastFaultStatusResponseType lstFaultStatResp = (LastFaultStatusResponseType) webServiceInvoker.get(
                    ServiceConstants.GET_LAST_FAULT_STATUS, null, queryParamsMap, null,
                    LastFaultStatusResponseType.class);
            if (lstFaultStatResp != null && !lstFaultStatResp.toString().isEmpty()) {
                final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
                final TimeZone firstTime = TimeZone.getTimeZone(assetOverviewBean.getUserTimeZone());
                zoneFormater.setTimeZone(firstTime);

                if (lstFaultStatResp.getLstEOAFault() != null
                        && !lstFaultStatResp.getLstEOAFault().toString().isEmpty()) {

                    lstFaultStatVO.setLstEOAFault(zoneFormater.format(lstFaultStatResp.getLstEOAFault()
                            .toGregorianCalendar().getTime()));
                }
                lstFaultStatVO.setLstEOAFaultHeader(lstFaultStatResp.getLstEOAFaultHeader());

                if (lstFaultStatResp.getLstESTPDownload() != null
                        && !lstFaultStatResp.getLstESTPDownload().toString().isEmpty()) {
                    lstFaultStatVO.setLstESTPDownload(zoneFormater.format(lstFaultStatResp.getLstESTPDownload()
                            .toGregorianCalendar().getTime()));
                }
                lstFaultStatVO.setLstESTPDownloadHeader(lstFaultStatResp.getLstESTPDownloadHeader());

                if (lstFaultStatResp.getLstPPATSMsg() != null
                        && !lstFaultStatResp.getLstPPATSMsg().toString().isEmpty()) {
                    lstFaultStatVO.setLstPPATSMsg(zoneFormater.format(lstFaultStatResp.getLstPPATSMsg()
                            .toGregorianCalendar().getTime()));
                }
                lstFaultStatVO.setLstPPATSMsgHeader(lstFaultStatResp.getLstPPATSMsgHeader());

            }
        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error("RMDWebException occured in getLstFaultStatus() method ", rmdEx);
            throw rmdEx;
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getLstFaultStatus() method ", ex);
            throw ex;
        }
        rmdWebLogger.debug("AssetOverviewServiceImpl : Inside getLstFaultStatus() method::END");
        return new AsyncResult<AssetLastFaultStatusVO>(lstFaultStatVO);
    }

    /**
     * @Author : GE
     * @param :
     * @return : Future<AssetLocatorResponseVO>
     * @throws RMDWebException
     * @Description: This method will fetch the last fault status and the assetlocation details of
     *               the asset
     */
    @Override
    public Future<AssetInstalledProductVO> getAssetInstalledProduct(final AssetOverviewBean overviewBean)
            throws RMDWebException, Exception {
        rmdWebLogger.debug("AssetOverviewServiceImpl : Inside getAssetInstalledProduct() method::START");
        final AssetInstalledProductVO assetInstalledProdVo = new AssetInstalledProductVO();
        final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
        final TimeZone firstTime = TimeZone.getTimeZone(overviewBean.getUserTimeZone());
        AssetsRequestType objAssetsRequestType = new AssetsRequestType();
        zoneFormater.setTimeZone(firstTime);

        try {
            if (null != overviewBean) {
                objAssetsRequestType.setCustomerId(overviewBean.getCustomer());
                objAssetsRequestType.setAssetNumber(overviewBean.getAsset());
                objAssetsRequestType.setAssetGrpName(overviewBean.getAssetGroup());
            }
            final AssetInstalledProductResponseType[] arrAssetInstalledProdResponse = (AssetInstalledProductResponseType[]) webServiceInvoker
                    .post(ServiceConstants.ASSET_SERVICE_GET_INSTALLED_PRODUCT, objAssetsRequestType,
                            AssetInstalledProductResponseType[].class);

            if (null != arrAssetInstalledProdResponse && arrAssetInstalledProdResponse.length > 0) {
                final AssetInstalledProductResponseType assetInstalledProdResponse = arrAssetInstalledProdResponse[0];
                if (null != assetInstalledProdResponse.getPartNumber()) {
                    assetInstalledProdVo.setPartNumber(assetInstalledProdResponse.getPartNumber());
                }
                if (null != assetInstalledProdResponse.getDescription()) {
                    assetInstalledProdVo.setDescription(assetInstalledProdResponse.getDescription());
                }

                if (null != assetInstalledProdResponse.getWarrantyEndDate()) {
                    assetInstalledProdVo.setWarrantyEndDate(zoneFormater.format(assetInstalledProdResponse
                            .getWarrantyEndDate().toGregorianCalendar().getTime()));
                }

            }
        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error("RMDWebException occured in getAssetInstalledProduct() method ", rmdEx);
            throw rmdEx;
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getAssetInstalledProduct() method ", ex);
            throw ex;
        }
        rmdWebLogger.debug("AssetOverviewServiceImpl : Inside getAssetInstalledProduct() method::END");
        return new AsyncResult<AssetInstalledProductVO>(assetInstalledProdVo);
    }

    /**
     * @Author : IgatePatni
     * @param : assetNumber, userVO, assetOverviewBean
     * @return : assetOverviewBean
     * @throws RMDWebException
     * @throws Exception
     * @Description: This method invokes the web service to get the information of last time status
     *               of fault, faultReset, healthCheck,aliveMessage sent of asset number. Convert
     *               the web service response(JAXB) to assetOverviewBean which will contain the
     *               details about the latest time of fault, faultReset, healthCheck,aliveMessage.
     */
    @Override
    public Future<AssetOverviewBean> getVehicleCommStatus(final AssetOverviewBean assetOverviewBean)
            throws RMDWebException, Exception {
        rmdWebLogger.debug("AssetOverviewServiceImpl : Inside getVehicleCommStatus() method::START");
        final Map<String, String> qParamAsset = new LinkedHashMap<String, String>();
        final Map<String, String> headerParams = getHeaderMap(assetOverviewBean);

        try {

            qParamAsset.put(AppConstants.WS_PARAM_ASSTNUM, assetOverviewBean.getAsset());
            qParamAsset.put(AppConstants.WS_PARAM_ASSTGRP, assetOverviewBean.getAssetGroup());
            qParamAsset.put(AppConstants.WS_PARAM_CUSTID, assetOverviewBean.getCustomer());

            final VehicleCommStatusResponseType[] vehiclComStatResp = (VehicleCommStatusResponseType[]) webServiceInvoker
                    .get(ServiceConstants.GET_VEHICLECOMMSTATUS, null, qParamAsset, headerParams,
                            VehicleCommStatusResponseType[].class);

            final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
            final TimeZone firstTime = TimeZone.getTimeZone(assetOverviewBean.getUserTimeZone());
            zoneFormater.setTimeZone(firstTime);

            if (null != vehiclComStatResp[0].getLastFaultReceivedTime()) {

                assetOverviewBean.setLastFaultReceived(zoneFormater.format(vehiclComStatResp[0]
                        .getLastFaultReceivedTime().toGregorianCalendar().getTime()));
            }
            if (null != vehiclComStatResp[0].getLastFaultResetTime()) {
                assetOverviewBean.setLastFaultResetTime(zoneFormater.format(vehiclComStatResp[0]
                        .getLastFaultResetTime().toGregorianCalendar().getTime()));
            }
            if (null != vehiclComStatResp[0].getLastHealthChkRequestTime()) {
                assetOverviewBean.setLastHealthCheckResponse(zoneFormater.format(vehiclComStatResp[0]
                        .getLastHealthChkRequestTime().toGregorianCalendar().getTime()));
            }
            if (null != vehiclComStatResp[0].getLastKeepAliveMsgRevdTime()) {
                assetOverviewBean.setLastKeepAliveMsgReceived(zoneFormater.format(vehiclComStatResp[0]
                        .getLastKeepAliveMsgRevdTime().toGregorianCalendar().getTime()));
            }
            if (null != vehiclComStatResp[0].getControllerConfig()) {
                assetOverviewBean.setControllerConfig(vehiclComStatResp[0].getControllerConfig());
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getVehicleCommStatus method ", ex);
            RMDWebErrorHandler.handleException(ex);

        }
        rmdWebLogger.debug("AssetOverviewServiceImpl : Inside getVehicleCommStatus() method::END");
        return new AsyncResult<AssetOverviewBean>(assetOverviewBean);
    }

    /**
     * @Author:
     * @param case id
     * @return CaseBean
     * @Description: return the list of all the rx associated with the case
     */
    @Override
    public List<SolutionDetailVO> getCaseRxHistory(String caseId, String timezone) throws RMDWebException, Exception {
        final Map<String, String> pathParamsMap = new HashMap<String, String>();
        SolutionInfoType[] caseRxHistoryResponceList = null;
        List<SolutionDetailVO> caseRxHistoryVoList = new ArrayList<SolutionDetailVO>();
        SolutionDetailVO solutionBean = null;
        XMLGregorianCalendar solutionDelvDateXMLGC = null;
        final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
        final TimeZone firstTime = TimeZone.getTimeZone(timezone);
        zoneFormater.setTimeZone(firstTime);
        try {
            pathParamsMap.put(AppConstants.CASE_ID, caseId);
            caseRxHistoryResponceList = (SolutionInfoType[]) webServiceInvoker.get(
                    ServiceConstants.GET_CASE_RX_HISTORY, pathParamsMap, null, null, SolutionInfoType[].class);

            for (SolutionInfoType currentRx : caseRxHistoryResponceList) {
                solutionBean = new SolutionDetailVO();
                solutionBean.setSolutionID(currentRx.getSolutionCaseID());
                solutionBean.setSolutionTitle(currentRx.getSolutionTitle());
                solutionDelvDateXMLGC = currentRx.getSolutionDelvDate();
                if (null != solutionDelvDateXMLGC) {
                    final GregorianCalendar solutionDelvDateGC = solutionDelvDateXMLGC.toGregorianCalendar();
                    solutionBean.setStrSolutionDelvDt(zoneFormater.format(solutionDelvDateGC.getTime()));
                }
                solutionBean.setUrgRepair(currentRx.getUrgency());
                solutionBean.setEstmTimeRepair(currentRx.getEstmRepTime());
                solutionBean.setRepairAction(currentRx.getRepairAction());
                solutionBean.setFeedback(currentRx.getFeedback());
                solutionBean.setFeedbackCode(currentRx.getFeedbackCode());
                caseRxHistoryVoList.add(solutionBean);
            }
        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in getCaseRxHistory method ", e);
            RMDWebErrorHandler.handleException(e);
        }
        return caseRxHistoryVoList;
    }

    public Future<List<CaseTypeBean>> getCaseType() throws RMDWebException {
        rmdWebLogger.debug("Inside AssetCaseServiceImpl in getCaseType Method");

        final Map<String, String> pathParamMap = new LinkedHashMap<String, String>();
        List<CaseTypeBean> caseTypeList = new ArrayList<CaseTypeBean>();
        CaseTypeBean caseTypeBean = null;
        try {
            pathParamMap.put(RMDCommonConstants.LIST_NAME, RMDCommonConstants.PREVIOUS_CASE_TYPES);
            ApplicationParametersResponseType[] arrayCaseTypeResponse = (ApplicationParametersResponseType[]) webServiceInvoker
                    .get(ServiceConstants.GET_EOA_LOOKUP_VALUES, pathParamMap, null, null,
                            ApplicationParametersResponseType[].class);

            if (arrayCaseTypeResponse.length != 0) {
                for (int i = 0; i < arrayCaseTypeResponse.length; i++) {
                    caseTypeBean = new CaseTypeBean();
                    caseTypeBean.setCaseTypeTitle(arrayCaseTypeResponse[i].getLookupValue());
                    caseTypeList.add(caseTypeBean);
                }
            }
            /*
             * Collections.sort(caseTypeList, new Comparator<CaseTypeBean>(){
             * @Override public int compare(CaseTypeBean caseBean1, CaseTypeBean caseBean2) { return
             * caseBean1.getCaseTypeTitle().compareTo(caseBean2.getCaseTypeTitle()); } });
             */
        } catch (Exception rmdEx) {
            rmdWebLogger.error("Exception occured in getCaseType method ", rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }
        return new AsyncResult<List<CaseTypeBean>>(caseTypeList);
    }

    /**
     * @Author :
     * @return :List<QueueDetailsVO>
     * @param :
     * @throws :RMDWebException
     * @Description:This method is used for fetching a list of Dynamic work QueueNames from Data
     *                   Base.
     */

    @Override
    public List<QueueDetailsVO> getQueueNames(String caseId) throws RMDWebException, Exception {
        QueueDetailsResponseType[] objQueueResponseTypeList = null;
        final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
        queryParamMap.put(AppConstants.CASE_ID, caseId);
        List<QueueDetailsVO> queueList = new ArrayList<QueueDetailsVO>();
        QueueDetailsVO queuebean = null;
        try {
            rmdWebLogger.debug("Begin of getQueueNames method in AssetCasesServiceImpl");
            objQueueResponseTypeList = (QueueDetailsResponseType[]) webServiceInvoker.get(
                    ServiceConstants.GET_QUEUE_NAMES, null, queryParamMap, null, QueueDetailsResponseType[].class);
            if (null != objQueueResponseTypeList && objQueueResponseTypeList.length > 0) {
                for (QueueDetailsResponseType objQueueDetailsResponseType : objQueueResponseTypeList) {
                    queuebean = new QueueDetailsVO();
                    queuebean.setQueueId(objQueueDetailsResponseType.getQueueId());
                    queuebean.setQueueName(objQueueDetailsResponseType.getQueueName());
                    queueList.add(queuebean);
                }
            }
        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in getQueueNamemethod  in AssetCaseServiceImpl", e);
            RMDWebErrorHandler.handleException(e);
        }
        rmdWebLogger.debug("End of getQueueNames method in AssetCasesServiceImpl");
        return queueList;
    }

    /**
     * @Author :
     * @return :String
     * @param :queueId,caseId,userId
     * @throws :RMDWebException
     * @Description:This method is used for a dispatching case to dynamic work queues selected by
     *                   the user.
     */
    @Override
    public String dispatchCaseToWorkQueue(final long queueId, final String caseId, final String userId)
            throws RMDWebException, Exception {

        String result = AppConstants.FAILURE;;

        try {
            rmdWebLogger.debug("Begin of dispatchCaseToQueue method in AssetCasesServiceImpl");
            CaseRequestType objCaseRequestType = new CaseRequestType();
            objCaseRequestType.setCaseID(caseId);
            objCaseRequestType.setUserId(userId);
            objCaseRequestType.setQueueId(queueId);
            result = (String) webServiceInvoker.post(ServiceConstants.DISPATCH_CASE_TO_QUEUE, objCaseRequestType,
                    String.class);

        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in dispatchToQueue in AssetCasesServiceImpl", e);
            RMDWebErrorHandler.handleException(e);

        }
        rmdWebLogger.debug("End of dispatchCaseToQueue method in AssetCasesServiceImpl");
        return result;
    }

    /**
     * @Author :
     * @return :String
     * @param :AddNotesEoaServiceVO
     * @throws : RMDWebException
     * @Description:This method is used for adding Case notes for a given case.
     */

    @Override
    public String addNotesToCase(final NotesBean notesBean) throws RMDWebException, Exception {
        String result = null;
        NotesRequestType requestobj = null;
        try {

            if (null != notesBean) {
                requestobj = new NotesRequestType();
                requestobj.setCaseId(notesBean.getCaseID());
                requestobj.setApplyLevel(notesBean.getApplyLevel());
                requestobj.setNotes(EsapiUtil.escapeSpecialChars(ESAPI.encoder().encodeForXML(notesBean.getNoteDescription())));
                requestobj.setSticky(notesBean.getSticky());
                requestobj.setUserId(notesBean.getUserId());

                result = (String) webServiceInvoker.post(ServiceConstants.ADD_NOTES_TO_CASE, requestobj, String.class);

            }

        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in dispatchToQueue   in AssetCasesServiceImpl:", e);
            RMDWebErrorHandler.handleException(e);
        }
        return result;
    }

    /**
     * @Author :
     * @return :StickyNotesDetailsVO
     * @param :caseId
     * @throws :RMDWebException,Exception
     * @Description:This method is used fetching case Sticky notes details for a given case.
     */
    @Override
    public StickyNotesDetailsVO fetchStickyCaseNotes(final String caseId, String timezone) throws RMDWebException,
            Exception {
        StickyNotesDetailsVO objStickyNotesDetailsVO = null;
        final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
        final TimeZone timeZone = TimeZone.getTimeZone(timezone);
        try {

            final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
            queryParamMap.put(AppConstants.CASE_ID, caseId);

            StickyNotesDetailsResponseType notesDetails = (StickyNotesDetailsResponseType) webServiceInvoker.get(
                    ServiceConstants.FETCH_CASE_STICKY_DETAILS, null, queryParamMap, null,
                    StickyNotesDetailsResponseType.class);

            if (null != notesDetails) {
                objStickyNotesDetailsVO = new StickyNotesDetailsVO();
                objStickyNotesDetailsVO.setApplyLevel(notesDetails.getApplyLevel());
                objStickyNotesDetailsVO.setAdditionalInfo(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(
                        notesDetails.getAdditionalInfo())));
                objStickyNotesDetailsVO.setCreatedBy(notesDetails.getCreatedBy());
                objStickyNotesDetailsVO.setObjId(notesDetails.getObjId());
                final XMLGregorianCalendar entryTime = notesDetails.getEntryTime();
                zoneFormater.setTimeZone(timeZone);
                if (null != notesDetails.getEntryTime()) {
                    objStickyNotesDetailsVO
                            .setEntryTime(zoneFormater.format(entryTime.toGregorianCalendar().getTime()));
                }
            }

        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in fetchStickyCaseNOtes in AssetCasesServiceImpl:", e);
            RMDWebErrorHandler.handleException(e);

        }

        return objStickyNotesDetailsVO;
    }

    /**
     * @Author :
     * @return :StickyNotesDetailsVO
     * @param :caseId
     * @throws :RMDWebException,Exception
     * @Description:This method is used fetching unit Sticky notes details for a given case.
     */
    @Override
    public StickyNotesDetailsVO fetchStickyUnitNotes(final String caseId, String timezone) throws RMDWebException,
            Exception {
        StickyNotesDetailsVO objStickyNotesDetailsVO = null;
        final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
        final TimeZone timeZone = TimeZone.getTimeZone(timezone);
        try {

            final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
            queryParamMap.put(AppConstants.CASE_ID, caseId);

            StickyNotesDetailsResponseType notesDetails = (StickyNotesDetailsResponseType) webServiceInvoker.get(
                    ServiceConstants.FETCH_UNIT_STICKY_DETAILS, null, queryParamMap, null,
                    StickyNotesDetailsResponseType.class);
            if (null != notesDetails) {
                objStickyNotesDetailsVO = new StickyNotesDetailsVO();
                objStickyNotesDetailsVO.setApplyLevel(notesDetails.getApplyLevel());
                
                objStickyNotesDetailsVO.setAdditionalInfo(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(
                        notesDetails.getAdditionalInfo())));
                objStickyNotesDetailsVO.setCreatedBy(notesDetails.getCreatedBy());
                objStickyNotesDetailsVO.setObjId(notesDetails.getObjId());
                final XMLGregorianCalendar entryTime = notesDetails.getEntryTime();
                zoneFormater.setTimeZone(timeZone);
                if (null != notesDetails.getEntryTime()) {
                    objStickyNotesDetailsVO
                            .setEntryTime(zoneFormater.format(entryTime.toGregorianCalendar().getTime()));
                }

            }
        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in fetchStickyCaseNOtes in AssetCasesServiceImpl:", e);
            RMDWebErrorHandler.handleException(e);

        }

        return objStickyNotesDetailsVO;
    }

    /**
     * @Author:
     * @param:
     * @return: List<CaseMgmtUsersDetails>
     * @throws:RMDWebException
     * @Description: This method fetches the users by invoking web services
     *               getCaseMgmtUsersDetails() method.
     */

    @Override
    public List<CaseMgmtUsersDetailsVO> getCaseMgmtUsersDetails() throws RMDWebException {
        List<CaseMgmtUsersDetailsVO> objCaseMgmtUsersDetailsList = null;
        CaseMgmtUsersResponseType[] objCaseMgmtUsersResponseType = null;
        CaseMgmtUsersDetailsVO objCaseMgmtUsersDetailsVO = null;
        try {

            objCaseMgmtUsersResponseType = (CaseMgmtUsersResponseType[]) webServiceInvoker.get(
                    ServiceConstants.GET_CASE_MGMT_USER_NAMES, null, null, null, CaseMgmtUsersResponseType[].class);
            if (null != objCaseMgmtUsersResponseType && objCaseMgmtUsersResponseType.length > 0) {
                objCaseMgmtUsersDetailsList = new ArrayList<CaseMgmtUsersDetailsVO>();
                for (CaseMgmtUsersResponseType objUserNamesResponseType : objCaseMgmtUsersResponseType) {
                    objCaseMgmtUsersDetailsVO = new CaseMgmtUsersDetailsVO();
                    objCaseMgmtUsersDetailsVO.setUserId(objUserNamesResponseType.getUserId());
                    objCaseMgmtUsersDetailsVO.setFirstName(objUserNamesResponseType.getFirstName());
                    objCaseMgmtUsersDetailsVO.setLastName(objUserNamesResponseType.getLastName());
                    objCaseMgmtUsersDetailsVO.setSso(objUserNamesResponseType.getSso());
                    objCaseMgmtUsersDetailsList.add(objCaseMgmtUsersDetailsVO);
                }

            }

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getCaseMgmtUsersDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);

        }

        return objCaseMgmtUsersDetailsList;
    }

    /**
     * @Author:
     * @param:userId ,caseId
     * @return:String
     * @throws:RMDWebException
     * @Description: This method assigns case to the user by invoking web services getOwnerForCase()
     *               method.
     */

    @Override
    public String assignCaseToUser(String userId, String caseId) throws RMDWebException {
        String result = AppConstants.FAILURE;
        CaseRequestType objCaseRequestType = new CaseRequestType();
        try {

            objCaseRequestType.setUserId(userId);
            objCaseRequestType.setCaseID(caseId);
            result = (String) webServiceInvoker.post(ServiceConstants.ASSIGN_TO_USER, objCaseRequestType, String.class);

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in assignCaseToUser method ", ex);
            RMDWebErrorHandler.handleException(ex);

        }

        return result;
    }

    /**
     * @Author:
     * @param:caseId
     * @return:String
     * @throws:RMDWebException
     * @Description: This method fetches the owner for respective case id by invoking web services
     *               getOwnerForCase() method.
     */

    @Override
    public CaseBean getCaseCurrentOwnerDetails(String caseId) throws RMDWebException {
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        CaseBean objCaseBean = new CaseBean();
        CaseInfoType objDetailsResponseType = null;
        try {

            if (null != caseId) {
                queryParams.put(AppConstants.CASE_ID, caseId);
            }
            objDetailsResponseType = (CaseInfoType) webServiceInvoker.get(ServiceConstants.GET_OWNER_FOR_CASE, null,
                    queryParams, null, CaseInfoType.class);
            if (null != objDetailsResponseType) {
                objCaseBean.setQueueName(objDetailsResponseType.getQueueName());
                objCaseBean.setCondition(objDetailsResponseType.getCondition());
                objCaseBean.setOwner(objDetailsResponseType.getOwner());

            }

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getOwnerForCase method ", ex);
            RMDWebErrorHandler.handleException(ex);

        }

        return objCaseBean;
    }

    /**
     * @Author:
     * @param:caseId
     * @return:List<CaseHistoryVO>
     * @throws:RMDWebException
     * @Description: This method fetches the set of activities based on case id by invoking web
     *               services getCaseHistory() method.
     */

    @Override
    public List<CaseHistoryVO> getCaseHistory(String caseId, String timeZone) throws RMDWebException {
        List<CaseHistoryVO> caseHistoryVOList = null;
        CaseHistoryResponseType[] objCaseHistoryResponseType = null;
        CaseHistoryVO objCaseHistoryVO = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
        final TimeZone firstTime = TimeZone.getTimeZone(timeZone);
        zoneFormater.setTimeZone(firstTime);
        Date creationTime = null;
        try {

            if (null != caseId) {
                queryParams.put(AppConstants.CASE_ID, caseId);
            }
            objCaseHistoryResponseType = (CaseHistoryResponseType[]) webServiceInvoker.get(
                    ServiceConstants.CASE_HISTORY, null, queryParams, null, CaseHistoryResponseType[].class);

            if (null != objCaseHistoryResponseType && objCaseHistoryResponseType.length > 0) {
                caseHistoryVOList = new ArrayList<CaseHistoryVO>(objCaseHistoryResponseType.length);
                for (CaseHistoryResponseType details : objCaseHistoryResponseType) {
                    objCaseHistoryVO = new CaseHistoryVO();
                    objCaseHistoryVO.setActivity(details.getActivity());
                    if (details.getCreateDate() != null) {
                        if (timeZone.equals(AppConstants.EST_TIMEZONE)) {
                            objCaseHistoryVO.setCreateDate(details.getCreateDate());
                        } else {
                            creationTime = RMDCommonUtility.stringToUSESTDate(details.getCreateDate(),
                                    RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
                            objCaseHistoryVO.setCreateDate(zoneFormater.format(creationTime));
                        }
                        // final String creationDate = zoneFormater.format(details
                        // .getCreateDate().toGregorianCalendar()
                        // .getTime());

                    }
                    objCaseHistoryVO.setUser(details.getUser());
                    objCaseHistoryVO.setAddInfo(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(details.getAddInfo())));
                    objCaseHistoryVO.setActivityType(details.getActivityType());
                    objCaseHistoryVO.setObjId(details.getObjId());
                    objCaseHistoryVO.setDescription(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(details.getDescription())));
                    caseHistoryVOList.add(objCaseHistoryVO);
                }

            }
            objCaseHistoryResponseType = null;
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getActivityLog method ", ex);
            RMDWebErrorHandler.handleException(ex);

        }

        return caseHistoryVOList;
    }

    @Override
    public List<CaseBean> getAssetCases(final CaseBean caseBean) throws RMDWebException, Exception {

        List<CaseBean> casesList = new ArrayList<CaseBean>();
        CaseRequestType objCasesReqType = new CaseRequestType();
        CaseBean objCaseBean;
        Date createdDate = null;
        Date closedDate = null;
        try {
            ViewCaseResponseType[] lstcaseInfoType = null;
            objCasesReqType.setAssetNumber(caseBean.getAssetNumber());
            objCasesReqType.setAssetGrpName(caseBean.getAssetGrpName());
            objCasesReqType.setCustomerId(caseBean.getCustomerId());
            objCasesReqType.setNoOfDays(caseBean.getNoOfDays());
            objCasesReqType.setCaseType(caseBean.getCaseType());
            objCasesReqType.setCaseLike(caseBean.getCaseId());
            objCasesReqType.setAppendFlag(caseBean.getAppendFlag());
            // Call web service for open cases
            lstcaseInfoType = (ViewCaseResponseType[]) webServiceInvoker.post(
                    ServiceConstants.CASES_SERVICE_GETVIEWCASES, objCasesReqType, ViewCaseResponseType[].class);

            final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
            final TimeZone firstTime = TimeZone.getTimeZone(caseBean.getTimeZone());
            zoneFormater.setTimeZone(firstTime);

            if (lstcaseInfoType != null && lstcaseInfoType.length > 0) {
                casesList = new ArrayList<CaseBean>(lstcaseInfoType.length);
            }
            for (ViewCaseResponseType caseInfoType : lstcaseInfoType) {
                objCaseBean = new CaseBean();
                objCaseBean.setCaseId(caseInfoType.getStrCaseId());
                objCaseBean.setCaseTitle(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(caseInfoType.getStrTitle())));
                objCaseBean.setOwner(caseInfoType.getStrOwner());
                objCaseBean.setQueueName(caseInfoType.getStrQueue());
                objCaseBean.setReason(caseInfoType.getStrReason());
                objCaseBean.setCaseType(caseInfoType.getCaseType());

                if (caseInfoType.getDtCreationDate() != null) {
                    if (caseBean.getTimeZone() != null && caseBean.getTimeZone().equals(AppConstants.EST_TIMEZONE)) {
                        objCaseBean.setCreatedDate(caseInfoType.getDtCreationDate());
                    } else {
                        createdDate = RMDCommonUtility.stringToUSESTDate(caseInfoType.getDtCreationDate(),
                                RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
                        objCaseBean.setCreatedDate(zoneFormater.format(createdDate));
                    }
                }
                objCaseBean.setPriority(caseInfoType.getStrPriority());
                objCaseBean.setCondition(caseInfoType.getCondition());
                if (caseInfoType.getCloseDate() != null) {
                    if (caseBean.getTimeZone() != null && caseBean.getTimeZone().equals(AppConstants.EST_TIMEZONE)) {
                        objCaseBean.setClosedDate(caseInfoType.getCloseDate());
                    } else {
                        closedDate = RMDCommonUtility.stringToUSESTDate(caseInfoType.getCloseDate(),
                                RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
                        objCaseBean.setClosedDate(zoneFormater.format(closedDate));
                    }
                }
                objCaseBean.setCaseObjid(caseInfoType.getCaseObjid());
                objCaseBean.setAppend(caseInfoType.getIsAppend());
                casesList.add(objCaseBean);
            }
            lstcaseInfoType = null;
        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error("RMDWebException occured in getCases() method ", rmdEx);

            if (!AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(rmdEx.getMessage())) {
                rmdWebLogger.info("No record found");
            } else {
                throw rmdEx;
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getCases() method ", ex);
            throw ex;
        }

        return casesList;
    }

    /**
     * @Author :
     * @return :String
     * @param :unitStickyObjid,caseStickyObjid, applyLevel
     * @throws :RMDWebException,Exception
     * @Description:This method is used for removing a unit Level as well as case Level Sticky Notes
     *                   for a given case.
     */
    @Override
    public String removeStickyNotes(final String unitStickyObjid, final String caseStickyObjid, final String applyLevel)
            throws RMDWebException, Exception {
        String result = null;
        try {
            StickyNotesDetailsResponseType objStickyDetailsResponseType = new StickyNotesDetailsResponseType();
            objStickyDetailsResponseType.setCaseStickyObjId(caseStickyObjid);
            objStickyDetailsResponseType.setUnitStickyObjId(unitStickyObjid);
            objStickyDetailsResponseType.setApplyLevel(applyLevel);
            result = (String) webServiceInvoker.post(ServiceConstants.REMOVE_STICKY_NOTES,
                    objStickyDetailsResponseType, String.class);

        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in removeStickyNOtes in AssetCasesServiceImpl:", e);
            RMDWebErrorHandler.handleException(e);
        }
        return result;
    }
    /**
     * @Author :
     * @return :String
     * @param :caseObjId, applyLevel
     * @throws :RMDWebException,Exception
     * @Description:This method is used for fetching the caseTypes
     */
    public List<CaseTypeBean> getCaseTypes() throws RMDWebException {
        List<CaseTypeBean> caseTypeList = new ArrayList<CaseTypeBean>();
        CaseTypeBean caseTypeBean = null;
        try {

            CaseTypeResponseType[] arrayCaseTypeResponse = (CaseTypeResponseType[]) webServiceInvoker.get(
                    ServiceConstants.GET_EOA_CASE_TYPE, null, null, null, CaseTypeResponseType[].class);

            if (null != arrayCaseTypeResponse && arrayCaseTypeResponse.length > 0) {
                for (int i = 0; i < arrayCaseTypeResponse.length; i++) {
                    caseTypeBean = new CaseTypeBean();
                    caseTypeBean.setCaseTypeTitle(arrayCaseTypeResponse[i].getCaseTypeTitle());
                    caseTypeBean.setCaseTypeId(Long.valueOf(arrayCaseTypeResponse[i].getCaseTypeSeqId()));
                    caseTypeList.add(caseTypeBean);
                }
            }

        } catch (Exception rmdEx) {
            rmdWebLogger.error("Exception occured in getCaseType method ", rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }
        return caseTypeList;
    }

    /**
     * @Author :
     * @return :String
     * @param :caseObjId, applyLevel
     * @throws :RMDWebException,Exception
     * @Description:This method is used for updating the case details
     */
    public String updateCaseDetails(String caseType, String caseTitle, String caseId) throws RMDWebException {

        String result = null;
        CaseRequestType objCaseRequestType = new CaseRequestType();

        try {

            objCaseRequestType.setCaseID(caseId);
            objCaseRequestType.setCaseTitle(AppSecUtil.htmlEscaping(caseTitle));
            objCaseRequestType.setCaseType(caseType);
            result = (String) webServiceInvoker.post(ServiceConstants.UPDATE_CASE_DETAILS, objCaseRequestType,
                    String.class);

        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in updateCaseDetails in AssetCasesServiceImpl", e);
            RMDWebErrorHandler.handleException(e);
        }
        return result;

    }

    /**
     * @Author :
     * @return :String
     * @param :caseObjId
     * @throws :RMDWebException,Exception
     * @Description:This method is used for updating case title
     */
    public String updateCaseTitle(CaseSolutionVO caseBean) throws RMDWebException {

        String result = null;
        CaseRequestType objCaseRequestType = new CaseRequestType();
        String title = null;
        String caseId = null;
        try {
            caseId = caseBean.getCaseId();
            title = caseBean.getCaseTitle();
            objCaseRequestType.setCaseID(caseId);
            objCaseRequestType.setCaseTitle(title);

            result = (String) webServiceInvoker.post(ServiceConstants.UPDATE_CASE_TITLE, objCaseRequestType,
                    String.class);

        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in updateCaseTitle in AssetCasesServiceImpl", e);
            RMDWebErrorHandler.handleException(e);
        }
        return result;

    }
    /****************************************** Begin for Add RX *************************************************/

    /**
     * @Author:
     * @param :
     * @return:List <CaseBean>
     * @throws:RMDWebException
     * @throws:GenericAjaxException
     * @Description: This method is used to fetch the solutions for a given case by passing
     *               caseObjId as Input Parameter.
     */
    @Override
    public List<CaseBean> getSolutionsForCase(String caseObjId, String timeZone) throws RMDWebException {
        List<CaseBean> selectedSolutionsList = new ArrayList<CaseBean>();
        final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
        final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
        final TimeZone firstTime = TimeZone.getTimeZone(timeZone);
        zoneFormater.setTimeZone(firstTime);
        try {
            if (null != caseObjId) {
                queryParamMap.put(AppConstants.CASE_OBJID, caseObjId);
            }
            SolutionDetailType[] solutionDetailResponseList = (SolutionDetailType[]) webServiceInvoker.get(
                    ServiceConstants.GET_SOLUTIONS_FOR_CASE, null, queryParamMap, null, SolutionDetailType[].class);
            for (SolutionDetailType objSolutionDetailType : solutionDetailResponseList) {
                CaseBean objBean = new CaseBean();
                objBean.setRxObjId(objSolutionDetailType.getRxObjId());
                objBean.setTitle(objSolutionDetailType.getSolutionTitle());
                objBean.setRxType(objSolutionDetailType.getSolutionType());
                objBean.setUrgency(objSolutionDetailType.getUrgRepair());
                objBean.setRepairTime(objSolutionDetailType.getEstmTimeRepair());
                objBean.setMessageId(objSolutionDetailType.getMessageId());
                objBean.setReIssue(objSolutionDetailType.getReIssue());
                if (null != objSolutionDetailType.getDeliveryDate()) {
                    objBean.setDeliveryDate(zoneFormater.format(objSolutionDetailType.getDeliveryDate()
                            .toGregorianCalendar().getTime()));
                }
                if (null != objSolutionDetailType.getCreationDate()) {
                    objBean.setCreatedDate(zoneFormater.format(objSolutionDetailType.getCreationDate()
                            .toGregorianCalendar().getTime()));
                }
                objBean.setRevisionNo(objSolutionDetailType.getSolutionRevNo());
                selectedSolutionsList.add(objBean);
            }

        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in getSolutionsForCase in AssetCasesServiceImpl", e);
            RMDWebErrorHandler.handleException(e);
        }

        return selectedSolutionsList;
    }

    /**
     * @Author:
     * @param :
     * @return:Map<String, String>
     * @throws:RMDWebException
     * @throws:GenericAjaxException
     * @Description: This method is used to get values from lookup to populate the subsystem drop
     *               downlist.
     */
    @Override
    public Map<String, String> getSubSystem() throws RMDWebException {
        Map<String, String> selectByMap = new LinkedHashMap<String, String>();
        final Map<String, String> pathParams = new LinkedHashMap<String, String>();
        try {
            LookupResponseType[] lookupResponseType = (LookupResponseType[]) webServiceInvoker.get(
                    ServiceConstants.GET_RX_SUBSYSTEM, null, null, null, LookupResponseType[].class);
            for (int i = 0; i < lookupResponseType.length; i++) {
                String susbsystem = lookupResponseType[i].getLookupValue();
                String subsystemDesc = lookupResponseType[i].getLookupID() + RMDCommonConstants.HYPHEN_WITHSPACE
                        + susbsystem;
                selectByMap.put(susbsystem, subsystemDesc);
            }

        } catch (Exception rmdEx) {
            rmdWebLogger.error("RMDWebException occured in getSubSystem() method - AssetCasesServiceImpl", rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }
        return selectByMap;
    }

    /**
     * @Author:
     * @param :
     * @return:String
     * @throws:RMDWebException
     * @throws:GenericAjaxException
     * @Description: This method is used to add a recommendation to a given Case.
     */
    @Override
    public String addRxForCase(CaseBean objCaseBean) throws RMDWebException {

        String result = AppConstants.FAILURE;
        try {
            CasesRequestType objCasesRequestType = new CasesRequestType();
            List<SolutionDetailType> solutionDetailTypes = new ArrayList<SolutionDetailType>();
            for (SolutionDetailVO objSolutionDetailVO : objCaseBean.getArlSolutionInfo()) {
                SolutionDetailType objSolutionDetailType = new SolutionDetailType();
                objSolutionDetailType.setSolutionID(objSolutionDetailVO.getSolutionID());
                objSolutionDetailType.setUrgRepair(objSolutionDetailVO.getUrgRepair());
                objSolutionDetailType.setEstmTimeRepair(objSolutionDetailVO.getEstmTimeRepair());
                objSolutionDetailType.setVersion(objSolutionDetailVO.getSolutionRevNo());
                solutionDetailTypes.add(objSolutionDetailType);
            }
            objCasesRequestType.setCaseObjId(objCaseBean.getStrCaseObjId());
            objCasesRequestType.setUserID(objCaseBean.getUserId());
            objCasesRequestType.setSolutionDetailType(solutionDetailTypes);
            result = (String) webServiceInvoker.post(ServiceConstants.ADD_RX_FOR_CASE, objCasesRequestType,
                    String.class);

        } catch (Exception rmdEx) {
            rmdWebLogger.error("RMDWebException occured in addRxForCase() method - AssetCasesServiceImpl", rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }
        return result;
    }

    /**
     * @Author:
     * @param :
     * @return:String
     * @throws:RMDWebException
     * @throws:GenericAjaxException
     * @Description: This method is used to delete a recommendation from a given Case.
     */

    @Override
    public String deleteRxForCase(CaseBean objCaseBean) throws RMDWebException {
        String result = AppConstants.FAILURE;
        try {
            CasesRequestType objCasesRequestType = new CasesRequestType();
            objCasesRequestType.setRxObjId(objCaseBean.getRxObjId());
            objCasesRequestType.setCaseObjId(objCaseBean.getCaseObjid().toString());
            result = (String) webServiceInvoker.post(ServiceConstants.DELETE_RX_FOR_CASE, objCasesRequestType,
                    String.class);

        } catch (Exception rmdEx) {
            rmdWebLogger.error("RMDWebException occured in deleteRxForCase() method - AssetCasesServiceImpl", rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }
        return result;
    }

    /**
     * @Author:
     * @param :String caseId
     * @return:CaseBean
     * @throws:RMDWebException
     * @throws:GenericAjaxException
     * @Description: This method is used for fetching the case Information.It accepts caseId as an
     *               Input Parameter and returns caseBean List.
     */
    @Override
    public CaseBean getCaseInfo(String caseId, String timeZone) throws RMDWebException {

        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        CaseInfoType objCaseInfoType = null;
        final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
        final TimeZone firstTime = TimeZone.getTimeZone(timeZone);
        zoneFormater.setTimeZone(firstTime);
        CaseBean objCaseBean = new CaseBean();
        try {
            queryParams.put(AppConstants.CASE_Id, caseId);
            objCaseInfoType = (CaseInfoType) webServiceInvoker.get(ServiceConstants.GET_CASE_INFO, null, queryParams,
                    null, CaseInfoType.class);
            if (null != objCaseInfoType) {
                objCaseBean.setStrCaseObjId(objCaseInfoType.getStrcaseObjId());
                objCaseBean.setCustomerName(objCaseInfoType.getCustomerName());
                objCaseBean.setRoadNumber(objCaseInfoType.getRoadNumber());
                objCaseBean.setModel(objCaseInfoType.getModel());
                objCaseBean.setCaseNumber(objCaseInfoType.getCaseNumber());
                objCaseBean.setCustomerRNH(objCaseInfoType.getCustomerRNH());
                objCaseBean.setOnBoardRNH(objCaseInfoType.getOnBoardRNH());
                objCaseBean.setCaseTitle(objCaseInfoType.getCaseTitle());
                objCaseBean.setCasePriority(objCaseInfoType.getCasePriority());
                objCaseBean.setCaseType(objCaseInfoType.getCaseType());
                objCaseBean.setFleet(objCaseInfoType.getFleet());
                objCaseBean.setGpsLatitude(objCaseInfoType.getGpsLatitude());
                objCaseBean.setGpslongitude(objCaseInfoType.getGpslongitude());
                objCaseBean.setGpsHeading(objCaseInfoType.getGpsHeading());
                objCaseBean.setBadActor(objCaseInfoType.getBadActor());
                objCaseBean.setVehicleObjId(objCaseInfoType.getVehicleObjId());
                objCaseBean.setRecPendingAlert(objCaseInfoType.getRecPendingAlert());
                objCaseBean.setPendingFaults(objCaseInfoType.getPendingFaults());
                objCaseBean.setServices(objCaseInfoType.getServices());
                objCaseBean.setControllerConfig(objCaseInfoType.getControllerConfig());
                if (null != objCaseInfoType.getNextScheduledRun()) {
                    objCaseBean.setNextScheduledRun(zoneFormater.format(objCaseInfoType.getNextScheduledRun()
                            .toGregorianCalendar().getTime()));
                }
                if (null != objCaseInfoType.getCreatedDate()) {
                    objCaseBean.setCreationDate(zoneFormater.format(objCaseInfoType.getCreatedDate()
                            .toGregorianCalendar().getTime()));
                }
                if (null != objCaseInfoType.getAppendedDate()) {
                    objCaseBean.setAppendedDate(zoneFormater.format(objCaseInfoType.getAppendedDate()
                            .toGregorianCalendar().getTime()));
                }
            }
        } catch (Exception rmdEx) {
            rmdWebLogger.error("RMDWebException occured in getCaseInfo() method - AssetCasesServiceImpl", rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }

        return objCaseBean;

    }

    /**
     * @Author:
     * @param:caseId,caseObjid,userName
     * @return:String
     * @throws:RMDWebException
     * @Description: This method reOpens case based on case id by invoking web services reOpenCase()
     *               method.
     */

    @Override
    public String reOpenCase(String caseId, String caseObjid, String userName) throws RMDWebException {
        String result = AppConstants.FAILURE;
        CaseRequestType objCaseRequestType = new CaseRequestType();
        try {
            objCaseRequestType.setUserName(userName);
            objCaseRequestType.setCaseID(caseId);
            objCaseRequestType.setCaseObjid(caseObjid);
            result = (String) webServiceInvoker.post(ServiceConstants.RE_OPEN_CASE, objCaseRequestType, String.class);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in reOpenCase method ", ex);
            RMDWebErrorHandler.handleException(ex);

        }

        return result;

    }

    /**
     * @Author :
     * @return :List<CustomerFdbkVO>
     * @param :caseObjId
     * @throws :RMDWebException
     * @Description:This method is used for fetching ServiceReqId & CustFdbkObjId by invoking web
     *                   services getServiceReqId() method.
     */
    public List<CustomerFdbkVO> getServiceReqId(String caseObjId) throws RMDWebException {
        List<CustomerFdbkVO> objCustomerFdbkList = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        CustomerFeedbackResponseType[] objCustomerFeedbackResponseType = null;
        CustomerFdbkVO objCustomerFdbkVO = null;
        try {
            if (!RMDCommonUtility.isNullOrEmpty(caseObjId)) {
                queryParams.put(AppConstants.VIEW_CLOSURE_CASEOBJID, caseObjId);
                objCustomerFeedbackResponseType = (CustomerFeedbackResponseType[]) webServiceInvoker.get(
                        ServiceConstants.GET_SERVICE_RQ_ID, null, queryParams, null,
                        CustomerFeedbackResponseType[].class);
                objCustomerFdbkList = new ArrayList<CustomerFdbkVO>();
                for (CustomerFeedbackResponseType objCusFdbkResponseType : objCustomerFeedbackResponseType) {
                    objCustomerFdbkVO = new CustomerFdbkVO();
                    objCustomerFdbkVO.setCustFdbkObjId(objCusFdbkResponseType.getCustFdbkObjId());
                    objCustomerFdbkVO.setServiceReqId(objCusFdbkResponseType.getServiceReqId());
                    objCustomerFdbkList.add(objCustomerFdbkVO);
                }
            }
        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in getServicerReqId in AssetCasesServiceImpl", e);
            RMDWebErrorHandler.handleException(e);
        }
        return objCustomerFdbkList;
    }

    /**
     * @Author :
     * @return :List<RxStatusHistoryVO>
     * @param :serviceReqId ,timezone
     * @throws :RMDWebException
     * @Description:This method is used for fetching RxStatus History by invoking web services
     *                   getRxstatusHistory() method.
     */
    @Override
    public List<RxStatusHistoryVO> getRxstatusHistory(String serviceReqId, String timezone) throws RMDWebException {
        List<RxStatusHistoryVO> objRxStatusHistoryVOList = null;
        RxStatusHistoryResponseType[] objRxStatusHistoryResponseType = null;
        RxStatusHistoryVO objRxStatusHistoryVO = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
        final TimeZone timeZone = TimeZone.getTimeZone(timezone);
        try {
            if (!RMDCommonUtility.isNullOrEmpty(serviceReqId)) {
                queryParams.put(AppConstants.SERVICE_REQ_ID, serviceReqId);
                objRxStatusHistoryResponseType = (RxStatusHistoryResponseType[]) webServiceInvoker.get(
                        ServiceConstants.GET_RX_STATUS_HISTORY, null, queryParams, null,
                        RxStatusHistoryResponseType[].class);
                objRxStatusHistoryVOList = new ArrayList<RxStatusHistoryVO>();
                for (RxStatusHistoryResponseType objRxStsHstResponseType : objRxStatusHistoryResponseType) {
                    objRxStatusHistoryVO = new RxStatusHistoryVO();
                    final XMLGregorianCalendar creationDate = objRxStsHstResponseType.getRxStatusDate();
                    zoneFormater.setTimeZone(timeZone);
                    if (null != objRxStsHstResponseType.getRxStatusDate()) {
                        objRxStatusHistoryVO.setRxStatusDate(zoneFormater.format(creationDate.toGregorianCalendar()
                                .getTime()));
                    }
                    objRxStatusHistoryVO.setStatus(objRxStsHstResponseType.getStatus());
                    objRxStatusHistoryVO.setComments(objRxStsHstResponseType.getComments());
                    objRxStatusHistoryVOList.add(objRxStatusHistoryVO);
                }
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getRxstatusHistory method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return objRxStatusHistoryVOList;
    }

    /**
     * @Author :
     * @return :String
     * @param :caseObjId
     * @throws :RMDWebException
     * @Description:This method is used for fetching Good Feedback by invoking web services
     *                   getClosureFdbk() method.
     */
    @Override
    public String getClosureFdbk(String rxCaseId) throws RMDWebException {
        String objClosureFdbk = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            if (!RMDCommonUtility.isNullOrEmpty(rxCaseId)) {
                queryParams.put(AppConstants.RX_CASE_ID, rxCaseId);
                objClosureFdbk = (String) webServiceInvoker.get(ServiceConstants.GET_CLOSURE_FDBK, null, queryParams,
                        null, String.class);
            }
        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in getClosureFdbk in AssetCasesServiceImpl", e);
            RMDWebErrorHandler.handleException(e);
        }
        return objClosureFdbk;
    }

    /**
     * @Author :
     * @return :List<RxHistoryVO>
     * @param :caseObjId , timezone
     * @throws :RMDWebException
     * @Description:This method is used for fetching Rx History by invoking web services
     *                   getRxHistory() method.
     */
    @Override
    public List<RxHistoryVO> getRxHistory(String caseObjId, String timezone) throws RMDWebException {
        List<RxHistoryVO> objRxHistoryVOList = null;
        RxHistoryResponseType[] objRxHistoryVOResponseType = null;
        RxHistoryVO objRxHistoryVO = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
        final TimeZone timeZone = TimeZone.getTimeZone(timezone);
        try {
            if (!RMDCommonUtility.isNullOrEmpty(caseObjId)) {
                queryParams.put(AppConstants.VIEW_CLOSURE_CASEOBJID, caseObjId);
                objRxHistoryVOResponseType = (RxHistoryResponseType[]) webServiceInvoker.get(
                        ServiceConstants.GET_RX_HISTORY, null, queryParams, null, RxHistoryResponseType[].class);
                objRxHistoryVOList = new ArrayList<RxHistoryVO>();
                for (RxHistoryResponseType objRxHistoryVOResType : objRxHistoryVOResponseType) {
                    objRxHistoryVO = new RxHistoryVO();
                    objRxHistoryVO.setRxCaseId(objRxHistoryVOResType.getRxCaseId());
                    objRxHistoryVO.setRxFeedback(AppSecUtil.decodeString(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(objRxHistoryVOResType.getRxFeedback()))));
                    objRxHistoryVO.setRxSuccess(objRxHistoryVOResType.getRxSuccess());
                    objRxHistoryVO.setMissCode(objRxHistoryVOResType.getMissCode());
                    objRxHistoryVO.setGoodFeedback(objRxHistoryVOResType.getGoodFeedback());
                    objRxHistoryVO.setCustFdbkObjId(objRxHistoryVOResType.getCustFdbkObjId());
                    objRxHistoryVO.setServiceRequestId(objRxHistoryVOResType.getServiceRequestId());
                    final XMLGregorianCalendar creationDate = objRxHistoryVOResType.getRxCloseDate();
                    zoneFormater.setTimeZone(timeZone);
                    if (null != objRxHistoryVOResType.getRxCloseDate()) {
                        objRxHistoryVO
                                .setRxCloseDate(zoneFormater.format(creationDate.toGregorianCalendar().getTime()));
                    }
                    objRxHistoryVOList.add(objRxHistoryVO);
                }
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getRxHistory method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return objRxHistoryVOList;
    }

    /**
     * @Author :
     * @return :List<CloseOutRepairCodeVO>
     * @param :caseObjId , timezone
     * @throws :RMDWebException
     * @Description:This method is used for fetching CloseOut Repair Code by invoking web services
     *                   getCloseOutRepairCode() method.
     */
    @Override
    public List<CloseOutRepairCodeVO> getCloseOutRepairCode(String custFdbkObjId, String serviceReqId)
            throws RMDWebException {
        List<CloseOutRepairCodeVO> objCloseOutRepairCodeVOList = null;
        CloseOutRepairCodesResponseType[] objCloseOutRepairCodesResponseType = null;
        CloseOutRepairCodeVO objCloseOutRepairCodeVO = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        CloseRepairCodeVO repairCode = null;
        try {
            if (!RMDCommonUtility.isNullOrEmpty(custFdbkObjId)) {
                queryParams.put(AppConstants.SERVICE_REQ_ID, serviceReqId);
                queryParams.put(AppConstants.CUST_FDBK_OBJ_ID, custFdbkObjId);
                objCloseOutRepairCodesResponseType = (CloseOutRepairCodesResponseType[]) webServiceInvoker.get(
                        ServiceConstants.GET_CLOSEOUT_REPAIR_CODE, null, queryParams, null,
                        CloseOutRepairCodesResponseType[].class);
                objCloseOutRepairCodeVOList = new ArrayList<CloseOutRepairCodeVO>();
                for (CloseOutRepairCodesResponseType objCloOutRpCodResponseType : objCloseOutRepairCodesResponseType) {
                    objCloseOutRepairCodeVO = new CloseOutRepairCodeVO();
                    objCloseOutRepairCodeVO.setId(objCloOutRpCodResponseType.getId());
                    objCloseOutRepairCodeVO
                            .setTask(ESAPI.encoder().decodeForHTML(objCloOutRpCodResponseType.getTask()));
                    objCloseOutRepairCodeVO.setFeedback(objCloOutRpCodResponseType.getFeedback());
                    objCloseOutRepairCodeVO.setRepairCode(objCloOutRpCodResponseType.getRepairCode());
                    objCloseOutRepairCodeVO.setDescription(ESAPI.encoder().decodeForHTML(
                            objCloOutRpCodResponseType.getDescription()));
                    objCloseOutRepairCodeVO.setRepairCodeId(objCloOutRpCodResponseType.getRepairCodeId());
                    if(RMDCommonUtility.isCollectionNotEmpty(objCloOutRpCodResponseType.getRepairCodes())) {
	                    for(RepairCodeType repairCodeVO: objCloOutRpCodResponseType.getRepairCodes()){
		                    repairCode = new CloseRepairCodeVO();
		                    repairCode.setRepairCode(repairCodeVO.getRepairCode());
		                    repairCode.setRepairCodeId(repairCodeVO.getRepairCodeId());
		                    repairCode.setRepairCodeDescription(repairCodeVO.getRepairCodeDesc());
							objCloseOutRepairCodeVO.addRepairCodes(repairCode );
	                    }
                    }
                    objCloseOutRepairCodeVOList.add(objCloseOutRepairCodeVO);
                }
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getCloseOutRepairCode method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return objCloseOutRepairCodeVOList;
    }

    /**
     * @Author :
     * @return :List<CloseOutRepairCodeVO>
     * @param :caseObjId
     * @throws :RMDWebException
     * @Description:This method is used for fetching Attached Details by invoking web services
     *                   getAttachedDetails() method.
     */
    @Override
    public List<CloseOutRepairCodeVO> getAttachedDetails(String caseId) throws RMDWebException {
        List<CloseOutRepairCodeVO> objAttachedDetailsList = null;
        CloseOutRepairCodesResponseType[] objCloseOutRepairCodesResponseType = null;
        CloseOutRepairCodeVO objCloseOutRepairCodeVO = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            if (!RMDCommonUtility.isNullOrEmpty(caseId)) {
                queryParams.put(AppConstants.VIEW_CLOSURE_CASE_ID, caseId);
                objCloseOutRepairCodesResponseType = (CloseOutRepairCodesResponseType[]) webServiceInvoker.get(
                        ServiceConstants.GET_ATTACHED_DETAILS, null, queryParams, null,
                        CloseOutRepairCodesResponseType[].class);
                objAttachedDetailsList = new ArrayList<CloseOutRepairCodeVO>();
                for (CloseOutRepairCodesResponseType objCloOutRpCodResponseType : objCloseOutRepairCodesResponseType) {
                    objCloseOutRepairCodeVO = new CloseOutRepairCodeVO();
                    objCloseOutRepairCodeVO.setId(objCloOutRpCodResponseType.getId());
                    objCloseOutRepairCodeVO.setRepairCode(objCloOutRpCodResponseType.getRepairCode());
                    objCloseOutRepairCodeVO.setDescription(objCloOutRpCodResponseType.getDescription());
                    objAttachedDetailsList.add(objCloseOutRepairCodeVO);
                }
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getAttachedDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return objAttachedDetailsList;
    }

    /**
     * @Author :
     * @return :String
     * @param :caseObjId
     * @throws :RMDWebException
     * @Description:This method is used for fetching Rx Notes by invoking web services getRxNote()
     *                   method.
     */
    @Override
    public String getRxNote(String caseObjId) throws RMDWebException {
        String rxNote = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();

        try {
            if (!RMDCommonUtility.isNullOrEmpty(caseObjId)) {
                queryParams.put(AppConstants.VIEW_CLOSURE_CASEOBJID, caseObjId);
                rxNote = (String) webServiceInvoker.get(ServiceConstants.GET_RX_NOTE, null, queryParams, null,
                        String.class);
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getRxNotes method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return rxNote;
    }

    /**
     * @Author:
     * @param:RecommDelVO objDelVO
     * @return:String
     * @throws:RMDWebException
     * @Description: This method delivers an Recommendation by invoking web services deliverRx()
     *               method.
     */

    @Override
    public String deliverRx(RecommDeliverVO objDelVO) throws RMDWebException {
        String result = AppConstants.FAILURE;
        CaseSolutionRequestType objCaseSolutionRequestType = new CaseSolutionRequestType();
        try {
            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getCaseId())) {
                objCaseSolutionRequestType.setCaseID(objDelVO.getCaseId());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getStrRxObjId())) {
                objCaseSolutionRequestType.setSolutionID(objDelVO.getStrRxObjId());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getUserName())) {
                objCaseSolutionRequestType.setUserName(objDelVO.getUserName());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getCustomerName())) {
                objCaseSolutionRequestType.setCustomerName(objDelVO.getCustomerName());
            }
            objCaseSolutionRequestType.setRecomNotes(AppSecUtil.htmlEscaping(objDelVO.getRecommNotes()));

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getCaseObjId())) {
                objCaseSolutionRequestType.setCaseObjId(objDelVO.getCaseObjId());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getEstRepairTime())) {
                objCaseSolutionRequestType.setEstmRepTime(objDelVO.getEstRepairTime());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getUrgency())) {
                objCaseSolutionRequestType.setUrgRepair(objDelVO.getUrgency());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getIsFromDeliver())) {
                objCaseSolutionRequestType.setIsFromdeliver(objDelVO.getIsFromDeliver());
            }

            // AddRx data
            SolutionDetailType objSolutionDetailType = new SolutionDetailType();
            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getSolutionDetailVO().getUrgRepair())) {
                objSolutionDetailType.setUrgRepair(objDelVO.getSolutionDetailVO().getUrgRepair());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getSolutionDetailVO().getEstmTimeRepair())) {
                objSolutionDetailType.setEstmTimeRepair(objDelVO.getSolutionDetailVO().getEstmTimeRepair());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getSolutionDetailVO().getSolutionRevNo())) {
                objSolutionDetailType.setVersion(objDelVO.getSolutionDetailVO().getSolutionRevNo());
            }

            objCaseSolutionRequestType.setObjSolutionDetailType(objSolutionDetailType);
            
            RxDelvDocType objRxDelvDocType=null;
            List<RxDelvDocType> arlRxDelvDocType=new ArrayList<RxDelvDocType>();
            List<RecommDelvDocVO> lstDocs=objDelVO.getArlRecommDelDocVO();
            for (Iterator iterator = lstDocs.iterator(); iterator.hasNext();) {
				RecommDelvDocVO recommDelvDocVO = (RecommDelvDocVO) iterator
						.next();
				objRxDelvDocType=new RxDelvDocType();
				objRxDelvDocType.setDocData(recommDelvDocVO.getDocData());				
				objRxDelvDocType.setDocTitle(recommDelvDocVO.getDocTitle());
				objRxDelvDocType.setDocPath(recommDelvDocVO.getDocPath());
				arlRxDelvDocType.add(objRxDelvDocType);
			}
            objCaseSolutionRequestType.setLstAttachment(arlRxDelvDocType);
            result = (String) webServiceInvoker.post(ServiceConstants.DELIVER_RX, objCaseSolutionRequestType,
                    String.class);

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in deliverRx method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return result;
    }

    /**
     * @Author:
     * @param:caseId,caseObjid,userName
     * @return:String
     * @throws:RMDWebException
     * @Description: This method modifies a recommendation by invoking web services modifyRx()
     *               method.
     */

    @Override
    public String modifyRx(RecommDeliverVO objDelVO) throws RMDWebException {
        String result = AppConstants.FAILURE;
        CaseSolutionRequestType objCaseSolutionRequestType = new CaseSolutionRequestType();
        try {
            objCaseSolutionRequestType.setCaseID(objDelVO.getCaseId());
            objCaseSolutionRequestType.setSolutionID(objDelVO.getStrRxObjId());
            objCaseSolutionRequestType.setUserName(objDelVO.getUserName());
            objCaseSolutionRequestType.setRecomNotes(objDelVO.getRecommNotes());
            objCaseSolutionRequestType.setCustomerName(objDelVO.getCustomerName());
            objCaseSolutionRequestType.setFdbkObjId(objDelVO.getFdbkObjId());
            objCaseSolutionRequestType.setEstmRepTime(objDelVO.getEstRepairTime());
            objCaseSolutionRequestType.setUrgRepair(objDelVO.getUrgency());            
            RxDelvDocType objRxDelvDocType=null;
            List<RxDelvDocType> arlRxDelvDocType=new ArrayList<RxDelvDocType>();
            List<RecommDelvDocVO> lstDocs=objDelVO.getArlRecommDelDocVO();
            for (Iterator iterator = lstDocs.iterator(); iterator.hasNext();) {
				RecommDelvDocVO recommDelvDocVO = (RecommDelvDocVO) iterator
						.next();
				objRxDelvDocType=new RxDelvDocType();
				objRxDelvDocType.setDocData(recommDelvDocVO.getDocData());				
				objRxDelvDocType.setDocTitle(recommDelvDocVO.getDocTitle());
				objRxDelvDocType.setDocPath(recommDelvDocVO.getDocPath());
				arlRxDelvDocType.add(objRxDelvDocType);
			}
            objCaseSolutionRequestType.setLstAttachment(arlRxDelvDocType);
            result = (String) webServiceInvoker.post(ServiceConstants.MODIFY_RX_TO_CASE, objCaseSolutionRequestType,
                    String.class);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in modifyRx method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return result;
    }

    /**
     * @Author:
     * @param:caseId,caseObjid,userName
     * @return:String
     * @throws:RMDWebException
     * @Description: This method replaces a recommendation by invoking web services replaceRx()
     *               method.
     */
    @Override
    public String replaceRx(RecommDeliverVO objDelVO) throws RMDWebException {
        String result = AppConstants.FAILURE;
        CaseSolutionRequestType objCaseSolutionRequestType = new CaseSolutionRequestType();
        try {

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getCaseId())) {
                objCaseSolutionRequestType.setCaseID(objDelVO.getCaseId());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getStrRxObjId())) {
                objCaseSolutionRequestType.setSolutionID(objDelVO.getStrRxObjId());
            }
            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getUserName())) {
                objCaseSolutionRequestType.setUserName(objDelVO.getUserName());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getCustomerName())) {
                objCaseSolutionRequestType.setCustomerName(objDelVO.getCustomerName());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getCaseObjId())) {
                objCaseSolutionRequestType.setCaseObjId(objDelVO.getCaseObjId());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getEstRepairTime())) {
                objCaseSolutionRequestType.setEstmRepTime(objDelVO.getEstRepairTime());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getUrgency())) {
                objCaseSolutionRequestType.setUrgRepair(objDelVO.getUrgency());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getIsFromDeliver())) {
                objCaseSolutionRequestType.setIsFromdeliver(objDelVO.getIsFromDeliver());
            }

            if (0 != objDelVO.getFdbkObjId()) {
                objCaseSolutionRequestType.setFdbkObjId(objDelVO.getFdbkObjId());
            }

            objCaseSolutionRequestType.setRecomNotes(AppSecUtil.htmlEscaping(objDelVO.getRecommNotes()));
            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getRxCaseId())) {
                objCaseSolutionRequestType.setRxCaseID(objDelVO.getRxCaseId());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getDelvrdRxObjId())) {
                objCaseSolutionRequestType.setDelvrdRxObjId(objDelVO.getDelvrdRxObjId());
            }
            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getUserId())) {
                objCaseSolutionRequestType.setUserId(objDelVO.getUserId());
            }

            // AddRx Data
            SolutionDetailType objSolutionDetailType = new SolutionDetailType();
            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getSolutionDetailVO().getUrgRepair())) {
                objSolutionDetailType.setUrgRepair(objDelVO.getSolutionDetailVO().getUrgRepair());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getSolutionDetailVO().getEstmTimeRepair())
                    && RMDCommonUtility.isNumbersOnly(objDelVO.getSolutionDetailVO().getEstmTimeRepair())) {
                objSolutionDetailType.setEstmTimeRepair(objDelVO.getSolutionDetailVO().getEstmTimeRepair());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objDelVO.getSolutionDetailVO().getSolutionRevNo())) {
                objSolutionDetailType.setVersion(objDelVO.getSolutionDetailVO().getSolutionRevNo());
            }

            objCaseSolutionRequestType.setObjSolutionDetailType(objSolutionDetailType);

            
            RxDelvDocType objRxDelvDocType=null;
            List<RxDelvDocType> arlRxDelvDocType=new ArrayList<RxDelvDocType>();
            List<RecommDelvDocVO> lstDocs=objDelVO.getArlRecommDelDocVO();
            for (Iterator iterator = lstDocs.iterator(); iterator.hasNext();) {
				RecommDelvDocVO recommDelvDocVO = (RecommDelvDocVO) iterator
						.next();
				objRxDelvDocType=new RxDelvDocType();
				objRxDelvDocType.setDocData(recommDelvDocVO.getDocData());				
				objRxDelvDocType.setDocTitle(recommDelvDocVO.getDocTitle());
				objRxDelvDocType.setDocPath(recommDelvDocVO.getDocPath());
				arlRxDelvDocType.add(objRxDelvDocType);
			}
            objCaseSolutionRequestType.setLstAttachment(arlRxDelvDocType);
            result = (String) webServiceInvoker.post(ServiceConstants.REPLACE_RX_TO_CASE, objCaseSolutionRequestType,
                    String.class);

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in replaceRx method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return result;
    }

    /**
     * @Author:
     * @param:String caseId
     * @return:RecommDelVO
     * @throws:RMDWebException
     * @Description: This method is used for fetching pendingFdbkServiceStatus by invoking web
     *               services pendingFdbkServiceStatus() method.
     */
    @Override
    public List<RecommDeliverVO> pendingFdbkServiceStatus(String caseId) throws RMDWebException {
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        List<RecommDeliverVO> arlDeliverVO = new ArrayList<RecommDeliverVO>();
        try {
            queryParams.put(AppConstants.CASE_ID, caseId);
            SolutionDetailType[] arlSolutionDetailTypes = (SolutionDetailType[]) webServiceInvoker.get(
                    ServiceConstants.PENDING_FDBK_SERIVICE_STATUS, null, queryParams, null, SolutionDetailType[].class);
            for (SolutionDetailType solutionDetailType : arlSolutionDetailTypes) {
                RecommDeliverVO objDeliverVO = new RecommDeliverVO();
                objDeliverVO.setFdbkStatus(solutionDetailType.getFdbkStatus());
                objDeliverVO.setRxObjId(solutionDetailType.getRxObjId());
                arlDeliverVO.add(objDeliverVO);
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in pendingFdbkServiceStatus method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return arlDeliverVO;
    }

    /**
     * @Author:
     * @param:String fdbkObjid
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching ServiceReqId by invoking web services
     *               getServiceReqIdStatus() method.
     */
    @Override
    public String getServiceReqIdStatus(String fdbkObjId) throws RMDWebException {
        String serviceReqIdStatus = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            queryParams.put(AppConstants.FDBK_OBJID, fdbkObjId);
            serviceReqIdStatus = (String) webServiceInvoker.get(ServiceConstants.GET_SERVICE_REQUESTID_STATUS, null,
                    queryParams, null, String.class);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getServiceReqIdStatus method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return serviceReqIdStatus;
    }

    /**
     * @Author:
     * @param:String caseObjid,String rxObjid
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching DeliveryDate by invoking web services
     *               getDelvDateForRx() method.
     */

    @Override
    public String getDelvDateForRx(String caseObjId, String rxObjId) throws RMDWebException {
        String deliverDate = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            queryParams.put(AppConstants.CASE_OBJID, caseObjId);
            queryParams.put(AppConstants.RX_OBJ_ID, rxObjId);
            deliverDate = (String) webServiceInvoker.get(ServiceConstants.GET_DELV_DATE_FOR_RX, null, queryParams,
                    null, String.class);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getDelvDateForRx method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return deliverDate;
    }

    /**
     * @Author:
     * @param:String caseId
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching requestId by invoking web services getT2Req()
     *               method.
     */
    @Override
    public String getT2Req(String caseId) throws RMDWebException {
        String t2Req = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            queryParams.put(AppConstants.CASE_ID, caseId);
            t2Req = (String) webServiceInvoker.get(ServiceConstants.GET_T2_REQUEST, null, queryParams, null,
                    String.class);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getT2Req method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return t2Req;
    }

    /**
     * @Author:
     * @param:String caseObjid
     * @return:String
     * @throws:RMDWebException
     * @Description: This method replaces a recommendation by invoking web services
     *               getUnitShipDetails() method.
     */

    @Override
    public String getUnitShipDetails(String caseObjId) throws RMDWebException {
        String unitShipDetails = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            queryParams.put(AppConstants.CASE_OBJID, caseObjId);
            unitShipDetails = (String) webServiceInvoker.get(ServiceConstants.GET_UNIT_SHIP_DETAILS, null, queryParams,
                    null, String.class);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getUnitShipDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return unitShipDetails;
    }

    /**
     * @Author:
     * @param:String caseid
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching case Score by invoking web services
     *               getCaseScore() method.
     */
    @Override
    public List<RecommDeliverVO> getCaseScore(String caseId) throws RMDWebException {
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        List<RecommDeliverVO> arlDeliverVO = new ArrayList<RecommDeliverVO>();
        try {
            queryParams.put(AppConstants.CASE_ID, caseId);
            SolutionExecutionResponseType[] objSolutionExecutionResponseType = (SolutionExecutionResponseType[]) webServiceInvoker
                    .get(ServiceConstants.GET_CASE_SCORE, null, queryParams, null,
                            SolutionExecutionResponseType[].class);
            RecommDeliverVO objDeliverVO = null;
            for (SolutionExecutionResponseType solutionExecutionResponseType : objSolutionExecutionResponseType) {
                objDeliverVO = new RecommDeliverVO();
                objDeliverVO.setRxCaseId(solutionExecutionResponseType.getRxCaseId());
                arlDeliverVO.add(objDeliverVO);
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getCaseScore method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return arlDeliverVO;
    }

    /**
     * @Author:
     * @param:String rxObjid
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching readyToDeliver date by invoking web services
     *               getReadyToDelv() method.
     */

    @Override
    public String getReadyToDelv(String rxObjid) throws RMDWebException {
        String readyToDelStatus = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            queryParams.put(AppConstants.RX_OBJ_ID, rxObjid);
            readyToDelStatus = (String) webServiceInvoker.get(ServiceConstants.GET_READY_TO_DELIVER, null, queryParams,
                    null, String.class);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getReadyToDelv method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return readyToDelStatus;
    }

    /**
     * @Author:
     * @param:String caseId,String rxObjid
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching customer feed back object Id by invoking web
     *               services getCustomerFdbkObjId() method.
     */
    @Override
    public RecommDeliverVO getPendingRcommendation(String caseId) throws RMDWebException {
        RecommDeliverVO objRecommDeliverVO = new RecommDeliverVO();
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            queryParams.put(AppConstants.CASE_Id, caseId);
            SolutionExecutionResponseType objSolutionExecutionResponseType = (SolutionExecutionResponseType) webServiceInvoker
                    .get(ServiceConstants.GET_PENDING_RECOMMENDATIONS, null, queryParams, null,
                            SolutionExecutionResponseType.class);
            if (null != objSolutionExecutionResponseType) {
                objRecommDeliverVO.setRxCaseId(objSolutionExecutionResponseType.getRxCaseId());
                objRecommDeliverVO.setFdbkObjId(objSolutionExecutionResponseType.getFdbkObjId());
                objRecommDeliverVO.setCaseObjId(objSolutionExecutionResponseType.getCaseObjId());
                objRecommDeliverVO.setStrRxObjId(objSolutionExecutionResponseType.getSolutionId());
                objRecommDeliverVO.setCaseTitle(objSolutionExecutionResponseType.getRxTitle());
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getPendingRcommendation method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return objRecommDeliverVO;
    }

    /**
     * @Author:
     * @param:String customerName
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for checking Whether delivery mechanism is present for
     *               particular Customer are not by invoking web services checkForDelvMechanism()
     *               method.
     */
    @Override
    public String checkForDelvMechanism(String customerName) throws RMDWebException {
        String result = null;

        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            queryParams.put(AppConstants.CUSTOMER_NAME, customerName);
            result = (String) webServiceInvoker.get(ServiceConstants.CHECK_FOR_DELV_MECHANISM, null, queryParams, null,
                    String.class);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getReadyToDelv method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return result;

    }

    /**
     * @Author:
     * @param:String caseObjid,String rxObjid, String fromScreen,String custFdbkObjId
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching Msdc Notes for the Recommendation by invoking
     *               web services getMsdcNotes() method.
     */

    @Override
    public String getMsdcNotes(String caseObjid, String rxObjid,String fromScreen,String custFdbkObjId) throws RMDWebException {
        String msdcNotes = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            queryParams.put(AppConstants.CASE_OBJID, caseObjid);
            queryParams.put(AppConstants.RX_OBJ_ID, rxObjid);
            queryParams.put(AppConstants.FROM_SCREEN, fromScreen);
            queryParams.put(AppConstants.CUST_FDBK_OBJ_ID, custFdbkObjId);
            msdcNotes = (String) webServiceInvoker.get(ServiceConstants.GET_MSDC_NOTES, null, queryParams, null,
                    String.class);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getMsdcNotes method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return msdcNotes;
    }

    /**
     * @Author :
     * @return :CustomerFdbkVO
     * @param :caseObjId
     * @throws :RMDWebException
     * @Description:This method is used for fetching Closure Details invoking web services
     *                   getClosureDetails() method.
     */
    @Override
    public CustomerFdbkVO getClosureDetails(String caseObjId) throws RMDWebException {
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        CustomerFeedbackResponseType objCustFdbkResType = null;
        CustomerFdbkVO objCustomerFdbkVO = null;
        try {
            if (!RMDCommonUtility.isNullOrEmpty(caseObjId)) {
                queryParams.put(AppConstants.VIEW_CLOSURE_CASEOBJID, caseObjId);
            }
            objCustFdbkResType = (CustomerFeedbackResponseType) webServiceInvoker.get(
                    ServiceConstants.GET_CLOSURE_DETAILS, null, queryParams, null, CustomerFeedbackResponseType.class);
            if (null != objCustFdbkResType) {
                objCustomerFdbkVO = new CustomerFdbkVO();
                objCustomerFdbkVO.setCustFdbkObjId(objCustFdbkResType.getCustFdbkObjId());
                objCustomerFdbkVO.setServiceReqId(objCustFdbkResType.getServiceReqId());
                objCustomerFdbkVO.setRxCloseDate(objCustFdbkResType.getRxCloseDate());
                objCustomerFdbkVO.setCaseSuccess(objCustFdbkResType.getCaseSuccess());
                objCustomerFdbkVO.setRxFdbk(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(objCustFdbkResType.getRxFdbk())));
                objCustomerFdbkVO.setIsRxPresent(objCustFdbkResType.getIsRxPresent());
                objCustomerFdbkVO.setRxCaseId(objCustFdbkResType.getRxCaseId());
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getClosureDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return objCustomerFdbkVO;
    }

    /**
     * @Author :
     * @return tring
     * @param :caseObjId,rxCaseId
     * @throws :RMDWebException
     * @Description: This method does eservice validation invoking doEserviceValidation()method in
     *               web services.
     */
    @Override
    public String doEserviceValidation(String caseObjId, String rxCaseId) throws RMDWebException {
        String result = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            queryParams.put(AppConstants.CASE_OBJID, caseObjId);
            queryParams.put(AppConstants.RX_CASE_ID, rxCaseId);
            result = (String) webServiceInvoker.get(ServiceConstants.DO_ESERVICE_VALIDATION, null, queryParams, null,
                    String.class);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in doEserviceValidation method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return result;
    }

    /**
     * @Author:
     * @param:rxObjId,caseObjId,model
     * @return:String
     * @throws RMDWebException
     * @Description: This method is used to check for Controller Configuration for the given
     *               Recommendation by Calling Web Services.
     */

    @Override
    public String checkForContollerConfig(String caseObjId, String rxObjId, String model) throws RMDWebException {
        String result = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            queryParams.put(AppConstants.RX_OBJ_ID, rxObjId);
            queryParams.put(AppConstants.CASE_OBJID, caseObjId);
            queryParams.put(AppConstants.MODEL, model);
            result = (String) webServiceInvoker.get(ServiceConstants.CHECK_FOR_CONTOLLER_CONFIG, null, queryParams,
                    null, String.class);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in checkForContoleerConfig method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return result;
    }

    /**
     * @Author :
     * @return :String
     * @param : caseBean
     * @throws :RMDWebException
     * @Description: This method is used to get enabled Rxs
     */
    @Override
    public List<String> getEnabledRxs(CaseBean caseBean) throws RMDWebException, Exception {
        final Map<String, String> pathParams = new HashMap<String, String>();
        final Map<String, String> queryParamsMap = new HashMap<String, String>();
        final Map<String, String> headerParams = getHeaderMap(caseBean);
        List<String> rxList = new ArrayList<String>();
        CaseRequestType objCasesReqType = new CaseRequestType();
        CaseBean objCaseBean;
        try {
            RxHistoryResponseType[] lstcaseInfoType = null;

            pathParams.put(AppConstants.CASE_ID, caseBean.getCaseId());
            queryParamsMap.put(AppConstants.CASE_TYPE, caseBean.getCaseType());
            pathParams.put(AppConstants.USER_ID, caseBean.getUserId());
            // Call web service for open cases
            lstcaseInfoType = (RxHistoryResponseType[]) webServiceInvoker.get(ServiceConstants.ENABLE_APPEND,
                    pathParams, queryParamsMap, headerParams, RxHistoryResponseType[].class);

            final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
            final TimeZone firstTime = TimeZone.getTimeZone(caseBean.getTimeZone());
            zoneFormater.setTimeZone(firstTime);
            if (lstcaseInfoType != null) {
                for (RxHistoryResponseType caseInfoType : lstcaseInfoType) {

                    rxList.add(caseInfoType.getRxCaseId());
                }
            }

        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error("RMDWebException occured in getEnabledRxs() method ", rmdEx);

            if (!AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(rmdEx.getMessage())) {
                rmdWebLogger.info("No record found");
            } else {
                throw rmdEx;
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getEnabledRxs() method ", ex);
            throw ex;
        }

        return rxList;
    }

    /**
     * @Author :
     * @return :String
     * @param : caseBean
     * @throws :RMDWebException
     * @Description: This method is used to append rx to a case
     */
    @Override
    public String appendRx(CaseBean caseBean) throws RMDWebException, Exception {

        final Map<String, String> pathParams = new HashMap<String, String>();
        final Map<String, String> queryParamsMap = new HashMap<String, String>();
        final Map<String, String> headerParams = getHeaderMap(caseBean);

        String strResponse = null;
        String ruleDef = null;
        try {

            if (caseBean.getRuleDefId() == null || caseBean.getRuleDefId().equals(AppConstants.EMPTY_STRING))
                ruleDef = "0";
            else
                ruleDef = caseBean.getRuleDefId();

            pathParams.put(AppConstants.CASE_ID, caseBean.getCaseId());
            pathParams.put("toCaseId", caseBean.getAppendToCaseId());
            pathParams.put(AppConstants.USER_ID, caseBean.getUserId());
            pathParams.put(AppConstants.RX_ID, String.valueOf(caseBean.getRxObjId()));
            pathParams.put(AppConstants.RULE_DEFINITION_ID, ruleDef);
            pathParams.put(AppConstants.ASSET_GROUP_NAME, caseBean.getAssetGrpName());
            pathParams.put(AppConstants.ASSET_NUMBER, caseBean.getAssetNumber());
            pathParams.put(AppConstants.CUSTOMER_ID, caseBean.getCustomerId());
            pathParams.put("toolId", caseBean.getToolId());
            pathParams.put(AppConstants.TOOL_OBJID, caseBean.getToolObjId());

            strResponse = (String) webServiceInvoker.get(ServiceConstants.APPEND_RX_TO_CASE, pathParams,
                    queryParamsMap, headerParams, String.class);

        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error("RMDWebException occured in appendRx() method ", rmdEx);

            return AppConstants.FAILURE;

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in appendRx() method ", ex);
            return AppConstants.FAILURE;
        }

        return strResponse;
    }
    public List<DeliverSummaryVO> toolOutputDeliver(CaseActionVO objCaseActionVO) throws RMDWebException, Exception {

        CaseSolutionRequestType objCaseSolutionRequestType = new CaseSolutionRequestType();
        DeliverSummaryVO objDeliverSummaryVO = null;
        List<DeliverSummaryVO> arlDeliverSummaryVO = new ArrayList<DeliverSummaryVO>();
        List<String> manualCaseIds = new ArrayList<String>();
        List<String> manualCaseObjids = new ArrayList<String>();
        List<String> rxTitles = new ArrayList<String>();
        String parentCaseId = RMDCommonConstants.EMPTY_STRING;
        String parentCaseObjId = RMDCommonConstants.EMPTY_STRING;

        try {

            List<ToolOutputDeliverVO> arlDeliverVO = objCaseActionVO.getDeliverVO();
            for (ToolOutputDeliverVO toolOutputDeliverVO : arlDeliverVO) {
                if (toolOutputDeliverVO.getCurrnewcasetype().equalsIgnoreCase(AppConstants.CC)) {

                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getCaseId())) {
                        objCaseSolutionRequestType.setCaseID(toolOutputDeliverVO.getCaseId());
                    }

                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getRxObjid())) {
                        objCaseSolutionRequestType.setSolutionID(toolOutputDeliverVO.getRxObjid());
                    }

                    if (!RMDCommonUtility.isNullOrEmpty(objCaseActionVO.getUserName())) {
                        objCaseSolutionRequestType.setUserName(objCaseActionVO.getUserName());
                    }

                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getCustomerName())) {
                        objCaseSolutionRequestType.setCustomerName(toolOutputDeliverVO.getCustomerName());
                    }
                    objCaseSolutionRequestType
                            .setRecomNotes(AppSecUtil.htmlEscaping(toolOutputDeliverVO.getMdscnote()));

                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getCaseObjid())) {
                        objCaseSolutionRequestType.setCaseObjId(toolOutputDeliverVO.getCaseObjid());
                    }

                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getTimetorepair())) {
                        objCaseSolutionRequestType.setEstmRepTime(toolOutputDeliverVO.getTimetorepair());
                    }

                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getUrgency())) {
                        objCaseSolutionRequestType.setUrgRepair(toolOutputDeliverVO.getUrgency());
                    }

                    objCaseSolutionRequestType.setIsFromdeliver(RMDCommonConstants.STR_TRUE);

                    // AddRx data
                    SolutionDetailType objSolutionDetailType = new SolutionDetailType();
                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getUrgency())) {
                        objSolutionDetailType.setUrgRepair(toolOutputDeliverVO.getUrgency());
                    }

                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getTimetorepair())) {
                        objSolutionDetailType.setEstmTimeRepair(toolOutputDeliverVO.getTimetorepair());
                    }

                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getSolutionRevisionNo())) {
                        objSolutionDetailType.setVersion(toolOutputDeliverVO.getSolutionRevisionNo());
                    }

                    objCaseSolutionRequestType.setObjSolutionDetailType(objSolutionDetailType);

                    RxDelvDocType objRxDelvDocType=null;
                    List<RxDelvDocType> arlRxDelvDocType=new ArrayList<RxDelvDocType>();
                    List<RecommDelvDocVO> lstDocs=toolOutputDeliverVO.getArlRecommDelDocVO();
                    for (Iterator iterator = lstDocs.iterator(); iterator.hasNext();) {
        				RecommDelvDocVO recommDelvDocVO = (RecommDelvDocVO) iterator
        						.next();
        				objRxDelvDocType=new RxDelvDocType();
        				objRxDelvDocType.setDocData(recommDelvDocVO.getDocData());				
        				objRxDelvDocType.setDocTitle(recommDelvDocVO.getDocTitle());
        				objRxDelvDocType.setDocPath(recommDelvDocVO.getDocPath());
        				arlRxDelvDocType.add(objRxDelvDocType);
        			}
                    objCaseSolutionRequestType.setLstAttachment(arlRxDelvDocType);
                    String result = (String) webServiceInvoker.post(ServiceConstants.DELIVER_RX,
                            objCaseSolutionRequestType, String.class);
                    if (result.equalsIgnoreCase(RMDCommonConstants.SUCCESS)) {
                        objDeliverSummaryVO = new DeliverSummaryVO();
                        objDeliverSummaryVO.setCaseId(toolOutputDeliverVO.getCaseId());
                        objDeliverSummaryVO.setCaseTitle(toolOutputDeliverVO.getRxtitle());
                        objDeliverSummaryVO.setType(AppConstants.CURRENT_CASE);
                        arlDeliverSummaryVO.add(objDeliverSummaryVO);
                    }

                }

                else {

                    CaseRequestType objCaseRequestType = new CaseRequestType();
                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getCaseType())) {
                        objCaseRequestType.setCaseType(toolOutputDeliverVO.getCaseType());
                    }
                    if (!toolOutputDeliverVO.getAssetnumber().isEmpty()
                            && !toolOutputDeliverVO.getGroupName().isEmpty()) {
                        List<String> assetList = new ArrayList<String>();
                        String asset = toolOutputDeliverVO.getGroupName() + RMDCommonConstants.HYPHEN
                                + toolOutputDeliverVO.getAssetnumber();
                        assetList.add(asset);
                        objCaseRequestType.setAssetNumberList(assetList);
                    }

                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getCaseId())) {
                        parentCaseId = toolOutputDeliverVO.getCaseId();
                    }
                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getCaseObjid())) {
                        parentCaseObjId = toolOutputDeliverVO.getCaseObjid();
                    }
                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getCustomerName())) {
                        objCaseRequestType.setCustomerName(toolOutputDeliverVO.getCustomerName());
                    }
                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getCustomerId())) {
                        objCaseRequestType.setCustomerId(toolOutputDeliverVO.getCustomerId());
                    }
                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getGroupName())) {
                        objCaseRequestType.setAssetGrpName(toolOutputDeliverVO.getGroupName());
                    }
                    if (!RMDCommonUtility.isNullOrEmpty(objCaseActionVO.getUserName())) {
                        objCaseRequestType.setUserName(objCaseActionVO.getUserName());
                    }
                    if (!RMDCommonUtility.isNullOrEmpty(objCaseActionVO.getUserLanguage())) {
                        objCaseRequestType.setUserLanguage(objCaseActionVO.getUserLanguage());
                    }
                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getUrgency())) {
                        objCaseRequestType.setUrgency(toolOutputDeliverVO.getUrgency());
                    }

                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getTimetorepair())) {
                        objCaseRequestType.setStrEstRepairTime(toolOutputDeliverVO.getTimetorepair());
                    }
                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getMdscnote())) {
                        objCaseRequestType.setMsdcNotes(AppSecUtil.htmlEscaping(toolOutputDeliverVO.getMdscnote()));
                    }

                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getRxtitle())) {
                        objCaseRequestType.setSolutionTitle(toolOutputDeliverVO.getRxtitle());
                    }

                    SolutionDetailType objSolutionDetailType = new SolutionDetailType();
                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getUrgency())) {
                        objSolutionDetailType.setUrgRepair(toolOutputDeliverVO.getUrgency());
                    }

                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getTimetorepair())) {
                        objSolutionDetailType.setEstmTimeRepair(toolOutputDeliverVO.getTimetorepair());
                    }
                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getSolutionRevisionNo())) {
                        objSolutionDetailType.setVersion(toolOutputDeliverVO.getSolutionRevisionNo());
                    }
                    if (!RMDCommonUtility.isNullOrEmpty(toolOutputDeliverVO.getRxObjid())) {
                        objSolutionDetailType.setSolutionID(toolOutputDeliverVO.getRxObjid());
                    }
                    objCaseRequestType.setObjSolutionDetailType(objSolutionDetailType);
                    RxDelvDocType objRxDelvDocType=null;
                    List<RxDelvDocType> arlRxDelvDocType=new ArrayList<RxDelvDocType>();
                    List<RecommDelvDocVO> lstDocs=toolOutputDeliverVO.getArlRecommDelDocVO();
                    for (Iterator iterator = lstDocs.iterator(); iterator.hasNext();) {
        				RecommDelvDocVO recommDelvDocVO = (RecommDelvDocVO) iterator
        						.next();
        				objRxDelvDocType=new RxDelvDocType();
        				objRxDelvDocType.setDocData(recommDelvDocVO.getDocData());				
        				objRxDelvDocType.setDocTitle(recommDelvDocVO.getDocTitle());
        				objRxDelvDocType.setDocPath(recommDelvDocVO.getDocPath());
        				arlRxDelvDocType.add(objRxDelvDocType);
        			}
                    objCaseRequestType.setLstAttachment(arlRxDelvDocType);

                    final ViewLogReponseType[] arViewLogReponseTypes = (ViewLogReponseType[]) webServiceInvoker.post(
                            ServiceConstants.TOOL_OUTPUT_CREATECASE, objCaseRequestType, ViewLogReponseType[].class);

                    if (arViewLogReponseTypes != null && arViewLogReponseTypes.length != 0) {
                        moveDeliverToolOutput(objCaseActionVO.getUserName(), toolOutputDeliverVO.getCaseId(),
                                arViewLogReponseTypes[0].getCaseId(), toolOutputDeliverVO.getRxObjid(),
                                toolOutputDeliverVO.getAssetnumber(), toolOutputDeliverVO.getGroupName(),
                                toolOutputDeliverVO.getCustomerId(), toolOutputDeliverVO.getRuleDefId(),
                                toolOutputDeliverVO.getToolId(), toolOutputDeliverVO.getCaseType(),
                                toolOutputDeliverVO.getToolObjId());

                        for (ViewLogReponseType objLogReponseType : arViewLogReponseTypes) {
                            objDeliverSummaryVO = new DeliverSummaryVO();
                            manualCaseIds.add(objLogReponseType.getCaseId());
                            manualCaseObjids.add(objLogReponseType.getCaseObjId());
                            rxTitles.add(objLogReponseType.getCaseTitle());
                            objDeliverSummaryVO.setCaseId(objLogReponseType.getCaseId());
                            objDeliverSummaryVO.setCaseTitle(objLogReponseType.getCaseTitle());
                            objDeliverSummaryVO.setType(AppConstants.NEW_CASE);
                            arlDeliverSummaryVO.add(objDeliverSummaryVO);
                        }

                        rmdWebLogger.info("Case merge code starts for Deliver");

                        // code for case merge in case of case Append.
                        String rxIdOfDeliverCase = toolOutputDeliverVO.getRxObjid();
                        MultiValueMap mergeVOMap = objCaseActionVO.getMergeVOMap();
                        rmdWebLogger.info(" value of MergeMap " + mergeVOMap);
                        if (null != mergeVOMap && !mergeVOMap.isEmpty()) {
                            // call merge method if any Rx which is tagged with current case
                            if (mergeVOMap.containsKey(rxIdOfDeliverCase)) {
                                rmdWebLogger.info("*******Match Found**********");
                                rmdWebLogger.info("Inside for loop TooloutputMerge");
                                // ToolOutputCaseMergeVO toolOutputCaseMergeVO =
                                // mergeVOMap.get(rxIdOfAppendedCase);
                                List<ToolOutputCaseMergeVO> toolOutputCaseMergeVOList = (ArrayList) mergeVOMap
                                        .get(rxIdOfDeliverCase);
                                for (ToolOutputCaseMergeVO toolOutputCaseMergeVO : toolOutputCaseMergeVOList) {
                                    String mergedToRxId = toolOutputCaseMergeVO.getMergedTo();
                                    rmdWebLogger.info("TooloutputMerge :::: RxId" + rxIdOfDeliverCase + "::::MergeTo"
                                            + mergedToRxId);
                                    rmdWebLogger.info("TooloutputMerge ::::Inside mergedTo===rxId check");
                                    // call merge method if there is any match or any Rx which is
                                    // tagged with appended case
                                    CaseBean caseMergeBean = new CaseBean();
                                    caseMergeBean.setCaseId(toolOutputCaseMergeVO.getCaseId());
                                    caseMergeBean.setAppendToCaseId(arViewLogReponseTypes[0].getCaseId());
                                    caseMergeBean.setRuleDefId(toolOutputCaseMergeVO.getRuleDefId());
                                    caseMergeBean.setAssetGrpName(toolOutputCaseMergeVO.getGroupName());
                                    caseMergeBean.setAssetNumber(toolOutputCaseMergeVO.getAssetnumber());
                                    caseMergeBean.setCustomerId(toolOutputCaseMergeVO.getCustomerId());
                                    caseMergeBean.setToolId(toolOutputCaseMergeVO.getToolid());
                                    caseMergeBean.setRxObjId(Long.valueOf(toolOutputCaseMergeVO.getRxId()));
                                    caseMergeBean.setUserId(toolOutputDeliverVO.getUserName());
                                    caseMergeBean.setToolObjId(toolOutputCaseMergeVO.getToolObjId());
                                    caseMergeBean.setMergedTo(Long.valueOf(mergedToRxId));
                                    mergeRx(caseMergeBean);
                                }

                                // }

                            }
                        }// ends

                    }

                }
            }
            if (manualCaseIds.size() > 0) {
                ToolOutputActEntry objToolOutputActEntry = new ToolOutputActEntry();
                objToolOutputActEntry.setCaseObjids(manualCaseObjids);
                objToolOutputActEntry.setCaseTitle(rxTitles);
                objToolOutputActEntry.setManualcaseID(manualCaseIds);
                objToolOutputActEntry.setParentCaseID(parentCaseId);
                objToolOutputActEntry.setUserName(objCaseActionVO.getUserName());
                objToolOutputActEntry.setParentCaseObjid(parentCaseObjId);
                final String result = (String) webServiceInvoker.post(ServiceConstants.TOOL_OUTPUT_ACT_ENTRY,
                        objToolOutputActEntry, String.class);
            }

        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error("RMDWebException occured in appendRx() method ", rmdEx);

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in appendRx() method ", ex);

        }

        return arlDeliverSummaryVO;
    }
    /**
     * @throws RMDWebException
     *             This is the method used to create case and move tooloutput
     * @return List<String>
     * @throws RMDWebException
     */
    public String moveDeliverToolOutput(String userId, String currCaseId, String newCaseId, String rxId,
            String assetNumber, String assetGroupName, String customerId, String ruleDefId, String toolId,
            String caseType, String toolObjId) throws RMDWebException {

        final Map<String, String> queryParams = new HashMap<String, String>();
        String response = null;
        try {
            queryParams.put(AppConstants.CASE_Id, currCaseId);
            queryParams.put(AppConstants.TO_CASE_ID, newCaseId);
            queryParams.put(AppConstants.USER_ID, userId);
            queryParams.put(AppConstants.RX_ID, rxId);
            queryParams.put(AppConstants.RULE_DEFINITION_ID, ruleDefId);
            queryParams.put(AppConstants.ASSET_GROUP_NAME, assetGroupName);
            queryParams.put(AppConstants.ASSET_NUMBER, assetNumber);
            queryParams.put(AppConstants.CUSTOMER_ID, customerId);
            queryParams.put(AppConstants.TOOL_ID, toolId);
            queryParams.put(AppConstants.CASE_TYPE, caseType);
            queryParams.put(AppConstants.TOOL_OBJID, toolObjId);
            response = (String) webServiceInvoker.get(ServiceConstants.MOVE_DELIVER_TOOL_OUTPUT, null, queryParams,
                    null, String.class);
        } catch (RMDWebException e) {

            rmdWebLogger.error("Exception occured in moveDeliverToolOutput() method ", e);
            return AppConstants.FAILURE;
        } catch (Exception ex) {
            // rmdWebLogger.error(
            // "Exception occured in moveToolOutput() method ", ex);

            RMDWebErrorHandler.handleException(ex);
            return AppConstants.FAILURE;
        }
        return response;
    }

    @Override
    public String activeRxExistsInCase(String appendFromCaseId) throws RMDWebException, Exception {

        CaseBean caseBean = new CaseBean();
        caseBean.setCaseId(appendFromCaseId);
        final Map<String, String> pathParams = new HashMap<String, String>();
        final Map<String, String> queryParamsMap = new HashMap<String, String>();
        final Map<String, String> headerParams = getHeaderMap(caseBean);

        String activeRxExistsInCase = null;

        try {

            pathParams.put(AppConstants.CASE_ID, caseBean.getCaseId());
            activeRxExistsInCase = (String) webServiceInvoker.get(ServiceConstants.ACTIVE_RX_EXISTS, pathParams,
                    queryParamsMap, headerParams, String.class);
            if (activeRxExistsInCase != null && activeRxExistsInCase.equalsIgnoreCase(AppConstants.LETTER_Y))
                activeRxExistsInCase = AppConstants.LETTER_Y;

        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error("RMDWebException occured in activeRxExistsInCase() method ", rmdEx);

            return AppConstants.FAILURE;

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in activeRxExistsInCase() method ", ex);
            return AppConstants.FAILURE;

        }
        return activeRxExistsInCase;
    }
    public Map<String, String> getCloseOption(String listName) throws RMDWebException, Exception {
        Map<String, String> result = new HashMap<String, String>();
        try {
            List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService.getAllLookupValues().get(
                    listName);
            if (applParamResponseTypeList != null) {
                for (int i = 0; i < applParamResponseTypeList.size(); i++) {
                    result.put(applParamResponseTypeList.get(i).getLookupValue().split(":")[0],
                            applParamResponseTypeList.get(i).getLookupValue().split(":")[1]);
                }
            }
        } catch (Exception e) {
            RMDWebErrorHandler.handleException(e);
        }
        return result;
    }

    /**
     * @Author :
     * @return :RxDetailsVO
     * @param : caseObjId,vehicleObjId
     * @throws :RMDWebException
     * @Description: This method is used to get Rx Details of the Case.
     */

    @Override
    public RxDetailsVO getRxDetails(String caseObjId, String vehicleObjId) throws RMDWebException {

        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        RxDetailsVO objRxDetailsVO = new RxDetailsVO();
        try {
            queryParams.put(AppConstants.CASE_OBJID, caseObjId);
            queryParams.put(AppConstants.VEHICLE_OBJID, vehicleObjId);
            RxDetailsResponseType objRxDetailsResponseType = (RxDetailsResponseType) webServiceInvoker.get(
                    ServiceConstants.GET_RX_DETAILS, null, queryParams, null, RxDetailsResponseType.class);
            if (null != objRxDetailsResponseType) {
                objRxDetailsVO.seteServiceRxStatus(objRxDetailsResponseType.geteServiceRxStatus());
                objRxDetailsVO.setB2BRxStatus(objRxDetailsResponseType.getB2BRxStatus());
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getRxDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return objRxDetailsVO;
    }

    /**
     * @Author:
     * @param:String vehicleObjId
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used check whether PP Asset History Button Has to Disable or
     *               Enable.
     */
    @Override
    public String displayPPAssetHistoryBtn(String vehicleObjId) throws RMDWebException {
        String result = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            queryParams.put(AppConstants.VEHICLE_OBJID, vehicleObjId);
            result = (String) webServiceInvoker.get(ServiceConstants.GET_PP_ASSET_HST_BTN_DETAILS, null, queryParams,
                    null, String.class);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in displayPPAssetHistoryBtn method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return result;
    }

    /**
     * @Author :Mohamed
     * @return :List<MaterialUsageVO>
     * @param : serviceReqId,lookUpDays
     * @throws :RMDWebException
     * @Description: This method is used to get list of parts for particular case.
     */

    @Override
    public List<MaterialUsageVO> getMaterialUsage(String serviceReqId, String lookUpDays, String timeZone)
            throws RMDWebException {
        List<MaterialUsageVO> objMaterialUsageVOList = null;
        MaterialUsageResponseType[] MaterialUsageResponseType = null;
        MaterialUsageVO objMaterialUsageVO = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.VISUAL_DATE_FORMAT);
        final TimeZone timezone = TimeZone.getTimeZone(timeZone);
        try {
            if (!RMDCommonUtility.isNullOrEmpty(serviceReqId) && !RMDCommonUtility.isNullOrEmpty(lookUpDays)) {
                queryParams.put(AppConstants.SERVICE_REQ_ID, serviceReqId);
                queryParams.put(AppConstants.MATERIAL_USAGE_LOOKUP_DAYS, lookUpDays);
                MaterialUsageResponseType = (MaterialUsageResponseType[]) webServiceInvoker
                        .get(ServiceConstants.GET_MATERIAL_USAGE, null, queryParams, null,
                                MaterialUsageResponseType[].class);
                objMaterialUsageVOList = new ArrayList<MaterialUsageVO>();
                for (MaterialUsageResponseType objMaterialUsageResponseType : MaterialUsageResponseType) {
                    objMaterialUsageVO = new MaterialUsageVO();
                    final XMLGregorianCalendar creationDate = objMaterialUsageResponseType.getCreationDate();
                    zoneFormater.setTimeZone(timezone);
                    objMaterialUsageVO.setPartNo(objMaterialUsageResponseType.getPartNo());
                    objMaterialUsageVO.setDescription(objMaterialUsageResponseType.getDescription());
                    if (null != objMaterialUsageResponseType.getCreationDate()) {
                        objMaterialUsageVO.setCreationDate(zoneFormater.format(creationDate.toGregorianCalendar()
                                .getTime()));
                    }
                    objMaterialUsageVO.setLocation(objMaterialUsageResponseType.getLocation());
                    objMaterialUsageVO.setQuantity(objMaterialUsageResponseType.getQuantity());
                    objMaterialUsageVOList.add(objMaterialUsageVO);
                }
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getMaterialUsage method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return objMaterialUsageVOList;
    }

    /**
     * @Author :Mohamed
     * @return :Future<AssetLocatorResponseVO>
     * @param :AssetOverviewBean assetBean
     * @throws Exception
     * @throws :RMDWebException
     * @Description:This method fetches the common section of the asset case by invoking web
     *                   services getAssetCaseCommSection() method.
     */

    @Override
    public Future<AssetLocatorResponseVO> getAssetCaseCommSection(final AssetOverviewBean assetBean) throws Exception {
        rmdWebLogger.debug("AssetOverviewServiceImpl : Inside getAssetCaseCommSection() method::START");
        final AssetLocatorResponseVO assetLocatorBean = new AssetLocatorResponseVO();
        AssetLocRequestType objAssetLocReqType = new AssetLocRequestType();
        final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
        final TimeZone firstTime = TimeZone.getTimeZone(assetBean.getUserTimeZone());
        zoneFormater.setTimeZone(firstTime);
        String userTimeZone = firstTime.getID();
        String defaulTimeZone = assetBean.getDefaultTimeZone();
        try {
            if (null != assetBean) {
                objAssetLocReqType.setCustomerId(assetBean.getCustomer());
                objAssetLocReqType.setAssetNumber(assetBean.getAsset());
                objAssetLocReqType.setAssetGrpName(assetBean.getAssetGroup());
            }

            final AssetLocatorResponseType[] arrAssetLocatorResponse = (AssetLocatorResponseType[]) webServiceInvoker
                    .post(ServiceConstants.GET_ASSET_CASE_COMMON_SECTION, objAssetLocReqType,
                            AssetLocatorResponseType[].class);

            if (arrAssetLocatorResponse != null && arrAssetLocatorResponse.length > 0) {
                final AssetLocatorResponseType assetLocatorResponse = arrAssetLocatorResponse[0];
                if (null != assetLocatorResponse.getAssetNumber()) {
                    assetLocatorBean.setAssetNumber(assetLocatorResponse.getAssetNumber());
                }
                if (null != assetLocatorResponse.getLatitude()) {
                    assetLocatorBean.setLatitude(assetLocatorResponse.getLatitude());
                }
                if (null != assetLocatorResponse.getLongitude()) {
                    assetLocatorBean.setLongitude(assetLocatorResponse.getLongitude());
                }

                AssetLastFaultStatusVO assetLastFaultStatusVO = new AssetLastFaultStatusVO();
                if (null != assetLocatorResponse.getLstEOAFaultHeader()) {
                    assetLastFaultStatusVO.setLstEOAFault(zoneFormater.format(assetLocatorResponse
                            .getLstEOAFaultHeader().toGregorianCalendar().getTime()));
                }

                if (null != assetLocatorResponse.getLstPPATSMsgHeader()) {
                    assetLastFaultStatusVO.setLstPPATSMsg(zoneFormater.format(assetLocatorResponse
                            .getLstPPATSMsgHeader().toGregorianCalendar().getTime()));
                }
                if (null != assetLocatorResponse.getLstESTPDownloadHeader()) {
                    assetLastFaultStatusVO.setLstESTPDownload(zoneFormater.format(assetLocatorResponse
                            .getLstESTPDownloadHeader().toGregorianCalendar().getTime()));
                }
                if (null != assetLocatorResponse.getLstFaultDateCell()) {
                    assetLastFaultStatusVO.setLstFaultDateCell(zoneFormater.format(assetLocatorResponse
                            .getLstFaultDateCell().toGregorianCalendar().getTime()));
                }

                if (AppConstants.EST_TIMEZONE.equals(userTimeZone)
                        && AppConstants.TIMEZONE_EASTERN.equals(defaulTimeZone)) {
                    if (null != assetLocatorResponse.getNextScheduledRun()) {
                        assetLastFaultStatusVO.setNextScheduledRun(assetLocatorResponse.getNextScheduledRun());
                    }

                } else {
                    if (null != assetLocatorResponse.getNextScheduledRun()) {
                        Date nextScheduledRun = RMDCommonUtility.stringToUSESTDate(
                                assetLocatorResponse.getNextScheduledRun(),
                                RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
                        assetLastFaultStatusVO.setNextScheduledRun(zoneFormater.format(nextScheduledRun));
                    }
                }
                
                if (AppConstants.EST_TIMEZONE.equals(userTimeZone)
                        && AppConstants.TIMEZONE_EASTERN.equals(defaulTimeZone)) {
                    if (null != assetLocatorResponse.getLastToolRun()) {
                    	 assetLastFaultStatusVO.setLastToolRun(assetLocatorResponse.getLastToolRun());
                    }

                } else {
                    if (null != assetLocatorResponse.getLastToolRun()) {
                        Date lastToolRun = RMDCommonUtility.stringToUSESTDate(
                                assetLocatorResponse.getLastToolRun(),
                                RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
                        assetLastFaultStatusVO.setLastToolRun(zoneFormater.format(lastToolRun));
                    }
                }
                
                if (AppConstants.EST_TIMEZONE.equals(userTimeZone)
                        && AppConstants.TIMEZONE_EASTERN.equals(defaulTimeZone)) {
                    if (null != assetLocatorResponse.getLastRecord()) {
                    	 assetLastFaultStatusVO.setLastRecord(assetLocatorResponse.getLastRecord());
                    }

                } else {
                    if (null != assetLocatorResponse.getLastRecord()) {
                        Date lastRecord = RMDCommonUtility.stringToUSESTDate(
                                assetLocatorResponse.getLastRecord(),
                                RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
                        assetLastFaultStatusVO.setLastRecord(zoneFormater.format(lastRecord));
                    }
                }
                
                if(null!=assetLastFaultStatusVO.getLastToolRun()&&null!=assetLastFaultStatusVO.getLastRecord()){
                
                SimpleDateFormat format = new SimpleDateFormat(
						AppConstants.DATE_FORMAT);
				Date d1 = null;
				Date d2 = null;
				d1 = format.parse(assetLastFaultStatusVO.getLastToolRun());
				d2 = format.parse(assetLastFaultStatusVO.getLastRecord());
				long diff = d2.getTime() - d1.getTime();
				long diffSeconds = diff / (1000);
				//long diffDays = diff / (24 * 60 * 60 * 1000);
				if (diffSeconds > 0) {
					assetLastFaultStatusVO.setShowToolRun(true);
				}else{
					assetLastFaultStatusVO.setShowToolRun(false);
				}
                }else{
                	assetLastFaultStatusVO.setShowToolRun(true);
                }
               
                assetLastFaultStatusVO.setServices(assetLocatorResponse.getServices());

                assetLocatorBean.setAssetlastFaultStatusVo(assetLastFaultStatusVO);

            }
        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error("RMDWebException occured in getAssetCaseCommSection() method ", rmdEx);
            throw rmdEx;
        }
        rmdWebLogger.debug("AssetOverviewServiceImpl : Inside getAssetCaseCommSection() method::END");
        return new AsyncResult<AssetLocatorResponseVO>(assetLocatorBean);
    }
    @Override
    public String mergeRx(CaseBean caseBean) throws RMDWebException, Exception {

        final Map<String, String> pathParams = new HashMap<String, String>();
        final Map<String, String> queryParamsMap = new HashMap<String, String>();
        final Map<String, String> headerParams = getHeaderMap(caseBean);

        String strResponse = null;
        String ruleDef = null;
        try {

            if (caseBean.getRuleDefId() == null || caseBean.getRuleDefId().equals(AppConstants.EMPTY_STRING))
                ruleDef = "0";
            else
                ruleDef = caseBean.getRuleDefId();

            pathParams.put(AppConstants.CASE_ID, caseBean.getCaseId());
            pathParams.put(AppConstants.TO_CASE_ID, caseBean.getAppendToCaseId());
            pathParams.put(AppConstants.USER_ID, caseBean.getUserId());
            pathParams.put(AppConstants.RX_ID, String.valueOf(caseBean.getRxObjId()));
            pathParams.put(AppConstants.MERGED_TO, String.valueOf(caseBean.getMergedTo()));
            pathParams.put(AppConstants.RULE_DEFINITION_ID, ruleDef);
            pathParams.put(AppConstants.ASSET_GROUP_NAME, caseBean.getAssetGrpName());
            pathParams.put(AppConstants.ASSET_NUMBER, caseBean.getAssetNumber());
            pathParams.put(AppConstants.CUSTOMER_ID, caseBean.getCustomerId());
            pathParams.put("toolId", caseBean.getToolId());
            pathParams.put(AppConstants.TOOL_OBJID, caseBean.getToolObjId());

            strResponse = (String) webServiceInvoker.get(ServiceConstants.MERGED_TO, pathParams, queryParamsMap,
                    headerParams, String.class);

        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error("RMDWebException occured in merge() method ", rmdEx);

            return AppConstants.FAILURE;

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in mergeRx() method ", ex);
            return AppConstants.FAILURE;
        }

        return strResponse;

    }
    /**
     * @Author :
     * @return :String
     * @param :AddNotesEoaServiceVO
     * @throws : RMDWebException
     * @Description:This method is used for adding Case notes for a given case.
     */

    @Override
    public String addNotesToUnit(final NotesBean notesBean) throws RMDWebException {
        String result = null;
        NotesRequestType requestobj = null;
        try {

            if (null != notesBean) {
                requestobj = new NotesRequestType();
                requestobj.setAssestNumber(notesBean.getAssetNumber());
                requestobj.setCustomerID(notesBean.getCustomerId());
                requestobj.setAssetGrpName(notesBean.getAssetGroup());
                requestobj.setApplyLevel(notesBean.getApplyLevel());
                requestobj.setNotes(ESAPI.encoder().encodeForXML(notesBean.getNoteDescription()));
                requestobj.setSticky(notesBean.getSticky());
                requestobj.setUserId(notesBean.getUserId());
                result = (String) webServiceInvoker.post(ServiceConstants.ADD_NOTES_TO_UNIT, requestobj, String.class);
            }
        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in addNotesToUnit   in AssetCasesServiceImpl:", e);
            RMDWebErrorHandler.handleException(e);
        }
        return result;
    }
    @Override
    public StickyNotesDetailsVO fetchStickyUnitLevelNotes(String assetNumber, String customerId, String assetGrpName,
            String timeZone) throws RMDWebException {
        StickyNotesDetailsVO objStickyNotesDetailsVO = null;
        final DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
        final TimeZone userTimeZone = TimeZone.getTimeZone(timeZone);
        try {

            final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
            queryParamMap.put(AppConstants.REQ_PARAM_ASSTNUM, assetNumber);
            queryParamMap.put(AppConstants.REQ_PARAM_CUSID, customerId);
            queryParamMap.put(AppConstants.REQ_PARAM_ASSTGRP, assetGrpName);
            StickyNotesDetailsResponseType notesDetails = (StickyNotesDetailsResponseType) webServiceInvoker.get(
                    ServiceConstants.FETCH_UNIT_LEVEL_STICKY_DETAILS, null, queryParamMap, null,
                    StickyNotesDetailsResponseType.class);
            if (null != notesDetails) {
                objStickyNotesDetailsVO = new StickyNotesDetailsVO();
                objStickyNotesDetailsVO.setApplyLevel(notesDetails.getApplyLevel());
                objStickyNotesDetailsVO.setAdditionalInfo(ESAPI.encoder().decodeForHTML(
                        notesDetails.getAdditionalInfo()));
                objStickyNotesDetailsVO.setCreatedBy(notesDetails.getCreatedBy());
                objStickyNotesDetailsVO.setObjId(notesDetails.getObjId());
                final XMLGregorianCalendar entryTime = notesDetails.getEntryTime();
                zoneFormater.setTimeZone(userTimeZone);
                if (null != notesDetails.getEntryTime()) {
                    objStickyNotesDetailsVO
                            .setEntryTime(zoneFormater.format(entryTime.toGregorianCalendar().getTime()));
                }
            }
        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in fetchStickyCaseNOtes in AssetCasesServiceImpl:", e);
            RMDWebErrorHandler.handleException(e);
        }
        return objStickyNotesDetailsVO;
    }

    /**
     * @Author :Vamshi
     * @return :Map<String,String>
     * @param :
     * @throws : RMDWebException
     * @Description:This method is used for fetching Smart Shop Votes
     */

    @Override
    public Map<String, String> getGPOCSmartShopVotes() throws RMDWebException {

        Map<String, String> smartVoteMap = new LinkedHashMap<String, String>();
        try {
            final Map<String, String> pathParams = new LinkedHashMap<String, String>();
            pathParams.put(AppConstants.LIST_NAME, AppConstants.GPOC_SMART_SHOP_VOTES);
            final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
            if (null != applParamResponseType) {

                for (int i = 0; i < applParamResponseType.length; i++) {
                    String repairCode = applParamResponseType[i].getLookupValue();
                    String desc = applParamResponseType[i].getListDescription();
                    smartVoteMap.put(repairCode, desc);
                }

            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getGPOCSmartShopVotes method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return smartVoteMap;
    }

    /**
     * @Author :Vamshi
     * @return :String
     * @param :CaseSolutionVO objCaseSolutionVO
     * @throws :RMDWebException
     * @Description:This method is responsible for Casting the GPOC Users Vote.
     */
    @Override
    public String castGPOCVote(CaseSolutionVO objCaseSolutionVO) throws RMDWebException {
        RepairCodeDetailsType objRepaircodeDetails = new RepairCodeDetailsType();
        String responseMsg = null;
        try {
            objRepaircodeDetails.setCaseID(objCaseSolutionVO.getCaseId());
            objRepaircodeDetails.setRepairCode(objCaseSolutionVO.getRepairCode());
            objRepaircodeDetails.setCmAliasName(objCaseSolutionVO.getUserId());
            responseMsg = (String) webServiceInvoker.post(ServiceConstants.CAST_GPOC_VOTE, objRepaircodeDetails,
                    String.class);
        } catch (RMDWebException e) {
            rmdWebLogger.error("Exception occured in castGPOCVote()  method ", e);
            throw e;
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in castGPOCVote()  method of AssetCasesServiceImpl.java ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return responseMsg;
    }

    /**
     * @Author :Vamshi
     * @return :String
     * @param :CaseSolutionVO objCaseSolutionVO
     * @throws :RMDWebException
     * @Description:This method is responsible for fetching previously Casted
     */

    @Override
    public String getPreviousVote(String caseObjId) throws RMDWebException {
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        String previousVote = null;
        try {
            queryParams.put(AppConstants.CASE_OBJID, caseObjId);
            previousVote = (String) webServiceInvoker.get(ServiceConstants.GET_PREVIOUS_VOTE, null, queryParams, null,
                    String.class);
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getPreviousVote() method of AssetCasesServiceImpl.java", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return previousVote;
    }

    @Override
    public Future<List<CaseTrendDataVO>> getOpenCommRXDetails() throws RMDWebException {
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        CaseTrendResponseType[] caseTrendResponseType = null;
        List<CaseTrendDataVO> openCommList = new ArrayList<CaseTrendDataVO>();
        CaseTrendDataVO openComm = null;
        try {
            caseTrendResponseType = (CaseTrendResponseType[]) webServiceInvoker.get(
                    ServiceConstants.GET_OPEN_COMM_RX_COUNT, null, queryParams, null, CaseTrendResponseType[].class);
            if (null != caseTrendResponseType && caseTrendResponseType.length > 0) {
                for (CaseTrendResponseType objCaseTrendResponseType : caseTrendResponseType) {
                    openComm = new CaseTrendDataVO();
                    openComm.setCustomer(objCaseTrendResponseType.getCustomer());
                    openComm.setCount(objCaseTrendResponseType.getRxCount());
                    openCommList.add(openComm);
                }
            }
            caseTrendResponseType = null;
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getOpenCommRXDetails() method of AssetCasesServiceImpl.java", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return new AsyncResult<List<CaseTrendDataVO>>(openCommList);
    }

    @Override
    public Future<CaseConversionBean> getCaseConversionDetails() throws RMDWebException {
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        CaseConversionResponseType[] caseConversionResponseType = null;
        Map<String, Map<Integer, String>> caseConvCount = new LinkedHashMap<String, Map<Integer, String>>();
        Map<Integer, String> conversion = null;
        CaseConversionBean caseConversionBean = new CaseConversionBean();
        List<CaseConversionBean> caseConversionBeanList = new ArrayList<CaseConversionBean>();
        try {
            caseConversionResponseType = (CaseConversionResponseType[]) webServiceInvoker.get(
                    ServiceConstants.GET_CASE_CONVERSION_DETAILS, null, queryParams, null,
                    CaseConversionResponseType[].class);
            if (null != caseConversionResponseType && caseConversionResponseType.length > 0) {
                for (CaseConversionResponseType objCaseConversionResponseType : caseConversionResponseType) {
                    if (caseConvCount.containsKey(objCaseConversionResponseType.getYear())) {
                        conversion = new LinkedHashMap<Integer, String>();
                        conversion = caseConvCount.get(objCaseConversionResponseType.getYear());
                        conversion.put(Integer.parseInt(objCaseConversionResponseType.getMonth()),
                                objCaseConversionResponseType.getConvCount());
                        caseConvCount.put(objCaseConversionResponseType.getYear(), conversion);
                    } else {
                        conversion = new LinkedHashMap<Integer, String>();
                        conversion.put(Integer.parseInt(objCaseConversionResponseType.getMonth()),
                                objCaseConversionResponseType.getConvCount());
                        caseConvCount.put(objCaseConversionResponseType.getYear(), conversion);
                    }
                }
            }
            caseConversionBean.setConversionMap(caseConvCount);
            caseConversionBeanList.add(caseConversionBean);
            caseConversionResponseType = null;
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getOpenCommRXDetails() method of AssetCasesServiceImpl.java", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return new AsyncResult<CaseConversionBean>(caseConversionBean);
    }

    @Override
    public String getCaseConversionPercentage() throws RMDWebException {
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        String responseType = null;
        String convPercentage = null;
        try {
            responseType = (String) webServiceInvoker.get(ServiceConstants.GET_CASE_CONVERSION_PERCENTAGE, null,
                    queryParams, null, String.class);
            if (null != responseType && !responseType.equals(AppConstants.EMPTY_STRING)) {
                convPercentage = responseType;
            } else {
                convPercentage = "Percentage Not Available";
            }
            responseType = null;
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getOpenCommRXDetails() method of AssetCasesServiceImpl.java", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return convPercentage;
    }

    @Override
    public Future<TopNoActionBean> getTopNoActionRXDetails() throws RMDWebException {
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        CaseConversionResponseType[] caseConversionResponseType = null;
        Map<String, List<String>> topNoActionRXMap = new LinkedHashMap<String, List<String>>();
        List<String> topNoActionRX = null;
        String title = null;
        TopNoActionBean caseBean = new TopNoActionBean();
        try {
            caseConversionResponseType = (CaseConversionResponseType[]) webServiceInvoker.get(
                    ServiceConstants.GET_TOP_NO_ACTION_RX_DETAILS, null, queryParams, null,
                    CaseConversionResponseType[].class);
            if (null != caseConversionResponseType && caseConversionResponseType.length > 0) {
                for (CaseConversionResponseType objCaseConversionResponseType : caseConversionResponseType) {
                    if (topNoActionRXMap.containsKey(objCaseConversionResponseType.getRxCount())) {
                        topNoActionRX = new ArrayList<String>();
                        topNoActionRX = topNoActionRXMap.get(objCaseConversionResponseType.getRxCount());
                        title = objCaseConversionResponseType.getRxTitle().replace(", No Action",
                                AppConstants.EMPTY_STRING);
                        topNoActionRX.add(title);
                        topNoActionRXMap.put(objCaseConversionResponseType.getRxCount(), topNoActionRX);
                    } else {
                        topNoActionRX = new ArrayList<String>();
                        title = objCaseConversionResponseType.getRxTitle().replace(", No Action",
                                AppConstants.EMPTY_STRING);
                        topNoActionRX.add(title);
                        topNoActionRXMap.put(objCaseConversionResponseType.getRxCount(), topNoActionRX);
                    }
                }
            }
            caseBean.setTopNoActionRX(topNoActionRXMap);
            caseConversionResponseType = null;

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getTopNoActionRXDetails() method of AssetCasesServiceImpl.java",
                    ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return new AsyncResult<TopNoActionBean>(caseBean);
    }

    @Override
    public List<GenNotesVO> getCommNotesDetails() throws RMDWebException {
        List<GenNotesVO> arlGenNotesVO = null;
        GenNotesVO objGenNotesVO = null;
        GeneralNotesResponseType[] arGeneralNotesResponseType = null;
        String notes =null;
        try {
            arGeneralNotesResponseType = (GeneralNotesResponseType[]) webServiceInvoker.get(
                    ServiceConstants.GET_COMM_NOTES_DETAILS, null, null,
                    null, GeneralNotesResponseType[].class);
            if (arGeneralNotesResponseType != null
                    && arGeneralNotesResponseType.length > 0) {
                arlGenNotesVO = new ArrayList<GenNotesVO>(arGeneralNotesResponseType.length);
                for (GeneralNotesResponseType gnRespType : arGeneralNotesResponseType) {
                    objGenNotesVO = new GenNotesVO();
                    if(!RMDCommonUtility.isNull(gnRespType.getNotesdesc())){
                        notes = EsapiUtil.resumeSpecialChars(gnRespType.getNotesdesc());
                        objGenNotesVO.setNotesdesc(notes.replace(RMDCommonConstants.GREATER_THAN_SYMBOL, RMDCommonConstants.GRTTHAN).replace(RMDCommonConstants.LESS_THAN_SYMBOL, RMDCommonConstants.LESSTHAN));
                    }
                    objGenNotesVO.setEnteredby(gnRespType.getEnteredby());
                    arlGenNotesVO.add(objGenNotesVO);
                }
            }
            
        }catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getCommNotesDetails() method of AssetCasesServiceImpl.java", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return arlGenNotesVO;
    }

    @Override
    public String getAddRepCodeDetails(String caseId) throws RMDWebException {
        String retValue = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            if (!RMDCommonUtility.isNullOrEmpty(caseId)) {
                queryParams.put(AppConstants.VIEW_CLOSURE_CASE_ID, caseId);
                retValue = (String) webServiceInvoker.get(ServiceConstants.GET_ADD_REP_CODE_DETAILS, null, queryParams,
                        null, String.class);
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getAddRepCodeDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }

        return retValue;
    }

    @Override
    public String getLookUpRepCodeDetails(String reapairCodeList) throws RMDWebException {
        String retValue = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            if (!RMDCommonUtility.isNullOrEmpty(reapairCodeList)) {
                queryParams.put(AppConstants.REPAIRCODE_LIST, reapairCodeList);
                retValue = (String) webServiceInvoker.get(ServiceConstants.GET_LOOKUP_ADD_REP_CODE_DETAILS, null,
                        queryParams, null, String.class);
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getLookUpRepCodeDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }

        return retValue;
    }
    
    @Override
	public List<CaseScoreRepairCodeVO> getCaseScoreRepairCodes(String rxCaseId)
			throws RMDWebException {
        List<CaseScoreRepairCodeVO> objCloseOutRepairCodeVOList = null;
        CaseScoreRepairCodesResponseType[] objCloseOutRepairCodesResponseType = null;
        CaseScoreRepairCodeVO objCloseOutRepairCodeVO = null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            if (!RMDCommonUtility.isNullOrEmpty(rxCaseId)) {
                queryParams.put(AppConstants.RX_CASE_ID, rxCaseId);
                objCloseOutRepairCodesResponseType = (CaseScoreRepairCodesResponseType[]) webServiceInvoker.get(
                        ServiceConstants.GET_CASESCORE_REPAIR_CODE, null, queryParams, null,
                        CaseScoreRepairCodesResponseType[].class);
                objCloseOutRepairCodeVOList = new ArrayList<CaseScoreRepairCodeVO>();
                for (CaseScoreRepairCodesResponseType objCloOutRpCodResponseType : objCloseOutRepairCodesResponseType) {
                    objCloseOutRepairCodeVO = new CaseScoreRepairCodeVO();
                    
                    objCloseOutRepairCodeVO.setRepairCode(objCloOutRpCodResponseType.getRepairCode());
                    objCloseOutRepairCodeVO.setDescription(ESAPI.encoder().decodeForHTML(
                            objCloOutRpCodResponseType.getDescription()));
                    objCloseOutRepairCodeVO.setRepairCodeId(objCloOutRpCodResponseType.getRepairCodeId());
                    objCloseOutRepairCodeVOList.add(objCloseOutRepairCodeVO);
                }
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getCloseOutRepairCode method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return objCloseOutRepairCodeVOList;
    }
    
    @Override
    public List<String> validateVehBoms(String customer,String rnh,String rn,String rxObjId,String fromScreen) throws RMDWebException {
        List<String> assetList = null;
        RxVehicleBomResponseType objRxVehicleBomResponseType=null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        try {
            if (!RMDCommonUtility.isNullOrEmpty(customer)) {
                queryParams.put(AppConstants.CUSTOMER, customer);
                
            }
            if (!RMDCommonUtility.isNullOrEmpty(rnh)) {
                queryParams.put(AppConstants.RNH, rnh);
                
            }
            if (!RMDCommonUtility.isNullOrEmpty(rn)) {
                queryParams.put(AppConstants.ROAD_NUMBER, rn);
                
            }
            if (!RMDCommonUtility.isNullOrEmpty(rxObjId)) {
                queryParams.put(AppConstants.RX_OBJ_ID, rxObjId);                
            }
            if (!RMDCommonUtility.isNullOrEmpty(fromScreen)) {
                queryParams.put(AppConstants.FROM_SCREEN, fromScreen);                
            }
            objRxVehicleBomResponseType = (RxVehicleBomResponseType) webServiceInvoker.get(ServiceConstants.VALIDATE_VEH_BOMS, null, queryParams,
                    null, RxVehicleBomResponseType.class);
            if(null!=objRxVehicleBomResponseType && RMDCommonUtility.isCollectionNotEmpty(objRxVehicleBomResponseType.getAssetList())){
                assetList=objRxVehicleBomResponseType.getAssetList();
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in validateVehBoms method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }

        return assetList;
    }

    /**
     * @Author:
     * @param:String caseObjid,String rxObjid, String fromScreen,String custFdbkObjId
     * @return:String
     * @throws:RMDWebException
     * @Description: This method is used for fetching Msdc Notes for the Recommendation by invoking
     *               web services getMsdcNotes() method.
     */

    @Override
    public List<RxDeliveryAttachmentVO> getRxDeliveryAttachments(String caseObjid, String rxObjid) throws RMDWebException {
    	RxDeliveryAttachmentVO objRxDeliveryAttachmentVO=null;
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        List<RxDeliveryAttachmentVO> arlRxDeliveryAttachmentVO=new ArrayList<RxDeliveryAttachmentVO>();
        try {
            queryParams.put(AppConstants.CASE_OBJID, caseObjid);
            queryParams.put(AppConstants.RX_OBJ_ID, rxObjid);            
            RxDeliveryAttachmentResponse[] lstAttachmentVOs = (RxDeliveryAttachmentResponse[]) webServiceInvoker.get(ServiceConstants.GET_RX_DELIVERY_ATTACHMENTS, null, queryParams, null,
            		RxDeliveryAttachmentResponse[].class);
            if(null!=lstAttachmentVOs){
            for(RxDeliveryAttachmentResponse objAttachmentResponse:lstAttachmentVOs){
            	objRxDeliveryAttachmentVO=new RxDeliveryAttachmentVO();
            	objRxDeliveryAttachmentVO.setStrDocumentPath(objAttachmentResponse.getDocumentPath());
            	objRxDeliveryAttachmentVO.setStrDocumentTitle(objAttachmentResponse.getDocumentTitle());
            	arlRxDeliveryAttachmentVO.add(objRxDeliveryAttachmentVO);
            }
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getMsdcNotes method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return arlRxDeliveryAttachmentVO;
    }
    
    /**
     * @Author :
     * @return :RxDetailsVO
     * @param : caseObjId,vehicleObjId
     * @throws :RMDWebException
     * @Description: This method is used to get Rx Details of the Case.
     */

    @Override
    public String getCaseRxDelvDetails(String caseId) throws RMDWebException {

        final Map<String, String> queryParams = new LinkedHashMap<String, String>();
        String rxObjid = null;
        try {
            queryParams.put(AppConstants.CASE_Id, caseId);
            CaseRxDetailsResponseType objCaseRxDetailsResponseType = (CaseRxDetailsResponseType) webServiceInvoker.get(
                    ServiceConstants.GET_CASE_RX_DELV_DETAILS, queryParams, null, null,
                    CaseRxDetailsResponseType.class);
            if (null != objCaseRxDetailsResponseType) {
                List<SolutionInfoType> delvRxList = objCaseRxDetailsResponseType.getSolutionInfo();    
                if(delvRxList != null && !delvRxList.isEmpty()){
                	rxObjid=delvRxList.get(0).getSolutionOBJID();
                }
            }
        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getRxDetails method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return rxObjid;
    }  
}
