/**
 * ============================================================
 * File 			: KPIServiceImpl.java
 * Description 		: Service implementation class for KPIService * 
 * Package 			: com.ge.trans.rmd.cm.service
 * Author 			: UST
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		: April 30, 2012
 * History
 * Modified By 		: Initial Release
 * Copyright (C) 2012 General Electric Company. All rights reserved
 * ============================================================
 */

package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.beans.KPIBean;
import com.ge.trans.rmd.cm.beans.OpenCasesBean;
import com.ge.trans.rmd.cm.valueobjects.KPITotalCountResponseTypeVO;
import com.ge.trans.rmd.cm.valueobjects.KpiInfoTypeVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.kpi.valueobjects.KpiInfoType;
import com.ge.trans.rmd.services.kpi.valueobjects.KpiRequestType;
import com.ge.trans.rmd.services.kpi.valueobjects.KpiTotalCountRequestType;
import com.ge.trans.rmd.services.kpi.valueobjects.KpiTotalCountResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service(AppConstants.KPISERVICE)
public class KPIServiceImpl extends RMDBaseServiceImpl implements KPIService {

	@Autowired
	private WebServiceInvoker webServiceInvoker;
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
	.getLogger(getClass());

	@Autowired
	private CachedService cachedService;
	/**
	 * This method is used to fetch default no.of days for each graph in the KPI
	 * pie charts
	 * 
	 * @param kpiDefaultLookupList
	 * @return
	 */
	@Override
	public Map<String, Long> findDefaultNumberOfDays(
			List<String> kpiDefaultLookupList) {
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		Map<String, Long> defaultLookupMap = new HashMap<String, Long>();
		String numDaysBefore = AppConstants.EMPTYSTRING;
		String lookupName = AppConstants.EMPTYSTRING;
		try {
			Iterator<String> it = kpiDefaultLookupList.iterator();
			while (it.hasNext()) {
				pathParams.clear();
				lookupName = it.next();
				pathParams.put(AppConstants.LIST_NAME, lookupName);
				final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
				if (applParamResponseType != null) {
					numDaysBefore = applParamResponseType[0].getLookupValue();
					defaultLookupMap.put(lookupName,
							Long.parseLong(numDaysBefore));
				}
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in findDefaultNumberOfDays() method ",
							rmdEx);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in findDefaultNumberOfDays() method ",
					ex);
		}
		return defaultLookupMap;
	}

	/**
	 * This method is used to fetch RxCount to be displayed in the KPI pie
	 * charts
	 * 
	 * @param openCaseBean
	 * @return
	 */
	public List<KPITotalCountResponseTypeVO> getRxKPIValues(
			final List<KPIBean> kpiList, final OpenCasesBean openCaseBean, final String userCustomer) {

		List<KPITotalCountResponseTypeVO> kpiTotalCountResponseTypeVOs = new ArrayList<KPITotalCountResponseTypeVO>();
		KpiTotalCountRequestType objKpiTotCntReqType = new KpiTotalCountRequestType();
		List<KpiRequestType> kpiRequestList = new ArrayList<KpiRequestType>();
		KpiTotalCountResponseType kpiTotalCountResponseType;
		KPITotalCountResponseTypeVO kpiTotalCountResponseTypeVO;
		DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_DAY);
		DateFormat zoneFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_DAY);
		final TimeZone userTimezone = TimeZone.getTimeZone(openCaseBean.getTimeZone());
		XMLGregorianCalendar xmlLastUpdatedDt = null;
		XMLGregorianCalendar xmlToDate = null;
		Date fromdate = null; 
		Date todate = null;
		GregorianCalendar fromgregorianCalendar, togregorianCalendar;

		
		try {
			if (cachedService.getSDCustLookup().get(userCustomer) != null
	                && cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
	                && !cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim().equals("")){
	          zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat());
			}

			Iterator<KPIBean> it = kpiList.iterator();
			while (it.hasNext()) {
				KPIBean tempBean = it.next();
				KpiRequestType kpi = new KpiRequestType();
				kpi.setKpiName(tempBean.getKpiName());
				kpi.setNoDays(tempBean.getNumDays());
				kpiRequestList.add(kpi);
			}
			objKpiTotCntReqType.setKpiRequestType(kpiRequestList);
			if (null != openCaseBean.getCustomerId()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(openCaseBean.getCustomerId())) {
				objKpiTotCntReqType.setCustomerId(openCaseBean.getCustomerId());
			}

			parseProducts(openCaseBean.getProducts(), objKpiTotCntReqType);
			final KpiTotalCountResponseType[] kpiTotalCountResponseTypeList = (KpiTotalCountResponseType[]) webServiceInvoker
					.post(ServiceConstants.GET_RX_KPI_COUNTS,
							objKpiTotCntReqType,
							KpiTotalCountResponseType[].class);
			for (int i = 0; i < kpiTotalCountResponseTypeList.length; i++) {

				kpiTotalCountResponseType = kpiTotalCountResponseTypeList[i];
				kpiTotalCountResponseTypeVO = new KPITotalCountResponseTypeVO();
				kpiTotalCountResponseTypeVO = populateKPITotalCountResponseType(kpiTotalCountResponseType);
				
				zoneFormater.setTimeZone(userTimezone);
				
				//TZ Fix Changes				
				if (null != kpiTotalCountResponseTypeVO.getLastUpdatedDate()) {
					String lastUpdatedDt = kpiTotalCountResponseTypeVO.getLastUpdatedDate();
					GregorianCalendar objGregorianCalendar = (GregorianCalendar) GregorianCalendar.getInstance();
					objGregorianCalendar.setTime(zoneFormat.parse(lastUpdatedDt));
					RMDCommonUtility.setZoneOffsetTime( objGregorianCalendar,openCaseBean.getTimeZoneCode());
					xmlLastUpdatedDt = DatatypeFactory.newInstance().newXMLGregorianCalendar(objGregorianCalendar);
					kpiTotalCountResponseTypeVO.setLastUpdatedDate(zoneFormater.format(xmlLastUpdatedDt.toGregorianCalendar().getTime()).substring(0, 10)+RMDCommonConstants.BLANK_SPACE+openCaseBean.getTimeZoneCode());
				}
				
				kpiTotalCountResponseTypeVOs.add(kpiTotalCountResponseTypeVO);
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in  getRxKPIValues() method ",
					rmdEx);
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getRxKPIValues() method ",
					ex);
		}
		return kpiTotalCountResponseTypeVOs;
	}
	
	/**
	 * This method is used to build the RxCount data that needs to be populated
	 * in the KPI pie charts
	 * 
	 * @param kpiTotalCountResponseType
	 * @param firstTime 
	 * @return
	 */
	private KPITotalCountResponseTypeVO populateKPITotalCountResponseType(
			final KpiTotalCountResponseType kpiTotalCountResponseType) {
		final KPITotalCountResponseTypeVO kpiTotalCountResponseTypeVO = new KPITotalCountResponseTypeVO();
		KpiInfoTypeVO kpiInfoVo;
		final List<KpiInfoTypeVO> kpiInfoList = new ArrayList<KpiInfoTypeVO>();

		BeanUtils.copyProperties(kpiTotalCountResponseType,
				kpiTotalCountResponseTypeVO);
		if (null != kpiTotalCountResponseType.getParameter()) {
			for (KpiInfoType kpiInfoType : kpiTotalCountResponseType
					.getParameter()) {
				kpiInfoVo = new KpiInfoTypeVO();
				kpiInfoVo.setParameterName(kpiInfoType.getParameterName());
				if (kpiInfoType.getParameterCount().contains(
						AppConstants.VIEW_DECIMAL)
						|| kpiInfoType.getParameterCount().contains(
								RMDCommonConstants.N_A)) {
					kpiInfoVo.setPercentage(kpiInfoType.getParameterCount());
				} else {
					kpiInfoVo.setParameterCount(Integer.valueOf(kpiInfoType
							.getParameterCount()));
					kpiInfoVo.setPercentage(kpiInfoType.getParameterCount());
				}
				kpiInfoList.add(kpiInfoVo);
			}
			if (null != kpiTotalCountResponseType.getLastFourWeekAvg()) {
				kpiTotalCountResponseTypeVO
						.setLastFourWeekAvg(kpiTotalCountResponseType
								.getLastFourWeekAvg());
			}
			if (null != kpiTotalCountResponseType.getLastQuarterAvg()) {
				kpiTotalCountResponseTypeVO
						.setLastQuarterAvg(kpiTotalCountResponseType
								.getLastQuarterAvg());
			}
			if (null != kpiTotalCountResponseType.getCurrentYearAvg()) {
				kpiTotalCountResponseTypeVO
						.setCurrentYearAvg(kpiTotalCountResponseType
								.getCurrentYearAvg());
			}
			
			

			
			
			
			kpiTotalCountResponseTypeVO.setCustomerId(kpiTotalCountResponseType
					.getCustomerId());
			kpiTotalCountResponseTypeVO.setParameter(kpiInfoList);
		}
		return kpiTotalCountResponseTypeVO;
	}

	/**
	 * This method is used get values for drop down values in the KPI pie charts
	 * 
	 * @param kpiLookupList
	 * @return
	 */
	@Override
	public Map<String, List<String>> getDaysFromLookUp(
			List<String> kpiLookupList) {
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		Map<String, List<String>> LookupMap = new HashMap<String, List<String>>();
		String lookupName = AppConstants.EMPTYSTRING;
		try {
			Iterator<String> it = kpiLookupList.iterator();
			while (it.hasNext()) {
				List<String> numDaysBefore = new ArrayList<String>();
				pathParams.clear();
				lookupName = it.next();
				pathParams.put(AppConstants.LIST_NAME, lookupName);
				final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
				if (applParamResponseType != null) {
					for (ApplicationParametersResponseType daysList : applParamResponseType) {
						numDaysBefore.add(daysList.getLookupValue());
					}
					LookupMap.put(lookupName, numDaysBefore);
				}
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getDaysFromLookUp() method ",
					rmdEx);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getDaysFromLookUp() method ", ex);
		}
		return LookupMap;
	}
	
}