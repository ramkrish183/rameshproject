package com.ge.trans.rmd.cm.service;

import java.util.List;

import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.valueobjects.UnitRoadHeaderUpdateVO;
import com.ge.trans.rmd.pp.beans.AssetBean;

public interface UnitRenumberingService {
	public String updateUnitNumber(String oldUnitNum, String newUnitNum, String vehicleHeader, String customerId) throws RMDWebException;
	public String updateUnitHeader(UnitRoadHeaderUpdateVO unitRoadHeaderUpdate) throws RMDWebException;
	public List<String> getAssets(AssetBean assetBean) throws RMDWebException, Exception;
}
