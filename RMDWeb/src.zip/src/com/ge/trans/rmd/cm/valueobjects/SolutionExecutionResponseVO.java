/**
 * ============================================================
 * File 			: SolutionExecutionResponseVO.java
 * Description 		: Value Object for Rx Case Details Display * 
 * Package 			: com.ge.trans.rmd.cm.valueobjects
 * Author 			: UST
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		: April 3, 2012
 * History
 * Modified By 		: Initial Release
 * Copyright (C) 2012 General Electric Company. All rights reserved
 * ============================================================
 */
package com.ge.trans.rmd.cm.valueobjects;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

public class SolutionExecutionResponseVO implements Serializable {

	private static final long serialVersionUID = 1022L;
	protected String caseID;
	protected String assetGrpName;
	protected String assetNumber;
	protected SolutionDetailVO solutionDetail;
	protected String solutionDelvID;
	protected String solutionExecutionID;
	protected String strIssueDate;
	protected String strCreationDate;
	protected String closedBy;
	protected Date strClosedDate;
	protected List<TaskDetailVO> taskDetail;
	protected String rxTitle;
	protected String repairAction;
	protected String defectMode;
	protected String rxCloseFlag;
	protected String solutionFileName;
	protected String solutionFilePath;
	protected List<String> arlRecomTaskList;
	protected String strRxExecutionId;
	
	protected Date rxExecutionDate;
		
	//Request params got from the cases page to be passed to RxExecution details Page for display purpose
	private String owner;
	private String urgency;
	private String estmRepairTime;
	private String locomotiveImpact;
	private String delvDate;
	private String age;
	private String solutionCaseID;
	private List<LocationVO> locationVOList;
	private String locationId;
	private boolean selectedTask;
	private String strRecomId;	
	private String strClosedDateAge;
	private String version;
	private String strViz;
	private String endUserScoring;
	private String userSeqId;
	
	private String recomNotes;
	private String rxDescription;
	private String rxDeliveredBy;
	private String prerequisites;
	private String customerName;
	private List<DeliveryAttachmentVO>  deliveryRxAttachments;
	
	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}
	

	public String getStrViz() {
		return strViz;
	}

	public void setStrViz(String strViz) {
		this.strViz = strViz;
	}

	public String getAssetGrpName() {
		return assetGrpName;
	}

	public void setAssetGrpName(String assetGrpName) {
		this.assetGrpName = assetGrpName;
	}

	public Date getRxExecutionDate() {
		return rxExecutionDate;
	}

	public void setRxExecutionDate(Date rxExecutionDate) {
		this.rxExecutionDate = rxExecutionDate;
	}

	public boolean isSelectedTask() {
		return selectedTask;
	}

	public void setSelectedTask(boolean selectedTask) {
		this.selectedTask = selectedTask;
	}

	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	public List<LocationVO> getLocationVOList() {
		return locationVOList;
	}

	public void setLocationVOList(List<LocationVO> locationVOList) {
		this.locationVOList = locationVOList;
	}

	public String getCaseID() {
		return caseID;
	}

	public void setCaseID(final String caseID) {
		this.caseID = caseID;
	}

	public String getAssetNumber() {
		return assetNumber;
	}

	public void setAssetNumber(final String assetNumber) {
		this.assetNumber = assetNumber;
	}

	public SolutionDetailVO getSolutionDetail() {
		return solutionDetail;
	}

	public void setSolutionDetail(final SolutionDetailVO solutionDetail) {
		this.solutionDetail = solutionDetail;
	}

	public String getSolutionDelvID() {
		return solutionDelvID;
	}

	public void setSolutionDelvID(final String solutionDelvID) {
		this.solutionDelvID = solutionDelvID;
	}

	public String getSolutionExecutionID() {
		return solutionExecutionID;
	}

	public void setSolutionExecutionID(final String solutionExecutionID) {
		setStrRxExecutionId(solutionExecutionID);
		this.solutionExecutionID = solutionExecutionID;
	}

	public String getStrIssueDate() {
		return strIssueDate;
	}

	public void setStrIssueDate(final String strIssueDate) {
		this.strIssueDate = strIssueDate;
	}

	public String getStrCreationDate() {
		return strCreationDate;
	}

	public void setStrCreationDate(final String strCreationDate) {
		this.strCreationDate = strCreationDate;
	}

	public String getClosedBy() {
		return closedBy;
	}

	public void setClosedBy(final String closedBy) {
		this.closedBy = closedBy;
	}

	public Date getStrClosedDate() {
		return strClosedDate;
	}

	public void setStrClosedDate(final Date strClosedDate) {
		this.strClosedDate = strClosedDate;
	}

	public List<TaskDetailVO> getTaskDetail() {
		return taskDetail;
	}

	public void setTaskDetail(final List<TaskDetailVO> taskDetail) {
		this.taskDetail = taskDetail;
	}

	public String getRxTitle() {
		return rxTitle;
	}

	public void setRxTitle(final String rxTitle) {
		this.rxTitle = rxTitle;
	}

	public String getRepairAction() {
		return repairAction;
	}

	public void setRepairAction(final String repairAction) {
		this.repairAction = repairAction;
	}

	public String getDefectMode() {
		return defectMode;
	}

	public void setDefectMode(final String defectMode) {
		this.defectMode = defectMode;
	}

	public String getRxCloseFlag() {
		return rxCloseFlag;
	}

	public void setRxCloseFlag(final String rxCloseFlag) {
		this.rxCloseFlag = rxCloseFlag;
	}

	public String getSolutionFileName() {
		return solutionFileName;
	}

	public void setSolutionFileName(final String solutionFileName) {
		this.solutionFileName = solutionFileName;
	}

	public String getSolutionFilePath() {
		return solutionFilePath;
	}

	public void setSolutionFilePath(final String solutionFilePath) {
		this.solutionFilePath = solutionFilePath;
	}

	public List<String> getArlRecomTaskList() {
		return arlRecomTaskList;
	}

	public void setArlRecomTaskList(final List<String> arlRecomTaskList) {
		this.arlRecomTaskList = arlRecomTaskList;
	}

	public String getStrRxExecutionId() {
		return strRxExecutionId;
	}

	public void setStrRxExecutionId(final String strRxExecutionId) {
		this.strRxExecutionId = strRxExecutionId;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(final String owner) {
		this.owner = owner;
	}

	public String getUrgency() {
		return urgency;
	}

	public void setUrgency(final String urgency) {
		this.urgency = urgency;
	}

	public String getEstmRepairTime() {
		return estmRepairTime;
	}

	public void setEstmRepairTime(final String estmRepairTime) {
		this.estmRepairTime = estmRepairTime;
	}

	public String getLocomotiveImpact() {
		return locomotiveImpact;
	}

	public void setLocomotiveImpact(final String locomotiveImpact) {
		this.locomotiveImpact = locomotiveImpact;
	}

	public String getDelvDate() {
		return delvDate;
	}

	public void setDelvDate(final String delvDate) {
		this.delvDate = delvDate;
	}

	public String getAge() {
		return age;
	}

	public void setAge(final String age) {
		this.age = age;
	}

	public String getSolutionCaseID() {
		return solutionCaseID;
	}

	public void setSolutionCaseID(String solutionCaseID) {
		this.solutionCaseID = solutionCaseID;
	}	

	public String getStrRecomId() {
		return strRecomId;
	}

	public void setStrRecomId(String strRecomId) {
		this.strRecomId = strRecomId;
	}

	public String getStrClosedDateAge() {
		return strClosedDateAge;
	}

	public void setStrClosedDateAge(String strClosedDateAge) {
		this.strClosedDateAge = strClosedDateAge;
	}

	public String getEndUserScoring() {
		return endUserScoring;
	}

	public void setEndUserScoring(String endUserScoring) {
		this.endUserScoring = endUserScoring;
	}

    public String getUserSeqId() {
        return userSeqId;
    }

    public void setUserSeqId(String userSeqId) {
        this.userSeqId = userSeqId;
    }

	public String getRecomNotes() {
		return recomNotes;
	}

	public void setRecomNotes(String recomNotes) {
		this.recomNotes = recomNotes;
	}

	public String getRxDescription() {
		return rxDescription;
	}

	public void setRxDescription(String rxDescription) {
		this.rxDescription = rxDescription;
	}

	public String getRxDeliveredBy() {
		return rxDeliveredBy;
	}

	public void setRxDeliveredBy(String rxDeliveredBy) {
		this.rxDeliveredBy = rxDeliveredBy;
	}

	public String getPrerequisites() {
		return prerequisites;
	}

	public void setPrerequisites(String prerequisites) {
		this.prerequisites = prerequisites;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public List<DeliveryAttachmentVO> getDeliveryRxAttachments() {
		return deliveryRxAttachments;
	}

	public void setDeliveryRxAttachments(List<DeliveryAttachmentVO> deliveryRxAttachments) {
		this.deliveryRxAttachments = deliveryRxAttachments;
	}
	

}
