/**
 * 
 */
package com.ge.trans.rmd.cm.valueobjects;

/**
 * @author MSHIRAJUDDIN
 *
 */
public class AssetTemplateVO {
	
	private String templateId;
	private String obsoleteFlag; 
	private String templateType;
	private String templateNumber;
	private String templateVersion;
	private String installationDate;
	private String offboardStatus;
	private String offboardStatusDate;
	private String templateRemove;
	private String templateReapply;
	private String strTemplateID;
	private String strTemplateKey;
	private String strActive;
	private String title;
	
	/**
	 * @return the templateVersion
	 */
	public String getTemplateVersion() {
		return templateVersion;
	}
	/**
	 * @param templateVersion the templateVersion to set
	 */
	public void setTemplateVersion(String templateVersion) {
		this.templateVersion = templateVersion;
	}
	
	
	/**
	 * @return the templateRemove
	 */
	public String getTemplateRemove() {
		return templateRemove;
	}
	/**
	 * @param templateRemove the templateRemove to set
	 */
	public void setTemplateRemove(String templateRemove) {
		this.templateRemove = templateRemove;
	}
	/**
	 * @return the templateReapply
	 */
	public String getTemplateReapply() {
		return templateReapply;
	}
	/**
	 * @param templateReapply the templateReapply to set
	 */
	public void setTemplateReapply(String templateReapply) {
		this.templateReapply = templateReapply;
	}
	/**
	 * @return the strTemplateID
	 */
	public String getStrTemplateID() {
		return strTemplateID;
	}
	/**
	 * @param strTemplateID the strTemplateID to set
	 */
	public void setStrTemplateID(String strTemplateID) {
		this.strTemplateID = strTemplateID;
	}
	/**
	 * @return the strTemplateKey
	 */
	public String getStrTemplateKey() {
		return strTemplateKey;
	}
	/**
	 * @param strTemplateKey the strTemplateKey to set
	 */
	public void setStrTemplateKey(String strTemplateKey) {
		this.strTemplateKey = strTemplateKey;
	}
	public String getTemplateId() {
		return templateId;
	}
	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	
	public String getObsoleteFlag() {
		return obsoleteFlag;
	}
	public void setObsoleteFlag(String obsoleteFlag) {
		this.obsoleteFlag = obsoleteFlag;
	}
	public String getTemplateType() {
		return templateType;
	}
	public void setTemplateType(String templateType) {
		this.templateType = templateType;
	}
	public String getTempVer() {
		return templateVersion;
	}
	public void setTempVer(String templateVersion) {
		this.templateVersion = templateVersion;
	}
	public String getInstallationDate() {
		return installationDate;
	}
	public void setInstallationDate(String installationDate) {
		this.installationDate = installationDate;
	}
	public String getOffboardStatus() {
		return offboardStatus;
	}
	public void setOffboardStatus(String offboardStatus) {
		this.offboardStatus = offboardStatus;
	}
	public String getOffboardStatusDate() {
		return offboardStatusDate;
	}
	public void setOffboardStatusDate(String offboardStatusDate) {
		this.offboardStatusDate = offboardStatusDate;
	}
	public String getTemplateNumber() {
		return templateNumber;
	}
	public void setTemplateNumber(String templateNumber) {
		this.templateNumber = templateNumber;
	}
	public String getStrActive() {
		return strActive;
	}
	public void setStrActive(String strActive) {
		this.strActive = strActive;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}	

}
