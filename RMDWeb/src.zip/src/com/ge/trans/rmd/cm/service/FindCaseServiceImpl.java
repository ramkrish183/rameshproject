package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;

import javax.xml.datatype.XMLGregorianCalendar;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.FindCasesDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.FindCasesVO;
import com.ge.trans.rmd.cm.valueobjects.RxHistoryVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.pp.valueobjects.PPAssetHistoryDetailsVO;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseInfoType;
import com.ge.trans.rmd.services.cases.valueobjects.FindCasesDetailsResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.FindCasesRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.RxHistoryResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;
import com.ge.trans.rmd.utilities.AppSecUtil;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class FindCaseServiceImpl extends RMDBaseServiceImpl implements FindCaseService
{
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	WebServiceInvoker webServiceInvoker;

	/**
	 * 
	 * @param
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Find Cases Search Options By dropdown.
	 * 
	 */
	@Override
	public Map<String, String> getfindCaseSearchOptions()
			throws RMDWebException {
		Map<String, String> allStatusMap = new LinkedHashMap<String, String>();
		String searchOptions = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.FINDCASE_SEARCH_OPTIONS);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					searchOptions = applParamResponseType[i].getLookupValue();
					allStatusMap.put(searchOptions, searchOptions);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getfindCaseSearchOptions method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allStatusMap;
	}

	/**
	 * 
	 * @param
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Find Cases Filter Options By dropdown.
	 * 
	 */
	@Override
	public Map<String, String> getfindCaseFilterOptions()
			throws RMDWebException {
		Map<String, String> allStatusMap = new LinkedHashMap<String, String>();
		String filterOptions = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.FINDCASE_FILTER_OPTIONS);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					filterOptions = applParamResponseType[i].getLookupValue();
					allStatusMap.put(filterOptions, filterOptions);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getfindCaseFilterOptions method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allStatusMap;
	}
	
	
	/**
	 * 
	 * @param
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the RN Filter Options By dropdown.
	 * 
	 */
	@Override
	public Map<String, String> getRNFilterOptions()
			throws RMDWebException {
		Map<String, String> allStatusMap = new LinkedHashMap<String, String>();
		String filterOptions = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.RN_FILTER_OPTIONS);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					filterOptions = applParamResponseType[i].getLookupValue();
					allStatusMap.put(filterOptions, filterOptions);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getfindCaseFilterOptions method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allStatusMap;
	}

	/**
	 * 
	 * @param
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Find Cases CaseType By dropdown.
	 * 
	 */
	@Override
	public Map<String, String> getfindCaseCaseType() throws RMDWebException {
		Map<String, String> allStatusMap = new TreeMap<String, String>();
		String caseTypes = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.FINDCASE_CASE_TYPES);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					caseTypes = applParamResponseType[i].getLookupValue();
					allStatusMap.put(caseTypes, caseTypes);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getfindCaseCaseType method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allStatusMap;
	}

	/**
	 * 
	 * @param
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the Find Cases LookBakDays By dropdown.
	 * 
	 */
	public String getFindCasesLookBakDays() throws RMDWebException {
		String strFindCasesLookBackDays = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.FINDCASES_LOOKBACK_DAYS);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					strFindCasesLookBackDays = applParamResponseType[i]
							.getLookupValue();
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getFindCasesLookBakDays method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return strFindCasesLookBackDays;
	}

	/**
	 * @Author:
	 * @param:FindCasesDetailsVO
	 * @return:List<FindCasesDetailsVO>
	 * @throws:RMDWebException
	 * @Description: This method is used to get Find Cases Details.
	 */
	@Override
	public List<FindCasesDetailsVO> getFindCases(FindCasesVO objFindCasesVO,
			String timezone , String defaultTimeZone) throws RMDWebException {
		List<FindCasesDetailsVO> objFindCasesDetailsVOlst = new ArrayList<FindCasesDetailsVO>();
		FindCasesRequestType objFindCasesRequestType = new FindCasesRequestType();
		FindCasesDetailsResponseType objFindCasesDetailsResponseType[] = null;
		final DateFormat nonESTZoneFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		FindCasesDetailsVO objFindCasesDetailsVO = null;
		final TimeZone firstTime = TimeZone.getTimeZone(timezone);
		nonESTZoneFormat.setTimeZone(firstTime);
		String userTimeZone = firstTime.getID();
		Date creationTime = null;
		try {
			objFindCasesRequestType.setCustomerName(objFindCasesVO
					.getCustomerName());
			objFindCasesRequestType.setRoadNumberHeader(objFindCasesVO
					.getRoadNumberHeader());
			objFindCasesRequestType.setRoadNumber(objFindCasesVO
					.getRoadNumber());
			objFindCasesRequestType.setSearchOption(objFindCasesVO
					.getSearchOption());
			objFindCasesRequestType.setFilterOption(objFindCasesVO
					.getFilterOption());
			objFindCasesRequestType.setFieldValue(objFindCasesVO
					.getFieldValue());
			objFindCasesRequestType.setCaseType(objFindCasesVO.getCaseType());
			objFindCasesRequestType.setStartdate(objFindCasesVO.getStartdate());
			objFindCasesRequestType.setEndDate(objFindCasesVO.getEndDate());
			objFindCasesRequestType.setRoadNumberFilterSelected(objFindCasesVO.getRoadNumberFilterSelected());

			// Call web service for find cases
			objFindCasesDetailsResponseType = (FindCasesDetailsResponseType[]) webServiceInvoker
					.post(ServiceConstants.GET_FIND_CASES,
							objFindCasesRequestType,
							FindCasesDetailsResponseType[].class);

			if (null != objFindCasesDetailsResponseType) {
				objFindCasesDetailsVOlst = new ArrayList<FindCasesDetailsVO>(objFindCasesDetailsResponseType.length);
				for (FindCasesDetailsResponseType objFindCasesDtlsResponseType : objFindCasesDetailsResponseType) {
					objFindCasesDetailsVO = new FindCasesDetailsVO();
					objFindCasesDetailsVO
							.setCaseID(objFindCasesDtlsResponseType.getCaseID());
					objFindCasesDetailsVO.setTitle(ESAPI.encoder()
							.decodeForHTML(
									objFindCasesDtlsResponseType.getTitle()));
					objFindCasesDetailsVO
							.setCondition(objFindCasesDtlsResponseType
									.getCondition());
					objFindCasesDetailsVO
							.setStatus(objFindCasesDtlsResponseType.getStatus());
					objFindCasesDetailsVO
							.setContact(objFindCasesDtlsResponseType
									.getContact());

					if (userTimeZone.equals(AppConstants.EST_TIMEZONE)
							&& defaultTimeZone.equals(AppConstants.TIMEZONE_EASTERN)) {
						if (null != objFindCasesDtlsResponseType.getCreationTime()) {
							objFindCasesDetailsVO.setCreationTime(objFindCasesDtlsResponseType.getCreationTime());
						}

					 } else {
						if (null != objFindCasesDtlsResponseType.getCreationTime()) {
							creationTime = RMDCommonUtility.stringToUSESTDate(
									objFindCasesDtlsResponseType.getCreationTime(),
									RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
							objFindCasesDetailsVO.setCreationTime(nonESTZoneFormat.format(creationTime));
						}
					 }
						
					objFindCasesDetailsVO
							.setCaseType(objFindCasesDtlsResponseType
									.getCaseType());
					objFindCasesDetailsVO
							.setCustomerId(objFindCasesDtlsResponseType
									.getCustomerId());
					objFindCasesDetailsVO
							.setCustRNH(objFindCasesDtlsResponseType
									.getCustRNH());
					objFindCasesDetailsVO.setRn(objFindCasesDtlsResponseType
							.getRn());
					objFindCasesDetailsVO.setQueue(objFindCasesDtlsResponseType
							.getQueue());
					objFindCasesDetailsVOlst.add(objFindCasesDetailsVO);
				}
			} objFindCasesDetailsResponseType=null;
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getFindCases method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return objFindCasesDetailsVOlst;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, List<String>>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Customer Name and Road
	 *               Number Headers.
	 */
	@Override
	public Map<String, List<String>> getCustNameRNH() throws RMDWebException {
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		final Map<String, List<String>> custNameRNHMap = new LinkedHashMap<String, List<String>>();
		List<String> lstString = null;
		String customerName = null;
		String strRNH = null;
		AssetResponseType objAssetResponseType[] = null;
		try {
			// Call web service for find cases
			objAssetResponseType = (AssetResponseType[]) webServiceInvoker.get(
					ServiceConstants.GET_CUSTOMER_RNH, null, queryParamMap,
					null, AssetResponseType[].class);
			if (null != objAssetResponseType) {
				for (AssetResponseType objAssetRespType : objAssetResponseType) {
					customerName = objAssetRespType.getCustomerName();
					strRNH = objAssetRespType.getAssetGroupName();
					if (custNameRNHMap.containsKey(customerName)) {
						lstString = new ArrayList<String>();
						lstString = custNameRNHMap.get(customerName);
						lstString.add(strRNH);
						custNameRNHMap.put(customerName, lstString);
					} else {
						lstString = new ArrayList<String>();
						lstString.add(strRNH);
						custNameRNHMap.put(customerName, lstString);
					}
				}
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getCustNameRNH() method - FindCaseServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return custNameRNHMap;
	}
	

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Road Number.
	 */
	@Override
	public Map<String, String> getRoadNumbers(String customerName, String rnhId)
			throws RMDWebException {
		Map<String, String> allRoadNumbers = new TreeMap<String, String>();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		String strRoadNumber = null;
		try {
			queryParams.put(AppConstants.RNH_ID, rnhId);
			queryParams.put(AppConstants.CUSTOMER_NAME, customerName);
			final AssetResponseType[] assetResponseType = (AssetResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_ROAD_NUM, null, queryParams,
							null, AssetResponseType[].class);
			if (null != assetResponseType) {
				for (AssetResponseType objassetResponseType : assetResponseType) {
					strRoadNumber = objassetResponseType.getAssetNumber();
					allRoadNumbers.put(strRoadNumber, strRoadNumber);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getRoadNumbers method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allRoadNumbers;
	}
	
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Road Number.
	 */
	@Override
	public Map<String, String> getRoadNumbers(String customerName, String rnhId, String rnSearchString, String rnFilter )
			throws RMDWebException {
		Map<String, String> allRoadNumbers = new TreeMap<String, String>();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		String strRoadNumber = null;
		try {
			queryParams.put(AppConstants.RNH_ID, rnhId);
			queryParams.put(AppConstants.CUSTOMER_NAME, customerName);
			queryParams.put(AppConstants.RN_SEARCH_STRING, rnSearchString);
			queryParams.put(AppConstants.RN_FILTER, rnFilter);
			final AssetResponseType[] assetResponseType = (AssetResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_ROAD_NUM_WITH_FILTER, null, queryParams,
							null, AssetResponseType[].class);
			if (null != assetResponseType) {
				for (AssetResponseType objassetResponseType : assetResponseType) {
					strRoadNumber = objassetResponseType.getAssetNumber();
					allRoadNumbers.put(strRoadNumber, strRoadNumber);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getRoadNumbers method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return allRoadNumbers;
	}
}
