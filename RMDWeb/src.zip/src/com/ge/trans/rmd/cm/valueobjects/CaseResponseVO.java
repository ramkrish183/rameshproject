/**
 * ============================================================
 * File 			: CaseResponseVO.java
 * Description 		: Value Object for Open Cases Display * 
 * Package	 		: com.ge.trans.rmd.cm.valueobjects
 * Author 			: UST
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		: April 3, 2012
 * History
 * Modified By 		: Initial Release
 * Copyright (C) 2012 General Electric Company. All rights reserved
 * ============================================================
 */
package com.ge.trans.rmd.cm.valueobjects;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class CaseResponseVO implements Serializable,Cloneable {

	private static final long serialVersionUID = 6628227939071535472L;
	private String assetNumber;
	private String caseStatus;
	private String queueName;
	private String caseId;
	private String caseTitle;
	private String urgency;
	private String owner;
	private String priority;

	private String createdDate;
	private String closedDate;
	private String age;
	private String timeZone;
	private String solutionStatus;
	private String solutionTitle;
	private String solutionOBJID;
	private String strUrgRepair;
	private String customerName;
	private String assetGrpName;
	private String estRepairTime;
	private Map<String, String> errorMsg;
	private String caseType;
	private String fleet;
	private String model;
	private String actionableRxType;
	public String getRxType() {
		return rxType;
	}

	public void setRxType(String rxType) {
		this.rxType = rxType;
	}


	private String rxType;

	private List<TechnicianSolutionDetailVO> techCaseDetail;
	
	public Map<String, String> getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(Map<String, String> errorMsg) {
		this.errorMsg = errorMsg;
	}

	public String getEstRepairTime() {
		return estRepairTime;
	}

	public void setEstRepairTime(String estRepairTime) {
		this.estRepairTime = estRepairTime;
	}

	public String getAssetGrpName() {
		return assetGrpName;
	}

	public void setAssetGrpName(String assetGrpName) {
		this.assetGrpName = assetGrpName;
	}

	public String getSolutionStatus() {
		return solutionStatus;
	}

	public void setSolutionStatus(final String solutionStatus) {
		this.solutionStatus = solutionStatus;
	}

	public String getSolutionTitle() {
		return solutionTitle;
	}

	public void setSolutionTitle(final String solutionTitle) {
		this.solutionTitle = solutionTitle;
	}

	public String getSolutionOBJID() {
		return solutionOBJID;
	}

	public void setSolutionOBJID(final String solutionOBJID) {
		this.solutionOBJID = solutionOBJID;
	}

	public String getStrUrgRepair() {
		return strUrgRepair;
	}

	public void setStrUrgRepair(final String strUrgRepair) {
		this.strUrgRepair = strUrgRepair;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(final String customerName) {
		this.customerName = customerName;
	}

	/**
	 * 
	 * @return the caseId
	 */
	public String getCaseId() {
		return caseId;
	}

	/**
	 * 
	 * @param caseId
	 *            the caseId to set
	 */
	public void setCaseId(final String caseId) {
		this.caseId = caseId;
	}

	/**
	 * 
	 * @return the caseTitle
	 */
	public String getCaseTitle() {
		return caseTitle;
	}

	/**
	 * 
	 * @param caseTitle
	 *            the caseTitle to set
	 */
	public void setCaseTitle(final String caseTitle) {
		this.caseTitle = caseTitle;
	}

	/**
	 * 
	 * @return the urgency
	 */
	public String getUrgency() {
		return urgency;
	}

	/**
	 * 
	 * @param urgency
	 *            the urgency to set
	 */
	public void setUrgency(final String urgency) {
		this.urgency = urgency;
	}

	/**
	 * 
	 * @return the assetNumber
	 */
	public String getAssetNumber() {
		return assetNumber;
	}

	/**
	 * 
	 * @param assetNumber
	 *            the assetNumber to set
	 */
	public void setAssetNumber(final String assetNumber) {
		this.assetNumber = assetNumber;
	}

	/**
	 * 
	 * @return the caseStatus
	 */
	public String getCaseStatus() {
		return caseStatus;
	}

	/**
	 * 
	 * @param caseStatus
	 *            the caseStatus to set
	 */
	public void setCaseStatus(final String caseStatus) {
		this.caseStatus = caseStatus;
	}

	public String getOwner() {
		return owner;
	}

	public void setOwner(final String owner) {
		this.owner = owner;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(final String priority) {
		this.priority = priority;
	}

	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(final String queueName) {
		this.queueName = queueName;
	}

	public String getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(final String createdDate) {
		this.createdDate = createdDate;
	}

	public String getClosedDate() {
		return closedDate;
	}

	public void setClosedDate(final String closedDate) {
		this.closedDate = closedDate;
	}

	public String getAge() {
		return age;
	}

	public void setAge(final String age) {
		this.age = age;
	}

	public List<TechnicianSolutionDetailVO> getTechCaseDetail() {
		return techCaseDetail;
	}

	public void setTechCaseDetail(List<TechnicianSolutionDetailVO> techCaseDetail) {
		this.techCaseDetail = techCaseDetail;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(final String timeZone) {
		this.timeZone = timeZone;
	}

	public String getCaseType() {
		return caseType;
	}

	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public String getFleet() {
		return fleet;
	}

	public void setFleet(String fleet) {
		this.fleet = fleet;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}
	
	public String getActionableRxType() {
		return actionableRxType;
	}

	public void setActionableRxType(String actionableRxType) {
		this.actionableRxType = actionableRxType;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	@Override
	public Object clone() throws CloneNotSupportedException {
		CaseResponseVO caseResponseVO = new CaseResponseVO();
			caseResponseVO.setAssetNumber(assetNumber);
			caseResponseVO.setCaseStatus(caseStatus);
			caseResponseVO.setQueueName(queueName);
			caseResponseVO.setCaseId(caseId);
			caseResponseVO.setCaseTitle(caseTitle);
			caseResponseVO.setUrgency(urgency);
			caseResponseVO.setOwner(owner);
			caseResponseVO.setPriority(priority);
			caseResponseVO.setCreatedDate(createdDate);
			caseResponseVO.setClosedDate(closedDate);
			caseResponseVO.setAge(age);
			caseResponseVO.setTimeZone(timeZone);
			caseResponseVO.setSolutionStatus(solutionStatus);
			caseResponseVO.setSolutionTitle(solutionTitle);
			caseResponseVO.setSolutionOBJID(solutionOBJID);
			caseResponseVO.setUrgency(strUrgRepair);
			caseResponseVO.setCustomerName(customerName);
			caseResponseVO.setAssetGrpName(assetGrpName);
			caseResponseVO.setEstRepairTime(estRepairTime);
			caseResponseVO.setCaseType(caseType);
			caseResponseVO.setFleet(fleet);
			caseResponseVO.setModel(model);
			caseResponseVO.setActionableRxType(actionableRxType);
			caseResponseVO.setRxType(rxType);
		return caseResponseVO;
	}
	
}
