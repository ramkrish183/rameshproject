/**
 * ============================================================
 * File : SolutionExecutionController.java
 * Description : Controller for Technician Cases and Rx Case Execution Details
 * 
 * Package 			: com.ge.trans.rmd.cm.mvc.controller
 * Author 			: UST
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		: April 03, 2012
 * History
 * Modified By 		: Initial Release
 * Copyright (C) 2012 General Electric Company. All rights reserved
 * ============================================================
 */
package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import com.ge.trans.rmd.common.esapi.util.EsapiUtil;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.owasp.esapi.codecs.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ge.trans.rmd.cm.beans.OpenCasesBean;
import com.ge.trans.rmd.cm.service.SolutionExecutionService;
import com.ge.trans.rmd.cm.valueobjects.CaseResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LocationVO;
import com.ge.trans.rmd.cm.valueobjects.SolutionExecutionResponseVO;
import com.ge.trans.rmd.cm.valueobjects.TaskDetailVO;
import com.ge.trans.rmd.cm.valueobjects.TechnicianSolutionDetailVO;
import com.ge.trans.rmd.common.beans.FavoriteFilterBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.km.mvc.controller.RxController;
import com.ge.trans.rmd.km.util.KMConstants;
import com.ge.trans.rmd.logging.RMDLogger;
import com.ge.trans.rmd.utilities.AppSecUtil;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.common.service.CachedService;

@Controller
@SessionAttributes
public class SolutionExecutionController extends RMDBaseController {

	@Autowired
	private SolutionExecutionService solutionExecutionService;

	@Autowired
	private AuthorizationService authService;

	@Autowired
	RxController rxController;
	@Autowired
	private AssetOverviewController assetOverviewController;

	@Autowired
	ApplicationContext appContext;
	public static final RMDLogger LOG = RMDLogger
			.getLogger(SolutionExecutionController.class);
	
	@Autowired
	private CachedService cachedService;
	/**
	 * This method will fetch cases for the Technician view with solution status
	 * as OPEN
	 * 
	 * @param model
	 * @param response
	 * @return Model
	 */
	@RequestMapping(value = AppConstants.GET_RXEXEC_CASES)
	public String getCases(final Model model,
			final HttpServletResponse response, final HttpServletRequest request)
			throws Exception {
		response.setContentType(AppConstants.TEXT_HTML);
		request.setAttribute(AppConstants.FILTERFLAG,
				EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG)));
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);

		final OpenCasesBean openCaseBean = new OpenCasesBean();
		final CaseResponseVO objCaseResponseVO = new CaseResponseVO();
		/* For timezone issue */
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		/* For timezone issue */
		openCaseBean.setUserLanguage(userVO.getStrUserLanguage());
		openCaseBean.setTimeZone(applicationTimezone);
		openCaseBean.setCustomerId(userVO.getCustomerId());
		if(null!=userVO.getProducts()&& !userVO.getProducts().isEmpty()){
		openCaseBean.setProducts(userVO.getProducts());
		}		
		List<CaseResponseVO> listCaseResponseVO = new ArrayList<CaseResponseVO>();
		try {
			
			Map<String, String> componentList = new HashMap<String, String>();
			componentList.put(
					AppConstants.RX_FILTER_URGENCY_TECHCASES_PRIVILEGE,
					AppConstants.RX_FILTER_URGENCY);
			componentList.put(
					AppConstants.RX_FILTER_ESTREPTIME_TECHCASES_PRIVILEGE,
					AppConstants.RX_FILTER_ESTREPTIME);
			/* For RX Title in technician filter */
			componentList.put(
					AppConstants.RX_FILTER_TITLES_TECHNICIAN_PRIVILEGE,
					AppConstants.RX_FILTER_APPROVEDRXTITLES);
			/* For RX Title in technician filter */
			/*For case Type*/
			componentList.put(
					AppConstants.FILTER_CASETYPE_TECHNICIAN_PRIVILEGE,
					AppConstants.RX_FILTER_CASETYPE);
			/*For case Type*/
			//For Fleet
			componentList.put(AppConstants.RX_FILTER_FLEET_TECHCASES_PRIVILEGE,
					AppConstants.RX_FILTER_FLEET);
			//For Model
			componentList.put(AppConstants.RX_FILTER_MODEL_TECHCASES_PRIVILEGE,
					AppConstants.RX_FILTER_MODEL);
			componentList.put(
					AppConstants.DEFAULT_FILTER_TECHNICIAN_PRIVILEGE,
					AppConstants.DEFAULT_FILTER);
			componentList.put(AppConstants.RX_FILTER_ACTIONABLE_RXTYPE_TECHCASES_PRIVILEGE,
					AppConstants.RX_FILTER_ACTIONABLE_RXTYPE);
			// method call to get the enabled components for logged in user
			getComponentPrivilege(componentList, userVO, request);
			//Added for favorite filter story
			Map<String,Object> componentMap =new HashMap<String,Object>();
			componentMap.put(AppConstants.URGENCY_FAV_FILTER, request.getAttribute(AppConstants.RX_FILTER_URGENCY));
			componentMap.put(AppConstants.EST_REPAIR_TIME, request.getAttribute(AppConstants.RX_FILTER_ESTREPTIME));
			componentMap.put(AppConstants.RX_TITLE, request.getAttribute(AppConstants.RX_FILTER_APPROVEDRXTITLES));
			componentMap.put(AppConstants.COMPONENT_CASE_TYPE, request.getAttribute(AppConstants.RX_FILTER_CASETYPE));
			componentMap.put(AppConstants.COMPONENT_FLEET, request.getAttribute(AppConstants.RX_FILTER_FLEET));
			componentMap.put(AppConstants.COMPONENT_MODEL, request.getAttribute(AppConstants.RX_FILTER_MODEL));
			componentMap.put(AppConstants.RX_ACTIONABLE_TYPE, request.getAttribute(AppConstants.RX_FILTER_ACTIONABLE_RXTYPE));
			componentMap.put(AppConstants.ASSETNUM, true);
			componentMap.put(AppConstants.CASEID, true);
			String favoriteFilters=getFavoriteFilters(AppConstants.TECHNICIAN,userVO,componentMap);
			if(null!=favoriteFilters && !favoriteFilters.equals(AppConstants.EMPTY_STRING)&&(Boolean)request.getAttribute(AppConstants.DEFAULT_FILTER)){
				request.setAttribute(AppConstants.FAVORITE_FILTER, favoriteFilters);
			}
			/*else{
				if(null!=userVO.getProducts()&& !userVO.getProducts().isEmpty()){
			listCaseResponseVO = solutionExecutionService.getCases(
					AppConstants.QUEUE_DELIVERED,
					AppConstants.SOLUTION_STATUS_VALUE, openCaseBean,
					objCaseResponseVO);
				}
			model.addAttribute(AppConstants.TECHCASESBEAN, listCaseResponseVO);
			}*/
			final String techCasesRefreshTime = authService
					.getLookUpValueForName(AppConstants.CASES_REFRESH_TIME);
			request.setAttribute(AppConstants.TECHNICIAN_REFRESH_TIME,
					techCasesRefreshTime);
			request.setAttribute(AppConstants.TECH_CASE_ID,
					AppConstants.TECHNICIAN_CASES_VAL);
			

		} catch (Exception ex) {
			RMDWebErrorHandler.handleException(ex);
		}
		//Added for favorite filter story
		request.setAttribute(AppConstants.SELECTED_TAB, AppConstants.TECHNICIAN);
		//adding for pagination
		request.setAttribute(
				AppConstants.TECHNICIAN_DEFAULT_RECORDS,
				findNumberOfRecords(AppConstants.TECHNICIAN_TABLE_DEFAULT_RECORDS));
		return AppConstants.TECHNICIAN_CASES;
	}

	/**
	 * This method will fetch closed cases for the Technician view with solution
	 * status as Closed
	 * 
	 * @param model
	 * @param response
	 * @return Model
	 */
	@RequestMapping(value = AppConstants.GET_RXEXEC_CLOSED_CASES)
	public String getClosedRxCases(final Model model,
			final HttpServletResponse response, final HttpServletRequest request)
			throws Exception {
		response.setContentType(AppConstants.TEXT_HTML);
		request.setAttribute(AppConstants.FILTERFLAG,
				EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG)));
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);

		final OpenCasesBean openCaseBean = new OpenCasesBean();
		final CaseResponseVO objCaseResponseVO = new CaseResponseVO();
		List<CaseResponseVO> listCaseResponseVO = new ArrayList<CaseResponseVO>();
		int closedRxLookBackDays=0;
		try {
			/* For timezone issue */
			final String defaultTimezone = (String) request
					.getAttribute(AppConstants.DEFAULT_TIMEZONE);
			String applicationTimezone = RMDCommonUtil.getTimezone(
					defaultTimezone, userVO.getTimeZone());
			/* For timezone issue */
			openCaseBean.setUserLanguage(userVO.getStrUserLanguage());
			openCaseBean.setTimeZone(applicationTimezone);
			openCaseBean.setCustomerId(userVO.getCustomerId());
			if (null != userVO.getProducts() && !userVO.getProducts().isEmpty()) {
				openCaseBean.setProducts(userVO.getProducts());
			}
			if (null != cachedService.getAllLookupValues().get(
					AppConstants.TECHNICIAN_CLOSEDRX_LOOKBACK_DAYS_DEFAULT)) {
				closedRxLookBackDays = RMDCommonUtility
						.convertObjectToInt(cachedService
								.getAllLookupValues()
								.get(AppConstants.TECHNICIAN_CLOSEDRX_LOOKBACK_DAYS_DEFAULT)
								.get(0).getLookupValue());
			}			
			openCaseBean.setClosedRxLookBackDays(closedRxLookBackDays);
			Map<String, String> componentList = new HashMap<String, String>();
			componentList.put(
					AppConstants.RX_FILTER_URGENCY_TECHCASES_CLOSED_PRIVILEGE,
					AppConstants.RX_FILTER_URGENCY);
			componentList
					.put(AppConstants.RX_FILTER_ESTREPTIME_TECHCASES_CLOSED_PRIVILEGE,
							AppConstants.RX_FILTER_ESTREPTIME);
			componentList.put(
					AppConstants.RX_FILTER_TITLES_TECHNICIAN_CLOSED_PRIVILEGE,
					AppConstants.RX_FILTER_APPROVEDRXTITLES);
			componentList.put(
					AppConstants.FILTER_CASETYPE_TECHNICIAN_CLOSED_PRIVILEGE,
					AppConstants.RX_FILTER_CASETYPE);
			componentList.put(
					AppConstants.RX_FILTER_FLEET_TECHCASES_CLOSED_PRIVILEGE,
					AppConstants.RX_FILTER_FLEET);
			componentList.put(
					AppConstants.RX_FILTER_MODEL_TECHCASES_CLOSED_PRIVILEGE,
					AppConstants.RX_FILTER_MODEL);
			componentList.put(
					AppConstants.DEFAULT_FILTER_TECHNICIAN_CLOSED_PRIVILEGE,
					AppConstants.DEFAULT_FILTER);
			componentList
					.put(AppConstants.RX_FILTER_ACTIONABLE_RXTYPE_TECHCASES_CLOSED_PRIVILEGE,
							AppConstants.RX_FILTER_ACTIONABLE_RXTYPE);
			componentList
					.put(AppConstants.RX_FILTER_LOOKBACK_DAYS_TECHCASES_CLOSED_PRIVILEGE,
							AppConstants.RX_FILTER_LOOKBACK_DAYS);
			// method call to get the enabled components for logged in user
			getComponentPrivilege(componentList, userVO, request);
			// Added for favorite filter story
			Map<String, Object> componentMap = new HashMap<String, Object>();
			componentMap.put(AppConstants.URGENCY_FAV_FILTER,
					request.getAttribute(AppConstants.RX_FILTER_URGENCY));
			componentMap.put(AppConstants.EST_REPAIR_TIME,
					request.getAttribute(AppConstants.RX_FILTER_ESTREPTIME));
			componentMap.put(AppConstants.RX_TITLE, request
					.getAttribute(AppConstants.RX_FILTER_APPROVEDRXTITLES));
			componentMap.put(AppConstants.COMPONENT_CASE_TYPE,
					request.getAttribute(AppConstants.RX_FILTER_CASETYPE));
			componentMap.put(AppConstants.COMPONENT_FLEET,
					request.getAttribute(AppConstants.RX_FILTER_FLEET));
			componentMap.put(AppConstants.COMPONENT_MODEL,
					request.getAttribute(AppConstants.RX_FILTER_MODEL));
			componentMap.put(AppConstants.RX_ACTIONABLE_TYPE, request
					.getAttribute(AppConstants.RX_FILTER_ACTIONABLE_RXTYPE));
			componentMap.put(AppConstants.RX_LOOKBACK_DAYS,
					request.getAttribute(AppConstants.RX_FILTER_LOOKBACK_DAYS));
			componentMap.put(AppConstants.ASSETNUM, true);
			componentMap.put(AppConstants.CASEID, true);
			

			String favoriteFilters = getFavoriteFilters(
					AppConstants.CLOSED_RX_TAB, userVO, componentMap);
			if (null != favoriteFilters
					&& !favoriteFilters.equals(AppConstants.EMPTY_STRING)
					&& (Boolean) request
							.getAttribute(AppConstants.DEFAULT_FILTER)) {
				request.setAttribute(AppConstants.FAVORITE_FILTER,
						favoriteFilters);
			} 
			/*else {
				if (null != userVO.getProducts()
						&& !userVO.getProducts().isEmpty()) {
					listCaseResponseVO = solutionExecutionService.getCases(
							AppConstants.QUEUE_DELIVERED,
							AppConstants.STATUS_CLOSED, openCaseBean,
							objCaseResponseVO);
				}
				model.addAttribute(AppConstants.TECHCASESBEAN,
						listCaseResponseVO);
			}*/
			request.setAttribute(
					AppConstants.TECHNICIAN_CLOSEDRX_LOOKBACK_DAYS_DEFAULT,
					closedRxLookBackDays);
			// Added for favorite filter story
			request.setAttribute(AppConstants.SELECTED_TAB,
					AppConstants.CLOSED_RX_TAB);
			// adding for pagination
			request.setAttribute(
					AppConstants.TECHNICIAN_DEFAULT_RECORDS,
					findNumberOfRecords(AppConstants.TECHNICIAN_TABLE_DEFAULT_RECORDS));
		} catch (Exception ex) {
			RMDWebErrorHandler.handleException(ex);
		}

		return AppConstants.TECHNICIAN_CLOSED_CASES;
	}
	
	@RequestMapping(value = AppConstants.GET_RX_EXEC_RXCASEID, method = RequestMethod.GET)
	public String getSolutionExecDetailsForRxCaseID(
			@RequestParam(AppConstants.RXCASE_ID) final String rxcaseId,
			@RequestParam(AppConstants.CUSTOMER_ID) final String customerId,
			final Model model, final HttpServletResponse response,
			final HttpServletRequest request) throws RMDWebException, Exception {
		
		String caseId = null, urgency = null, estmRepairTime = null, locomotiveImpact = null;
		String delvDate = null, age = null, assetNumber = null, assetGrpName = null;	
		
		response.setContentType(AppConstants.TEXT_HTML);
		final HttpSession session = request.getSession(false);
		String locationName = null;
		String rxEXSubmitionPrivlege = null;
		boolean rxLocDropdownPrivilege = false;
		boolean rxEXSubmitionPrivilege = false;
		final String delvAge;
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		OpenCasesBean openCaseBean = new OpenCasesBean();
		
		final String defaultTimezone = (String) request
			.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		/* For timezone issue */
		openCaseBean.setUserLanguage(userVO.getStrUserLanguage());
		openCaseBean.setTimeZone(applicationTimezone);

		CaseResponseVO objCaseResponseVO = new CaseResponseVO();
		List<CaseResponseVO> listCaseResponseVO = new ArrayList<CaseResponseVO>();
		openCaseBean.setRxCaseId(rxcaseId);
		openCaseBean.setCustomerId(customerId);
		listCaseResponseVO = solutionExecutionService.getCases(
				AppConstants.QUEUE_DELIVERED,
				AppConstants.SOLUTION_STATUS_VALUE, openCaseBean,
				new CaseResponseVO());
		if (listCaseResponseVO != null && listCaseResponseVO.size() > 0) {
			objCaseResponseVO = listCaseResponseVO.get(0);
			
			caseId = objCaseResponseVO.getCaseId();
			urgency = objCaseResponseVO.getTechCaseDetail().get(0).getUrgency();
			estmRepairTime = objCaseResponseVO.getTechCaseDetail().get(0).getEstmRepairTime();
			locomotiveImpact = objCaseResponseVO.getTechCaseDetail().get(0).getLocomotiveImpact();
			delvDate = objCaseResponseVO.getTechCaseDetail().get(0).getSolutionDelvDate();
			age = objCaseResponseVO.getAge();
			assetNumber = objCaseResponseVO.getAssetNumber();
			assetGrpName = objCaseResponseVO.getAssetGrpName();
		} else {
			throw new Exception("RxCaseID is invalid.");
		}
		openCaseBean.setCaseId(rxcaseId);
		
		openCaseBean.setTimeZone(applicationTimezone);
		openCaseBean.setLanguage(userVO.getStrUserLanguage());
		final SolutionExecutionResponseVO solutionExecutionResponseVO = solutionExecutionService
				.getSolutionExecutionDetails(openCaseBean);
		solutionExecutionResponseVO.setCaseID(caseId);
		solutionExecutionResponseVO.setSolutionCaseID(rxcaseId);
		solutionExecutionResponseVO
				.setStrRxExecutionId(solutionExecutionResponseVO
						.getSolutionExecutionID());
		solutionExecutionResponseVO.setOwner(customerId);
		solutionExecutionResponseVO.setAssetGrpName(assetGrpName);
		solutionExecutionResponseVO.setUrgency(urgency);
		solutionExecutionResponseVO.setEstmRepairTime(estmRepairTime);
		solutionExecutionResponseVO.setLocomotiveImpact(locomotiveImpact);
		solutionExecutionResponseVO.setDelvDate(delvDate);
		solutionExecutionResponseVO.setAge(age);
		
		if (delvDate !=null && !AppConstants.EMPTY_STRING.equals(delvDate)) {
			DateFormat formatter = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
			formatter.setTimeZone(TimeZone.getTimeZone(openCaseBean.getTimeZone()));
			GregorianCalendar objGregorianCalendar = new GregorianCalendar();
			objGregorianCalendar.setTime(formatter.parse(delvDate));
			delvAge = RMDCommonUtil
					.calculateAge(objGregorianCalendar, new GregorianCalendar(),openCaseBean.getTimeZone());		
			solutionExecutionResponseVO.setAge(delvAge);	
		}
	    
		// Added for Add location for RX_EX Screen implementation:start
		locationName = authService
				.getLookUpValueForName(AppConstants.RXEX_LOCATION);
		rxEXSubmitionPrivlege = authService
				.getLookUpValueForName(AppConstants.RXEX_PRIVILEGE);
		rxLocDropdownPrivilege = RMDCommonUtil.componentValue(
				userVO.getComponentList(), locationName);
		rxEXSubmitionPrivilege = RMDCommonUtil.componentValue(
				userVO.getComponentList(), rxEXSubmitionPrivlege);
	
		openCaseBean.setUserLanguage(userVO.getStrUserLanguage());
		openCaseBean.setCustomerId(customerId);
		try {
			List<LocationVO> listLocationVO = solutionExecutionService
					.getRXEXLocations(openCaseBean);
			solutionExecutionResponseVO.setLocationVOList(listLocationVO);
		} catch (Exception e) {
			RMDWebErrorHandler.handleException(e);
		}
		solutionExecutionResponseVO.setAssetNumber(assetNumber);
		request.setAttribute(AppConstants.RX_LOCATION_DROPDOWN_PRIVILEGES_VAR,
				rxLocDropdownPrivilege);
		request.setAttribute(AppConstants.RXEX_SUBMITION_PRIVILEGE,
				rxEXSubmitionPrivilege);
		// Added for Add location for RX_EX Screen implementation:start
		model.addAttribute("solutionExecution", solutionExecutionResponseVO);
		model.addAttribute("userName", userVO.getStrUserName());
		model.addAttribute("timezoneval", userVO.getTimeZone());

		return AppConstants.VIEW_RX_EXEC_DETAIL;
	}

	/**
	 * This method will fetch the Solution execution Details for a Case Request
	 * params got from the cases page would be passed to RxExecution details
	 * Page for display purpose
	 * 
	 * @param rxCaseId
	 * @param model
	 * @param response
	 * @param request
	 * @return String
	 * @throws Exception
	 * @throws RMDWebException
	 */
	@RequestMapping(value = AppConstants.GET_RX_EXEC, method = RequestMethod.GET)
	public String getSolutionExecutionDetails(
			@RequestParam(AppConstants.WS_PARAM_CASEID_2) final String caseId,
			@RequestParam(AppConstants.RXCASE_ID) final String rxcaseId,
			@RequestParam(AppConstants.OWNER) final String owner,
			@RequestParam(AppConstants.CREATCASE_WSPARAM_URGENCY) final String urgency,
			@RequestParam(AppConstants.ESTMREPAIR_TIME) final String estmRepairTime,
			@RequestParam(AppConstants.LOCOMOTIVE_IMPACT) final String locomotiveImpact,
			@RequestParam(AppConstants.DELVDATE) final String delvDate,
			@RequestParam(AppConstants.AGE) final String age,
			@RequestParam(AppConstants.ASSETNUMBER) final String assetNumber,
			@RequestParam(AppConstants.ASSET_GROUP_NAME) final String assetGrpName,
			final Model model, final HttpServletResponse response,
			final HttpServletRequest request) throws RMDWebException, Exception {
		response.setContentType(AppConstants.TEXT_HTML);
		final HttpSession session = request.getSession(false);
		String locationName = null;
		String rxEXSubmitionPrivlege = null;
		boolean rxLocDropdownPrivilege = false;
		boolean rxEXSubmitionPrivilege = false;
		final String delvAge;
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		OpenCasesBean openCaseBean = new OpenCasesBean();
		openCaseBean.setCustomerId(owner);
		openCaseBean.setCaseId(rxcaseId);
		
		
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(
				defaultTimezone, userVO.getTimeZone());
		openCaseBean.setTimeZone(applicationTimezone);
		
		
		openCaseBean.setLanguage(userVO.getStrUserLanguage());
		final SolutionExecutionResponseVO solutionExecutionResponseVO = solutionExecutionService
				.getSolutionExecutionDetails(openCaseBean);
		solutionExecutionResponseVO.setCaseID(caseId);
		solutionExecutionResponseVO.setSolutionCaseID(rxcaseId);
		solutionExecutionResponseVO
				.setStrRxExecutionId(solutionExecutionResponseVO
						.getSolutionExecutionID());
		solutionExecutionResponseVO.setOwner(owner);
		solutionExecutionResponseVO.setAssetGrpName(assetGrpName);
		solutionExecutionResponseVO.setUrgency(urgency);
		solutionExecutionResponseVO.setEstmRepairTime(estmRepairTime);
		solutionExecutionResponseVO.setLocomotiveImpact(locomotiveImpact);
		solutionExecutionResponseVO.setDelvDate(delvDate);
		solutionExecutionResponseVO.setAge(age);
		
		if(delvDate !=null && !AppConstants.EMPTY_STRING.equals(delvDate)){
			DateFormat formatter = new SimpleDateFormat(RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
			if (cachedService.getSDCustLookup().get(userVO.getCustomerId()) != null
					&& cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat() != null
					&& !cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat().trim().equals("")) {
				formatter = new SimpleDateFormat(cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat());
				request.setAttribute("dateFormat", cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat());
				request.setAttribute("dateFmtDay", cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat().split(" ")[0]);
			} else {
				request.setAttribute("dateFormat", AppConstants.DATE_FORMAT_24HRS);
				request.setAttribute("dateFmtDay", AppConstants.DATE_FORMAT_24HRS.split(" ")[0]);
			}
			formatter.setTimeZone(TimeZone.getTimeZone(openCaseBean.getTimeZone()));
			GregorianCalendar objGregorianCalendar = new GregorianCalendar();
			objGregorianCalendar.setTime(formatter.parse(delvDate));
			delvAge = calculateAge(objGregorianCalendar, new GregorianCalendar(),openCaseBean.getTimeZone());		
			solutionExecutionResponseVO.setAge(delvAge);	
		}
	    
		// Added for Add location for RX_EX Screen implementation:start
		locationName = authService
				.getLookUpValueForName(AppConstants.RXEX_LOCATION);
		rxEXSubmitionPrivlege = authService
				.getLookUpValueForName(AppConstants.RXEX_PRIVILEGE);
		rxLocDropdownPrivilege = RMDCommonUtil.componentValue(
				userVO.getComponentList(), locationName);
		rxEXSubmitionPrivilege = RMDCommonUtil.componentValue(
				userVO.getComponentList(), rxEXSubmitionPrivlege);
	
		openCaseBean.setUserLanguage(userVO.getStrUserLanguage());
		openCaseBean.setCustomerId(owner);
		try {
			List<LocationVO> listLocationVO = solutionExecutionService
					.getRXEXLocations(openCaseBean);
			solutionExecutionResponseVO.setLocationVOList(listLocationVO);
		} catch (Exception e) {
			RMDWebErrorHandler.handleException(e);
		}
		solutionExecutionResponseVO.setAssetNumber(assetNumber);
		request.setAttribute(AppConstants.RX_LOCATION_DROPDOWN_PRIVILEGES_VAR,
				rxLocDropdownPrivilege);
		request.setAttribute(AppConstants.RXEX_SUBMITION_PRIVILEGE,
				rxEXSubmitionPrivilege);
		// Added for Add location for RX_EX Screen implementation:start
		model.addAttribute("solutionExecution", solutionExecutionResponseVO);
		model.addAttribute("userName", userVO.getStrUserName());
		model.addAttribute("timezoneval", userVO.getTimeZone());

		return AppConstants.VIEW_RX_EXEC_DETAIL;
	}

	/**
	 * 
	 * @param solExeVo
	 * @param result
	 * @return String
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 * @Desription:This method for Save/Submit for Rx Execution Details for a
	 *                  case.
	 */
	@RequestMapping(value = AppConstants.SAVE_RX_EXEC, method = RequestMethod.POST)
	public @ResponseBody
	Map<String, String> saveCaseExecution(
			final @ModelAttribute(AppConstants.SOLUTION_EXECUTION) SolutionExecutionResponseVO solExeVo,
			final HttpServletRequest request) throws RMDWebException, Exception {

		String resultStr = AppConstants.FAILURE;
		Map<String, String> validationMap = null;
		try {
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			final OpenCasesBean openCaseBean = new OpenCasesBean();
			openCaseBean.setUserLanguage(userVO.getStrUserLanguage());
			openCaseBean.setUserId(userVO.getStrUserName());
			openCaseBean.setUserFirstName(userVO.getStrFirstName());
			openCaseBean.setUserLastName(userVO.getStrLastName());
			solExeVo.setEndUserScoring(request.getParameter(AppConstants.END_SCORING_FLAG));
			solExeVo.setUserSeqId(userVO.getUsrUsersSeqId().toString());
			validationMap = validateUserInputForSolutionExecution(solExeVo);
			if(null != validationMap &&	 validationMap.size()>0){
				return validationMap;
			}
			else if (solExeVo.getRxCloseFlag().equalsIgnoreCase(
					AppConstants.RXCASE_SUBMIT_FLAG)) {

				solutionExecutionService.submitSolutionExecutionDetails(
						solExeVo, openCaseBean);
				// Rx Case close flag set to yes will submit
				// the case to next level.
				validationMap = new HashMap<String, String>();
				validationMap.put(AppConstants.STATUS, AppConstants.SUCCESS);
			} else {

				solutionExecutionService.saveSolutionExecutionDetails(solExeVo,
						openCaseBean);// Rx Case close flag set to no will save
										// case
										// details.
				validationMap = new HashMap<String, String>();
				validationMap.put(AppConstants.STATUS, AppConstants.SUCCESS);
			}
		}

		catch (Exception ex) {
			
			LOG.error("Exception occured in saveCaseExecution method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return validationMap;
	}

	/*
	 * @param SolutionExecutionResponseVO solExeVo
	 * 
	 * @return String
	 * 
	 * @Desription:This method for downloading the PDF file for the Rx Execution
	 * Details Screen for a case.
	 */
	@RequestMapping(value = AppConstants.EXPORT_RX_EXEC, method = RequestMethod.POST)
	public String exportCaseExecutions(
			final @ModelAttribute(AppConstants.SOLUTION_EXECUTION) SolutionExecutionResponseVO solExeVo,
			final HttpServletResponse response) throws Exception {

		final String filePath = solExeVo.getSolutionFilePath() + File.separator
				+ solExeVo.getSolutionFileName();
		final File fileNew = new File(filePath);

		if (fileNew.exists()) {
			final int fSize = (int) fileNew.length();
			final byte[] fileBArray = new byte[(int) fSize];
			final FileInputStream fis = new FileInputStream(fileNew);
			fis.read(fileBArray);
			String byteArrayStr= Base64.encodeBytes(fileBArray);
			final ServletOutputStream out = response.getOutputStream();
			response.setContentType(AppConstants.APPL_PDF);
			response.setHeader(
					AppConstants.CONTENT,
					(new StringBuilder(AppConstants.ATTACH_FILENAME)).append(
							solExeVo.getSolutionFileName()).toString());
			out.write(Base64.decode(byteArrayStr), 0, (Base64.decode(byteArrayStr)).length);
			out.flush();
			out.close();
			fis.close();
		}
		return null;

	}

	/**
	 * 
	 * @param urgency
	 *            ,estRepairTime,response,request
	 * @return List<CaseResponseVO>
	 * @throws RMDWebException
	 * @Desription:This method is used to fetch the case details based on the
	 *                  urgency , estRepairTime and RxTitle selected in Filter
	 */

	@RequestMapping(value = AppConstants.GET_TECHNICIAN_CASE_DETAILS, method = RequestMethod.POST)
	public @ResponseBody
	java.util.List<CaseResponseVO> getCasesDetails(
			@RequestParam(value = KMConstants.URGENCY_REPAIR) String urgency,
			@RequestParam(value = KMConstants.ESTIMATED_REPAIR) String estRepairTime,
			@RequestParam(value = AppConstants.QUERY_PARAM_TITLE) final String title,
			@RequestParam(value = AppConstants.QUERY_PARAM_FAV_FILTER) final String favFilter,
			@RequestParam(value = AppConstants.CASE_TYPE) final String caseType,
			@RequestParam(value = AppConstants.FLEET) final String fleet,
			@RequestParam(value = AppConstants.MODEL) final String model,
			@RequestParam(value = AppConstants.RX_TYPE) final String rxType,
			@RequestParam(value = AppConstants.STATUS, required=false) final String rxStatus,
			@RequestParam(value = AppConstants.NO_OF_DAYS, required=false) final String noOfDays,
			@RequestParam(value = AppConstants.QUERY_PARAM_FILTER_CHANGED) final boolean filterChanged,
			@RequestParam(value = AppConstants.CASEID) final String caseID,
			@RequestParam(value = AppConstants.ASSETNUM) final String assetNum,
			final HttpServletResponse response, final HttpServletRequest request)
			throws RMDWebException {
		response.setContentType(AppConstants.TEXT_HTML);
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final OpenCasesBean openCaseBean = new OpenCasesBean();
		final CaseResponseVO objCaseResponseVO = new CaseResponseVO();
		/* For timezone issue */
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		/* For timezone issue */
		openCaseBean.setUserLanguage(userVO.getStrUserLanguage());
		openCaseBean.setTimeZone(applicationTimezone);
		openCaseBean.setCustomerId(userVO.getCustomerId());
		if(null!=userVO.getProducts()&& !userVO.getProducts().isEmpty()){
		openCaseBean.setProducts(userVO.getProducts());
		}
		FavoriteFilterBean favFilterBean=new FavoriteFilterBean();
		HashMap<String,String> columnTypes=new HashMap<String,String>();		
		HashMap<String,String> columnValues=new HashMap<String,String>();
		if (rxStatus != null
				&& rxStatus.equalsIgnoreCase(AppConstants.STATUS_CLOSED)) {
			favFilterBean.setScreenName(AppConstants.CLOSED_RX_TAB);
		} else {
			favFilterBean.setScreenName(AppConstants.TECHNICIAN);
		}
		Long linkUserRoleSeqId=null;
		String filterId="";
		List<CaseResponseVO> listCaseResponseVO = new ArrayList<CaseResponseVO>();
		try {
			final Map<String, String> result = validateUserInputForTechnicianCases(request,
					urgency, estRepairTime, title,caseType,fleet,model,rxType,caseID,assetNum);

			if (!result.isEmpty() && null != result) {

				objCaseResponseVO.setErrorMsg(result);
				listCaseResponseVO.add(objCaseResponseVO);

			} else {
				if (null != urgency
						&& !RMDCommonConstants.EMPTY_STRING.equals(urgency)){
					objCaseResponseVO.setUrgency(urgency);
					//Adding urgency criteria information for favorite filter
					columnTypes.put(AppConstants.URGENCY_FAV_FILTER, AppConstants.TEXT);
					columnValues.put(AppConstants.URGENCY_FAV_FILTER, urgency);
					}
				if (null != estRepairTime
						&& !RMDCommonConstants.EMPTY_STRING.equals(estRepairTime)){
					objCaseResponseVO.setEstRepairTime(estRepairTime);
					//Adding Estimated repair time criteria information for favorite filter
					columnTypes.put(AppConstants.EST_REPAIR_TIME, AppConstants.NUMBER);
					columnValues.put(AppConstants.EST_REPAIR_TIME, estRepairTime);
				}
				
				if (null != rxType
						&& !RMDCommonConstants.EMPTY_STRING.equals(rxType)&&!AppConstants.ZERO.equals(rxType)){
					objCaseResponseVO.setActionableRxType(rxType);
					//Adding rxType criteria information for favorite filter
					columnTypes.put(AppConstants.RX_TYPE_FAV_FILTER, AppConstants.NUMBER);
					columnValues.put(AppConstants.RX_TYPE_FAV_FILTER, rxType);
					}
				if (null != title
						&& !RMDCommonConstants.EMPTY_STRING.equals(title)){
					objCaseResponseVO.setSolutionTitle(title);
					//Adding RX Ids criteria information for favorite filter
					columnTypes.put(AppConstants.RX_TITLE, AppConstants.NUMBER);
					columnValues.put(AppConstants.RX_TITLE, title);
				}
				
				if (null != caseType
						&& !RMDCommonConstants.EMPTY_STRING.equals(caseType)){
					objCaseResponseVO.setCaseType(caseType);
					//Adding Case Type criteria information for favorite filter
					columnTypes.put(AppConstants.COMPONENT_CASE_TYPE, AppConstants.NUMBER);
					columnValues.put(AppConstants.COMPONENT_CASE_TYPE, caseType);
				}
				if (null != fleet
						&& !RMDCommonConstants.EMPTY_STRING.equals(fleet)){
					objCaseResponseVO.setFleet(fleet);
					//Adding Fleet criteria information for favorite filter
					columnTypes.put(AppConstants.COMPONENT_FLEET, AppConstants.NUMBER);
					columnValues.put(AppConstants.COMPONENT_FLEET, fleet);
				}
				if (null != model
						&& !RMDCommonConstants.EMPTY_STRING.equals(model)){
					objCaseResponseVO.setModel(model);
					//Adding Model criteria information for favorite filter
					columnTypes.put(AppConstants.COMPONENT_MODEL, AppConstants.NUMBER);
					columnValues.put(AppConstants.COMPONENT_MODEL, model);
				}
				if (null != noOfDays
						&& !RMDCommonConstants.EMPTY_STRING.equals(noOfDays)){
					openCaseBean.setClosedRxLookBackDays(Integer.parseInt(noOfDays));		
					//Adding no of days criteria information for favorite filter
					columnTypes.put(AppConstants.RX_LOOKBACK_DAYS, AppConstants.NUMBER);
					columnValues.put(AppConstants.RX_LOOKBACK_DAYS, noOfDays);
				}
				if (null != caseID
						&& !RMDCommonConstants.EMPTY_STRING.equals(caseID)){
					objCaseResponseVO.setCaseId(caseID);		
					//Adding no of days criteria information for favorite filter
					columnTypes.put(AppConstants.CASEID, AppConstants.TEXT);
					columnValues.put(AppConstants.CASEID, caseID);
				}
				if (null != assetNum
						&& !RMDCommonConstants.EMPTY_STRING.equals(assetNum)){
					objCaseResponseVO.setAssetNumber(assetNum);		
					//Adding no of days criteria information for favorite filter
					columnTypes.put(AppConstants.ASSETNUM, AppConstants.TEXT);
					columnValues.put(AppConstants.ASSETNUM, assetNum);
				}
				//Call generic favorite filter method if atleast one column available
				if(filterChanged){
				if (!columnTypes.isEmpty()) {
				favFilterBean.setColumnType(columnTypes);
				favFilterBean.setColumnValue(columnValues);
				}
				if(rxStatus != null && rxStatus.equalsIgnoreCase(AppConstants.STATUS_CLOSED)){
					filterId=getFilterId(AppConstants.CLOSED_RX_TAB, userVO);
				}else{
					filterId=getFilterId(AppConstants.TECHNICIAN, userVO);
				}
				favFilterBean.setFavFilterFlag(favFilter+"");
				if(null!=filterId && !filterId.equals(AppConstants.EMPTY_STRING)){
				favFilterBean.setFilterId(filterId);
				}
				linkUserRoleSeqId=getLinkUsrRoleSeqId(userVO.getRolesVOLst(),userVO.getRoleId());
				favFilterBean.setLinkUserRoleSeqId(linkUserRoleSeqId);
				callFavoriteFilter(favFilterBean);
				if(rxStatus != null && rxStatus.equalsIgnoreCase(AppConstants.STATUS_CLOSED)){
					setFavoriteFiltersToUserVO(AppConstants.CLOSED_RX_TAB,userVO,favFilterBean,favFilter+"");
				}
				else{
					setFavoriteFiltersToUserVO(AppConstants.TECHNICIAN,userVO,favFilterBean,favFilter+"");
				}
				}
				// fetching the casedetails based on the filter criteria
				if(null!=userVO.getProducts()&& !userVO.getProducts().isEmpty()){
					if(rxStatus != null && rxStatus.equalsIgnoreCase(AppConstants.STATUS_CLOSED)){
						listCaseResponseVO = solutionExecutionService.getCasesLite(
								AppConstants.QUEUE_DELIVERED,
								AppConstants.STATUS_CLOSED, openCaseBean,
								objCaseResponseVO, userVO.getCustomerId());
					} else {
						listCaseResponseVO = solutionExecutionService.getCasesLite(
								AppConstants.QUEUE_DELIVERED,
								AppConstants.SOLUTION_STATUS_VALUE, openCaseBean,
								objCaseResponseVO, userVO.getCustomerId());
					}
				}
				
			}

			final String techCasesRefreshTime = authService
					.getLookUpValueForName(AppConstants.CASES_REFRESH_TIME);
			request.setAttribute(AppConstants.TECHNICIAN_REFRESH_TIME,
					techCasesRefreshTime);
			request.setAttribute(AppConstants.TECH_CASE_ID,
					AppConstants.TECHNICIAN_CASES_VAL);
		} catch (Exception ex) {
			RMDWebErrorHandler.handleException(ex);
		}
		return listCaseResponseVO;
	}

	/**
	 * 
	 * @param request 
	 * @param urgency
	 *            ,estRepairTime
	 * @param model 
	 * @param fleet 
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Desription:This method is used to validate UserInput for Technician
	 *                  Cases
	 */
	public Map<String, String> validateUserInputForTechnicianCases(
			HttpServletRequest request, final String urgency, final String estRepairTime, String title,String caseType, String fleet, String model
			,String rxType,String caseID,String assetNum) {
		final Map<String, String> result = new HashMap<String, String>();
		try {
			if (null != urgency && !urgency.isEmpty()
					&& !urgency.equalsIgnoreCase(AppConstants.UNDEFINED)
					&& !urgency.equalsIgnoreCase(KMConstants.SELECT)) {
				// webservice call
				final Map<String, String> urgencyRepairMap = rxController
						.getUrgencyOfRepair();
				// convert map to list
				final List<String> urgencyRepairList = new ArrayList<String>(
						urgencyRepairMap.keySet());
				// input provided by user
				final List<String> userInputList = Arrays.asList(urgency
						.split(AppConstants.SPLIT_STRING_ARRAY_REGEX));

				// compare lists
				if (!AppSecUtil.compareLists(urgencyRepairList, userInputList)) {
					result.put(KMConstants.URGENCY, KMConstants.INVALID);
				}
			}
			// estimated repair time

			if (null != estRepairTime && !estRepairTime.isEmpty()
					&& !estRepairTime.equalsIgnoreCase(KMConstants.SELECT)
					&& !estRepairTime.equalsIgnoreCase(AppConstants.UNDEFINED)) {
				final Map<String, String> repairMap = rxController
						.getEstRepairTime();
				// convert map to list
				final List<String> repairList = new ArrayList<String>(
						repairMap.keySet());
				// input provided by user
				final String userInput = estRepairTime;

				if (!AppSecUtil.isListContainsValue(userInput, repairList)) {
					result.put(KMConstants.ESTIMATED_REPAIR,
							KMConstants.INVALID);
				}
			}

			if (null != title && !title.isEmpty() && rxType.isEmpty()
					&& !title.equalsIgnoreCase(KMConstants.SELECT)
					&& !title.equalsIgnoreCase(AppConstants.UNDEFINED)) {
				// webservice call
				final Map<String, String> rxTitleMap = rxController
						.getApprovedRxTitles(request);
				// convert map to list
				final List<String> rxTitleList = new ArrayList<String>(
						rxTitleMap.keySet());
				// input provided by user
				final List<String> userInputList = new ArrayList<String>(
						Arrays.asList(title.split(AppConstants.COMMA)));
				// compare lists
				if (!AppSecUtil.compareLists(rxTitleList, userInputList)) {
					result.put(AppConstants.RXTITLE, KMConstants.INVALID);
				}
			}
			
			if (null != caseType && !caseType.isEmpty()
					&& !caseType.equalsIgnoreCase(KMConstants.SELECT)
					&& !caseType.equalsIgnoreCase(AppConstants.UNDEFINED)) {
				// webservice call
				final Map<String, String> caseTypeMap = rxController
						.getCaseType();
				// convert map to list
				final List<String> caseTypeList = new ArrayList<String>(
						caseTypeMap.keySet());
				// input provided by user
				final List<String> userInputList = new ArrayList<String>(
						Arrays.asList(caseType.split(AppConstants.COMMA)));
				// compare lists
				if (!AppSecUtil.compareLists(caseTypeList, userInputList)) {
					result.put(AppConstants.ERR_CASE_TYPE, KMConstants.INVALID);
				}
			}
			if (null != fleet&& !fleet.isEmpty()
					&& !fleet.equalsIgnoreCase(KMConstants.SELECT)
					&& !fleet.equalsIgnoreCase(AppConstants.UNDEFINED)) {
				// webservice call
				final Map<String, String> fleetMap = assetOverviewController.getFleets(request);
				// convert map to list
				final List<String> fleetList = new ArrayList<String>(
						fleetMap.keySet());
				// input provided by user
				final List<String> userInputList = new ArrayList<String>(
						Arrays.asList(fleet.split(AppConstants.COMMA)));
				// compare lists
				if (!AppSecUtil.compareLists(fleetList, userInputList)) {
					result.put(AppConstants.ERR_FLEET, KMConstants.INVALID);
				}
			}
			 
			if (null != model&& !model.isEmpty()
					&& !model.equalsIgnoreCase(KMConstants.SELECT)
					&& !model.equalsIgnoreCase(AppConstants.UNDEFINED)) {
				// webservice call
				final Map<String, String> modelMap = assetOverviewController.getModelsForFilter(request);
				// convert map to list
				final List<String> modelList = new ArrayList<String>(
						modelMap.keySet());
				// input provided by user
				final List<String> userInputList = new ArrayList<String>(
						Arrays.asList(model.split(AppConstants.COMMA)));
				// compare lists
				if (!AppSecUtil.compareLists(modelList, userInputList)) {
					result.put(AppConstants.ERR_FLEET, KMConstants.INVALID);
				}
			}

		} catch (Exception exception) {
			LOG.error(KMConstants.RX_VALIDATION_MESSAGE
					+ exception.getMessage());
		}

		return result;

	}
	/**
	 * @Description:This method is used for calling the serviceImpl in turn
	 *                   which will call webservices and bring the technican
	 *                   cases related records for download for
	 * @return: void
	 * @param:HttpServletRequest request,HttpServletResponse response,Locale
	 *                           locale
	 */

	@RequestMapping(value = AppConstants.EXPORT_DATA_TECHNICIAN_CASES, method = RequestMethod.POST)
	public void exportDataTechnicianCases(final HttpServletResponse response,
			final HttpServletRequest request, final Locale locale)
			throws IOException {

		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		String urgency = RMDCommonConstants.EMPTY_STRING;
		String estRepairTime = RMDCommonConstants.EMPTY_STRING;
		String title=RMDCommonConstants.EMPTY_STRING;
		String caseType=RMDCommonConstants.EMPTY_STRING;
		String fleet=RMDCommonConstants.EMPTY_STRING;
		String model=RMDCommonConstants.EMPTY_STRING;
		String rxStatus=RMDCommonConstants.EMPTY_STRING;
		String noOfDays=RMDCommonConstants.EMPTY_STRING;
		String caseID = RMDCommonConstants.EMPTY_STRING;
		String assetNum = RMDCommonConstants.EMPTY_STRING;
		List<CaseResponseVO> listCaseResponseVO = new ArrayList<CaseResponseVO>();
		try {
			objServletOutputStream = response.getOutputStream();
			urgency = request.getParameter(AppConstants.QUERY_PARAM_URGENCY);
			estRepairTime = request
					.getParameter(AppConstants.QUERY_PARAM_ESTREPTIME);
			title = request
			.getParameter(AppConstants.QUERY_PARAM_TITLE);
			caseType=request
					.getParameter(AppConstants.ID_CASE_TYPE);
			fleet=request
					.getParameter(AppConstants.ID_FLEET);
			model=request
					.getParameter(AppConstants.ID_MODEL);
			rxStatus=request
					.getParameter(AppConstants.STATUS);
			noOfDays=request
					.getParameter(AppConstants.NO_OF_DAYS);
			caseID = request
					.getParameter(AppConstants.CASEID);
			assetNum = request
					.getParameter(AppConstants.ASSETNUM);
			listCaseResponseVO=getCasesDetails(urgency, estRepairTime, title,"",caseType,fleet,model,"",rxStatus,noOfDays,false,caseID,assetNum,response, request);

			// calling convertToCSVTechnicanCases method to convert the
			// listCaseResponseVO to comma seperated value
			csvContent = convertToCSVTechnicanCases(listCaseResponseVO, locale, rxStatus);
			response.setContentType(AppConstants.CONTENT_TYPE);
			if(AppConstants.STATUS_CLOSED.equalsIgnoreCase(rxStatus)){
				response.setHeader(AppConstants.CONTENT,
						AppConstants.ATTACH_FILENAME
								+ AppConstants.TECHNICIAN_CLOSED_RX_EXPORT_FILENAME);
			}else{
				response.setHeader(AppConstants.CONTENT,
						AppConstants.ATTACH_FILENAME
								+ AppConstants.TECHNICIAN_OPEN_RX_EXPORT_FILENAME);	
			}
			
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(objByteArrayInputStream);

			objBufferedOutputStream = new BufferedOutputStream(objServletOutputStream);

			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0, byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (Exception e) {

		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}

	/**
	 * @param rxStatus 
	 * @Description:This method is used for looping through the list of
	 *                   TechnicanCases records and will covert to csv content
	 * @return: String
	 * @param:collectiveResponse,Locale locale
	 */
	private String convertToCSVTechnicanCases(
			List<CaseResponseVO> listCaseResponseVO, Locale locale, String rxStatus) {
		StringBuffer strTechCasesBuffer = new StringBuffer();
		List<TechnicianSolutionDetailVO> listTechnicianSolutionDetail = null;
		String csvContent = null;
		try {
			if (AppConstants.STATUS_CLOSED.equalsIgnoreCase(rxStatus)) {
				strTechCasesBuffer.append(appContext.getMessage(
						AppConstants.TECHNICIAN_CLOSED_CASES_HEADER, null,
						locale));
			} else {
				strTechCasesBuffer.append(appContext.getMessage(
						AppConstants.TECHNICIAN_CASES_HEADER, null, locale));
			}
			strTechCasesBuffer.append(RMDCommonConstants.NEWLINE);
			if(RMDCommonUtility.isCollectionNotEmpty(listCaseResponseVO)){
			for (Iterator<CaseResponseVO> iterlistCaseResponse = listCaseResponseVO.iterator(); iterlistCaseResponse
					.hasNext();) {
				CaseResponseVO caseResponseVO = (CaseResponseVO) iterlistCaseResponse
						.next();
				listTechnicianSolutionDetail = caseResponseVO
						.getTechCaseDetail();
				for (Iterator<TechnicianSolutionDetailVO> iterTechSolDetail = listTechnicianSolutionDetail
						.iterator(); iterTechSolDetail.hasNext();) {
					TechnicianSolutionDetailVO objTechnicianSolutionDetailVO = (TechnicianSolutionDetailVO) iterTechSolDetail
							.next();
					strTechCasesBuffer.append(RMDCommonUtil.removeHtmlandNullValues(objTechnicianSolutionDetailVO
							.getUrgency())
							+ RMDCommonConstants.COMMMA_SEPARATOR
							+ RMDCommonUtil.removeHtmlandNullValues(objTechnicianSolutionDetailVO.getSolutionCaseID())
							+ RMDCommonConstants.COMMMA_SEPARATOR
							+ RMDCommonUtil.removeHtmlandNullValues(caseResponseVO.getAssetNumber())
							+ RMDCommonConstants.COMMMA_SEPARATOR);	
					strTechCasesBuffer.append(RMDCommonUtil.removeHtmlandNullValues(caseResponseVO.getAssetGrpName())
							+ RMDCommonConstants.COMMMA_SEPARATOR
							+ RMDCommonUtil.removeHtmlandNullValues(objTechnicianSolutionDetailVO.getSolutionStatus()));
					if (null != caseResponseVO.getRxType())
					{
					strTechCasesBuffer.append( RMDCommonConstants.COMMMA_SEPARATOR
							+ RMDCommonUtil.removeHtmlandNullValues(objTechnicianSolutionDetailVO.getSolutionTitle()+RMDCommonConstants.HYPHEN+caseResponseVO.getRxType()));
					}
					else
					{
						strTechCasesBuffer.append( RMDCommonConstants.COMMMA_SEPARATOR
								+ RMDCommonUtil.removeHtmlandNullValues(objTechnicianSolutionDetailVO.getSolutionTitle()));
					}
					
					strTechCasesBuffer.append( RMDCommonConstants.COMMMA_SEPARATOR
							+ RMDCommonUtil.removeHtmlandNullValues(objTechnicianSolutionDetailVO.getLocomotiveImpact())
							+ RMDCommonConstants.COMMMA_SEPARATOR);
					strTechCasesBuffer.append(RMDCommonUtil.removeHtmlandNullValues(caseResponseVO.getCreatedDate()));
					
					if (null != caseResponseVO.getAge()
							&& !RMDCommonConstants.EMPTY_STRING
									.equalsIgnoreCase(caseResponseVO.getAge())) {
						strTechCasesBuffer
								.append(RMDCommonConstants.BLANK_SPACE
										+ caseResponseVO.getAge());
					}
					if (null != objTechnicianSolutionDetailVO.getSolutionCloseDate()
							&& !RMDCommonConstants.EMPTY_STRING
									.equalsIgnoreCase(objTechnicianSolutionDetailVO.getSolutionCloseDate())) {
						strTechCasesBuffer
								.append(RMDCommonConstants.COMMMA_SEPARATOR
										+ RMDCommonUtil
												.removeHtmlandNullValues(objTechnicianSolutionDetailVO.getSolutionCloseDate()));
						strTechCasesBuffer
						.append(RMDCommonConstants.BLANK_SPACE
								+ objTechnicianSolutionDetailVO.getClosedDateAge());
					}
					strTechCasesBuffer.append(RMDCommonConstants.NEWLINE);
				}
				
			}
		}
			csvContent = strTechCasesBuffer.toString();
		} catch (Exception exception) {
			LOG.error("Export to CSV Tchnicna cases" + exception.getMessage());
		}
		return csvContent;
	}

	/*
	 * @Description: Function to retrieve no of days dropdown values
	 */
	@RequestMapping(value = AppConstants.GET_NO_OF_DAYS)
	public @ResponseBody
	Map<String, String> getNoOfDays(final HttpServletRequest request)
			throws RMDWebException {

		Map<String, String> result = new LinkedHashMap<String, String>();
		String listName = AppConstants.TECHNICIAN_CLOSED_RX_LOOKBACK_LIST_NAME;
		try {
			final Map<String, String> noOfDaysMap = solutionExecutionService
					.getNoOfDays(listName);
			result = SortMapValues(noOfDaysMap);
		} catch (Exception ex) {
			LOG.error(
					"RMDWebException occured in getNoOfDays() method - SolutionExecutionController",
					ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return result;
	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 * @Description * This method is used for fetching Validating Solution section inputs from user values.
	 * 
	 */

	public Map<String, String> validateUserInputForSolutionExecution(SolutionExecutionResponseVO solExeVo) {
		Map<String, String> result = new HashMap<String, String>();
		List<TaskDetailVO> taskList = null;
		Iterator<TaskDetailVO> it = null;
		TaskDetailVO tempTask = null;
		int index = 0;
		try {
			// title validations
			if(null !=solExeVo && null!=solExeVo.getTaskDetail() ){
				if(RMDCommonUtility.isSpecialCharactersFound(solExeVo.getRepairAction())){
					result.put("repairAction",AppConstants.INVALID_SPECIAL_CHARACTER);
				}
				taskList = solExeVo.getTaskDetail();
				it = taskList.iterator();
				while(it.hasNext()){
					tempTask = it.next();
					if (null != tempTask.getTaskComments()
							&& RMDCommonUtility
									.isSpecialCharactersFound(tempTask
											.getTaskComments())) {
						result.put("taskDetail" + index + "taskComments",
								AppConstants.INVALID_SPECIAL_CHARACTER);
					}
					index++;
				}
				
			}
			
		} catch (Exception exception) {
			LOG.error("Error occured in validateUserInputForRxExecution"
					+ exception.getMessage());
		}
		return result;
	}
	
	@RequestMapping(value = AppConstants.GET_DELIVER_RX_URL, method = RequestMethod.GET)
	public  @ResponseBody String
	getDeliverRxURL(final HttpServletRequest request)
			throws Exception {
		LOG
				.debug(" SolutionExecutionController: Inside getDeliverRxURL() method:::::START ");
		final String caseId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CASE_ID));
		String result = null;
		try {
			if (null != caseId
					&& !caseId
							.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {
				result = solutionExecutionService.getDeliverRxURL(caseId);
			} 
		} catch (Exception ex) {
			LOG
					.error("Exception occured in getDeliverRxURL method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}
	
	@RequestMapping(value = AppConstants.VALIDATE_URL, method = RequestMethod.POST)
	@ResponseBody public String
	validateURL(
			@RequestParam(value = AppConstants.CASE_ID) String caseID,
			@RequestParam(value = AppConstants.FILENAME) String filename,
			@RequestParam(value = AppConstants.TASK_ID) String taskId,
			final HttpServletRequest request)
			throws Exception {
		LOG
				.debug(" SolutionExecutionController: Inside validateURL() method:::::START ");
		final String caseId = EsapiUtil.stripXSSCharacters(caseID);
		final String fileName = EsapiUtil.stripXSSCharacters(filename);
		final String taskID = EsapiUtil.stripXSSCharacters(taskId);
		String result = null;
		try {
			if (null != caseId
					&& !caseId
							.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {
				result = solutionExecutionService.validateURL(caseId,fileName,taskID);
			} 
		} catch (Exception ex) {
			LOG
					.error("Exception occured in validateURL method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}
	
	private String calculateAge(final GregorianCalendar startDate,
			final GregorianCalendar endDate,String timeZone) {
		String age = AppConstants.EMPTY_STRING;
		RMDCommonUtility.setZoneOffsetTime(startDate,timeZone);
		RMDCommonUtility.setZoneOffsetTime(endDate,timeZone);

		final long startTime = startDate.getTimeInMillis();
		final long endTime = endDate.getTimeInMillis();

		// Calculate difference in milliseconds
		final long diff = endTime - startTime;

		// Difference in minutes
		final long diffMin = diff / (60 * 1000);

		// Difference in hours
		final long diffHours = diff / (60 * 60 * 1000);

		// Difference in days
		final long diffDays = diff / (24 * 60 * 60 * 1000);
		age = diffDays + AppConstants.D
				+ AppConstants.BLANK_STRING + (diffHours - (diffDays * 24))
				+ AppConstants.HRS + AppConstants.BLANK_STRING
				+ (diffMin - (diffHours * 60)) + AppConstants.MIN;
		return age;
	}
}
