package com.ge.trans.rmd.cm.valueobjects;

public class AddEditEDPDetailsVO {

	private String tempObjId;
	private String ctrlCfgObjId;
	private String ctrlCfgName;
	private String cfgFileName;
	private String paramObjId;
	private String addedParamObjId;
	private String removedParamObjId;
	private String templateNo;
	private String versionNo;
	private String status;
	private String title;
	private String whatNew;
	private String userName;
	
	public String getTempObjId() {
		return tempObjId;
	}
	public void setTempObjId(String tempObjId) {
		this.tempObjId = tempObjId;
	}
	public String getCtrlCfgObjId() {
		return ctrlCfgObjId;
	}
	public void setCtrlCfgObjId(String ctrlCfgObjId) {
		this.ctrlCfgObjId = ctrlCfgObjId;
	}
	public String getCtrlCfgName() {
		return ctrlCfgName;
	}
	public void setCtrlCfgName(String ctrlCfgName) {
		this.ctrlCfgName = ctrlCfgName;
	}
	public String getCfgFileName() {
		return cfgFileName;
	}
	public void setCfgFileName(String cfgFileName) {
		this.cfgFileName = cfgFileName;
	}
	public String getParamObjId() {
		return paramObjId;
	}
	public void setParamObjId(String paramObjId) {
		this.paramObjId = paramObjId;
	}	
	public String getAddedParamObjId() {
		return addedParamObjId;
	}
	public void setAddedParamObjId(String addedParamObjId) {
		this.addedParamObjId = addedParamObjId;
	}
	public String getRemovedParamObjId() {
		return removedParamObjId;
	}
	public void setRemovedParamObjId(String removedParamObjId) {
		this.removedParamObjId = removedParamObjId;
	}
	public String getTemplateNo() {
		return templateNo;
	}
	public void setTemplateNo(String templateNo) {
		this.templateNo = templateNo;
	}
	public String getVersionNo() {
		return versionNo;
	}
	public void setVersionNo(String versionNo) {
		this.versionNo = versionNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getWhatNew() {
		return whatNew;
	}
	public void setWhatNew(String whatNew) {
		this.whatNew = whatNew;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
	
}
