package com.ge.trans.rmd.cm.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Pattern;

import org.codehaus.jackson.map.ObjectMapper;
import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.eoa.services.security.service.valueobjects.UserServiceVO;
import com.ge.trans.rmd.alert.valueobjects.ModelVO;
import com.ge.trans.rmd.cm.valueobjects.RecommDelvDocVO;
import com.ge.trans.rmd.cm.valueobjects.RxChangeAdminTitleVO;
import com.ge.trans.rmd.cm.valueobjects.RxChangeAdminVO;
import com.ge.trans.rmd.cm.valueobjects.RxChangeSearchVO;
import com.ge.trans.rmd.cm.valueobjects.RxChangeVO;
import com.ge.trans.rmd.common.beans.RxChangeBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.AppSecUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.vo.CustomerVO;
import com.ge.trans.rmd.common.vo.HeaderSearchRespVO;
import com.ge.trans.rmd.km.service.RxService;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.alert.valueobjects.ModelsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetHeaderSearchResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetNumberResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.Customer;
import com.ge.trans.rmd.services.assets.valueobjects.UserEOADetailsResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.RxDelvDocType;
import com.ge.trans.rmd.services.rxchange.valueobjects.RxChangeAdminRequestType;
import com.ge.trans.rmd.services.rxchange.valueobjects.RxChangeAdminResponseType;
import com.ge.trans.rmd.services.rxchange.valueobjects.RxChangeOverviewRequestType;
import com.ge.trans.rmd.services.rxchange.valueobjects.RxChangeRequestType;
import com.ge.trans.rmd.services.rxchange.valueobjects.RxChangeResponseType;
import com.ge.trans.rmd.services.solutions.valueobjects.SolutionLiteResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class RxChangeServiceImpl extends RMDBaseServiceImpl implements
		RxChangeService {

	@Autowired
	WebServiceInvoker webServiceInvoker;

	private final RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	@Autowired
	private CachedService cachedService;

	@Autowired
	private RxService rxService;

	/**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for fetching rx change requests.
     */
	@Override
	public List<RxChangeVO> getRxChangeOverviewData(
			RxChangeSearchVO rxChangeSearchVO) throws RMDWebException {

		List<RxChangeVO> rxChangeVOLst = null;
		RxChangeVO rxChangeOverivewVO = null;
		try {

			RxChangeOverviewRequestType objRxChangeOverviewRequestType = new RxChangeOverviewRequestType();
			objRxChangeOverviewRequestType.setUserId(rxChangeSearchVO
					.getUserId());
			objRxChangeOverviewRequestType.setCustomerIdLst(rxChangeSearchVO
					.getCustomerIdLst());
			objRxChangeOverviewRequestType.setFromDate(rxChangeSearchVO
					.getFromDate());
			objRxChangeOverviewRequestType.setToDate(rxChangeSearchVO
					.getToDate());
			objRxChangeOverviewRequestType.setModelLst(rxChangeSearchVO
					.getModelLst());
			objRxChangeOverviewRequestType.setStatus(rxChangeSearchVO
					.getStatus());
			objRxChangeOverviewRequestType.setRxTitle(rxChangeSearchVO
					.getRxTitle());
			objRxChangeOverviewRequestType.setTypeOfChangeReq(rxChangeSearchVO
					.getTypeOfChangeReq());
			objRxChangeOverviewRequestType
					.setTypeOfChangeReqLst(rxChangeSearchVO
							.getTypeOfChangeReqLst());
			
			RxChangeResponseType[] rxChangeResponeType = (RxChangeResponseType[]) webServiceInvoker
					.post(ServiceConstants.GET_RX_CHANGE_OVERVIEW_DATA,
							objRxChangeOverviewRequestType,
							RxChangeResponseType[].class);
			if (null != rxChangeResponeType) {
				rxChangeVOLst = new ArrayList<RxChangeVO>(
						rxChangeResponeType.length);
				for (RxChangeResponseType rxChangeVO : rxChangeResponeType) {
					rxChangeOverivewVO = new RxChangeVO();
					rxChangeOverivewVO.setObjId(rxChangeVO.getObjId());
					rxChangeOverivewVO.setRequestId(rxChangeVO.getRequestId());
					rxChangeOverivewVO.setRequestOwner(rxChangeVO
							.getRequestOwner());
					rxChangeOverivewVO.setRequestor(rxChangeVO.getRequestor());
					rxChangeOverivewVO
							.setRoadNumber(rxChangeVO.getRoadNumber());
					rxChangeOverivewVO.setCaseId(rxChangeVO.getCaseId());
					rxChangeOverivewVO.setModel(rxChangeVO.getModel());
					// Date conversion from EST to UserPreferredTimezone
					if (!RMDCommonUtility.isNullOrEmpty(rxChangeVO
							.getRequestLoggedDate())) {
						rxChangeOverivewVO
								.setRequestLoggedDate(RMDCommonUtility.convertDateFormatAndTimezone(
										rxChangeVO.getRequestLoggedDate(),
										AppConstants.TO_DATE_FORMAT,
										AppConstants.TO_DATE_FORMAT,
										AppConstants.TIMEZONE_EASTERN,
										rxChangeSearchVO.getUserTimeZone()));
					}
					rxChangeOverivewVO.setStatus(rxChangeVO.getStatus());
					rxChangeOverivewVO.setTypeOfChangeReq(rxChangeVO
							.getTypeOfChangeReq());
					rxChangeOverivewVO.setChangesSuggested(EsapiUtil
							.resumeSpecialChars(ESAPI.encoder().decodeForHTML(
									rxChangeVO.getChangesSuggested())));
						
					if(!RMDCommonUtility.isNullOrEmpty(rxChangeVO.getNotes())){
					rxChangeOverivewVO.setNotes(EsapiUtil
							.resumeSpecialChars(ESAPI.encoder().decodeForHTML(
									rxChangeVO.getNotes())));
					}
					
					rxChangeOverivewVO.setRxTitle(rxChangeVO.getRxTitle());
					rxChangeOverivewVO.setCustomer(rxChangeVO.getCustomer());
					rxChangeOverivewVO.setRevisionType(rxChangeVO
							.getRevisionType());
					rxChangeOverivewVO
							.setRoadNumber(rxChangeVO.getRoadNumber());
					rxChangeOverivewVO
							.setAttachment(rxChangeVO.getAttachment());
					rxChangeOverivewVO.setFileName(rxChangeVO.getFileName());
					rxChangeOverivewVO.setFilePath(rxChangeVO.getFilePath());
					rxChangeOverivewVO.setUserName(rxChangeVO.getUserName());
					rxChangeOverivewVO.setSaveAsDraftFlag(rxChangeVO
							.getSaveAsDraftFlag());
					rxChangeOverivewVO.setRxChangeProcObjId(rxChangeVO
							.getRxChangeProcObjId());
					rxChangeOverivewVO.setRequestOwnerSSO(rxChangeVO
							.getRequestOwnerSSO());
					rxChangeOverivewVO.setWhitePaperPdffileName(rxChangeVO.getWhitePaperPdffileName());
					rxChangeOverivewVO.setWhitePaperPdffilePath(rxChangeVO.getWhitePaperPdffilePath());
					rxChangeOverivewVO.setRecomObjId(rxChangeVO.getRecomObjId());
					if(!RMDCommonUtility.isNullOrEmpty(rxChangeVO.getNotestoRequestor())){
					rxChangeOverivewVO.setNotestoRequestor(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(rxChangeVO
							.getNotestoRequestor())));
					}
					
					List<RxChangeVO> rxchangeAuditInfoLst = new ArrayList<RxChangeVO>();
					List<String>rxChangeAuditStrLst  = new ArrayList<String>();
					if(null != rxChangeVO.getRxchangeAuditInfoLst() && !rxChangeVO.getRxchangeAuditInfoLst().isEmpty()){
	                for(RxChangeResponseType tempRxChangeVO : rxChangeVO.getRxchangeAuditInfoLst()){
	                    RxChangeVO tempRxChangeResponseType = new RxChangeVO();
	                    tempRxChangeResponseType.setStatus(tempRxChangeVO.getStatus());
	                    tempRxChangeResponseType.setRequestLoggedDate(tempRxChangeVO.getRequestLoggedDate());
	                    tempRxChangeResponseType.setUserName(tempRxChangeVO.getUserName()); 
	                    if(!RMDCommonUtility.isNullOrEmpty(tempRxChangeVO.getNotes())){
	                    tempRxChangeResponseType.setNotes(tempRxChangeVO.getNotes());
	                    }else{
	                        tempRxChangeResponseType.setNotes(RMDCommonConstants.EMPTY_STRING); 
	                    }
	                    
	                    ObjectMapper mapperObj = new ObjectMapper();	                   
	                        // get Employee object as a json string
	                    String jsonStr = mapperObj.writeValueAsString(tempRxChangeResponseType);
	                    logger.debug(jsonStr);
	                    rxchangeAuditInfoLst.add(tempRxChangeResponseType);
	                    rxChangeAuditStrLst.add(jsonStr);
	                }
					}
	                rxChangeOverivewVO.setRxchangeAuditInfoLst(rxchangeAuditInfoLst);
	                rxChangeOverivewVO.setRxChangeAuditStrLst(rxChangeAuditStrLst);
					rxChangeVOLst.add(rxChangeOverivewVO);
				}
			}

        } catch (RMDWebException rmdEx) {
            logger.error("RMDWebException occured in getRxChangeOverviewData() method ", rmdEx);
            throw rmdEx;
        } catch (Exception ex) {
            logger.error("Excpetion occured in getRxChangeOverviewData() method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
		return rxChangeVOLst;
	}

	/**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for fetching the user details based on fname/lname/SSO.
     */
	@Override
	public Map<String, String> getRequestorDetails(String fName, String lName,
			String userId) throws  RMDWebException {
		Map<String, String> requestorMap = new LinkedHashMap<String, String>();
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();

		try {
			pathParams.put(AppConstants.FIRST_NAME, fName);
			pathParams.put(AppConstants.LAST_NAME, lName);
			pathParams.put(AppConstants.WS_PARAM_USER_ID, userId);

			SolutionLiteResponseType[] assetResponses = (SolutionLiteResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_RXCHANGE_REQUESTORS, null,
							pathParams, null, SolutionLiteResponseType[].class);

			if (assetResponses != null && assetResponses.length > 0) {

				for (int i = 0; i < assetResponses.length; i++) {

					requestorMap.put(assetResponses[i].getSolutionId(),
							assetResponses[i].getSolutionTitle());
				}

			}

		} catch (RMDWebException e) {
			logger.error("RxChangeServiceImpl :: Exception occured in getRequestorDetails() method "
					+ e.getMessage());
			throw e;

		} catch (Exception ex) {
			logger.error("Exception occured in getRequestorDetails method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return requestorMap;
	}
	
	/**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for fetching the lookup values for the list name.
     */

	@Override
	public Map<String, String> getRxChangeLookUp(String listName)
			throws  RMDWebException {
		Map<String, String> lookUpMapResult = new LinkedHashMap<String, String>();
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		Map<String, List<ApplicationParametersResponseType>> lookUpMap = new TreeMap<String, List<ApplicationParametersResponseType>>();

		try {
			pathParams.put(AppConstants.LOOKUP_NAME, listName);

			lookUpMap = cachedService.getAllLookupValues();

			if (null != lookUpMap && !lookUpMap.isEmpty()
					&& null != lookUpMap.get(listName)) {
				for (ApplicationParametersResponseType objModelVO : lookUpMap
						.get(listName)) {
					lookUpMapResult.put(
							String.valueOf(objModelVO.getSysLookupSeqId()),
							objModelVO.getLookupValue());
				}
			}
		} catch (RMDWebException e) {
			logger.error("RxChangeServiceImpl :: Exception occured in getRxChangeLookUp() method "
					+ e.getMessage());
			throw e;

		} catch (Exception ex) {
			logger.error("RxChangeServiceImpl :: Exception occured in getRxChangeLookUp() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lookUpMapResult;
	}

	/**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for fetching the Customer values for
     *               particular User.
     */
	@Override
	public Map<String, String> getCustomerDetails(String userID)
			throws RMDWebException {
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		Map<String, String> customerMap = new LinkedHashMap<String, String>();
		String[] strUserVal = null;

		try {
			if (userID != null) {
				strUserVal = (userID.split(AppConstants.UNDERSCORE));
			}
			
            if (null != strUserVal) {
                pathParams.put(AppConstants.WS_PARAM_USER_ID, strUserVal[0]);

                Customer[] customer = (Customer[]) webServiceInvoker.get(ServiceConstants.GET_USER_CUSTOMERS,
                        pathParams, null, null, Customer[].class);

                for (int i = 0; i < customer.length; i++) {
                    customerMap.put(customer[i].getCustomerSeqId() + "_" + customer[i].getCustomerID(),
                            customer[i].getCustomerName());
                }
            }
        } catch (RMDWebException e) {
            if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
                logger.error("RxChangeServiceImpl :: No records found for getCustomers() service " + e.getMessage());
            } else {
                logger.error("RxChangeServiceImpl :: Exception occured in getCustomers() method " + e.getMessage());
                throw e;
            }
        } catch (Exception ex) {
            logger.error("Exception occured in getCustomers method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }

        return customerMap;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:GenericAjaxException,RMDWebException
	 * @Description: This method is used for fetching the Model values for
	 *               particular Customer.
	 */
	@Override
	public Map<String, String> getModelDetails(String customerId)
			throws RMDWebException {
		Map<String, ArrayList<ModelVO>> modelMap = new TreeMap<String, ArrayList<ModelVO>>();
		Map<String, String> modelList = null;
		Map<String, String> uniqueModelList = null;
		String[] customerIdLst = null;
		String customerIdVal = null;

		try {
			modelMap = cachedService.getAllModels();
			modelList = new TreeMap<String, String>();
			uniqueModelList = new TreeMap<String, String>();
			if (!RMDCommonUtility.isNullOrEmpty(customerId)) {
				customerIdLst = (customerId.split(AppConstants.COMMA));
			}
			/**
	    	    * Fixing DE85985 UAT issue Ben Rx Change Request : Overview and Details screen implementation changes
	    	 */			
			else
				customerIdLst=null;

			if (customerIdLst != null) {
				for (String strCust : customerIdLst) {
					customerIdVal = (strCust.split(AppConstants.UNDERSCORE))[1];
					if (null != modelMap && !modelMap.isEmpty()
							&& null != modelMap.get(customerIdVal)) {
						for (ModelVO objModelVO : modelMap.get(customerIdVal)) {
							modelList.put(objModelVO.getModelName(),
									objModelVO.getModelGeneral());
						}
					}
				}
			}
			/**
	    	    * Fixing DE85985 UAT issue Ben Rx Change Request : Overview and Details screen implementation changes
	    	    */
			else{
				if (null != modelMap && !modelMap.isEmpty()){
					for (Map.Entry<String, ArrayList<ModelVO>> mapEntry : modelMap.entrySet()) {
						List<ModelVO> modelVOLst = mapEntry.getValue();
						for(ModelVO modelObj: modelVOLst){
							modelList.put(modelObj.getModelName(),
									modelObj.getModelGeneral());
						}
					}					
				}
			}

			if (null != modelList && !modelList.isEmpty()) {
				for (Map.Entry<String, String> entry : modelList.entrySet()) {
					String key = entry.getKey();
					String value = entry.getValue();
					uniqueModelList.put(value, key);
				}
				modelList = new TreeMap<String, String>();
				for (Map.Entry<String, String> entry : uniqueModelList
						.entrySet()) {
					String key = entry.getKey();
					String value = entry.getValue();
					modelList.put(value, key);
				}
			}
		} catch (Exception rmdEx) {
            logger.error("RMDWebException occured in getModelDetails() method - RxChangeServiceImpl", rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
		}
		return modelList;
	}

	/**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for fetching the Rx title for the matching text.
     */
	@Override
	public Map<String, String> getRxTitles(String searchVal, String modelId)
			throws  RMDWebException {
		Map<String, String> rxTitleMap = new LinkedHashMap<String, String>();
		final Map<String, String> queryParamMap = new HashMap<String, String>();
		int responseLength;

		try {
			queryParamMap.put(AppConstants.SEARCH_VAL, searchVal);
			queryParamMap.put(AppConstants.MODEL_ID, modelId);
			SolutionLiteResponseType[] rxTitleResponses = (SolutionLiteResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_RXCHANGE_RX_TITLE, null,
							queryParamMap, null,
							SolutionLiteResponseType[].class);

			if (rxTitleResponses != null && rxTitleResponses.length > 0) {				
				for (int i = 0; i < rxTitleResponses.length; i++) {

					rxTitleMap.put(rxTitleResponses[i].getSolutionId(),
							EsapiUtil.escapeSpecialChars(rxTitleResponses[i]
									.getSolutionTitle()));
				}
			} else {
				responseLength = 0;
				rxTitleMap.put(AppConstants.ASSET_RESPONSE_LENGTH,
						Integer.toString(responseLength));
			}
		} catch (RMDWebException e) {
			logger.error("RxChangeServiceImpl :: Exception occured in getRxTitles() method "
					+ e.getMessage());
			throw e;

		} catch (Exception ex) {
			logger.error("Exception occured in getRxTitles method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return rxTitleMap;
	}
	/**
     * @Author:
     * @param:
     * @return:boolean
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for validating caseid.
     */
	@Override
	public boolean getCaseId(String userId, String searchString)
			throws RMDWebException {
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		String result = null;

		try {
			queryParamMap.put(AppConstants.USER_ID, userId);
			queryParamMap.put(AppConstants.SEARCH_VAL, searchString);
			result = (String) webServiceInvoker.get(
					ServiceConstants.GET_RXCHANGE_USER_CASES, null,
					queryParamMap, null, String.class);
		} catch (Exception rmdEx) {
			logger.error(
					"RMDWebException occured in getCaseId() method - RxChangeServiceImpl",
					rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return RMDCommonConstants.TRUE_STRING.equalsIgnoreCase(result);
	}

	/**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for fetching road numbers based on the customer id and model id.
     */
	@Override
	public Map<String, String> getRoadNumbers(String customerId,
			String modelId, String searchString) throws 
			RMDWebException {
		final HeaderSearchRespVO headerResponseVO = new HeaderSearchRespVO();

		Map<String, String> roadNumberMap = new HashMap<String, String>();
		AssetHeaderSearchResponseType[] assetResponses = null;
		int responseLength;
		String[] customerIdLst = null;
		StringBuilder resultStr = new StringBuilder();

		try {
			AssetsRequestType objAssetsReqType = new AssetsRequestType();

			if (customerId != null) {
				customerIdLst = (customerId.split(AppConstants.COMMA));
				if (customerIdLst != null) {
					for (String strCust : customerIdLst) {
						resultStr.append((strCust
								.split(AppConstants.UNDERSCORE))[1]);
						resultStr.append(AppConstants.COMMA);
						resultStr.append(AppConstants.EMPTY_STRING);
					}
				}
				if (!(AppConstants.EMPTY_STRING).equals(resultStr.toString()))
					objAssetsReqType.setCustomerId(resultStr.substring(0,
							resultStr.lastIndexOf(AppConstants.COMMA)));
			}
			
			objAssetsReqType.setModelId(modelId);
			objAssetsReqType.setAssetNumberLike(searchString);

			assetResponses = (AssetHeaderSearchResponseType[]) webServiceInvoker
					.post(ServiceConstants.GET_ASSETS_HEADER, objAssetsReqType,
							AssetHeaderSearchResponseType[].class);
			
			System.out.println("assetResponses :: "+assetResponses);

			if (assetResponses != null && assetResponses.length > 0) {
			    System.out.println("in if"+assetResponses);
				for (int i = 0; i < assetResponses.length; i++) {				    
					roadNumberMap.put(assetResponses[i].getVehicleObjId(),
					        assetResponses[i].getCustomerID() + "-"
									+ assetResponses[i].getAssetNumber());
				}

			} else {
			    System.out.println("in else"+assetResponses);
				responseLength = 0;
				roadNumberMap.put("","");
				headerResponseVO.setResponseLength(roadNumberMap);
			}
        } catch (RMDWebException rmdEx) {
            logger.error("RMDWebException occured in RxChangeServiceImpl() getAssetsData method ", rmdEx);
            headerResponseVO.setResponseLength(roadNumberMap);
        } catch (Exception ex) {
            logger.error("Exception occured in HeaderSearchServiceImpl() method getAssetsData", ex);
        }
		return roadNumberMap;
	}

	/**
	 * @Author:
	 * @param : RxChangeBean
	 * @return : String
	 * @Description: This method will persist Rx Change request data to the database
	 */
	@Override
	public String saveRxChangeReqDetails(final RxChangeBean rxChangeBean)
			throws  RMDWebException {

		final RxChangeRequestType rxChangeType = new RxChangeRequestType();
		Map<String, String> pdfDistListMap = null;
		Map<String, String> lookUpMap = null;
		String returnString = null;
		String pdfDistList = null;
		String triggerLogicNote = null;
		try {
			rxChangeType.setAdminEmailIdLst(getAdminEmailIdStr());
			pdfDistListMap = getRxChangeLookUp(RMDCommonConstants.RX_CHANGE_PDF_DISTRIBUTION_LIST);
			if(pdfDistListMap != null){
			    for (Map.Entry<String, String> entry : pdfDistListMap.entrySet()) {
			        pdfDistList = entry.getValue();
			    }
			}
			
			rxChangeType.setPdfEmailIdList(pdfDistList);
			
			lookUpMap = getRxChangeLookUp(RMDCommonConstants.RX_CHANGE_TRIGGER_LOGIC_NOTE);
            if(lookUpMap != null){
                for (Map.Entry<String, String> entry : lookUpMap.entrySet()) {
                    triggerLogicNote = entry.getValue();
                }
            }
            
            rxChangeType.setTriggerLogicNote(triggerLogicNote);
			
			if (!RMDCommonUtility.isNullOrEmpty(rxChangeBean.getObjId())) {
				rxChangeType.setObjId(rxChangeBean.getObjId());
				if(!RMDCommonUtility.isNullOrEmpty(rxChangeBean.getNotes())) {
				rxChangeType.setNotes(AppSecUtil.htmlEscaping(rxChangeBean.getNotes()));
				}
				rxChangeType.setStatus(rxChangeBean.getStatus());
				rxChangeType.setStatusObjId(rxChangeBean.getStatusObjId());
				rxChangeType.setRequestOwner(rxChangeBean.getRequestOwner());
				if(!RMDCommonUtility.isNullOrEmpty(rxChangeBean.getChangesSuggested())){
	                rxChangeType.setChangesSuggested(AppSecUtil.htmlEscaping(rxChangeBean
	                        .getChangesSuggested()));
	                }
	                
	                rxChangeType.setUserId(rxChangeBean.getUserId());
				returnString = (String) webServiceInvoker.post(
						ServiceConstants.SAVE_EDIT_RX_CHANGE_DETAILS,
						rxChangeType, String.class);
			} else {
				rxChangeType.setRequestor(rxChangeBean.getRequestor());
				if (null != rxChangeBean.getCustomerIdList()
						&& !rxChangeBean.getCustomerIdList().isEmpty()) {
					rxChangeType.setListCustomerIds(rxChangeBean
							.getCustomerIdList());
				}
				if (null != rxChangeBean.getModelIdList()
						&& !rxChangeBean.getModelIdList().isEmpty()) {
					rxChangeType.setListModelIds(rxChangeBean.getModelIdList());
				}

				rxChangeType.setRequestor(rxChangeBean.getRequestor());
				rxChangeType.setRevisionType(rxChangeBean.getRevisionType());
				rxChangeType.setSpecificRxTitle(rxChangeBean
						.getSpecificRxTitle());
				rxChangeType
						.setGeneralRxTitle(rxChangeBean.getGeneralRxTitle());
				rxChangeType.setRoadNumber(rxChangeBean.getRoadNumber());
				rxChangeType.setCaseId(rxChangeBean.getCaseId());
				
				if(!RMDCommonUtility.isNullOrEmpty(rxChangeBean.getChangesSuggested())){
				rxChangeType.setChangesSuggested(AppSecUtil.htmlEscaping(rxChangeBean
						.getChangesSuggested()));
				}
				
				rxChangeType.setUserId(rxChangeBean.getUserId());
				
				if(!RMDCommonUtility.isNullOrEmpty(rxChangeBean.getNotes())){
				rxChangeType.setNotes(AppSecUtil.htmlEscaping(rxChangeBean.getNotes()));
				}
				
				/**
				 * US293725	Customers : Rx Update Workflow - Save multiple attachments in Add Rx Change Request Page
				 */
				/*rxChangeType.setFileName(rxChangeBean.getFileName());
				rxChangeType.setFileData(rxChangeBean.getFileData());
				rxChangeType.setFilePath(rxChangeBean.getFilePath());*/
				
				RxDelvDocType objRxDelvDocType = null;
				List<RxDelvDocType> arlRxDelvDocType = new ArrayList<RxDelvDocType>();
				List<RecommDelvDocVO> lstDocs = rxChangeBean.getArlRecommDelDocVO();
				if(RMDCommonUtility.isCollectionNotEmpty(lstDocs)){
				for (Iterator iterator = lstDocs.iterator(); iterator.hasNext();) {
						RecommDelvDocVO recommDelvDocVO = (RecommDelvDocVO) iterator
								.next();
						objRxDelvDocType = new RxDelvDocType();
						objRxDelvDocType.setDocData(recommDelvDocVO.getDocData());
						objRxDelvDocType.setDocTitle(recommDelvDocVO.getDocTitle());
						objRxDelvDocType.setDocPath(recommDelvDocVO.getDocPath());
						arlRxDelvDocType.add(objRxDelvDocType);
					}
					rxChangeType.setLstAttachment(arlRxDelvDocType);
				}
				rxChangeType.setScreenName(rxChangeBean.getScreenName());
				/**
				 * US293725	Customers : Rx Update Workflow - Save multiple attachments in Add Rx Change Request Page End
				 */
				rxChangeType.setStatusObjId(rxChangeBean.getStatusObjId());
				rxChangeType.setStatus(rxChangeBean.getStatus());
				rxChangeType
						.setTypeOfRxChange(rxChangeBean.getTypeOfRxChange());
				returnString = (String) webServiceInvoker.post(
						ServiceConstants.SAVE_EDIT_RX_CHANGE_DETAILS,
						rxChangeType, String.class);

			}

		} catch (Exception ex) {
			returnString = RMDCommonConstants.FAILURE_MSG;			
			logger.error("Exception occured in saveRxChangeReqDetails method ",
					ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return returnString;
	}
	
	/**
     * @Author:
     * @param:
     * @return:List<ModelVO>
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for fetching the Models based on Rx title.
     */
	@Override
	public List<ModelVO> getModelForRxTitle(RxChangeSearchVO rxChangeSearchVO)
			throws  RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		List<ModelVO> lstModelVO = new ArrayList<ModelVO>();
		try {
			queryParams.put(AppConstants.RECOM_ID,
					rxChangeSearchVO.getRecomObjId());

			ModelsResponseType[] arrResponseType = (ModelsResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_RXCHANGE_MODEL_FOR_RX_TITLE,
							null, queryParams, null, ModelsResponseType[].class);

			if (null != arrResponseType) {
				lstModelVO = new ArrayList<ModelVO>(arrResponseType.length);
				for (ModelsResponseType objModelReponseType : arrResponseType) {
					ModelVO modelVO = new ModelVO();
					modelVO.setModelFamily(objModelReponseType.getModelFamily());
					modelVO.setModelGeneral(objModelReponseType
							.getModelGeneral());
					modelVO.setModelName(objModelReponseType.getModelName());
					modelVO.setModelObjId(objModelReponseType.getModelObjId());
					lstModelVO.add(modelVO);
				}
			}
        } catch (RMDWebException rmdEx) {
            logger.error("RMDWebException occured in getRxChangeOverviewData() method ", rmdEx);
            throw rmdEx;

        } catch (Exception ex) {
            logger.error("Excpetion occured in getRxChangeOverviewData() method ", ex);
            RMDWebErrorHandler.handleException(ex);

        }

		return lstModelVO;
	}

	@Override
	public String saveUpdateRxChangeAdminDetails(RxChangeAdminVO rxChangeAdminVO)
			throws  RMDWebException {
		String result = null;
		try {
			RxChangeAdminRequestType objRxChangeAdminRequest = new RxChangeAdminRequestType();
			if (null != rxChangeAdminVO) {
				objRxChangeAdminRequest
						.setAdminEmailIdLst(getAdminEmailIdStr());
				objRxChangeAdminRequest.setUserId(rxChangeAdminVO.getUserId());
				objRxChangeAdminRequest.setRxChangeRequestId(rxChangeAdminVO
						.getRxChangeRequestId());
				objRxChangeAdminRequest.setReViewerUserSeqId(rxChangeAdminVO
						.getReViewerUserSeqId());
				objRxChangeAdminRequest.setObjId(rxChangeAdminVO.getObjId());
				objRxChangeAdminRequest.setNewRxCreated(rxChangeAdminVO
						.getNewRxCreated());
				objRxChangeAdminRequest.setAnyChangeinMaterial(rxChangeAdminVO
						.getAnyChangeinMaterial());
				objRxChangeAdminRequest.setTriggerLogicChange(rxChangeAdminVO
						.getTriggerLogicChange());
				objRxChangeAdminRequest
						.setUnfamiliarSystemChange(rxChangeAdminVO
								.getUnfamiliarSystemChange());
				objRxChangeAdminRequest.setNoOfRxAttachment(rxChangeAdminVO
						.getNoOfRxAttachment());
				if (!RMDCommonUtility.isNullOrEmpty(rxChangeAdminVO
						.getModelsImpacted())) {
					List<String> modelList = new ArrayList<String>(
							Arrays.asList(rxChangeAdminVO.getModelsImpacted()
									.split(AppConstants.COMMA)));
					objRxChangeAdminRequest.setModelsImpacted(modelList);

				}
				if (!RMDCommonUtility.isNullOrEmpty(rxChangeAdminVO
						.getCustomers())) {
					List<String> customerList = new ArrayList<String>(
							Arrays.asList(rxChangeAdminVO.getCustomers().split(
									AppConstants.COMMA)));
					objRxChangeAdminRequest.setCustomers(customerList);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxChangeAdminVO
						.getRxsImpacted())) {
					List<String> rxTitleList = new ArrayList<String>(
							Arrays.asList(rxChangeAdminVO.getRxsImpacted()
									.split(AppConstants.COMMA)));
					objRxChangeAdminRequest.setRxsImpacted(rxTitleList);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxChangeAdminVO.getRxChangeReasons())) {
					List<String> typeOfRxChangeLst = new ArrayList<String>(
							Arrays.asList(rxChangeAdminVO.getRxChangeReasons()
									.split(AppConstants.COMMA)));
					objRxChangeAdminRequest
							.setRxChangeReasons(typeOfRxChangeLst);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxChangeAdminVO
						.getAdditionalReviewer())) {
					List<String> additionalReviewerLst = new ArrayList<String>(
							Arrays.asList(rxChangeAdminVO
									.getAdditionalReviewer().split(
											AppConstants.COMMA)));
					objRxChangeAdminRequest
							.setAdditionalReviewer(additionalReviewerLst);
				}
				
				objRxChangeAdminRequest.setAcceptanceFlag(rxChangeAdminVO
						.getAcceptanceFlag());
				if(!RMDCommonUtility.isNullOrEmpty(rxChangeAdminVO.getReviewerNotes())){
				objRxChangeAdminRequest.setReviewerNotes(AppSecUtil.htmlEscaping(rxChangeAdminVO
						.getReviewerNotes()));
				}
				if(!RMDCommonUtility.isNullOrEmpty(rxChangeAdminVO.getInternalNotes())) {
				objRxChangeAdminRequest.setInternalNotes(AppSecUtil.htmlEscaping(rxChangeAdminVO
						.getInternalNotes()));
				}

				objRxChangeAdminRequest
						.setTargetImplementationDate(rxChangeAdminVO
								.getTargetImplementationDate());
				objRxChangeAdminRequest.setSaveAsDraft(rxChangeAdminVO
						.getSaveAsDraft());
				if(!RMDCommonUtility.isNullOrEmpty(rxChangeAdminVO.getSummaryOfChanges()))	{
				objRxChangeAdminRequest.setSummaryOfChanges(AppSecUtil.htmlEscaping(rxChangeAdminVO
						.getSummaryOfChanges()));	
				}
				result = (String) webServiceInvoker.post(
						ServiceConstants.RX_CHANGE_SAVE_UPDATE_ADMIN_DETAILS,
						objRxChangeAdminRequest, String.class);
			}

        } catch (RMDWebException rmdEx) {
            logger.error("RMDWebException occured in saveUpdateRxChangeAdminDetails() method ", rmdEx);

            throw rmdEx;

        } catch (Exception ex) {
            logger.error("Excpetion occured in saveUpdateRxChangeAdminDetails() method ", ex);
            RMDWebErrorHandler.handleException(ex);

        }
		return result;
	}

	@Override
	public RxChangeAdminVO getRxChangeAdminData(
			RxChangeSearchVO rxChangeSearchVO) throws 
			RMDWebException {
		RxChangeAdminVO objRxChangeAdminVO = null;
		List<RxChangeAdminTitleVO> lstRxChagneAdminTitleVO = null;
		RxChangeAdminTitleVO rxChangeAdminTitleVO = null;
		try {
			RxChangeOverviewRequestType objRxChangeOverviewRequestType = new RxChangeOverviewRequestType();
			objRxChangeOverviewRequestType
					.setRxChangeProcObjId(rxChangeSearchVO
							.getRxChangeProcObjId());
			objRxChangeOverviewRequestType.setRxChangeReqObjId(rxChangeSearchVO
					.getRxChangeReqObjId());

			RxChangeAdminResponseType rxChangeAdminResponseType = (RxChangeAdminResponseType) webServiceInvoker
					.post(ServiceConstants.GET_RX_CHANGE_ADMIN_DETAILS,
							objRxChangeOverviewRequestType,
							RxChangeAdminResponseType.class);

			if (null != rxChangeAdminResponseType) {
				objRxChangeAdminVO = new RxChangeAdminVO();
				objRxChangeAdminVO.setUserId(rxChangeAdminResponseType
						.getUserId());
				objRxChangeAdminVO
						.setRxChangeRequestId(rxChangeAdminResponseType
								.getRxChangeRequestId());
				objRxChangeAdminVO.setObjId(rxChangeAdminResponseType
						.getObjId());
				objRxChangeAdminVO.setNewRxCreated(rxChangeAdminResponseType
						.getNewRxCreated());
				objRxChangeAdminVO
						.setAnyChangeinMaterial(rxChangeAdminResponseType
								.getAnyChangeinMaterial());
				objRxChangeAdminVO
						.setTriggerLogicChange(rxChangeAdminResponseType
								.getTriggerLogicChange());
				objRxChangeAdminVO
						.setUnfamiliarSystemChange(rxChangeAdminResponseType
								.getUnfamiliarSystemChange());
				objRxChangeAdminVO
						.setNoOfRxAttachment(rxChangeAdminResponseType
								.getNoOfRxAttachment());
				
				if(!RMDCommonUtility.isNullOrEmpty(rxChangeAdminResponseType.getSummaryOfChanges())){
				objRxChangeAdminVO.setSummaryOfChanges(EsapiUtil
						.resumeSpecialChars(ESAPI.encoder()
								.decodeForHTML(
										rxChangeAdminResponseType
												.getSummaryOfChanges())));
				}
				
				objRxChangeAdminVO.setModelsImpacted(rxChangeAdminResponseType
						.getStrModel());
				objRxChangeAdminVO.setAcceptanceFlag(rxChangeAdminResponseType
						.getAcceptanceFlag());
				objRxChangeAdminVO.setCustomers(rxChangeAdminResponseType
						.getStrCustomer());

				if (!RMDCommonUtility.isNullOrEmpty(rxChangeAdminResponseType
						.getRxList())) {
					lstRxChagneAdminTitleVO = new ArrayList<RxChangeAdminTitleVO>();
					String[] arrRx = rxChangeAdminResponseType.getRxList()
							.split(Pattern.quote(AppConstants.SYMBOL_OR));
					if (null != arrRx && arrRx.length > 0) {
						for (String rx : arrRx) {
							rxChangeAdminTitleVO = new RxChangeAdminTitleVO();
							String[] rxList = rx.split(AppConstants.TILDA);
							if (null != rxList && rxList.length > 0) {
								rxChangeAdminTitleVO.setValue(rxList[0]);
								rxChangeAdminTitleVO.setText(rxList[1]);
								lstRxChagneAdminTitleVO
										.add(rxChangeAdminTitleVO);
							}
						}
					}
				}
				objRxChangeAdminVO.setRxList(lstRxChagneAdminTitleVO);
				
				if(!RMDCommonUtility.isNullOrEmpty(rxChangeAdminResponseType.getReviewerNotes())){
				objRxChangeAdminVO.setReviewerNotes(EsapiUtil
						.resumeSpecialChars(ESAPI.encoder().decodeForHTML(
								rxChangeAdminResponseType.getReviewerNotes())));
				}
				
				if(!RMDCommonUtility.isNullOrEmpty(rxChangeAdminResponseType.getInternalNotes())){
				objRxChangeAdminVO.setInternalNotes(EsapiUtil
						.resumeSpecialChars(ESAPI.encoder().decodeForHTML(
								rxChangeAdminResponseType.getInternalNotes())));
				}
				
				
				StringBuilder rxChangeReasons = new StringBuilder();
				int i =0;
		        if (null != rxChangeAdminResponseType.getRxChangeReasons()) {
		            for (String objid : rxChangeAdminResponseType.getRxChangeReasons().split(Pattern
		                            .quote(RMDCommonConstants.COMMMA_SEPARATOR))) {
		                if(i != 0){
		                    rxChangeReasons.append(RMDCommonConstants.COMMMA_SEPARATOR);
		                }
		                rxChangeReasons.append(objid.split(RMDCommonConstants.TILDA)[0]);
		                i++;
		            }
		        }
		        
		        objRxChangeAdminVO.setRxChangeReasons(rxChangeReasons.toString()); 
		        
				objRxChangeAdminVO
						.setTargetImplementationDate(rxChangeAdminResponseType
								.getTargetImplementationDate());
				objRxChangeAdminVO
						.setAdditionalReviewer(rxChangeAdminResponseType
								.getAdditionalReviewer());
				
				List<RxChangeVO> rxchangeAuditInfoLst = new ArrayList<RxChangeVO>();
                if(null != rxChangeAdminResponseType.getRxchangeAuditInfoLst() && !rxChangeAdminResponseType.getRxchangeAuditInfoLst().isEmpty()){
                for(RxChangeResponseType tempRxChangeVO : rxChangeAdminResponseType.getRxchangeAuditInfoLst()){
                    RxChangeVO tempRxChangeResponseType = new RxChangeVO();
                    tempRxChangeResponseType.setStatus(tempRxChangeVO.getStatus());
                    tempRxChangeResponseType.setRequestLoggedDate(tempRxChangeVO.getRequestLoggedDate());
                    tempRxChangeResponseType.setUserName(tempRxChangeVO.getUserName()); 
                    tempRxChangeResponseType.setNotes(EsapiUtil
                            .resumeSpecialChars(ESAPI.encoder().decodeForHTML(tempRxChangeVO.getNotes())));    
                    rxchangeAuditInfoLst.add(tempRxChangeResponseType);
                }
                }
                objRxChangeAdminVO.setRxchangeAuditInfoLst(rxchangeAuditInfoLst);
			}

        } catch (RMDWebException rmdEx) {
            logger.error("RMDWebException occured in getRxChangeAdminData() method ", rmdEx);

            throw rmdEx;

        } catch (Exception ex) {
            logger.error("Excpetion occured in getRxChangeAdminData() method ", ex);
            RMDWebErrorHandler.handleException(ex);

        }
		return objRxChangeAdminVO;

	}

	@Override
	public List<CustomerVO> getCustomerForModel(String model)
			throws  RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		List<CustomerVO> lstCustomerVO = new ArrayList<CustomerVO>();
		try {
			queryParams.put(AppConstants.MODEL, model);

			Customer[] customerResponse = (Customer[]) webServiceInvoker.get(
					ServiceConstants.GET_ALL_CUSTOMERS_FOR_MODEL, null,
					queryParams, null, Customer[].class);

			if (null != customerResponse) {
				lstCustomerVO = new ArrayList<CustomerVO>(
						customerResponse.length);
				for (Customer objCustomer : customerResponse) {
					CustomerVO customerVO = new CustomerVO();
					customerVO.setCustomerID(objCustomer.getCustomerID());
					customerVO.setCustomerName(objCustomer
							.getCustomerFullName());
					customerVO.setCustomerSeqId(objCustomer.getCustomerSeqId());
					lstCustomerVO.add(customerVO);
				}
			}
        } catch (RMDWebException rmdEx) {
            logger.error("RMDWebException occured in getCustomerForModel() method ", rmdEx);

            throw rmdEx;

        } catch (Exception ex) {
            logger.error("Excpetion occured in getCustomerForModel() method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
		return lstCustomerVO;
	}

	@Override
	public List<UserServiceVO> getRxChangeAdminUsers() throws RMDWebException {

		List<UserServiceVO> lstUserSerVoResponse = null;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();

		try {

			UserEOADetailsResponseType[] userResponse = (UserEOADetailsResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_RXCHANGE_ADMIN_USERS, null,
							queryParams, null,
							UserEOADetailsResponseType[].class);

			if (null != userResponse) {
				lstUserSerVoResponse = new ArrayList<UserServiceVO>(
						userResponse.length);
				for (UserEOADetailsResponseType objUser : userResponse) {
					UserServiceVO userVO = new UserServiceVO();
					userVO.setUserId(objUser.getUserId());
					userVO.setStrFirstName(objUser.getFirstName());
					userVO.setStrLastName(objUser.getLastName());
					userVO.setStrEmail(objUser.getEmailId());
					lstUserSerVoResponse.add(userVO);
				}
			}
        } catch (RMDWebException rmdEx) {
            logger.error("RMDWebException occured in getRxChangeAdminUsers() method ", rmdEx);
            throw rmdEx;
        } catch (Exception ex) {
            logger.error("Excpetion occured in getRxChangeAdminUsers() method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
		return lstUserSerVoResponse;
	}

	@Override
	public String getAdminEmailIdStr() throws  RMDWebException {
		StringBuilder emailIdStr = null;
		String strEmailIdResult = "";
		try {
			List<UserServiceVO> lstUserVo = getRxChangeAdminUsers();

			if (null != lstUserVo && !lstUserVo.isEmpty()) {
				emailIdStr = new StringBuilder();

				for (UserServiceVO userServiceVO : lstUserVo) {
					if (emailIdStr.length() > 0) {
						emailIdStr.append(", ");
					}
					emailIdStr.append(userServiceVO.getStrEmail());
				}
				strEmailIdResult = emailIdStr.toString();
			}
        } catch (RMDWebException rmdEx) {
            logger.error("RMDWebException occured in getAdminEmailIdStr() method ", rmdEx);

            throw rmdEx;

        } catch (Exception ex) {
            logger.error("Excpetion occured in getAdminEmailIdStr() method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }

		return strEmailIdResult;
	}
	
	@Override
    public List<RxChangeVO> getRxChangeAuditTrailInfo(String rxChngObjid, String timeZone) throws  RMDWebException {
     logger.debug("timeZone :: "+timeZone);
        final Map<String, String> queryParams = new LinkedHashMap<String, String>();        
        List<RxChangeVO> rxchangeAuditInfoLst = new ArrayList<RxChangeVO>();
        SimpleDateFormat sdf = new SimpleDateFormat("mm-dd-yyyy hh:mm:ss"); 
        try {
            queryParams.put(AppConstants.RX_CHANGE_REQ_OBJ_ID, rxChngObjid);

             
            RxChangeResponseType[] rxChangeResponeType = (RxChangeResponseType[]) webServiceInvoker
                    .get(ServiceConstants.GET_RXCHANGE_AUDIT_TRIAL_INFO, null,
                            queryParams, null, RxChangeResponseType[].class);
           
            if(null != rxChangeResponeType && rxChangeResponeType.length > 0){
            for(RxChangeResponseType tempRxChangeRespType : rxChangeResponeType){
                RxChangeVO rxchangeVO = new RxChangeVO();
                rxchangeVO.setStatus(tempRxChangeRespType.getStatus());
                rxchangeVO.setRequestLoggedDate(tempRxChangeRespType.getRequestLoggedDate());
                
                if (!RMDCommonUtility.isNullOrEmpty(tempRxChangeRespType.getRequestLoggedDate())) {
                    rxchangeVO
                            .setRequestLoggedDate(RMDCommonUtility.convertDateFormatAndTimezone(
                                    tempRxChangeRespType.getRequestLoggedDate(),
                                    AppConstants.TO_DATE_FORMAT,
                                    AppConstants.TO_DATE_FORMAT,
                                    AppConstants.TIMEZONE_EASTERN,
                                    timeZone));
                }
                
                
                rxchangeVO.setUserName(tempRxChangeRespType.getUserName()); 
                if(!RMDCommonUtility.isNullOrEmpty(tempRxChangeRespType.getNotes()) && !("null".equals(tempRxChangeRespType.getNotes())))
                rxchangeVO.setNotes(EsapiUtil
                        .resumeSpecialChars(ESAPI.encoder().decodeForHTML(tempRxChangeRespType.getNotes())));  
                else
                    rxchangeVO.setNotes(RMDCommonConstants.EMPTY_STRING); 
                rxchangeAuditInfoLst.add(rxchangeVO);
            }
            }
         }catch (RMDWebException rmdEx) {
            logger.error("RMDWebException occured in getAdminEmailIdStr() method ", rmdEx);

            throw rmdEx;

        } catch (Exception ex) {
            logger.error("Excpetion occured in getAdminEmailIdStr() method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }

        return rxchangeAuditInfoLst;
    }
	@Override
	public Map<String, String> getModelForTechnicianScreen(String customer,String fleet,String rnh,String assetList)
			throws RMDWebException {
		Map<String, String> modelMap = null;
		AssetNumberResponseType[] objassetNumberResponseType=null;
		Map<String, String> queryParams = new LinkedHashMap<String, String>(4);
		try {
			queryParams.put(AppConstants.CUSTOMER, customer);
			queryParams.put(AppConstants.FLEET, fleet);
			queryParams.put(AppConstants.RNH, rnh);
			queryParams.put(AppConstants.ASSET_LIST, assetList);
			objassetNumberResponseType = (AssetNumberResponseType[]) webServiceInvoker.get(
					ServiceConstants.GET_MODEL_BASED_FILTER, null, queryParams,
					null, AssetNumberResponseType[].class);
			if (null != objassetNumberResponseType
					&& objassetNumberResponseType.length > 0) {
				modelMap=new HashMap<String, String>(objassetNumberResponseType.length);
				for (AssetNumberResponseType assetNumberResponseType : objassetNumberResponseType) {
					modelMap.put(assetNumberResponseType.getModel(), assetNumberResponseType.getModelGeneral());
				}
			}
		} catch (Exception rmdEx) {
			logger
					.error("RMDWebException occured in getModelByFilter() method - CreateCaseServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally
		{
			objassetNumberResponseType=null;
			queryParams=null;
		}
		return modelMap;
	}

}