package com.ge.trans.rmd.cm.mvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;

@Controller
@SessionAttributes
public class OverviewController extends RMDBaseController {
	@SuppressWarnings("unused")
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
	.getLogger(getClass());
	
	@RequestMapping(AppConstants.REQ_URI_OVERVIEW)
	public ModelAndView showOverview(final HttpServletRequest request) {
		request.setAttribute(AppConstants.FILTERFLAG, EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG)));
		
		return new ModelAndView(AppConstants.VIEW_OVERVIEW);
	}
}
