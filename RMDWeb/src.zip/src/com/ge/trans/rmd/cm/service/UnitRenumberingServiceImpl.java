package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.UnitRenumberingRequestVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.valueobjects.UnitRoadHeaderUpdateVO;
import com.ge.trans.rmd.pp.beans.AssetBean;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.UnitHeaderUpdateRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.UnitRenumberingRequestType;

@Service
public class UnitRenumberingServiceImpl extends RMDBaseServiceImpl implements UnitRenumberingService {
	private final RMDWebLogger logger = RMDWebLogger.getLogger(getClass());
	@Autowired
	private WebServiceInvoker rsInvoker;
	@Override
	public String updateUnitNumber(String oldUnitNum, String newUnitNum, String vehicleHeader, String customerId) throws RMDWebException {
		String status = null;
		UnitRenumberingRequestType requestObj = null;
		try {
			requestObj = new UnitRenumberingRequestType();
			requestObj.setCustomerId(customerId);
			requestObj.setVehicleHeader(vehicleHeader);
			requestObj.setOldUnitNumber(oldUnitNum);
			requestObj.setNewUnitNumber(newUnitNum);
			status = (String) (rsInvoker.post(
					ServiceConstants.UPDATE_UNIT_NUMBER, requestObj,
					String.class));
		}catch (Exception e) {
			logger.error(
					"Exception occured in updateUnitNumber in UnitRenumberingServiceImpl:",e);
			RMDWebErrorHandler.handleException(e);
		}
		return status;
	}
	@Override
	public String updateUnitHeader(UnitRoadHeaderUpdateVO unitRoadHeaderUpdate)
			throws RMDWebException {
		UnitHeaderUpdateRequestType requestObj;
		String status = null;
		try{
			requestObj = new UnitHeaderUpdateRequestType();
			requestObj.setCustomerId(unitRoadHeaderUpdate.getCustomer());
			requestObj.setCurrentVehicleHeader(unitRoadHeaderUpdate.getCurrentRoadHeader());
			requestObj.setNewVehicleHeader(unitRoadHeaderUpdate.getNewRoadHeader());
			requestObj.setVehicleNumber(unitRoadHeaderUpdate.getVehicleNumbers());
			status = (String) (rsInvoker.post(
					ServiceConstants.UPDATE_UNIT_HEADER, requestObj,
					String.class));
		} catch (Exception e) {
			logger.error(
					"Exception occured in updateUnitNumber in UnitRenumberingServiceImpl:",e);
			RMDWebErrorHandler.handleException(e);
		}
		return status;
	}

	/**
	 * This method will call web-service to return list of asset numbers for
	 * given keys like customerId, assetGroup and assetnumber
	 */
	@Override
	public List<String> getAssets(AssetBean assetBean) throws RMDWebException,
			Exception {

		AssetResponseType[] assetResponses = null;
		List<String> assetNumbers = new ArrayList<String>();
		final Map<String, String> headerParams = getHeaderMap(assetBean);
		try {
			AssetsRequestType objAssetsReqType=new AssetsRequestType();
			objAssetsReqType.setLanguage(headerParams.get(AppConstants.USER_LANGUAGE));
			objAssetsReqType.setCustomerId(assetBean.getCustomerId());
			objAssetsReqType.setAssetNumberLike(assetBean.getAssetNumber());
			objAssetsReqType.setFleetId(assetBean.getFleetId());
			if(null!=assetBean.getAssetGroup()&&!assetBean.getAssetGroup().equals(RMDCommonConstants.EMPTY_STRING)){
				objAssetsReqType.setAssetGrpName(assetBean.getAssetGroup());
			}
			assetResponses = (AssetResponseType[])rsInvoker
					.post(ServiceConstants.GET_ASSETS_UNIT_RENUM, objAssetsReqType, AssetResponseType[].class);

			for (int i = 0; i < assetResponses.length; i++) {
				assetNumbers.add(assetResponses[i].getAssetNumber() + "");
			}

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				logger
						.error("CreateCaseServiceImpl :: No records found for getAssets() service "
								+ e.getMessage());
				assetResponses = null;
			} else {
				logger
						.error("CreateCaseServiceImpl :: Exception occured in getAssets() method "
								+ e.getMessage());
				throw e;
			}
		} catch (Exception e) {
			logger.error("Exception occured in getAssets method ", e);
			throw e;
		}
		return assetNumbers;
	}
}
