package com.ge.trans.rmd.cm.mvc.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.NewsService;
import com.ge.trans.rmd.cm.valueobjects.InsertNewsVO;
import com.ge.trans.rmd.common.beans.UserManagementBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.NewsAllVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.services.admin.valueobjects.NewsDeleteRequestType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.cm.valueobjects.RecommDeliverVO;
import com.ge.trans.rmd.cm.valueobjects.RecommDelvDocVO;
@Controller
@SessionAttributes
public class WelcomeController extends RMDBaseController {
	@SuppressWarnings("unused")
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
	.getLogger(getClass());
	
	@Autowired
	private NewsService newsService;
	
	@RequestMapping(AppConstants.REQ_URI_WELCOME)
	public ModelAndView getWelcome(final HttpServletRequest request) throws  RMDWebException {
		rmdWebLogger
    	.debug("Inside getwelcome in welcome controller ");
		String bgstaticURL = "../../RMDWeb/img/app/train.jpg";
		String bgImageURL = null;
    	try {
    		HttpSession session = request.getSession(false);
    		UserVO userVO = (UserVO) session
    				.getAttribute(AppConstants.ATTR_USER_OBJECT);
    		if(userVO.getCustomerId()!=null && !(AppConstants.EMPTYSTRING).equals(userVO.getCustomerId()) && !(AppConstants.ALL).equals(userVO.getCustomerId())){
    			bgImageURL = newsService.getBackgroundImage(userVO.getCustomerId());
    		}
    		else
    		{
    			bgImageURL = newsService.getBackgroundImage("GETS");
    		}
    		request.setAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE,
    				userVO.getIsCMPrivilege());
    		if(!RMDCommonUtility.isNullOrEmpty(bgImageURL)){
    		request.setAttribute(AppConstants.BACKGROUND_IMAGE_URL, bgImageURL);
    		}
    		else
    		{
    		request.setAttribute(AppConstants.BACKGROUND_IMAGE_URL, bgstaticURL);
    		}
    		
    	} catch (Exception ex) {
    		rmdWebLogger
    		.error("Exception occured in Inside getwelcome in welcome controller ",
    				ex);
    		RMDWebErrorHandler.handleException(ex);
    		}
		return new ModelAndView(AppConstants.VIEW_WELCOME);
	}
	
	@RequestMapping(AppConstants.REQ_URI_NEWS)
	public ModelAndView getNews(final HttpServletRequest request) throws  RMDWebException {
		rmdWebLogger
    	.debug("Inside getnews in welcome controller ");
    	try {
    		HttpSession session = request.getSession(false);
    		String fromDate = null;
    		String isAdminPage = "Y";
    		final SimpleDateFormat dateFormat = new SimpleDateFormat(
    				AppConstants.FROM_DATE_FORMAT);
    		List<NewsAllVO> newsVO = new ArrayList<NewsAllVO>();
    		UserVO userVO = (UserVO) session
    				.getAttribute(AppConstants.ATTR_USER_OBJECT);
    		final String defaultTimezone = (String) request
    				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
    		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
    				userVO.getTimeZone());
    		dateFormat.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
    		Calendar fromDtCal = Calendar.getInstance();
    		fromDtCal.add(Calendar.DATE, 0);
    		fromDate = dateFormat.format(fromDtCal.getTime());
    		newsVO = newsService.getAllNews(userVO.getUserId(),isAdminPage,userVO.getCustomerId());
    		for (NewsAllVO obj : newsVO) {
				obj.setExpiryDate(RMDCommonUtility
					.convertDateFormatAndTimezone(obj.getExpiryDate(),
							AppConstants.FROM_DATE_FORMAT,
							AppConstants.FROM_DATE_FORMAT,
							AppConstants.TIMEZONE_EASTERN,
							applicationTimezone
							));
				obj.setCreationDate(RMDCommonUtility
	                    .convertDateFormatAndTimezone(obj.getCreationDate(),
	                            AppConstants.FROM_DATE_FORMAT,
	                            AppConstants.FROM_DATE_FORMAT,
	                            AppConstants.TIMEZONE_EASTERN,
	                            applicationTimezone
	                            ));
				if(null!=obj.getLastUpdatedDate() && !RMDCommonConstants.EMPTY_STRING.equals(obj.getLastUpdatedDate())){
    				obj.setLastUpdatedDate(RMDCommonUtility
                            .convertDateFormatAndTimezone(obj.getLastUpdatedDate(),
                                    AppConstants.FROM_DATE_FORMAT,
                                    AppConstants.FROM_DATE_FORMAT,
                                    AppConstants.TIMEZONE_EASTERN,
                                    applicationTimezone
                                    ));
				}
			}
    		request.setAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE,
    				userVO.getIsCMPrivilege());
    		request.setAttribute(AppConstants.FROM_DATE, fromDate);
    		request.setAttribute("AllNews", newsVO);
    		
    	} catch (Exception ex) {
    		rmdWebLogger
    		.error("Exception occured in Inside getnews in welcome controller ",
    				ex);
    		RMDWebErrorHandler.handleException(ex);
    		}
		return new ModelAndView(AppConstants.VIEW_NEWS);
	}
	
	@RequestMapping(value = AppConstants.REQ_URI_SAVE_NEWS ,  method = RequestMethod.POST)
	public @ResponseBody String saveNews(final HttpServletRequest request) throws  RMDWebException {
		String response = "";
		rmdWebLogger.debug("Inside saveNews in welcome controller ");
		List<String> customerarray =null;
		String status=null;
		String currDate = null;
    	try {
    		HttpSession session = request.getSession(false);
    		UserVO userVO = (UserVO) session
    				.getAttribute(AppConstants.ATTR_USER_OBJECT);
    		final String defaultTimezone = (String) request
					.getAttribute(AppConstants.DEFAULT_TIMEZONE);
    		String applicationTimezone = RMDCommonUtil.getTimezone(
					defaultTimezone, userVO.getTimeZone());
    		final SimpleDateFormat dateFormat = new SimpleDateFormat(
                    AppConstants.FROM_DATE_FORMAT);
    		final String objId = EsapiUtil.stripXSSCharacters(request
                    .getParameter("objId"));
    		if(null==objId){
    		    customerarray = Arrays.asList(EsapiUtil
					.stripXSSCharacters(request.getParameter("customerarray"))
					.split(AppConstants.TILDA));
    		    status=RMDCommonConstants.LETTER_Y;
    		}else{
    		    status =EsapiUtil.stripXSSCharacters(request
                        .getParameter("status"));
    		}
			final String newsDesc = EsapiUtil.stripXSSCharacters(request
					.getParameter("newsDesc"));
    		final String expiryDate = EsapiUtil.stripXSSCharacters(request
					.getParameter("expiryDate"));
    		final String docDetails = EsapiUtil.stripXSSCharacters(request
                    .getParameter("docDetails"));
    		final String imgDetails = EsapiUtil.stripXSSCharacters(request
                    .getParameter("imgDetails"));
    		final String fileRemoved = EsapiUtil.stripXSSCharacters(request
                    .getParameter("fileRemoved"));
    		
    		dateFormat.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
            Calendar fromDtCal = Calendar.getInstance();
            fromDtCal.add(Calendar.DATE, 0);
            currDate = dateFormat.format(fromDtCal.getTime());
    		RecommDelvDocVO objDocVO =null;
    		RecommDelvDocVO objImgVO=null;
    		final ObjectMapper mapper = new ObjectMapper();
            mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
            if (null != docDetails) {
                objDocVO = mapper.readValue(docDetails, RecommDelvDocVO.class);
            }
            if (null != imgDetails) {
                objImgVO = mapper.readValue(imgDetails, RecommDelvDocVO.class);
            }
            
            
            if (RMDCommonConstants.LETTER_Y.equalsIgnoreCase(status)
                    && !validateDate(expiryDate, currDate)) {
                response = AppConstants.FINDNOTES_START_FUTURE_DATE;
            } else {
                InsertNewsVO insertNewsVO = new InsertNewsVO();
                insertNewsVO.setCustomerarray(customerarray);
                insertNewsVO.setExpiryDate((RMDCommonUtility
                        .convertDateFormatAndTimezone(expiryDate,
                                AppConstants.FROM_DATE_FORMAT,
                                AppConstants.HEATMAP_DB_DATE_FORMAT,
                                applicationTimezone,
                                AppConstants.TIMEZONE_EASTERN)));
                insertNewsVO.setNewsDesc(newsDesc);
                insertNewsVO.setUserId(userVO.getUserId());
                insertNewsVO.setImgDetails(objImgVO);
                insertNewsVO.setDocDetails(objDocVO);
                insertNewsVO.setObjId(objId);
                insertNewsVO.setStatus(status);
                insertNewsVO.setFileRemoved(fileRemoved);
                response = newsService.saveNews(insertNewsVO);
            }
              
    		
    	}
    	catch (Exception ex) {
    		rmdWebLogger
    		.error("Exception occured in Inside saveNews in welcome controller ",
    				ex);
    		RMDWebErrorHandler.handleException(ex);
    		}
    	return response;
	}
	
	@RequestMapping(value = AppConstants.REQ_URI_WELCOME_NEWS,  method = RequestMethod.GET)
	public  @ResponseBody List<NewsAllVO> welcomeNews(final HttpServletRequest request) throws  RMDWebException {
		rmdWebLogger
    	.debug("Inside getnews in welcome controller ");
  
		List<NewsAllVO> response = new ArrayList<NewsAllVO>();
		String isAdminPage = "N";
		List<NewsAllVO> newsVO = new ArrayList<NewsAllVO>();
    			try {
            		HttpSession session = request.getSession(false);
            		UserVO userVO = (UserVO) session
            				.getAttribute(AppConstants.ATTR_USER_OBJECT);
            		String customerName = userVO.getCustomerName();
            		newsVO = newsService.getAllNews(userVO.getUserId(),isAdminPage,userVO.getCustomerId());
        		}
    		
    		catch (Exception ex) {
        		rmdWebLogger
        		.error("Exception occured in Inside welcomeNews in welcome controller ",
        				ex);
        		RMDWebErrorHandler.handleException(ex);
        		}
    		return newsVO;
    	}
	//@RequestParam(AppConstants.GET_PARAMETER_STRING) String paramString,
	@RequestMapping(value = AppConstants.deleteUserNews,  method = RequestMethod.POST)
	public  @ResponseBody String deleteNews(@RequestParam(AppConstants.OBJID) String objId,final HttpServletRequest request) throws  RMDWebException {
		rmdWebLogger
    	.debug("Inside deleteNews in welcome controller ");
  
		String response = null;
		final ObjectMapper mapper = new ObjectMapper();
    		try {
    			response = newsService.deleteNews(objId);
    			
    		}
    		catch (Exception ex) {
        		rmdWebLogger
        		.error("Exception occured in Inside welcomeNews in welcome controller ",
        				ex);
        		RMDWebErrorHandler.handleException(ex);
        		}
    		return response;
    	}
	@RequestMapping(value = AppConstants.REQ_URI_UPDATE_READ_FLAG,  method = RequestMethod.POST)
	public  @ResponseBody String updateReadFlag(@RequestParam(AppConstants.OBJID) String objId,final HttpServletRequest request) throws  RMDWebException {
		rmdWebLogger
    	.debug("Inside updateReadFlag in welcome controller ");
  
		String response = null;
    		try {
    			response = newsService.updateReadFlag(objId);
    			
    		}
    		catch (Exception ex) {
        		rmdWebLogger
        		.error("Exception occured in Inside updateReadFlag in welcome controller ",
        				ex);
        		RMDWebErrorHandler.handleException(ex);
        		}
    		return response;
    	}
	
	public boolean validateDate(String expireDtae,String currDate) throws GenericAjaxException, RMDWebException{
	    
	    Date tempDate1 = null;
	    Date tempDate2 =null;
	    boolean result=RMDCommonConstants.TRUE;
	            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
	                            AppConstants.DATE_FORMAT_24HRS);
	            try {
                    tempDate1 = simpleDateFormat.parse(currDate);
                    tempDate2 = simpleDateFormat.parse(expireDtae);
                    
                    if (tempDate2.getTime() - tempDate1.getTime() < 0) {
                        result=RMDCommonConstants.FALSE;
                    }
                } catch (ParseException e) {
                    rmdWebLogger
                    .error("Exception occured in Inside validateDate in welcome controller ",
                            e);
                    RMDWebErrorHandler.handleException(e);
                }   
	        return result;    
	            
	    
	}
}

