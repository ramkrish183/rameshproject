/**
 * ============================================================

 * Classification		: GE Confidential
 * File 				: ViewLogVO.java
 * Description 			:
 * Package 				: com.ge.trans.rmd.cm.valueobjects;
 * Author 				: iGATE Global Solutions Ltd.
 * Last Edited By 		:
 * Version 				: 1.0
 * Created on 			:
 * History				:
 * Modified By 			: Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */

package com.ge.trans.rmd.cm.valueobjects;

/*******************************************************************************
 * 
 * @Author :
 * @Version : 1.0
 * @Date Created :21-07-2015
 * @Date Modified :21-07-2015
 * @Modified By :Vamshi
 * @Contact :
 * @Description :This is plain POJO class which carries log details.It Contains
 *              Corresponding variable Declarations along with their respective
 *              getters and setters.
 * @History :
 * 
 ******************************************************************************/
public class ViewLogVO {

	private String creationDate;
	private String roadNumberHeader;
	private String roadNumber;
	private String caseId;
	private String rxQueue;
	private String errorMsg;
	private String customerId;
	
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getRoadNumberHeader() {
		return roadNumberHeader;
	}
	public void setRoadNumberHeader(String roadNumberHeader) {
		this.roadNumberHeader = roadNumberHeader;
	}
	public String getRoadNumber() {
		return roadNumber;
	}
	public void setRoadNumber(String roadNumber) {
		this.roadNumber = roadNumber;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getRxQueue() {
		return rxQueue;
	}
	public void setRxQueue(String rxQueue) {
		this.rxQueue = rxQueue;
	}
	

	
	
}
