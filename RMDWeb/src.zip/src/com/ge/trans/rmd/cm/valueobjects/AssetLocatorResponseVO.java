package com.ge.trans.rmd.cm.valueobjects;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.vo.RMDBaseVO;
@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class AssetLocatorResponseVO extends RMDBaseVO{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String assetNumber;
	private String latitude;
	private String longitude;
	private String latlonSource;
	private String latlonDate;
	private String maxOccurTime;
	
	private AssetLastFaultStatusVO assetlastFaultStatusVo;
	private AssetOverviewBean assetOverviewBean;
	
	public String getLatlonSource() {
		return latlonSource;
	}

	public void setLatlonSource(String latlonSource) {
		this.latlonSource = latlonSource;
	}

	public String getLatlonDate() {
		return latlonDate;
	}

	public void setLatlonDate(String latlonDate) {
		this.latlonDate = latlonDate;
	}

	public AssetOverviewBean getAssetOverviewBean() {
		return assetOverviewBean;
	}

	public void setAssetOverviewBean(AssetOverviewBean assetOverviewBean) {
		this.assetOverviewBean = assetOverviewBean;
	}

	public AssetLastFaultStatusVO getAssetlastFaultStatusVo() {
		return assetlastFaultStatusVo;
	}

	public void setAssetlastFaultStatusVo(
			AssetLastFaultStatusVO assetlastFaultStatusVo) {
		this.assetlastFaultStatusVo = assetlastFaultStatusVo;
	}

	public String getAssetNumber() {
		return assetNumber;
	}
	
	public void setAssetNumber(final String assetNumber) {
		this.assetNumber = assetNumber;
	}
	
	public String getLatitude() {
		return latitude;
	}
	
	public void setLatitude(final String latitude) {
		this.latitude = latitude;
	}
	
	public String getLongitude() {
		return longitude;
	}
	
	public void setLongitude(final String longitude) {
		this.longitude = longitude;
	}
	
	public String getMaxOccurTime() {
		return maxOccurTime;
	}
	
	public void setMaxOccurTime(final String maxOccurTime) {
		this.maxOccurTime = maxOccurTime;
	}	

}
