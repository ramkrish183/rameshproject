package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.MdscStartUpControllersVO;
import com.ge.trans.rmd.cm.valueobjects.VehicleCfgTemplateVO;
import com.ge.trans.rmd.cm.valueobjects.VehicleCfgVO;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.CtrlCfgResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.MdscStartUpControllersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.VehCfgTemplateRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.VehCfgTemplateResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.VehicleCfgRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.VehicleCfgResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseInfoType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class VehicleCfgServiceImpl extends RMDBaseServiceImpl implements
		VehicleCfgService {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	WebServiceInvoker webServiceInvoker;

	@Override
	public List<VehicleCfgVO> getVehicleBOMConfigs(String customer, String rnh,
			String roadNumber) throws RMDWebException {

		VehicleCfgResponseType[] objVehicleCfgResponseType = null;
		List<VehicleCfgVO> objVehicleCfgVO = new ArrayList<VehicleCfgVO>();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		VehicleCfgVO vehicleCfgVO = null;
		try {
			queryParams.put(AppConstants.CUSTOMER, customer);
			queryParams.put(AppConstants.RNH, rnh);
			queryParams.put(AppConstants.ROAD_NUMBER, roadNumber);
			objVehicleCfgResponseType = (VehicleCfgResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_VEHICLE_CFG_ITEMS, null,
							queryParams, null, VehicleCfgResponseType[].class);
			if (null != objVehicleCfgResponseType
					&& objVehicleCfgResponseType.length > 0) {
				for (VehicleCfgResponseType vehicleCfgResponseType : objVehicleCfgResponseType) {
					vehicleCfgVO = new VehicleCfgVO();
					vehicleCfgVO.setConfigItem(ESAPI.encoder().decodeForHTML(
							vehicleCfgResponseType.getConfigItem()));
					vehicleCfgVO.setConfigObjId(vehicleCfgResponseType
							.getConfigObjId());
					vehicleCfgVO.setCurrentVersion(vehicleCfgResponseType
							.getCurrentVersion());
					vehicleCfgVO.setExpectedVersion(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(vehicleCfgResponseType
							.getExpectedVersion())));
					vehicleCfgVO.setMasterBOMObjId(vehicleCfgResponseType
							.getMasterBOMObjId());
					vehicleCfgVO.setParmeterNo(vehicleCfgResponseType
							.getParmeterNo());
					vehicleCfgVO.setSerialNumber(vehicleCfgResponseType
							.getSerialNumber());
					vehicleCfgVO.setNotificationFlag(vehicleCfgResponseType
							.getNotificationFlag());
					vehicleCfgVO.setVehicleObjId(vehicleCfgResponseType
							.getVehicleObjId());
					objVehicleCfgVO.add(vehicleCfgVO);
				}
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getVehicleBOMConfigs() method - VehicleCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}

		return objVehicleCfgVO;
	}

	@Override
	public List<String> getMDSCStartUpControllerNames() throws RMDWebException {

		rmdWebLogger
				.debug("Inside CreateCasesServiceImpl in getSolUrgencyOfRepair Method");

		List<String> mdscControllerNames = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.GET_MSDC_START_UP_CONTROLLERS);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				mdscControllerNames = new ArrayList<String>();
				for (int i = 0; i < applParamResponseType.length; i++) {
					String startUpControllerNames = applParamResponseType[i]
							.getLookupValue();

					mdscControllerNames.add(startUpControllerNames);
				}

			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getMDSCStartUpControllerNames method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return mdscControllerNames;
	}

	@Override
	public MdscStartUpControllersVO getMDSCStartUpControllersInfo(
			String customer, String rnh, String roadNumber)
			throws RMDWebException {

		MdscStartUpControllersResponseType objMdscStartUpControllersResponseType = null;
		MdscStartUpControllersVO objMdscStartUpControllersVO = null;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		try {
			queryParams.put(AppConstants.CUSTOMER, customer);
			queryParams.put(AppConstants.RNH, rnh);
			queryParams.put(AppConstants.ROAD_NUMBER, roadNumber);
			objMdscStartUpControllersResponseType = (MdscStartUpControllersResponseType) webServiceInvoker
					.get(ServiceConstants.GET_MDSC_CONTROLLERS_INFO, null,
							queryParams, null,
							MdscStartUpControllersResponseType.class);
			if (null != objMdscStartUpControllersResponseType) {
				objMdscStartUpControllersVO = new MdscStartUpControllersVO();
				objMdscStartUpControllersVO
						.setAcComm(objMdscStartUpControllersResponseType
								.getAcComm());
				objMdscStartUpControllersVO
						.setAuxComm(objMdscStartUpControllersResponseType
								.getAuxComm());
				objMdscStartUpControllersVO
						.setCabComm(objMdscStartUpControllersResponseType
								.getCabComm());
				objMdscStartUpControllersVO
						.setCaxComm(objMdscStartUpControllersResponseType
								.getCaxComm());
				objMdscStartUpControllersVO
						.setCcaComm(objMdscStartUpControllersResponseType
								.getCcaComm());
				objMdscStartUpControllersVO
						.setEabComm(objMdscStartUpControllersResponseType
								.getEabComm());
				objMdscStartUpControllersVO
						.setEfiComm(objMdscStartUpControllersResponseType
								.getEfiComm());
				objMdscStartUpControllersVO
						.setErComm(objMdscStartUpControllersResponseType
								.getErComm());
				objMdscStartUpControllersVO
						.setExcComm(objMdscStartUpControllersResponseType
								.getExcComm());
				objMdscStartUpControllersVO
						.setFlmComm(objMdscStartUpControllersResponseType
								.getFlmComm());
				objMdscStartUpControllersVO
						.setServicePdp(objMdscStartUpControllersResponseType
								.getServicePdp());
				objMdscStartUpControllersVO
						.setSmsEnabled(objMdscStartUpControllersResponseType
								.getSmsEnabled());

			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getVehicleBOMConfigs() method - VehicleCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return objMdscStartUpControllersVO;
	}

	@Override
	public String saveVehicleBOMConfigs(List<VehicleCfgVO> vehicleCfgVOList,
			CaseBean objCaseBean, String isCaseVehicleConfig)
			throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<VehicleCfgRequestType> vehicleCfgRequestType = new ArrayList<VehicleCfgRequestType>();
		VehicleCfgRequestType objVehCfgRequestType = new VehicleCfgRequestType();
		try {

			for (VehicleCfgVO objVehicleCfgVO : vehicleCfgVOList) {
				VehicleCfgRequestType vehCfgRequestType = new VehicleCfgRequestType();

				if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgVO
						.getCurrentVersion())) {
					vehCfgRequestType.setCurrentVersion(objVehicleCfgVO
							.getCurrentVersion());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgVO
						.getExpectedVersion())) {
					vehCfgRequestType.setExpectedVersion(objVehicleCfgVO
							.getExpectedVersion());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgVO
						.getSerialNumber())) {
					vehCfgRequestType.setSerialNumber(objVehicleCfgVO
							.getSerialNumber());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgVO
						.getConfigObjId())) {
					vehCfgRequestType.setConfigObjId(objVehicleCfgVO
							.getConfigObjId());
				}

				if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgVO
						.getUserName())) {
					vehCfgRequestType
							.setUserName(objVehicleCfgVO.getUserName());
				}
				
				if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgVO
						.getNotificationFlag())) {
					vehCfgRequestType.setNotificationgFlag(objVehicleCfgVO
							.getNotificationFlag());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgVO
						.getNotificationFlag())) {
					vehCfgRequestType.setVehicleObjId(objVehicleCfgVO
							.getVehicleObjId());
				}
				
				vehicleCfgRequestType.add(vehCfgRequestType);
			}

			if (AppConstants.STR_Y.equalsIgnoreCase(isCaseVehicleConfig)) {
				CaseInfoType objCaseInfoType = new CaseInfoType();
				if (!RMDCommonUtility.isNullOrEmpty(objCaseBean.getCaseId())) {
					objCaseInfoType.setCaseID(objCaseBean.getCaseId());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objCaseBean
						.getStrCaseObjId())) {
					objCaseInfoType.setStrcaseObjId(objCaseBean
							.getStrCaseObjId());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objCaseBean.getCaseType())) {
					objCaseInfoType.setCaseType(objCaseBean.getCaseType());
				}
				if (!RMDCommonUtility
						.isNullOrEmpty(objCaseBean.getCaseStatus())) {
					objCaseInfoType.setCaseStatus(objCaseBean.getCaseStatus());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objCaseBean.getOwnerName())) {
					objCaseInfoType.setOwnerName(objCaseBean.getOwnerName());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objCaseBean.getUserId())) {
					objCaseInfoType.setUserName(objCaseBean.getUserId());
				}
				objVehCfgRequestType.setObjCaseInfoType(objCaseInfoType);
			}

			objVehCfgRequestType
					.setArlVehicleCfgRequestTypes(vehicleCfgRequestType);
			objVehCfgRequestType.setIsCaseVehicleConfig(isCaseVehicleConfig);
			status = (String) webServiceInvoker.post(
					ServiceConstants.UPDATE_VEHICLE_CFG_ITEMS,
					objVehCfgRequestType, String.class);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("Exception occured in saveVehicleBOMConfigs method  method of VehicleCfgServiceImpl ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return status;
	}

	@Override
	public List<VehicleCfgTemplateVO> getVehicleCfgTemplates(String customer,
			String rnh, String roadNumber) throws RMDWebException {
		VehCfgTemplateResponseType[] objVehCfgTemplateResponseType = null;
		List<VehicleCfgTemplateVO> objVehicleCfgTemplateVO = new ArrayList<VehicleCfgTemplateVO>();
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		VehicleCfgTemplateVO vehicleCfgTemplateVO = null;
		try {
			queryParams.put(AppConstants.CUSTOMER, customer);
			queryParams.put(AppConstants.RNH, rnh);
			queryParams.put(AppConstants.ROAD_NUMBER, roadNumber);
			objVehCfgTemplateResponseType = (VehCfgTemplateResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_VEHICLE_CFG_TEMPLATES, null,
							queryParams, null,
							VehCfgTemplateResponseType[].class);
			if (null != objVehCfgTemplateResponseType
					&& objVehCfgTemplateResponseType.length > 0) {
				for (VehCfgTemplateResponseType vehCfgTemplateResponseType : objVehCfgTemplateResponseType) {
					vehicleCfgTemplateVO = new VehicleCfgTemplateVO();
					vehicleCfgTemplateVO.setObjId(vehCfgTemplateResponseType
							.getObjId());
					vehicleCfgTemplateVO
							.setConfigFile(vehCfgTemplateResponseType
									.getConfigFile());
					vehicleCfgTemplateVO.setObjId(vehCfgTemplateResponseType
							.getObjId());
					vehicleCfgTemplateVO.setStatus(vehCfgTemplateResponseType
							.getStatus());
					vehicleCfgTemplateVO.setTemplate(vehCfgTemplateResponseType
							.getTemplate());
					vehicleCfgTemplateVO.setTitle(ESAPI.encoder()
							.decodeForHTML(
									vehCfgTemplateResponseType.getTitle()));
					vehicleCfgTemplateVO.setVersion(vehCfgTemplateResponseType
							.getVersion());
					vehicleCfgTemplateVO.setOffboardStatus(vehCfgTemplateResponseType.getOffboardStatus());
					vehicleCfgTemplateVO.setOnboardStatus(vehCfgTemplateResponseType.getOnboardStatus());
					vehicleCfgTemplateVO.setVehStatusObjId(vehCfgTemplateResponseType.getVehStatusObjId());
					objVehicleCfgTemplateVO.add(vehicleCfgTemplateVO);
				}
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getVehicleBOMConfigs() method - VehicleCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}

		return objVehicleCfgTemplateVO;
	}

	/**
	 * @Author :
	 * @return :String
	 * @param : VehicleCfgTemplateVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for Deleting vehicle
	 *               Configuration Template.
	 * 
	 */
	@Override
	public String deleteVehicleCfgTemplate(
			VehicleCfgTemplateVO objVehicleCfgTemplateVO)
			throws RMDWebException {
		String result = AppConstants.FAILURE;
		try {
			VehCfgTemplateRequestType objCfgTemplateRequestType = new VehCfgTemplateRequestType();
			if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
					.getConfigFile())) {
				objCfgTemplateRequestType.setConfigFile(objVehicleCfgTemplateVO
						.getConfigFile());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
					.getCustomer())) {
				objCfgTemplateRequestType.setCustomer(objVehicleCfgTemplateVO
						.getCustomer());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
					.getObjId())) {
				objCfgTemplateRequestType.setObjId(objVehicleCfgTemplateVO
						.getObjId());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
					.getAssetGrpName())) {
				objCfgTemplateRequestType
						.setAssetGrpName(objVehicleCfgTemplateVO
								.getAssetGrpName());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
					.getAssetNumber())) {
				objCfgTemplateRequestType
						.setAssetNumber(objVehicleCfgTemplateVO
								.getAssetNumber());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
					.getStatus())) {
				objCfgTemplateRequestType.setStatus(objVehicleCfgTemplateVO
						.getStatus());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
					.getTemplate())) {
				objCfgTemplateRequestType.setTemplate(objVehicleCfgTemplateVO
						.getTemplate());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
					.getTitle())) {
				objCfgTemplateRequestType.setTitle(objVehicleCfgTemplateVO
						.getTitle());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
					.getVersion())) {
				objCfgTemplateRequestType.setVersion(objVehicleCfgTemplateVO
						.getVersion());
			}

			if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
					.getUserName())) {
				objCfgTemplateRequestType.setUserName(objVehicleCfgTemplateVO
						.getUserName());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
					.getCustomerId())) {
				objCfgTemplateRequestType.setCustomerId(objVehicleCfgTemplateVO
						.getCustomerId());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
                    .getVehStatusObjId())) {
                objCfgTemplateRequestType.setVehStatusObjId(objVehicleCfgTemplateVO
                        .getVehStatusObjId());
            }

			result = (String) webServiceInvoker.post(
					ServiceConstants.DELETE_VEHICLE_CFG_TEMPLATE,
					objCfgTemplateRequestType, String.class);
		} catch (Exception ex) {
			result = AppConstants.FAILURE;
			rmdWebLogger
					.error("Exception occured in deleteVehicleCfgTemplate method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @Author :
	 * @return :List<String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for getting vehicle configs from
	 *               LookUp Table .
	 * 
	 */

	@Override
	public List<String> getConfigFiles() throws RMDWebException {
		List<String> arlconfigs = new ArrayList<String>();
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		try {
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.DELETE_CONFIG_TYPE);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			for (int i = 0; i < applParamResponseType.length; i++) {
				arlconfigs.add(applParamResponseType[i].getLookupValue());
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getConfigFiles method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlconfigs;
	}

	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching controller configs
	 * 
	 */
	@Override
	public Map<String, String> getControllerConfigs() throws RMDWebException {
		rmdWebLogger
				.debug("VehicleCfgServiceImpl : Inside getControllerConfigs() method:::::START");
		Map<String, String> cntrlCnfgMap = new LinkedHashMap<String, String>();
		try {
			CtrlCfgResponseType[] objCtrlCfgResponseType = (CtrlCfgResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_CONTROLLER_CONFIGURATIONS, null,
							null, null, CtrlCfgResponseType[].class);
			if (null != objCtrlCfgResponseType) {
				for (int i = 0; i < objCtrlCfgResponseType.length; i++) {
					cntrlCnfgMap.put(
							objCtrlCfgResponseType[i].getCtrlCfgObjId(),
							objCtrlCfgResponseType[i].getCtrlCfgName());
				}
			}
			objCtrlCfgResponseType = null;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getControllerConfigs method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return cntrlCnfgMap;
	}

	/**
	 * @Author :
	 * @return :List<VehicleCfgTemplateVO>
	 * @param : String,String
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching controller configs
	 *               templates
	 * 
	 */
	@Override
	public List<VehicleCfgTemplateVO> getControllerConfigTemplates(
			String cntrlCnfg, String cnfgFile) throws RMDWebException {
		VehCfgTemplateResponseType[] objVehCfgTemplateResponseType = null;
		List<VehicleCfgTemplateVO> objVehicleCfgTemplateVO = null;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		VehicleCfgTemplateVO vehicleCfgTemplateVO = null;
		try {
			queryParams.put(AppConstants.CONTROLLER_CONFIGURATION, cntrlCnfg);
			queryParams.put(AppConstants.CONFIGURATION_FILE, cnfgFile);
			objVehCfgTemplateResponseType = (VehCfgTemplateResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_CONTROLLER_CONFIGURATION_TEMPLATES,
							null, queryParams, null,
							VehCfgTemplateResponseType[].class);
			if (null != objVehCfgTemplateResponseType
					&& objVehCfgTemplateResponseType.length > 0) {
				objVehicleCfgTemplateVO = new ArrayList<VehicleCfgTemplateVO>(objVehCfgTemplateResponseType.length);
				for (VehCfgTemplateResponseType vehCfgTemplateResponseType : objVehCfgTemplateResponseType) {
					vehicleCfgTemplateVO = new VehicleCfgTemplateVO();
					vehicleCfgTemplateVO.setObjId(vehCfgTemplateResponseType
							.getObjId());
					vehicleCfgTemplateVO
							.setConfigFile(vehCfgTemplateResponseType
									.getConfigFile());
					vehicleCfgTemplateVO
							.setCntrlCnfg(vehCfgTemplateResponseType
									.getCntrlCnfg());
					vehicleCfgTemplateVO.setStatus(vehCfgTemplateResponseType
							.getStatus());
					vehicleCfgTemplateVO.setTemplate(vehCfgTemplateResponseType
							.getTemplate());
					vehicleCfgTemplateVO.setTitle(ESAPI.encoder()
							.decodeForHTML(
									vehCfgTemplateResponseType.getTitle()));
					vehicleCfgTemplateVO.setVersion(vehCfgTemplateResponseType
							.getVersion());
					objVehicleCfgTemplateVO.add(vehicleCfgTemplateVO);
				}
			}
			objVehCfgTemplateResponseType=null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getControllerConfigTemplates() method - VehicleCfgServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}

		return objVehicleCfgTemplateVO;
	}
	/**
	 * @Author :
	 * @return :String
	 * @param : List<VehicleCfgTemplateVO>
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for Deleting vehicle
	 *               Configuration Template.
	 * 
	 */
	@Override
	public String deleteVehicleCfg(
			List<VehicleCfgTemplateVO> vehicleCfgTemplateVOList)
			throws RMDWebException {
		String result = AppConstants.FAILURE;
		List<VehCfgTemplateRequestType> vehCfgTemplateRequestTypeList = new ArrayList<VehCfgTemplateRequestType>();
		VehCfgTemplateRequestType objVehCfgTemplateRequestType = new VehCfgTemplateRequestType();
		try {
			if (!vehicleCfgTemplateVOList.isEmpty()) {
				for (VehicleCfgTemplateVO objVehicleCfgTemplateVO : vehicleCfgTemplateVOList) {
					VehCfgTemplateRequestType vehCfgTemplateRequestType = new VehCfgTemplateRequestType();

					if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
							.getObjId())) {
						vehCfgTemplateRequestType
								.setObjId(objVehicleCfgTemplateVO.getObjId());
					}
					if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
							.getCntrlCnfg())) {
						vehCfgTemplateRequestType
								.setCntrlCnfg(objVehicleCfgTemplateVO
										.getCntrlCnfg());
					}
					if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
							.getConfigFile())) {
						vehCfgTemplateRequestType
								.setConfigFile(objVehicleCfgTemplateVO
										.getConfigFile());
					}
					if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
							.getTemplate())) {
						vehCfgTemplateRequestType
								.setTemplate(objVehicleCfgTemplateVO
										.getTemplate());
					}
					if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
							.getVersion())) {
						vehCfgTemplateRequestType
								.setVersion(objVehicleCfgTemplateVO
										.getVersion());
					}
					if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
							.getTitle())) {
						vehCfgTemplateRequestType
								.setTitle(objVehicleCfgTemplateVO.getTitle());
					}
					if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
							.getStatus())) {
						vehCfgTemplateRequestType
								.setStatus(objVehicleCfgTemplateVO.getStatus());
					}
					if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
							.getCustomer())) {
						vehCfgTemplateRequestType
								.setCustomer(objVehicleCfgTemplateVO
										.getCustomer());
					}

					if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
							.getAssetGrpName())) {
						vehCfgTemplateRequestType
								.setAssetGrpName(objVehicleCfgTemplateVO
										.getAssetGrpName());
					}
					if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
							.getAssetNumber())) {
						vehCfgTemplateRequestType
								.setAssetNumber(objVehicleCfgTemplateVO
										.getAssetNumber());
					}
					if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
							.getUserName())) {
						vehCfgTemplateRequestType
								.setUserName(objVehicleCfgTemplateVO
										.getUserName());
					}
					vehCfgTemplateRequestTypeList
							.add(vehCfgTemplateRequestType);
				}
				objVehCfgTemplateRequestType
						.setArrVehCfgTemplateRequestType(vehCfgTemplateRequestTypeList);
				result = (String) webServiceInvoker.post(
						ServiceConstants.DELETE_VEHICLE_CFG,
						objVehCfgTemplateRequestType, String.class);
			}
		} catch (Exception ex) {
			result = AppConstants.FAILURE;
			rmdWebLogger.error("Exception occured in deleteVehicleCfg method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}
	@Override
	public Map<String, String> getLookupValueTooltip() throws RMDWebException {
		rmdWebLogger
				.debug("VehicleCfgServiceImpl : Inside getLookupValueTooltip() method:::::START");
		Map<String, String> LookupValueMap = new LinkedHashMap<String, String>();
		try {
			 ApplicationParametersResponseType[] arrResponseType = (ApplicationParametersResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_LOOKUP_VALUE_TOOLTIP, null,
							null, null, ApplicationParametersResponseType[].class);
			if (null != arrResponseType) {
				for (int i = 0; i < arrResponseType.length; i++) {
					LookupValueMap.put(
							arrResponseType[i].getLookupValue(),
							ESAPI.encoder().decodeForHTML(arrResponseType[i].getLookValueDesc()));
				}
			}
			arrResponseType = null;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLookupValueTooltip method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return LookupValueMap;
	}
	
	/**
     * @Author :
     * @return :String
     * @param : VehicleCfgTemplateVO
     * @throws :RMDWebException
     * @Description: This method is Responsible for Re Applying vehicle
     *               Configuration Template.
     * 
     */
    @Override
    public String reApplyTemplate(
            VehicleCfgTemplateVO objVehicleCfgTemplateVO)
            throws RMDWebException {
        String result = AppConstants.FAILURE;
        try {
            VehCfgTemplateRequestType objCfgTemplateRequestType = new VehCfgTemplateRequestType();
            if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
                    .getConfigFile())) {
                objCfgTemplateRequestType.setConfigFile(objVehicleCfgTemplateVO
                        .getConfigFile());
            }
            if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
                    .getCustomer())) {
                objCfgTemplateRequestType.setCustomer(objVehicleCfgTemplateVO
                        .getCustomer());
            }
            if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
                    .getObjId())) {
                objCfgTemplateRequestType.setObjId(objVehicleCfgTemplateVO
                        .getObjId());
            }
            if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
                    .getAssetGrpName())) {
                objCfgTemplateRequestType
                        .setAssetGrpName(objVehicleCfgTemplateVO
                                .getAssetGrpName());
            }
            if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
                    .getAssetNumber())) {
                objCfgTemplateRequestType
                        .setAssetNumber(objVehicleCfgTemplateVO
                                .getAssetNumber());
            }
            if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
                    .getStatus())) {
                objCfgTemplateRequestType.setStatus(objVehicleCfgTemplateVO
                        .getStatus());
            }
            if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
                    .getTemplate())) {
                objCfgTemplateRequestType.setTemplate(objVehicleCfgTemplateVO
                        .getTemplate());
            }
            if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
                    .getTitle())) {
                objCfgTemplateRequestType.setTitle(objVehicleCfgTemplateVO
                        .getTitle());
            }
            if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
                    .getVersion())) {
                objCfgTemplateRequestType.setVersion(objVehicleCfgTemplateVO
                        .getVersion());
            }

            if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
                    .getUserName())) {
                objCfgTemplateRequestType.setUserName(objVehicleCfgTemplateVO
                        .getUserName());
            }
            if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
                    .getCustomerId())) {
                objCfgTemplateRequestType.setCustomerId(objVehicleCfgTemplateVO
                        .getCustomerId());
            }
            if (!RMDCommonUtility.isNullOrEmpty(objVehicleCfgTemplateVO
                    .getVehStatusObjId())) {
                objCfgTemplateRequestType.setVehStatusObjId(objVehicleCfgTemplateVO
                        .getVehStatusObjId());
            }

            result = (String) webServiceInvoker.post(
                    ServiceConstants.RE_APPLY_TEMPLATE,
                    objCfgTemplateRequestType, String.class);
        } catch (Exception ex) {
            result = AppConstants.FAILURE;
            rmdWebLogger
                    .error("Exception occured in reApplyTemplate method ",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return result;
    }

    /**
     * @Author :
     * @return :String
     * @param : String vehStatusObjId,String userId
     * @throws :RMDWebException
     * @Description: This method is Responsible for re notify vehicle
     *               Configuration Template.
     * 
     */
    @Override
    public String reNotifyTemplateAssociation(String vehStatusObjId,
            String userId) throws RMDWebException {
        String result = RMDCommonConstants.EMPTY_STRING;
        Map<String, String> queryParams = null;
        try{
            queryParams = new LinkedHashMap<String, String>();
            queryParams.put(AppConstants.VEH_STATUS_OBJID, vehStatusObjId);
            queryParams.put(AppConstants.USER_ID, userId);
           
            result = (String) webServiceInvoker
                    .get(ServiceConstants.RE_NOTIFY_TEMPLATE_ASSOCIATION, null,
                            queryParams, null,
                            String.class);
            
        
        }catch (Exception ex) {
            result = AppConstants.FAILURE;
            rmdWebLogger
                    .error("Exception occured in reNotifyTemplateAssociation method ",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        
        return result;
    }

}
