package com.ge.trans.rmd.cm.mvc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.LDVRAssetPQService;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.pp.beans.AssetBean;

@Controller
@SessionAttributes
public class LDVRAssetPQController extends RMDBaseController {

    @Autowired
    private LDVRAssetPQService ldvrAssetPQService;

    private final RMDWebLogger rmdWebLogger = RMDWebLogger
            .getLogger(getClass());

    @RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_ASSET_PQ, method = RequestMethod.GET)
    public ModelAndView getLDVRManageAssetPQPage(
            final HttpServletRequest request) throws RMDWebException {
        return new ModelAndView(AppConstants.VIEW_LDVR_ASSET_PQ);
    }

    /**
     * 
     * @param customerId
     * @param assetGroup
     * @param assetNumber
     * @param request
     * @param model
     * @return
     * @Description This method will return the list of asset numbers for given
     *              keys like customerId, assetGroup and asset number
     */
    @RequestMapping(value = AppConstants.REQ_URI_GETSOLASSETNUMPRODUCT, method = RequestMethod.GET)
    public @ResponseBody java.util.List<String> getAssetsProducts(
            @RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId,
            @RequestParam(value = AppConstants.CREATCASE_ASSTGRP, required = true) final String assetGroup,
            @RequestParam(value = AppConstants.ASSET_NUMBER, required = true) final String assetNumber,
            @RequestParam(value = AppConstants.FLEET) final String fleet,
            final HttpServletRequest request, final Model model)
            throws RMDWebException {
        rmdWebLogger
                .debug("Inside LDVRAssetPQController in getAssetsProducts Method");
        List<String> assetNumbers = null;
        AssetBean assetBean;
        final HttpSession session = request.getSession(false);
        final UserVO userVO = (UserVO) session
                .getAttribute(AppConstants.ATTR_USER_OBJECT);
        try {

            assetBean = new AssetBean();
            assetBean.setUserFirstName(userVO.getStrFirstName());
            assetBean.setUserLastName(userVO.getStrLastName());
            assetBean.setUserId(userVO.getUserId());
            assetBean.setUserLanguage(userVO.getStrUserLanguage());
            assetBean.setCustomerId(customerId);
            assetBean.setAssetGroup(assetGroup);
            assetBean.setAssetNumber(assetNumber);
            assetBean.setFleetId(fleet);
            if (null != userVO.getProducts() && !userVO.getProducts().isEmpty()) {
                assetBean.setProducts(userVO.getProducts());
            }
            assetNumbers = ldvrAssetPQService.getAssetProducts(assetBean);

        } catch (Exception ex) {
            rmdWebLogger.error("Exception occured in getAssetNumbers method ",
                    ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return assetNumbers;

    }

    @RequestMapping(value = AppConstants.GET_ASSET_LIS_PRODUCTS)
    @ResponseBody
    public List<String> getAssetListProducts(
            @RequestParam(value = AppConstants.CUSTOMER_ID) final String customerId,
            @RequestParam(value = AppConstants.FLEET) final String fleet,
            @RequestParam(value = AppConstants.ASSET_GROUP_NAME) final String assetGrpName,
            @RequestParam(value = AppConstants.FROM_ROAD_NUMBER) final String fromRoadNumber,
            @RequestParam(value = AppConstants.TO_ROAD_NUMBER) final String toRoadNumber,
            final HttpServletRequest request) throws RMDWebException {
            rmdWebLogger
                .debug("Inside LDVRAssetPQController in getAssetsProducts Method");
        List<String> assetNumbers = null;
        AssetBean assetBean;
        final HttpSession session = request.getSession(false);
        final UserVO userVO = (UserVO) session
                .getAttribute(AppConstants.ATTR_USER_OBJECT);
        try {

            assetBean = new AssetBean();
            assetBean.setUserFirstName(userVO.getStrFirstName());
            assetBean.setUserLastName(userVO.getStrLastName());
            assetBean.setUserId(userVO.getUserId());
            assetBean.setUserLanguage(userVO.getStrUserLanguage());
            assetBean.setCustomerId(customerId);
            assetBean.setAssetGroup(assetGrpName);
            assetBean.setFromAssetNumber(fromRoadNumber);
            assetBean.setToAssetNumber(toRoadNumber);
            assetBean.setFleetId(fleet);
            if (null != userVO.getProducts() && !userVO.getProducts().isEmpty()) {
                assetBean.setProducts(userVO.getProducts());
            }
            assetNumbers = ldvrAssetPQService.getAssetsProductList(assetBean);
        } catch (Exception exception) {
            rmdWebLogger.error("Exception occured in getAssetList() method ",
                    exception);
            RMDWebErrorHandler.handleException(exception);
        }
        return assetNumbers;
    }

}
