package com.ge.trans.rmd.cm.service;


import java.util.List;
import java.util.Map;

import com.ge.trans.eoa.services.security.service.valueobjects.UserServiceVO;
import com.ge.trans.rmd.alert.valueobjects.ModelVO;
import com.ge.trans.rmd.cm.valueobjects.RxChangeAdminVO;
import com.ge.trans.rmd.cm.valueobjects.RxChangeSearchVO;
import com.ge.trans.rmd.cm.valueobjects.RxChangeVO;
import com.ge.trans.rmd.common.beans.RxChangeBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.vo.CustomerVO;
import com.ge.trans.rmd.common.vo.UserVO;


/**
 * @author 212338353
 *
 */
public interface RxChangeService {
    /**
     * To populate Rx change request for GPOC/non GPOC user
     * @param rxChangeSearchVO
     * @return
     * @throws RMDWebException
     */
    public List<RxChangeVO> getRxChangeOverviewData(RxChangeSearchVO rxChangeSearchVO) throws RMDWebException;     
    public Map<String, String> getCustomerDetails(String userID) throws RMDWebException;
    public Map<String, String> getModelDetails(String customerId) throws RMDWebException;
    public Map<String, String> getRxTitles(String strSearchString,String modelId) throws RMDWebException;
    public Map<String, String> getRoadNumbers(String customerId, String modelId, String searchString) throws RMDWebException;
    public boolean getCaseId(String userId, String searchString) throws RMDWebException;
    public String saveRxChangeReqDetails(RxChangeBean rxChangeBean) throws RMDWebException;
    public Map<String, String> getRequestorDetails(String fName, String lName, String userId) throws RMDWebException;
            
    public Map<String, String> getRxChangeLookUp(String listName) throws RMDWebException;    
    /**
     * To populate Model based on RxTitle
     * @param rxChangeSearchVO
     * @return
     * @throws RMDWebException
     * @throws Exception
     */
    List<ModelVO> getModelForRxTitle(RxChangeSearchVO rxChangeSearchVO) throws RMDWebException; 
    /**
     * To save/update RxChange Admin changes
     * @param rxChangeAdminVO
     * @return
     * @throws RMDWebException
     * @throws Exception
     */
    public String saveUpdateRxChangeAdminDetails(RxChangeAdminVO rxChangeAdminVO) throws RMDWebException;
	   /**
	    * To populate Rxchange Admin information Saved in Draft version
	    * @param rxChangeSearchVO
	    * @return
	    * @throws RMDWebException
	    * @throws Exception
	    */
    public RxChangeAdminVO getRxChangeAdminData(RxChangeSearchVO rxChangeSearchVO) throws RMDWebException;
    
    /**
     * 
     * @param rxChangeSearchVO
     * @return
     * @throws RMDWebException
     * @throws Exception
     */
    List<CustomerVO> getCustomerForModel(String model) throws RMDWebException;
    List<UserServiceVO> getRxChangeAdminUsers() throws RMDWebException;
    String getAdminEmailIdStr() throws RMDWebException;
    
    /**
     * @param rxChngObjid
     * @param string 
     * @return
     * @throws RMDWebException
     */
    List<RxChangeVO> getRxChangeAuditTrailInfo(String rxChngObjid, String string) throws RMDWebException;
    
    /**
     * @param Customer, Fleet,RoadNumberHeader,RoadNumber
     * @param String
     * @return Model name and General
     * @throws RMDWebException
     */
    public Map<String, String> getModelForTechnicianScreen(String customer,String fleet,String rnh,String assetList) throws RMDWebException;
 }
