/**
 * ============================================================
 * Classification: GE Confidential
 * File : AssetDataScreenServiceImpl.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.cm.service;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on : February 14, 2012
 * History
 * Modified By : iGATE
 *
 * Copyright (C) 2012 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.beans.AssetFaultDataBean;
import com.ge.trans.rmd.cm.mvc.model.ColModel;
import com.ge.trans.rmd.cm.mvc.model.GridMetaData;
import com.ge.trans.rmd.cm.mvc.model.HeatMap;
import com.ge.trans.rmd.cm.mvc.model.LatestCases;
import com.ge.trans.rmd.cm.mvc.model.RuleBean;
import com.ge.trans.rmd.cm.valueobjects.AssetDataResponseVO;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.MetricsConversionUtil;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.pp.beans.MetricsBean;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.FaultDataDetailsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.FaultDetailsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.FaultLogServiceResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ToolParamInfoResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ToolsParamGroupResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.LatestCaseRuleRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.ToolOutputDetailsResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.UnitConfigResponseType;

@Service
public class AssetDataScreenServiceImpl extends RMDBaseServiceImpl implements
		AssetDataScreenService {

	@Autowired
	private	WebServiceInvoker rsInvoker;
	@Autowired
	private AssetFaultService assetService;
	@Autowired
	private CachedService cachedService;
	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());
	final private static String INCIDENT = "INCIDENT";
	final private static String FAULT_STRATEGY_ID = "FaultStrategyID";
	final private static String PROXIMITY_DESC = "proximityDesc";

	/**
	 * @throws RMDWebException
	 *             This Method is used for calling Web Service and get list of
	 *             FaultDataDetailsResponseType parameters passed in
	 *             assetFaultDataBean
	 * 
	 * @param assetFaultDataBean
	 * @return GridMetaData
	 * 
	 */
	public GridMetaData getAssetMetaData(final AssetFaultDataBean assetFaultDataBean, final String userCustomer)
			throws RMDWebException, Exception {

		final long startTime = System.currentTimeMillis();
		final List<String> columHeader = new ArrayList<String>();
		final List<ColModel> columModel = new ArrayList<ColModel>();
		final Map<String, String> grupCounts = new HashMap<String, String>();
		final Map<String, String> groupColors = new HashMap<String, String>();
		final List<String> groupNames = new ArrayList<String>();		
		final GridMetaData assetMetaData = new GridMetaData();
		FaultDataDetailsResponseType objFaultDataDetails = null;

		try {
			// Added for Data Screen: Display Data dropdown --Rajesh,iGATE Patni
			objFaultDataDetails = (FaultDataDetailsResponseType) assetService.getAssetFaultDetails(assetFaultDataBean, userCustomer);
			
			
			if (null != objFaultDataDetails) {
				assetMetaData.setResponseObject(objFaultDataDetails);
				final List<ToolParamInfoResponseType> headerList = objFaultDataDetails.getHeader();
				final List<ToolsParamGroupResponseType> groupList = objFaultDataDetails.getGrpheader();
				for (ToolParamInfoResponseType headerName : headerList) {
					columHeader.add(headerName.getHeaderHtml());
					final ColModel cm1 = new ColModel();
					cm1.setCharLength(headerName.getCharLength());
					cm1.setName(headerName.getColumnName());
					cm1.setIndex(headerName.getColumnName());
					cm1.setWidth((int) Float.parseFloat(headerName.getHeaderWidth()));
					if (headerName.getColumnName() != null && "REC_TYPE".equals(headerName.getColumnName().trim())
							&& assetFaultDataBean.getDataSet() != null && INCIDENT.equals(assetFaultDataBean.getDataSet().trim())) {
						cm1.setWidth((int)(Float.parseFloat(headerName.getHeaderWidth()) + 10));
					}
					cm1.setHeaderName(headerName.getHeaderHtml());
					if (userCustomer != null && userCustomer.equalsIgnoreCase(RMDCommonConstants.ARZN)) {    
						if ("BASIC_CCOP".equals(headerName.getColumnName())) {
							cm1.setWidth((cm1.getWidth() + 16));
						} else if ("BASIC_MAT".equals(headerName.getColumnName()) || "BASIC_PTLT".equals(headerName.getColumnName()) 
								|| "BASIC_PTRT".equals(headerName.getColumnName())) {
							cm1.setWidth((cm1.getWidth() + 11));
						} else {
							cm1.setWidth((cm1.getWidth() + 4));
						}
					}
					if (headerName.getColumnName() != null && "FAULT_CLASSIFICATION".equals(headerName.getColumnName().trim())) {
						cm1.setHeaderName("C&nbspF<br>r&nbsp&nbspa<br>i&nbsp&nbsp&nbspu<br>t&nbsp&nbsp&nbspl<br>i&nbsp&nbsp&nbspt<br>" +
								"c&nbsp&nbsp<br>a&nbsp&nbsp<br>l&nbsp&nbsp");
					}					
					cm1.setStyle(headerName.getStyle());
					if (headerName.getDataTooltipFlag() != null && !"".equals(headerName.getDataTooltipFlag().trim())) {
						cm1.setDataToolTipFlag(headerName.getDataTooltipFlag());
					}
					if (headerName.getToolTip() != null && !"".equals(headerName.getToolTip().trim())) {
						cm1.setToolTip(headerName.getToolTip());						
					}					
					if (headerName.getLowerBound() != null && !"0.0".equals(headerName.getLowerBound().trim())) {
						cm1.setLowerBound(headerName.getLowerBound());
					}
					if (headerName.getUpperBound() != null && !"0.0".equals(headerName.getUpperBound().trim())) {
						cm1.setUpperBound(headerName.getUpperBound());
					}
					if (headerName.getFilter() != null) {
						cm1.setFilter(headerName.getFilter());
					}
					if (null != headerName.getStyle() && headerName.getStyle().equalsIgnoreCase(AppConstants.FREEZE_STYLE_FIXED)) {
						cm1.setFrozen(true);
					}
					columModel.add(cm1);
				}

				for (ToolsParamGroupResponseType groupName : groupList) {
					logger.debug("HeaderHtml" + groupName.getParamGroup());
					groupNames.add(groupName.getParamGroup());
					grupCounts.put(groupName.getParamGroup(), groupName.getColspan());
					groupColors.put(groupName.getParamGroup(), groupName.getStyle());
				}
				assetMetaData.setUnitConversionRoleList(objFaultDataDetails.getUnitConversionRoleList());
			}
		} 
		catch (Exception ex) {
			
			logger.error("Exception occured in getAssetMetaData method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}

		assetMetaData.setColumHeader(columHeader);
		assetMetaData.setColumModel(columModel);
		assetMetaData.setGrupCounts(grupCounts);
		assetMetaData.setGrupColors(groupColors);
		assetMetaData.setGroupNames(groupNames);
		final long endTime = System.currentTimeMillis();
		logger.debug("############ Class: AssetDataScreenServiceImpl - Method: getAssetMetaData() >> START TIME: "
				+ startTime
				+ "ms  END TIME: "
				+ endTime
				+ "ms WS + Header part Difference: "
				+ (endTime - startTime)
				+ "ms");
		return assetMetaData;
	}

	/**
	 * @throws RMDWebException
	 *             ,Exception This Method is used for returning
	 *             AssetDataResponseVO with the heat map and other required data
	 *             parameters passed in assetFaultDataBean
	 * 
	 * @param assetFaultDataBean
	 * @return AssetDataResponseVO
	 * 
	 */
	
	
	public AssetDataResponseVO getAssetFaultData(
			final AssetFaultDataBean assetFaultDataBean, final String userCustomer)
			throws RMDWebException, Exception {
		final long startTime = System.currentTimeMillis();
		AssetDataResponseVO objAssetDataResponse = new AssetDataResponseVO();
		List<Map<String, String>> lsFaultAssetValuePart = null;
		lsFaultAssetValuePart = new ArrayList<Map<String, String>>();
		GridMetaData objGridMetaData = getAssetMetaData(assetFaultDataBean, userCustomer) ;
		List<String> unitConversionRoleList = null;
		if(objGridMetaData != null){
			unitConversionRoleList = objGridMetaData.getUnitConversionRoleList();
		}
		if (assetFaultDataBean.getDataSet() != null && "CASE".equals(assetFaultDataBean.getDataSet().trim())
				&& assetFaultDataBean.getCaseType() != null && "Oil Anomaly".equals(assetFaultDataBean.getCaseType().trim())) {
			objAssetDataResponse.setOilCase("Y");
		}
		Map<String, String> dateFormatCols = getLookupValueList("DATA_SCREEN_DATEFORMAT_COL");
		boolean formatDateAndDeg = false;
		DateFormat dateFormatter = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS.replaceAll("yyyy", "yy"));
		DateFormat custDateFormatter = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS.replaceAll("yyyy", "yy"));
		NumberFormat numFormat = NumberFormat.getInstance();
		numFormat.setMaximumFractionDigits(5);
		if (cachedService.getSDCustLookup().get(userCustomer) != null
                && cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
                && !"".equals(cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim())) {
			formatDateAndDeg = true;
			custDateFormatter = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat().replaceAll("yyyy", "yy"));
        }
		if (cachedService.getSDCustLookup().get(userCustomer) != null
                && cachedService.getSDCustLookup().get(userCustomer).getFamPrivilege() != null
                && "Y".equals(cachedService.getSDCustLookup().get(userCustomer).getFamPrivilege().trim())) {
			objAssetDataResponse.setFlagFAM("Y");			
        }
		ColModel[] colModelTemp = null;
		String headerName = null;
		
		final List<HeatMap> heatmaps = new ArrayList<HeatMap>();
		
		List<String> deviceList = getNoOfDaysDropdownValues("HPEAP_DEVICE");
		List<MetricsBean> metricsValue = cachedService.getMetricsConversion();
		Map<String, String> fromUnit = new HashMap<String, String>();
		Map<String, String> toUnit = new HashMap<String, String>();
		if (metricsValue != null && !metricsValue.isEmpty()) {
			for (int i = 0; i < metricsValue.size(); i++) {
				if (metricsValue.get(i).getCustomerName().equals(userCustomer) &&
						"DATASCREEN".equals(metricsValue.get(i).getScreenName()) &&
						"Y".equals(metricsValue.get(i).getConvReq())) {
					fromUnit.put(metricsValue.get(i).getColumnName().toUpperCase(), metricsValue.get(i).getFromUnit());
					toUnit.put(metricsValue.get(i).getColumnName().toUpperCase(), metricsValue.get(i).getToUnit());
				}
			}
		}
		
		final List<ColModel> colModels = objGridMetaData.getColumModel();		 
		if (objGridMetaData != null) {
			List<ColModel> UXColModel = new ArrayList<ColModel>();
			List<String> colHeader = new ArrayList<String>();
			for (int i = 0; i < colModels.size(); i++) {
				if (fromUnit.get((colModels.get(i)).getIndex().toUpperCase()) != null) {
                    			(colModels.get(i)).setWidth((colModels.get(i)).getWidth() + 10);
                		}
				UXColModel.add(colModels.get(i));
				colHeader.add(colModels.get(i).getHeaderName());
			}
			objAssetDataResponse.setColModel(UXColModel);
			objAssetDataResponse.setColHeader(colHeader);
			objAssetDataResponse.setGrupCounts(objGridMetaData.getGrupCounts());
			objAssetDataResponse.setGroupColors(objGridMetaData.getGrupColors());
			objAssetDataResponse.setGroupNames(objGridMetaData.getGroupNames());
			if (objGridMetaData.getResponseObject() != null) {
				if (objGridMetaData.getResponseObject().getCtrlCfg() != null) {
					objAssetDataResponse.setControllerCfg(objGridMetaData.getResponseObject().getCtrlCfg());
				}
				if (objGridMetaData.getResponseObject().getPartStatus() != null) {
					objAssetDataResponse.setPartStatus(objGridMetaData.getResponseObject().getPartStatus());
				}
				if (objGridMetaData.getResponseObject().getCaseSortOrder() != null) {
					objAssetDataResponse.setCaseDefaultSortOrder(objGridMetaData.getResponseObject().getCaseSortOrder());
				}
				if (objGridMetaData.getResponseObject().getCaseLookBackDays() != null) {
					objAssetDataResponse.setCaseDefaultDays(objGridMetaData.getResponseObject().getCaseLookBackDays());
				}
				if (objGridMetaData.getResponseObject().getRecordsTotal() != null) {
					objAssetDataResponse.setRecordsTotal(objGridMetaData.getResponseObject().getRecordsTotal());
				}
			}
		}
		
		final List<FaultLogServiceResponseType> faultDataResponse = objGridMetaData
			.getResponseObject().getFaultDataResponse().getFaultdata();
		try {
			if (objGridMetaData != null) {
				Map<String, String> lsFaultAssetValueTempMap = null;
				String paramDataWholeString = AppConstants.EMPTY_STRING;
				String paramDataValue = null;
				ColModel colModel = null;
				FaultDetailsResponseType faultDetailsResponseType = null;
				FaultLogServiceResponseType faultLogService = null;

				for (int iValue = 0; iValue < faultDataResponse.size(); iValue++) {
					faultLogService = faultDataResponse.get(iValue);
					final List<FaultDetailsResponseType> faultDetailsResponse = faultLogService.getLstFaultdataDetails();
					lsFaultAssetValueTempMap = new HashMap<String, String>();
					
					for (int i = 0; i < faultDetailsResponse.size(); i++) {
						int allowedChars = 0;
						faultDetailsResponseType = faultDetailsResponse.get(i);
						if (colModels != null && !colModels.isEmpty() && i < colModels.size()) {
							colModel = colModels.get(i);
							colModelTemp =  colModels.toArray(new ColModel[colModels.size()]);								
						}
						if (colModelTemp != null && i < colModels.size()) {
							headerName = colModelTemp[i].getName();			
						} else if (i == colModels.size() 
								&& assetFaultDataBean.getDataSet().trim().indexOf("CASE") == -1) {
							headerName = FAULT_STRATEGY_ID;
						} else if (i == colModels.size() 
								&& !assetFaultDataBean.isLimitedParam()
								&& assetFaultDataBean.getDataSet().trim().indexOf("CASE") > -1) {
							headerName = FAULT_STRATEGY_ID;
						} else if (i == (colModels.size() + 1) && !assetFaultDataBean.isLimitedParam()
								&& assetFaultDataBean.getDataSet().trim().indexOf("CASE") == -1) {
							headerName = PROXIMITY_DESC;
						} else if (i == (colModels.size() + 1) && !assetFaultDataBean.isLimitedParam()
								&& assetFaultDataBean.getDataSet().trim().indexOf("CASE") > -1 && assetFaultDataBean.getDataSet().trim().indexOf("OIL") == -1) {
							headerName = PROXIMITY_DESC;
						} else if (i == (colModels.size() + 2) && assetFaultDataBean.isLimitedParam()
								&& "VEHICLE".equals(assetFaultDataBean.getDataSet().trim())) {
							headerName = "faultOrigin";
						} else {
							if(lsFaultAssetValueTempMap != null && (lsFaultAssetValueTempMap.containsKey("faultOrigin") /*|| 
									lsFaultAssetValueTempMap.containsKey(FAULT_STRATEGY_ID)*/ || lsFaultAssetValueTempMap.containsKey(PROXIMITY_DESC))){
								break;
							}
						}
						if (headerName != null && (headerName.toLowerCase().indexOf("desc") > -1 
								|| headerName.toLowerCase().indexOf("event_data") > -1)
								&& colModelTemp != null && (i < colModels.size())) {
							allowedChars = Integer.parseInt(colModelTemp[i].getCharLength());
						}
						if (faultDetailsResponseType != null && faultDetailsResponseType.getParamData() != null)
							paramDataWholeString = faultDetailsResponseType.getParamData().trim();
						if(assetFaultDataBean.isHeatMap()){
							HeatMap heat = new HeatMap();
													
							if (paramDataWholeString != null
									&& paramDataWholeString.indexOf(AppConstants.HIGER_HEATMAP) > -1) {
								heat.setClassName(AppConstants.HEATMAP_UPPER_LIMIT);
								heat.setCellId(headerName);
								heat.setRowId(AppConstants.EMPTY_STRING + iValue);
								heatmaps.add(heat);
							}
							if (paramDataWholeString != null
									&& paramDataWholeString.indexOf(AppConstants.LOWER_HEATMAP) > -1) {
								heat.setClassName(AppConstants.HEATMAP_LOWER_LIMIT);
								heat.setCellId(headerName);
								heat.setRowId(AppConstants.EMPTY_STRING + iValue);
								heatmaps.add(heat);
							}
						}
						if (paramDataWholeString == null || AppConstants.EMPTY_STRING.equalsIgnoreCase(paramDataWholeString)) {
							paramDataValue = AppConstants.EMPTY_STRING;
						} else {
							final int index = paramDataWholeString.indexOf(AppConstants.CARAT);
							if (index > -1) {
								paramDataValue = paramDataWholeString.substring(0, index);
								if (paramDataWholeString.contains(AppConstants.DATE_FORMATTER_DATA_SCREEN)) {
									String strTempDate = AppConstants.EMPTY_STRING;
									String strDate = AppConstants.EMPTY_STRING;
									String strTime = AppConstants.EMPTY_STRING;
									try {
										strTempDate = RMDCommonUtil.convertTimeInto24HrFormat(paramDataValue);
									} catch (ParseException e) {
										logger.error("Error while converting date in 24 hr format "
												+ e.getMessage());
									}
									if (strTempDate != null	&& !AppConstants.EMPTY_STRING.equalsIgnoreCase(strTempDate)) {
										strDate = strTempDate.substring(0, 10);
										strTime = strTempDate.substring(11, 19);
									}
									paramDataValue = "<div class=\"datepart\"><span>"
											+ strDate
											+ "</span><br><span class=\"greycolortext\">"
											+ strTime + "</span></div>";
								} else if(objAssetDataResponse.getOilCase() != null 
										&& "Y".equals(objAssetDataResponse.getOilCase().trim())) {
									paramDataValue = paramDataWholeString.substring(0, index);
									String toolTip = paramDataWholeString.substring(index, paramDataWholeString.length());
									if (toolTip != null && !"".equals(toolTip.trim())) {
										toolTip = paramDataWholeString.substring(index, paramDataWholeString.length()).replace(Character.toString(AppConstants.CARAT), "");
										paramDataValue = toolTip + AppConstants.CARAT + paramDataValue;
									}
								} 
							} else {
								paramDataValue = paramDataWholeString;
							}
						}
						if (headerName != null && "DeviceInfo".equals(headerName) 
								&& assetFaultDataBean.getDataSet().trim().indexOf(INCIDENT) == -1) {
							if (deviceList != null && !deviceList.isEmpty()) {
								String equipType = null;
								for (int a = 0; a < deviceList.size(); a++) {
									if (deviceList.get(a).split("~")[0].equals(paramDataValue)) {
										equipType = deviceList.get(a).split("~")[1];
									}
								}
								if (equipType == null) {
									paramDataValue = AppConstants.EMPTY_STRING;
								} else {
									paramDataValue = equipType;
								}
							}
						} else if (headerName != null && "DeviceInfo".equals(headerName) 
								&& assetFaultDataBean.getDataSet().trim().indexOf(INCIDENT) > -1) {
							paramDataValue = paramDataValue.toUpperCase();
						}
						if (!paramDataValue.equals(AppConstants.EMPTY_STRING)) {
							if (allowedChars > 0 && paramDataValue.length() > allowedChars) {
								paramDataValue = paramDataValue.substring(0, allowedChars);
							}
							if (i < colModels.size()) {
								if (formatDateAndDeg && dateFormatCols.get(colModel.getName()) != null) {
									lsFaultAssetValueTempMap.put(colModel.getName(),
											custDateFormatter.format(new Date(dateFormatter.parse(paramDataValue).getTime())));
								} else if (formatDateAndDeg && (colModel.getName().toUpperCase().indexOf("GPS_LAT") > -1 
										|| colModel.getName().toUpperCase().indexOf("GPS_LON") > -1 
										|| colModel.getName().toUpperCase().indexOf("LATITUDE") > -1 
										|| colModel.getName().toUpperCase().indexOf("LONGITUDE") > -1) && paramDataValue.indexOf(":") > -1) {
									String degArray[] = paramDataValue.split(":");
									double deg = Math.abs(Double.parseDouble(degArray[0])) 
										+ (Double.parseDouble(degArray[1]) / 60) + (Double.parseDouble(degArray[2]) / 3600);
									if (degArray[0].indexOf("-") > -1) {
										paramDataValue = "-" + numFormat.format(deg);	
									} else {
										paramDataValue = numFormat.format(deg);
									}
									lsFaultAssetValueTempMap.put(colModel.getName(),
											paramDataValue);
								} else if (fromUnit.get(colModel.getName().toUpperCase()) != null &&
										toUnit.get(colModel.getName().toUpperCase()) != null) {
									if(unitConversionRoleList != null && !unitConversionRoleList.isEmpty() 
											&& unitConversionRoleList.contains(assetFaultDataBean.getRoleName())){
										if (fromUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_MPH) &&
												toUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_KPH) ) {
											paramDataValue = MetricsConversionUtil.getConvertedDistanceVelocity(Float.parseFloat(paramDataValue),
													AppConstants.VIEW_MPH, AppConstants.VIEW_KPH);
										} else if (fromUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_FAHRENHEIT) &&
												toUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_CENTIGRADE) ) {
											paramDataValue = MetricsConversionUtil.getConvertedTemperature(Float.parseFloat(paramDataValue),
													AppConstants.VIEW_FAHRENHEIT, AppConstants.VIEW_CENTIGRADE);
										}  else if (fromUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_HP) &&
												toUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_KW) ) {
											paramDataValue = MetricsConversionUtil.HPToKW(Float.parseFloat(paramDataValue));
										}  else if (fromUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_PSI) &&
												toUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_MMH2O) ) {
											paramDataValue = MetricsConversionUtil.PSIToMMH2O(Float.parseFloat(paramDataValue));
										} else if (fromUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_PSI) &&
												toUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_CMH2O) ) {
											paramDataValue = MetricsConversionUtil.psiToCMH2O(Float.parseFloat(paramDataValue));
										} else if (fromUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_INH2O) &&
												toUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_MMH2O) ) {
											paramDataValue = MetricsConversionUtil.inH2OToMMH2O(Float.parseFloat(paramDataValue));
										} else if (fromUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_PSI) &&
												toUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_KILOPASCAL) ) {
											paramDataValue = MetricsConversionUtil.PSIToKiloPascal(Float.parseFloat(paramDataValue));
										}  else if (fromUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_LBS) &&
												toUnit.get(colModel.getName().toUpperCase()).equals(AppConstants.VIEW_KILONEWTON) ) {
											paramDataValue = MetricsConversionUtil.lbsToKiloNewtons(Float.parseFloat(paramDataValue));
										}
									}
									lsFaultAssetValueTempMap.put(colModel.getName(), paramDataValue);
									
								} else {
									lsFaultAssetValueTempMap.put(colModel.getName(), paramDataValue);
								}
							} else if (i >= colModels.size()) {
								lsFaultAssetValueTempMap.put(headerName, paramDataValue);
							}
						}
					}
					lsFaultAssetValuePart.add(lsFaultAssetValueTempMap);
				}
				objAssetDataResponse.setTotal(Integer.toString((int) Math.ceil(faultDataResponse.size() / 10)));
			}
		} catch (Exception ex) {
			logger.error("Exception occured in getAssetFaultData method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		objAssetDataResponse.setLsFaultAssetValuePart(lsFaultAssetValuePart);

		final HeatMap[] heatmap = heatmaps.toArray(new HeatMap[heatmaps.size()]);
		objAssetDataResponse.setHeatMapData(heatmap);
		final long endTime = System.currentTimeMillis();
		StringBuilder debugLoggerBuilder = new StringBuilder().append("############ Class: AssetDataScreenServiceImpl - Method: getAssetFaultData() >> START TIME: ")
				.append(startTime).append("ms  END TIME: ").append(endTime).append("ms WS+Heasder+HEATMAP+Display Difference: ")
				.append((endTime - startTime)).append("ms");
		logger.debug(debugLoggerBuilder.toString());
		return objAssetDataResponse;

	}
		

	@Override
	public List<LatestCases> getLatestCases(final AssetFaultDataBean objAssetFaultDataBean) throws Exception {
		LatestCaseRuleRequestType[] latestCaseRuleRequestType = null;
		List<LatestCases> latestCasesVOLst = new ArrayList<LatestCases>();
		LatestCases latestCasesVO = null;
		final Map<String, String> headerParams = getHeaderMap(objAssetFaultDataBean);
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		try {
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTNUM, objAssetFaultDataBean.getAssetNumber());
			queryParamsMap.put(AppConstants.REQ_PARAM_CUSID, objAssetFaultDataBean.getCustomerId());
			queryParamsMap.put(AppConstants.REQ_PARAM_ASSTGRP, objAssetFaultDataBean.getAssetGrpName());
			latestCaseRuleRequestType = (LatestCaseRuleRequestType[]) rsInvoker.get(
					ServiceConstants.GET_LATEST_CASERULES, null, queryParamsMap,
					headerParams, LatestCaseRuleRequestType[].class);		
			Map<String, ArrayList<RuleBean>> mapCaseRoles = new LinkedHashMap<String, ArrayList<RuleBean>>();
			if (latestCaseRuleRequestType != null) {
				for (int i = 0; i < latestCaseRuleRequestType.length; i++) {
					latestCasesVO = new LatestCases();
					String caseId = latestCaseRuleRequestType[i].getCaseId();
					latestCasesVO.setCaseId(caseId);
					queryParamsMap = new HashMap<String, String>();
					queryParamsMap.put(AppConstants.DATA_SCREEN_DROPDOWN, caseId);
					ToolOutputDetailsResponseType[] toolOutputDetailsResponse = null;
					ArrayList<RuleBean> lstRules = null;

					try {
						if (latestCaseRuleRequestType[i].getToolOutputDetailsResponse() == null || 
								latestCaseRuleRequestType[i].getToolOutputDetailsResponse().isEmpty()) {
							latestCasesVOLst.add(latestCasesVO);
							continue;
						}
						toolOutputDetailsResponse = new ToolOutputDetailsResponseType[
						    latestCaseRuleRequestType[i].getToolOutputDetailsResponse().size()];
						for (int x = 0; x < latestCaseRuleRequestType[i].getToolOutputDetailsResponse().size(); x++) {
							toolOutputDetailsResponse[x] = latestCaseRuleRequestType[i].getToolOutputDetailsResponse().get(x);
						}
						lstRules = new ArrayList<RuleBean>();
						RuleBean rule = null;
						for (int j = 0; j < toolOutputDetailsResponse.length; j++) {
							rule = new RuleBean();
							rule.setRuleDefId(toolOutputDetailsResponse[j].getRuleDefId());
							rule.setRuleId(toolOutputDetailsResponse[j].getRuleID());							
							lstRules.add(rule);
						}
						mapCaseRoles.put(caseId, lstRules);
						latestCasesVO.setLstCaseRules(mapCaseRoles);
					} 
					catch (Exception ex) {
						logger.error("Exception occured in getLatestCases method ", ex);
					}
					latestCasesVOLst.add(latestCasesVO);
				}
			} else {
				latestCasesVOLst = null;
			}

			return latestCasesVOLst;
		} catch (Exception ex) {
			logger.error("Exception occured in getLatestCases method ", ex);
		}
		return latestCasesVOLst;
	}

	public Map<String, String> getDDDropdown(Map<String, String> listName)
			throws Exception {

		ApplicationParametersResponseType[] applParamResponseType = getLookupValue(listName);
		Map<String, String> ddDropdownMap = new LinkedHashMap<String, String>();
		if (applParamResponseType != null && applParamResponseType.length > 0) {
			String key;
			String value;
			for (int i = 0; i < applParamResponseType.length; i++) {
				key = applParamResponseType[i].getLookupValue();
				value = applParamResponseType[i].getListDescription();
				ddDropdownMap.put(key, value);
			}
		}
		return ddDropdownMap;
	}

	public Map<String, String> getDDRoleName(Map<String, String> listName)
			throws Exception {

		ApplicationParametersResponseType[] applParamResponseType = getLookupValue(listName);
		Map<String, String> ddDropdownMap = new LinkedHashMap<String, String>();
		if (applParamResponseType != null && applParamResponseType.length > 0) {
			String key;
			String value;

			key = applParamResponseType[0].getLookupValue();
			value = applParamResponseType[0].getLookupValue();
			ddDropdownMap.put(key, value);

		}
		return ddDropdownMap;
	}
	//This Function creates the dropdown values for time based datascreen filter
	public Map<String, String> getTimeBasedFilter(Map<String, String> listName)
			throws Exception {
		String key=null;
		String value=null;
		ApplicationParametersResponseType[] applParamResponseType = getLookupValue(listName);
		Map<String, String> timeBasedFilterMap = new LinkedHashMap<String, String>();
		if (applParamResponseType != null && applParamResponseType.length > 0) {
			
			for(ApplicationParametersResponseType objResponse: applParamResponseType){
				key = objResponse.getLookupValue();
				value = objResponse.getListDescription();
				timeBasedFilterMap.put(key, value);
			}
		}
		return timeBasedFilterMap;
	}
	
	//This Function gets the dropdown values for no: of days dropdown
		public List<String> getNoOfDaysDropdownValues(String listName) throws Exception {
			List<String> noOfDaysList = new ArrayList<String>();
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService.getAllLookupValues().get(listName);
			if (applParamResponseTypeList != null && !applParamResponseTypeList.isEmpty()) {
				for(ApplicationParametersResponseType objResponse: applParamResponseTypeList){
					noOfDaysList.add(objResponse.getLookupValue());
				}
			}
			return noOfDaysList;
		}

	/**
	 * @Author :
	 * @return :Map<String, String>
	 * @param : CaseBean
	 * @throws :RMDWebException
	 * @Description: This method is used to get unit configuration details in
	 *               data screen
	 * 
	 */
	@Override
	public Map<String, List<String>> getUnitConfigDetails(CaseBean objCaseBean)
			throws RMDWebException {
		Map<String, List<String>> unitConfigDetails = new LinkedHashMap<String, List<String>>();
		Map<String, String> queryParams = null;
		UnitConfigResponseType[] objUnitConfigResponseType = null;
		List<String> value = null;
		List<String> model = new ArrayList<String>();
		try {
			if (null != objCaseBean.getLocoId()
					&& !RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(objCaseBean.getLocoId())
					&& null != objCaseBean.getCaseId()
					&& !RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(objCaseBean.getCaseId())) {
				queryParams = new LinkedHashMap<String, String>();
				queryParams.put(AppConstants.ESERVICES_LOCO_ID, objCaseBean.getLocoId());
				queryParams.put(AppConstants.CASE_Id, objCaseBean.getCaseId());
				objUnitConfigResponseType = (UnitConfigResponseType[]) rsInvoker
						.get(ServiceConstants.UNIT_CONFIG, null, queryParams,
								null, UnitConfigResponseType[].class);
				if (null != objUnitConfigResponseType && objUnitConfigResponseType.length > 0) {
					model.add(objUnitConfigResponseType[0].getModelName());
					unitConfigDetails.put(AppConstants.UNIT_CONFIG_Model, model);
					for (UnitConfigResponseType obj : objUnitConfigResponseType) {
						String configGroup = obj.getConfigGroup();
						String configItem = obj.getConfigItem();
						if (unitConfigDetails.containsKey(configGroup)) {
							value = unitConfigDetails.get(configGroup);
							value.add(configItem);
							unitConfigDetails.put(configGroup, value);
						} else {
							value = new ArrayList<String>();
							value.add(configItem);
							unitConfigDetails.put(configGroup, value);
						}
					}
				}
			}
		} catch (Exception e) {
			RMDWebErrorHandler.handleException(e);
		}
		return unitConfigDetails;
	}
	
	@Override
	public Map<String, String> getLookupValueList(String listName)
			throws Exception {
		String key = null;
		String value = null;
		Map<String, String> resultMap = new LinkedHashMap<String, String>();
		try {
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService
					.getAllLookupValues().get(listName);
			if (applParamResponseTypeList != null) {
				for (int i = 0; i < applParamResponseTypeList.size(); i++) {
					value = applParamResponseTypeList.get(i).getLookupValue();
					key = applParamResponseTypeList.get(i).getLookupValue();
					resultMap.put(key, value);
				}
			}

		} catch (Exception e) {
			RMDWebErrorHandler.handleException(e);
		}
		return resultMap;
	}

	@Override
	public String getLocoId(AssetOverviewBean assetOverviewBean)
			throws RMDWebException {
		Map<String, List<String>> unitConfigDetails = new LinkedHashMap<String, List<String>>();
		Map<String, String> queryParams = null;
		String locoId = null;
		List<String> value = null;
		List<String> model = new ArrayList<String>();
		try {
			queryParams = new LinkedHashMap<String, String>();
			if (null != assetOverviewBean.getAssetGroup()
					&& !RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(assetOverviewBean.getAssetGroup()))
					 {
						queryParams.put(AppConstants.ASSET_GROUP_NAME, assetOverviewBean.getAssetGroup());
					 }
			else
			{
				queryParams.put(AppConstants.ASSET_GROUP_NAME, AppConstants.EMPTY_STRING);
			}
			if (null != assetOverviewBean.getCustomer()
					&& !RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(assetOverviewBean.getCustomer()))
					 {
						queryParams.put(AppConstants.CUSTOMER_ID, assetOverviewBean.getCustomer());
					 }
			else
			{
				queryParams.put(AppConstants.CUSTOMER_ID, AppConstants.EMPTY_STRING);
			}
			if (null != assetOverviewBean.getAsset()
					&& !RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(assetOverviewBean.getAsset()))
					 {
						queryParams.put(AppConstants.ASSET_NUMBER, assetOverviewBean.getAsset());
					 }
			else
			{
				queryParams.put(AppConstants.ASSET_NUMBER, AppConstants.EMPTY_STRING);
			}
				
			locoId = (String) rsInvoker
						.get(ServiceConstants.GET_LOCO_ID, null, queryParams,
								null, String.class);
		} catch (Exception e) {
			RMDWebErrorHandler.handleException(e);
		}
		return locoId;
	}

}
