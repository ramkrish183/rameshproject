package com.ge.trans.rmd.cm.mvc.model;

public class ColModel {
	private String headerName;
	private String name;
	private String index;
	private String style;
	private int width;
	private String filter;
	private String charLength;
	private String lowerBound;
	private String upperBound;
	private String valueMatch;
	private String dataToolTipFlag;
	private String toolTip;
    private boolean frozen= false;

	public String getToolTip() {
		return toolTip;
	}
	public void setToolTip(String toolTip) {
		this.toolTip = toolTip;
	}
	public String getDataToolTipFlag() {
		return dataToolTipFlag;
	}
	public void setDataToolTipFlag(String dataToolTipFlag) {
		this.dataToolTipFlag = dataToolTipFlag;
	}
	public String getLowerBound() {
		return lowerBound;
	}
	public void setLowerBound(String lowerBound) {
		this.lowerBound = lowerBound;
	}
	public String getUpperBound() {
		return upperBound;
	}
	public void setUpperBound(String upperBound) {
		this.upperBound = upperBound;
	}
	public String getValueMatch() {
		return valueMatch;
	}
	public void setValueMatch(String valueMatch) {
		this.valueMatch = valueMatch;
	}
	public String getFilter() {
		return filter;
	}
	public String getCharLength() {
		return charLength;
	}
	public void setCharLength(String charLength) {
		this.charLength = charLength;
	}
	public void setFilter(String filter) {
		this.filter = filter;
	}
	public String getStyle() {
		return style;
	}
	public void setStyle(String style) {
		this.style = style;
	}
	public boolean isFrozen() {
		return frozen;
	}
	public void setFrozen(final boolean frozen) {
		this.frozen = frozen;
	}
	public String getName() {
		return name;
	}
	public void setName(final String name) {
		this.name = name;
	}
	public String getIndex() {
		return index;
	}
	public void setIndex(final String index) {
		this.index = index;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(final int width) {
		this.width = width;
	}
	public String getHeaderName() {
		return headerName;
	}
	public void setHeaderName(final String headerName) {
		this.headerName = headerName;
	}
	

}
