package com.ge.trans.rmd.cm.valueobjects;

public class MdscStartUpControllersVO {
	
	private String cabComm;
	private String caxComm;
	private String excComm;
	private String auxComm;
	private String efiComm;
	private String smsEnabled;
	private String flmComm;
	private String AcComm;
	private String ccaComm;
	private String servicePdp;
	private String eabComm;
	private String erComm;
	public String getCabComm() {
		return cabComm;
	}
	public void setCabComm(String cabComm) {
		this.cabComm = cabComm;
	}
	public String getCaxComm() {
		return caxComm;
	}
	public void setCaxComm(String caxComm) {
		this.caxComm = caxComm;
	}
	public String getExcComm() {
		return excComm;
	}
	public void setExcComm(String excComm) {
		this.excComm = excComm;
	}
	public String getAuxComm() {
		return auxComm;
	}
	public void setAuxComm(String auxComm) {
		this.auxComm = auxComm;
	}
	public String getEfiComm() {
		return efiComm;
	}
	public void setEfiComm(String efiComm) {
		this.efiComm = efiComm;
	}
	public String getSmsEnabled() {
		return smsEnabled;
	}
	public void setSmsEnabled(String smsEnabled) {
		this.smsEnabled = smsEnabled;
	}
	public String getFlmComm() {
		return flmComm;
	}
	public void setFlmComm(String flmComm) {
		this.flmComm = flmComm;
	}
	public String getAcComm() {
		return AcComm;
	}
	public void setAcComm(String acComm) {
		AcComm = acComm;
	}
	public String getCcaComm() {
		return ccaComm;
	}
	public void setCcaComm(String ccaComm) {
		this.ccaComm = ccaComm;
	}
	public String getServicePdp() {
		return servicePdp;
	}
	public void setServicePdp(String servicePdp) {
		this.servicePdp = servicePdp;
	}
	public String getEabComm() {
		return eabComm;
	}
	public void setEabComm(String eabComm) {
		this.eabComm = eabComm;
	}
	public String getErComm() {
		return erComm;
	}
	public void setErComm(String erComm) {
		this.erComm = erComm;
	}
	

}
