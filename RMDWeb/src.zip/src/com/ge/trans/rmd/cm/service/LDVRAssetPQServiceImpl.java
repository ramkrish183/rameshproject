package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.pp.beans.AssetBean;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;

@Service
public class LDVRAssetPQServiceImpl extends RMDBaseServiceImpl implements
        LDVRAssetPQService {

    private final RMDWebLogger rmdWebLogger = RMDWebLogger
            .getLogger(getClass());

    @Autowired
    private WebServiceInvoker webServiceInvoker;

    @Autowired
    private AuthorizationService authorizationService;

    /**
     * This method will call web-service to return list of asset numbers mapped
     * with products given keys like customerId, assetGroup and assetnumber
     */

    public List<String> getAssetProducts(AssetBean assetBean) throws RMDWebException {

        AssetResponseType[] assetResponses = null;
        List<String> assetNumbers = new ArrayList<String>();
        final Map<String, String> headerParams = getHeaderMap(assetBean);
        try {
            AssetsRequestType objAssetsReqType = new AssetsRequestType();
            objAssetsReqType.setLanguage(headerParams
                    .get(AppConstants.USER_LANGUAGE));
            objAssetsReqType.setCustomerId(assetBean.getCustomerId());
            objAssetsReqType.setAssetNumberLike(assetBean.getAssetNumber());
            objAssetsReqType.setFleetId(assetBean.getFleetId());
            if (null != assetBean.getAssetGroup()
                    && !assetBean.getAssetGroup().equals(
                            RMDCommonConstants.EMPTY_STRING)) {
                objAssetsReqType.setAssetGrpName(assetBean.getAssetGroup());
            }
            parseProducts(assetBean.getProducts(), objAssetsReqType);
            assetResponses = (AssetResponseType[]) webServiceInvoker.post(
                    ServiceConstants.GET_ASSETS, objAssetsReqType,
                    AssetResponseType[].class);

            for (int i = 0; i < assetResponses.length; i++) {
                assetNumbers.add(assetResponses[i].getAssetNumber() + "");
            }

        } catch (RMDWebException e) {
            if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
                rmdWebLogger
                        .error("LDVRAssetPQServiceImpl :: No records found for getAssetProducts() service "
                                + e.getMessage());
              } else {
                rmdWebLogger
                        .error("LDVRAssetPQServiceImpl :: Exception occured in getAssetProducts() method "
                                + e.getMessage());
                throw e;
            }
        } 
        return assetNumbers;
    }
    /**
     * @Author:
     * @param :AssetDetailsVO
     * @return:List<String>
     * @throws:RMDWebException
     * @Description: This method is used for fetching the list of assets based
     *               upon user selection.
     */
    @Override
    public List<String> getAssetsProductList(AssetBean assetBean) throws RMDWebException  {
        List<String> assetList = new ArrayList<String>();
        AssetsRequestType objAssetsRequestType = new AssetsRequestType();
        try {
            objAssetsRequestType.setCustomerId(assetBean.getCustomerId());
            objAssetsRequestType.setAssetGrpName(assetBean.getAssetGroup());
            objAssetsRequestType.setFleetId(assetBean.getFleetId());
            objAssetsRequestType.setAssetFrom(assetBean.getFromAssetNumber());
            objAssetsRequestType.setAssetTo(assetBean.getToAssetNumber());
            parseProducts(assetBean.getProducts(), objAssetsRequestType);
            final AssetResponseType[] assetResponseType = (AssetResponseType[]) webServiceInvoker
                    .post(ServiceConstants.GET_ASSETS, objAssetsRequestType,
                            AssetResponseType[].class);
            if (null != assetResponseType && assetResponseType.length > 0) {

                for (AssetResponseType assetResponse : assetResponseType) {

                    String asset = assetResponse.getAssetGroupName()
                            + AppConstants.SYMBOL_HYPEN
                            + assetResponse.getAssetNumber();
                    assetList.add(asset);
                }
            }
        } catch (RMDWebException e) {
            if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
                rmdWebLogger
                        .error("LDVRAssetPQServiceImpl :: No records found for getAssetsProductList() service "
                                + e.getMessage());
              
            } else {
                rmdWebLogger
                        .error("LDVRAssetPQServiceImpl :: Exception occured in getAssetsProductList() method "
                                + e.getMessage());
                throw e;
            }
        } 
        return assetList;
    }
}
