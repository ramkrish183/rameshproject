package com.ge.trans.rmd.cm.service;

import java.util.List;

import com.ge.trans.rmd.cm.valueobjects.CallLogNotesVO;
import com.ge.trans.rmd.common.exception.RMDWebException;


public interface CallLogNotesService {
	public List<CallLogNotesVO> getCallLogNotes(CallLogNotesVO callLogNotesVO,String userTimeZone) throws RMDWebException;
			
}
