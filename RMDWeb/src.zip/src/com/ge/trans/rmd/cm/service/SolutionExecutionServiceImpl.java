/**
 * ============================================================
 * File : SolutionExecutionService.java
 * Description 		: Service implementation  class  for Technician Cases and Rx Case Execution Details
 * 
 * Package 			: com.ge.trans.rmd.cm.service
 * Author 			: UST
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		: April 3, 2012
 * History
 * Modified By 		: Initial Release
 * Copyright (C) 2012 General Electric Company. All rights reserved
 * ============================================================
 */
package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.StringEscapeUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.eoa.services.tools.rx.service.valueobjects.RxDeliveryAttachmentVO;
import com.ge.trans.rmd.cm.beans.OpenCasesBean;
import com.ge.trans.rmd.cm.valueobjects.AttachmentVO;
import com.ge.trans.rmd.cm.valueobjects.CaseResponseVO;
import com.ge.trans.rmd.cm.valueobjects.DeliveryAttachmentVO;
import com.ge.trans.rmd.cm.valueobjects.LocationVO;
import com.ge.trans.rmd.cm.valueobjects.SolutionExecutionResponseVO;
import com.ge.trans.rmd.cm.valueobjects.TaskDetailVO;
import com.ge.trans.rmd.cm.valueobjects.TechnicianSolutionDetailVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.admin.valueobjects.AddressDetailType;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.admin.valueobjects.LocationResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CasesRequestType;
import com.ge.trans.rmd.services.solutions.valueobjects.RxDeliveryAttachmentResponse;
import com.ge.trans.rmd.services.solutions.valueobjects.SolutionExecutionRequestType;
import com.ge.trans.rmd.services.solutions.valueobjects.SolutionExecutionResponseType;
import com.ge.trans.rmd.services.solutions.valueobjects.TaskDetailType;
import com.ge.trans.rmd.utilities.AppSecUtil;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service(AppConstants.SOLUTION_EXECUTION_SERVICEIMPL)
public class SolutionExecutionServiceImpl extends RMDBaseServiceImpl implements
		SolutionExecutionService {
	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());
	@Autowired
	private WebServiceInvoker webServiceInvoker;
	@Autowired
	private CachedService cachedService;

	/*
	 * This method calls the service getCases to fetch the open Technician Cases
	 * 
	 * @see
	 * com.ge.trans.rmd.cm.service.SolutionExecutionService#getCases(java.lang
	 * .String, com.ge.trans.rmd.cm.beans.OpenCasesBean)
	 */

	/**
	 * This method calls the service getCases to fetch the open Technician Cases
	 * 
	 * @param queueNameValue
	 *            ,solutionStatusValue
	 * @param objCaseResponseVO
	 * @param openCaseBean
	 * @return List<CaseResponseVO>
	 */
	public List<CaseResponseVO> getCases(final String queueNameValue,
			final String solutionStatusValue, final OpenCasesBean openCaseBean,
			final CaseResponseVO objCaseResponseVO) {
		List<CaseResponseVO> caseResVOLst = new ArrayList<CaseResponseVO>();
		CasesRequestType objCasesReqType = new CasesRequestType();
		try {

			// setting the query params
			objCasesReqType.setQueueName(queueNameValue);
			objCasesReqType.setSolutionStatus(solutionStatusValue);
			parseProducts(openCaseBean.getProducts(), objCasesReqType);
			if (openCaseBean.getRxCaseId() != null) {
				objCasesReqType.setRxCaseID(openCaseBean.getRxCaseId());
			}
			if (openCaseBean.getCustomerId() != null)
				objCasesReqType.setCustomerId(openCaseBean.getCustomerId());
			objCasesReqType.setUserLanguage(openCaseBean.getUserLanguage());
			// setting the urgency and estimated Repair time in query params
			if (null != objCaseResponseVO.getUrgency()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseResponseVO.getUrgency())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(objCaseResponseVO.getUrgency())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(objCaseResponseVO.getUrgency())) {

				objCasesReqType.setUrgency(objCaseResponseVO.getUrgency());
			}

			if (null != objCaseResponseVO.getEstRepairTime()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseResponseVO
									.getEstRepairTime())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(objCaseResponseVO
									.getEstRepairTime())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(objCaseResponseVO
									.getEstRepairTime())) {

				objCasesReqType.setEstRepTm(objCaseResponseVO
						.getEstRepairTime());
			}

			/* For CaseType */
			if (null != objCaseResponseVO.getCaseType()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseResponseVO.getCaseType())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(objCaseResponseVO.getCaseType())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(objCaseResponseVO.getCaseType())) {

				objCasesReqType.setCaseType(objCaseResponseVO.getCaseType());
			}
			/* For Fleet */
			if (null != objCaseResponseVO.getFleet()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseResponseVO.getFleet())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(objCaseResponseVO.getFleet())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(objCaseResponseVO.getFleet())) {

				objCasesReqType.setFleetId(objCaseResponseVO.getFleet());
			}
			/* For Model */
			if (null != objCaseResponseVO.getModel()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseResponseVO.getModel())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(objCaseResponseVO.getModel())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(objCaseResponseVO.getModel())) {

				objCasesReqType.setModelId(objCaseResponseVO.getModel());
			}
			/* For CaseType */
			CaseResponseType[] arrayCaseResLst = null;
			objCasesReqType.setRxId(objCaseResponseVO.getSolutionTitle());
			objCasesReqType.setClosedRxlookBackDays(openCaseBean
					.getClosedRxLookBackDays());
			/*
			 * if (null != objCaseResponseVO.getSolutionTitle() &&
			 * !RMDCommonConstants
			 * .EMPTY_STRING.equals(objCaseResponseVO.getSolutionTitle())) {
			 * String[] totalRxIdsArr =
			 * objCaseResponseVO.getSolutionTitle().split(","); String[]
			 * subRxIdsArr = null; int limitOfRxIds=1000; String rxIdForWS = "";
			 * int countToIterate = totalRxIdsArr.length / limitOfRxIds; if
			 * (countToIterate > 0) { CaseResponseType[] combinedCaseResponse =
			 * null; for (int i = 0; i <= countToIterate; i++) { rxIdForWS = "";
			 * /* copying 1000 or less rx ids to new array
			 */
			/*
			 * if (totalRxIdsArr.length - (i * limitOfRxIds) >= limitOfRxIds) {
			 * subRxIdsArr = new String[limitOfRxIds];
			 * System.arraycopy(totalRxIdsArr, i * limitOfRxIds, subRxIdsArr, 0,
			 * subRxIdsArr.length); } else { subRxIdsArr = new
			 * String[totalRxIdsArr.length - (i * limitOfRxIds)];
			 * System.arraycopy(totalRxIdsArr, i * limitOfRxIds, subRxIdsArr, 0,
			 * totalRxIdsArr.length - (i * limitOfRxIds)); } for (int j = 0; j <
			 * subRxIdsArr.length; j++) {
			 * 
			 * rxIdForWS = rxIdForWS + subRxIdsArr[j]; if (j <
			 * subRxIdsArr.length) rxIdForWS = rxIdForWS + ","; }
			 * objCasesReqType.setRxId(rxIdForWS); try { arrayCaseResLst =
			 * (CaseResponseType[]) webServiceInvoker
			 * .post(ServiceConstants.CASES_SERVICE_LITE_GETDELCASES,
			 * objCasesReqType, CaseResponseType[].class); } catch (Exception e)
			 * {
			 * 
			 * if (e instanceof RMDWebException) {
			 * 
			 * RMDWebException rmdEx = (RMDWebException) e; if
			 * (AppConstants.EXCEPTION_EOA_101
			 * .equalsIgnoreCase(rmdEx.getErrorCode())) { continue; } else throw
			 * e; }
			 * 
			 * }
			 * 
			 * combinedCaseResponse = (CaseResponseType[]) ArrayUtils
			 * .addAll(combinedCaseResponse, arrayCaseResLst);
			 * 
			 * } arrayCaseResLst = combinedCaseResponse; } else {
			 * objCasesReqType.setRxId(objCaseResponseVO.getSolutionTitle());
			 * arrayCaseResLst = (CaseResponseType[]) webServiceInvoker
			 * .post(ServiceConstants.CASES_SERVICE_LITE_GETDELCASES,
			 * objCasesReqType, CaseResponseType[].class); }
			 * 
			 * } else {
			 */
			arrayCaseResLst = (CaseResponseType[]) webServiceInvoker.post(
					ServiceConstants.CASES_SERVICE_LITE_GETDELCASES,
					objCasesReqType, CaseResponseType[].class);
			// }
			caseResVOLst = populateCaseBean(caseResVOLst, arrayCaseResLst,
					openCaseBean);
		} catch (Exception e) {
			logger.error("Exception occured in getCases() method ");
			
		}
		return caseResVOLst;
	}
	
	/**
	 * This method calls the service getCases to fetch the open Technician Cases
	 * 
	 * @param queueNameValue
	 *            ,solutionStatusValue
	 * @param objCaseResponseVO
	 * @param openCaseBean
	 * @return List<CaseResponseVO>
	 */
	public List<CaseResponseVO> getCasesLite(final String queueNameValue,
			final String solutionStatusValue, final OpenCasesBean openCaseBean,
			final CaseResponseVO objCaseResponseVO, final String userCustomer) {
		List<CaseResponseVO> caseResVOLst = new ArrayList<CaseResponseVO>();
		CasesRequestType objCasesReqType = new CasesRequestType();
		try {

			// setting the query params
			objCasesReqType.setQueueName(queueNameValue);
			objCasesReqType.setSolutionStatus(solutionStatusValue);
			parseProducts(openCaseBean.getProducts(), objCasesReqType);
			if (openCaseBean.getRxCaseId() != null) {
				objCasesReqType.setRxCaseID(openCaseBean.getRxCaseId());
			}
			if (openCaseBean.getCustomerId() != null)
				objCasesReqType.setCustomerId(openCaseBean.getCustomerId());
				objCasesReqType.setUserLanguage(openCaseBean.getUserLanguage());
			// setting the urgency and estimated Repair time in query params
			if (null != objCaseResponseVO.getUrgency()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseResponseVO.getUrgency())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(objCaseResponseVO.getUrgency())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(objCaseResponseVO.getUrgency())) {

				objCasesReqType.setUrgency(objCaseResponseVO.getUrgency());
			}

			if (null != objCaseResponseVO.getEstRepairTime()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseResponseVO
									.getEstRepairTime())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(objCaseResponseVO
									.getEstRepairTime())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(objCaseResponseVO
									.getEstRepairTime())) {

				objCasesReqType.setEstRepTm(objCaseResponseVO
						.getEstRepairTime());
			}

			/* For CaseType */
			if (null != objCaseResponseVO.getCaseType()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseResponseVO.getCaseType())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(objCaseResponseVO.getCaseType())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(objCaseResponseVO.getCaseType())) {

				objCasesReqType.setCaseType(objCaseResponseVO.getCaseType());
			}
			/* For Fleet */
			if (null != objCaseResponseVO.getFleet()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseResponseVO.getFleet())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(objCaseResponseVO.getFleet())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(objCaseResponseVO.getFleet())) {

				objCasesReqType.setFleetId(objCaseResponseVO.getFleet());
			}
			/* For Model */
			if (null != objCaseResponseVO.getModel()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseResponseVO.getModel())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(objCaseResponseVO.getModel())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(objCaseResponseVO.getModel())) {

				objCasesReqType.setModelId(objCaseResponseVO.getModel());
			}
			/* For CaseID */
			if (null != objCaseResponseVO.getCaseId()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseResponseVO.getCaseId())) {

				objCasesReqType.setCaseID(objCaseResponseVO.getCaseId());
			}
			/* For Asset No */
			if (null != objCaseResponseVO.getAssetNumber()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objCaseResponseVO.getAssetNumber())) {

				objCasesReqType.setAssetNumber(objCaseResponseVO.getAssetNumber());
			}
			/* For CaseType */
			CaseResponseType[] arrayCaseResLst = null;
			objCasesReqType.setRxId(objCaseResponseVO.getSolutionTitle());
			objCasesReqType.setClosedRxlookBackDays(openCaseBean
					.getClosedRxLookBackDays());
	        objCasesReqType.setScreenName(RMDCommonConstants.TECHNICIAN_CASES);
			arrayCaseResLst = (CaseResponseType[]) webServiceInvoker.post(
					ServiceConstants.CASES_SERVICE_LITE_GETDELCASES,
					objCasesReqType, CaseResponseType[].class);
			caseResVOLst = populateCaseBeanLite(caseResVOLst, arrayCaseResLst,
					openCaseBean, userCustomer);
		} catch (Exception e) {
			logger.error("Exception occured in getCases() method ");
			
		}
		return caseResVOLst;
	}

	/*
	 * This method calls the service getDeliveredSolutionDetails to fetch
	 * RxExecution Details of the selected Case
	 * 
	 * @see com.ge.trans.rmd.cm.service.SolutionExecutionService#
	 * getSolutionExecutionDetails(java.lang.String)
	 */
	public SolutionExecutionResponseVO getSolutionExecutionDetails(
			final OpenCasesBean openCaseBean) {

		SolutionExecutionResponseVO solExecResVo = new SolutionExecutionResponseVO();
		final Map<String, String> pathParamMap = new LinkedHashMap<String, String>();
		final Map<String, String> queryParam = new LinkedHashMap<String, String>();
		Map<String,TaskDetailVO> uniqueList = null;
		TaskDetailVO taskDetail = new TaskDetailVO();
		List<TaskDetailVO> taskDetailList = new ArrayList<TaskDetailVO>();
		TaskDetailVO task = new TaskDetailVO();
		try {
			/*
			 * added as part of Sprint 7 - Multi Lingual Story -Start passing
			 * user preferred language to webservice
			 */
			final Map<String, String> headerParams = getHeaderMap(openCaseBean);
			String descVal;
			List<TaskDetailVO> taskDetails = new ArrayList<TaskDetailVO>();
			/*
			 * added as part of Sprint 7 - Multi Lingual Story -End
			 */
			pathParamMap.put(AppConstants.RX_CASE_ID, openCaseBean.getCaseId());
			queryParam.put(AppConstants.CUSTOMERID,
					openCaseBean.getCustomerId());
			final SolutionExecutionResponseType solutionExecutionResponseType = (SolutionExecutionResponseType) webServiceInvoker
					.get(ServiceConstants.GET_RX_EXEC, pathParamMap,
							queryParam, headerParams,
							SolutionExecutionResponseType.class);
			solExecResVo = populateRxExecutionDetails(solutionExecutionResponseType, openCaseBean.getTimeZone());
			
			solExecResVo.setRecomNotes(solutionExecutionResponseType.getRecomNotes());
			solExecResVo.setRxDescription(solutionExecutionResponseType.getRxDescription());
			solExecResVo.setRxDeliveredBy(solutionExecutionResponseType.getRxDeliveredBy());
			solExecResVo.setPrerequisites(solutionExecutionResponseType.getPrerequisites());
			solExecResVo.setCustomerName(solutionExecutionResponseType.getCustomerName());
			List<DeliveryAttachmentVO> rxDeliveryAttachmentLists = new ArrayList<DeliveryAttachmentVO>();
			
			if(solutionExecutionResponseType.getDeliveryAttachmentDetails()!=null && !solutionExecutionResponseType.getDeliveryAttachmentDetails().isEmpty()){
            	for(RxDeliveryAttachmentResponse deliveryAttachmentResponse : solutionExecutionResponseType.getDeliveryAttachmentDetails()){
            		DeliveryAttachmentVO rxObject = new DeliveryAttachmentVO();
            		rxObject.setDocumentName(deliveryAttachmentResponse.getDocumentTitle());
            		rxObject.setDocumentLocation(deliveryAttachmentResponse.getDocumentPath());
            		rxDeliveryAttachmentLists.add(rxObject);
            	}
            }
			solExecResVo.setDeliveryRxAttachments(rxDeliveryAttachmentLists);
			uniqueList = new LinkedHashMap<String, TaskDetailVO>();
			for (TaskDetailVO taskDetailUniqueList : solExecResVo.getTaskDetail()) {
				 if(uniqueList.containsKey(taskDetailUniqueList.getTaskID())){
					 taskDetail = uniqueList.get(taskDetailUniqueList.getTaskID());
					 AttachmentVO document = null;
					 List<AttachmentVO> documentList = new ArrayList<AttachmentVO>();
					 for(AttachmentVO path : taskDetail.getDocAttachment()){
						 document = new AttachmentVO();
						 document.setDocPath(path.getDocPath());
						 document.setDocTitle(path.getDocTitle());
						 documentList.add(document);
					 }
					 AttachmentVO document1 = new AttachmentVO();
					 document1.setDocPath(taskDetailUniqueList.getDocPath());
					 document1.setDocTitle(taskDetailUniqueList.getDocTitle());
					 documentList.add(document1);
					 taskDetail.setDocAttachment(documentList);
					 uniqueList.put(taskDetailUniqueList.getTaskID(), taskDetail);
                 }else{
					 AttachmentVO document = new AttachmentVO();
					 List<AttachmentVO> documentList = new ArrayList<AttachmentVO>();
					 document.setDocPath(taskDetailUniqueList.getDocPath());
					 document.setDocTitle(taskDetailUniqueList.getDocTitle());
					 documentList.add(document);
					 taskDetailUniqueList.setDocAttachment(documentList);
                	 uniqueList.put(taskDetailUniqueList.getTaskID(), taskDetailUniqueList);
                 }
				
			}
		    for (Map.Entry<String,TaskDetailVO> pair : uniqueList.entrySet()) {
		    	  task = (TaskDetailVO) pair.getValue();
			        taskDetailList.add(task);
		    }
		    solExecResVo.setTaskDetail(taskDetailList);
		    if(openCaseBean.getLanguage().equalsIgnoreCase("hi_IN")){
				taskDetails = solExecResVo.getTaskDetail();
				for (TaskDetailVO taskDetailVO : taskDetails) {
					descVal = taskDetailVO.getTaskDesc();
					taskDetailVO.setTaskDesc(StringEscapeUtils.unescapeJava(descVal));
				}
			}
		} catch (Exception e) {
			logger.error("In SolutionExecutionServiceImpl : Exception occured in getSolutionExecutionDetails() method "+e.getMessage());
			
		}
		finally{
			uniqueList = null;
		}
		return solExecResVo;
	}

	/**
	 * This method is used to build the data of the open cases that needs to be
	 * populated in the Technician Cases Page
	 * 
	 * @param casesList
	 * @param caseResponseTypeArr
	 * @param openCaseBean
	 * @return
	 */
	private List<CaseResponseVO> populateCaseBean(
			final List<CaseResponseVO> casesList,
			final CaseResponseType[] caseResponseTypeArr,
			final OpenCasesBean openCaseBean) {

		TechnicianSolutionDetailVO techCaseDetail;
		String closedDateAge;
		for (CaseResponseType caseResponseType : caseResponseTypeArr) {
			final List<TechnicianSolutionDetailVO> techCasesList = new ArrayList<TechnicianSolutionDetailVO>();
			final CaseResponseVO caseBean = new CaseResponseVO();
			caseBean.setAssetNumber(caseResponseType.getAssetNumber());
			if (caseResponseType.getCaseInfo() != null) {
				final DateFormat zoneFormater = new SimpleDateFormat(
						AppConstants.DATE_FORMAT_24HRS);
				final TimeZone firstTime = TimeZone.getTimeZone(openCaseBean
						.getTimeZone());
				zoneFormater.setTimeZone(firstTime);

				caseBean.setCustomerName(caseResponseType.getCaseInfo()
						.getCustomerName());
				caseBean.setAssetGrpName(caseResponseType.getAssetGrpName());
				caseBean.setCaseId(caseResponseType.getCaseInfo().getCaseID());
				// Age Calculation for the delivered Solution
				caseBean.setCreatedDate(zoneFormater.format(caseResponseType
						.getCaseInfo().getCreatedDate().toGregorianCalendar()
						.getTime()));
				if (null != caseResponseType.getCaseInfo().getCreatedDate()) {
					final XMLGregorianCalendar creationDate = caseResponseType
							.getCaseInfo().getCreatedDate();
					final GregorianCalendar startDate = creationDate
							.toGregorianCalendar();
					final String age = RMDCommonUtil
							.calculateAge(startDate, new GregorianCalendar(),
									openCaseBean.getTimeZone());
					caseBean.setAge(age);
				}
				// This is to populate the open solution details for a Case
				if (caseResponseType.getSolutionInfo() != null) {
					for (int i = 0; i < caseResponseType.getSolutionInfo()
							.size(); i++) {
						techCaseDetail = new TechnicianSolutionDetailVO();
						techCaseDetail.setSolutionCaseID(caseResponseType
								.getSolutionInfo().get(i).getSolutionCaseID());
						techCaseDetail.setSolutionDelvDate(zoneFormater
								.format(caseResponseType.getSolutionInfo()
										.get(i).getSolutionDelvDate()
										.toGregorianCalendar().getTime()));
						techCaseDetail.setSolutionTitle(caseResponseType
								.getSolutionInfo().get(i).getSolutionTitle());
						techCaseDetail.setUrgency(caseResponseType
								.getSolutionInfo().get(i).getUrgency());
						techCaseDetail.setEstmRepairTime(caseResponseType
								.getSolutionInfo().get(i).getEstmRepTime());
						techCaseDetail
								.setLocomotiveImpact(caseResponseType
										.getSolutionInfo().get(i)
										.getLocomotiveImpact());

						if (null != caseResponseType.getSolutionInfo().get(i)
								.getSolutionCloseDate()) {
							
							techCaseDetail.setSolutionCloseDate(zoneFormater
									.format(caseResponseType.getSolutionInfo()
											.get(i).getSolutionCloseDate()
											.toGregorianCalendar().getTime()));
							
							closedDateAge = RMDCommonUtil
									.calculateAge( caseResponseType.getSolutionInfo().get(i)
											.getSolutionCloseDate().toGregorianCalendar(), new GregorianCalendar(),
											openCaseBean.getTimeZone());
							techCaseDetail.setClosedDateAge(closedDateAge);
							
						}

						// If solutionCloseDate is NULL, Rx Status is OPEN, Else
						// Status is CLOSED
						if (caseResponseType.getSolutionInfo().get(i)
								.getSolutionCloseDate() == null) {
							techCaseDetail
									.setSolutionStatus(AppConstants.STATUS_OPEN);
						} else
							techCaseDetail
									.setSolutionStatus(AppConstants.STATUS_CLOSED);

						techCasesList.add(techCaseDetail);
					}
				}
				caseBean.setTechCaseDetail(techCasesList);
			}
			casesList.add(caseBean);
		}
		return casesList;
	}
	
	/**
	 * This method is used to build the data of the open cases that needs to be
	 * populated in the Technician Cases Page
	 * 
	 * @param casesList
	 * @param caseResponseTypeArr
	 * @param openCaseBean
	 * @return
	 * @throws Exception 
	 * @throws RMDWebException 
	 */
	private List<CaseResponseVO> populateCaseBeanLite(
			final List<CaseResponseVO> casesList,
			final CaseResponseType[] caseResponseTypeArr,
			final OpenCasesBean openCaseBean,
			final String userCustomer) throws RMDWebException, Exception {

		TechnicianSolutionDetailVO techCaseDetail;
		String closedDateAge;
		String reissueRxDelvAge;
		for (CaseResponseType caseResponseType : caseResponseTypeArr) {
			List<TechnicianSolutionDetailVO> techCasesList = new ArrayList<TechnicianSolutionDetailVO>();
			CaseResponseVO caseBean = new CaseResponseVO();
			caseBean.setRxType(caseResponseType.getRxType());

			caseBean.setAssetNumber(caseResponseType.getAssetNumber());
			if (caseResponseType.getCaseInfo() != null) {
				DateFormat zoneFormater = new SimpleDateFormat(
						AppConstants.DATE_FORMAT_24HRS);
				if (cachedService.getSDCustLookup().get(userCustomer) != null
						&& cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
						&& !cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim().equals("")) {
					zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat());
				}
				final TimeZone firstTime = TimeZone.getTimeZone(openCaseBean
						.getTimeZone());
				zoneFormater.setTimeZone(firstTime);

				caseBean.setCustomerName(caseResponseType.getCaseInfo()
						.getCustomerName());
				caseBean.setAssetGrpName(caseResponseType.getAssetGrpName());
				caseBean.setCaseId(caseResponseType.getCaseInfo().getCaseID());
				// Age Calculation for the delivered Solution
				caseBean.setCreatedDate(zoneFormater.format(caseResponseType
						.getCaseInfo().getCreatedDate().toGregorianCalendar()
						.getTime()));
				if (null != caseResponseType.getCaseInfo().getCreatedDate()) {
					final XMLGregorianCalendar creationDate = caseResponseType
							.getCaseInfo().getCreatedDate();
					final GregorianCalendar startDate = creationDate
							.toGregorianCalendar();
					final String age = RMDCommonUtil
							.calculateAge(startDate, new GregorianCalendar(),
									openCaseBean.getTimeZone());
					caseBean.setAge(age);
				}
				// This is to populate the open solution details for a Case
				if (caseResponseType.getSolutionInfo() != null) {
					for (int i = 0; i < caseResponseType.getSolutionInfo()
							.size(); i++) {
						techCaseDetail = new TechnicianSolutionDetailVO();
						techCaseDetail.setSolutionCaseID(caseResponseType
								.getSolutionInfo().get(i).getSolutionCaseID());
						techCaseDetail.setSolutionDelvDate(zoneFormater
								.format(caseResponseType.getSolutionInfo()
										.get(i).getSolutionDelvDate()
										.toGregorianCalendar().getTime()));
						techCaseDetail.setSolutionTitle(AppSecUtil.decodeString(caseResponseType
								.getSolutionInfo().get(i).getSolutionTitle()));
						techCaseDetail.setUrgency(caseResponseType
								.getSolutionInfo().get(i).getUrgency());
						techCaseDetail.setEstmRepairTime(caseResponseType
								.getSolutionInfo().get(i).getEstmRepTime());
						techCaseDetail
						.setLocomotiveImpact(AppSecUtil.decodeString(caseResponseType
								.getSolutionInfo().get(i)
								.getLocomotiveImpact()));

						if (null != caseResponseType.getSolutionInfo().get(i)
								.getSolutionCloseDate()) {

							techCaseDetail.setSolutionCloseDate(zoneFormater
									.format(caseResponseType.getSolutionInfo()
											.get(i).getSolutionCloseDate()
											.toGregorianCalendar().getTime()));

							closedDateAge = RMDCommonUtil.calculateAge(
									caseResponseType.getSolutionInfo().get(i)
											.getSolutionCloseDate()
											.toGregorianCalendar(),
									new GregorianCalendar(),
									openCaseBean.getTimeZone());
							techCaseDetail.setClosedDateAge(closedDateAge);

						}
						
						if (null != caseResponseType.getSolutionInfo().get(i)
								.getReissueRxDelvDate()) {
							techCaseDetail.setReissueRxDelvDate(zoneFormater
									.format(caseResponseType.getSolutionInfo()
											.get(i).getReissueRxDelvDate()
											.toGregorianCalendar().getTime()));
							
							reissueRxDelvAge = RMDCommonUtil
									.calculateAge( caseResponseType.getSolutionInfo()
											.get(i).getReissueRxDelvDate()
											.toGregorianCalendar(), new GregorianCalendar(),
											openCaseBean.getTimeZone());
							techCaseDetail.setReissueRxDelvAge(reissueRxDelvAge);
						}

						// If solutionCloseDate is NULL, Rx Status is OPEN, Else
						// Status is CLOSED
						if (caseResponseType.getSolutionInfo().get(i)
								.getSolutionCloseDate() == null) {
							techCaseDetail
									.setSolutionStatus(AppConstants.STATUS_OPEN);
						} else
							techCaseDetail
									.setSolutionStatus(AppConstants.STATUS_CLOSED);

						techCasesList.clear();
						techCasesList.add(techCaseDetail);
						CaseResponseVO clonedCaseBean = (CaseResponseVO) caseBean.clone();
						clonedCaseBean.setTechCaseDetail(techCasesList);
						casesList.add(clonedCaseBean);
					}
				}
			}
		}
		return casesList;
	}


	/**
	 * This method populates teh details needed to be displayed in the
	 * RxExecutionDetails Page
	 * 
	 * @param solutionExecutionResponseType
	 * @return
	 */
	
	private SolutionExecutionResponseVO populateRxExecutionDetails(
			final SolutionExecutionResponseType solutionExecutionResponseType, String timeZone) {

		final SolutionExecutionResponseVO solExecResVo = new SolutionExecutionResponseVO();
		BeanUtils.copyProperties(solutionExecutionResponseType, solExecResVo);
		TaskDetailVO taskDetailVO;
		final List<TaskDetailVO> arlTaskDetail = new ArrayList<TaskDetailVO>();

		if (null != solutionExecutionResponseType.getSolutionDetail()) {

			BeanUtils.copyProperties( 
					solutionExecutionResponseType.getSolutionDetail(),
					solExecResVo.getSolutionDetail());
			solExecResVo.setSolutionFilePath(AppSecUtil.decodeString(solutionExecutionResponseType.getSolutionFilePath()));
			solExecResVo.setRxTitle(AppSecUtil.decodeString(solutionExecutionResponseType.getRxTitle()));
			solExecResVo.getSolutionDetail().setRevisionComments(
					AppSecUtil.decodeString(solutionExecutionResponseType
							.getSolutionDetail().getRevisionComments()));

		}
		final List<String> reComTaskList = new ArrayList<String>();
		if (null != solutionExecutionResponseType.getArlRecomTaskList()) {

			for (int i = 0; i < solutionExecutionResponseType
					.getArlRecomTaskList().size(); i++) {
				reComTaskList.add(solutionExecutionResponseType
						.getArlRecomTaskList().get(i));
			}
		}
		solExecResVo.setArlRecomTaskList(reComTaskList);

		if (null != solutionExecutionResponseType.getTaskDetail()) {

			for (int i = 0; i < solutionExecutionResponseType.getTaskDetail()
					.size(); i++) {

				taskDetailVO = new TaskDetailVO();
				BeanUtils.copyProperties(solutionExecutionResponseType
						.getTaskDetail().get(i), taskDetailVO);
				taskDetailVO.setTaskComments(EsapiUtil.resumeSpecialChars(AppSecUtil.decodeString(solutionExecutionResponseType
						.getTaskDetail().get(i).getTaskComments())));
				taskDetailVO.setTaskDesc(RMDCommonUtility.makeHttpHyperlinks(AppSecUtil.decodeString(solutionExecutionResponseType
						.getTaskDetail().get(i).getTaskDesc())));
				final XMLGregorianCalendar lastUpDate = solutionExecutionResponseType
						.getTaskDetail().get(i).getLastUpdateDate();
				if (null != lastUpDate) {
					final GregorianCalendar startDate = lastUpDate
							.toGregorianCalendar();
					taskDetailVO.setLastUpdatedDate(startDate.getTime());
				}

				final XMLGregorianCalendar rxCloseCreationDate = solutionExecutionResponseType
						.getTaskDetail().get(i).getCreationDate();
				if (null != rxCloseCreationDate) {
					final GregorianCalendar startDate = rxCloseCreationDate
							.toGregorianCalendar();
					taskDetailVO.setRxCloseCreationDate(startDate.getTime());
				}

				if (taskDetailVO.getCheckedFlag().equals(
						AppConstants.STATUS_TRUE)) {
					solExecResVo.setSelectedTask(AppConstants.TRUE);
				}
				taskDetailVO.setTaskComments(EsapiUtil.resumeSpecialChars(AppSecUtil.decodeString(solutionExecutionResponseType
						.getTaskDetail().get(i).getTaskComments())));
				taskDetailVO.setDocTitle(solutionExecutionResponseType		
						.getTaskDetail().get(i).getDocTitle());		
				taskDetailVO.setDocPath(solutionExecutionResponseType		
						.getTaskDetail().get(i).getDocPath());
				arlTaskDetail.add(taskDetailVO);
			}
			solExecResVo.setTaskDetail(arlTaskDetail);
		}

		solExecResVo.setRepairAction(EsapiUtil.resumeSpecialChars(AppSecUtil.decodeString(solutionExecutionResponseType.getRepairAction())));
		// Added for disabling submit button in RX_EX Screen
		// implementation:start
		final XMLGregorianCalendar closeDate = solutionExecutionResponseType
				.getClosedDate();			
		
		if (null != closeDate) {
			final GregorianCalendar startDate = closeDate.toGregorianCalendar();
			solExecResVo.setStrClosedDate(startDate.getTime());				
			String closedDateAge = RMDCommonUtil.calculateAge(startDate, new GregorianCalendar(), timeZone);
			solExecResVo.setStrClosedDateAge(closedDateAge);
		}
		solExecResVo.setLocationId(solutionExecutionResponseType
				.getRxLocationId());
		solExecResVo.setLocomotiveImpact(AppSecUtil.decodeString(solutionExecutionResponseType
				.getLocoImpact()));
		// Added for disabling submit button in RX_EX Screen implementation:end

		solExecResVo.setStrRecomId(solutionExecutionResponseType.getSolutionId());
		solExecResVo.setVersion(solutionExecutionResponseType.getVersion());

		return solExecResVo;
	}

	/**
	 * @param solutionExecutionResponseVO
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 * @Description: Method to call webservice for saving to Rx Execution
	 *               Details for a case.
	 */

	public void saveSolutionExecutionDetails(
			final SolutionExecutionResponseVO solutionExecutionResponseVO,
			final OpenCasesBean openCaseBean) throws Exception {

		final Map<String, String> headerParams = getHeaderMap(openCaseBean);

		try {

			webServiceInvoker.post(ServiceConstants.SAVE_RX_EXEC,
					populateSolutionRequestType(solutionExecutionResponseVO),
					headerParams);

		} catch (Exception ex) {
			RMDWebErrorHandler.handleException(ex);
		}

	}

	/**
	 * @param solutionExecutionResponseVO
	 * @throws Exception
	 * @Description: Method to call webservice for submitting to Rx Execution
	 *               Details for a case.
	 */
	public void submitSolutionExecutionDetails(
			final SolutionExecutionResponseVO solutionExecutionResponseVO,
			final OpenCasesBean openCaseBean) throws Exception {

		final Map<String, String> headerParams = getHeaderMap(openCaseBean);

		try {

			webServiceInvoker.post(ServiceConstants.SAVE_RX_EXEC,
					populateSolutionRequestType(solutionExecutionResponseVO),
					headerParams);

		} catch (Exception ex) {
			RMDWebErrorHandler.handleException(ex);
		}

	}

	/**
	 * 
	 * @param solutionExecutionResponseVO
	 * @return SolutionExecutionRequestType .
	 * @Description: This method populates SolutionExecutionRequestType JAXB
	 *               object properties with value from
	 *               SolutionExecutionResponseVO value object from the
	 *               controller to pass to webservice.
	 */

	private SolutionExecutionRequestType populateSolutionRequestType(
			final SolutionExecutionResponseVO solutionExecutionResponseVO) {
		final SolutionExecutionRequestType solutionExecutionRequestType = new SolutionExecutionRequestType();
		final List<TaskDetailType> arlTaskDetail = new ArrayList<TaskDetailType>();
		final List<String> reComTaskList = new LinkedList<String>();
		TaskDetailType objTaskDetailType = null;
		BeanUtils.copyProperties(solutionExecutionResponseVO,
				solutionExecutionRequestType);
		solutionExecutionRequestType
				.setSolutionExecutionId(solutionExecutionResponseVO
						.getSolutionExecutionID());

		for (TaskDetailVO objTaskDetailVO : solutionExecutionResponseVO
				.getTaskDetail()) {

			objTaskDetailType = new TaskDetailType();
			BeanUtils.copyProperties(objTaskDetailVO, objTaskDetailType);
			objTaskDetailType.setLastUpdatedBy(objTaskDetailVO
					.getLastUpdatedBy());
			objTaskDetailType.setTaskComments(AppSecUtil.htmlEscaping(objTaskDetailVO
					.getTaskComments()));
			objTaskDetailType
					.setLastUpdateDate(covertDateTOXMLGeorgianCalender(objTaskDetailVO
							.getLastUpdatedDate()));
			if (objTaskDetailVO.getCheckedFlag().equalsIgnoreCase(
					AppConstants.STATUS_TRUE)) {
				reComTaskList.add(objTaskDetailVO.getRecomTaskId());
			}
			objTaskDetailType.setIsTaskModified(objTaskDetailVO
					.getIsTaskModified());
			arlTaskDetail.add(objTaskDetailType);
		}

		solutionExecutionRequestType
				.setSolutionCloseFlag(solutionExecutionResponseVO
						.getRxCloseFlag());
		solutionExecutionRequestType.setTaskListID(reComTaskList);
		solutionExecutionRequestType.setTaskDetail(arlTaskDetail);
		solutionExecutionRequestType.setRepairAction(EsapiUtil.resumeSpecialChars(AppSecUtil.htmlEscaping(solutionExecutionRequestType.getRepairAction())));
		solutionExecutionRequestType
				.setRxLocationId(solutionExecutionResponseVO.getLocationId());
		solutionExecutionRequestType.setSolutionId(solutionExecutionResponseVO
				.getStrRecomId());
		solutionExecutionRequestType.setEndUserScoring(solutionExecutionResponseVO.getEndUserScoring());
		solutionExecutionRequestType.setUserSeqId(solutionExecutionResponseVO.getUserSeqId());

		return solutionExecutionRequestType;
	}

	private XMLGregorianCalendar covertDateTOXMLGeorgianCalender(final Date date) {

		try {

			final GregorianCalendar objGregorianCalendar = new GregorianCalendar();
			objGregorianCalendar.setTime(date);
			return DatatypeFactory.newInstance().newXMLGregorianCalendar(objGregorianCalendar);

		} catch (Exception ex) {
			return null;
		}
	}

	/**
	 * 
	 * @param solutionExecutionResponseVO
	 * 
	 * @throws Exception
	 * 
	 * @Description: Method to call webservice for submitting to Rx Execution
	 * 
	 *               Details for a case.
	 */

	public List<LocationVO> getRXEXLocations(final OpenCasesBean openCaseBean)
			throws RMDWebException, Exception {
		List<LocationVO> locationVOList = new ArrayList<LocationVO>();
		LocationVO locationVO = new LocationVO();
		AddressDetailType addressDetailType = null;
		try {
			final Map<String, String> queryParam = new LinkedHashMap<String, String>();
			final Map<String, String> headerParams = getHeaderMap(openCaseBean);
			queryParam.put(AppConstants.CUSTOMER_ID,
					openCaseBean.getCustomerId());
			LocationResponseType[] arrLocationResponseType = (LocationResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_RX_EXEC_LOCATIONS, null,
							queryParam, headerParams,
							LocationResponseType[].class);
			for (LocationResponseType locationResponseType : arrLocationResponseType) {
				locationVO = new LocationVO();
				addressDetailType = new AddressDetailType();
				addressDetailType = locationResponseType.getAddressDetail();
				locationVO.setStrLocationId(locationResponseType
						.getLocationId());
				locationVO.setStrLocationName(locationResponseType
						.getLocationName());
				locationVO.setStrLocationType(locationResponseType
						.getLocationType());
				locationVO.setStrCity(addressDetailType.getCity());
				locationVO.setStrState(addressDetailType.getState());
				locationVOList.add(locationVO);
			}

		} catch (Exception ex) {
			RMDWebErrorHandler.handleException(ex);
		}
		return locationVOList;

	}

	/*
	 * Function to get the No of days drop down value
	 */
	@Override
	public Map<String, String> getNoOfDays(String listName) throws Exception {
		Map<String, String> noOfDaysList = new HashMap<String, String>();
		try {
			List<ApplicationParametersResponseType> applParamResponseTypeList = cachedService
					.getAllLookupValues().get(listName);
			if (applParamResponseTypeList != null	&& !applParamResponseTypeList.isEmpty()) {

				for (ApplicationParametersResponseType objResponse : applParamResponseTypeList) {
					noOfDaysList.put(objResponse.getLookupValue(),
							objResponse.getLookupValue());
				}
			}
		} catch (Exception e) {
			RMDWebErrorHandler.handleException(e);
		}
		return noOfDaysList;
	}

	@Override
	public String getDeliverRxURL(String caseId) throws Exception {
		String result=null;
		try {
			final Map<String, String> queryParam = new LinkedHashMap<String, String>();
			queryParam.put(AppConstants.CASE_ID,
					caseId);
			result = (String) webServiceInvoker.get(
					ServiceConstants.GET_DELIVER_RX_URL, null, queryParam,
					null, String.class);
		} catch (Exception ex) {
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	@Override
	public String validateURL(String caseId, String fileName,String taskID) throws RMDWebException {
	
	TaskDetailType[] docTitle=null;
		String result = null;
		try {
			final Map<String, String> queryParam = new LinkedHashMap<String, String>();
			queryParam.put(AppConstants.CASE_ID,
					caseId);
			queryParam.put(AppConstants.FILENAME,
					fileName);
			queryParam.put(AppConstants.TASK_ID,
					taskID);
			docTitle = (TaskDetailType[]) webServiceInvoker.get(
					ServiceConstants.VALIDATE_URL, null, queryParam,
					null, TaskDetailType[].class);
			outerloop : for (TaskDetailType taskDetailType : docTitle) {
				if(taskDetailType.getDocTitle().equals(fileName)){
					result = AppConstants.SUCCESS;
					break outerloop;
				}
				else
				{
					result = AppConstants.FAILURE;
				}
			
			}
			
		} catch (Exception ex) {
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}



}
