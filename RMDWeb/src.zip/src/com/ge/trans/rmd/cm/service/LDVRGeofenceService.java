package com.ge.trans.rmd.cm.service;

import java.io.File;
import java.util.List;

import com.ge.trans.rmd.cm.valueobjects.LDVRGeofenceRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRGeofenceResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRSaveGeofenceRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRSaveGeofenceResponseVO;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface LDVRGeofenceService {
	LDVRGeofenceResponseVO getLDVRGeoZones(LDVRGeofenceRequestVO ldvrGeoZoneRequestVO) throws RMDWebException,Exception ;
	LDVRSaveGeofenceResponseVO saveUpdateLDVRGeoZones(List<LDVRSaveGeofenceRequestVO> ldvrSaveGeofenceRequestVOs) throws RMDWebException,Exception ;
	List<LDVRSaveGeofenceRequestVO> readXLS(File file, String userName,String customerId) throws RMDWebException, Exception;
}
