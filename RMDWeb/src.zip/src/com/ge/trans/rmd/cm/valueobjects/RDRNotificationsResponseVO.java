package com.ge.trans.rmd.cm.valueobjects;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * @author 212687474
 *
 */
public class RDRNotificationsResponseVO {
	protected List<RDRNotificationsVO> notifications;

	public List<RDRNotificationsVO> getNotifications() {
		return notifications;
	}

	public void setNotifications(List<RDRNotificationsVO> notifications) {
		this.notifications = notifications;
	}	
}
