package com.ge.trans.rmd.cm.valueobjects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.common.vo.RMDBaseVO;

@SuppressWarnings("serial")
public class VisualizationDataResponseVO extends RMDBaseVO{

	private List<String> colHeader;
	private List<String> lstAxisSide;
	private List<String> stackOrder;
	private ArrayList<ArrayList<ArrayList<Number>>> colData;
	private List<String> assets;
	private Map<String,String> errorMsgs;
	private String leftDependentAxis;
	private String rightDependentAxis;
	private String inDependentAxis;
	private String title;
	
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getLeftDependentAxis() {
		return leftDependentAxis;
	}

	public void setLeftDependentAxis(String leftDependentAxis) {
		this.leftDependentAxis = leftDependentAxis;
	}

	public String getRightDependentAxis() {
		return rightDependentAxis;
	}

	public void setRightDependentAxis(String rightDependentAxis) {
		this.rightDependentAxis = rightDependentAxis;
	}

	public String getInDependentAxis() {
		return inDependentAxis;
	}

	public void setInDependentAxis(String inDependentAxis) {
		this.inDependentAxis = inDependentAxis;
	}

	public List<String> getLstAxisSide() {
		return lstAxisSide;
	}

	public void setLstAxisSide(List<String> lstAxisSide) {
		this.lstAxisSide = lstAxisSide;
	}

	public List<String> getAssets() {
		return assets;
	}

	public void setAssets(List<String> assets) {
		this.assets = assets;
	}

	public List<String> getStackOrder() {
		return stackOrder;
	}

	public void setStackOrder(List<String> stackOrder) {
		this.stackOrder = stackOrder;
	}

	public List<String> getColHeader() {
		return colHeader;
	}
	
	public void setColHeader(List<String> colHeader) {
		this.colHeader = colHeader;
	}
	public ArrayList<ArrayList<ArrayList<Number>>> getColData() {
		return colData;
	}
	public void setColData(ArrayList<ArrayList<ArrayList<Number>>> colData) {
		this.colData = colData;
	}
	public Map<String, String> getErrorMsgs() {
		return errorMsgs;
	}
	public void setErrorMsgs(Map<String, String> errorMsgs) {
		this.errorMsgs = errorMsgs;
	}
	
	
	

}
