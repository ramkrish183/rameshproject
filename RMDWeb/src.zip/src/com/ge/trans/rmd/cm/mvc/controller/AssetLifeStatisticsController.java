/**
 * ============================================================
 * File : AssetLifeStatisticsController.java
 * Description : 
 * 
 * Package :  com.ge.trans.rmd.cm.mvc.controller
 * Author : iGATE 
 * Last Edited By :
 * Version : 1.0
 * Created on : Nov 21, 2014
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2013 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.AssetLifeStatisticsService;
import com.ge.trans.rmd.cm.service.AssetOverviewService;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.LifeStatisticsVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class AssetLifeStatisticsController extends RMDBaseController {
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	private AssetLifeStatisticsService lifeStatisticsService;
	@Autowired
	private AssetOverviewService asstOvwService;
	@Autowired
	private AuthorizationService authService;
	@Autowired
	private ApplicationContext appContext;
	@Autowired
	private CachedService cachedService;

	/**
	 * @return:ModelAndView
	 * @Description: Displays the life statistics page of the RMD application
	 */
	@RequestMapping(AppConstants.REQ_URI_LIFE_STATISTICS)
	public ModelAndView getLifeStatisticsPage(final HttpServletRequest request)
			throws RMDWebException, Exception {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String timezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		String lookBackDays;
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat fromDateFormat = new SimpleDateFormat(
				AppConstants.DATE_FORMAT_24HRS);
		/*Begin of Changes for fetching customer Id from Webservices */
		final String assetNumber=request.getParameter(AppConstants.REQ_PARAM_ASSTNUM);
		final String assetGrpName=request.getParameter(AppConstants.ASSET_GROUP_NAME);
		/*End OF Changes*/
		if (cachedService.getSDCustLookup().get(userVO.getCustomerId()) != null
                && cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat() != null
                && !cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat().trim().equals("")) {
			fromDateFormat = new SimpleDateFormat(cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat());
			request.setAttribute("dateFormat", cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat().replaceAll("HH", "hh"));
		} else {
			request.setAttribute("dateFormat", AppConstants.DATE_FORMAT_24HRS.replaceAll("HH", "hh"));
		}
		try {
			fromDateFormat.setTimeZone(TimeZone.getTimeZone(timezone));
			lookBackDays = authService
					.getLookUpValueForName(AppConstants.DEFAULT_ASSET_LIFESTATISTICS_LOOKBACK_DAYS);
			cal.add(Calendar.DATE, -Integer.parseInt(lookBackDays));
			String fromDate = fromDateFormat.format(cal.getTime());
			cal.add(Calendar.DATE, Integer.parseInt(lookBackDays));
			String toDate = fromDateFormat.format(cal.getTime());
			/*Added by Vamshi for fetching customerID from WebServices*/
			String customerId = asstOvwService.getCustomerId(assetNumber,
					assetGrpName);
			request.setAttribute(AppConstants.WS_PARAM_ASSTNUM, assetNumber);
			request.setAttribute(AppConstants.CUSTOMER_ID, customerId);
			request.setAttribute(AppConstants.ASSET_GROUP_NAME, assetGrpName);
			/*End of Changes*/
			request.setAttribute(AppConstants.PP_FROM_PREVOIUSDATE, fromDate);
			request.setAttribute(AppConstants.PP_CURRENT_DATE, toDate);

		} catch (Exception ex) {
			rmdWebLogger.error(
					AppConstants.EXCEPTION_IN_GETLIFESTATISTICSDATA, ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return new ModelAndView(AppConstants.LIFE_STATISTICS);
	}

	/**
	 * @return:LifeStatisticsVO
	 * @Description: Displays the life statistics page of the RMD application
	 */
	@RequestMapping(value = AppConstants.REQ_URI_LIFE_STATISTICS_DATA, method = RequestMethod.GET)
	@ResponseBody
	public LifeStatisticsVO getAssetLifeStatistics(
			final HttpServletRequest request) throws RMDWebException, Exception {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String timezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		SimpleDateFormat simpleDateFormat;
		AssetOverviewBean assetOverviewBean = new AssetOverviewBean();
		Long maxLookBackDays, dateDifference;
		String toDate = null;
		XMLGregorianCalendar xmlFromDate = null;
		XMLGregorianCalendar xmlToDate = null;
		Map<String, String> validationResult = new HashMap<String, String>();
		Date fromdate = null, todate = null;
		String errorString = null;
		GregorianCalendar fromgregorianCalendar, togregorianCalendar;
		LifeStatisticsVO resultLifeStatisticVO = new LifeStatisticsVO();
		simpleDateFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		String vvfHideL3Faults = null;
		boolean isVvfHideL3Faults = false;
		try {
			final String assetNumber = request
					.getParameter(AppConstants.REQ_PARAM_ASSTNUM);
			final String customerID = request
					.getParameter(EsapiUtil.stripXSSCharacters(AppConstants.CUSTOMER_ID));
			final String assetGrpName = request
					.getParameter(EsapiUtil.stripXSSCharacters(AppConstants.ASSET_GROUP_NAME));
			assetOverviewBean.setAsset(assetNumber);
			assetOverviewBean.setUserTimeZone(timezone);
			assetOverviewBean.setUserLanguage(userVO.getStrUserLanguage());
			assetOverviewBean.setCustomer(customerID);
			assetOverviewBean.setAssetGroup(assetGrpName);
			assetOverviewBean = asstOvwService.getAssets(assetOverviewBean);
			assetOverviewBean.setCustomer(customerID);
			vvfHideL3Faults = authService.getLookUpValueForName(AppConstants.DATASCREEN_VVF_HIDE_L3_FAULTS);
			isVvfHideL3Faults = RMDCommonUtil.componentValue(userVO.getComponentList(), vvfHideL3Faults);
			assetOverviewBean.setHideL3Fault(isVvfHideL3Faults);
			if (null != request.getParameter(AppConstants.FROM_DATE)
					&& !request.getParameter(AppConstants.FROM_DATE).isEmpty()) {
				String fromDate = request.getParameter(AppConstants.FROM_DATE);
				fromdate = simpleDateFormat.parse(fromDate);
				fromgregorianCalendar = (GregorianCalendar) GregorianCalendar
						.getInstance();
				fromgregorianCalendar.setTime(fromdate);
				RMDCommonUtility.setZoneOffsetTime(fromgregorianCalendar,
						timezone);
				xmlFromDate = DatatypeFactory.newInstance()
						.newXMLGregorianCalendar(fromgregorianCalendar);
				assetOverviewBean.setFromDate(xmlFromDate);

				if (null != request.getParameter(AppConstants.TO_DATE)
						&& !request.getParameter(AppConstants.TO_DATE)
								.isEmpty()) {
					toDate = request.getParameter(AppConstants.TO_DATE);
					todate = simpleDateFormat.parse(toDate);
					togregorianCalendar = (GregorianCalendar) GregorianCalendar
							.getInstance();
					togregorianCalendar.setTime(todate);
					RMDCommonUtility.setZoneOffsetTime(togregorianCalendar,
							timezone);
					xmlToDate = DatatypeFactory.newInstance()
							.newXMLGregorianCalendar(togregorianCalendar);
					assetOverviewBean.setToDate(xmlToDate);
					if (togregorianCalendar.getTimeInMillis()
							- fromgregorianCalendar.getTimeInMillis() < 0) {
						resultLifeStatisticVO
								.setErrorString(AppConstants.ERROR_DATE_RANGE);
						return resultLifeStatisticVO;
					}

				} else if ((null == request.getParameter(AppConstants.TO_DATE) || request
						.getParameter(AppConstants.TO_DATE).isEmpty())) {
					resultLifeStatisticVO
							.setErrorString(AppConstants.ERROR_TO_DATE_EMPTY);
					return resultLifeStatisticVO;
				}
			} else {
				errorString = AppConstants.ERROR_FROM_DATE_EMPTY;
			}
			if (null == errorString) {
				resultLifeStatisticVO = lifeStatisticsService
						.getassetLifeStatistics(assetOverviewBean, userVO.getCustomerId());

			} else {
				resultLifeStatisticVO.setErrorMap(validationResult);
				resultLifeStatisticVO.setErrorString(errorString);
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					AppConstants.EXCEPTION_IN_GETLIFESTATISTICSDATA, ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return resultLifeStatisticVO;
	}

	/**
	 * @Description:This method is used for calling the serviceImpl in turn
	 *                   which will call webservices and bring the records for
	 *                   download
	 * @return: void
	 * @param:HttpServletRequest request,HttpServletResponse response,Locale
	 *                           locale
	 * @throws RMDWebException
	 * @throws GenericAjaxException
	 */
	@RequestMapping(value = AppConstants.EXPORT_ASSET_lIFE_STAT, method = RequestMethod.POST)
	public void exportDataFleets(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws IOException, GenericAjaxException, RMDWebException {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String timezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		SimpleDateFormat simpleDateFormat;
		AssetOverviewBean assetOverviewBean = new AssetOverviewBean();
		String toDate = null;
		XMLGregorianCalendar xmlFromDate = null;
		XMLGregorianCalendar xmlToDate = null;
		Date fromdate = null, todate = null;
		GregorianCalendar fromgregorianCalendar, togregorianCalendar;
		LifeStatisticsVO resultLifeStatisticVO = new LifeStatisticsVO();
		simpleDateFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		try {
			final String assetNumber = request
					.getParameter(AppConstants.REQ_PARAM_ASSTNUM);
			final String customerID = request
					.getParameter(AppConstants.CUSTOMER_ID);
			final String assetGrpName = request
					.getParameter(AppConstants.ASSET_GROUP_NAME);
			assetOverviewBean.setAsset(assetNumber);
			assetOverviewBean.setUserTimeZone(timezone);
			assetOverviewBean.setUserLanguage(userVO.getStrUserLanguage());
			assetOverviewBean.setCustomer(customerID);
			assetOverviewBean.setAssetGroup(assetGrpName);
			assetOverviewBean = asstOvwService.getAssets(assetOverviewBean);
			assetOverviewBean.setCustomer(customerID);
			String fromDate = request.getParameter(AppConstants.FROM_DATE);
			fromdate = simpleDateFormat.parse(fromDate);
			fromgregorianCalendar = (GregorianCalendar) GregorianCalendar
					.getInstance();
			fromgregorianCalendar.setTime(fromdate);
			RMDCommonUtility.setZoneOffsetTime(fromgregorianCalendar, timezone);
			xmlFromDate = DatatypeFactory.newInstance()
					.newXMLGregorianCalendar(fromgregorianCalendar);
			assetOverviewBean.setFromDate(xmlFromDate);
			toDate = request.getParameter(AppConstants.TO_DATE);
			todate = simpleDateFormat.parse(toDate);
			togregorianCalendar = (GregorianCalendar) GregorianCalendar
					.getInstance();
			togregorianCalendar.setTime(todate);
			RMDCommonUtility.setZoneOffsetTime(togregorianCalendar, timezone);
			xmlToDate = DatatypeFactory.newInstance().newXMLGregorianCalendar(
					togregorianCalendar);
			assetOverviewBean.setToDate(xmlToDate);
			resultLifeStatisticVO = lifeStatisticsService
					.getassetLifeStatistics(assetOverviewBean, userVO.getCustomerId());
			csvContent = convertToCSVAssetLifeStat(resultLifeStatisticVO,
					locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.ASSET_LIFESTATISTICS_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);

			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);

			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}

		} catch (Exception ex) {
			rmdWebLogger.error(
					AppConstants.EXCEPTION_IN_GETLIFESTATISTICSDATA, ex);
			RMDWebErrorHandler.handleException(ex);
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}

	private String convertToCSVAssetLifeStat(
			LifeStatisticsVO resultLifeStatisticVO, Locale locale) {
		String csvContent = null;
		StringBuilder strBufferAssetHeader = new StringBuilder();
		try {
			strBufferAssetHeader.append(appContext.getMessage(
					AppConstants.LIFE_STAT_HEADER, null, locale));
			for (String currentDate : resultLifeStatisticVO
					.getHeaderDatesList()) {
				strBufferAssetHeader.append(RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE + AppConstants.EMPTY_SPACE
						+ currentDate + AppConstants.QUOTE);
			}
			strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			for (Map.Entry<String, Map<String, String>> entry : resultLifeStatisticVO
					.getTimeStampValueMap().entrySet()) {
				String AttributeAndUnit = entry.getKey();
				String name = AttributeAndUnit.substring(0, AttributeAndUnit.lastIndexOf("_"));
				String unit = AttributeAndUnit.substring(AttributeAndUnit.lastIndexOf("_") + 1, AttributeAndUnit.length());
				if(null != name && !"".equalsIgnoreCase(name) && name.contains(",")) {
						name = "\"" + name + "\"";
						
				 } 
				if(null != name)
				{
				name = name.replaceAll("\n", "");
				}
				strBufferAssetHeader
						.append(name
								+ RMDCommonConstants.COMMMA_SEPARATOR
								+ AppConstants.QUOTE
								+ unit
								+ AppConstants.QUOTE);

				for (String currentDate : resultLifeStatisticVO
						.getHeaderDatesList()) {
					strBufferAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ entry.getValue().get(currentDate)
									+ AppConstants.QUOTE);
				}
				strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBufferAssetHeader.toString();
		} catch (Exception exception) {
			rmdWebLogger.error("Export to CSV Asset life Stat"
					+ exception);
		}
		return csvContent;
	}
}
