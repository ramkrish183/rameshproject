package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

public class AssetLDVRDataVO {

	private List<LDVRPreservationRequestTemplateVO>  activePreservationTemplates;
	private List<ActiveLcvLDVRCamDetailsVO>  activeLcvLDVRCamDetails;
	/**
	 * @return the activePreservationTemplates
	 */
	public List<LDVRPreservationRequestTemplateVO> getActivePreservationTemplates() {
		return activePreservationTemplates;
	}
	/**
	 * @param activePreservationTemplates the activePreservationTemplates to set
	 */
	public void setActivePreservationTemplates(
			List<LDVRPreservationRequestTemplateVO> activePreservationTemplates) {
		this.activePreservationTemplates = activePreservationTemplates;
	}
	/**
	 * @return the activeLcvLDVRCamDetails
	 */
	public List<ActiveLcvLDVRCamDetailsVO> getActiveLcvLDVRCamDetails() {
		return activeLcvLDVRCamDetails;
	}
	/**
	 * @param activeLcvLDVRCamDetails the activeLcvLDVRCamDetails to set
	 */
	public void setActiveLcvLDVRCamDetails(
			List<ActiveLcvLDVRCamDetailsVO> activeLcvLDVRCamDetails) {
		this.activeLcvLDVRCamDetails = activeLcvLDVRCamDetails;
	}

}
