package com.ge.trans.rmd.cm.valueobjects;

import java.util.Map;

public class CreateCaseLookUpVO {
	Map<String,String> repairTimeMap ;
	Map<String,String> urgencyOfRepMap ;
	Map<String,String> modelTypeMap;
	Map<String,String> selectByMap;
	Map<String,String> ConditionMap;
	
	private String model;
	
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public Map<String, String> getRepairTimeMap() {
	return repairTimeMap;
	}
	public void setRepairTimeMap(Map<String, String> repairTimeMap) {
	this.repairTimeMap = repairTimeMap;
	}
	public Map<String, String> getUrgencyOfRepMap() {
	return urgencyOfRepMap;
	}
	public void setUrgencyOfRepMap(Map<String, String> urgencyOfRepMap) {
	this.urgencyOfRepMap = urgencyOfRepMap;
	}
	public Map<String, String> getModelTypeMap() {
	return modelTypeMap;
	}
	public void setModelTypeMap(Map<String, String> modelTypeMap) {
	this.modelTypeMap = modelTypeMap;
	}
	public Map<String, String> getSelectByMap() {
	return selectByMap;
	}
	public void setSelectByMap(Map<String, String> selectByMap) {
	this.selectByMap = selectByMap;
	}
	public Map<String, String> getConditionMap() {
	return ConditionMap;
	}
	public void setConditionMap(Map<String, String> conditionMap) {
	ConditionMap = conditionMap;
	}


}
