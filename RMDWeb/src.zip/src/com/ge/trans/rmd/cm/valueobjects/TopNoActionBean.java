package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;
import java.util.Map;

public class TopNoActionBean {
	private Map<String, List<String>> topNoActionRX;

	public Map<String, List<String>> getTopNoActionRX() {
		return topNoActionRX;
	}

	public void setTopNoActionRX(Map<String, List<String>> topNoActionRX) {
		this.topNoActionRX = topNoActionRX;
	}

}
