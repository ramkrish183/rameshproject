/**
 * ============================================================
 * Classification: GE Confidential
 * File : ApplyCfgTemplateVO.java
 * Description :
 *
 * Package : com.ge.trans.eoa.services.assets.resources;
 * Author : Capgemini India
 * Last Edited By :
 * Version : 1.0
 * Created on : October 6, 2016
 * History
 * Modified By : iGATE
 *
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

public class ApplyCfgTemplateVO {

	private List<VerifyCfgTemplateVO> cfgTemplateList;
	private String userName;
	private String ctrlCfgObjId;
	private String searchType;
	private String ctrlCfgName;
	private boolean deleteCfgAction;
	private String customerName;
	private String userId;
	private String vehHdrNo;
	private String customerId;
	private String device;

	private List<CfgAssetSearchVO> arlAssetSearchVOs;

	public List<CfgAssetSearchVO> getArlAssetSearchVOs() {
		return arlAssetSearchVOs;
	}

	public void setArlAssetSearchVOs(List<CfgAssetSearchVO> arlAssetSearchVOs) {
		this.arlAssetSearchVOs = arlAssetSearchVOs;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCtrlCfgName() {
		return ctrlCfgName;
	}

	public void setCtrlCfgName(String ctrlCfgName) {
		this.ctrlCfgName = ctrlCfgName;
	}

	public boolean isDeleteCfgAction() {
		return deleteCfgAction;
	}

	public void setDeleteCfgAction(boolean deleteCfgAction) {
		this.deleteCfgAction = deleteCfgAction;
	}

	public String getSearchType() {
		return searchType;
	}

	public void setSearchType(String searchType) {
		this.searchType = searchType;
	}

	public String getCtrlCfgObjId() {
		return ctrlCfgObjId;
	}

	public void setCtrlCfgObjId(String ctrlCfgObjId) {
		this.ctrlCfgObjId = ctrlCfgObjId;
	}

	public List<VerifyCfgTemplateVO> getCfgTemplateList() {
		return cfgTemplateList;
	}

	public void setCfgTemplateList(List<VerifyCfgTemplateVO> cfgTemplateList) {
		this.cfgTemplateList = cfgTemplateList;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getVehHdrNo() {
        return vehHdrNo;
    }

    public void setVehHdrNo(String vehHdrNo) {
        this.vehHdrNo = vehHdrNo;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getDevice() {
        return device;
    }

    public void setDevice(String device) {
        this.device = device;
    }
    
    
	
	

}
