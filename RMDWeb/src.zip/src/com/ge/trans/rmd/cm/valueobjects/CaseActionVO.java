package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;
import java.util.Map;
import org.apache.commons.collections.map.MultiValueMap;


public class CaseActionVO {
	
	private List<ToolOutputDeliverVO> deliverVO;
	private List<ToolOutputCaseAppendVO> caseAppendVO;
	private List<ToolOutputCaseCloseVO> caseCloseVO;
	private String userName;
	private String userId;
	private String userLanguage;
	private List<ToolOutputCaseMergeVO> caseMergeVO;
	private MultiValueMap mergeVOMap;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserLanguage() {
		return userLanguage;
	}
	public void setUserLanguage(String userLanguage) {
		this.userLanguage = userLanguage;
	}
	public List<ToolOutputDeliverVO> getDeliverVO() {
		return deliverVO;
	}
	public void setDeliverVO(List<ToolOutputDeliverVO> deliverVO) {
		this.deliverVO = deliverVO;
	}
	public List<ToolOutputCaseAppendVO> getCaseAppendVO() {
		return caseAppendVO;
	}
	public void setCaseAppendVO(List<ToolOutputCaseAppendVO> caseAppendVO) {
		this.caseAppendVO = caseAppendVO;
	}
	public List<ToolOutputCaseCloseVO> getCaseCloseVO() {
		return caseCloseVO;
	}
	public void setCaseCloseVO(List<ToolOutputCaseCloseVO> caseCloseVO) {
		this.caseCloseVO = caseCloseVO;
	}
	public List<ToolOutputCaseMergeVO> getCaseMergeVO() {
		return caseMergeVO;
	}
	public void setCaseMergeVO(List<ToolOutputCaseMergeVO> caseMergeVO) {
		this.caseMergeVO = caseMergeVO;
	}
	public MultiValueMap getMergeVOMap() {
		return mergeVOMap;
	}
	public void setMergeVOMap(MultiValueMap mergeVOMap) {
		this.mergeVOMap = mergeVOMap;
	}

		/**
	 * @return the mergeVOMap
	 */

	
	
}
