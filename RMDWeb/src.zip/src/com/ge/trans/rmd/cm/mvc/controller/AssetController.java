package com.ge.trans.rmd.cm.mvc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
@Controller
@SessionAttributes
public class AssetController extends RMDBaseController {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	
	@RequestMapping(AppConstants.REQ_URI_ASSET)
	public ModelAndView showCases() {
		return new ModelAndView(AppConstants.VIEW_ASSET);
	}
	
	@RequestMapping(AppConstants.REQ_URI_ASSET_COMM_REPORT)
	public ModelAndView getCommReport(final HttpServletRequest request) throws GenericAjaxException, RMDWebException {
		rmdWebLogger
    	.debug("Inside getwelcome in welcome controller ");
    	try {
    		HttpSession session = request.getSession(false);
    		UserVO userVO = (UserVO) session
    				.getAttribute(AppConstants.ATTR_USER_OBJECT);
    		request.setAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE,
    				userVO.getIsCMPrivilege());
    		
    	} catch (Exception ex) {
    		rmdWebLogger
    		.error("Exception occured in Inside getwelcome in welcome controller ",
    				ex);
    		RMDWebErrorHandler.handleException(ex);
    		}
		return new ModelAndView(AppConstants.COMM_REPORT);
	}
}
