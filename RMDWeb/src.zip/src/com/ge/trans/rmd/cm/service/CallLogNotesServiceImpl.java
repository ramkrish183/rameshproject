package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.CallLogNotesVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.assets.valueobjects.CallLogNotesResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;


@Service
public class CallLogNotesServiceImpl extends RMDBaseServiceImpl implements
		CallLogNotesService {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	WebServiceInvoker webServiceInvoker;

	@Override
	public List<CallLogNotesVO> getCallLogNotes(CallLogNotesVO callLogNotesVO,String userTimeZone)
			throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		List<CallLogNotesVO> lstCallLogNotes = new ArrayList<CallLogNotesVO>();
		/*final DateFormat nonESTZoneFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		final TimeZone firstTime = TimeZone.getTimeZone(userTimeZone);
		nonESTZoneFormat.setTimeZone(firstTime);	*/
		try {
			queryParams.put(AppConstants.FROM_DATE, callLogNotesVO.getFromDate());
			queryParams.put(AppConstants.TO_DATE, callLogNotesVO.getToDate());
			queryParams.put(AppConstants.ASSET_NUMBER, callLogNotesVO.getAssetNumber());
			queryParams.put(AppConstants.CUSTOMER_ID, callLogNotesVO.getCustomerId());
			queryParams.put(AppConstants.ASSET_GROUP_NAME, callLogNotesVO.getAssetGroupName());
			queryParams.put(AppConstants.TO_DATE, callLogNotesVO.getToDate());
			queryParams.put(AppConstants.ATTR_TIME_ZONE, userTimeZone);
			
			CallLogNotesResponseType[] arrResponseType = (CallLogNotesResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_CALL_LOG_NOTES, null, queryParams,
							null, CallLogNotesResponseType[].class);
			if (null != arrResponseType) {
				lstCallLogNotes = new ArrayList<CallLogNotesVO>(arrResponseType.length);
				for (CallLogNotesResponseType objCallLogReponseType : arrResponseType) {					
					CallLogNotesVO resultCallLogVO = new CallLogNotesVO();
					resultCallLogVO.setCallLogID(objCallLogReponseType.getCallLogID());
					resultCallLogVO.setCallerName(objCallLogReponseType.getCallerName());
					resultCallLogVO.setCustomerId(objCallLogReponseType.getCustomerId());
					resultCallLogVO.setAgentSSO(objCallLogReponseType.getAgentSSO());
					resultCallLogVO.setAgentName(objCallLogReponseType.getAgentName());
					resultCallLogVO.setBusniessArea(objCallLogReponseType.getBusniessArea());
					resultCallLogVO.setCallType(objCallLogReponseType.getCallType());
					resultCallLogVO.setIssueType(objCallLogReponseType.getIssueType());
					resultCallLogVO.setLocation(objCallLogReponseType.getLocation());
					//Added for US276325    GPOC: SFDC - OMD Integration - Showing two additional columns in OMD call log screen
					if(!RMDCommonUtility.isNullOrEmpty(objCallLogReponseType.getCreationDate())){
					    resultCallLogVO
	                     .setCreationDate(RMDCommonUtility.convertDateFormatAndTimezone(
	                             objCallLogReponseType.getCreationDate(),
	                             RMDCommonConstants.DateConstants.MMddyyyyHHmmss,
	                             RMDCommonConstants.DateConstants.MMddyyyyHHmmss,
	                             AppConstants.TIMEZONE_EASTERN, userTimeZone));
					}
					
					/*if (userTimeZone.equals(AppConstants.EST_TIMEZONE)) {
						resultCallLogVO.setCreationDate(objCallLogReponseType.getCreationDate());	
					} else {
						creationTime = RMDCommonUtility.stringToUSESTDate(
								objCallLogReponseType.getCreationDate(),
								RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
						resultCallLogVO.setCreationDate(nonESTZoneFormat
								.format(creationTime));
					}				*/
					 if(!RMDCommonUtility.isNullOrEmpty(objCallLogReponseType.getCallStartedOn())){
					     resultCallLogVO
                         .setCallStartedOn(RMDCommonUtility.convertDateFormatAndTimezone(
                                 objCallLogReponseType.getCallStartedOn(),
                                 RMDCommonConstants.DateConstants.MMddyyyyHHmmss,
                                 RMDCommonConstants.DateConstants.MMddyyyyHHmmss,
                                 AppConstants.TIMEZONE_EASTERN, userTimeZone));
					 }
                   
					resultCallLogVO.setNotes(objCallLogReponseType.getNotes());
					resultCallLogVO.setCallDurationSeconds(objCallLogReponseType.getCallDurationSeconds());
					 if(!RMDCommonUtility.isNullOrEmpty(objCallLogReponseType.getCallEndedOn())){
					     resultCallLogVO
		                    .setCallEndedOn(RMDCommonUtility.convertDateFormatAndTimezone(
		                            objCallLogReponseType.getCallEndedOn(),
		                            RMDCommonConstants.DateConstants.MMddyyyyHHmmss,
		                            RMDCommonConstants.DateConstants.MMddyyyyHHmmss,
		                            AppConstants.TIMEZONE_EASTERN, userTimeZone));
					 }
					
					lstCallLogNotes.add(resultCallLogVO);
				}
				arrResponseType = null;
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCallLogNotes method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lstCallLogNotes;
	}
}
