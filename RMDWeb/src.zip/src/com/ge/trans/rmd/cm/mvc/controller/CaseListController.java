/**
 * ============================================================
 * File : CaseListController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.cm.mvc.controller
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Mar 05, 2012
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */

package com.ge.trans.rmd.cm.mvc.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.SortedSet;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.OpenCasesService;
import com.ge.trans.rmd.cm.valueobjects.OpenCasesVO;
import com.ge.trans.rmd.common.beans.HeaderSearchBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.HeaderSearchService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.HeaderSearchResponseVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.common.vo.CustomerVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class CaseListController extends RMDBaseController {

	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private HeaderSearchService headerSearchService;

	@Autowired
	private OpenCasesService openCasesService;

	@RequestMapping(AppConstants.REQ_URI_CASELIST)
	public ModelAndView showCaseList(final HttpServletRequest request)
			throws RMDWebException, Exception {
		request.setAttribute(AppConstants.FILTERFLAG,
				request.getParameter(AppConstants.FLAG));

		List<OpenCasesVO> openCaseVOLst = new ArrayList<OpenCasesVO>();

		final HttpSession session = request.getSession(false);
		final HeaderSearchBean headerSearchBean = new HeaderSearchBean();
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String searchString = request
				.getParameter(AppConstants.HEADERSEARCH_SEARCH_STRING);
		HeaderSearchResponseVO responseVO=null; 
		String customerList="";
		try {
			if (null != searchString && searchString.trim().length() > 0) {
				headerSearchBean.setUserLanguage(userVO.getStrUserLanguage());
				headerSearchBean.setStrCustomerId(userVO.getCustomerId());
				headerSearchBean.setTimeZone(userVO.getTimeZone());
				headerSearchBean.setSearchString(searchString);
				if (userVO.getIsCMPrivilege()
						&& null != userVO.getCmAliasName()
						&&!RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(userVO
								.getCmAliasName())) {
				if (!RMDCommonUtility.isNullOrEmpty(userVO.getCustomerId())) {
					customerList = getCustomerList(userVO.getCustomerList());
					headerSearchBean.setStrCustomerId(customerList);
				}
				}
				if (null != userVO.getProducts()
						&& !userVO.getProducts().isEmpty()) {
				headerSearchBean.setProducts(userVO.getProducts());
				}
				try {
					if(null!=userVO.getProducts()&& !userVO.getProducts().isEmpty()){
						responseVO = headerSearchService
							.getCases(headerSearchBean);
					}
					if (null != responseVO) {
						openCaseVOLst = responseVO.getCases();
					}

				} catch (Exception ex) {
					rmdWebLogger.error("Exception occured in showCaseList method ",
							ex);
					request.setAttribute(AppConstants.ERRORMSG,
							AppConstants.UNKNOWN_EXCEPTION);

				}

				request.setAttribute(AppConstants.OPENCASES_VO_LST,
						openCaseVOLst);
				request.setAttribute(AppConstants.HEADERSEARCH_SEARCH_STRING,
						searchString);
				
				if(null != request.getParameter(AppConstants.DATA_CASE_LENGTH)){
					request.setAttribute(AppConstants.DATA_CASE_LENGTH,
							request.getParameter(AppConstants.DATA_CASE_LENGTH));
				}else if(null != openCaseVOLst){
					request.setAttribute(AppConstants.DATA_CASE_LENGTH, openCaseVOLst.size());
				}
				
				if(null != request.getParameter(AppConstants.DATA_ASSET_LENGTH)){
					request.setAttribute(AppConstants.DATA_ASSET_LENGTH,
						request.getParameter(AppConstants.DATA_ASSET_LENGTH));
				}

				final SortedSet<Entry<String, String>> mapDropdown = openCasesService
						.getDropDownValues();

				if (mapDropdown != null) {
					request.setAttribute(AppConstants.OPENCASES_DROPDOWN,
							mapDropdown);
				}
				
				
			}
			//adding for pagination - Start
			request.setAttribute(
					AppConstants.CASELIST_DEFAULT_RECORDS,
					findNumberOfRecords(AppConstants.CASELIST_TABLE_DEFAULT_RECORDS));
			return new ModelAndView(AppConstants.VIEW_CASELIST);

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error("RMDWebException occured in showCaseList() method ",
					rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in showCaseList method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		}

	}
}
