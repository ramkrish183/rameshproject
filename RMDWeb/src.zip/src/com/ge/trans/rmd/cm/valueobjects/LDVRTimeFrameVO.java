package com.ge.trans.rmd.cm.valueobjects;

public class LDVRTimeFrameVO {
	private String requestedStartTime;

	public String getRequestedStartTime() {
		return requestedStartTime;
	}

	public void setRequestedStartTime(String requestedStartTime) {
		this.requestedStartTime = requestedStartTime;
	}
	
	
}
