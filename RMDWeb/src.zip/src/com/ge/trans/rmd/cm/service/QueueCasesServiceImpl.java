package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;

import javax.xml.datatype.XMLGregorianCalendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.QueueCaseVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.cases.valueobjects.QueueCaseResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class QueueCasesServiceImpl extends RMDBaseServiceImpl implements
		QueueCasesService {

	@Autowired
	WebServiceInvoker webServiceInvoker;
	
	private final String ENDSTR = ")";
	private final String STARTSTR = "(";
	private final String EMPTYSTR = " ";
	private final String MINSTR = "min";
	private final String HRSSTR = "hrs";
	private final String DAYSTR = "d";
	private final RMDWebLogger logger = RMDWebLogger.getLogger(getClass());
	
	
	/**
	 * @Author:
	 * @param:String queueobjid, String customerId,String timeZone
	 * @return:List<QueueCaseVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching list of Cases Associated
	 *               to particular Queue by Invoking WebServices
	 */
	@Override
	public List<QueueCaseVO> getQueueCases(String queueobjid,
			String customerId, String timeZone, String defaultTimezone) throws RMDWebException,
			Exception {
		logger.debug("QueueCasesServiceImpl : Inside getQueueCases() method:::::START");
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		QueueCaseResponseType[] arrQueueCaseResponseType = null;
		List<QueueCaseVO> lstQueueCaseVO = null;
		Date creationTime = null;
		final TimeZone firstTime = TimeZone.getTimeZone(timeZone);
		final DateFormat nonESTZoneFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		StringBuffer sb = new StringBuffer();
		nonESTZoneFormat.setTimeZone(firstTime);
		String userTimeZone = firstTime.getID();
		try {
			queryParamsMap.put(AppConstants.REQ_PARAM_CUSID, customerId);
			queryParamsMap.put(AppConstants.QUEUE_OBJ_ID, queueobjid);
			arrQueueCaseResponseType = (QueueCaseResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_QUEUE_CASES, null,
							queryParamsMap, null, QueueCaseResponseType[].class);
			if (arrQueueCaseResponseType != null) {
				lstQueueCaseVO = new ArrayList<QueueCaseVO>(arrQueueCaseResponseType.length);
				for (QueueCaseResponseType queueCaseRespType : arrQueueCaseResponseType) {
					QueueCaseVO queueCaseVO = new QueueCaseVO();
					queueCaseVO.setCaseId(queueCaseRespType.getCaseId());
					queueCaseVO.setSitepartSerialNo(queueCaseRespType
							.getSitepartSerialNo());
					queueCaseVO
							.setVehHdrCust(queueCaseRespType.getVehHdrCust());
					queueCaseVO.setVehHdr(queueCaseRespType.getVehHdr());
					queueCaseVO.setTitle(queueCaseRespType.getTitle());
					queueCaseVO.setPriority(queueCaseRespType.getPriority());
					queueCaseVO.setSeverity(queueCaseRespType.getSeverity());
					
					
					if (queueCaseRespType.getAge() != null && !queueCaseRespType.getAge().isEmpty()) {
						sb = new StringBuffer(queueCaseRespType.getAge().trim());
						replaceAgeStr(sb);
						queueCaseVO.setAge(sb.toString());
					}

					/*if (null !=queueCaseRespType.getAge()) {
						final XMLGregorianCalendar latModifyDate = queueCaseRespType.getAge();
						final GregorianCalendar modifyDate = latModifyDate
								.toGregorianCalendar();
						modifyDate.setTimeZone(firstTime);
						
						String age = RMDCommonUtil.calculateAge(modifyDate,
								new GregorianCalendar(),
								timeZone);
						queueCaseVO.setAge(age);
					}*/
					
					if (userTimeZone.equals(AppConstants.EST_TIMEZONE)
							&& defaultTimezone.equals(AppConstants.TIMEZONE_EASTERN)) {
						if (null != queueCaseRespType.getCreationTime()) {
							queueCaseVO.setCreationTime(queueCaseRespType.getCreationTime());
						}

					} else {
						if (null != queueCaseRespType.getCreationTime()) {
							creationTime = RMDCommonUtility.stringToUSESTDate(
									queueCaseRespType.getCreationTime(),
									RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
							queueCaseVO.setCreationTime(nonESTZoneFormat.format(creationTime));
						}
					}
					
					/*if (null != queueCaseRespType.getCreationTime()) {
						queueCaseVO.setCreationTime(RMDCommonUtility
								.convertXMLGregorianCalenderToString(
										queueCaseRespType.getCreationTime(),
										timeZone));
					}*/
					queueCaseVO.setStatus(queueCaseRespType.getStatus());
					queueCaseVO.setCondition(queueCaseRespType.getCondition());
					queueCaseVO.setUserLoginName(queueCaseRespType
							.getUserLoginName());
					queueCaseVO
							.setCustomerId(queueCaseRespType.getCustomerId());
					lstQueueCaseVO.add(queueCaseVO);
				} 
			} arrQueueCaseResponseType=null;

		} catch (Exception ex) {
			logger.error("Exception occured in getQueueCases method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		logger.debug("QueueCasesServiceImpl : Inside getQueueCases() method:::::END");
		return lstQueueCaseVO;
	}

	
	void replaceAgeStr(StringBuffer sb) {
		
	    /* Logic to get Hrs,Mins and Secs*/
        StringBuffer days= new StringBuffer(sb.substring(0, sb.indexOf(RMDCommonConstants.BLANK_SPACE)));
        StringBuffer hrs= new StringBuffer(sb.substring(sb.indexOf(RMDCommonConstants.BLANK_SPACE)+1, sb.indexOf(RMDCommonConstants.FULL_COLON)));
        StringBuffer mins= new StringBuffer(sb.substring(sb.indexOf(RMDCommonConstants.FULL_COLON)+1));
        /*End of Hrs,Mins and Secs*/
        
        /*Logic to remove the starting 0's from Hrs,Mins and Secs*/
        if(days.charAt(0)==RMDCommonConstants.CHAR_ZERO && days.charAt(1)==RMDCommonConstants.CHAR_ZERO )
            days=days.replace(0, 2,RMDCommonConstants.EMPTY_STRING);
        else if(days.charAt(0)==RMDCommonConstants.CHAR_ZERO ){
            days=days.replace(0,1,RMDCommonConstants.EMPTY_STRING);
        }
        if(hrs.charAt(0)==RMDCommonConstants.CHAR_ZERO ){
            hrs=hrs.replace(0,1,RMDCommonConstants.EMPTY_STRING);
        }
        if(mins.charAt(0)==RMDCommonConstants.CHAR_ZERO){
            mins=mins.replace(0,1,RMDCommonConstants.EMPTY_STRING);
        }
        /*End of remove the starting 0's*/
        sb.setLength(0);
        sb.append(STARTSTR+days+DAYSTR+RMDCommonConstants.BLANK_SPACE+hrs+HRSSTR+RMDCommonConstants.BLANK_SPACE+mins+MINSTR+ENDSTR);    
	}
	/**
	 * @Author:
	 * @param:String roleId
	 * @return:List<QueueCaseVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching list of Queues by Invoking
	 *               WebServices.
	 */

	@Override
	public List<QueueCaseVO> getQueueList(String roleId)
			throws RMDWebException, Exception {
		
		logger.debug("QueueCasesServiceImpl : Inside getQueueList() method:::::START");
		Map<String, String> queryParamsMap = new HashMap<String, String>();
		QueueCaseResponseType[] arrQueueCaseResponseType = null;
		List<QueueCaseVO> lstQueueCaseVO = null;
		try {
			queryParamsMap.put(AppConstants.ROLE_ID, roleId);
			arrQueueCaseResponseType = (QueueCaseResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_QUEUE_LIST, null, queryParamsMap,
							null, QueueCaseResponseType[].class);
			if (arrQueueCaseResponseType != null) {
				lstQueueCaseVO = new ArrayList<QueueCaseVO>();
				for (QueueCaseResponseType queueCaseRespType : arrQueueCaseResponseType) {
					QueueCaseVO queueCaseVO = new QueueCaseVO();

					queueCaseVO
							.setQueueObjId(queueCaseRespType.getQueueObjId());
					queueCaseVO
							.setQueueTitle(queueCaseRespType.getQueueTitle());
					lstQueueCaseVO.add(queueCaseVO);
				}
			}
		} catch (Exception ex) {
			logger.error("Exception occured in getQueueList method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		logger.debug("QueueCasesServiceImpl : Inside getQueueList() method:::::END");
		return lstQueueCaseVO;

	}

}
