package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.eoa.services.asset.service.valueobjects.TemplateInfoVO;
import com.ge.trans.rmd.cm.valueobjects.AddEditEDPDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.ConfigTemplateDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.EDPHeaderDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.EDPParamDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.EDPSearchParamVO;
import com.ge.trans.rmd.cm.valueobjects.EFIDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.FFDDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.FRDDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.FaultFilterDefDetails;
import com.ge.trans.rmd.cm.valueobjects.FaultRangeDefDetails;
import com.ge.trans.rmd.cm.valueobjects.TemplateReportBean;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface ConfigMaintenanceService {

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the all controller configs
	 */
	public Map<String, String> getControllerConfigs() throws RMDWebException;

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the all controller config
	 *               files
	 */
	public Map<String, String> getConfigFiles() throws RMDWebException;

	/**
	 * 
	 * @param ctrlCfgObjId
	 *            , cfgFile
	 * @return ConfigTemplateDetailsVO
	 * @throws RMDWebException
	 * @Description This method is used to get the Templates for the selected
	 *              Controller Config and Config File.
	 * 
	 */
	public List<ConfigTemplateDetailsVO> getCtrlCfgTemplates(
			String ctrlCfgObjId, String cfgFileName) throws RMDWebException;

	/**
	 * @Author:
	 * @param:
	 * @return:List<EFIDetailsVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the existing EFI templates
	 */
	public List<EFIDetailsVO> getEFIDetails() throws RMDWebException;

	/**
	 * @Author:
	 * @param:userName
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for creating new EFI templates
	 */
	public String createNewEFI(String userName) throws RMDWebException;

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the status for EDP
	 *               templates
	 */
	public Map<String, String> getCtrlCfgStatus() throws RMDWebException;

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the SearchBy dropdown
	 *               values for EDP template
	 */
	public Map<String, String> getEDPSearchByOptions() throws RMDWebException;

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Condition dropdown
	 *               values for EDP template
	 */
	public Map<String, String> getEDPConditionOptions() throws RMDWebException;

	/**
	 * @Author:
	 * @param:ctrlCfgObjId, cfgFileName
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the latest template Number
	 */
	public String getMaxTemplateNumber(String ctrlCfgObjId, String cfgFileName)
			throws RMDWebException;

	/**
	 * @Author:
	 * @param:ctrlCfgObjId, cfgFileName,templateNo
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the latest version number
	 *               of the opened template
	 */
	public String getTempMaxVerNumber(String ctrlCfgObjId, String cfgFileName,
			String templateNo) throws RMDWebException;

	/**
	 * @Author:
	 * @param EDPSearchParamVO
	 * @return List<EDPParamDetailsVO>
	 * @throws RMDWebException
	 * @Description This method is used to get the parameters that can be added
	 *              for EDP templates.
	 * 
	 */
	public List<EDPParamDetailsVO> getEDPParameters(
			EDPSearchParamVO objEDPSearchParamVO) throws RMDWebException;

	/**
	 * @Author:
	 * @param:tempObjId
	 * @return:List< EDPParamDetailsVO >
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the opened template added
	 *               parameters
	 */
	public List<EDPParamDetailsVO> getAddedEDPParams(String tempObjId)
			throws RMDWebException;

	/**
	 * @Author:
	 * @param:
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for creating or updating EDP templates
	 */
	public String saveEDPTemplate(AddEditEDPDetailsVO objAddEditEDPDetailsVO)
			throws RMDWebException;

	/**
	 * @Author:
	 * @param:String cfgFileName, String templateNo, String versionNo,String
	 *               ctrlCfgObjId
	 * @return:EDPHeaderDetailsVO
	 * @throws:RMDWebException
	 * @Description: This method is used for getting the Next/Previous EDP
	 *               template templates
	 */
	public EDPHeaderDetailsVO getPreNextEDPDetails(String cfgFileName,
			String templateNo, String versionNo, String ctrlCfgObjId)
			throws RMDWebException;

	/**
	 * @Author:
	 * @param:String configId
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetch parameter title list
	 * 
	 */
	public Map<String, String> getParameterTitle(String configId)
			throws RMDWebException;

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching operator values from
	 *               Lookup table
	 */
	public Map<String, String> getOperatorList() throws RMDWebException;

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching conjunction values from
	 *               Lookup table
	 */
	public Map<String, String> getConjunctionList() throws RMDWebException;

	/**
	 * @Author:
	 * @param:String configId,String templateId,String versionId
	 * @return:List<FaultFilterDefDetails>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching FFD Template list from
	 *               database
	 */
	public List<FaultFilterDefDetails> populateFFDDetails(String configId,
			String templateId, String versionId) throws RMDWebException;

	/**
	 * @Author:
	 * @param:
	 * @return:List<FaultRangeDefDetails>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching FRD Template list from
	 *               database
	 */
	public List<FaultRangeDefDetails> populateFRDDetails(
			List<FFDDetailsVO> ffdDetailsVO) throws RMDWebException;

	/**
	 * @Author:
	 * @param:List<FaultFilterDefDetails>
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for save FFD Template details in
	 *               database
	 */
	public String saveFFDTemplate(
			List<FaultFilterDefDetails> lstFaultFilterDefDetails)
			throws RMDWebException;

	/**
	 * @Author:
	 * @param:List<FaultRangeDefDetails>
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for save FRD Template details in
	 *               database
	 */
	public String saveFRDTemplate(
			List<FaultRangeDefDetails> lstFaultRangeDefDetails)
			throws RMDWebException;

	/**
	 * @Author:
	 * @param:List<FFDDetailsVO>
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for remove FRD Template details in
	 *               database
	 */
	public String removeFRDTemplate(List<FFDDetailsVO> ffdDetailsVO)
			throws RMDWebException;

	/**
	 * @Author:
	 * @param:List<FFDDetailsVO>
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for remove FFD Template details in
	 *               database
	 */
	public String removeFFDTemplate(List<FFDDetailsVO> ffdDetailsVO)
			throws RMDWebException;

	/**
	 * @Author:
	 * @param:String configId
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching EDP template value
	 */
	public Map<String, String> getEDPTemplate(String configId)
			throws RMDWebException;

	/**
	 * @Author:
	 * @param:String configId,String configValue
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching fault source list.
	 */
	public Map<String, String> getFaultSource(String configId,
			String configValue) throws RMDWebException;

	/**
	 * @Author:
	 * @param:
	 * @return:List<FRDDetailsVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching default values from
	 *               database.
	 */
	public List<FRDDetailsVO> getDefaultValuesRange() throws RMDWebException;

	/**
	 * @Author:
	 * @param:String configId,String templateId,String configFile
	 * @return:Integer
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching maximum version value
	 */
	public int getMaximumVersion(String configId, String templateId,
			String configFile) throws RMDWebException;

	/**
	 * @Author:
	 * @param:String configId,String configFile
	 * @return:Integer
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching current template value.
	 */
	public int getCurrentTemplate(String configId, String configFile)
			throws RMDWebException;

	/**
	 * @Author:
	 * @param:String configId,String templateId,String versionId
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching status values
	 */
	public String getCurrentStatus(String configId, String templateId,
			String versionId) throws RMDWebException;

	/**
	 * @Author:
	 * @param:String configId,String templateId,String versionId
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching title values
	 */
	public String getTitle(String configId, String templateId, String versionId)
			throws RMDWebException;

	/**
	 * @Author:
	 * @param:String configId,String templateId,String versionId
	 * @return:List<FFDDetailsVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching status details
	 */
	public List<FFDDetailsVO> getStatusDetails(String configId,
			String templateId, String versionId) throws RMDWebException;

	/**
	 * @Author:
	 * @param:List<FaultRangeDefDetails>
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for check fault range details
	 */
	public String checkFaultRange(
			List<FaultRangeDefDetails> lstFaultRangeDetails)
			throws RMDWebException;

	/**
	 * @Author:
	 * @param:
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching maximum number of
	 *               parameter allowed details.
	 */
	public String getMaxParameterCount() throws RMDWebException;
	
	/**
	 * 
	 * @param ctrlCfgObjId
	 *            , cfgFile
	 * @return ConfigTemplateDetailsVO
	 * @throws RMDWebException
	 * @Description This method is used to get the Templates for the selected
	 *              Controller Config and Config File.
	 * 
	 */
	public List<ConfigTemplateDetailsVO> getTemplateReport(TemplateReportBean templateReportBean) throws RMDWebException;

	/**
     * @Author :
     * @return :String
     * @param : String tempObjId,String templateNo,String versionNo,String cmAliasName,String status
     * @throws :RMDWebException
     * @Description: This method is Responsible for updating the RCI template
     * 
     */
    public String updateRCITemplate(String tempObjId,String templateNo,String versionNo,String cmAliasName,String status) throws RMDWebException;

	/**
     * @Author:
     * @param:
     * @return:String
     * @throws:RMDServiceException
     * @Description: This method is save new RCI Template
     */    
    public String saveRCITemplate(final TemplateReportBean templateInfo) throws RMDWebException;
}
