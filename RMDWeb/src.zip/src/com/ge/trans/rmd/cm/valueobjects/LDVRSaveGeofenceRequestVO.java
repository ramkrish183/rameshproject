package com.ge.trans.rmd.cm.valueobjects;

import org.codehaus.jackson.annotate.JsonProperty;

public class LDVRSaveGeofenceRequestVO {

    @JsonProperty("geozoneObjid")
    private String geozoneObjId;
    
    @JsonProperty("geozoneId")
    private String geozoneId;
    
    @JsonProperty("assetOwnerId")
	private String assetOwnerId;
    
    @JsonProperty("geozoneName")
	private String geozoneName;
    
    @JsonProperty("lattitude1")
	private double lattitude1;
    
    @JsonProperty("longitude1")
	private double longitude1;
    
    @JsonProperty("lattitude3")
	private double lattitude3;
    
    @JsonProperty("longitude")
	private double longitude3;
    
    @JsonProperty("userName")
	private String userName;
    
    @JsonProperty("active")
	private String active;
	  

	public String getGeozoneObjId() {
		return geozoneObjId;
	}



	public void setGeozoneObjId(String geozoneObjId) {
		this.geozoneObjId = geozoneObjId;
	}



	public String getGeozoneId() {
		return geozoneId;
	}



	public void setGeozoneId(String geozoneId) {
		this.geozoneId = geozoneId;
	}



	public String getAssetOwnerId() {
		return assetOwnerId;
	}



	public void setAssetOwnerId(String assetOwnerId) {
		this.assetOwnerId = assetOwnerId;
	}



	public String getGeozoneName() {
		return geozoneName;
	}



	public void setGeozoneName(String geozoneName) {
		this.geozoneName = geozoneName;
	}



	public double getLattitude1() {
		return lattitude1;
	}



	public void setLattitude1(double lattitude1) {
		this.lattitude1 = lattitude1;
	}



	public double getLongitude1() {
		return longitude1;
	}



	public void setLongitude1(double longitude1) {
		this.longitude1 = longitude1;
	}



	public double getLattitude3() {
		return lattitude3;
	}



	public void setLattitude3(double lattitude3) {
		this.lattitude3 = lattitude3;
	}



	public double getLongitude3() {
		return longitude3;
	}



	public void setLongitude3(double longitude3) {
		this.longitude3 = longitude3;
	}



	public String getUserName() {
		return userName;
	}



	public void setUserName(String userName) {
		this.userName = userName;
	}



	public String getActive() {
		return active;
	}



	public void setActive(String active) {
		this.active = active;
	}



	@Override
	public String toString() {
		return "[geozoneObjId: "+geozoneObjId+ ", geozoneId: "+geozoneId+", geozoneName: "+geozoneName+
				", assetOwnerId: "+assetOwnerId+", lattitude1: "+lattitude1+",longitude1: "+longitude1+", lattitude3 "+
				", longitude3: "+lattitude3+", userName: "+userName+", activeFlag: "+active+"]" ;
	}
}
