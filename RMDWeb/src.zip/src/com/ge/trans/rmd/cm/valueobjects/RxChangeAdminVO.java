package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

public class RxChangeAdminVO{
    
	private static final long serialVersionUID = 4986269726343465474L;
	private String objId;
	private String rxChangeRequestId;
	private long reViewerUserSeqId;
	private String newRxCreated;
	private String anyChangeinMaterial;
	private String triggerLogicChange;
	private String unfamiliarSystemChange;
	private String rxsImpacted;
	private String noOfRxAttachment;
	private String modelsImpacted;
	private String customers;
	private String summaryOfChanges;
	private String acceptanceFlag;
	private String internalNotes;
	private String reviewerNotes;
	private String targetImplementationDate;
	private String rxChangeReasons;
	private String userId;
	private String actionType;
	private String saveAsDraft;
	private List<RxChangeAdminTitleVO> rxList;
	private String draftmodelImpacted;
	private String draftcustomerImpacted;
	private String draftrxsImpacted;
	private String additionalReviewer;
	private List<RxChangeVO> rxchangeAuditInfoLst;
	
	/**
	 * @return the objId
	 */
	public String getObjId() {
		return objId;
	}
	/**
	 * @param objId the objId to set
	 */
	public void setObjId(String objId) {
		this.objId = objId;
	}
	/**
	 * @return the rxChangeRequestId
	 */
	public String getRxChangeRequestId() {
		return rxChangeRequestId;
	}
	/**
	 * @param rxChangeRequestId the rxChangeRequestId to set
	 */
	public void setRxChangeRequestId(String rxChangeRequestId) {
		this.rxChangeRequestId = rxChangeRequestId;
	}
	
	
	public long getReViewerUserSeqId() {
        return reViewerUserSeqId;
    }
    public void setReViewerUserSeqId(long reViewerUserSeqId) {
        this.reViewerUserSeqId = reViewerUserSeqId;
    }
    /**
	 * @return the newRxCreated
	 */
	public String getNewRxCreated() {
		return newRxCreated;
	}
	/**
	 * @param newRxCreated the newRxCreated to set
	 */
	public void setNewRxCreated(String newRxCreated) {
		this.newRxCreated = newRxCreated;
	}
	/**
	 * @return the anyChangeinMaterial
	 */
	public String getAnyChangeinMaterial() {
		return anyChangeinMaterial;
	}
	/**
	 * @param anyChangeinMaterial the anyChangeinMaterial to set
	 */
	public void setAnyChangeinMaterial(String anyChangeinMaterial) {
		this.anyChangeinMaterial = anyChangeinMaterial;
	}
	/**
	 * @return the triggerLogicChange
	 */
	public String getTriggerLogicChange() {
		return triggerLogicChange;
	}
	/**
	 * @param triggerLogicChange the triggerLogicChange to set
	 */
	public void setTriggerLogicChange(String triggerLogicChange) {
		this.triggerLogicChange = triggerLogicChange;
	}
	/**
	 * @return the unfamiliarSystemChange
	 */
	public String getUnfamiliarSystemChange() {
		return unfamiliarSystemChange;
	}
	/**
	 * @param unfamiliarSystemChange the unfamiliarSystemChange to set
	 */
	public void setUnfamiliarSystemChange(String unfamiliarSystemChange) {
		this.unfamiliarSystemChange = unfamiliarSystemChange;
	}
	
	
	/**
	 * @return the noOfRxAttachment
	 */
	public String getNoOfRxAttachment() {
		return noOfRxAttachment;
	}
	/**
	 * @param noOfRxAttachment the noOfRxAttachment to set
	 */
	public void setNoOfRxAttachment(String noOfRxAttachment) {
		this.noOfRxAttachment = noOfRxAttachment;
	}	
	
	/**
	 * @return the summaryOfChanges
	 */
	public String getSummaryOfChanges() {
		return summaryOfChanges;
	}
	/**
	 * @param summaryOfChanges the summaryOfChanges to set
	 */
	public void setSummaryOfChanges(String summaryOfChanges) {
		this.summaryOfChanges = summaryOfChanges;
	}
	/**
	 * @return the acceptanceFlag
	 */
	public String getAcceptanceFlag() {
		return acceptanceFlag;
	}
	/**
	 * @param acceptanceFlag the acceptanceFlag to set
	 */
	public void setAcceptanceFlag(String acceptanceFlag) {
		this.acceptanceFlag = acceptanceFlag;
	}
	/**
	 * @return the internalNotes
	 */
	public String getInternalNotes() {
		return internalNotes;
	}
	/**
	 * @param internalNotes the internalNotes to set
	 */
	public void setInternalNotes(String internalNotes) {
		this.internalNotes = internalNotes;
	}
	/**
	 * @return the reviewerNotes
	 */
	public String getReviewerNotes() {
		return reviewerNotes;
	}
	/**
	 * @param reviewerNotes the reviewerNotes to set
	 */
	public void setReviewerNotes(String reviewerNotes) {
		this.reviewerNotes = reviewerNotes;
	}
	/**
	 * @return the targetImplementationDate
	 */
	public String getTargetImplementationDate() {
		return targetImplementationDate;
	}
	/**
	 * @param targetImplementationDate the targetImplementationDate to set
	 */
	public void setTargetImplementationDate(String targetImplementationDate) {
		this.targetImplementationDate = targetImplementationDate;
	}
	/**
	 * @return the rxChangeReasons
	 */
	public String getRxChangeReasons() {
		return rxChangeReasons;
	}
	/**
	 * @param rxChangeReasons the rxChangeReasons to set
	 */
	public void setRxChangeReasons(String rxChangeReasons) {
		this.rxChangeReasons = rxChangeReasons;
	}
	/**
	 * @return the userId
	 */
	public String getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(String userId) {
		this.userId = userId;
	}
	/**
	 * @return the rxsImpacted
	 */
	public String getRxsImpacted() {
		return rxsImpacted;
	}
	/**
	 * @param rxsImpacted the rxsImpacted to set
	 */
	public void setRxsImpacted(String rxsImpacted) {
		this.rxsImpacted = rxsImpacted;
	}
	/**
	 * @return the modelsImpacted
	 */
	public String getModelsImpacted() {
		return modelsImpacted;
	}
	/**
	 * @param modelsImpacted the modelsImpacted to set
	 */
	public void setModelsImpacted(String modelsImpacted) {
		this.modelsImpacted = modelsImpacted;
	}
	/**
	 * @return the customers
	 */
	public String getCustomers() {
		return customers;
	}
	/**
	 * @param customers the customers to set
	 */
	public void setCustomers(String customers) {
		this.customers = customers;	
	}
	/**
	 * @return the saveAsDraft
	 */
	public String getSaveAsDraft() {
		return saveAsDraft;
	}
	/**
	 * @param saveAsDraft the saveAsDraft to set
	 */
	public void setSaveAsDraft(String saveAsDraft) {
		this.saveAsDraft = saveAsDraft;
	}
	/**
	 * @return the actionType
	 */
	public String getActionType() {
		return actionType;
	}
	/**
	 * @param actionType the actionType to set
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	/**
	 * @return the rxList
	 */
	public List<RxChangeAdminTitleVO> getRxList() {
		return rxList;
	}
	/**
	 * @param rxList the rxList to set
	 */
	public void setRxList(List<RxChangeAdminTitleVO> rxList) {
		this.rxList = rxList;
	}
	
    /**
	 * @return the draftmodelImpacted
	 */
	public String getDraftmodelImpacted() {
		return draftmodelImpacted;
	}
	/**
	 * @param draftmodelImpacted the draftmodelImpacted to set
	 */
	public void setDraftmodelImpacted(String draftmodelImpacted) {
		this.draftmodelImpacted = draftmodelImpacted;
	}
	/**
	 * @return the draftcustomerImpacted
	 */
	public String getDraftcustomerImpacted() {
		return draftcustomerImpacted;
	}
	/**
	 * @param draftcustomerImpacted the draftcustomerImpacted to set
	 */
	public void setDraftcustomerImpacted(String draftcustomerImpacted) {
		this.draftcustomerImpacted = draftcustomerImpacted;
	}
	/**
	 * @return the draftrxsImpacted
	 */
	public String getDraftrxsImpacted() {
		return draftrxsImpacted;
	}
	/**
	 * @param draftrxsImpacted the draftrxsImpacted to set
	 */
	public void setDraftrxsImpacted(String draftrxsImpacted) {
		this.draftrxsImpacted = draftrxsImpacted;
	}
	
	/**
	 * @return the additionalReviewer
	 */
	public String getAdditionalReviewer() {
		return additionalReviewer;
	}
	/**
	 * @param additionalReviewer the additionalReviewer to set
	 */
	public void setAdditionalReviewer(String additionalReviewer) {
		this.additionalReviewer = additionalReviewer;
	}
	
	public List<RxChangeVO> getRxchangeAuditInfoLst() {
        return rxchangeAuditInfoLst;
    }
    public void setRxchangeAuditInfoLst(List<RxChangeVO> rxchangeAuditInfoLst) {
        this.rxchangeAuditInfoLst = rxchangeAuditInfoLst;
    }
    @Override
    public String toString() {
        return "RxChangeAdminVO [objId=" + objId + ", rxChangeRequestId=" + rxChangeRequestId + ", reViewerUserSeqId="
                + reViewerUserSeqId + ", newRxCreated=" + newRxCreated + ", anyChangeinMaterial=" + anyChangeinMaterial
                + ", triggerLogicChange=" + triggerLogicChange + ", unfamiliarSystemChange=" + unfamiliarSystemChange
                + ", rxsImpacted=" + rxsImpacted + ", noOfRxAttachment=" + noOfRxAttachment + ", modelsImpacted="
                + modelsImpacted + ", customers=" + customers + ", summaryOfChanges=" + summaryOfChanges
                + ", acceptanceFlag=" + acceptanceFlag + ", internalNotes=" + internalNotes + ", reviewerNotes="
                + reviewerNotes + ", targetImplementationDate=" + targetImplementationDate + ", rxChangeReasons="
                + rxChangeReasons + ", userId=" + userId + ", actionType=" + actionType + ", saveAsDraft="
                + saveAsDraft + ", rxList=" + rxList + "]";
    }
}
