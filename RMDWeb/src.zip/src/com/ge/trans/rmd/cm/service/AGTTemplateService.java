package com.ge.trans.rmd.cm.service;

import java.util.List;

import com.ge.trans.rmd.cm.valueobjects.ConfigSearchVO;
import com.ge.trans.rmd.cm.valueobjects.MassApplyCfgVO;
import com.ge.trans.rmd.cm.valueobjects.VerifyCfgTemplateVO;
import com.ge.trans.rmd.services.assets.valueobjects.ApplyCfgTemplateRequestType;

public interface AGTTemplateService {

   public List<MassApplyCfgVO> getAGTTemplates(ConfigSearchVO objConfigSearchVO);
   public VerifyCfgTemplateVO getSelectedAGTTemplate(String tempNoVer,String timeZone);
   public String applyAGTTemplate(ApplyCfgTemplateRequestType objApplyCfgTemplateRequestType);
   
}
