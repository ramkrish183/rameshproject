package com.ge.trans.rmd.cm.mvc.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ge.trans.rmd.cm.service.AssetDataScreenService;
import com.ge.trans.rmd.cm.service.HeatMapService;
import com.ge.trans.rmd.cm.valueobjects.HeatMapResponseVO;
import com.ge.trans.rmd.cm.valueobjects.HeatMapSearchVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
/*
 * Controller class for Heat Map feature which handles all the operations in it.
 */
public class HeatMapController extends RMDBaseController {

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private HeatMapService heatMapService;

	@Autowired
	private AuthorizationService authorizationService;

	@Autowired
	private AssetDataScreenService objAssetDataScreenService;

	@RequestMapping(value = AppConstants.REQ_URI_HEATMAP, method = RequestMethod.GET)
	public String getHeatMapPage(final HttpServletRequest request)
			throws Exception {
		String fromDate = null;
		String toDate = null;
		List<String> noOfDaysList = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final SimpleDateFormat dateFormat = new SimpleDateFormat(
				AppConstants.TO_DATE_FORMAT);

		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);

		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());

		dateFormat.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
		Calendar fromDtCal = Calendar.getInstance();
		fromDtCal.add(Calendar.DATE, -Integer.parseInt(AppConstants.INDEX_2));
		fromDate = dateFormat.format(fromDtCal.getTime());
		toDate = dateFormat.format(new Date());
		noOfDaysList = objAssetDataScreenService
				.getNoOfDaysDropdownValues(AppConstants.VEHICLE_FAULT_DROPDOWN_DAYS);
		request.setAttribute(AppConstants.DATA_SCREEN_NO_OF_DAYS_DROPDOWN,
				noOfDaysList);

		request.setAttribute(AppConstants.FROM_DATE, fromDate);
		request.setAttribute(AppConstants.TO_DATE, toDate);

		return AppConstants.VIEW_HEATMAP;
	}

	@RequestMapping(value = AppConstants.REQ_URI_HEATMAP_MODEL, method = RequestMethod.POST)
	public @ResponseBody HeatMapResponseVO getHeatMapModels(
			final HttpServletRequest request) throws RMDWebException {
		HeatMapResponseVO heatMapRespVO = null;
		HeatMapSearchVO heatMapSearchVO = null;
		try {
			final String customerId = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_CUSID));

			heatMapSearchVO = new HeatMapSearchVO();
			heatMapSearchVO.setCustomerId(customerId);
			heatMapRespVO = heatMapService.getHeatMapModels(heatMapSearchVO);

		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"RMDWebException occured in getHeatMapModels Method ", e);
			RMDWebErrorHandler.handleException(e);

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getHeatMapModels Method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return heatMapRespVO;
	}

	@RequestMapping(value = AppConstants.REQ_URI_HEATMAP_ASSETSHEADERS, method = RequestMethod.POST)
	public @ResponseBody HeatMapResponseVO getHeatMapAssetHeaders(
			final HttpServletRequest request) throws RMDWebException {
		HeatMapResponseVO heatMapRespVO = null;
		HeatMapSearchVO heatMapSearchVO = null;
		try {			
			final String customerId = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_CUSID));
			final String model = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.MODEL));
			final String roadNumber = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.ROAD_NUMBER));

			heatMapSearchVO = new HeatMapSearchVO();
			heatMapSearchVO.setCustomerId(customerId);
			if (!RMDCommonUtility.isNullOrEmpty(model)) {
				List<String> modelLst = new ArrayList<String>(
						Arrays.asList(model.split(AppConstants.COMMA)));
				heatMapSearchVO.setModelLst(modelLst);
			}
			if (!RMDCommonUtility.isNullOrEmpty(roadNumber)) {
				List<String> assetNumberLst = new ArrayList<String>(
						Arrays.asList(roadNumber.split(AppConstants.COMMA)));
				heatMapSearchVO.setAssetNumberLst(assetNumberLst);
			}
			heatMapRespVO = heatMapService
					.getHeatMapAssetHeaders(heatMapSearchVO);

		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"RMDWebException occured in getHeatMapAssetHeaders Method",
					e);
			RMDWebErrorHandler.handleException(e);

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getHeatMapAssetHeaders Method", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return heatMapRespVO;
	}

	@RequestMapping(value = AppConstants.REQ_URI_HEATMAP_ASSETSNUMBERS, method = RequestMethod.POST)
	public @ResponseBody HeatMapResponseVO getHeatMapAssetNumbers(
			final HttpServletRequest request) throws RMDWebException {

		HeatMapResponseVO heatMapRespVO = null;
		HeatMapSearchVO heatMapSearchVO = null;
		try {
			final String customerId = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_CUSID));
			final String model = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.MODEL));
			final String assetHeader = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.RNH));

			heatMapSearchVO = new HeatMapSearchVO();
			heatMapSearchVO.setCustomerId(customerId);
			if (!RMDCommonUtility.isNullOrEmpty(model)) {
				List<String> modelLst = new ArrayList<String>(
						Arrays.asList(model.split(AppConstants.COMMA)));
				heatMapSearchVO.setModelLst(modelLst);
			}
			if (!RMDCommonUtility.isNullOrEmpty(assetHeader)) {
				List<String> roadHeaderLst = new ArrayList<String>(
						Arrays.asList(assetHeader.split(AppConstants.COMMA)));
				heatMapSearchVO.setAssetNumberLst(roadHeaderLst);
			}
			heatMapRespVO = heatMapService
					.getHeatMapAssetNumbers(heatMapSearchVO);

		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"RMDWebException occured in getHeatMapAssetNumbers Method",
					e);
			RMDWebErrorHandler.handleException(e);

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getHeatMapAssetNumbers Method", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return heatMapRespVO;
	}

	@RequestMapping(value = AppConstants.REQ_URI_HEATMAP_FAULTS, method = RequestMethod.POST)
	public @ResponseBody HeatMapResponseVO getHeatMapFaults(
			final HttpServletRequest request) throws RMDWebException {
		HeatMapResponseVO heatMapRespVO = null;
		HeatMapSearchVO heatMapSearchVO = null;
		try {
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			final String customerId = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_CUSID));
			final String model = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.MODEL));
			final String roadNumHeader = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.RNH));
			final String roadNumber = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.ROAD_NUMBER));

			final String fromDate = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.FROM_DATE));

			final String toDate = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.TO_DATE));

			final String noOfDays = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.NO_OF_DAYS));

			final String defaultTimezone = (String) request
					.getAttribute(AppConstants.DEFAULT_TIMEZONE);

			String applicationTimezone = RMDCommonUtil.getTimezone(
					defaultTimezone, userVO.getTimeZone());

			heatMapSearchVO = new HeatMapSearchVO();
			heatMapSearchVO.setCustomerId(customerId);
			if (!RMDCommonUtility.isNullOrEmpty(model)) {
				List<String> modelLst = new ArrayList<String>(
						Arrays.asList(model.split(AppConstants.COMMA)));
				heatMapSearchVO.setModelLst(modelLst);
			}
			if (!RMDCommonUtility.isNullOrEmpty(roadNumHeader)) {
				List<String> assetHeaderLst = new ArrayList<String>(
						Arrays.asList(roadNumHeader.split(AppConstants.COMMA)));
				heatMapSearchVO.setAssetHeaderLst(assetHeaderLst);
			}
			if (!RMDCommonUtility.isNullOrEmpty(roadNumber)) {
				List<String> assetNumberLst = new ArrayList<String>(
						Arrays.asList(roadNumber.split(AppConstants.COMMA)));
				heatMapSearchVO.setAssetNumberLst(assetNumberLst);
			}
			if (!RMDCommonUtility.isNullOrEmpty(noOfDays)) {
				heatMapSearchVO.setNoOfDays(noOfDays);
			} else {
				heatMapSearchVO.setFromDate(RMDCommonUtility
						.convertDateFormatAndTimezone(fromDate,
								AppConstants.TO_DATE_FORMAT,
								AppConstants.HEATMAP_DB_DATE_FORMAT,
								applicationTimezone,
								AppConstants.TIMEZONE_EASTERN));
				heatMapSearchVO.setToDate(RMDCommonUtility
						.convertDateFormatAndTimezone(toDate,
								AppConstants.TO_DATE_FORMAT,
								AppConstants.HEATMAP_DB_DATE_FORMAT,
								applicationTimezone,
								AppConstants.TIMEZONE_EASTERN));
			}
			String hideNotesRoleId = authorizationService
					.getLookUpValueForName(AppConstants.HIDE_ASSETOVERVIEW_NOTES_CREATED_BY_ROLE_ID);
			List<String> roleIdList = Arrays.asList(hideNotesRoleId
					.split(RMDCommonConstants.COMMMA_SEPARATOR));
			if (roleIdList != null
					&& roleIdList.contains(userVO.getRoleId().toString()))//if the logged in user is DE
				heatMapSearchVO.setIsNonGPOCUser(RMDCommonConstants.NO);
			else
				heatMapSearchVO.setIsNonGPOCUser(RMDCommonConstants.YES);
			heatMapRespVO = heatMapService.getHeatMapFaults(heatMapSearchVO);

		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"RMDWebException occured in getHeatMapFaults Method", e);
			RMDWebErrorHandler.handleException(e);

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getHeatMapFaults Method",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return heatMapRespVO;
	}

	@RequestMapping(value = AppConstants.REQ_URI_HEATMAP_FILTER_RESULTS, method = RequestMethod.POST)
	public @ResponseBody HeatMapResponseVO getHeatMapFilterResults(
			final HttpServletRequest request) throws RMDWebException {
		HeatMapResponseVO heatMapRespVO = null;
		HeatMapSearchVO heatMapSearchVO = null;
		rmdWebLogger
				.info("Inside HeatMapController in getHeatMapFaults Method");
		try {			
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			final String customerId = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_CUSID));
			final String model = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.MODEL));
			final String roadNumHeader = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.RNH));
			final String roadNumber = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.ROAD_NUMBER));

			final String fromDate = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.FROM_DATE));

			final String toDate = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.TO_DATE));

			final String noOfDays = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.NO_OF_DAYS));

			final String faultCode = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.FAULT_CODE));

			final String defaultTimezone = (String) request
					.getAttribute(AppConstants.DEFAULT_TIMEZONE);

			String applicationTimezone = RMDCommonUtil.getTimezone(
					defaultTimezone, userVO.getTimeZone());			

			heatMapSearchVO = new HeatMapSearchVO();
			heatMapSearchVO.setCustomerId(customerId);
			if (!RMDCommonUtility.isNullOrEmpty(model)) {
				List<String> modelLst = new ArrayList<String>(
						Arrays.asList(model.split(AppConstants.COMMA)));
				heatMapSearchVO.setModelLst(modelLst);
			}
			if (!RMDCommonUtility.isNullOrEmpty(roadNumHeader)) {
				List<String> assetHeaderLst = new ArrayList<String>(
						Arrays.asList(roadNumHeader.split(AppConstants.COMMA)));
				heatMapSearchVO.setAssetHeaderLst(assetHeaderLst);
			}
			if (!RMDCommonUtility.isNullOrEmpty(roadNumber)) {
				List<String> assetNumberLst = new ArrayList<String>(
						Arrays.asList(roadNumber.split(AppConstants.COMMA)));
				heatMapSearchVO.setAssetNumberLst(assetNumberLst);
			}
			if (!RMDCommonUtility.isNullOrEmpty(faultCode)) {
				List<String> faultCodeLst = new ArrayList<String>(
						Arrays.asList(faultCode.split(AppConstants.COMMA)));
				heatMapSearchVO.setFaultCodeLst(faultCodeLst);
			}
			if (!RMDCommonUtility.isNullOrEmpty(noOfDays)) {
				heatMapSearchVO.setNoOfDays(noOfDays);
			} else {
				heatMapSearchVO.setFromDate(RMDCommonUtility
						.convertDateFormatAndTimezone(fromDate,
								AppConstants.TO_DATE_FORMAT,
								AppConstants.HEATMAP_DB_DATE_FORMAT,
								AppConstants.TIMEZONE_EASTERN,
								applicationTimezone));
				heatMapSearchVO.setToDate(RMDCommonUtility
						.convertDateFormatAndTimezone(toDate,
								AppConstants.TO_DATE_FORMAT,
								AppConstants.HEATMAP_DB_DATE_FORMAT,
								AppConstants.TIMEZONE_EASTERN,
								applicationTimezone));
			}	
			
			heatMapRespVO = heatMapService.getHeatMapFilterResults(
					heatMapSearchVO, applicationTimezone);

		} catch (RMDWebException e) {
			rmdWebLogger.error(
					"RMDWebException occured in getHeatMapFaults Method", e);
			RMDWebErrorHandler.handleException(e);

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getHeatMapFaults Method",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return heatMapRespVO;
	}
}
