package com.ge.trans.rmd.cm.service;

import java.util.Map;

import com.ge.trans.rmd.cm.beans.MapBean;
import com.ge.trans.rmd.cm.valueobjects.MapServiceVO;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface MapService {

	public Map<String, MapServiceVO> getMapPage(MapBean mapBean, String userCustomer)
			throws RMDWebException, Exception;
	public String getLastRefreshTime(String listName,String applicationTimezone, String userCustomer)
			throws RMDWebException, Exception;

}


