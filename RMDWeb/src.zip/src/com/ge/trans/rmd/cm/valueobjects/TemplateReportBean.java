/**
 * ============================================================
 * Classification: GE Confidential
 * File : TemplateReportBean.java
 * Description :
 *
 * Package :com.ge.trans.rmd.cm.valueobjects;
 * Author : Capgemini
 * Last Edited By :
 * Version : 1.0
 * Created on :
 * History
 * Modified By : Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.valueobjects;

/**
 * @author 502166888
 *
 */
public class TemplateReportBean extends AssetsVO {
	private String templateNumber;
	private String configFile ;
	private String templateVersion;
	private String templateStatus;
	private String offboardStatus;
	private String onboardStatus;
	private String onboardStatusDate;
	private String offboardStatusDate;
	private String templateTitle;
	private String controllerConfigId;
	private String templateFileContent;
	private String faultCode;
	private String fileName;
	private String userName;
	
	

	
	/**
	 * @return the templateStatus
	 */
	public final String getTemplateStatus() {
		return templateStatus;
	}
	/**
	 * @param templateStatus the templateStatus to set
	 */
	public final void setTemplateStatus(String templateStatus) {
		this.templateStatus = templateStatus;
	}
	/**
	 * @return the offboardStatus
	 */
	public final String getOffboardStatus() {
		return offboardStatus;
	}
	/**
	 * @param offboardStatus the offboardStatus to set
	 */
	public final void setOffboardStatus(String offboardStatus) {
		this.offboardStatus = offboardStatus;
	}
	/**
	 * @return the onboardStatus
	 */
	public final String getOnboardStatus() {
		return onboardStatus;
	}
	/**
	 * @param onboardStatus the onboardStatus to set
	 */
	public final void setOnboardStatus(String onboardStatus) {
		this.onboardStatus = onboardStatus;
	}
	/**
	 * @return the onboardStatusDate
	 */
	public final String getOnboardStatusDate() {
		return onboardStatusDate;
	}
	/**
	 * @param onboardStatusDate the onboardStatusDate to set
	 */
	public final void setOnboardStatusDate(String onboardStatusDate) {
		this.onboardStatusDate = onboardStatusDate;
	}
	/**
	 * @return the templateNumber
	 */
	public final String getTemplateNumber() {
		return templateNumber;
	}
	/**
	 * @param templateNumber the templateNumber to set
	 */
	public final void setTemplateNumber(String templateNumber) {
		this.templateNumber = templateNumber;
	}
	/**
	 * @return the configFile
	 */
	public final String getConfigFile() {
		return configFile;
	}
	/**
	 * @param configFile the configFile to set
	 */
	public final void setConfigFile(String configFile) {
		this.configFile = configFile;
	}
	/**
	 * @return the templateVersion
	 */
	public final String getTemplateVersion() {
		return templateVersion;
	}
	/**
	 * @param templateVersion the templateVersion to set
	 */
	public final void setTemplateVersion(String templateVersion) {
		this.templateVersion = templateVersion;
	}
	/**
	 * @return the templateTitle
	 */
	public final String getTemplateTitle() {
		return templateTitle;
	}
	/**
	 * @param templateTitle the templateTitle to set
	 */
	public final void setTemplateTitle(String templateTitle) {
		this.templateTitle = templateTitle;
	}
	/**
	 * @return the controllerConfigId
	 */
	public final String getControllerConfigId() {
		return controllerConfigId;
	}
	/**
	 * @param controllerConfigId the controllerConfigId to set
	 */
	public final void setControllerConfigId(String controllerConfigId) {
		this.controllerConfigId = controllerConfigId;
	}
	/**
	 * @return the offboardStatusDate
	 */
	public final String getOffboardStatusDate() {
		return offboardStatusDate;
	}
	/**
	 * @param offboardStatusDate the offboardStatusDate to set
	 */
	public final void setOffboardStatusDate(String offboardStatusDate) {
		this.offboardStatusDate = offboardStatusDate;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "TemplateReportBean [templateNumber=" + templateNumber
				+ ", configFile=" + configFile + ", templateVersion="
				+ templateVersion + ", templateStatus=" + templateStatus
				+ ", offboardStatus=" + offboardStatus + ", onboardStatus="
				+ onboardStatus + ", onboardStatusDate=" + onboardStatusDate
				+ ", offboardStatusDate=" + offboardStatusDate
				+ ", templateTitle=" + templateTitle + ", controllerConfigId="
				+ controllerConfigId + ", getAssetOwnerId()="
				+ getAssetOwnerId() + ", getRoadInitial()=" + getRoadInitial()
				+ ", getRoadNumberFrom()=" + getRoadNumberFrom()
				+ ", getRoadNumberTo()=" + getRoadNumberTo()
				+ ", getRoadHdrInitial()=" + getRoadHdrInitial()
				+ ", getRoadNumber()=" + getRoadNumber()
				+ ", getRoadNumberHdr()=" + getRoadNumberHdr()
				+ ", getCustomerId()=" + getCustomerId()
				+ ", getCustomerName()=" + getCustomerName() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}
	
	public String getTemplateFileContent() {
		return templateFileContent;
	}
	public void setTemplateFileContent(String templateFileContent) {
		this.templateFileContent = templateFileContent;
	}
    public String getFaultCode() {
        return faultCode;
    }
    public void setFaultCode(String faultCode) {
        this.faultCode = faultCode;
    }
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
	
	
	
	
}
