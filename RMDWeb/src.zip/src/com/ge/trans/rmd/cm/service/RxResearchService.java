package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.valueobjects.RxResearchVO;
import com.ge.trans.rmd.cm.valueobjects.RxRepairCodeDetailsVO;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface RxResearchService {
	
	public List<String> getSearchSolution(RxResearchVO rxResearchVO) throws RMDWebException;
	public List<RxResearchVO> getGraphicalData(RxResearchVO rxResearchVO) throws RMDWebException;
	public List<RxRepairCodeDetailsVO> populateRepairCodeDetails(RxResearchVO rxResearchVO) throws RMDWebException;

}
