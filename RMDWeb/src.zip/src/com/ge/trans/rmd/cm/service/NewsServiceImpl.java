package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.InsertNewsVO;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.vo.NewsAllVO;
import com.ge.trans.rmd.services.admin.valueobjects.NewsDeleteRequestType;
import com.ge.trans.rmd.services.admin.valueobjects.UpdateReadFlagRequestType;
import com.ge.trans.rmd.services.admin.valueobjects.UserDeleteRequestType;
import com.ge.trans.rmd.services.news.valueobjects.NewsAllResponseType;
import com.ge.trans.rmd.services.news.valueobjects.NewsInsertRequestType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.services.cases.valueobjects.RxDelvDocType;

@Service
public class NewsServiceImpl extends RMDBaseServiceImpl implements NewsService{

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
            .getLogger(getClass());
    @Autowired
    WebServiceInvoker webServiceInvoker;
    
    final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());
	@Override
	public String saveNews(InsertNewsVO insertNewsVO) throws RMDWebException {
		String response =null;
		RxDelvDocType objDocDetails = null;
		RxDelvDocType objImgDetails = null;
		try{
			
			NewsInsertRequestType newsInsertRequestType = new NewsInsertRequestType();
			newsInsertRequestType.setCustomerarray(insertNewsVO.getCustomerarray());
			newsInsertRequestType.setExpiryDate(insertNewsVO.getExpiryDate());
			newsInsertRequestType.setNewsDesc(insertNewsVO.getNewsDesc());
			newsInsertRequestType.setUserId(insertNewsVO.getUserId());
			newsInsertRequestType.setObjId(insertNewsVO.getObjId());
			newsInsertRequestType.setStatus(insertNewsVO.getStatus());
			newsInsertRequestType.setFileRemoved(insertNewsVO.getFileRemoved());
			if(null!=insertNewsVO.getDocDetails()){
			    objDocDetails = new RxDelvDocType();
			    objDocDetails.setDocTitle(insertNewsVO.getDocDetails().getDocTitle());
			    objDocDetails.setDocData(insertNewsVO.getDocDetails().getDocData());
			    objDocDetails.setDocPath(insertNewsVO.getDocDetails().getDocPath());
			    newsInsertRequestType.setObjDocDetails(objDocDetails);
			}
			if(null!=insertNewsVO.getImgDetails()){
			    objImgDetails = new RxDelvDocType();
			    objImgDetails.setDocTitle(insertNewsVO.getImgDetails().getDocTitle());
			    objImgDetails.setDocData(insertNewsVO.getImgDetails().getDocData());
			    objImgDetails.setDocPath(insertNewsVO.getImgDetails().getDocPath());
			    newsInsertRequestType.setObjImgDetails(objImgDetails);
            }
			response = (String) webServiceInvoker.post(ServiceConstants.GET_INSERT_NEWS_VALUES,
					newsInsertRequestType, String.class);
			
		}
		catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
                    "RMDWebException occured in saveNews() method ",
                    rmdEx);

            throw rmdEx;
        } 
		return response;
	}

	@Override
	public List<NewsAllVO> getAllNews(String userId,String isAdminPage,String customerId) throws RMDWebException {
		final List<NewsAllVO> allNewsVO = new ArrayList<NewsAllVO>();
		NewsAllResponseType[] newsAllResponseType = null;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		final Map<String, String> headerParams = new LinkedHashMap<String, String>();
		NewsAllVO newsVO = null;
		try{
			if(!RMDCommonUtility.isNullOrEmpty(userId)){
				queryParams.put(AppConstants.USER_ID, userId);
			}
			else
			{
				queryParams.put(AppConstants.USER_ID, AppConstants.EMPTYSTRING);
			}
			if(!RMDCommonUtility.isNullOrEmpty(isAdminPage)){
				queryParams.put(AppConstants.IS_ADMIN_PAGE, isAdminPage);
			}
			else
			{
				queryParams.put(AppConstants.IS_ADMIN_PAGE, AppConstants.NO_FLAG);
			}
			if(!RMDCommonUtility.isNullOrEmpty(customerId)){
				queryParams.put(AppConstants.CUSTOMER_ID, customerId);
			}
			else
			{
				queryParams.put(AppConstants.CUSTOMER_ID, AppConstants.EMPTY_STRING);
			}
			newsAllResponseType = (NewsAllResponseType[]) webServiceInvoker.get(
					ServiceConstants.GET_ALL_NEWS, null,
					queryParams, headerParams, NewsAllResponseType[].class);
			
			if (newsAllResponseType != null && newsAllResponseType.length > 0) {
				for (NewsAllResponseType objResponseType : newsAllResponseType) {
					newsVO = new NewsAllVO();
					if(RMDCommonUtility.isNull(objResponseType.getAttachmentPath())){
						newsVO.setAttachmentPath("N/A");
					}else{
					newsVO.setAttachmentPath(objResponseType.getAttachmentPath());
					}
					
					newsVO.setCreatedBy(objResponseType.getCreatedBy());
					newsVO.setCustomerId(objResponseType.getCustomerId());
					newsVO.setDescription(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(objResponseType.getDescription())));
					newsVO.setExpiryDate(objResponseType.getExpiryDate());
					newsVO.setCreationDate(objResponseType.getCreationDate());
					newsVO.setObjid(objResponseType.getObjid());
					newsVO.setStatus(objResponseType.getStatus());
					newsVO.setAttName(objResponseType.getAttName());
					newsVO.setReadNewsFlag(objResponseType.getReadNewsFlag());
					newsVO.setNewsObjId(objResponseType.getNewsObjId());
					newsVO.setLastUpdatedBy(objResponseType.getLastUpdatedBy());
					newsVO.setLastUpdatedDate(objResponseType.getLastUpdatedDate());
					allNewsVO.add(newsVO);
				}
			}
			
		} catch (Exception ex) {
			logger.error("Exception occured in getallNews method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return allNewsVO;
	}

	@Override
	public String deleteNews(String objId) throws RMDWebException {
		final NewsDeleteRequestType newsRequestType = new NewsDeleteRequestType();
		String responce = null;
		try{
			if(!RMDCommonUtility.isNullOrEmpty(objId)){
				newsRequestType.setObjId(objId);
				}
				else
				{
				newsRequestType.setObjId(AppConstants.EMPTYSTRING);
				}
		responce = (String) webServiceInvoker.post(ServiceConstants.DELETE_NEWS, newsRequestType, String.class);
		}catch (Exception e) {
			logger.error("Exception occured in getNoCMRoles method of UserManagementServiceImpl"
                    + e);
            RMDWebErrorHandler.handleException(e);
		}
		
		return responce;
	}

	@Override
	public String getBackgroundImage(String customerId) throws RMDWebException {
		String bgImage = null;
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		final Map<String, String> headerParams = new LinkedHashMap<String, String>();
		try{
			if(!RMDCommonUtility.isNullOrEmpty(customerId)){
				queryParams.put(AppConstants.CUSTOMER_ID, customerId);
			}
			else
			{
				queryParams.put(AppConstants.CUSTOMER_ID, AppConstants.EMPTYSTRING);
			}
			bgImage = (String) webServiceInvoker.get(
					ServiceConstants.GET_BACKGROUND_IMAGE_URL, null,
					queryParams, headerParams, String.class);
			
		} catch (Exception ex) {
			logger.error("Exception occured in getBackgroundImage method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return bgImage;
	}
	@Override
	public String updateReadFlag(String objId) throws RMDWebException {
		final UpdateReadFlagRequestType updateReadFlagRequestType = new UpdateReadFlagRequestType();
		String responce = null;
		try{
			if(!RMDCommonUtility.isNullOrEmpty(objId)){
				updateReadFlagRequestType.setObjId(objId);
				}
				else
				{
					updateReadFlagRequestType.setObjId(AppConstants.EMPTYSTRING);
				}
		responce = (String) webServiceInvoker.post(
				ServiceConstants.UPDATE_READ_FLAG,
				updateReadFlagRequestType, String.class);
		}catch (Exception e) {
			logger.error("Exception occured in updateReadFlag method of UserManagementServiceImpl"
                    + e);
            RMDWebErrorHandler.handleException(e);
		}
		
		return responce;
	}

}
