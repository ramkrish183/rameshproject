package com.ge.trans.rmd.cm.mvc.model;

public class RuleBean {
 
	private String ruleId;
	private String ruleDefId;

	
	public String getRuleId() {
		return ruleId;
	}

	public void setRuleId(String ruleId) {
		this.ruleId = ruleId;
	}

	public String getRuleDefId() {
		return ruleDefId;
	}

	public void setRuleDefId(final String ruleDefId) {
		this.ruleDefId = ruleDefId;
	}
}
