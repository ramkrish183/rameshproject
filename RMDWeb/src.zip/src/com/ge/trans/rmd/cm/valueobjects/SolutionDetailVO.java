/**
 * ============================================================
 * File 			: SolutionDetailVO.java
 * Description 		: Value Object for SolutionDetails
 * Package 			: com.ge.trans.rmd.cm.valueobjects
 * Author 			: UST
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		: April 3, 2012
 * History
 * Modified By 		: Initial Release
 * Copyright (C) 2012 General Electric Company. All rights reserved
 * ============================================================
 */

package com.ge.trans.rmd.cm.valueobjects;

public class SolutionDetailVO {

	private String solutionID;
	private String solutionTitle;
	private String solutionStatus;
	private String urgRepair;
	private String estmTimeRepair;
	private String strSolutionDelvDt;
	private String solutionRevNo;
	private String revisionComments;
	private String lockedBy;
	private String processType;
	private String locomotiveImpact;
	private String solutionCloseDate;
	private String solutionNotes;
	private String repairAction;
	private String feedbackCode;
	private String feedback;

	public String getRepairAction() {
		return repairAction;
	}

	public void setRepairAction(String repairAction) {
		this.repairAction = repairAction;
	}

	public String getFeedbackCode() {
		return feedbackCode;
	}

	public void setFeedbackCode(String feedbackCode) {
		this.feedbackCode = feedbackCode;
	}

	public String getFeedback() {
		return feedback;
	}

	public void setFeedback(String feedback) {
		this.feedback = feedback;
	}


	public String getSolutionID() {
		return solutionID;
	}

	public void setSolutionID(String solutionID) {
		this.solutionID = solutionID;
	}

	public String getSolutionTitle() {
		return solutionTitle;
	}

	public void setSolutionTitle(String solutionTitle) {
		this.solutionTitle = solutionTitle;
	}

	public String getSolutionStatus() {
		return solutionStatus;
	}

	public void setSolutionStatus(String solutionStatus) {
		this.solutionStatus = solutionStatus;
	}

	public String getUrgRepair() {
		return urgRepair;
	}

	public void setUrgRepair(String urgRepair) {
		this.urgRepair = urgRepair;
	}

	public String getEstmTimeRepair() {
		return estmTimeRepair;
	}

	public void setEstmTimeRepair(String estmTimeRepair) {
		this.estmTimeRepair = estmTimeRepair;
	}

	public String getStrSolutionDelvDt() {
		return strSolutionDelvDt;
	}

	public void setStrSolutionDelvDt(String strSolutionDelvDt) {
		this.strSolutionDelvDt = strSolutionDelvDt;
	}

	public String getSolutionRevNo() {
		return solutionRevNo;
	}

	public void setSolutionRevNo(String solutionRevNo) {
		this.solutionRevNo = solutionRevNo;
	}

	public String getRevisionComments() {
		return revisionComments;
	}

	public void setRevisionComments(String revisionComments) {
		this.revisionComments = revisionComments;
	}

	public String getLockedBy() {
		return lockedBy;
	}

	public void setLockedBy(String lockedBy) {
		this.lockedBy = lockedBy;
	}

	public String getProcessType() {
		return processType;
	}

	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public String getLocomotiveImpact() {
		return locomotiveImpact;
	}

	public void setLocomotiveImpact(String locomotiveImpact) {
		this.locomotiveImpact = locomotiveImpact;
	}

	public String getSolutionCloseDate() {
		return solutionCloseDate;
	}

	public void setSolutionCloseDate(String solutionCloseDate) {
		this.solutionCloseDate = solutionCloseDate;
	}
	public String getSolutionNotes() {
		return solutionNotes;
	}

	public void setSolutionNotes(String solutionNotes) {
		this.solutionNotes = solutionNotes;
	}

}
