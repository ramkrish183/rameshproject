/**
 * ============================================================

 * Classification		: GE Confidential
 * File 				: QueueDetailsVO.java
 * Description 			:
 * Package 				: com.ge.trans.rmd.cm.valueobjects;
 * Author 				: iGATE Global Solutions Ltd.
 * Last Edited By 		:
 * Version 				: 1.0
 * Created on 			:
 * History				:
 * Modified By 			: Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */

package com.ge.trans.rmd.cm.valueobjects;

/*******************************************************************************
 * 
 * @Author 			:
 * @Version 		: 1.0
 * @Date Created	:
 * @Date Modified 	:
 * @Modified By 	:
 * @Contact 		:
 * @Description 	:This is plain POJO class which contains queueId,queueName
 *             		 Declarations along with their respective getters and setters.
 * @History 		:
 * 
 ******************************************************************************/


public class RecommDelVO {

private String rxObjId;
private String caseId;
private String customerName;
private String recommNotes;
private String userName;

public String getUserName() {
	return userName;
}
public void setUserName(String userName) {
	this.userName = userName;
}
public String getRxObjId() {
	return rxObjId;
}
public void setRxObjId(String rxObjId) {
	this.rxObjId = rxObjId;
}
public String getCaseId() {
	return caseId;
}
public void setCaseId(String caseId) {
	this.caseId = caseId;
}

public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getRecommNotes() {
	return recommNotes;
}
public void setRecommNotes(String recommNotes) {
	this.recommNotes = recommNotes;
}



	
}
