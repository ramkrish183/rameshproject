/**
 * 
 */
package com.ge.trans.rmd.cm.valueobjects;

/**
 * @author MSHIRAJUDDIN
 *
 */
public class LDVRMasterDataResponseVO {
	
	private DataSetVO[] dataSet;

	/**
	 * @return the dataSet
	 */
	public DataSetVO[] getDataSet() {
		return dataSet;
	}

	/**
	 * @param dataSet the dataSet to set
	 */
	public void setDataSet(DataSetVO[] dataSet) {
		this.dataSet = dataSet;
	}


}
