package com.ge.trans.rmd.cm.mvc.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.RepairFacilityService;
import com.ge.trans.rmd.cm.valueobjects.RepairFacilityDetailsVO;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
public class RepairFacilityController extends RMDBaseController{
	
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
	.getLogger(getClass());
	@Autowired
	RepairFacilityService repairFacilityService;
	@Autowired
	ApplicationContext appContext;
	
	@RequestMapping(AppConstants.REQ_URI_REPAIR_FACILITY)
	public ModelAndView showRepairFacilityPage(final HttpServletRequest request) {
		rmdWebLogger.debug("Inside showRepairFacilityPage method of RepairFacilityController");
		return new ModelAndView(AppConstants.REPAIR_FACILITY);
	}

	/**
	 * @Author:
	 * @param:customerId
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the sites for
	 *               the selected customer
	 */
	@RequestMapping(value = AppConstants.GET_CUST_SITES)
	public @ResponseBody
	Map<String, String> getCustomerSites(
			@RequestParam(value = AppConstants.CUSTOMER_ID) final String customerId)
			throws RMDWebException {
		Map<String, String> custSiteMap = new LinkedHashMap<String, String>();
		try {
			custSiteMap = repairFacilityService
					.getCustomerSites(EsapiUtil.stripXSSCharacters(customerId));
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getCustomerSites() method of RepairFacilityController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return custSiteMap;
	}
	
	/**
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the rail code status values in  drop down.
	 */
	@RequestMapping(value = AppConstants.GET_REPAIR_FACILITY_STATUS)
	public @ResponseBody
	Map<String, String> getRepairFacilityStatus() throws RMDWebException {
		Map<String, String> statusMap = new LinkedHashMap<String, String>();
		try {
			statusMap = repairFacilityService.getRepairFacilityStatus();
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCfgStatusList method of RepairFacilityController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return statusMap;
	}
	
	/**
	 * 
	 * @param customerId
	 *            ,site,status
	 * @return RepairFacilityDetailsVO
	 * @throws RMDWebException
	 * @Description This method is used to get the Repair Facility Details.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_REPAIR_FACILITY_DETAILS, method = RequestMethod.GET)
	public @ResponseBody
	List<RepairFacilityDetailsVO> getRepairFacilityDetails(
			@RequestParam(value = AppConstants.CUSTOMER_ID) final String customerId,
			@RequestParam(value = AppConstants.SITE) final String site,
			@RequestParam(value = AppConstants.STATUS) final String status,
			final HttpServletRequest request) throws RMDWebException {
		List<RepairFacilityDetailsVO> repairFacilityDetailsList = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(customerId)
					&& !RMDCommonUtility.isNullOrEmpty(site)
					&& !RMDCommonUtility.isNullOrEmpty(status)) {
				repairFacilityDetailsList = repairFacilityService
						.getRepairFacilityDetails(customerId, site, status);
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getRepairFacilityDetails method of RepairFacilityController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return repairFacilityDetailsList;

	}
	
	/**
	 * 
	 * @param RepairFacilityDetailsVO
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used to insert new repair/site location details.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_INSERT_REPAIR_SITE_LOCATION, method = RequestMethod.POST)
	public @ResponseBody
	String insertRepairSiteLoc(
			@RequestParam(value = AppConstants.CUSTOMER_ID) final String customerId,
			@RequestParam(value = AppConstants.SITE) final String site,
			@RequestParam(value = AppConstants.RAILWAY_DESIG_CODE) final String railWayDesigCode,
			@RequestParam(value = AppConstants.REPAIR_LOCATION) final String repairLocation,
			@RequestParam(value = AppConstants.LOCATION_CODE) final String locationCode,
			@RequestParam(value = AppConstants.STATUS) final String status,
			@RequestParam(value = AppConstants.USER_ID) final String userId,
			final HttpServletRequest request) throws RMDWebException {
		rmdWebLogger
				.debug("Inside insertRepairSiteLoc method of  RepairFacilityController");
		String result = AppConstants.FAILURE;
		RepairFacilityDetailsVO repairFacilityDetailsVO = new RepairFacilityDetailsVO();
		try {
			if (!RMDCommonUtility.isNullOrEmpty(customerId)) {
				repairFacilityDetailsVO.setCustomerId(EsapiUtil.stripXSSCharacters(customerId));
			}
			if (!RMDCommonUtility.isNullOrEmpty(site)) {
				repairFacilityDetailsVO.setSite(EsapiUtil.stripXSSCharacters(site));
			}
			if (!RMDCommonUtility.isNullOrEmpty(railWayDesigCode)) {
				repairFacilityDetailsVO.setRailWayDesigCode(railWayDesigCode);
			}
			if (!RMDCommonUtility.isNullOrEmpty(repairLocation)) {
				repairFacilityDetailsVO.setRepairLocation(repairLocation);
			}
			if (!RMDCommonUtility.isNullOrEmpty(locationCode)) {
				repairFacilityDetailsVO.setLocationCode(locationCode);
			}
			if (!RMDCommonUtility.isNullOrEmpty(status)) {
				repairFacilityDetailsVO.setStatus(status);
			}
			if (!RMDCommonUtility.isNullOrEmpty(userId)) {
				repairFacilityDetailsVO.setUserName(userId);
			}
			result = repairFacilityService
					.insertRepairSiteLoc(repairFacilityDetailsVO);

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in insertRepairSiteLoc method of RepairFacilityController",
							ex);
			result = AppConstants.FAILURE;
			RMDWebErrorHandler.handleException(ex);
		}

		return result;

	}
	
	/**
	 * 
	 * @param parameterString
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used to update existing repair/site location
	 *              details.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_UPDATE_REPAIR_SITE_DETAILS, method = RequestMethod.POST)
	public @ResponseBody
	String updateRepairSiteLoc(
			@RequestParam(value = AppConstants.GET_PARAMETER_STRING) final String parameterString,
			final HttpServletRequest request) throws RMDWebException {
		String result = AppConstants.FAILURE;
		List<RepairFacilityDetailsVO> repairFacilityDetailsVOList = new ArrayList<RepairFacilityDetailsVO>();
		final ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			RepairFacilityDetailsVO[] arrRepairFacilityDetailsVO = mapper
					.readValue(EsapiUtil.stripXSSCharacters(parameterString), RepairFacilityDetailsVO[].class);
			repairFacilityDetailsVOList = Arrays
					.asList(arrRepairFacilityDetailsVO);
			result = repairFacilityService
					.updateRepairSiteLoc(repairFacilityDetailsVOList);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in updateRepairSilteLoc method of RepairFacilityController",
							ex);
			result = AppConstants.FAILURE;
			RMDWebErrorHandler.handleException(ex);
		}

		return result;
	}
}
