package com.ge.trans.rmd.cm.service;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.Future;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import com.ge.trans.rmd.cm.beans.MapBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.assets.valueobjects.AssetLocRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetLocatorResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CasesRequestType;
import com.ge.trans.rmd.services.solutions.valueobjects.UrgencyResponseType;

@Component
public class MapServiceCallWrapper extends RMDBaseServiceImpl{

	private final RMDWebLogger logger = RMDWebLogger.getLogger(getClass());
	
	@Autowired
	private WebServiceInvoker rsInvoker;
	
	
	/* Getting the asset location response for all assets */
	@Async
	public Future<AssetLocatorResponseType[]> getAssetLocation(
			Map<String, String> headerParams, MapBean mapBean)
			throws RMDWebException, Exception {

		AssetLocRequestType objAssetLocReqType=new AssetLocRequestType();
		objAssetLocReqType.setLastFault(mapBean.isLastFault());
		objAssetLocReqType.setLanguage(headerParams.get(AppConstants.USER_LANGUAGE));
		objAssetLocReqType.setCustomerId(mapBean.getCustomerId());
		parseProducts(mapBean.getProducts(),objAssetLocReqType);
		AssetLocatorResponseType[] assetLocResponses = null;
		try {
	/*For Fleet*/
			if (null != mapBean.getFleet()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(mapBean.getFleet())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(mapBean.getFleet())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(mapBean.getFleet())) {

				objAssetLocReqType.setFleetId(mapBean.getFleet());
			}
			/*For Model*/
			if (null != mapBean.getModel()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(mapBean.getModel())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(mapBean.getModel())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(mapBean.getModel())) {

				objAssetLocReqType.setModelId(mapBean.getModel());
			}
			objAssetLocReqType.setScreenName("MAP");
			assetLocResponses = (AssetLocatorResponseType[]) rsInvoker.post(
					ServiceConstants.GET_ASSET_FAULT_LOCATION, objAssetLocReqType,
					AssetLocatorResponseType[].class);

		} catch (Exception e) {
			logger.error("Exception occured in getAssetLocation method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return new AsyncResult<AssetLocatorResponseType[]>(assetLocResponses);
	}

	/* Getting the asset response for all assets */
	@Async
	public Future<AssetResponseType[]> getAssetResponse(
			Map<String, String> headerParams, MapBean mapBean)
			throws RMDWebException, Exception {

		AssetsRequestType objAssetsReqType=new AssetsRequestType();
		objAssetsReqType.setLanguage(headerParams.get(AppConstants.USER_LANGUAGE));
		objAssetsReqType.setCustomerId(mapBean.getCustomerId());
		parseProducts(mapBean.getProducts(),objAssetsReqType);
		AssetResponseType[] assetResponses = null;

		try {
			assetResponses = (AssetResponseType[]) rsInvoker.post(
					ServiceConstants.GET_ASSETS, objAssetsReqType, AssetResponseType[].class);

		} catch (Exception e) {
			logger.error("Exception occured in getAssetResponse method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return new AsyncResult<AssetResponseType[]>(assetResponses);
	}

	/* Getting the worst urgency response for all assets */
	@Async
	public Future<UrgencyResponseType[]> getUrgencyResponse(
			final Map<String, String> headerParams, String customerId)
			throws RMDWebException, Exception {

		final Map<String, String> queryParamsMap = new HashMap<String, String>();
		queryParamsMap.put(AppConstants.WS_PARAM_CUSTID, customerId);
		UrgencyResponseType[] urgencyResponses = null;

		try {
			urgencyResponses = (UrgencyResponseType[]) rsInvoker.get(
					ServiceConstants.GET_WORST_URGENCY, null, queryParamsMap,
					headerParams, UrgencyResponseType[].class);

		} catch (Exception e) {
			logger.error("Exception occured in getUrgencyResponse() method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return new AsyncResult<UrgencyResponseType[]>(urgencyResponses);
	}

	/* Getting the cases(open rx) response for all assets */
	@Async
	public Future<CaseResponseType[]> getCaseResponse(
			final Map<String, String> headerParams, MapBean mapBean)
			throws RMDWebException, Exception {

		CasesRequestType objCasesReqType=new CasesRequestType();
		objCasesReqType.setCustomerId(mapBean.getCustomerId());
		objCasesReqType.setUserLanguage(mapBean.getUserLanguage());
		parseProducts(mapBean.getProducts(), objCasesReqType);
		CaseResponseType[] caseRespType = null;
		try {
			objCasesReqType.setSolutionStatus(AppConstants.STATUS_OPEN);
			if (null != mapBean.getUrgency()
					&& !RMDCommonConstants.EMPTY_STRING.equals(mapBean.getUrgency())
					&& !RMDCommonConstants.SELECT
					.equalsIgnoreCase(mapBean.getUrgency())
			&& !AppConstants.UNDEFINED
					.equalsIgnoreCase(mapBean.getUrgency()))

				objCasesReqType.setUrgency(mapBean.getUrgency());
			if (null != mapBean.getEstRepTime()
					&& !RMDCommonConstants.EMPTY_STRING.equals(mapBean.getEstRepTime())
					&& !RMDCommonConstants.SELECT
					.equalsIgnoreCase(mapBean.getEstRepTime())
			&& !AppConstants.UNDEFINED
					.equalsIgnoreCase(mapBean.getEstRepTime()))
				objCasesReqType.setEstRepTm(mapBean.getEstRepTime());
			
			/*For CaseType*/
			if (null != mapBean.getCaseType()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(mapBean.getCaseType())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(mapBean.getCaseType())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(mapBean.getCaseType())) {

				objCasesReqType.setCaseType(mapBean.getCaseType());
			}
			/*For CaseType*/
			/*For Fleet*/
			if (null != mapBean.getFleet()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(mapBean.getFleet())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(mapBean.getFleet())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(mapBean.getFleet())) {
				objCasesReqType.setFleetId(mapBean.getFleet());
			}
			/*For Model*/
			if (null != mapBean.getModel()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(mapBean.getModel())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(mapBean.getModel())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(mapBean.getModel())) {
				objCasesReqType.setModelId(mapBean.getModel());
			}
			objCasesReqType.setRxId(mapBean.getRxIds());
			/*if (null != mapBean.getRxIds() && !RMDCommonConstants.EMPTY_STRING.equals(mapBean.getRxIds())) {
				String[] totalRxIdsArr = mapBean.getRxIds().split(",");
				String[] subRxIdsArr = null;
				int limitOfRxIds=1000;
				String rxIdForWS = "";
				int countToIterate = totalRxIdsArr.length / limitOfRxIds;
				if (countToIterate > 0) {
					CaseResponseType[] combinedCaseResponse = null;
					for (int i = 0; i <= countToIterate; i++) {
						rxIdForWS = "";
						/* copying 1000 or less rx ids to new array */
						/*if (totalRxIdsArr.length - (i * limitOfRxIds) >= limitOfRxIds) {
							subRxIdsArr = new String[limitOfRxIds];
							System.arraycopy(totalRxIdsArr, i * limitOfRxIds,
									subRxIdsArr, 0, subRxIdsArr.length);
						} else {
							subRxIdsArr = new String[totalRxIdsArr.length
									- (i * limitOfRxIds)];
							System.arraycopy(totalRxIdsArr, i * limitOfRxIds,
									subRxIdsArr, 0, totalRxIdsArr.length
											- (i * limitOfRxIds));
						}
						for (int j = 0; j < subRxIdsArr.length; j++) {

							rxIdForWS = rxIdForWS + subRxIdsArr[j];
							if (j < subRxIdsArr.length)
								rxIdForWS = rxIdForWS + ",";
						}
						/*queryParamsMap.put(AppConstants.FILTER_PARAM_RX_IDS,
								rxIdForWS);*/
						/*objCasesReqType.setRxId(rxIdForWS);
						try {
							caseRespType = (CaseResponseType[]) rsInvoker.post(
									ServiceConstants.CASES_SERVICE_LITE_GETDELCASES, objCasesReqType,
									CaseResponseType[].class);
						} catch (Exception e) {

							if (e instanceof RMDWebException) {

								RMDWebException rmdEx = (RMDWebException) e;
								if (AppConstants.EXCEPTION_EOA_101
										.equalsIgnoreCase(rmdEx.getErrorCode())) {
									continue;
								} else
									throw e;
							}

						}

						combinedCaseResponse = (CaseResponseType[]) ArrayUtils
								.addAll(combinedCaseResponse, caseRespType);

					}
					caseRespType = combinedCaseResponse;
				} else {
					/*queryParamsMap.put(AppConstants.FILTER_PARAM_RX_IDS, mapBean.getRxIds());*/
					/*objCasesReqType.setRxId(mapBean.getRxIds());
					caseRespType = (CaseResponseType[]) rsInvoker.post(
							ServiceConstants.CASES_SERVICE_LITE_GETDELCASES,objCasesReqType,
							CaseResponseType[].class);
				}

			} else { */
				caseRespType = (CaseResponseType[]) rsInvoker.post(
						ServiceConstants.CASES_SERVICE_LITE_GETDELCASES,objCasesReqType, CaseResponseType[].class);
			//}
		} catch (Exception e) {
			logger.error("In MapServiceCallWrapper : Exception occured in getCaseResponse() method "+e.getMessage());
			RMDWebErrorHandler.handleException(e);
		}
		return new AsyncResult<CaseResponseType[]>(caseRespType);
	}

	
}
