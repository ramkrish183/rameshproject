/**
 * ============================================================
 * File 			: TaskDetailVO.java
 * Description 		: Value Object for Rx Case Task Details Display * 
 * Package 			: com.ge.trans.rmd.cm.valueobjects
 * Author 			: UST
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		: April 3, 2012
 * History
 * Modified By 		: Initial Release
 * Copyright (C) 2012 General Electric Company. All rights reserved
 * ============================================================
 */
package com.ge.trans.rmd.cm.valueobjects;

import java.util.Date;
import java.util.List;

public class TaskDetailVO {

	private String taskID;
	private String taskDesc;
	private String subTask;
	private String usl;
	private String lsl;
	private String target;
	private String taskComments;
	private String recomTaskId;
	private String checkedFlag;
	private String lastUpdatedBy;
	private String disable;
	private Date lastUpdatedDate;
	private String taskExecutedUserId;
	private Date rxCloseCreationDate;	
	private String isTaskModified;
	private String docTitle;
    private String docPath;
    private List<AttachmentVO> docAttachment;
    
	public String getTaskID() {
		return taskID;
	}

	public void setTaskID(final String taskID) {
		this.taskID = taskID;
	}


	public String getTaskDesc() {
		return taskDesc;
	}

	public void setTaskDesc(final String taskDesc) {
		this.taskDesc = taskDesc;
	}

	public String getSubTask() {
		return subTask;
	}

	public void setSubTask(final String subTask) {
		this.subTask = subTask;
	}

	public String getUsl() {
		return usl;
	}

	public void setUsl(final String usl) {
		this.usl = usl;
	}

	public String getLsl() {
		return lsl;
	}

	public void setLsl(final String lsl) {
		this.lsl = lsl;
	}

	public String getTarget() {
		return target;
	}

	public void setTarget(final String target) {
		this.target = target;
	}

	public String getTaskComments() {
		return taskComments;
	}

	public void setTaskComments(final String taskComments) {
		this.taskComments = taskComments;
	}

	public String getRecomTaskId() {
		return recomTaskId;
	}

	public void setRecomTaskId(final String recomTaskId) {
		this.recomTaskId = recomTaskId;
	}

	public String getCheckedFlag() {
		return checkedFlag;
	}

	public void setCheckedFlag(final String checkedFlag) {
		this.checkedFlag = checkedFlag;
	}

	public String getLastUpdatedBy() {
		return lastUpdatedBy;
	}

	public void setLastUpdatedBy(final String lastUpdatedBy) {
		this.lastUpdatedBy = lastUpdatedBy;
	}

	public String getDisable() {
		return disable;
	}

	public void setDisable(final String disable) {
		this.disable = disable;
	}

	public List<AttachmentVO> getDocAttachment() {
		return docAttachment;
	}

	public void setDocAttachment(List<AttachmentVO> docAttachment) {
		this.docAttachment = docAttachment;
	}

	public Date getLastUpdatedDate() {
		return lastUpdatedDate;
	}

	public void setLastUpdatedDate(final Date lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}

	public String getTaskExecutedUserId() {
		return taskExecutedUserId;
	}

	public void setTaskExecutedUserId(String taskExecutedUserId) {
		this.taskExecutedUserId = taskExecutedUserId;
	}

	public Date getRxCloseCreationDate() {
		return rxCloseCreationDate;
	}

	public void setRxCloseCreationDate(Date rxCloseCreationDate) {
		this.rxCloseCreationDate = rxCloseCreationDate;
	}	

	public String getDocTitle() {
		return docTitle;
	}

	public void setDocTitle(String docTitle) {
		this.docTitle = docTitle;
	}

	public String getDocPath() {
		return docPath;
	}

	public void setDocPath(String docPath) {
		this.docPath = docPath;
	}

	public String getIsTaskModified() {
		return isTaskModified;
	}

	public void setIsTaskModified(String isTaskModified) {
		this.isTaskModified = isTaskModified;
	}
}