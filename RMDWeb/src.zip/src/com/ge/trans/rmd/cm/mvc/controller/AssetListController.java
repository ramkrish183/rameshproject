/**
 * ============================================================
 * File : AssetListController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.cm.mvc.controller
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Mar 05, 2012
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */

package com.ge.trans.rmd.cm.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.common.beans.HeaderSearchBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.HeaderSearchService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.HeaderSearchResponseVO;
import com.ge.trans.rmd.common.vo.HeaderSearchVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.common.vo.CustomerVO;
import com.ge.trans.rmd.pp.service.PPHeaderSearchService;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class AssetListController extends RMDBaseController {

	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	private HeaderSearchService headerSearchService;
	@Autowired
	private PPHeaderSearchService ppsearchService;
	@RequestMapping(value = AppConstants.REQ_URI_ASSETLIST)
	public ModelAndView getAssets(final HttpServletRequest request)
			throws RMDWebException, Exception {
		request.setAttribute(AppConstants.FILTERFLAG,
				request.getParameter(AppConstants.FLAG));

		List<HeaderSearchVO> headerSearchVOLst = new ArrayList<HeaderSearchVO>();
		final HttpSession session = request.getSession(false);
		final HeaderSearchBean headerSearchBean = new HeaderSearchBean();
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String searchString = request
				.getParameter(AppConstants.HEADERSEARCH_SEARCH_STRING);
		String tab_name=request
				.getParameter(AppConstants.TAB_NAME);
		 String sticky_tab_name=request
				.getParameter(AppConstants.STICKY_TAB_NAME);
		HeaderSearchResponseVO responseVO =null;
		String customerList="";
		try {
			if (null != searchString && searchString.trim().length() > 0) {
				headerSearchBean.setUserLanguage(userVO.getStrUserLanguage());
				headerSearchBean.setTimeZone(userVO.getTimeZone());
				headerSearchBean.setStrCustomerId(userVO.getCustomerId());
				headerSearchBean.setSearchString(searchString);
				if (userVO.getIsCMPrivilege()
						&& null != userVO.getCmAliasName()
						&&!RMDCommonConstants.EMPTY_STRING.equalsIgnoreCase(userVO
								.getCmAliasName())) {
				if (!RMDCommonUtility.isNullOrEmpty(userVO.getCustomerId())) {
					customerList = getCustomerList(userVO.getCustomerList());
					headerSearchBean.setStrCustomerId(customerList);
				}
				headerSearchBean.setGPOCUser(true);
				}
				if (null != userVO.getProducts()
						&& !userVO.getProducts().isEmpty() && (tab_name!=null || sticky_tab_name!=null)) {
				headerSearchBean.setProducts(userVO.getProducts());
				if(tab_name.equals("AssetTracker") || sticky_tab_name.equals("PPASSET_STICKYTAB"))
				{
					responseVO =ppsearchService.getPPSearchAssets(headerSearchBean);
				
				}
				else
				{
					responseVO = headerSearchService
							.getAssets(headerSearchBean);
				}
				}
				if (null != responseVO) {
					headerSearchVOLst = responseVO.getAssets();
				}

				request.setAttribute(AppConstants.HEADERSEARCH_VO_LST,
						headerSearchVOLst);
				request.setAttribute(AppConstants.HEADERSEARCH_SEARCH_STRING,
						searchString);
				if(null != request.getParameter(AppConstants.DATA_CASE_LENGTH)){
					request.setAttribute(AppConstants.DATA_CASE_LENGTH,
						request.getParameter(AppConstants.DATA_CASE_LENGTH));
				}
				if(null != request.getParameter(AppConstants.DATA_ASSET_LENGTH)){
					request.setAttribute(AppConstants.DATA_ASSET_LENGTH,
						request.getParameter(AppConstants.DATA_ASSET_LENGTH));
				}else if(null != headerSearchVOLst){
					request.setAttribute(AppConstants.DATA_ASSET_LENGTH, headerSearchVOLst.size());
				}

			}
			//adding for pagination - Start
			request.setAttribute(
					AppConstants.ASSET_DEFAULT_RECORDS,
					findNumberOfRecords(AppConstants.ASSET_TABLE_DEFAULT_RECORDS));
			request.setAttribute(AppConstants.TAB_NAME, tab_name);
			request.setAttribute(AppConstants.STICKY_TAB_NAME, sticky_tab_name);
			
			return new ModelAndView(AppConstants.VIEW_ASSETLIST);
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getAssets() method ", rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getAssets method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		}
	}
}
