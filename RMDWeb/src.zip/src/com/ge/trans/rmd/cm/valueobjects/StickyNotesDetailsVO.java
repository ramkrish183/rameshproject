/**
 * ============================================================

 * Classification	: GE Confidential
 * File 			: StickyNotesDetailsVO.java
 * Description 		:This is a POJO class which contains information about StickyNotes Details. 
 * Package 			: com.ge.trans.rmd.cm.valueobjects;
 * Author 			: iGATE Global Solutions Ltd.
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		:
 * History
 * Modified By 		: Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

/*******************************************************************************
 * 
 * @Author 			:
 * @Version 		: 1.0
 * @Date Created 	:
 * @Date Modified	:
 * @Modified By 	:
 * @Contact 		:	
 * @Description		:This is a plain POJO class which carries details about
 *              	StickyNotes.
 * @History 		:
 * 
 ******************************************************************************/
public class StickyNotesDetailsVO {

	private String applyLevel;
	private String additionalInfo;
	private String entryTime;
	private String createdBy;
	private String objId;
	private List<String> stickyAssets;
	private List<String> nonStickyAssets;

	public List<String> getNonStickyAssets() {
		return nonStickyAssets;
	}

	public void setNonStickyAssets(List<String> nonStickyAssets) {
		this.nonStickyAssets = nonStickyAssets;
	}
	public String getApplyLevel() {
		return applyLevel;
	}

	public void setApplyLevel(String applyLevel) {
		this.applyLevel = applyLevel;
	}

	public String getAdditionalInfo() {
		return additionalInfo;
	}

	public void setAdditionalInfo(String additionalInfo) {
		this.additionalInfo = additionalInfo;
	}

	public String getEntryTime() {
		return entryTime;
	}

	public void setEntryTime(String entryTime) {
		this.entryTime = entryTime;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public String getObjId() {
		return objId;
	}

	public void setObjId(String objId) {
		this.objId = objId;
	}
	public List<String> getStickyAssets() {
		return stickyAssets;
	}

	public void setStickyAssets(List<String> stickyAssets) {
		this.stickyAssets = stickyAssets;
	}
}
