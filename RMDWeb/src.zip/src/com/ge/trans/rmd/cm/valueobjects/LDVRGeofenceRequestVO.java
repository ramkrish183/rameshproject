package com.ge.trans.rmd.cm.valueobjects;

public class LDVRGeofenceRequestVO {

	private String assetOwnerId;
	private String activeFlag;
	private String geofenceName; 
	
	public String getAssetOwnerId() {
		return assetOwnerId;
	}
	public void setAssetOwnerId(String assetOwnerId) {
		this.assetOwnerId = assetOwnerId;
	}
	public String getActiveFlag() {
		return activeFlag;
	}
	public void setActiveFlag(String activeFlag) {
		this.activeFlag = activeFlag;
	}	
	/**
	 * @return the geofenceName
	 */
	public String getGeofenceName() {
		return geofenceName;
	}
	/**
	 * @param geofenceName the geofenceName to set
	 */
	public void setGeofenceName(String geofenceName) {
		this.geofenceName = geofenceName;
	}
	@Override
	public String toString() {
		return "[assetOwnerId="+assetOwnerId+", activeFlag="+activeFlag+",geofenceName="+geofenceName+"]";
	}
	
}
