/**
 * ============================================================
 * File 			: TechnicianCaseDetailVO.java
 * Description 		: Value Object for Open Rx Technician Cases Page Display 
 * Package 			: com.ge.trans.rmd.cm.valueobjects
 * Author 			: UST
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		: April 3, 2012
 * History
 * Modified By 		: Initial Release
 * Copyright (C) 2012 General Electric Company. All rights reserved
 * ============================================================
 */
package com.ge.trans.rmd.cm.valueobjects;

import java.io.Serializable;

public class TechnicianSolutionDetailVO implements Serializable {

	private static final long serialVersionUID = 10545L;
	private String solutionCaseID;
	private String solutionStatus;
	private String solutionDelvDate;
	private String solutionCloseDate;
	private String solutionTitle;
	private String solutionOBJID;
	private String urgency;
	private String estmRepairTime;
	private String locomotiveImpact;
	private String closedDateAge;
	private String reissueRxDelvDate;
	private String reissueRxDelvAge;
	

	public String getSolutionCaseID() {
		return solutionCaseID;
	}

	public void setSolutionCaseID(String solutionCaseID) {
		this.solutionCaseID = solutionCaseID;
	}

	public String getSolutionStatus() {
		return solutionStatus;
	}

	public void setSolutionStatus(String solutionStatus) {
		this.solutionStatus = solutionStatus;
	}

	public String getSolutionDelvDate() {
		return solutionDelvDate;
	}

	public void setSolutionDelvDate(String solutionDelvDate) {
		this.solutionDelvDate = solutionDelvDate;
	}

	public String getSolutionCloseDate() {
		return solutionCloseDate;
	}

	public void setSolutionCloseDate(String solutionCloseDate) {
		this.solutionCloseDate = solutionCloseDate;
	}

	public String getSolutionTitle() {
		return solutionTitle;
	}

	public void setSolutionTitle(String solutionTitle) {
		this.solutionTitle = solutionTitle;
	}

	public String getSolutionOBJID() {
		return solutionOBJID;
	}

	public void setSolutionOBJID(String solutionOBJID) {
		this.solutionOBJID = solutionOBJID;
	}

	public String getUrgency() {
		return urgency;
	}

	public void setUrgency(String urgency) {
		this.urgency = urgency;
	}

	public String getEstmRepairTime() {
		return estmRepairTime;
	}

	public void setEstmRepairTime(String estmRepairTime) {
		this.estmRepairTime = estmRepairTime;
	}

	public String getLocomotiveImpact() {
		return locomotiveImpact;
	}

	public void setLocomotiveImpact(String locomotiveImpact) {
		this.locomotiveImpact = locomotiveImpact;
	}

	public String getClosedDateAge() {
		return closedDateAge;
	}

	public void setClosedDateAge(String closedDateAge) {
		this.closedDateAge = closedDateAge;
	}

	public String getReissueRxDelvDate() {
		return reissueRxDelvDate;
	}

	public void setReissueRxDelvDate(String reissueRxDelvDate) {
		this.reissueRxDelvDate = reissueRxDelvDate;
	}

	public String getReissueRxDelvAge() {
		return reissueRxDelvAge;
	}

	public void setReissueRxDelvAge(String reissueRxDelvAge) {
		this.reissueRxDelvAge = reissueRxDelvAge;
	}

	

}
