package com.ge.trans.rmd.cm.beans;

import com.ge.trans.rmd.common.beans.RMDBaseBean;

@SuppressWarnings("serial")
public class MapBean extends RMDBaseBean{

	private String timeZone;
	private String customerId;
	private String urgency;
	private String estRepTime;
	private String rxIds;
	private String caseType;
	private String fleet;
	private String model;
	private String actionableRxType;
	private String timeZoneChk;
	private boolean isLastFault;
	
	public boolean isLastFault() {
		return isLastFault;
	}

	public void setLastFault(boolean isLastFault) {
		this.isLastFault = isLastFault;
	}

	public String getTimeZoneChk() {
		return timeZoneChk;
	}

	public void setTimeZoneChk(String timeZoneChk) {
		this.timeZoneChk = timeZoneChk;
	}

	public String getFleet() {
		return fleet;
	}

	public void setFleet(String fleet) {
		this.fleet = fleet;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getCaseType() {
		return caseType;
	}

	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}

	public String getRxIds() {
		return rxIds;
	}

	public void setRxIds(String rxIds) {
		this.rxIds = rxIds;
	}

	public String getUrgency() {
		return urgency;
	}

	public void setUrgency(String urgency) {
		this.urgency = urgency;
	}

	public String getEstRepTime() {
		return estRepTime;
	}

	public void setEstRepTime(String estRepTime) {
		this.estRepTime = estRepTime;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getActionableRxType() {
		return actionableRxType;
	}

	public void setActionableRxType(String actionableRxType) {
		this.actionableRxType = actionableRxType;
	}
	
}
