package com.ge.trans.rmd.cm.valueobjects;

import com.ge.trans.rmd.common.vo.RMDBaseVO;

public class AssetLastDownloadStatusVO extends RMDBaseVO{

	private String lstDownloadTm;
	private String lstDownloadHeader;
	private String state;
	private String stateHeader;
	private String vax;
	private String vaxHeader;
	private String vaxDt;
	private String egu;
	private String eguHeader;
	private String eguDt;

	private String inc;
	private String incHeader;
	private String incDt;

	private String snp;
	private String snpHeader;
	private String snpDt;
	
	public String getLstDownloadTm() {
		return lstDownloadTm;
	}
	public void setLstDownloadTm(String lstDownloadTm) {
		this.lstDownloadTm = lstDownloadTm;
	}
	public String getLstDownloadHeader() {
		return lstDownloadHeader;
	}
	public void setLstDownloadHeader(String lstDownloadHeader) {
		this.lstDownloadHeader = lstDownloadHeader;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getStateHeader() {
		return stateHeader;
	}
	public void setStateHeader(String stateHeader) {
		this.stateHeader = stateHeader;
	}
	public String getVax() {
		return vax;
	}
	public void setVax(String vax) {
		this.vax = vax;
	}
	public String getVaxHeader() {
		return vaxHeader;
	}
	public void setVaxHeader(String vaxHeader) {
		this.vaxHeader = vaxHeader;
	}
	
	public String getEgu() {
		return egu;
	}
	public void setEgu(String egu) {
		this.egu = egu;
	}
	public String getEguHeader() {
		return eguHeader;
	}
	public void setEguHeader(String eguHeader) {
		this.eguHeader = eguHeader;
	}
	
	public String getInc() {
		return inc;
	}
	public void setInc(String inc) {
		this.inc = inc;
	}
	public String getIncHeader() {
		return incHeader;
	}
	public void setIncHeader(String incHeader) {
		this.incHeader = incHeader;
	}
	
	public String getSnp() {
		return snp;
	}
	public void setSnp(String snp) {
		this.snp = snp;
	}
	public String getSnpHeader() {
		return snpHeader;
	}
	public void setSnpHeader(String snpHeader) {
		this.snpHeader = snpHeader;
	}
	public String getVaxDt() {
		return vaxDt;
	}
	public void setVaxDt(String vaxDt) {
		this.vaxDt = vaxDt;
	}
	public String getEguDt() {
		return eguDt;
	}
	public void setEguDt(String eguDt) {
		this.eguDt = eguDt;
	}
	public String getIncDt() {
		return incDt;
	}
	public void setIncDt(String incDt) {
		this.incDt = incDt;
	}
	public String getSnpDt() {
		return snpDt;
	}
	public void setSnpDt(String snpDt) {
		this.snpDt = snpDt;
	}
	
	
}
