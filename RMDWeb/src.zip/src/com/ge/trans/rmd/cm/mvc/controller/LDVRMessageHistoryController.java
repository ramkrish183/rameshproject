/*******************************************************************************
 *
 * @Author 		: GE
 * @Version 	: 1.0
 * @Date Created: Jan 21, 2016
 * @Date Modified:
 * @Modified By : 
 * @Contact 	:
 * @Description : This class act as a controller to get ldvr message history data
 * 
 * @History		:
 *
 ******************************************************************************/
package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.AssetDataScreenService;
import com.ge.trans.rmd.cm.service.AssetOverviewService;
import com.ge.trans.rmd.cm.service.LDVRRequestsService;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetCriteriaVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRMessageHistoryRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRMessageHistoryResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRMessageVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class LDVRMessageHistoryController extends RMDBaseController {
	private final  RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	
	@Autowired
	private ApplicationContext appContext;

	@Autowired
	private LDVRRequestsService ldvrRequestsService;

	@Autowired
	private LDVRRequestController ldvrRequestController;

	@Autowired
	private AssetOverviewService asstOvwService;
	
	@Autowired
	private AssetDataScreenService objAssetDataScreenService;
	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description:
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_MSG_HISTORY, method = RequestMethod.GET)
	public ModelAndView getLDVRMessageHistoryPage(
			final HttpServletRequest request) throws RMDWebException {

		rmdWebLogger.info("Inside getLDVRMessageHistoryPage method");
		final String strAssetNumber = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String strAssetGroup = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_GROUP_NAME));
		
		String strCustomerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_CUSID));
		if(RMDCommonUtility.isNullOrEmpty(strCustomerId)){
			strCustomerId = asstOvwService.getCustomerId(strAssetNumber, strAssetGroup);
			
		}
		final String roadInitial = ldvrRequestsService.getRoadInitial(
				strCustomerId, strAssetNumber, strAssetGroup);

		request.setAttribute(AppConstants.REQ_PARAM_ASSTNUM, strAssetNumber);
		request.setAttribute(AppConstants.ASSET_GROUP_NAME, strAssetGroup);
		request.setAttribute(AppConstants.WS_PARAM_CUSTID, strCustomerId);
		request.setAttribute(AppConstants.LDVR_ROAD_INITIAL, roadInitial);
		
		return new ModelAndView(AppConstants.VIEW_LDVR_MSG_HISTORY);
	}

	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description:
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_MSG_HISTORY_DETAILS, method = RequestMethod.GET)
	@ResponseBody  public LDVRMessageHistoryResponseVO getLDVRMessageHistory(
			final HttpServletRequest request) throws RMDWebException {

		rmdWebLogger.info("Inside getLDVRMessageHistoryDetails method");

		LDVRMessageHistoryRequestVO ldvrMessageHistoryRequestVO = null;
		LDVRMessageHistoryResponseVO ldvrMessageHistoryResponseVO = null;
		String customerId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CUSTOMER_ID));
		String assetNumber = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ASSET_NUMBER));
		String messageType = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.LDVR_MESSAGETYPE));
		String direction = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.LDVR_DIRECTION));
		String status =EsapiUtil.stripXSSCharacters( request.getParameter(AppConstants.LDVR_STATUS));
		String timeRange = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.LDVR_TIMERANGE));
		String device = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.LDVR_DEVICE));
		String roadInitial = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.ROAD_INITIAL));		
		List<LDVRMessageVO> ldvrMessageVOLst = new ArrayList<LDVRMessageVO>();
		SimpleDateFormat formatter = new SimpleDateFormat(RMDCommonConstants.DateConstants.yyyyMMddHHmmss);
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String defaultTimezone = (String) request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		List<String> messageIDLst = new ArrayList<String>();
		try {
			String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,	userVO.getTimeZone());
			
			ldvrMessageHistoryRequestVO = new LDVRMessageHistoryRequestVO();

			ldvrMessageHistoryRequestVO
					.setApplicationId(RMDCommonConstants.LDVR_MCS_APPLICATION_ID);

			if (!RMDCommonUtility.isNullOrEmpty(messageType)) {
				messageIDLst.add(ldvrRequestController.getLDVRMessageID(messageType));
			} else {
				String[] messageTypeArr = AppConstants.LDVR_MESSAGE_TYPE_VALUES
						.split(",");

				if (messageTypeArr != null && messageTypeArr.length > 0) {					
					for (int i = 0; i < messageTypeArr.length; i++) {
						messageIDLst.add(ldvrRequestController
								.getLDVRMessageID(messageTypeArr[i]));
					}
				}
			}
			ldvrMessageHistoryRequestVO.setMessageDirection(direction);
			ldvrMessageHistoryRequestVO.setMessageStatus(status);
			ldvrMessageHistoryRequestVO.setMessageId(messageIDLst);
			if(RMDCommonUtility.isNullOrEmpty(timeRange)){
				timeRange = AppConstants.LDVR_TIMERANGE_DEFAULT;
			}			
			Calendar cal = Calendar.getInstance();
			cal.add(Calendar.DATE, -Integer.parseInt(timeRange));			
			String fromDate = formatter.format(cal.getTime());
	    
			String toDate = formatter.format(new Date());
			
			ldvrMessageHistoryRequestVO.setDateTimeTo(toDate);
			ldvrMessageHistoryRequestVO.setDateTimeFrom(fromDate);
			
			LDVRAssetCriteriaVO ldvrAssetCriteriaVO = new LDVRAssetCriteriaVO();
			ldvrAssetCriteriaVO.setAssetOwnerId(customerId);
			ldvrAssetCriteriaVO.setRoadInitial(roadInitial);
			ldvrAssetCriteriaVO.setRoadNumberFrom(assetNumber);
			ldvrAssetCriteriaVO.setRoadNumberTo(assetNumber);
			ldvrAssetCriteriaVO.setDevice(device);
			List<LDVRAssetCriteriaVO> assetCriteriaVOs = new ArrayList<LDVRAssetCriteriaVO>();
			assetCriteriaVOs.add(ldvrAssetCriteriaVO);

			ldvrMessageHistoryRequestVO.setAssetCriteria(assetCriteriaVOs);

			ldvrMessageHistoryResponseVO = ldvrRequestsService
					.getLDVRMessageHistory(ldvrMessageHistoryRequestVO);

			if (ldvrMessageHistoryResponseVO != null) {
				ldvrMessageVOLst = ldvrMessageHistoryResponseVO.getMessages();
				
				if(CollectionUtils.isNotEmpty(ldvrMessageVOLst)){
					for(LDVRMessageVO msgevo : ldvrMessageVOLst) {
						String statusDtTm = msgevo.getStatusDateTime();
						String requestDtTm = msgevo.getRequestDateTime();						
				
						/*sdf.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
						if(!RMDCommonUtility.isNullOrEmpty(statusDtTm)){							
							Date statusDateTimeD = sdf.parse(statusDtTm);
							msgevo.setStatusDateTime(osdf.format(statusDateTimeD.getTime()));				
						}
						if(!RMDCommonUtility.isNullOrEmpty(requestDtTm)){
							Date requestDateTimeD = sdf.parse(requestDtTm);
							msgevo.setRequestDateTime(osdf.format(requestDateTimeD.getTime()));
						}			*/
						if(!RMDCommonUtility.isNullOrEmpty(statusDtTm))
							msgevo.setStatusDateTime(RMDCommonUtility
								.convertDateFormatTimezone(statusDtTm,
										RMDCommonConstants.yyyyMMddHHmmssSSS,
										RMDCommonConstants.ddMMyyyyHHmmss,
										applicationTimezone));
						
						if(!RMDCommonUtility.isNullOrEmpty(requestDtTm))					
							msgevo.setRequestDateTime(RMDCommonUtility
								.convertDateFormatTimezone(requestDtTm,
										RMDCommonConstants.yyyyMMddHHmmssSSS,
										RMDCommonConstants.ddMMyyyyHHmmss,
										applicationTimezone));
						
						
					}
					
				}
				
				ldvrMessageHistoryResponseVO.setMessages(ldvrMessageVOLst);
			}	
			

		} catch (RMDWebException ex) {
			rmdWebLogger.error(
					"RMDWebException occured in getLDVRMessageHistory  method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLDVRMessageHistory  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return ldvrMessageHistoryResponseVO;

	}
	/**
	 * @Author:
	 * @param:HttpServletRequest reques
	 * @return:List<CallLogVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for exporting call log notes to CSV
	 *               Format.
	 */

	@RequestMapping(AppConstants.EXPORT_LDVR_MESSAGE_HISTORY)
	@ResponseBody public void exportLDVRMessageHistory(final HttpServletRequest request,final HttpServletResponse response,final Locale locale)
			throws RMDWebException, Exception {
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;		
		try {			
			LDVRMessageHistoryResponseVO ldvrMessageResVO = getLDVRMessageHistory(request);
			csvContent = convertToCSVMessageHistory(ldvrMessageResVO.getMessages(),locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.LDVR_MESSAGE_HISTORY_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);
			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);
			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
			.error("Exception occured in exportLDVRMessageHistory method ", rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in exportLDVRMessageHistory method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		}
		finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}
		
	}
	/**
	 * @Description:This method is used convert Queue cases into csv format
	 * @return: String
	 * @param:List<QueueCaseVO> queuCasesList, Locale locale
	 */
	private String convertToCSVMessageHistory(List<LDVRMessageVO> ldvrMessagHistoryLst,
			Locale locale)  throws RMDWebException {
		String csvContent = null;
		StringBuilder strBuilderAssetHeader = new StringBuilder();
		try {
			strBuilderAssetHeader.append(appContext.getMessage(
					AppConstants.LDVR_MESSAGE_HISTORY_HEADER, null, locale));
			strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);
			for (LDVRMessageVO ldvrMsgVO : ldvrMessagHistoryLst) {
				strBuilderAssetHeader.append(AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE + ldvrMsgVO.getId()
						+ AppConstants.QUOTE);
						
						strBuilderAssetHeader
						.append(RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE
						+ ldvrMsgVO.getMessageTypeName()
						+ AppConstants.QUOTE);
									
						strBuilderAssetHeader
						.append(RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE
						+ ldvrMsgVO.getDevice()
						+ AppConstants.QUOTE);
						
						
						strBuilderAssetHeader
						.append(RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE
						+ ldvrMsgVO.getMessageDirection()
						+ AppConstants.QUOTE);
						
						
						strBuilderAssetHeader
						.append(RMDCommonConstants.COMMMA_SEPARATOR
						+ AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE
						+ ldvrMsgVO.getRequestor()
						+ AppConstants.QUOTE
						+ AppConstants.EMPTY_SPACE);
							
				
						strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ ldvrMsgVO.getRequestDateTime()
									+ AppConstants.QUOTE);
			
					
						strBuilderAssetHeader
						.append(RMDCommonConstants.COMMMA_SEPARATOR
								+ AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+ ldvrMsgVO.getMessageStatus()
								+ AppConstants.QUOTE);
					
						
						if (null != ldvrMsgVO.getAppRetryCount()) {		
							strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ ldvrMsgVO.getAppRetryCount()
											+ AppConstants.QUOTE);		
						} else {
							strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ AppConstants.QUOTE);
						}
						
						strBuilderAssetHeader
						.append(RMDCommonConstants.COMMMA_SEPARATOR
								+ AppConstants.QUOTE
								+ AppConstants.EMPTY_SPACE
								+ ldvrMsgVO.getStatusDateTime()
								+ AppConstants.QUOTE);
											
						if (null != ldvrMsgVO.getTemplateNumber()) {		
							strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ ldvrMsgVO.getTemplateNumber()
											+ AppConstants.QUOTE);		
						} else {
							strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ AppConstants.QUOTE);
						}
						if (null != ldvrMsgVO.getTemplateVersion()) {		
							strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ ldvrMsgVO.getTemplateVersion()
											+ AppConstants.QUOTE);		
						} else {
							strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ AppConstants.QUOTE);
						}
						
						if (null != ldvrMsgVO.getMessageOutId()) {		
							strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ ldvrMsgVO.getMessageOutId()
											+ AppConstants.QUOTE);		
						} else {
							strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ AppConstants.QUOTE);
						}			
						
						if (null != ldvrMsgVO.getOriginalMsgId()) {		
							strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ ldvrMsgVO.getOriginalMsgId()
											+ AppConstants.QUOTE);		
						} else {
							strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ AppConstants.QUOTE);
						}
						if (null != ldvrMsgVO.getOmrStatus()) {		
							strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ ldvrMsgVO.getOmrStatus()
											+ AppConstants.QUOTE);		
						} else {
							strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ AppConstants.QUOTE);
						}
						if (null != ldvrMsgVO.getDestination()) {		
							strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ ldvrMsgVO.getDestination()
											+ AppConstants.QUOTE);		
						} else {
							strBuilderAssetHeader
									.append(RMDCommonConstants.COMMMA_SEPARATOR
											+ AppConstants.QUOTE
											+ AppConstants.EMPTY_SPACE
											+ AppConstants.QUOTE);
						}					

				strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBuilderAssetHeader.toString();
		} catch (Exception exception) {
			rmdWebLogger.error("Export to CSV LDVR Message history List"
					+ exception.getMessage());
			RMDWebErrorHandler.handleException(exception);
		}
		return csvContent;
	}

	@RequestMapping(value = AppConstants.GET_LCV_MESSATE_HISTORY_DROPDOWN, method = RequestMethod.GET)
	@ResponseBody public Map<String, String> getLcvMsgHistoryData()	throws Exception {
		Map<String, String> ddDropdownVal = null;
		try {
			final Map<String, String> listName = new LinkedHashMap<String, String>();
			listName.put(AppConstants.LIST_NAME,
					AppConstants.LDVR_MESSAGE_TYPE_VALUES_DROPDOWN);
			ddDropdownVal = objAssetDataScreenService.getDDDropdown(listName);
			return ddDropdownVal;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLcvMsgHistoryData method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return ddDropdownVal;
	}
}
