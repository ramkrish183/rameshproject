package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.valueobjects.AssetSearchVO;
import com.ge.trans.rmd.cm.valueobjects.CaseTypeBean;
import com.ge.trans.rmd.cm.valueobjects.CreateCasesVO;
import com.ge.trans.rmd.cm.valueobjects.UnitShipDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.ViewLogVO;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.beans.CaseSolutionVO;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.beans.SolutionBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.pp.beans.AssetBean;

public interface CreateCasesService {

	/**
	 * This is the method used for fetching the getRxStatus values through
	 * jquery call
	 * 
	 * @param
	 * @return list of string
	 * @throws
	 */
	//public Map<String, String> getSolStatus() throws RMDWebException;

	/**
	 * This is the method used for fetching the getRxType values through jquery
	 * call
	 * 
	 * @param
	 * @return list of string
	 * @throws
	 */
	public Map<String, String> getSolEstRepairTime() throws RMDWebException;

	/**
	 * This is the method used for fetching the Urgency Of Repair values through
	 * jquery call
	 * 
	 * @param
	 * @return list of string
	 * @throws
	 */
	public Map<String, String> getSolUrgencyOfRepair() throws RMDWebException;
	/**
	 * @param string 
	 * This is the method used for fetching the model type values through
	 * jquery call
	 * 
	 * @param
	 * @return list of string
	 * @throws
	 */
	public Map<String, String> getSolModelType(String string) throws RMDWebException;
	/**
	 * This is the method used for fetching the Select by values through
	 * jquery call
	 * 
	 * @param
	 * @return list of string
	 * @throws
	 */
	public Map<String, String> getSolSelectBy() throws RMDWebException;
	/**
	 * This is the method used for fetching the condition values through
	 * jquery call
	 * 
	 * @param
	 * @return list of string
	 * @throws
	 */
	public Map<String, String> getSolCondition() throws RMDWebException;


	/**
	 * This is the method used for fetching the values based on search criteria
	 * through jquery ajax
	 * 
	 * 
	 * @param
	 * @return List<RxVO>
	 * @throws
	 */
	public List<CreateCasesVO> getSolSearchResults(SolutionBean objSolBean,
			String isDeafultLoad) throws RMDWebException;

	public String createCases(final CaseBean caseBean) throws RMDWebException,
			Exception;

	public List<String> getSolTitles(String strRxTitles) throws RMDWebException;

	public List<String> getAssets(AssetBean assetBean) throws RMDWebException,
			Exception;
	public List<AssetBean> getAssetDetails(AssetBean assetBean) throws RMDWebException,
	Exception;

	public Map<String, String> getCustomers() throws RMDWebException,Exception;

	public List<String> getAssetGroups(String customerId)
			throws RMDWebException, Exception;

	public String deliverSolution(SolutionBean solutionBean, CaseBean caseBean)
			throws RMDWebException, Exception;

	String addNotes(NotesBean notesBean) throws RMDWebException, Exception;

	/**
	 * This is the method used for creating a bean through jquery ajax
	 * 
	 * 
	 * @param CaseSolutionVO
	 * @return String
	 * @throws
	 *//*
	public List<CaseSolutionVO> massApplyRx(CaseSolutionVO caseBeanMassApply)
			throws RMDWebException, Exception;*/
	/**
	 * This is the method used for fetching the case type list for validation 
	 * 
	 * 
	 * @param 
	 * @return list of String
	 * @throws
	 */
	public List<String> getCaseTypeForValidation() throws RMDWebException, Exception;

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the list of all Models.
	 */
	
	public Map<String,String> getAllModels() throws RMDWebException;
	
	/**
	 * @Author:
	 * @param customerId
	 * @return:Map<String, String>
	 * @throws RMDWebException
	 * @Description: This method is used for fetching the list of all fleets
	 *               based upon CustomerId.
	 */
	public Map<String, String> getFleets(final String customerId)throws RMDWebException;

	
	/**
	 * @Author:
	 * @param customerName
	 * @return:Map<String, String>
	 * @throws RMDWebException
	 * @Description: This method is used for fetching the list of all Road
	 *               Initials based upon CustomerId.
	 */
	
	public Map<String, String> getRoadNumberHeaders(final String customerId)throws RMDWebException;

	/**
	 * @Author:
	 * @param :
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used to checking foe maximum numbers of
	 *               units on which mass apply rx can be applied.
	 */
	public String getMaxMassApplyUnits() throws RMDWebException;
	
	/**
	 * @Author:
	 * @param :
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching Case Types based Upon the
	 *               Urgency value.
	 */
	public 	List<CaseTypeBean> getCaseTypeValues(String urgency) throws RMDWebException;

	/**
	 * @Author:
	 * @param :
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching Solution SelectBy for Mass
	 *               Apply Rx.
	 */
	public Map<String, String> getMassApplySolSelectBy()throws RMDWebException;
	

	/**
	 * @Author:
	 * @param :AssetDetailsVO
	 * @return:List<String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the list of assets based
	 *               upon user selection.
	 */
	public List<String> getAssetList(AssetSearchVO objAssetDetailsVO)throws RMDWebException;
	
	/**
	 * @Author:
	 * @param :AssetDetailsVO
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the list of assets and associated model based
	 *               upon user selection.
	 */
	public Map<String,String> getAssetModelList(AssetSearchVO objAssetDetailsVO)throws RMDWebException;

	/**
	 * @Author:
	 * @param :CreateCaseVO
	 * @return:List<ViewLogVO>
	 * @throws:RMDWebException
	 * @Description:This Method is used for creating cases and delivering
	 *                   recommendations for range of assets selected by the
	 *                   user.
	 */
	
	public List<ViewLogVO> massApplyRx(CreateCasesVO objCreateCasesVO,String timeZone)throws RMDWebException;
	
	/**
	 * @Author
	 * @param
	 * @return list of string
	 * @throws:RMDWebException
	 * @Description:This is the method used for fetching the Urgency Of Repair
	 *                   values.
	 * 
	 */
	public Map<String, String> getMassApplySolUrgencyOfRepair() throws RMDWebException;

	/**
	 * @author
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used for getting solutions status values from
	 *              lookup table
	 */

	public String getSolutionStatus() throws RMDWebException;

	/**
	 * @author
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used for getting solutions type values from
	 *              lookup table
	 */

	public String getSolutionType() throws RMDWebException;
	
	/**
	 * @author
	 * @param AssetSearchVO
	 * @return AssetBean
	 * @throws RMDWebException
	 * @Description This method is for fetching asset info.
	 */
	public AssetBean getAssetInfo(AssetSearchVO objAssetSearchVO)
			throws RMDWebException;

	/**
	 * @Author:Vamsee
	 * @param :UnitShipDetailsVO
	 * @return :String
	 * @throws RMDWebException
	 * @Description:This method is used for Checking whether unit is Shipped or
	 *                   not.
	 * 
	 */
	
	public String checkForUnitShipDetails(UnitShipDetailsVO objUnitShipDetailsVO)
			throws RMDWebException;
	
	/**
	 * @Author:Mohamed
	 * @param :AssetDetailsVO
	 * @return:List<String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the list of assets which are not shipped based
	 *               upon user selection.
	 */
	public String fetchNotShippedeAssetDetails(AssetSearchVO objAssetDetailsVO)throws RMDWebException;
	public Map<String,String> getModelByFilter(String customer,String fleet,String rnh,String assetList )throws RMDWebException;
}
