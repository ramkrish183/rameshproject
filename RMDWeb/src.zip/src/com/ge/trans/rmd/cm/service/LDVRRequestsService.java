package com.ge.trans.rmd.cm.service;

import com.ge.trans.rmd.cm.valueobjects.ActivePreservationDataRequestVO;
import com.ge.trans.rmd.cm.valueobjects.ActivePreservationDataResponseVO;
import com.ge.trans.rmd.cm.valueobjects.CameraDetailsRequestVO;
import com.ge.trans.rmd.cm.valueobjects.CameraDetailsResponseVO;
import com.ge.trans.rmd.cm.valueobjects.CheckActiveLDVRPreservationRequestVO;
import com.ge.trans.rmd.cm.valueobjects.CheckActiveLDVRPreservationResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRMessageHistoryRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRMessageHistoryResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRRequestVO;
import com.ge.trans.rmd.cm.valueobjects.RemoveTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.RemoveTemplateResponseVO;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface LDVRRequestsService {

	public String submitLDVRRequest(LDVRRequestVO ldvrRequestVO)
			throws RMDWebException, Exception;;

	public CameraDetailsResponseVO getLDVRCameraDetails(
			CameraDetailsRequestVO cameraDetailsRequestVO)
			throws RMDWebException, Exception;

	public CheckActiveLDVRPreservationResponseVO checkActiveLDVRPreservationRequests(
			CheckActiveLDVRPreservationRequestVO checkActiveLDVRPreservationRequestVO)
			throws RMDWebException, Exception;

	public ActivePreservationDataResponseVO getActivePreservationData(
			ActivePreservationDataRequestVO activePreservationDataRequestVO)
			throws RMDWebException, Exception;

	public RemoveTemplateResponseVO removeTemplate(
			RemoveTemplateRequestVO removeTemplateRequestVO)
			throws RMDWebException, Exception;

	public String getRoadInitial(String strCustomerId, String strAssetId,
			String strGrpName) throws RMDWebException;

	public LDVRMessageHistoryResponseVO getLDVRMessageHistory(
			LDVRMessageHistoryRequestVO ldvrMessageHistoryRequestVO)
			throws RMDWebException, Exception;

	public boolean getLDVRAssetSnapshotList(LDVRRequestVO ldvrRequestVO)
			throws RMDWebException, Exception;
	
	public String getLookupValueForError(String errorCode, String errorMsg)
			throws RMDWebException, Exception;
	
}