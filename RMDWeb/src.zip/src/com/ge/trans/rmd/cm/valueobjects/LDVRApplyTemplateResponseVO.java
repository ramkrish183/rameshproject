/**
 * 
 */

package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

public class LDVRApplyTemplateResponseVO {
	
	private List<TemplatesVO> templates;
	private List<MessageStatusVO> messageStatus;
	private List<ExcludedAssetsVO> excludedAssets;
	private List<ApplyTemplatesVO> applyTemplates;
	private List<SkipTemplatesVO> skipTemplates;	

	/**
	 * @return the messageStatus
	 */
	public List<MessageStatusVO> getMessageStatus() {
		return messageStatus;
	}

	/**
	 * @param messageStatus the messageStatus to set
	 */
	public void setMessageStatus(List<MessageStatusVO> messageStatus) {
		this.messageStatus = messageStatus;
	}

	/**
	 * @return the excludedAssets
	 */
	public List<ExcludedAssetsVO> getExcludedAssets() {
		return excludedAssets;
	}

	/**
	 * @param excludedAssets the excludedAssets to set
	 */
	public void setExcludedAssets(List<ExcludedAssetsVO> excludedAssets) {
		this.excludedAssets = excludedAssets;
	}

	/**
	 * @return the templates
	 */
	public List<TemplatesVO> getTemplates() {
		return templates;
	}

	/**
	 * @param templates the templates to set
	 */
	public void setTemplates(List<TemplatesVO> templates) {
		this.templates = templates;
	}

	/**
	 * @return the applyTemplates
	 */
	public List<ApplyTemplatesVO> getApplyTemplates() {
		return applyTemplates;
	}

	/**
	 * @param applyTemplates the applyTemplates to set
	 */
	public void setApplyTemplates(List<ApplyTemplatesVO> applyTemplates) {
		this.applyTemplates = applyTemplates;
	}

	/**
	 * @return the skipTemplates
	 */
	public List<SkipTemplatesVO> getSkipTemplates() {
		return skipTemplates;
	}

	/**
	 * @param skipTemplates the skipTemplates to set
	 */
	public void setSkipTemplates(List<SkipTemplatesVO> skipTemplates) {
		this.skipTemplates = skipTemplates;
	}
}
