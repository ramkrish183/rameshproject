package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ge.trans.rmd.cm.valueobjects.FaultCodeVO;
import com.ge.trans.rmd.cm.valueobjects.FaultServiceStrategyVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;

public interface FaultServiceStrategyService {

	/**
	 * @author
	 * @param AssetSearchVO
	 * @return AssetBean
	 * @throws RMDWebException
	 * @Description This method is for fetching DiagnosticWeight info.
	 */
	public List<String> getDiagnosticWeight() throws RMDWebException;
	/**
	 * @author
	 * @param AssetSearchVO
	 * @return AssetBean
	 * @throws RMDWebException
	 * @Description This method is for fetching SubSysWeight info.
	 */
	public  List<String> getSubSysWeight() throws RMDWebException;
	/**
	 * @author
	 * @param AssetSearchVO
	 * @return AssetBean
	 * @throws RMDWebException
	 * @Description This method is for fetching ModeRestriction info.
	 */
	public Map<String, String> getModeRestriction() throws RMDWebException;
	/**
	 * @author
	 * @param AssetSearchVO
	 * @return AssetBean
	 * @throws RMDWebException
	 * @Description This method is for fetching FaultClassification info.
	 */
	public Map<String, String> getFaultClassification() throws RMDWebException;
	/**
	 * @author
	 * @param AssetSearchVO
	 * @return AssetBean
	 * @throws RMDWebException
	 * @Description This method is for fetching CriticalFlag info.
	 */
	public Map<String, String> getCriticalFlag() throws RMDWebException;
	/**
	 * @author
	 * @param AssetSearchVO
	 * @return AssetBean
	 * @throws RMDWebException
	 * @Description This method is for fetching CriticalFlag info.
	 */
	public FaultServiceStrategyVO getFaultStrategyDetails(String fsObjId,String timezone) throws RMDWebException;
	/**
	 * @author
	 * @param faultCode
	 * @return List<FaultServiceStrategyVO>
	 * @throws RMDWebException
	 * @Description This method is for fetching CriticalFlag info.
	 */
	public List<FaultServiceStrategyVO>getRuleDesc(String faultCode) throws RMDWebException;
	/**
	 * @author
	 * @param FaultServiceStrategyVO
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is for updating FaultStrategy Details.
	 */
	public String updateFaultServiceStrategy(FaultServiceStrategyVO objFaultServiceStrategyVO) throws RMDWebException;

	
	
	/**
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description This method is used to fetch Fault Origin values to populate
	 *              Fault Origin Drop down.
	 * 
	 */
	public Map<String,String> getFaultOrigin() throws RMDWebException;

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description This method is used to fetch Fault Code SubId's to populate
	 *              Fault SubId Drop down.
	 * 
	 */

	public Map<String,String> getFaultCodeSubId(String faultCode, String faultOrigin)
			throws RMDWebException;

	/**
	 * 
	 * @param
	 * @return List<FaultCodeVO>
	 * @throws RMDWebException
	 * @Description This method is used to get Fault Code based upon Search
	 *              Criteria.
	 */

	public List<String> getViewFSSFaultCode(String faultCode,
			String faultOrigin) throws RMDWebException;

	/**
	 * 
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used to get Fault Code ObjId
	 */
	public String getFaultStrategyObjId(String faultCode, String faultOrigin,
			String faultCodeSubId) throws RMDWebException;

}
