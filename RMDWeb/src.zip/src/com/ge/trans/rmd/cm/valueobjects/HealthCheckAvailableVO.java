package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

public class HealthCheckAvailableVO {
	private List<String> platform;
	private String defaultPlatform;
	private String hcEnabled;
	private String isInternal;
	private String hasRevampedPrivilege;
	public String getHasRevampedPrivilege() {
		return hasRevampedPrivilege;
	}
	public void setHasRevampedPrivilege(String hasNotificationPrivilege) {
		this.hasRevampedPrivilege = hasNotificationPrivilege;
	}
	private String device;
	public String getDevice() {
		return device;
	}
	public void setDevice(String device) {
		this.device = device;
	}
	/**
	 * @return the platform
	 */
	public List<String> getPlatform() {
		return platform;
	}
	/**
	 * @param platform the platform to set
	 */
	public void setPlatform(List<String> platform) {
		this.platform = platform;
	}
	/**
	 * @return the defaultPlatform
	 */
	public String getDefaultPlatform() {
		return defaultPlatform;
	}
	/**
	 * @param defaultPlatform the defaultValue to set
	 */
	public void setDefaultPlatform(String defaultPlatform) {
		this.defaultPlatform = defaultPlatform;
	}
	/**
	 * @return the hcEnabled
	 */
	public String getHcEnabled() {
		return hcEnabled;
	}
	/**
	 * @param hcEnabled the hcEnabled to set
	 */
	public void setHcEnabled(String hcEnabled) {
		this.hcEnabled = hcEnabled;
	}
	/**
	 * @return the isInternal
	 */
	public String getIsInternal() {
		return isInternal;
	}
	/**
	 * @param isInternal the isInternal to set
	 */
	public void setIsInternal(String isInternal) {
		this.isInternal = isInternal;
	}
}
