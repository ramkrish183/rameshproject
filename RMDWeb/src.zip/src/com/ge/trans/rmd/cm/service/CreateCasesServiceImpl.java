package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.AssetSearchVO;
import com.ge.trans.rmd.cm.valueobjects.CaseTypeBean;
import com.ge.trans.rmd.cm.valueobjects.CreateCasesVO;
import com.ge.trans.rmd.cm.valueobjects.RecommDelvDocVO;
import com.ge.trans.rmd.cm.valueobjects.UnitShipDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.ViewLogVO;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.beans.SolutionBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.AppSecUtil;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.km.util.KMConstants;
import com.ge.trans.rmd.pp.beans.AssetBean;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetNumberResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetsRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.Customer;
import com.ge.trans.rmd.services.assets.valueobjects.Fleet;
import com.ge.trans.rmd.services.assets.valueobjects.Model;
import com.ge.trans.rmd.services.cases.valueobjects.AssetHeaderResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseSolutionRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.RxDelvDocType;
import com.ge.trans.rmd.services.cases.valueobjects.UnitShipDetailsRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.ViewLogReponseType;
import com.ge.trans.rmd.services.notes.valueobjects.NotesInfo;
import com.ge.trans.rmd.services.notes.valueobjects.NotesRequestType;
import com.ge.trans.rmd.services.solutions.valueobjects.SolutionDetailType;
import com.ge.trans.rmd.services.solutions.valueobjects.SolutionResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class CreateCasesServiceImpl extends RMDBaseServiceImpl implements
		CreateCasesService {
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	WebServiceInvoker webServiceInvoker;

	@Autowired
	private AssetOverviewService assetOverviewService;
	
	
	static Map sortByValue(Map map) {
	     List list = new LinkedList(map.entrySet());
	     Collections.sort(list, new Comparator() {
	          public int compare(Object o1, Object o2) {
	               return ((Comparable) ((Map.Entry) (o1)).getValue())
	              .compareTo(((Map.Entry) (o2)).getValue());
	          }
	     });

	    Map result = new LinkedHashMap();
	    for (Iterator it = list.iterator(); it.hasNext();) {
	        Map.Entry entry = (Map.Entry)it.next();
	        result.put(entry.getKey(), entry.getValue());
	    }
	    return result;
	} 
	/**
	 * This is the method used for fetching the Urgency of Repair values through
	 * jquery call
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */
	public Map<String, String> getSolUrgencyOfRepair() throws RMDWebException {
		rmdWebLogger
				.debug("Inside CreateCasesServiceImpl in getSolUrgencyOfRepair Method");

		Map<String, String> urgencyRepairMap = new HashMap<String, String>();
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.CREATCASE_URGOFREPAIR);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					String urgency = applParamResponseType[i].getLookupValue();
					urgencyRepairMap.put(urgency, urgency);
				}
				urgencyRepairMap.remove(AppConstants.SPECIFY);
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getSolUrgencyOfRepair method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return sortByValue(urgencyRepairMap);
	}

	/**
	 * This is the method used for fetching the Estimated Repair Time values
	 * through jquery call
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */
	public Map<String, String> getSolEstRepairTime() throws RMDWebException {
		rmdWebLogger
				.debug("Inside CreateCasesServiceImpl in getSolEstRepairTime Method");

		Map<String, String> estRepairTimeMap = new HashMap<String, String>();
		String estRepairTimeName = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.CREATCASE_ESTTIMEREPAIR);
			
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					estRepairTimeName = applParamResponseType[i]
							.getLookupValue();
					estRepairTimeMap.put(estRepairTimeName, estRepairTimeName);
				}
				estRepairTimeMap.remove(AppConstants.SPECIFY);
			}
		}catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getSolEstRepairTime method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return sortByValue(estRepairTimeMap);
	}

	/**
	 * This is the method used for fetching the values based on search criteria
	 * through jquery ajax
	 * 
	 * 
	 * @param
	 * @return List<RxVO>
	 * @throws
	 */
	@Override
	public List<CreateCasesVO> getSolSearchResults(SolutionBean objSolBean,
			String isDeafultLoad) throws RMDWebException {
		rmdWebLogger
				.debug("Inside CreateCasesServiceImpl in getSolSearchResults Method");

		CreateCasesVO objCreateCaseVO;
		List<CreateCasesVO> arlRxDetails = new ArrayList<CreateCasesVO>();

		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		try {

			queryParamMap.put(KMConstants.IS_DEFAULT_LOAD, isDeafultLoad);

			if (null != objSolBean) {

				if (null != objSolBean.getSolutionTitle()
						&& !RMDCommonConstants.EMPTY_STRING
								.equalsIgnoreCase(objSolBean.getSolutionTitle())) {
					queryParamMap.put(RMDCommonConstants.SOLUTION_TITLE,
							objSolBean.getSolutionTitle());

				}

				if (!RMDCommonUtility.isNull((RMDCommonUtil
						.convertArrayToString(objSolBean
								.getSolUrgencyOfRepair())))
						&& RMDCommonUtility.isCollectionNotEmpty(objSolBean
								.getSolUrgencyOfRepair())
						&& !RMDCommonConstants.ALL
								.equalsIgnoreCase(RMDCommonUtil
										.convertArrayToString(objSolBean
												.getSolUrgencyOfRepair()))) {
					queryParamMap.put(AppConstants.CREATCASE_WSPARAM_URGENCY,
							RMDCommonUtil.convertArrayToString(objSolBean
									.getSolUrgencyOfRepair()));

				}
				//
				if (null != objSolBean.getSolutionStatus()
						&& !RMDCommonUtility.isNull(objSolBean
								.getSolutionStatus())) {

					queryParamMap.put(RMDCommonConstants.SOLUTION_STATUS,
							objSolBean.getSolutionStatus());

				}
				if (null != objSolBean.getSolEstRepairTime()
						&& !RMDCommonUtility.isNull(objSolBean
								.getSolEstRepairTime())
						&& !RMDCommonConstants.ALL.equalsIgnoreCase(objSolBean
								.getSolEstRepairTime())) {
					queryParamMap.put(AppConstants.CREATCASE_WSPARAM_ESTREPAIR,
							objSolBean.getSolEstRepairTime());
				}
				if (null != objSolBean.getSolCondition()
						&& !AppConstants.EMPTY_STRING.equals(objSolBean
								.getSolCondition())) {
					queryParamMap.put(AppConstants.CREATCASE_WSPARAM_CONDITION,
							objSolBean.getSolCondition());
				} else {
					queryParamMap.put(AppConstants.CREATCASE_WSPARAM_CONDITION,
							RMDCommonConstants.CONTAINS);
				}
				if (null != objSolBean.getSolSelectBy()
						&& !RMDCommonUtility
								.isNull(objSolBean.getSolSelectBy())) {
					queryParamMap.put(AppConstants.CREATCASE_WSPARAM_SELECTBY,
							objSolBean.getSolSelectBy());
				}
				if (null != objSolBean.getSolModelType()
						&& !RMDCommonUtility.isNull(objSolBean
								.getSolModelType())
						&& !RMDCommonConstants.ALL.equalsIgnoreCase(objSolBean
								.getSolModelType())) {
					queryParamMap.put(AppConstants.CREATCASE_WSPARAM_MODELTYPE,
							objSolBean.getSolModelType());
				}
				if (null != objSolBean.getSolutionType()
						&& !RMDCommonUtility.isNull(objSolBean
								.getSolutionType())) {
					queryParamMap.put(
							AppConstants.CREATCASE_WSPARAM_SOLUTIONTYPE,
							objSolBean.getSolutionType());
				}
				if (null != objSolBean.getSolValue()
						&& !RMDCommonUtility.isNull(objSolBean.getSolValue())) {
					queryParamMap.put(AppConstants.CREATCASE_WSPARAM_VALUE,
							AppSecUtil.htmlEscaping(objSolBean.getSolValue()));
				}
				
				if (null != objSolBean.getSolSubSystem()
						&& !AppConstants.EMPTY_STRING.equals(objSolBean
								.getSolSubSystem())) {
					queryParamMap.put(AppConstants.GET_RX_SUB_SYSTEM,
							objSolBean.getSolSubSystem());
				}
				if (null != objSolBean.getModel()
						&& !AppConstants.EMPTY_STRING.equals(objSolBean
								.getModel())) {
					queryParamMap
							.put(AppConstants.MODEL, objSolBean.getModel());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objSolBean
						.getIsMassApplyRx())) {
					queryParamMap
							.put(AppConstants.IS_MASS_APPLY_RX, objSolBean.getIsMassApplyRx());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objSolBean
						.getAddRxApply())) {
					queryParamMap
							.put(AppConstants.ADD_RX_APPLY, objSolBean.getAddRxApply());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objSolBean
                        .getCustomer())) {
                    queryParamMap
                            .put(AppConstants.CUSTOMER, objSolBean.getCustomer());
                }
				if (!RMDCommonUtility.isNullOrEmpty(objSolBean
                        .getFromRN())) {
                    queryParamMap
                            .put(AppConstants.FROM_RN, objSolBean.getFromRN());
                }
				if (!RMDCommonUtility.isNullOrEmpty(objSolBean
                        .getToRN())) {
                    queryParamMap
                            .put(AppConstants.TO_RN, objSolBean.getToRN());
                }
				if (!RMDCommonUtility.isNullOrEmpty(objSolBean
                        .getRnh())) {
                    queryParamMap
                            .put(AppConstants.RNH, objSolBean.getRnh());
                }
				if (!RMDCommonUtility.isNullOrEmpty(objSolBean
                        .getFleet())) {
                    queryParamMap
                            .put(AppConstants.FLEET, objSolBean.getFleet());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objSolBean
                        .getAssets())) {
                    queryParamMap
                            .put(AppConstants.ASSET_LIST, objSolBean.getAssets());
                }
			}
			queryParamMap.put(AppConstants.CREATE_CASE_BLNDELVFLAG,
					AppConstants.LETTER_Y);
			SolutionResponseType[] objSolutionResponseType = (SolutionResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_RECOMMS, null, queryParamMap,
							null, SolutionResponseType[].class);

			for (int i = 0; i < objSolutionResponseType.length; i++) {
				objCreateCaseVO = new CreateCasesVO();

				if (null != objSolutionResponseType[i].getSolutionDetail()
						.getSolutionTitle()
						&& !objSolutionResponseType[i].getSolutionDetail()
								.getSolutionTitle().isEmpty()) {
					objCreateCaseVO.setSolutionTitle(objSolutionResponseType[i]
							.getSolutionDetail().getSolutionTitle());
				} else {
					objCreateCaseVO
							.setSolutionTitle(RMDCommonConstants.EMPTY_STRING);
				}
				if (null != objSolutionResponseType[i].getSolutionDetail()
						.getSolutionID()
						&& !objSolutionResponseType[i].getSolutionDetail()
								.getSolutionID().isEmpty()) {
					objCreateCaseVO.setSolutionID(objSolutionResponseType[i]
							.getSolutionDetail().getSolutionID());
				} else {
					objCreateCaseVO
							.setSolutionID(RMDCommonConstants.EMPTY_STRING);
				}
				if (null != objSolutionResponseType[i].getSolutionDetail()
						.getUrgRepair()
						&& !objSolutionResponseType[i].getSolutionDetail()
								.getUrgRepair().isEmpty()) {
					objCreateCaseVO.setUrgRepair(objSolutionResponseType[i]
							.getSolutionDetail().getUrgRepair());
				} else {
					objCreateCaseVO
							.setUrgRepair(RMDCommonConstants.EMPTY_STRING);
				}
				if (null != objSolutionResponseType[i].getSolutionDetail()
						.getEstmTimeRepair()
						&& !objSolutionResponseType[i].getSolutionDetail()
								.getEstmTimeRepair().isEmpty()) {
					objCreateCaseVO
							.setEstmTimeRepair(objSolutionResponseType[i]
									.getSolutionDetail().getEstmTimeRepair());
				} else {
					objCreateCaseVO
							.setEstmTimeRepair(RMDCommonConstants.EMPTY_STRING);
				}
				if (null != objSolutionResponseType[i].getSolutionDetail()
						.getModel()
						&& !objSolutionResponseType[i].getSolutionDetail()
								.getModel().isEmpty()) {
					objCreateCaseVO.setModel((objSolutionResponseType[i]
							.getSolutionDetail().getModel()));
				} else {
					objCreateCaseVO.setModel(RMDCommonConstants.EMPTY_STRING);
				}
				if (null != objSolutionResponseType[i].getSolutionDetail()
						.getVersion()
						&& !objSolutionResponseType[i].getSolutionDetail()
								.getVersion().isEmpty()) {
					objCreateCaseVO.setVersion((objSolutionResponseType[i]
							.getSolutionDetail().getVersion()));
				} else {
					objCreateCaseVO.setVersion(RMDCommonConstants.EMPTY_STRING);
				}
				if (null != objSolutionResponseType[i].getSolutionDetail()
						.getSolutionStatus()
						&& !objSolutionResponseType[i].getSolutionDetail()
								.getSolutionStatus().isEmpty()) {
					objCreateCaseVO.setSolutionStatus((objSolutionResponseType[i]
							.getSolutionDetail().getSolutionStatus()));
				} else {
					objCreateCaseVO.setSolutionStatus(RMDCommonConstants.EMPTY_STRING);
				}

				arlRxDetails.add(objCreateCaseVO);
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getSolSearchResults method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlRxDetails;

	}

	/**
	 * @Author : IgatePatni
	 * @param : notesBean
	 * @return : String
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description: This method invokes the web service to put the information
	 *               of notes of asset number's case.
	 */
	@Override
	public String createCases(final CaseBean caseBean) throws RMDWebException,
			Exception {

		final CaseRequestType casesRequestType = new CaseRequestType();
		String returnStr = AppConstants.FAILURE;
		try {

			// casesInfo.setCaseID(caseBean.getCaseId());
			//Added for create from Tooloutput
			if(caseBean.getRequestfromToolOutput()){
				casesRequestType.setCaseTitle(caseBean.getCaseTitle());
				casesRequestType.setCaseType(AppConstants.CREATCASE_INFORMATIONAL);	//Change to casetype
			}
			
			else
			{
			casesRequestType.setCaseTitle(AppConstants.CREATCASE_FIELDREQ);
			casesRequestType.setCaseType(AppConstants.CREATCASE_INFORMATIONAL);
			}
			
			casesRequestType.setQueueName(AppConstants.CREATCASE_WORK);
			casesRequestType.setPriority(AppConstants.CREATCASE_HIGH);
			casesRequestType.setSolutionTitle(AppConstants.CREATCASE_FIELDREQ);
			casesRequestType.setAssetNumber(caseBean.getAssetNumber());
			casesRequestType.setCustomerId(caseBean.getCustomerId());
			casesRequestType.setAssetGrpName(caseBean.getAssetGrpName());
			casesRequestType.setCustomerName(caseBean.getCustomerId());
			casesRequestType.setUserName(caseBean.getUserId());
			casesRequestType.setUserLanguage(caseBean.getUserLanguage());
			returnStr = (String) webServiceInvoker.post(
					ServiceConstants.CREATE_CASES, casesRequestType,
					String.class);

		} catch (RMDWebException e) {
			rmdWebLogger.error("Exception occured in createCases() method ", e);
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				returnStr = AppConstants.FAILURE;
			} else {
				// throw e;
			}
		} catch (Exception e) {
			rmdWebLogger.error("Exception occured in createCases() method ", e);

			throw e;

		}

		return returnStr;

	}

	/**
	 * This is the method used for fetching the rxTitle values through jquery
	 * call
	 * 
	 * @param strRxTitles
	 * @return list of string
	 * @throws
	 */
	public List<String> getSolTitles(String strRxTitles) throws RMDWebException {
		String localRxTitles =strRxTitles;
		List<String> lstRxTitles = new ArrayList<String>();
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		try {
			if (localRxTitles == null) {
				localRxTitles = RMDCommonConstants.BLANK_SPACE;
			}
			queryParamMap.put(KMConstants.SOLUTION_TITLE, localRxTitles);
			SolutionResponseType[] arraySolutionResponseType = (SolutionResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_SOLUTION_INFORMATION, null,
							queryParamMap, null, SolutionResponseType[].class);

			for (int i = 0; i < arraySolutionResponseType.length; i++) {

				lstRxTitles.add(arraySolutionResponseType[i]
						.getSolutionDetail().getSolutionTitle());
			}
			// To remove the duplicate values in the list and to maintain the
			// order
			lstRxTitles = RMDCommonUtility.removeDuplicateValues(lstRxTitles);
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getSolTitles method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lstRxTitles;
	}

	/**
	 * This method will call web-service to return list of asset numbers for
	 * given keys like customerId, assetGroup and assetnumber
	 */
	@Override
	public List<String> getAssets(AssetBean assetBean) throws RMDWebException,
			Exception {

		AssetResponseType[] assetResponses = null;
		List<String> assetNumbers = new ArrayList<String>();
		final Map<String, String> headerParams = getHeaderMap(assetBean);
		try {
			AssetsRequestType objAssetsReqType=new AssetsRequestType();
			objAssetsReqType.setLanguage(headerParams.get(AppConstants.USER_LANGUAGE));
			objAssetsReqType.setCustomerId(assetBean.getCustomerId());
			objAssetsReqType.setAssetNumberLike(assetBean.getAssetNumber());
			objAssetsReqType.setFleetId(assetBean.getFleetId());
			if(null!=assetBean.getAssetGroup()&&!assetBean.getAssetGroup().equals(RMDCommonConstants.EMPTY_STRING)){
				objAssetsReqType.setAssetGrpName(assetBean.getAssetGroup());
			}
			assetResponses = (AssetResponseType[])webServiceInvoker
					.post(ServiceConstants.GET_ASSETS, objAssetsReqType, AssetResponseType[].class);

			for (int i = 0; i < assetResponses.length; i++) {
				assetNumbers.add(assetResponses[i].getAssetNumber() + "");
			}

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: No records found for getAssets() service "
								+ e.getMessage());
				assetResponses = null;
			} else {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: Exception occured in getAssets() method "
								+ e.getMessage());
				throw e;
			}
		} catch (Exception e) {
			rmdWebLogger.error("Exception occured in getAssets method ", e);
			throw e;
		}
		return assetNumbers;
	}

	/**
	 * This method will call web-service to return list of customers available
	 * is application
	 */
	@Override
public Map<String, String> getCustomers() throws RMDWebException, Exception {

	final Map<String, String> customers=new LinkedHashMap<String,String>();

		try {
			Customer[] customer = (Customer[]) webServiceInvoker.get(
					ServiceConstants.GET_CUSTOMERS, null, null, null,
					Customer[].class);

			for (int i = 0; i < customer.length; i++) {
				customers.put(customer[i].getCustomerID(),customer[i].getCustomerName());
			}

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: No records found for getCustomers() service "
								+ e.getMessage());
			} else {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: Exception occured in getCustomers() method "
								+ e.getMessage());
				throw e;
			}
		}catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCustomers method ", ex);
			RMDWebErrorHandler.handleException(ex);
			
		}

		return customers;
	}

	/**
	 * This method will call web-service to return list of asset groups
	 * available for given customerId
	 */
	@Override
	public List<String> getAssetGroups(String customerId)
			throws RMDWebException, Exception {

		final Map<String, String> pathParamsMap = new HashMap<String, String>();
		List<String> assetGroups = new ArrayList<String>();
		try {
			pathParamsMap.put(AppConstants.CUSTOMER_ID, customerId);
			AssetResponseType[] assetGrps = (AssetResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_ASSET_GROUPS, pathParamsMap,
							null, null, AssetResponseType[].class);

			for (int i = 0; i < assetGrps.length; i++) {
				assetGroups.add(assetGrps[i].getAssetGroupName());
			}

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: No records found for getCustomers() service "
								+ e.getMessage());
				assetGroups = null;
			} else {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: Exception occured in getCustomers() method "
								+ e.getMessage());
				throw e;
			}
		} catch (Exception e) {
			rmdWebLogger.error("Exception occured in getCustomers method ", e);
			throw e;
		}
		Collections.sort(assetGroups);
		return assetGroups;
	}

	/**
	 * This method will call Web-Service to deliver the solution which is user
	 * sent from UI
	 */
	@Override
	public String deliverSolution(final SolutionBean solutionBean,
			final CaseBean caseBean) throws RMDWebException, Exception {

		final Map<String, String> headerParams = getHeaderMap(solutionBean);
		final CaseSolutionRequestType solunReqType = new CaseSolutionRequestType();
		String returnStr = AppConstants.FAILURE;
		try {

			solunReqType.setCaseID(caseBean.getCaseId());
			solunReqType.setSolutionID(solutionBean.getSolutionId());
			solunReqType.setEstmRepTime(solutionBean.getSolEstRepairTime());
			solunReqType.setUrgRepair(solutionBean.getSolUrgencyOfRepair().get(
					0));
			solunReqType.setRecomNotes(solutionBean.getRecomNotes());
			solunReqType.setUserName(caseBean.getUserFirstName());
			solunReqType.setUserLanguage(caseBean.getUserLanguage());
			solunReqType.setUserName(caseBean.getUserId());
			solunReqType.setCustomerId(caseBean.getCustomerId());
			webServiceInvoker.put(ServiceConstants.POST_DELIVER_SOLUTION,
					solunReqType, headerParams);
			returnStr = AppConstants.SUCCESS;
		} catch (RMDWebException e) {
			rmdWebLogger.error("Exception occured in addNotes() method ", e);
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				returnStr = AppConstants.FAILURE;
			} else {
				throw e;
			}
		} catch (Exception e) {
			rmdWebLogger.error("Exception occured in addNotes() method ", e);

			throw e;

		}

		return returnStr;
	}

	/**
	 * @Author : IgatePatni
	 * @param : notes
	 * @param : assetNumber
	 * @param : userName
	 * @return : String
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description: This method invokes the web service to put the information
	 *               of notes of asset number.
	 */
	@Override
	public String addNotes(final NotesBean notesBean) throws RMDWebException,
			Exception {
		final Map<String, String> headerParams = getHeaderMap(notesBean);
		final NotesRequestType notesRequestType = new NotesRequestType();
		final NotesInfo notesInfo = new NotesInfo();
		String returnStr = AppConstants.FAILURE;
		try {

			notesRequestType.setFromPage(AppConstants.MENU);
			notesRequestType.setSticky(AppConstants.NO);
			notesRequestType.setFromAsset(notesBean.getAssetNumber());
			notesRequestType.setToAsset(notesBean.getAssetNumber());
			notesRequestType.setNotes(notesBean.getNoteDescription());
			notesRequestType.setNotesInfo(notesInfo);
			notesRequestType.setAssetGrpName(notesBean.getAssetGroup());
			notesRequestType.setCustomerID(notesBean.getCustomerId());

			webServiceInvoker.put(ServiceConstants.POST_NOTES,
					notesRequestType, headerParams);
			returnStr = AppConstants.SUCCESS;
		} catch (RMDWebException e) {
			rmdWebLogger.error("Exception occured in addNotes() method ", e);
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				returnStr = AppConstants.FAILURE;
			} else {
				throw e;
			}
		} catch (Exception e) {
			rmdWebLogger.error("Exception occured in addNotes() method ", e);

			throw e;

		}

		return returnStr;
	}
	
	/**
	 * This is the method used for fetching the model type values through
	 * jquery call
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */
	@Override
	public Map<String, String> getSolModelType(String customerId)
			throws RMDWebException {
		Map<String, String> modelMap = new TreeMap<String, String>();
		String modelID = null;
		String modelName = null;

		Map<String, String> modelType = new LinkedHashMap<String, String>();

		try {
			if (null == customerId || customerId.equals(AppConstants.EMPTY_STRING))
				customerId = RMDCommonConstants.ALL_CUSTOMER;
			AssetOverviewBean assetBean = new AssetOverviewBean();

			assetBean.setCustomer(customerId);
			modelType = assetOverviewService.getModelsForFilter(assetBean);
			for (Map.Entry<String, String> entry : modelType.entrySet()) {
				modelID = entry.getKey();
				modelName = entry.getValue();
				modelMap.put(modelName, modelName);
			}

		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getSolModelType() method - CreateCasesServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return modelMap;
	}


	/**
	 * This is the method used for fetching the select by values through
	 * jquery call
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */
	@Override
	public Map<String, String> getSolSelectBy() throws RMDWebException {
		Map<String, String> selectByMap = new HashMap<String, String>();
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		try {
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.SELECT_BY_OPTIONS);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			for (int i = 0; i < applParamResponseType.length; i++) {
				String selectBy = applParamResponseType[i].getLookupValue();
				selectByMap.put(selectBy, selectBy);
			}

		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getSolSelectBy() method - CreateCasesServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return selectByMap;
	}
	/**
	 * This is the method used for fetching the condition values through
	 * jquery call
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 */

	@Override
	public Map<String, String> getSolCondition() throws RMDWebException {
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		Map<String, String> conditionMap = new LinkedHashMap<String, String>();
		try {
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.SEARCH_CONDITIONS);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					String condition = applParamResponseType[i]
							.getLookupValue();
					conditionMap.put(condition, condition);
				}
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getSolCondition() method - CreateCasesServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return conditionMap;
	}
/*
	*//**
	 * This is the method used for creating a bean through jquery ajax
	 * 
	 * 
	 * @param CaseSolutionVO
	 * @return String
	 * @throws
	 *//*
	@Override
	public List<CaseSolutionVO> massApplyRx(CaseSolutionVO caseBeanMassApply)
			throws RMDWebException, Exception {
		final MassApplyRXRequestType massApplyRXRequestType = new MassApplyRXRequestType();
		MassApplyRxResponseType[] massApplyRxResponseType = null;
		CaseSolutionVO caseSolutionVO=null;
		List <CaseSolutionVO> massApplyRxResult = new ArrayList<CaseSolutionVO>();
		Map<String,String> headerParams=new HashMap<String,String>();
		try {

			massApplyRXRequestType.setCaseType(caseBeanMassApply.getCaseType());
			massApplyRXRequestType.setAssetNumber(caseBeanMassApply
					.getAssetNumber());
			massApplyRXRequestType.setCustomerId(caseBeanMassApply
					.getCustomerId());
			massApplyRXRequestType.setAssetGrpName(caseBeanMassApply
					.getAssetGrpName());
			headerParams.put(AppConstants.GENERAL_PARAM_USER_ID,caseBeanMassApply.getUserId());
			headerParams.put(AppConstants.LANGUAGE,caseBeanMassApply.getUserLanguage());
			headerParams.put(AppConstants.USER_LANGUAGE,caseBeanMassApply.getUserLanguage());
			massApplyRXRequestType.setUserId(caseBeanMassApply.getUserId());
			massApplyRXRequestType.setSolutionID(caseBeanMassApply
					.getSolutionId());
			massApplyRXRequestType.setCaseTitle(caseBeanMassApply.getCaseTitle());
			massApplyRXRequestType.setPriority(caseBeanMassApply.getPriority());
			massApplyRxResponseType = (MassApplyRxResponseType[]) webServiceInvoker.post(
					ServiceConstants.MASS_APPLY_RX, massApplyRXRequestType,
					MassApplyRxResponseType[].class,headerParams);
			if (null != massApplyRxResponseType) {
				for (int i = 0; i < massApplyRxResponseType.length; i++) {
					caseSolutionVO=new CaseSolutionVO();
					caseSolutionVO.setAssetNumber(massApplyRxResponseType[i].getAssetNumber());
					caseSolutionVO.setCaseId(massApplyRxResponseType[i].getCaseId());
					caseSolutionVO.setRxDelivered(massApplyRxResponseType[i].isRxDelivered());
					caseSolutionVO.setCaseCreationSucess(massApplyRxResponseType[i].isCaseSucess());
					caseSolutionVO.setAssetGrpName(massApplyRxResponseType[i].getAssetGroupName());
					massApplyRxResult.add(caseSolutionVO);
				}
			}
			
		} catch (Exception e) {
			rmdWebLogger.error("Exception occured in massApplyRx() method ", e);
			throw e;

		}

		return massApplyRxResult;
	}*/

	/**
	 * This is the method used for fetching the case type list for validation 
	 * 
	 * 
	 * @param 
	 * @return list of String
	 * @throws
	 */
	@Override
	public List<String> getCaseTypeForValidation() throws RMDWebException,
			Exception {
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		List<String> caseTypeList = new ArrayList<String>();
		try {
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.CASETYPE_VALIDATION);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					String caseType = applParamResponseType[i].getLookupValue();
					caseTypeList.add(caseType);
				}
			}

		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getCaseTypeForValidation() method - CreateCasesServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return caseTypeList;
	}
	
	
	/**
	 * This method will call web-service to return list of asset numbers for
	 * given keys like customerId, assetGroup and assetnumber
	 */
	
	public List<AssetBean> getAssetDetails(AssetBean assetBean) throws RMDWebException,
			Exception {

		AssetResponseType[] assetResponses = null;
		List<AssetBean> lstAssetDetails = new ArrayList<AssetBean>();
		AssetBean objAssetBean=null;
		final Map<String, String> headerParams = getHeaderMap(assetBean);
		try {
			AssetsRequestType objAssetsReqType=new AssetsRequestType();
			objAssetsReqType.setLanguage(headerParams.get(AppConstants.USER_LANGUAGE));
			objAssetsReqType.setCustomerId(assetBean.getCustomerId());
			objAssetsReqType.setAssetNumber(assetBean.getAssetNumber());
			objAssetsReqType.setAssetFrom(assetBean.getFromAssetNumber());
			objAssetsReqType.setAssetTo(assetBean.getToAssetNumber());
			if(null!=assetBean.getAssetGroup()&&!assetBean.getAssetGroup().equals(RMDCommonConstants.EMPTY_STRING)){
				objAssetsReqType.setAssetGrpName(assetBean.getAssetGroup());
			}
			assetResponses = (AssetResponseType[])webServiceInvoker
					.post(ServiceConstants.GET_ASSETS, objAssetsReqType, AssetResponseType[].class);

			for (int i = 0; i < assetResponses.length; i++) {
				objAssetBean=new AssetBean();
				objAssetBean.setAssetGroup(assetResponses[i].getAssetGroupName());
				objAssetBean.setCustomerId(assetResponses[i].getCustomerID());
				objAssetBean.setAssetNumber(assetResponses[i].getAssetNumber());
				lstAssetDetails.add(objAssetBean);
			}

		} catch (RMDWebException e) {
			if (AppConstants.EXCEPTION_EOA_101.equalsIgnoreCase(e.getMessage())) {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: No records found for getAssets() service "
								+ e.getMessage());
				assetResponses = null;
			} else {
				rmdWebLogger
						.error("CreateCaseServiceImpl :: Exception occured in getAssets() method "
								+ e.getMessage());
				throw e;
			}
		} catch (Exception e) {
			rmdWebLogger.error("Exception occured in getAssets method ", e);
			throw e;
		}
		return lstAssetDetails;
	}
	
	/**
	 * @author
	 * @param AssetSearchVO
	 * @return AssetBean
	 * @throws RMDWebException
	 * @Description This method is for fetching asset info.
	 */
	public AssetBean getAssetInfo(AssetSearchVO objAssetSearchVO)
			throws RMDWebException {
		AssetResponseType[] assetResponses = null;
		AssetBean objAssetBean = null;
		try {

			if (!RMDCommonUtility.isNullOrEmpty(objAssetSearchVO
					.getAssetNumber())
					&& !RMDCommonUtility.isNullOrEmpty(objAssetSearchVO
							.getAssetGroupName())
					&& !RMDCommonUtility.isNullOrEmpty(objAssetSearchVO
							.getCustomerId())) {
				AssetsRequestType objAssetsReqType = new AssetsRequestType();
				objAssetsReqType
						.setCustomerId(objAssetSearchVO.getCustomerId());
				objAssetsReqType.setAssetNumber(objAssetSearchVO
						.getAssetNumber());
				objAssetsReqType.setAssetGrpName(objAssetSearchVO
						.getAssetGroupName());
				assetResponses = (AssetResponseType[]) webServiceInvoker.post(
						ServiceConstants.GET_ASSETS, objAssetsReqType,
						AssetResponseType[].class);
				for (int i = 0; i < assetResponses.length; i++) {
					objAssetBean = new AssetBean();
					objAssetBean.setAssetGroup(assetResponses[i]
							.getAssetGroupName());
					objAssetBean.setCustomerId(assetResponses[i]
							.getCustomerID());
					objAssetBean.setAssetNumber(assetResponses[i]
							.getAssetNumber());
					objAssetBean.setModel(assetResponses[i].getModel());
					objAssetBean.setCustomerName(assetResponses[i]
							.getCustomerName());
				}
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getAssetInfo() method - CreateCasesServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return objAssetBean;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the list of all Models.
	 */

	@Override
	public Map<String, String> getAllModels() throws RMDWebException {
		Map<String, String> modelMap = new HashMap<String, String>();
		String modelID = null;
		String modelName = null;
		try {
			Model[] model = (Model[]) webServiceInvoker.get(
					ServiceConstants.GET_MODELS, null, null, null,
					Model[].class);
			for (int i = 0; i < model.length; i++) {
				modelID = model[i].getModelID();
				modelName = model[i].getModelName();
				modelMap.put(modelID, modelName);
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getAllModels() method - CreateCaseServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return modelMap;
	}

	/**
	 * @Author:
	 * @param: String customerId
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the list of all fleets
	 *               based upon customerId.
	 */

	@Override
	public Map<String, String> getFleets(String customerId)
			throws RMDWebException {
		final Map<String, String> fleetMap = new LinkedHashMap<String, String>();
		String fleetsName = null;
		String fleetID = null;
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		try {
			queryParamMap.put(AppConstants.CUSTOMER, customerId);
			final Fleet[] fleet = (Fleet[]) webServiceInvoker.get(
					ServiceConstants.GET_FLEET, null, queryParamMap, null,
					Fleet[].class);
			if (fleet != null) {
				for (int i = 0; i < fleet.length; i++) {
					fleetsName = fleet[i].getFleet();
					fleetID = fleet[i].getFleetID();
					fleetMap.put(fleetID, fleetsName);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getFleets() method - CreateCasesServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return fleetMap;
	}

	/**
	 * @Author:
	 * @param customerName
	 * @return:Map<String, String>
	 * @throws RMDWebException
	 * @Description: This method is used for fetching the list of all Road
	 *               Initials based upon CustomerId.
	 */
	@Override
	public Map<String, String> getRoadNumberHeaders(final String customerId)
			throws RMDWebException {
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		final Map<String, String> roadIntialsMap = new TreeMap<String, String>();
		try {
			queryParamMap.put(AppConstants.CUSTOMER_ID, customerId);
			final AssetHeaderResponseType[] roadIntialsList = (AssetHeaderResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_ROAD_NUMBER_HEADERS, null,
							queryParamMap, null,
							AssetHeaderResponseType[].class);
			for (AssetHeaderResponseType objAssetHeaderResponseType : roadIntialsList) {
				roadIntialsMap.put(
						objAssetHeaderResponseType.getAssetGroupName(),
						objAssetHeaderResponseType.getAssetGroupName());
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getRoadNumberHeaders() method - CreateCasesServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return roadIntialsMap;
	}

	/**
	 * @Author:
	 * @param :
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used to checking foe maximum numbers of
	 *               units on which mass apply rx can be applied.
	 */
	@Override
	public String getMaxMassApplyUnits() throws RMDWebException {
		String result = null;
		try {
			result = (String) webServiceInvoker.get(
					ServiceConstants.GET_MAX_MASS_APPLY_UNITS, null, null,
					null, String.class);
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getMaxMassApplyUnits() method - CreateCasesServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @Author:
	 * @param :
	 * @return:List<CaseTypeBean>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching Case Types based Upon the
	 *               Urgency value.
	 */

	@Override
	public List<CaseTypeBean> getCaseTypeValues(String urgency)
			throws RMDWebException {
		List<CaseTypeBean> arlCaseTypeBeans = new ArrayList<CaseTypeBean>();
		final Map<String, String> pathParamsPastDays = new LinkedHashMap<String, String>();
		String listName = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(urgency)) {
				listName = AppConstants.MASS_APPLY_CASE_TYPES + urgency;
				pathParamsPastDays.put(AppConstants.LIST_NAME, listName);
				final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParamsPastDays);
				for (int i = 0; i < applParamResponseType.length; i++) {
					CaseTypeBean objCaseBean = new CaseTypeBean();
					objCaseBean.setCaseTypeTitle(applParamResponseType[i]
							.getLookupValue());
					arlCaseTypeBeans.add(objCaseBean);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getCaseTypeValues() method - CreateCasesServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlCaseTypeBeans;
	}

	/**
	 * @Author:
	 * @param :
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching Solution Conditions for
	 *               Mass Apply Rx.
	 */
	@Override
	public Map<String, String> getMassApplySolSelectBy() throws RMDWebException {
		Map<String, String> selectByMap = new HashMap<String, String>();
		final Map<String, String> pathParams = new LinkedHashMap<String, String>();
		try {
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.MASS_APPLY_SELECT_BY_OPTIONS);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			for (int i = 0; i < applParamResponseType.length; i++) {
				String selectBy = applParamResponseType[i].getLookupValue();
				selectByMap.put(selectBy, selectBy);
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getMassApplySolSelectBy() method - CreateCasesServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return selectByMap;
	}
	
	/**
	 * @Author
	 * @param
	 * @return list of string
	 * @throws:RMDWebException
	 * @Description:This is the method used for fetching the Urgency Of Repair
	 *                   values.
	 * 
	 */
	public Map<String, String> getMassApplySolUrgencyOfRepair()
			throws RMDWebException {
		Map<String, String> urgencyRepairMap = new HashMap<String, String>();
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.MASS_APPLY_URGENCY_REPAIR);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					String urgency = applParamResponseType[i].getLookupValue();
					String urgencyDescription = applParamResponseType[i]
							.getListDescription();
					urgencyRepairMap.put(urgencyDescription, urgency);
				}
				urgencyRepairMap.remove(AppConstants.SPECIFY);
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getMassApplySolUrgencyOfRepair method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return sortByValue(urgencyRepairMap);
	}

	/**
	 * @author
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used for getting solutions status values from
	 *              lookup table
	 */
	@Override
	public String getSolutionStatus() throws RMDWebException {
		String solutionStatus = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.DEFAULT_MASS_APPLY_SOLUTION_STATUS);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			for (ApplicationParametersResponseType objApplicationParametersResponseType : applParamResponseType) {
				solutionStatus = objApplicationParametersResponseType
						.getLookupValue();
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getSolutionStatus() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return solutionStatus;
	}

	/**
	 * @author
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used for getting solutions type values from
	 *              lookup table
	 */
	@Override
	public String getSolutionType() throws RMDWebException {
		String solutionType = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.DEFAULT_MASS_APPLY_SOLUTION_TYPE);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			for (ApplicationParametersResponseType objApplicationParametersResponseType : applParamResponseType) {
				solutionType = objApplicationParametersResponseType
						.getLookupValue();
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getSolutionStatus method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return solutionType;
	}

	/**
	 * @Author:
	 * @param :AssetDetailsVO
	 * @return:List<String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the list of assets based
	 *               upon user selection.
	 */
	@Override
	public List<String> getAssetList(AssetSearchVO objAssetSearchVO)
			throws RMDWebException {
		List<String> assetList = new ArrayList<String>();
		AssetsRequestType objAssetsRequestType = new AssetsRequestType();
		try {
			objAssetsRequestType
					.setCustomerId(objAssetSearchVO.getCustomerId());
			objAssetsRequestType.setAssetGrpName(objAssetSearchVO
					.getAssetGroupName());
			objAssetsRequestType.setFleetId(objAssetSearchVO.getFleet());
			objAssetsRequestType.setAssetFrom(objAssetSearchVO.getAssetFrom());
			objAssetsRequestType.setAssetTo(objAssetSearchVO.getAssetTo());
			final AssetResponseType[] assetResponseType = (AssetResponseType[]) webServiceInvoker
					.post(ServiceConstants.GET_ASSETS, objAssetsRequestType,
							AssetResponseType[].class);
			if (null != assetResponseType && assetResponseType.length > 0) {

				for (AssetResponseType assetResponse : assetResponseType) {

					String asset = assetResponse.getAssetGroupName()
							+ AppConstants.SYMBOL_HYPEN
							+ assetResponse.getAssetNumber();
					assetList.add(asset);
				}
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getAssetList() method - CreateCasesServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return assetList;
	}
	
	/**
	 * @Author:
	 * @param :AssetDetailsVO
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the list of assets and associated model based
	 *               upon user selection.
	 */
	@Override
	public Map<String,String> getAssetModelList(AssetSearchVO objAssetSearchVO)
			throws RMDWebException {
		Map<String,String> assetModelList = new LinkedHashMap<String,String>();
		AssetsRequestType objAssetsRequestType = new AssetsRequestType();
		try {
			objAssetsRequestType
					.setCustomerId(objAssetSearchVO.getCustomerId());
			objAssetsRequestType.setAssetGrpName(objAssetSearchVO
					.getAssetGroupName());
			objAssetsRequestType.setFleetId(objAssetSearchVO.getFleet());
			objAssetsRequestType.setAssetFrom(objAssetSearchVO.getAssetFrom());
			objAssetsRequestType.setAssetTo(objAssetSearchVO.getAssetTo());
			final AssetResponseType[] assetResponseType = (AssetResponseType[]) webServiceInvoker
					.post(ServiceConstants.GET_ASSETS, objAssetsRequestType,
							AssetResponseType[].class);
			if (null != assetResponseType && assetResponseType.length > 0) {

				for (AssetResponseType assetResponse : assetResponseType) {

					assetModelList.put(assetResponse.getAssetGroupName()
							+ AppConstants.SYMBOL_HYPEN
							+ assetResponse.getAssetNumber(), assetResponse.getModel());
				}
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getAssetModelList() method - CreateCasesServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return assetModelList;
	}

	/**
	 * @Author:
	 * @param :CreateCaseVO
	 * @return:List<ViewLogVO>
	 * @throws:RMDWebException
	 * @Description:This Method is used for creating cases and delivering
	 *                   recommendations for range of assets selected by the
	 *                   user.
	 */
	@Override
	public List<ViewLogVO> massApplyRx(CreateCasesVO objCreateCaseVO,
			String timeZone) throws RMDWebException {
		List<ViewLogVO> arlViewLogVOs = new ArrayList<ViewLogVO>();
		final DateFormat zoneFormater = new SimpleDateFormat(
				AppConstants.DATE_FORMAT_24HRS);
		final TimeZone time = TimeZone.getTimeZone(timeZone);
		zoneFormater.setTimeZone(time);
		try {
			CaseRequestType objCaseRequestType = new CaseRequestType();
			objCaseRequestType.setIsMassApplyRx(objCreateCaseVO
					.getIsMassApplyRx());
			if (!RMDCommonUtility.isNullOrEmpty(objCreateCaseVO.getCaseType())) {
				objCaseRequestType.setCaseType(objCreateCaseVO.getCaseType());
			}
			if (!objCreateCaseVO.getAssetList().isEmpty()) {
				objCaseRequestType.setAssetNumberList(objCreateCaseVO
						.getAssetList());
			}
			if (!RMDCommonUtility
					.isNullOrEmpty(objCreateCaseVO.getCustomerId())) {
				objCaseRequestType.setCustomerId(objCreateCaseVO
						.getCustomerId());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objCreateCaseVO
					.getAssetGrpName())) {
				objCaseRequestType.setAssetGrpName(objCreateCaseVO
						.getAssetGrpName());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objCreateCaseVO.getUserId())) {
				objCaseRequestType.setUserName(objCreateCaseVO.getUserId());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objCreateCaseVO
					.getUserLanguage())) {
				objCaseRequestType.setUserLanguage(objCreateCaseVO
						.getUserLanguage());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objCreateCaseVO
					.getObjSolutionDetailVO().getSolutionID())) {
				objCaseRequestType.setUrgency(objCreateCaseVO.getUrgRepair());
			}

			if (!RMDCommonUtility.isNullOrEmpty(objCreateCaseVO
					.getObjSolutionDetailVO().getSolutionID())) {
				objCaseRequestType.setStrEstRepairTime(objCreateCaseVO
						.getEstmTimeRepair());
			}
			if (!RMDCommonUtility.isNullOrEmpty(objCreateCaseVO.getMsdcNotes())) {
				objCaseRequestType.setMsdcNotes(AppSecUtil
						.htmlEscaping(objCreateCaseVO.getMsdcNotes()));
			}
			if (!RMDCommonUtility.isNullOrEmpty(objCreateCaseVO
					.getCustomerName())) {
				objCaseRequestType.setCustomerName(objCreateCaseVO
						.getCustomerName());
			}
			if (null != objCreateCaseVO.getObjSolutionDetailVO()) {
				SolutionDetailType objSolutionDetailType = new SolutionDetailType();
				if (!RMDCommonUtility.isNullOrEmpty(objCreateCaseVO
						.getObjSolutionDetailVO().getUrgRepair())) {
					objSolutionDetailType.setUrgRepair(objCreateCaseVO
							.getObjSolutionDetailVO().getUrgRepair());
				}

				if (!RMDCommonUtility.isNullOrEmpty(objCreateCaseVO
						.getObjSolutionDetailVO().getEstmTimeRepair())) {
					objSolutionDetailType.setEstmTimeRepair(objCreateCaseVO
							.getObjSolutionDetailVO().getEstmTimeRepair());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objCreateCaseVO
						.getObjSolutionDetailVO().getSolutionRevNo())) {
					objSolutionDetailType.setVersion(objCreateCaseVO
							.getObjSolutionDetailVO().getSolutionRevNo());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objCreateCaseVO
						.getObjSolutionDetailVO().getSolutionID())) {
					objSolutionDetailType.setSolutionID(objCreateCaseVO
							.getObjSolutionDetailVO().getSolutionID());
				}
				objCaseRequestType
						.setObjSolutionDetailType(objSolutionDetailType);
				
				RxDelvDocType objRxDelvDocType=null;
	            List<RxDelvDocType> arlRxDelvDocType=new ArrayList<RxDelvDocType>();
	            List<RecommDelvDocVO> lstDocs=objCreateCaseVO.getArlRecommDelDocVO();
	            for (Iterator iterator = lstDocs.iterator(); iterator.hasNext();) {
					RecommDelvDocVO recommDelvDocVO = (RecommDelvDocVO) iterator
							.next();
					objRxDelvDocType=new RxDelvDocType();
					objRxDelvDocType.setDocData(recommDelvDocVO.getDocData());				
					objRxDelvDocType.setDocTitle(recommDelvDocVO.getDocTitle());
					objRxDelvDocType.setDocPath(recommDelvDocVO.getDocPath());
					arlRxDelvDocType.add(objRxDelvDocType);
				}
	            
	            objCaseRequestType.setLstAttachment(arlRxDelvDocType);
			}
			
			
			final ViewLogReponseType[] arViewLogReponseTypes = (ViewLogReponseType[]) webServiceInvoker
					.post(ServiceConstants.MASS_APPLY_RX, objCaseRequestType,
							ViewLogReponseType[].class);
			for (ViewLogReponseType objLogReponseType : arViewLogReponseTypes) {
				ViewLogVO objViewLogVO = new ViewLogVO();
				objViewLogVO.setCaseId(objLogReponseType.getCaseId());
				if (null != objLogReponseType.getCreationDate()) {
					objViewLogVO.setCreationDate(zoneFormater
							.format(objLogReponseType.getCreationDate()
									.toGregorianCalendar().getTime()));
				}
				objViewLogVO.setRoadNumber(objLogReponseType.getRoadNumber());
				objViewLogVO.setRoadNumberHeader(objLogReponseType
						.getRoadNumberHeader());
				objViewLogVO.setRxQueue(objLogReponseType.getRxQueue());
				objViewLogVO.setCustomerId(objLogReponseType.getCustomerId());
				arlViewLogVOs.add(objViewLogVO);
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in massApplyRx() method - CreateCasesServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return arlViewLogVOs;
	}
	
	/**
	 * @Author:Vamsee
	 * @param :UnitShipDetailsVO
	 * @return :String
	 * @throws RMDWebException
	 * @Description:This method is used for Checking whether unit is Shipped or
	 *                   not.
	 * 
	 */

	@Override
	public String checkForUnitShipDetails(UnitShipDetailsVO objUnitShipDetailsVO)
			throws RMDWebException {
		String unitShipDetails = null;
		try {
			UnitShipDetailsRequestType objUnitShipDetailsRequestType = new UnitShipDetailsRequestType();
			objUnitShipDetailsRequestType.setCustomerId(objUnitShipDetailsVO
					.getCustomerId());
			objUnitShipDetailsRequestType.setAssetGrpName(objUnitShipDetailsVO
					.getAssetGrpName());
			objUnitShipDetailsRequestType.setAssetNumber(objUnitShipDetailsVO
					.getAssetNumber());
			unitShipDetails = (String) webServiceInvoker.post(
					ServiceConstants.CHECK_FOR_UNIT_SHIP_DETAILS,
					objUnitShipDetailsRequestType, String.class);
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in checkForUnitShipDetails() method - CreateCasesServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return unitShipDetails;
	}
	
	
	/**
	 * @Author: Mohamed
	 * @param :AssetDetailsVO
	 * @return:List<String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the list of assets which are not shipped based
	 *               upon user selection.
	 */
	@Override
	public String fetchNotShippedeAssetDetails(AssetSearchVO objAssetSearchVO)
			throws RMDWebException {
		//List<String> assetList = new ArrayList<String>();
		AssetsRequestType objAssetsRequestType = new AssetsRequestType();
		StringBuilder assetList = new StringBuilder();
		String assetNumber = "";
		AssetNumberResponseType assetResponse=null;
		try {
			objAssetsRequestType
					.setCustomerId(objAssetSearchVO.getCustomerId());
			objAssetsRequestType.setAssetGrpName(objAssetSearchVO
					.getAssetGroupName());
			objAssetsRequestType.setFleetId(objAssetSearchVO.getFleet());
			objAssetsRequestType.setAssetFrom(objAssetSearchVO.getAssetFrom());
			objAssetsRequestType.setAssetTo(objAssetSearchVO.getAssetTo());
			 AssetNumberResponseType[] assetResponseType = (AssetNumberResponseType[])webServiceInvoker
					.post(ServiceConstants.GET_ASSET_NUMBERS_FOR_SHIP_UNITS, objAssetsRequestType, AssetNumberResponseType[].class);
			if (null != assetResponseType && assetResponseType.length > 0) {
				for(int i = 0; i <= assetResponseType.length-1;i++){
					 assetResponse = assetResponseType[i];
					String asset = assetResponse.getCustomerID()
							+ AppConstants.SYMBOL_HYPEN
							+ assetResponse.getAssetNumber();
							if(i!= assetResponseType.length-1){
								asset = asset + AppConstants.COMMA;
							}
							
					assetList.append(asset);
				}
				assetNumber=assetList.toString();
			}
	    assetResponseType=null;
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getAssetList() method - CreateCasesServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return assetNumber;
	}
	@Override
	public Map<String, String> getModelByFilter(String customer,String fleet,String rnh,String assetList)
			throws RMDWebException {
		Map<String, String> modelMap = null;
		AssetNumberResponseType[] objassetNumberResponseType=null;
		Map<String, String> queryParams = new LinkedHashMap<String, String>(4);
		try {
			queryParams.put(AppConstants.CUSTOMER, customer);
			queryParams.put(AppConstants.FLEET, fleet);
			queryParams.put(AppConstants.RNH, rnh);
			queryParams.put(AppConstants.ASSET_LIST, assetList);
			objassetNumberResponseType = (AssetNumberResponseType[]) webServiceInvoker.get(
					ServiceConstants.GET_MODEL_BASED_FILTER, null, queryParams,
					null, AssetNumberResponseType[].class);
			if (null != objassetNumberResponseType
					&& objassetNumberResponseType.length > 0) {
				modelMap=new HashMap<String, String>(objassetNumberResponseType.length);
				for (AssetNumberResponseType assetNumberResponseType : objassetNumberResponseType) {
					modelMap.put(assetNumberResponseType.getModel(), assetNumberResponseType.getModel());
				}
			}
		} catch (Exception rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in getModelByFilter() method - CreateCaseServiceImpl",
							rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		finally
		{
			objassetNumberResponseType=null;
			queryParams=null;
		}
		return modelMap;
	}
}