package com.ge.trans.rmd.cm.service;

import java.util.List;

import com.ge.trans.rmd.cm.valueobjects.QueueCaseVO;
import com.ge.trans.rmd.common.exception.RMDWebException;


public interface QueueCasesService {
	public List<QueueCaseVO> getQueueList(String roleId) throws RMDWebException,
	Exception;
	
	public List<QueueCaseVO> getQueueCases(String queueobjid,String customerId,String timeZone, String defaultTimezone) throws RMDWebException,
	Exception;
}
