/**
 * 
 */
package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

/**
 * @author MSHIRAJUDDIN
 *
 */
public class LDVRMasterDataRequestVO {
	
	private List<String> masterDataSet;

	/**
	 * @return the masterDataSet
	 */
	public List<String> getMasterDataSet() {
		return masterDataSet;
	}

	/**
	 * @param masterDataSet the masterDataSet to set
	 */
	public void setMasterDataSet(List<String> masterDataSet) {
		this.masterDataSet = masterDataSet;
	}

	

}
