package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;



public class LDVRSaveTemplateGeofenceVO {
	private List<Long> geoZoneIds;

	public List<Long> getGeoZoneIds() {
		return geoZoneIds;
	}

	public void setGeoZoneIds(List<Long> geoZoneIds) {
		this.geoZoneIds = geoZoneIds;
	}	
	
}


