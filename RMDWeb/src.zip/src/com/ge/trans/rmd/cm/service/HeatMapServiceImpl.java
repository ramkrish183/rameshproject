package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.alert.valueobjects.ModelVO;
import com.ge.trans.rmd.cm.valueobjects.AssetsVO;
import com.ge.trans.rmd.cm.valueobjects.FaultVO;
import com.ge.trans.rmd.cm.valueobjects.HeatMapResponseVO;
import com.ge.trans.rmd.cm.valueobjects.HeatMapSearchVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.alert.valueobjects.ModelsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.faultstrategy.valueobjects.FaultCodesResponseType;
import com.ge.trans.rmd.services.heatmap.valueobjects.HeatMapFaultResponseType;
import com.ge.trans.rmd.services.heatmap.valueobjects.HeatMapRequestType;
import com.ge.trans.rmd.services.heatmap.valueobjects.HeatMapResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.cm.valueobjects.FaultHeatMapVO;

@Service
public class HeatMapServiceImpl extends RMDBaseServiceImpl implements
        HeatMapService {
    private final RMDWebLogger rmdWebLogger = RMDWebLogger
            .getLogger(getClass());
    @Autowired
    WebServiceInvoker webServiceInvoker;

    @Override
    public HeatMapResponseVO getHeatMapModels(HeatMapSearchVO heatmapSearchVO)
            throws RMDWebException {
        HeatMapResponseVO heatMapResponseVO = null;
        List<ModelVO> modelList = null;
        ModelVO modelVO = null;
        try {
            HeatMapRequestType objHeatMapReqType = new HeatMapRequestType();
            objHeatMapReqType.setCustomerId(heatmapSearchVO.getCustomerId());
            HeatMapResponseType heatMapResponseType = (HeatMapResponseType) webServiceInvoker
                    .post(ServiceConstants.GET_HEAT_MAP_MODELS,
                            objHeatMapReqType, HeatMapResponseType.class);
            if (null != heatMapResponseType) {
                heatMapResponseVO = new HeatMapResponseVO();
                List<ModelsResponseType> modelRespLst = heatMapResponseType
                        .getModels();
                if (RMDCommonUtility.isCollectionNotEmpty(modelRespLst)) {
                    modelList = new ArrayList<ModelVO>(modelRespLst.size());
                    for (ModelsResponseType modelResponseType : modelRespLst) {
                        modelVO = new ModelVO();
                        modelVO.setModelName(modelResponseType.getModelName());
                        modelVO.setModelObjId(modelResponseType.getModelObjId());
                        modelList.add(modelVO);
                    }                    
                }
                heatMapResponseVO.setModels(modelList);
            }
        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error(
                    "RMDWebException occured in getHeatMapModels() method ",
                    rmdEx);

            throw rmdEx;

        } 
        return heatMapResponseVO;
    }

    @Override
    public HeatMapResponseVO getHeatMapAssetNumbers(
            HeatMapSearchVO heatmapSearchVO) throws RMDWebException {
        HeatMapResponseVO heatMapResponseVO = null;
        List<AssetsVO> assetList = null;
        AssetsVO assetsVO = null;
        try {
            HeatMapRequestType objHeatMapReqType = new HeatMapRequestType();
            objHeatMapReqType.setCustomerId(heatmapSearchVO.getCustomerId());
            objHeatMapReqType.setModelLst(heatmapSearchVO.getModelLst());
            objHeatMapReqType.setAssetHeaderLst(heatmapSearchVO.getAssetHeaderLst());
            HeatMapResponseType heatMapResponseType = (HeatMapResponseType) webServiceInvoker
                    .post(ServiceConstants.GET_HEAT_MAP_ASSET_NUMBERS,
                            objHeatMapReqType, HeatMapResponseType.class);
            if (null != heatMapResponseType) {
                heatMapResponseVO = new HeatMapResponseVO();
                    List<AssetResponseType> assetRespLst = heatMapResponseType
                            .getAssets();
                    if (RMDCommonUtility.isCollectionNotEmpty(assetRespLst)) {
                        assetList = new ArrayList<AssetsVO>(assetRespLst.size());
                        for (AssetResponseType assetResponseType : assetRespLst) {
                            assetsVO = new AssetsVO();
                            assetsVO.setRoadNumberFrom(assetResponseType
                                    .getAssetNumber());
                            assetList.add(assetsVO);
                        }
                        
                    }
                
                heatMapResponseVO.setAssets(assetList);
            }
        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error(
                    "RMDWebException occured in getHeatMapAssetNumbers() method ",
                    rmdEx);

            throw rmdEx;

        } 
        return heatMapResponseVO;
    }

    @Override
    public HeatMapResponseVO getHeatMapAssetHeaders(
            HeatMapSearchVO heatmapSearchVO) throws RMDWebException {
        HeatMapResponseVO heatMapResponseVO = null;
        List<AssetsVO> assetList = null;
        AssetsVO assetsVO = null;
        try {
            HeatMapRequestType objHeatMapReqType = new HeatMapRequestType();
            objHeatMapReqType.setCustomerId(heatmapSearchVO.getCustomerId());
            objHeatMapReqType.setModelLst(heatmapSearchVO.getModelLst());
            objHeatMapReqType.setAssetNumberLst(heatmapSearchVO.getAssetNumberLst());
            HeatMapResponseType heatMapResponseType = (HeatMapResponseType) webServiceInvoker
                    .post(ServiceConstants.GET_HEAT_MAP_ASSET_HEADERS,
                            objHeatMapReqType, HeatMapResponseType.class);
            if (null != heatMapResponseType) {
                heatMapResponseVO = new HeatMapResponseVO();
                    List<AssetResponseType> assetRespLst = heatMapResponseType
                            .getAssets();
                    if (RMDCommonUtility.isCollectionNotEmpty(assetRespLst)) {
                        assetList = new ArrayList<AssetsVO>(assetRespLst.size());
                        for (AssetResponseType assetResponseType : assetRespLst) {
                            assetsVO = new AssetsVO();
                            assetsVO.setRoadInitial(assetResponseType
                                    .getAssetGroupName());
                            assetList.add(assetsVO);
                        }                     
                    }
                
                heatMapResponseVO.setAssets(assetList);
            }
        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error(
                    "RMDWebException occured in getHeatMapAssetHeaders() method ",
                    rmdEx);

            throw rmdEx;

        } 
        return heatMapResponseVO;
    }

    @Override
    public HeatMapResponseVO getHeatMapFaults(HeatMapSearchVO heatmapSearchVO)
            throws RMDWebException {
        HeatMapResponseVO heatMapResponseVO = null;
        List<FaultVO> faultList = null;
        FaultVO faultVO = null;
        try {
            HeatMapRequestType objHeatMapReqType = new HeatMapRequestType();
            objHeatMapReqType.setCustomerId(heatmapSearchVO.getCustomerId());
            objHeatMapReqType.setModelLst(heatmapSearchVO.getModelLst());
            objHeatMapReqType.setAssetNumberLst(heatmapSearchVO.getAssetNumberLst());
            objHeatMapReqType.setAssetHeaderLst(heatmapSearchVO.getAssetHeaderLst());
            objHeatMapReqType.setFromDate(heatmapSearchVO.getFromDate());
            objHeatMapReqType.setToDate(heatmapSearchVO.getToDate());
            objHeatMapReqType.setNoOfdays(heatmapSearchVO.getNoOfDays());
            objHeatMapReqType.setIsNonGPOCUser(heatmapSearchVO.getIsNonGPOCUser());
            HeatMapResponseType heatMapResponseType = (HeatMapResponseType) webServiceInvoker
                    .post(ServiceConstants.GET_HEAT_MAP_FAULTS,
                            objHeatMapReqType, HeatMapResponseType.class);
            if (null != heatMapResponseType) {
                heatMapResponseVO = new HeatMapResponseVO();
                    List<FaultCodesResponseType> faultRespList = heatMapResponseType
                            .getFaults();
                    if (RMDCommonUtility.isCollectionNotEmpty(faultRespList)) {
                        faultList = new ArrayList<FaultVO>(faultRespList.size());
                        for (FaultCodesResponseType faultResponseType : faultRespList) {
                            faultVO = new FaultVO();
                            faultVO.setStrFaultDescription(faultResponseType.getFaultDescription());
                            faultVO.setStrFaultCode(faultResponseType.getFaultCode());
                            faultVO.setStrSubId(faultResponseType.getFaultSubId());
                            faultList.add(faultVO);
                        }                       
                    }
                
                heatMapResponseVO.setFaults(faultList);
            }
        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error(
                    "RMDWebException occured in getHeatMapFaults() method ",
                    rmdEx);

            throw rmdEx;

        } 
        return heatMapResponseVO;
    }
    @Override
    public HeatMapResponseVO getHeatMapFilterResults(
            HeatMapSearchVO heatmapSearchVO,String timeZone) throws RMDWebException {
        HeatMapResponseVO heatMapResponseVO = null;
        List<FaultHeatMapVO> faultHeatMapList = null;
        FaultHeatMapVO faultHeatMapVO = null;
        try {
            HeatMapRequestType objHeatMapReqType = new HeatMapRequestType();
            objHeatMapReqType.setCustomerId(heatmapSearchVO.getCustomerId());
            objHeatMapReqType.setModelLst(heatmapSearchVO.getModelLst());
            objHeatMapReqType.setAssetNumberLst(heatmapSearchVO.getAssetNumberLst());
            objHeatMapReqType.setAssetHeaderLst(heatmapSearchVO.getAssetHeaderLst());
            objHeatMapReqType.setFaultCodeLst(heatmapSearchVO.getFaultCodeLst());
            objHeatMapReqType.setFromDate(heatmapSearchVO.getFromDate());
            objHeatMapReqType.setToDate(heatmapSearchVO.getToDate());
            objHeatMapReqType.setNoOfdays(heatmapSearchVO.getNoOfDays());           
            HeatMapResponseType heatMapResponseType = (HeatMapResponseType) webServiceInvoker
                    .post(ServiceConstants.GET_HEAT_MAP_FILTER_FAULTS,
                            objHeatMapReqType, HeatMapResponseType.class);
            if (null != heatMapResponseType) {
                    heatMapResponseVO = new HeatMapResponseVO();  
                    List<HeatMapFaultResponseType> faultRespList = heatMapResponseType
                            .getFaultHeatMapResponseType();
                    if (RMDCommonUtility.isCollectionNotEmpty(faultRespList)) {
                        faultHeatMapList = new ArrayList<FaultHeatMapVO>(faultRespList.size());
                        for (HeatMapFaultResponseType faultResponseType : faultRespList) {
                            faultHeatMapVO = new FaultHeatMapVO();
                            faultHeatMapVO.setStrCustomerId(faultResponseType.getStrCustomerId());
                            faultHeatMapVO.setStrFaultCode(faultResponseType.getStrFaultCode());
                            faultHeatMapVO.setStrFaultDescription(faultResponseType.getStrFaultDescription());
                            faultHeatMapVO.setStrSubId(faultResponseType.getStrSubId());
                            faultHeatMapVO.setStrSerialNo(faultResponseType.getStrSerialNo());
                            faultHeatMapVO.setStrAssetHeader(faultResponseType.getStrAssetHeader());
                            faultHeatMapVO.setStrAssetNumber(faultResponseType.getStrAssetNumber());                            
                            faultHeatMapVO.setStrCustomerName(faultResponseType.getStrCustomerName());
                            faultHeatMapVO.setStrModelId(faultResponseType.getStrModelId());
                            faultHeatMapVO.setStrModelName(faultResponseType.getStrModelName());                         
                            if(!RMDCommonUtility.isNullOrEmpty(faultResponseType.getOccurDate())){
                                faultHeatMapVO.setOccurDate(RMDCommonUtility
                                 .convertDateFormatAndTimezone(faultResponseType.getOccurDate(),
                                AppConstants.TO_DATE_FORMAT,
                                AppConstants.TO_DATE_FORMAT,
                                AppConstants.TIMEZONE_EASTERN,
                                timeZone));
                            }
                            if(!RMDCommonUtility.isNullOrEmpty(faultResponseType.getOffBoardLoadDate())){
                                faultHeatMapVO.setOffBoardLoadDate(RMDCommonUtility
                                 .convertDateFormatAndTimezone(faultResponseType.getOffBoardLoadDate(),
                                AppConstants.TO_DATE_FORMAT,
                                AppConstants.TO_DATE_FORMAT,
                                AppConstants.TIMEZONE_EASTERN,
                                timeZone));
                            }                                        
                            faultHeatMapVO.setStrGPSLatitude(faultResponseType.getStrGPSLatitude());
                            faultHeatMapVO.setStrGPSLongitude(faultResponseType.getStrGPSLongitude());     
                            faultHeatMapVO.setWorstUrgency(faultResponseType.getWorstUrgency());    
                            faultHeatMapList.add(faultHeatMapVO);                           
                        }                        
                    }               
                heatMapResponseVO.setFaultHeatMap(faultHeatMapList);
            }
        } catch (RMDWebException rmdEx) {
            rmdWebLogger.error(
                    "RMDWebException occured in getHeatMapFilterResults() method ",
                    rmdEx);
            throw rmdEx;

        }catch(Exception ex){
            rmdWebLogger.error(
                    "Excpetion occured in getHeatMapFilterResults() method ",
                    ex);
            RMDWebErrorHandler.handleException(ex);

        }   
        return heatMapResponseVO;
    }
}
