package com.ge.trans.rmd.cm.valueobjects;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CallLogReportBean {

	private List<CallLogDetailsVO> callLogReport;
	private HashMap<String,Map<String,String>> callCntByBsnArea;
	private HashMap<String,Map<String,String>> weeklyCallCntByBsnArea;
	private HashMap<String,Map<String,String>> vehCallCntByBsnArea;

	public List<CallLogDetailsVO> getCallLogReport() {
		return callLogReport;
	}

	public void setCallLogReport(List<CallLogDetailsVO> callLogReport) {
		this.callLogReport = callLogReport;
	}

    public HashMap<String, Map<String, String>> getCallCntByBsnArea() {
        return callCntByBsnArea;
    }

    public void setCallCntByBsnArea(
            HashMap<String, Map<String, String>> callCntByBsnArea) {
        this.callCntByBsnArea = callCntByBsnArea;
    }

    public HashMap<String, Map<String, String>> getWeeklyCallCntByBsnArea() {
        return weeklyCallCntByBsnArea;
    }

    public void setWeeklyCallCntByBsnArea(
            HashMap<String, Map<String, String>> weeklyCallCntByBsnArea) {
        this.weeklyCallCntByBsnArea = weeklyCallCntByBsnArea;
    }

    public HashMap<String, Map<String, String>> getVehCallCntByBsnArea() {
        return vehCallCntByBsnArea;
    }

    public void setVehCallCntByBsnArea(
            HashMap<String, Map<String, String>> vehCallCntByBsnArea) {
        this.vehCallCntByBsnArea = vehCallCntByBsnArea;
    }
    
    
    
    
	
	
}
