
package com.ge.trans.rmd.cm.mcs.assestmessagehistory;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.ge.trans.rmd.cm.mcs.assestmessagehistory package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GroupMsgHistoryRequest_QNAME = new QName("http://www.getransporatation.com/railsolutions/mcs", "groupMsgHistoryRequest");
    private final static QName _MessageDetailsRequest_QNAME = new QName("http://www.getransporatation.com/railsolutions/mcs", "messageDetailsRequest");
    private final static QName _ConsumerId_QNAME = new QName("http://www.getransporatation.com/railsolutions/mcs", "consumerId");
    private final static QName _MessageHistoryResponse_QNAME = new QName("http://www.getransporatation.com/railsolutions/mcs", "messageHistoryResponse");
    private final static QName _RequestDetailsRequest_QNAME = new QName("http://www.getransporatation.com/railsolutions/mcs", "requestDetailsRequest");
    private final static QName _FaultInfo_QNAME = new QName("http://www.getransporatation.com/railsolutions/mcs", "faultInfo");
    private final static QName _RequestDetailsResponse_QNAME = new QName("http://www.getransporatation.com/railsolutions/mcs", "requestDetailsResponse");
    private final static QName _MessageHistoryRequest_QNAME = new QName("http://www.getransporatation.com/railsolutions/mcs", "messageHistoryRequest");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.ge.trans.rmd.cm.mcs.assestmessagehistory
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link MessageHistoryRequest.DateTimeTo }
     * 
     */
    public MessageHistoryRequest.DateTimeTo createMessageHistoryRequestDateTimeTo() {
        return new MessageHistoryRequest.DateTimeTo();
    }

    /**
     * Create an instance of {@link Message.MessageGenerateTime }
     * 
     */
    public Message.MessageGenerateTime createMessageMessageGenerateTime() {
        return new Message.MessageGenerateTime();
    }

    /**
     * Create an instance of {@link AssetCriteria }
     * 
     */
    public AssetCriteria createAssetCriteria() {
        return new AssetCriteria();
    }

    /**
     * Create an instance of {@link MessageCriteria }
     * 
     */
    public MessageCriteria createMessageCriteria() {
        return new MessageCriteria();
    }

    /**
     * Create an instance of {@link FaultInfo }
     * 
     */
    public FaultInfo createFaultInfo() {
        return new FaultInfo();
    }

    /**
     * Create an instance of {@link Message.RequestDateTime }
     * 
     */
    public Message.RequestDateTime createMessageRequestDateTime() {
        return new Message.RequestDateTime();
    }

    /**
     * Create an instance of {@link RequestDetailsRequest }
     * 
     */
    public RequestDetailsRequest createRequestDetailsRequest() {
        return new RequestDetailsRequest();
    }

    /**
     * Create an instance of {@link Message }
     * 
     */
    public Message createMessage() {
        return new Message();
    }

    /**
     * Create an instance of {@link Message.MessageSentTime }
     * 
     */
    public Message.MessageSentTime createMessageMessageSentTime() {
        return new Message.MessageSentTime();
    }

    /**
     * Create an instance of {@link GroupMsgHistoryRequest.DateTimeTo }
     * 
     */
    public GroupMsgHistoryRequest.DateTimeTo createGroupMsgHistoryRequestDateTimeTo() {
        return new GroupMsgHistoryRequest.DateTimeTo();
    }

    /**
     * Create an instance of {@link Message.MessageRecievedTime }
     * 
     */
    public Message.MessageRecievedTime createMessageMessageRecievedTime() {
        return new Message.MessageRecievedTime();
    }

    /**
     * Create an instance of {@link MessageHistoryRequest.DateTimeFrom }
     * 
     */
    public MessageHistoryRequest.DateTimeFrom createMessageHistoryRequestDateTimeFrom() {
        return new MessageHistoryRequest.DateTimeFrom();
    }

    /**
     * Create an instance of {@link Message.LastUpdatedDate }
     * 
     */
    public Message.LastUpdatedDate createMessageLastUpdatedDate() {
        return new Message.LastUpdatedDate();
    }

    /**
     * Create an instance of {@link RequestDetailsResponse.DateRequested }
     * 
     */
    public RequestDetailsResponse.DateRequested createRequestDetailsResponseDateRequested() {
        return new RequestDetailsResponse.DateRequested();
    }

    /**
     * Create an instance of {@link MessageHistoryResponse }
     * 
     */
    public MessageHistoryResponse createMessageHistoryResponse() {
        return new MessageHistoryResponse();
    }

    /**
     * Create an instance of {@link RequestDetailsResponse.Attribute }
     * 
     */
    public RequestDetailsResponse.Attribute createRequestDetailsResponseAttribute() {
        return new RequestDetailsResponse.Attribute();
    }

    /**
     * Create an instance of {@link MessageHistoryRequest }
     * 
     */
    public MessageHistoryRequest createMessageHistoryRequest() {
        return new MessageHistoryRequest();
    }

    /**
     * Create an instance of {@link MessageDetailsRequest }
     * 
     */
    public MessageDetailsRequest createMessageDetailsRequest() {
        return new MessageDetailsRequest();
    }

    /**
     * Create an instance of {@link GroupMsgHistoryRequest.DateTimeFrom }
     * 
     */
    public GroupMsgHistoryRequest.DateTimeFrom createGroupMsgHistoryRequestDateTimeFrom() {
        return new GroupMsgHistoryRequest.DateTimeFrom();
    }

    /**
     * Create an instance of {@link Message.CreatedDate }
     * 
     */
    public Message.CreatedDate createMessageCreatedDate() {
        return new Message.CreatedDate();
    }

    /**
     * Create an instance of {@link GroupMsgHistoryRequest }
     * 
     */
    public GroupMsgHistoryRequest createGroupMsgHistoryRequest() {
        return new GroupMsgHistoryRequest();
    }

    /**
     * Create an instance of {@link Message.StatusDateTime }
     * 
     */
    public Message.StatusDateTime createMessageStatusDateTime() {
        return new Message.StatusDateTime();
    }

    /**
     * Create an instance of {@link RequestDetailsResponse }
     * 
     */
    public RequestDetailsResponse createRequestDetailsResponse() {
        return new RequestDetailsResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GroupMsgHistoryRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.getransporatation.com/railsolutions/mcs", name = "groupMsgHistoryRequest")
    public JAXBElement<GroupMsgHistoryRequest> createGroupMsgHistoryRequest(GroupMsgHistoryRequest value) {
        return new JAXBElement<GroupMsgHistoryRequest>(_GroupMsgHistoryRequest_QNAME, GroupMsgHistoryRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MessageDetailsRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.getransporatation.com/railsolutions/mcs", name = "messageDetailsRequest")
    public JAXBElement<MessageDetailsRequest> createMessageDetailsRequest(MessageDetailsRequest value) {
        return new JAXBElement<MessageDetailsRequest>(_MessageDetailsRequest_QNAME, MessageDetailsRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.getransporatation.com/railsolutions/mcs", name = "consumerId")
    public JAXBElement<String> createConsumerId(String value) {
        return new JAXBElement<String>(_ConsumerId_QNAME, String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MessageHistoryResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.getransporatation.com/railsolutions/mcs", name = "messageHistoryResponse")
    public JAXBElement<MessageHistoryResponse> createMessageHistoryResponse(MessageHistoryResponse value) {
        return new JAXBElement<MessageHistoryResponse>(_MessageHistoryResponse_QNAME, MessageHistoryResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequestDetailsRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.getransporatation.com/railsolutions/mcs", name = "requestDetailsRequest")
    public JAXBElement<RequestDetailsRequest> createRequestDetailsRequest(RequestDetailsRequest value) {
        return new JAXBElement<RequestDetailsRequest>(_RequestDetailsRequest_QNAME, RequestDetailsRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FaultInfo }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.getransporatation.com/railsolutions/mcs", name = "faultInfo")
    public JAXBElement<FaultInfo> createFaultInfo(FaultInfo value) {
        return new JAXBElement<FaultInfo>(_FaultInfo_QNAME, FaultInfo.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RequestDetailsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.getransporatation.com/railsolutions/mcs", name = "requestDetailsResponse")
    public JAXBElement<RequestDetailsResponse> createRequestDetailsResponse(RequestDetailsResponse value) {
        return new JAXBElement<RequestDetailsResponse>(_RequestDetailsResponse_QNAME, RequestDetailsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link MessageHistoryRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.getransporatation.com/railsolutions/mcs", name = "messageHistoryRequest")
    public JAXBElement<MessageHistoryRequest> createMessageHistoryRequest(MessageHistoryRequest value) {
        return new JAXBElement<MessageHistoryRequest>(_MessageHistoryRequest_QNAME, MessageHistoryRequest.class, null, value);
    }

}
