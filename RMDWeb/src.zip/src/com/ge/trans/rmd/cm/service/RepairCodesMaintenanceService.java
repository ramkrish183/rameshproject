/**
 * ============================================================
 * Classification: GE Confidential
 * File : RepairCodesMaintenanceService.java
 * Description :
 *
 * Package : com.ge.trans.rmd.cm.service;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on :
 * History
 * Modified By : Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.valueobjects.RepairCodeVO;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface RepairCodesMaintenanceService {

	/**
	 * @Author:
	 * @param :
	 * @return:Map<String, String>
	 * @throws:RMDWebException,Exception
	 * @Description: This method is used for fetching values to populate select
	 *               by drop down.
	 */
	public Map<String, String> getRepairCodesSelectBy() throws RMDWebException,
			Exception;

	/**
	 * @Author:
	 * @param :
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching values to populate status
	 *               drop down.
	 */
	public Map<String, String> getRepairCodesStatus() throws RMDWebException,
			Exception;

	/**
	 * @Author:
	 * @param:String selectBy,
			String condition, String status, String model, String value
	 * @return:List<RepairCodeVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching repair codes based on
	 *               search criteria
	 */
	public List<RepairCodeVO> getRepairCodesList(String selectBy,
			String condition, String status, String model, String value)
			throws RMDWebException, Exception;

	/**
	 * @Author:
	 * @param :String repairCode, String repairCodeDesc, String flag
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for validating the repair codes and
	 *               repair code description.
	 */
	public String repairCodeValidations(String repairCode,
			String repairCodeDesc, String flag) throws RMDWebException,
			Exception;

	public String addRepairCodes(String repairCode, String repairCodeDesc,
			String status, String model)throws RMDWebException,
			Exception;

	public String updateRepairCodes(String repairCode, String repairCodeDesc,
			String status, String model)throws RMDWebException,
			Exception;

	/**
	 * @Author:
	 * @param :
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching values to populate conditions
	 *               drop down.
	 */
	public Map<String, String> getRepairCodesConditions()throws RMDWebException,
	Exception;
	
}
