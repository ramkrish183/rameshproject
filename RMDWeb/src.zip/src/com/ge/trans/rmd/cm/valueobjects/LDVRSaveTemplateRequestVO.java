package com.ge.trans.rmd.cm.valueobjects;

public class LDVRSaveTemplateRequestVO {

	private String templateObjid;
	
	private String messageId;
	
    private String applicationId;
	
    private Integer templateNumber;
	
    private Integer templateVersion;
	
    private String description;
	
    private String templateStatus;
	
    private String customerId;
    
    private String userName;   
    
	private String createdDate;
	
	private String lastUpdatedDate;
    
    private LDVRTemplateDetails templateDetails;
    
 
      
	public String getMessageId() {
		return messageId;
	}


	public void setMessageId(String messageId) {
		this.messageId = messageId;
	}


	public String getApplicationId() {
		return applicationId;
	}


	public void setApplicationId(String applicationId) {
		this.applicationId = applicationId;
	}

	
	/**
	 * @return the templateNumber
	 */
	public Integer getTemplateNumber() {
		return templateNumber;
	}


	/**
	 * @param templateNumber the templateNumber to set
	 */
	public void setTemplateNumber(Integer templateNumber) {
		this.templateNumber = templateNumber;
	}


	/**
	 * @return the templateVersion
	 */
	public Integer getTemplateVersion() {
		return templateVersion;
	}


	/**
	 * @param templateVersion the templateVersion to set
	 */
	public void setTemplateVersion(Integer templateVersion) {
		this.templateVersion = templateVersion;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getTemplateStatus() {
		return templateStatus;
	}


	public void setTemplateStatus(String templateStatus) {
		this.templateStatus = templateStatus;
	}


	public String getCustomerId() {
		return customerId;
	}


	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}




	/**
	 * @return the templateObjid
	 */
	public String getTemplateObjid() {
		return templateObjid;
	}


	/**
	 * @param templateObjid the templateObjid to set
	 */
	public void setTemplateObjid(String templateObjid) {
		this.templateObjid = templateObjid;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}


	public String getLastUpdatedDate() {
		return lastUpdatedDate;
	}


	public void setLastUpdatedDate(String lastUpdatedDate) {
		this.lastUpdatedDate = lastUpdatedDate;
	}


	/**
	 * @return the templateDetails
	 */
	public LDVRTemplateDetails getTemplateDetails() {
		return templateDetails;
	}


	/**
	 * @param templateDetails the templateDetails to set
	 */
	public void setTemplateDetails(LDVRTemplateDetails templateDetails) {
		this.templateDetails = templateDetails;
	}


	

	
	/*	@Override
	public String toString() {
		String val = "applicationId: "+applicationId
						+"\nmessageId: "+messageId
						+"\ntemplateNumber: "+templateNumber
						+"\ntemplateVersion: "+templateVersion
						+"\ntemplateStatus: "+templateStatus
						+"\ndescription: "+description
						+"\ncustomerId: "+customerId;						
		return val;
	}*/
	
}

