package com.ge.trans.rmd.cm.mvc.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ge.trans.rmd.cm.service.AssetCasesService;
import com.ge.trans.rmd.cm.service.AssetOverviewService;
import com.ge.trans.rmd.cm.service.CreateCasesService;
import com.ge.trans.rmd.cm.valueobjects.AssetSearchVO;
import com.ge.trans.rmd.cm.valueobjects.CaseTypeBean;
import com.ge.trans.rmd.cm.valueobjects.CreateCaseLookUpVO;
import com.ge.trans.rmd.cm.valueobjects.CreateCasesVO;
import com.ge.trans.rmd.cm.valueobjects.UnitShipDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.ViewLogVO;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.beans.CaseSolutionVO;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.beans.SolutionBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.AppSecUtil;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.pp.beans.AssetBean;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.common.vo.CustomerVO;
import com.sun.jersey.core.impl.provider.entity.XMLJAXBElementProvider.App;
@Controller
@SessionAttributes
public class CreateCasesController extends RMDBaseController {
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
	.getLogger(getClass());

	@Autowired
	private CreateCasesService createCasesService;
	@Autowired
	private AssetCasesService assetCasesService;
	@Autowired
	private ApplicationContext appContext;
	
	@Autowired
	private AssetOverviewService asstOvwService;
	/**
	 * 
	 * @param
	 * @return Map<String,list>
	 * @throws RMDWebException 
	 * @Description * This method is used for fetching all look up values
	 * 
	 */
	
	@RequestMapping(value = AppConstants.GET_LOOKUP_VALUES)
	public @ResponseBody
	CreateCaseLookUpVO getSolutionLookUps(HttpServletRequest request)
			throws RMDWebException {

		rmdWebLogger
				.debug("Inside CreateCasesController in getSolutionLookUps Method");
		CreateCaseLookUpVO lookUPResults = new CreateCaseLookUpVO();
		AssetOverviewBean assetOverviewBean = new AssetOverviewBean();
		try {

			final HttpSession session = request.getSession(false);
			String assetNumber =  (String)request.getParameter("assetNumber");
			String assetGrpName =  (String)request.getParameter("assetGrpName");
			String customerId =  (String)request.getParameter("customerId");
			
	        	assetOverviewBean.setAsset(EsapiUtil.stripXSSCharacters(assetNumber));
			assetOverviewBean.setAssetGroup(EsapiUtil.stripXSSCharacters(assetGrpName));
			assetOverviewBean.setCustomer(EsapiUtil.stripXSSCharacters(customerId));
			//assetOverviewBean.setAssetGroup(groupName);
			//assetOverviewBean.setCustomer(customerId);
			//assetOverviewBean.setUserLanguage(userVO.getStrUserLanguage());
			// Get the basic information of asset
			//assetOverviewBean = asstOvwService.getAssets(assetOverviewBean);
			
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			Map<String, String> repairTimeMap = createCasesService
					.getSolEstRepairTime();
			Map<String, String> urgencyOfRepMap = createCasesService
					.getSolUrgencyOfRepair();
			Map<String, String> modelTypeMap = createCasesService
					.getSolModelType(userVO.getCustomerId());
			Map<String, String> selectByMap = createCasesService
					.getSolSelectBy();
			Map<String, String> conditionMap = createCasesService
					.getSolCondition();
			lookUPResults.setConditionMap(conditionMap);
			lookUPResults.setModelTypeMap(modelTypeMap);
			lookUPResults.setRepairTimeMap(repairTimeMap);
			lookUPResults.setSelectByMap(selectByMap);
			lookUPResults.setUrgencyOfRepMap(urgencyOfRepMap);
			lookUPResults.setModel(assetOverviewBean.getModel());
			

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getSolutionLookUps method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lookUPResults;
	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 * @Description * This method is used for fetching Urgency of repair values.
	 *              This method will be invoked through ajax call.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GETSOLURG)
	public @ResponseBody
	java.util.Map<String, String> getSolUrgencyOfRepair() throws RMDWebException {

		rmdWebLogger
				.debug("Inside CreateCasesController in getSolUrgencyOfRepair Method");
		Map<String, String> urgencyOfRepairMap = null;
		TreeMap<String, String> result = new TreeMap<String, String>(
				String.CASE_INSENSITIVE_ORDER);
		try {
			urgencyOfRepairMap = createCasesService.getSolUrgencyOfRepair();

			result.putAll(urgencyOfRepairMap);
		}catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getSolUrgencyOfRepair method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws RMDWebException 
	 * @Description * This method is used for fetching estimated Repair Time
	 *              values. This method will be invoked through ajax call.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GETSOLEST)
	public @ResponseBody
	java.util.Map<String, String> getSolEstRepairTime() throws RMDWebException {

		rmdWebLogger
		.debug("Inside CreateCasesController in getSolEstRepairTime Method");
		Map<String, String> estRepairTimeMap = null;
		TreeMap<String, String> result = new TreeMap<String, String>(
				String.CASE_INSENSITIVE_ORDER);
		try {
			estRepairTimeMap = createCasesService.getSolEstRepairTime();

			result.putAll(estRepairTimeMap);
		}catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getSolEstRepairTime method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * 
	 * @param
	 * @return String
	 * @throws
	 * @Description * This method is used for fetching the values for right pane
	 *              table on page load. It will fetch the Rx records for last 30
	 *              days
	 * 
	 */
/*
	@RequestMapping(value = AppConstants.REQ_URI_GETSOLSEACHRES, method = RequestMethod.GET)
	public String getSolSearchResults(final Model model) {
		try {
			List<CreateCasesVO> arlSolVO;
			SolutionBean objSolBean = new SolutionBean();
			arlSolVO = createCasesService.getSolSearchResults(objSolBean,
					RMDCommonConstants.LETTER_Y);
			objSolBean.setCreateCasesVO(arlSolVO);
			model.addAttribute(AppConstants.CREATECASE_SOLN_BEAN, objSolBean);
		} catch (Exception e) {
			rmdWebLogger
			.error("Error occurred in RxController - getRxSearchResults Method"
					+ e);
		}
		return AppConstants.SOLNSEARCHRESULTS;

	}*/

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 * @Description * This method is used for fetching RxDetails values. This
	 *              method will be invoked on click of Run button through ajax
	 *              call.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GETSOLDETAIL, method = RequestMethod.POST)
	public @ResponseBody
	java.util.List<CreateCasesVO> getSolDetails(
			@RequestParam(value = AppConstants.REQ_PARAM_SOLNSFORMVAL, required = true) final String solSearchFormValues,
			Model model) throws RMDWebException {
		ObjectMapper mapper = new ObjectMapper();
		List<CreateCasesVO> lstCreateCasesVO = null;
		rmdWebLogger
				.debug("Inside CreateCasesController in getSolDetails Method");
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			SolutionBean objSolBean = mapper.readValue(solSearchFormValues,
					SolutionBean.class);
			Map<String, String> result = validateUserInputForSolution(
					objSolBean, model);
			if (!result.isEmpty() && null != result) {
				lstCreateCasesVO = new ArrayList<CreateCasesVO>();
				CreateCasesVO createCasesVO = new CreateCasesVO();
				createCasesVO.setErrorMsg(result);
				lstCreateCasesVO.add(createCasesVO);

			} else {
				lstCreateCasesVO = createCasesService.getSolSearchResults(
						objSolBean, RMDCommonConstants.LETTER_N);
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getSolDetails method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lstCreateCasesVO;
	}
		
	/**
	 * 
	 * @param customerId
	 * @param assetGroup
	 * @param assetNumber
	 * @param request
	 * @param model
	 * @return
	 * @Description This method will return the list of asset numbers for given
	 *              keys like customerId, assetGroup and asset number
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GETASSETDETAIL, method = RequestMethod.GET)
	public @ResponseBody
	java.util.List<AssetBean> getAssetDetails(
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId,
			@RequestParam(value = AppConstants.CREATCASE_ASSTGRP, required = true) final String assetGroup,
			@RequestParam(value = AppConstants.ASSTNUMFROM, required = true) final String fromAssetNumber,
			@RequestParam(value = AppConstants.ASSTNUMTO, required = true) final String toAssetNumber,
			final HttpServletRequest request, final Model model) throws RMDWebException {
		rmdWebLogger
		.debug("Inside CreateCaseController in getAssetNumbers Method");
		List<AssetBean> lstAssetDetails = new ArrayList<AssetBean>();
		AssetBean assetBean;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
		.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {

			assetBean = new AssetBean();
			assetBean.setUserFirstName(userVO.getStrFirstName());
			assetBean.setUserLastName(userVO.getStrLastName());
			assetBean.setUserId(userVO.getUserId());
			assetBean.setUserLanguage(userVO.getStrUserLanguage());
			assetBean.setCustomerId(customerId);
			assetBean.setAssetGroup(assetGroup);
			assetBean.setFromAssetNumber(fromAssetNumber);
			assetBean.setToAssetNumber(toAssetNumber);
			lstAssetDetails = createCasesService.getAssetDetails(assetBean);

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getAssetNumbers method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lstAssetDetails;

	}

	/**
	 * 
	 * @param
	 * @return Map<String,String>
	 * @throws
	 * @Description * This method is used for fetching Validating Solution section inputs from user values.
	 * 
	 */

	public Map<String, String> validateUserInputForSolution(
			SolutionBean objSolBean, Model model) {
		Map<String, String> result = new HashMap<String, String>();

		try {
			// title validations

			if (null != objSolBean.getSolutionTitle()
					&& !objSolBean.getSolutionTitle().isEmpty()) {
				if (RMDCommonUtility.isSpecialCharactersFound(objSolBean
						.getSolutionTitle())) {
					result.put(AppConstants.SOLNTITLE,
							AppConstants.CREATCASE_INVALID);
				}
			}
			// condition value
			if (null != objSolBean.getSolValue()
					&& !objSolBean.getSolValue().isEmpty()) {
				if (objSolBean.getSolValue().length() > 50) {
					result.put(AppConstants.VALUE,
							AppConstants.CREATCASE_INVALID);
				} else if (RMDCommonUtility.isSpecialCharactersFound(objSolBean
						.getSolValue())) {
					result.put(AppConstants.VALUE,
							AppConstants.INVALID_SPECIAL_CHARACTER);
				}
			}

			// estimated repair time validations
			if (!objSolBean.getSolEstRepairTime().isEmpty()
					&& !RMDCommonConstants.ALL.equalsIgnoreCase(objSolBean
							.getSolEstRepairTime())) {
				if (!AppSecUtil
						.checkIntNumber(objSolBean.getSolEstRepairTime())) {
					Map<String, String> estRprTimeMap = getSolEstRepairTime();
					List<String> estRprTimeList = new ArrayList<String>(
							estRprTimeMap.keySet());

					if (!AppSecUtil.isListContainsValue(
							objSolBean.getSolutionStatus(), estRprTimeList)) {
						result.put(AppConstants.ESTIMATED_REPAIR,
								AppConstants.CREATCASE_INVALID);
					}

				}
			}
			// Sol Urgency  repair time validations 
			if (null !=objSolBean.getSolUrgencyOfRepair() && !objSolBean.getSolUrgencyOfRepair().isEmpty()&&!RMDCommonConstants.ALL
					.equalsIgnoreCase(RMDCommonUtil.convertArrayToString(objSolBean.getSolUrgencyOfRepair()))) {
				// webservice call
				Map<String, String> urgencyRepairMap = getSolUrgencyOfRepair();
				//convert map to list
				List<String> urgencyRepairList = new ArrayList<String>(urgencyRepairMap.keySet()); 
				// input provided by user
				List<String> userInputList = objSolBean.getSolUrgencyOfRepair();
				// compare lists
				if(!AppSecUtil.compareLists(urgencyRepairList, userInputList)){
					result.put(AppConstants.URGENCY, AppConstants.CREATCASE_INVALID);
				}
			}	 

		} catch (Exception exception) {
			rmdWebLogger.error("Error occured in validateUserInputForRx"
					+ exception.getMessage());
		}
		return result;
	}

	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description: post the new notes information for requested asset number.
	 * 
	 * 
	 *               1) put the notes to the service call with required params
	 *               like assetNumber,notes and user name 2) return a String for
	 *               successful post of notes.
	 * 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_CREATECASE, method = RequestMethod.GET)
	public @ResponseBody
	Map<String, String> createCases(
			@RequestParam(value = AppConstants.CREATCASE_FORMVALUES, required = true) final String formValues,
			final HttpServletRequest request,final Locale locale) throws Exception {
		rmdWebLogger
		.debug("createCases Controller : createCases() method Starts");
		// Get the asset number from request
		ObjectMapper mapper = new ObjectMapper();
		mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
		mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
		CreateCasesVO createCasesVO = mapper.readValue(EsapiUtil.stripXSSCharacters(formValues),
				CreateCasesVO.class);
		Model model=null;
		final String assetNumber;
		if (null != createCasesVO.getAssetNumber()
				&& !createCasesVO.getAssetNumber().isEmpty()) {
			assetNumber = createCasesVO.getAssetNumber();
		} else {
			assetNumber = AppConstants.EMPTY_STRING;
		}
		final String groupName;
		if (null != createCasesVO.getAssetGrpName()
				&& !createCasesVO.getAssetGrpName().isEmpty()) {
			groupName = createCasesVO.getAssetGrpName();
		} else {
			groupName = AppConstants.EMPTY_STRING;
		}
		final String customerId;
		final String customerName;

		if (null != createCasesVO.getCustomerId()
				&& !createCasesVO.getCustomerId().isEmpty()) {
			customerId = createCasesVO.getCustomerId();
			customerName = createCasesVO.getCustomerId();
		} else {
			customerId = AppConstants.EMPTY_STRING;
			customerName = AppConstants.EMPTY_STRING;
		}

		Map<String, String> result =validateUserInputForAssetSec(customerId,groupName,assetNumber,request,model);
		if (!result.isEmpty() && null != result) {			
			createCasesVO.setErrorMsg(result);
			return result;

		}else{
			final String notes = createCasesVO.getNote();
			String returnStrCases = AppConstants.FAILURE;
			String caseId = null;
			final NotesBean notesBean = new NotesBean();
			final CaseBean caseBean = new CaseBean();

			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
			.getAttribute(AppConstants.ATTR_USER_OBJECT);
			try {
				caseBean.setAssetNumber(EsapiUtil.stripXSSCharacters(assetNumber));
				caseBean.setUserFirstName(EsapiUtil.stripXSSCharacters(userVO.getStrFirstName()));
				caseBean.setUserLastName(EsapiUtil.stripXSSCharacters(userVO.getStrLastName()));
				caseBean.setUserId(EsapiUtil.stripXSSCharacters(userVO.getUserId()));
				caseBean.setUserLanguage(EsapiUtil.stripXSSCharacters(userVO.getStrUserLanguage()));
				caseBean.setCustomerId(EsapiUtil.stripXSSCharacters(customerId));
				caseBean.setAssetGrpName(EsapiUtil.stripXSSCharacters(groupName));
				caseBean.setCustomerName(EsapiUtil.stripXSSCharacters(customerName));
				caseId = createCasesService.createCases(caseBean);
				returnStrCases = AppConstants.SUCCESS;

				if (caseId != null && !caseId.isEmpty() && notes != null
						&& !notes.isEmpty() && !notes.equals(appContext.getMessage(AppConstants.CREATE_CASE_DEFAULTNOTE,null,locale))) {
					notesBean.setAssetNumber(EsapiUtil.stripXSSCharacters(assetNumber));
					notesBean.setNoteDescription(AppSecUtil.htmlEscaping(EsapiUtil.stripXSSCharacters(notes)));
					notesBean.setUserFirstName(EsapiUtil.stripXSSCharacters(userVO.getStrFirstName()));
					notesBean.setUserLastName(EsapiUtil.stripXSSCharacters(userVO.getStrLastName()));
					notesBean.setUserId(EsapiUtil.stripXSSCharacters(userVO.getUserId()));
					notesBean.setUserLanguage(EsapiUtil.stripXSSCharacters(userVO.getStrUserLanguage()));
					notesBean.setCustomerId(EsapiUtil.stripXSSCharacters(customerId));
					notesBean.setAssetGroup(EsapiUtil.stripXSSCharacters(groupName));
					returnStrCases = createCasesService.addNotes(notesBean);
				}

			} catch (RMDWebException rmdEx) {
				rmdWebLogger.error(
						"RMDWebException occured in createCases() method ", rmdEx);
				request.setAttribute(AppConstants.ERRORMSG,
						AppConstants.UNKNOWN_EXCEPTION);
				throw rmdEx;
			} catch (Exception ex) {
				rmdWebLogger.error("Exception occured in createCases method ", ex);
				request.setAttribute(AppConstants.ERRORMSG,
						AppConstants.UNKNOWN_EXCEPTION);
				throw ex;
			}

			rmdWebLogger
			.debug("createCases Controller : createCases() method Ends");
			return Collections.singletonMap(AppConstants.MESSAGE, returnStrCases);
		}
	}

	private Map<String, String> validateUserInputForAssetSec(String customerId,String assetGroup,String assetNumber,final HttpServletRequest request,Model model) {
		Map<String, String> result = new HashMap<String, String>();
		try{
			//customer validation validations
			if (null!=customerId&&!customerId.isEmpty()) {
				Map<String, String> customerMap = getCustomers(request,model);
				List<String> customerList = new ArrayList<String>(
						customerMap.keySet());

				if (!AppSecUtil.isListContainsValue(customerId, customerList)) {
					result.put(AppConstants.CUSTOMERID, AppConstants.CREATCASE_INVALID);
				}

			}
			if (null!=assetGroup&&!assetGroup.isEmpty()) {
				List<String> assetGroupList = getAssetGroups(customerId,model);

				if (!AppSecUtil.isListContainsValue(assetGroup, assetGroupList)) {
					result.put(AppConstants.ASSETGRP, AppConstants.CREATCASE_INVALID);
				}

			}
			if (null!=assetNumber&&!assetNumber.isEmpty()) {
				List<String> assetNumberList = getAssetNumbers(customerId,assetGroup,assetNumber,RMDCommonConstants.EMPTY_STRING,request,model);

				if (!AppSecUtil.isListContainsValue(assetNumber, assetNumberList)) {
					result.put(AppConstants.ASSETNUMBER, AppConstants.CREATCASE_INVALID);
				}

			}

		} catch (Exception exception) {
			rmdWebLogger.error("Error occured in validateUserInputForRx"
					+ exception.getMessage());
		}
		return result;
	}

	

	/**
	 * @param ruleTitle
	 * @return List<String>
	 * @Description: This method is used for ajax to list all the Rx Titles
	 * 
	 * 
	 */

	@RequestMapping(value = AppConstants.REQ_URI_GETSOLTITLES, method = RequestMethod.GET)
	public @ResponseBody
	java.util.List<String> getSolTitles(
			@RequestParam(value =AppConstants.RXTITLE, required = true) final String rxTitle,
			final Model model) throws GenericAjaxException, RMDWebException {
		rmdWebLogger.debug("Inside RxController in getSolTitles Method");
		List<String> lstRxTitle = null;
		try {

			lstRxTitle = createCasesService.getSolTitles(rxTitle);

		}catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getSolTitles method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lstRxTitle;

	}

	/**
	 * 
	 * @param customerId
	 * @param assetGroup
	 * @param assetNumber
	 * @param request
	 * @param model
	 * @return
	 * @Description This method will return the list of asset numbers for given
	 *              keys like customerId, assetGroup and asset number
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GETSOLASSETNUM, method = RequestMethod.GET)
	public @ResponseBody
	java.util.List<String> getAssetNumbers(
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId,
			@RequestParam(value = AppConstants.CREATCASE_ASSTGRP, required = true) final String assetGroup,
			@RequestParam(value = AppConstants.ASSET_NUMBER, required = true) final String assetNumber,
			@RequestParam(value = AppConstants.FLEET) final String fleet,
			final HttpServletRequest request, final Model model) throws RMDWebException {
		rmdWebLogger
		.debug("Inside CreateCaseController in getAssetNumbers Method");
		List<String> assetNumbers = null;
		AssetBean assetBean;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
		.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {

			assetBean = new AssetBean();
			assetBean.setUserFirstName(userVO.getStrFirstName());
			assetBean.setUserLastName(userVO.getStrLastName());
			assetBean.setUserId(userVO.getUserId());
			assetBean.setUserLanguage(userVO.getStrUserLanguage());
			assetBean.setCustomerId(customerId);
			assetBean.setAssetGroup(assetGroup);
			assetBean.setAssetNumber(assetNumber);
			assetBean.setFleetId(fleet);
			assetNumbers = createCasesService.getAssets(assetBean);

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getAssetNumbers method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return assetNumbers;

	}

	/**
	 * 
	 * @param model
	 * @return This controller method will return the list of customers
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GETCASESUTOMERS, method = RequestMethod.GET)
	public @ResponseBody
	Map<String, String> getCustomers(final HttpServletRequest request,
			final Model model) throws RMDWebException {

		Map<String, String> customers = new LinkedHashMap<String, String>();
		final HttpSession session = request.getSession(false);
		try {
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			if (null != userVO.getDefaultCustomer()
					&& !userVO.getDefaultCustomer().isEmpty() && (null == EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID))
							|| EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID)).trim().isEmpty())) {
				List<CustomerVO> customerList = userVO.getCustomerList();
				for (CustomerVO customer : customerList) {
					customers.put(EsapiUtil.stripXSSCharacters(customer.getCustomerID()),
							EsapiUtil.stripXSSCharacters(customer.getCustomerName()));
				}
			} else {
				customers = createCasesService.getCustomers();
			}

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCustomers method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return customers;

	}

	/**
	 * 
	 * @param customerId
	 * @param model
	 * @return
	 * @Description This method will return the list of asset groups for given
	 *              customerId
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GETCASEASSTGROUP, method = RequestMethod.GET)
	public @ResponseBody
	java.util.List<String> getAssetGroups(
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId,
			final Model model) throws RMDWebException {

		List<String> assetGroups = null;
		try {

			assetGroups = createCasesService.getAssetGroups(EsapiUtil.stripXSSCharacters(customerId));

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getAssetGroups method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return assetGroups;

	}
	/*
	*//**
	 * 
	 * @param customerId
	 * @param assetGroup
	 * @param assetNumber
	 * @param solEstRepairTime
	 * @param solUrgency
	 * @param solutionId
	 * @param request
	 * @param model
	 * @return
	 * @throws RMDWebException
	 * @throws Exception
	 * @Description This method is used to create case with mass apply rx
	 *//*

	@RequestMapping(value = AppConstants.REQ_URI_CREATECASEWITHRX, method = RequestMethod.POST)
	public @ResponseBody
	Map<String, Object> massApplyRx(
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId,
			@RequestParam(value = AppConstants.CREATCASE_ASSTGRP, required = true) final String assetGroup,
			@RequestParam(value = AppConstants.ASSET_NUMBER, required = true) final String assetNumber,
			@RequestParam(value = AppConstants.CREATCASE_ESTRPRTIME, required = true) final String solEstRepairTime,
			@RequestParam(value = AppConstants.CREATCASE_SOLNURGENCY, required = true) final String solUrgency,
			@RequestParam(value = AppConstants.CREATCASE_SOLNID, required = true) final String solutionId,
			@RequestParam(value = AppConstants.CREATCASE_CASE_TYPE, required = true) final String caseType,
			final HttpServletRequest request, final Model model)
			throws RMDWebException, Exception {

		List<CaseSolutionVO> massApplyRxResults = null;
		Map<String, Object> resultMessage = new HashMap<String, Object>();
		List<String> solUrgencyOfRepair = new ArrayList<String>();
		solUrgencyOfRepair.add(solUrgency);
		final CaseSolutionVO caseBeanMassApply = new CaseSolutionVO();
		String returnErrorCode = AppConstants.FAILURE;
		List<String> caseTypeList= null;
		Integer massApplyRxLimit = 0;
		try {
			// Create case starts
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			caseTypeList= createCasesService.getCaseTypeForValidation();
			massApplyRxLimit = (Integer)request.getAttribute(AppConstants.MASS_APPLY_RX_LIMIT);
			
			if (null == solutionId || solutionId.isEmpty()) {
				resultMessage.put(AppConstants.SOLUTION_ID_REQ_ERR,
						AppConstants.SOLUTION_ID_REQ_ERR);

			}
			if ((null == caseType || caseType.isEmpty())
					|| (null != caseType && AppConstants.SELECT
							.equalsIgnoreCase(caseType))) {
				resultMessage.put(AppConstants.CASE_TYPE_REQ_ERR,
						AppConstants.CASE_TYPE_REQ_ERR);

			} 
			if(null != assetNumber && assetNumber.split(AppConstants.COMMA).length > massApplyRxLimit){
				resultMessage.put(AppConstants.ASSET_NUMBER_LIMIT_ERR,
						AppConstants.ASSET_NUMBER_LIMIT_ERR);
			}
			
			
			
			else if (AppConstants.EOA_PROBLEM.equalsIgnoreCase(caseType)
					&& !RMDCommonUtil.containsString(AppConstants.URGENCY_WRYC,
							solUrgency)) {
				resultMessage.put(AppConstants.ERR_FLAG,
						AppConstants.EOA_PROBLEM_ERR);

			} else if (AppConstants.ESTP_PROBLEM.equalsIgnoreCase(caseType)
					&& !RMDCommonUtil.containsString(AppConstants.URGENCY_WRY,
							solUrgency)) {
				resultMessage.put(AppConstants.ERR_FLAG,
						AppConstants.ESTP_PROBLEM_ERR);
			} else if (AppConstants.MANUVAL_SHUTDOWN.equalsIgnoreCase(caseType)
					&& !AppConstants.CHAR_C.equalsIgnoreCase(solUrgency)) {
				resultMessage.put(AppConstants.ERR_FLAG,
						AppConstants.MANUVAL_SHUTDOWN_ERR);
			} else if (AppConstants.OIL_ANOMALY.equalsIgnoreCase(caseType)
					&& !AppConstants.CHAR_0.equalsIgnoreCase(solUrgency)) {
				resultMessage.put(AppConstants.ERR_FLAG,
						AppConstants.OIL_ANOMALY_ERR);
			} else if (caseTypeList.contains(caseType)
					&& !RMDCommonUtil.containsString(AppConstants.URGENCY_BG,
							solUrgency)) {
				resultMessage.put(AppConstants.ERR_FLAG,
						AppConstants.CASETYPE_LIST_ERR);
			} else if (AppConstants.COMMISSION.equalsIgnoreCase(caseType)) {
				resultMessage.put(AppConstants.ERR_FLAG,
						AppConstants.COMMISSION_ERR);
			}

			if (null != resultMessage && resultMessage.isEmpty()) {
				caseBeanMassApply.setCaseType(caseType);
				caseBeanMassApply.setSolutionId(solutionId);
				caseBeanMassApply.setUserId(userVO.getUserId());
				caseBeanMassApply.setCustomerId(customerId);
				caseBeanMassApply.setAssetGrpName(assetGroup);
				caseBeanMassApply.setAssetNumber(assetNumber);
				caseBeanMassApply.setUrgency(solUrgency);
				caseBeanMassApply.setEstRepairCode(solEstRepairTime);
				caseBeanMassApply.setCaseTitle(AppConstants.CREATCASE_FIELDREQ);
				caseBeanMassApply.setPriority(AppConstants.CREATCASE_HIGH);
				massApplyRxResults = createCasesService
						.massApplyRx(caseBeanMassApply);
				resultMessage.put(AppConstants.SUCCESS_FLAG, massApplyRxResults);
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in createCaseWithRx() method ",
					rmdEx);
			returnErrorCode = rmdEx.getErrorCode();
			if (RMDCommonUtil.containsString(AppConstants.CREATECASE_ERR_LIST,
					returnErrorCode)) {
				resultMessage.put(AppConstants.ERR_FLAG, returnErrorCode);

				return resultMessage;
			}
			else{
				RMDWebErrorHandler.handleException(rmdEx);	
			}
			
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in createCaseWithRx() method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			returnErrorCode = AppConstants.FAILURE;
			RMDWebErrorHandler.handleException(ex);
		}

		rmdWebLogger
				.debug("CreateCase Controller : createCaseWithRx() method Ends");
		return resultMessage;
	}
	*/
	
	/********************************MassApply Rx*******************************************************/	
	
	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the list of all Models.
	 */
	@RequestMapping(value = AppConstants.GET_ALL_MODELS)
	public @ResponseBody
	java.util.Map<String, String> getAllModels(final HttpServletRequest request)
			throws RMDWebException {
		Map<String, String> modelMap = null;
		Map<String, String> sortedMap = new LinkedHashMap<String, String>();
		try {
			modelMap = createCasesService.getAllModels();
			sortedMap = SortMapValues(modelMap);
		} catch (Exception e) {
			rmdWebLogger
					.error("Error occurred in CreateCasesController - getAllModels Method"
							+ e);
			RMDWebErrorHandler.handleException(e);
		}
		return sortedMap;
	}

	/**
	 * @Author:
	 * @param:String customerId
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the fleets based upon the
	 *               Customer.
	 */
	@RequestMapping(value = AppConstants.GET_FLEET_VALUES)
	public @ResponseBody
	Map<String, String> getFleets(
			@RequestParam(value = AppConstants.CUSTOMERID) final String customerId)
			throws RMDWebException {
		Map<String, String> fleetMap = new LinkedHashMap<String, String>();
		try {
			final Map<String, String> custMap = createCasesService
					.getFleets(EsapiUtil.stripXSSCharacters(customerId));
			fleetMap = SortMapValues(custMap);
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getFleets() method - CreateCasesController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return fleetMap;
	}

	/**
	 * @Author:
	 * @param:customerName
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Road Initials based
	 *               upon the CustomerId.
	 */
	@RequestMapping(value = AppConstants.GET_ROAD_NUMBER_HEADERS)
	public @ResponseBody
	Map<String, String> getRoadNumberHeaders(
			@RequestParam(value = AppConstants.CUSTOMER_ID) final String customerId)
			throws RMDWebException {
		Map<String, String> roadNumberHeaderMap = new LinkedHashMap<String, String>();
		try {
			final Map<String, String> custMap = createCasesService
					.getRoadNumberHeaders(EsapiUtil.stripXSSCharacters(customerId));
			roadNumberHeaderMap = SortMapValues(custMap);
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getRoadNumberHeaders() method - CreateCasesController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return roadNumberHeaderMap;
	}

	/**
	 * @Author:
	 * @param :
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used to checking foe maximum numbers of
	 *               units on which mass apply rx can be applied.
	 */
	@RequestMapping(value = AppConstants.GET_MAX_MASS_APPLY_UNITS)
	public @ResponseBody
	String getMaxMassApplyUnits() throws RMDWebException {
		String maximumLimit = null;
		try {
			maximumLimit = createCasesService.getMaxMassApplyUnits();
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getMaxMassApplyUnits() method - CreateCasesController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return maximumLimit;
	}

	/**
	 * @Author:
	 * @param :
	 * @return:String urgency
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching Case Types based Upon the
	 *               Urgency value.
	 */
	@RequestMapping(value = AppConstants.GET_CASE_TYPE_VALUES)
	public @ResponseBody
	List<CaseTypeBean> getCaseTypeValues(
			@RequestParam(value = AppConstants.URGENCY) final String urgency)
			throws RMDWebException {
		List<CaseTypeBean> arlCaseTypeBeans = new ArrayList<CaseTypeBean>();
		try {
			arlCaseTypeBeans = createCasesService.getCaseTypeValues(urgency);
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getCaseTypeValues() method - CreateCasesController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlCaseTypeBeans;
	}

	/**
	 * @Author:
	 * @param :
	 * @return:List<CreateCasesVO>
	 * @throws:RMDWebException
	 * @throws:GenericAjaxException
	 * @Description: This method is used to fetch solutions/recommendations
	 *               based upon the given search criteria.
	 */

	@RequestMapping(value = AppConstants.GET_MASS_APPLY_SOLUTION_SEARCH_RESULTS)
	public @ResponseBody
	List<CreateCasesVO> getSolSearchResults(
			@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString)
			throws RMDWebException {
		List<CreateCasesVO> solutionsList = new ArrayList<CreateCasesVO>();
		final ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			SolutionBean objSolutionBean = mapper.readValue(parameterString,
					SolutionBean.class);
			objSolutionBean.setIsMassApplyRx(AppConstants.YES_FLAG);
			solutionsList = createCasesService.getSolSearchResults(
					objSolutionBean, AppConstants.STR_N);
		} catch (Exception exception) {
			rmdWebLogger.error(
					"Exception occured in getSolSearchResults() method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}

		return solutionsList;
	}

	/**
	 * @Author:
	 * @param :
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching values to populate
	 *               solution select by drop down.
	 */

	@RequestMapping(value = AppConstants.GET_MASS_APPLY_SELECT_BY_OPTIONS)
	public @ResponseBody
	Map<String, String> getMassApplySolSelectBy() throws RMDWebException {
		Map<String, String> selectByMap = null;
		try {
			selectByMap = createCasesService.getMassApplySolSelectBy();
		} catch (Exception exception) {
			rmdWebLogger.error(
					"Exception occured in getMassApplygetSolSelectBy method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return selectByMap;
	}

	/**
	 * @author
	 * @param
	 * @return Map<String,String>
	 * @throws
	 * @Description This method is used for fetching urgency of repair values.
	 * 
	 */
	@RequestMapping(value = AppConstants.GET_MASS_APPLY_URGENCY_REPAIR)
	public @ResponseBody
	java.util.Map<String, String> getMassApplySolUrgencyOfRepair()
			throws RMDWebException {
		Map<String, String> urgencyOfRepairMap = null;
		TreeMap<String, String> result = new TreeMap<String, String>(
				String.CASE_INSENSITIVE_ORDER);
		try {
			urgencyOfRepairMap = createCasesService
					.getMassApplySolUrgencyOfRepair();
			result.putAll(urgencyOfRepairMap);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getMassApplySolUrgencyOfRepair method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @author
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used for getting default solutions status
	 *              values from lookup table
	 */
	@RequestMapping(value = AppConstants.GET_SOLUTION_STATUS)
	public @ResponseBody
	String getSolutionStatus() throws RMDWebException {
		String solutionStatus = null;
		try {
			solutionStatus = createCasesService.getSolutionStatus();
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getSolUrgencyOfRepair method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return solutionStatus;
	}

	/**
	 * @author
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used for getting default solutions type
	 *              values from lookup table
	 */
	@RequestMapping(value = AppConstants.GET_SOLUTION_TYPE)
	public @ResponseBody
	String getSolutionType() throws RMDWebException {
		String solutionType = null;
		try {
			solutionType = createCasesService.getSolutionType();
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getSolutionType method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return solutionType;
	}

	/**
	 * @Author:
	 * @param :customer,fleet,assetGrpName,fromRoadNumber,toRoadNumber
	 * @return:List<String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the list of assets based
	 *               upon user selection.
	 */

	@RequestMapping(value = AppConstants.GET_ASSET_LIST)
	@ResponseBody public 
	List<String> getAssetList(
			@RequestParam(value = AppConstants.CUSTOMER_ID) final String customerId,
			@RequestParam(value = AppConstants.FLEET) final String fleet,
			@RequestParam(value = AppConstants.ASSET_GROUP_NAME) final String assetGrpName,
			@RequestParam(value = AppConstants.FROM_ROAD_NUMBER) final String fromRoadNumber,
			@RequestParam(value = AppConstants.TO_ROAD_NUMBER) final String toRoadNumber)
			throws RMDWebException {
		List<String> assetList = new ArrayList<String>();
		try {
			if (!RMDCommonUtility.isNullOrEmpty(fromRoadNumber)
					&& !RMDCommonUtility.isNullOrEmpty(customerId)
					&& !RMDCommonUtility.isNullOrEmpty(toRoadNumber)) {
				AssetSearchVO objAssetSearchVO = new AssetSearchVO();
				objAssetSearchVO.setCustomerId(customerId);
				objAssetSearchVO.setFleet(fleet);
				objAssetSearchVO.setAssetGroupName(assetGrpName);
				objAssetSearchVO.setAssetFrom(fromRoadNumber);
				objAssetSearchVO.setAssetTo(toRoadNumber);
				assetList = createCasesService.getAssetList(objAssetSearchVO);
			}
		} catch (Exception exception) {
			rmdWebLogger.error("Exception occured in getAssetList() method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return assetList;
	}
	
	/**
	 * @Author:
	 * @param :customer,fleet,assetGrpName,fromRoadNumber,toRoadNumber
	 * @return:List<String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the list of assets based
	 *               upon user selection.
	 */

	@RequestMapping(value = AppConstants.GET_ASSET_MODEL_LIST)
	@ResponseBody public 
	Map<String,String> getAssetModelList(
			@RequestParam(value = AppConstants.CUSTOMER_ID) final String customerId,
			@RequestParam(value = AppConstants.FLEET) final String fleet,
			@RequestParam(value = AppConstants.ASSET_GROUP_NAME) final String assetGrpName,
			@RequestParam(value = AppConstants.FROM_ROAD_NUMBER) final String fromRoadNumber,
			@RequestParam(value = AppConstants.TO_ROAD_NUMBER) final String toRoadNumber)
			throws RMDWebException {
		Map<String,String> assetModelList = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(fromRoadNumber)
					&& !RMDCommonUtility.isNullOrEmpty(customerId)
					&& !RMDCommonUtility.isNullOrEmpty(toRoadNumber)) {
				AssetSearchVO objAssetSearchVO = new AssetSearchVO();
				objAssetSearchVO.setCustomerId(customerId);
				objAssetSearchVO.setFleet(fleet);
				objAssetSearchVO.setAssetGroupName(assetGrpName);
				objAssetSearchVO.setAssetFrom(fromRoadNumber);
				objAssetSearchVO.setAssetTo(toRoadNumber);
				assetModelList = createCasesService.getAssetModelList(objAssetSearchVO);
			}
		} catch (Exception exception) {
			rmdWebLogger.error("Exception occured in getAssetModelList() method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return assetModelList;
	}
	
	/**
	 * @Author:
	 * @param :customerId,assetGrpName,assetNumber
	 * @return:AssetSearchVO
	 * @throws:RMDWebException
	 * @Description:This Method is used for fetching AssetInfo.
	 */

	@RequestMapping(value = AppConstants.GET_ASSET_INFO)
	public @ResponseBody
	AssetBean getAssetInfo(
			@RequestParam(AppConstants.CUSTOMERID) String customerId,
			@RequestParam(AppConstants.ASSET_GROUP_NAME) String assetGrpName,
			@RequestParam(AppConstants.ASSET_NUMBER) String assetNumber)
			throws RMDWebException {
		AssetBean objAssetBean = null;
		try {
			AssetSearchVO objAssetSearchVO = new AssetSearchVO();
			objAssetSearchVO.setAssetGroupName(assetGrpName);
			objAssetSearchVO.setCustomerId(customerId);
			objAssetSearchVO.setAssetNumber(assetNumber);
			objAssetBean = createCasesService.getAssetInfo(objAssetSearchVO);
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getSolutionType method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return objAssetBean;
	}
	
	/**
	 * @Author:
	 * @param :
	 * @return:List<ViewLogVO>
	 * @throws:RMDWebException
	 * @Description:This Method is used for creating cases and delivering
	 *                   recommendations for range of assets selected by the
	 *                   user.
	 */

	@RequestMapping(value = AppConstants.MASS_APPLY_RX_CREATE_CASE)
	public @ResponseBody
	List<ViewLogVO> massApplyRx(
			@RequestParam("deliverParameterString") String parameterString,
			final HttpServletRequest request) throws RMDWebException {
		List<ViewLogVO> arlViewLogVOs = new ArrayList<ViewLogVO>();
		final ObjectMapper mapper = new ObjectMapper();
		final HttpSession session = request.getSession();
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			CreateCasesVO objCreateCasesVO = mapper.readValue(parameterString,
					CreateCasesVO.class);
			String timeZone = userVO.getTimeZone();
			objCreateCasesVO.setUserId(userVO.getCmAliasName());
			objCreateCasesVO.setUserLanguage(userVO.getStrLanguage());
			objCreateCasesVO.setIsMassApplyRx(AppConstants.STR_Y);
			String result = validateMassApplyRx(objCreateCasesVO);
			if (AppConstants.STR_Y.equalsIgnoreCase(result)) {
				arlViewLogVOs = createCasesService.massApplyRx(
						objCreateCasesVO, timeZone);
			} else {
				ViewLogVO objLogVO = new ViewLogVO();
				objLogVO.setErrorMsg(result);
				arlViewLogVOs.add(objLogVO);
			}
		} catch (Exception exception) {
			rmdWebLogger.error("Exception occured in massApplyRx method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return arlViewLogVOs;
	}
	
	
	
	/**
	 * @Author:
	 * @param :customerId,assetGrpName,assetNumber
	 * @return:AssetSearchVO
	 * @throws:RMDWebException
	 * @Description:This Method is used for validating the massApply Rx data and checking the following conditions.
	 * 				1.Checking delivery Mechanism for the Customer.
	 * 				2.Checking whether recommendation is ready to be delivered.
	 * 				3.Checking whether user selected  assets more than maximum limit.
	 */

	public String validateMassApplyRx(CreateCasesVO objCreateCasesVO)
			throws RMDWebException {
		try {
			if (RMDCommonUtility
					.isNullOrEmpty(objCreateCasesVO.getCustomerId())) {
				return AppConstants.CUSTOMER_ID_NOT_PROVIDED;
			}
			if (RMDCommonUtility.isNullOrEmpty(objCreateCasesVO.getCaseType())) {
				return AppConstants.CASE_TYPE_NOT_PROVIDED;
			}
			if (RMDCommonUtility.isNullOrEmpty(objCreateCasesVO.getCaseType())) {
				return AppConstants.CASE_TYPE_NOT_PROVIDED;
			}
			if (objCreateCasesVO.getAssetList().isEmpty()) {
				return AppConstants.ASSET_LIST_NOT_PROVIDED;
			}
			if (RMDCommonUtility.isNullOrEmpty(objCreateCasesVO
					.getObjSolutionDetailVO().getSolutionID())) {
				return AppConstants.RX_OBJID_NOT_PROVIDED;
			}
			String maxLimit = createCasesService.getMaxMassApplyUnits();

			if ((objCreateCasesVO.getAssetList().size()) > Integer
					.valueOf(maxLimit)) {
				return AppConstants.MAX_RANGE;
			}
			String deliveryMechnism = assetCasesService
					.checkForDelvMechanism(objCreateCasesVO.getCustomerName());
			if (AppConstants.STR_N.equalsIgnoreCase(deliveryMechnism)) {
				return AppConstants.DELIVERY_MECHANISM_NOT_PRESENT;
			}
			if (!AppConstants.STR_Y.equalsIgnoreCase(deliveryMechnism)
					&& !RMDCommonUtility.isNullOrEmpty(deliveryMechnism)) {
				String readyTodeliver = assetCasesService
						.getReadyToDelv(objCreateCasesVO
								.getObjSolutionDetailVO().getSolutionID());
				if (AppConstants.STR_N.equalsIgnoreCase(readyTodeliver)
						|| AppConstants.CUST_VERSION_NOT_EXIST
								.equalsIgnoreCase(readyTodeliver)) {
					return AppConstants.RX_IS_NOT_READY_TO_DELV;
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in validateMassApplyRx() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return AppConstants.STR_Y;
	}

	/**
	 * @Author:Vamsee
	 * @param :customerId,assetGrpName,assetNumber
	 * @return:AssetSearchVO
	 * @throws:RMDWebException
	 * @Description:This method is used for Checking whether unit is Shipped or
	 *                   not.
	 * 
	 */

	@RequestMapping(value = AppConstants.CHECK_FOR_UNIT_SHIP_DETAILS)
	public @ResponseBody
	String checkForUnitShipDetails(
			@RequestParam(AppConstants.CUSTOMER_ID) String customerId,
			@RequestParam(AppConstants.ASSET_GROUP_NAME) String assetGrpName,
			@RequestParam(AppConstants.ASSET_NUMBER) String assetNumber)
			throws RMDWebException {
		String unitShipDetails = null;
		try {
			UnitShipDetailsVO objUnitShipDetailsVO = new UnitShipDetailsVO();

			if (!RMDCommonUtility.isNullOrEmpty(customerId)
					&& !RMDCommonUtility.isNullOrEmpty(assetGrpName)
					&& RMDCommonUtility.isAlphaNumeric(assetNumber)){
			objUnitShipDetailsVO.setAssetGrpName(EsapiUtil.stripXSSCharacters(assetGrpName));
			objUnitShipDetailsVO.setCustomerId(EsapiUtil.stripXSSCharacters(customerId));
			objUnitShipDetailsVO.setAssetNumber(EsapiUtil.stripXSSCharacters(assetNumber));
			unitShipDetails = createCasesService
					.checkForUnitShipDetails(objUnitShipDetailsVO);
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in checkForUnitShipDetails() method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return unitShipDetails;
	}
	
	/**
	 * @Author:Mohamed
	 * @param :customer,assetGrpName,fromRoadNumber,toRoadNumber
	 * @return:List<String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the list of assets numbers which are not shipped based
	 *               upon user selection.
	 */

	@RequestMapping(value = AppConstants.FETCH_NOT_SHIPPED_ASSET_DETAILS)
	public @ResponseBody
	String fetchNotShippedeAssetDetails(
			@RequestParam(value = AppConstants.CUSTOMER_ID) final String customerId,
			@RequestParam(value = AppConstants.FLEET) final String fleet,
			@RequestParam(value = AppConstants.ASSET_GROUP_NAME) final String assetGrpName,
			@RequestParam(value = AppConstants.FROM_ROAD_NUMBER) final String fromRoadNumber,
			@RequestParam(value = AppConstants.TO_ROAD_NUMBER) final String toRoadNumber)
			throws RMDWebException {
		String assetListForNotShipped = "";
		try {
			if (!RMDCommonUtility.isNullOrEmpty(fromRoadNumber)
					&& !RMDCommonUtility.isNullOrEmpty(customerId)
					&& !RMDCommonUtility.isNullOrEmpty(toRoadNumber)) {
				AssetSearchVO objAssetSearchVO = new AssetSearchVO();
				objAssetSearchVO.setCustomerId(customerId);
				objAssetSearchVO.setFleet(fleet);
				objAssetSearchVO.setAssetGroupName(assetGrpName);
				objAssetSearchVO.setAssetFrom(fromRoadNumber);
				objAssetSearchVO.setAssetTo(toRoadNumber);
				assetListForNotShipped = createCasesService.fetchNotShippedeAssetDetails(objAssetSearchVO);
			}
		} catch (Exception exception) {
			rmdWebLogger.error("Exception occured in getAssetList() method ",
					exception);
			RMDWebErrorHandler.handleException(exception);
		}
		return assetListForNotShipped;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the list of all Models.
	 */
	@RequestMapping(value = AppConstants.GET_MODEL_BY_FILTER)
	@ResponseBody
	public java.util.Map<String, String> getModelByFilter(
			@RequestParam(value = AppConstants.CUSTOMER) final String customer,
			@RequestParam(value = AppConstants.FLEET) final String fleet,
			@RequestParam(value = AppConstants.RNH) final String rnh,
			@RequestParam(value = AppConstants.ASSET_LIST) final String assetList,
			HttpServletRequest request) throws RMDWebException {
		Map<String, String> modelMap = null;
		Map<String, String> sortedMap = new LinkedHashMap<String, String>();
		try {
			if ((customer != null && !customer
					.equals(AppConstants.EMPTY_STRING))
					|| (fleet != null && !fleet
							.equals(AppConstants.EMPTY_STRING))
					|| (rnh != null && !rnh.equals(AppConstants.EMPTY_STRING))
					|| (assetList != null && !assetList
							.equals(AppConstants.EMPTY_STRING))) {
				modelMap = createCasesService.getModelByFilter(EsapiUtil.stripXSSCharacters(customer), EsapiUtil.stripXSSCharacters(fleet),
						EsapiUtil.stripXSSCharacters(rnh), EsapiUtil.stripXSSCharacters(assetList));
				sortedMap = SortMapValues(modelMap);
			} else {
				modelMap = createCasesService.getAllModels();
				sortedMap = SortMapValues(modelMap);
			}

		} catch (Exception e) {
			rmdWebLogger
					.error("Error occurred in CreateCasesController - getModelByFilter Method"
							+ e);
			RMDWebErrorHandler.handleException(e);
		} finally {
			modelMap = null;
		}
		return sortedMap;
	}
}
