package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.SortedSet;
import java.util.StringTokenizer;
import java.util.TimeZone;

import javax.xml.datatype.XMLGregorianCalendar;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.beans.OpenCasesBean;
import com.ge.trans.rmd.cm.valueobjects.OpenCasesVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.PropertiesUtil;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.cases.valueobjects.CaseRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CasesRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.OpenCaseRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.OpenCaseResponseType;
import com.ge.trans.rmd.utilities.AppSecUtil;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class OpenCasesServiceImpl extends RMDBaseServiceImpl implements
		OpenCasesService {

	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	@Autowired
	private WebServiceInvoker rsInvoker;

	private final String ENDSTR = ")";
	private final String STARTSTR = "(";
	private final String EMPTYSTR = " ";
	private final String MINSTR = "min";
	private final String HRSSTR = "hrs";
	private final String DAYSTR = "d";
	/**
	 * @Author:
	 * @param
	 * @return Map<List<String> , ArrayList<ArrayList<ArrayList<Number>>>>
	 * @Description: This method will return the List of open cases from
	 *               database
	 */
	@Override
	public List<OpenCasesVO> fetchOpenCases(final OpenCasesBean openCaseBean)
			throws RMDWebException, Exception {
		OpenCaseResponseType[] casesResponses = null;
		List<OpenCasesVO> openCasesVOLst = new ArrayList<OpenCasesVO>();
		OpenCasesVO openCasesVO = null;
		OpenCaseRequestType objCasesReqType = new OpenCaseRequestType();
		final DateFormat nonESTZoneFormat = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		final TimeZone firstTime = TimeZone.getTimeZone(openCaseBean.getTimeZone());
		nonESTZoneFormat.setTimeZone(firstTime);
		String userTimeZone = firstTime.getID();
		String defaulTimeZone = openCaseBean.getDefaultTimeZone();
		StringBuffer sb = new StringBuffer();
		Date creationTime = null;
		try {
			objCasesReqType.setIsMyCases(AppConstants.FALSE);
			objCasesReqType.setDwq(AppConstants.OPENCASES_WS_VALUE);
			objCasesReqType.setCustomerId(openCaseBean.getCustomerId());
			objCasesReqType.setLanguage(openCaseBean.getLanguage());
			parseProducts(openCaseBean.getProducts(), objCasesReqType);
			casesResponses = (OpenCaseResponseType[]) rsInvoker.post(
					ServiceConstants.CASES_SERVICE_GET_OPEN_CASES,
					objCasesReqType, OpenCaseResponseType[].class);
			
			if (casesResponses != null && casesResponses.length > 0) {
				openCasesVOLst = new ArrayList<OpenCasesVO>(casesResponses.length);
			}

			for (int i = 0; i < casesResponses.length; i++) {
				openCasesVO = new OpenCasesVO();
				openCasesVO.setPriority(casesResponses[i].getPriority());
				openCasesVO.setAssetNumber(casesResponses[i].getAssetNumber());
				openCasesVO.setStrGrpName(casesResponses[i].getAssetGrpName());
				openCasesVO.setCaseID(casesResponses[i].getCaseID());
				openCasesVO.setCustomerName(casesResponses[i].getCustomerName());
				openCasesVO.setCaseTitle(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(casesResponses[i].getCaseTitle())));
				openCasesVO.setCaseType(casesResponses[i].getCaseType());
				openCasesVO.setCaseReason(casesResponses[i].getReason());
								
				if (null == casesResponses[i].getOwner()
						|| AppConstants.EMPTY_STRING.equalsIgnoreCase(casesResponses[i].getOwner())) {
					openCasesVO.setOwner(AppConstants.OPENCASES_VALUE_UNASSIGNED);
				} else {
					openCasesVO.setOwner(casesResponses[i].getOwner());
				}
				if (userTimeZone.equals(AppConstants.EST_TIMEZONE)
						&& defaulTimeZone.equals(AppConstants.TIMEZONE_EASTERN)) {
					if (null != casesResponses[i].getCreatedDate()) {
						openCasesVO.setCreatedDate(casesResponses[i].getCreatedDate());
					}

				} else {
					if (null != casesResponses[i].getCreatedDate()) {
						creationTime = RMDCommonUtility.stringToUSESTDate(
								casesResponses[i].getCreatedDate(),
								RMDCommonConstants.DateConstants.MMddyyyyHHmmss);
						openCasesVO.setCreatedDate(nonESTZoneFormat
								.format(creationTime));
					}
				}

				if (openCasesVO.getOwner().equalsIgnoreCase(AppConstants.OPENCASES_VALUE_UNASSIGNED)) {
					openCasesVO.setCssClass("unassignedOwner");
				} else if (openCasesVO.getOwner().equalsIgnoreCase(openCaseBean.getCmAliasName())) {
					openCasesVO.setCssClass("sameOwner");
				} else {
					openCasesVO.setCssClass("assignedOwner");
				}
				if (casesResponses[i].getAge() != null && !casesResponses[i].getAge().isEmpty()) {
					sb = new StringBuffer(casesResponses[i].getAge().trim());
					replaceAgeStr(sb);
					openCasesVO.setAge(sb.toString());
				}
				openCasesVO.setCaseCondition(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(casesResponses[i].getCaseCondition())));
				openCasesVOLst.add(openCasesVO);
			}
			casesResponses = null;

			return openCasesVOLst;
		} catch (RMDWebException rmdEx) {
			logger.error("Exception occured in fetchOpenCases() method ", rmdEx);
			throw rmdEx;
		} catch (Exception ex) {
			logger.error("Exception occured in fetchOpenCases() method ", ex);
			throw ex;
		}
	}
	
	void replaceAgeStr(StringBuffer sb) {
		sb.append(ENDSTR);
		sb.insert(0, STARTSTR);		
		sb.replace(7, 8, EMPTYSTR);
		sb.insert(10, MINSTR);
		sb.insert(7, HRSSTR);
		sb.insert(4, DAYSTR);
		if (sb.charAt(12) == '0') {
			sb.delete(12, 13);
		}
		if (sb.charAt(6) == '0') {
			sb.delete(6, 7);
		}
		if (sb.charAt(2) == '0' && sb.charAt(1) == '0') {
			sb.delete(2, 3);
		}
		if (sb.charAt(1) == '0') {
			sb.delete(1, 2);
		}
	}

	/**
	 * @Author:
	 * @param
	 * @return SortedSet<Entry<String, String>>
	 * @Description: This method will return the dropdown values of owner column
	 *               from properties file
	 */
	@Override
	public SortedSet<Entry<String, String>> getDropDownValues()
			throws RMDWebException, Exception {

		final HashMap<String, String> tempDropdown = new HashMap<String, String>();

		final String caseDropdown = PropertiesUtil
				.getProperty(AppConstants.OPEN_CASES_DROPDOWN);

		final StringTokenizer stringToken = new StringTokenizer(caseDropdown,
				AppConstants.ATTR_COLON);
		try {
			while (stringToken.hasMoreTokens()) {

				final String key = stringToken.nextToken();
				final String value = stringToken.nextToken();

				tempDropdown.put(key, value);
			}
		} catch (Exception e) {
			logger.error("Exception occured in getDropDownValues() method ", e);
			throw e;
		}
		final SortedSet<Entry<String, String>> mapDropdown = RMDCommonUtil
				.entriesSortedByValues(tempDropdown);
		return mapDropdown;
	}
	/*
	 * This method is use for take the ownership for particular case.
	 */
	@Override
	public String takeOwnerShip(final OpenCasesBean openCaseBean)
			throws RMDWebException, Exception {
		final Map<String, String> headerParams = getHeaderMap(openCaseBean);
		try {
			CaseRequestType caseRequestType = new CaseRequestType();
			caseRequestType.setCaseID(openCaseBean.getCaseId());
			caseRequestType.setUserName(openCaseBean.getUserId());
			caseRequestType.setLanguage(openCaseBean.getLanguage());
			caseRequestType.setFirstName(openCaseBean.getUserFirstName());
			caseRequestType.setLastName(openCaseBean.getUserLastName());
			caseRequestType.setCurrentOwnerName(openCaseBean.getCurrentOwner());
			rsInvoker.post(ServiceConstants.GET_CHANGE_OWNERSHIP,
					caseRequestType, headerParams);

		} catch (Exception ex) {
			logger.error("In OpenCasesServiceImpl : exception occured takeOwnerShip method "+ex.getMessage());
			RMDWebErrorHandler.handleException(ex);
		}
		return AppConstants.SUCCESS;
	}

	/**
	 * @Author:
	 * @param:OpenCasesBean
	 * @return: String
	 * @Description: This method reopens the case by invoking
	 *               casesresource.reOpenCase() method.
	 */
	@Override
	public String reOpenCase(final OpenCasesBean openCaseBean)
			throws RMDWebException, Exception {
		final Map<String, String> headerParams = getHeaderMap(openCaseBean);
		String responseString = AppConstants.FAILURE;
		try {
			CaseRequestType caseRequestType = new CaseRequestType();
			caseRequestType.setCaseID(openCaseBean.getCaseId());
			caseRequestType.setUserName(openCaseBean.getUserId());
			responseString = (String) rsInvoker.post(
					ServiceConstants.GET_REOPEN_CASE, caseRequestType,
					String.class, headerParams);

		} catch (RMDWebException ex) {
			if (AppConstants.EXCEPTION_RMD_213.equalsIgnoreCase(ex
					.getErrorCode())) {
				responseString = AppConstants.EXCEPTION_RMD_213;
			} else if (AppConstants.EXCEPTION_RMD_214.equalsIgnoreCase(ex
					.getErrorCode())) {
				responseString = AppConstants.EXCEPTION_RMD_214;
			}
			logger.error("Exception occurred in reOpenCases method ", ex);
		} catch (Exception ex) {
			logger.error("Exception occurred in reOpenCases method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return responseString;
	}

	/*
	 * This method is used for real time check of the owner of the case from eoa
	 * and omd
	 */
	@Override
	public String getCurrentOwnership(OpenCasesBean openCaseBean)
			throws RMDWebException {
		String responseString = null;
		final Map<String, String> headerParams = getHeaderMap(openCaseBean);
		final Map<String, String> pathParamsMap = new HashMap<String, String>();
		try {
			pathParamsMap.put(AppConstants.CASE_ID, openCaseBean.getCaseId());
			responseString = (String) rsInvoker.get(
					ServiceConstants.GET_CURRENT_OWNER, pathParamsMap,
					null, headerParams, String.class);
		} catch (RMDWebException ex) {
			if (AppConstants.EXCEPTION_RMD_203.equalsIgnoreCase(ex
					.getErrorCode())) {
				responseString = AppConstants.FAILURE;
			}
			logger.error("Exception occured in fetchCurrentOwnership method ",
					ex);
		} catch (Exception e) {
			logger.error("Exception occured in fetchCurrentOwnership method ",
					e);
			RMDWebErrorHandler.handleException(e);
		}
		return responseString;
	}
	
	/**
	 * @Author:
	 * @param
	 * @return List<OpenCasesVO>
	 * @Description: This method will return the List of cases from database
	 *               related to a User
	 */
	@Override
	public List<OpenCasesVO> getUserCases(final OpenCasesBean openCaseBean)
			throws RMDWebException, Exception {
		CaseResponseType[] casesResponses = null;
		final List<OpenCasesVO> openCasesVOLst = new ArrayList<OpenCasesVO>();
		OpenCasesVO openCasesVO = null;
		final DateFormat zoneFormater = new SimpleDateFormat(
				AppConstants.DATE_FORMAT_24HRS);
		CasesRequestType objCasesReqType = new CasesRequestType();
		final TimeZone firstTime = TimeZone.getTimeZone(openCaseBean
				.getTimeZone());

		String age = null;

		try {

			objCasesReqType.setUserID(openCaseBean.getUserId());
			objCasesReqType.setIsMyCases(openCaseBean.isMycases());
			objCasesReqType.setCustomerId(openCaseBean.getCustomerId());
			parseProducts(openCaseBean.getProducts(), objCasesReqType);
			casesResponses = (CaseResponseType[]) rsInvoker.post(
					ServiceConstants.CASES_SERVICE_GET_CASES, objCasesReqType,
					CaseResponseType[].class);
			for (int i = 0; i < casesResponses.length; i++) {

				openCasesVO = new OpenCasesVO();

				openCasesVO.setPriority(casesResponses[i].getCaseInfo()
						.getPriority());
				openCasesVO.setAssetNumber(casesResponses[i].getAssetNumber());
				openCasesVO.setStrGrpName(casesResponses[i].getAssetGrpName());
				openCasesVO.setCaseID(casesResponses[i].getCaseInfo()
						.getCaseID());

				openCasesVO.setRowVersion(casesResponses[i].getRowVersion());

				openCasesVO
						.setCustomerName(casesResponses[i].getCustomerName());
				openCasesVO.setCaseStatus(casesResponses[i].getCaseInfo()
						.getCaseStatus());
				openCasesVO.setCaseCondition(AppSecUtil.decodeString(casesResponses[i].getCaseInfo()
						.getCaseCondition()));
				openCasesVO.setCaseTitle(EsapiUtil.escapeSpecialChars(AppSecUtil.decodeString(casesResponses[i].getCaseInfo()
						.getCaseTitle())));
				openCasesVO.setCaseType(casesResponses[i].getCaseInfo()
						.getCaseType());
				openCasesVO.setCaseReason(casesResponses[i].getCaseInfo()
						.getReason());

				if (null == casesResponses[i].getCaseInfo().getOwner()
						|| AppConstants.EMPTY_STRING
								.equalsIgnoreCase(casesResponses[i]
										.getCaseInfo().getOwner())) {
					openCasesVO
							.setOwner(AppConstants.OPENCASES_VALUE_UNASSIGNED);
				} else {
					openCasesVO.setOwner(casesResponses[i].getCaseInfo()
							.getOwner());
					openCasesVO.setOwnerName(casesResponses[i].getCaseInfo()
							.getOwnerName());

				}

				zoneFormater.setTimeZone(firstTime);
				if (null != casesResponses[i].getCaseInfo().getCreatedDate()) {
					final XMLGregorianCalendar creationDate = casesResponses[i]
							.getCaseInfo().getCreatedDate();
					final GregorianCalendar startDate = creationDate
							.toGregorianCalendar();

					startDate.setTimeZone(firstTime);

					openCasesVO.setCreatedDate(zoneFormater.format(creationDate
							.toGregorianCalendar().getTime()));

					age = RMDCommonUtil
							.calculateAge(startDate, new GregorianCalendar(),
									openCaseBean.getTimeZone());
				}
				if (casesResponses[i].getCaseInfo().getAge() != null
						&& !casesResponses[i].getCaseInfo().getAge().isEmpty()) {
					openCasesVO
							.setAge(casesResponses[i].getCaseInfo().getAge());
				} else {
					openCasesVO.setAge(age);
				}

				openCasesVOLst.add(openCasesVO);
			}

			// return openCasesVOLst;
		} catch (RMDWebException rmdEx) {
			logger.error("Exception occured in myCases() method ", rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		} catch (Exception ex) {
			logger.error("Exception occured in myCases() method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return openCasesVOLst;
	}
	
	@Override
	public String yankCase(final OpenCasesBean openCaseBean)
			throws RMDWebException, Exception {
		final Map<String, String> headerParams = getHeaderMap(openCaseBean);
		try {
			CaseRequestType caseRequestType = new CaseRequestType();
			caseRequestType.setCaseID(openCaseBean.getCaseId());
			caseRequestType.setUserName(openCaseBean.getUserId());
			caseRequestType.setLanguage(openCaseBean.getLanguage());
			caseRequestType.setFirstName(openCaseBean.getUserFirstName());
			caseRequestType.setLastName(openCaseBean.getUserLastName());
			caseRequestType.setCurrentOwnerName(openCaseBean.getCurrentOwner());
			rsInvoker.post(ServiceConstants.YANK_CASE,
					caseRequestType, headerParams);

		} catch (Exception ex) {
			logger.error("exception occured takeOwnerShip in Service IMPL");
			RMDWebErrorHandler.handleException(ex);
		}
		return AppConstants.SUCCESS;
	}
}