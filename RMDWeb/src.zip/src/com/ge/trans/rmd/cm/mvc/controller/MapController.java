package com.ge.trans.rmd.cm.mvc.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ge.trans.rmd.cm.beans.MapBean;
import com.ge.trans.rmd.cm.service.MapService;
import com.ge.trans.rmd.cm.valueobjects.MapServiceVO;
import com.ge.trans.rmd.common.beans.FavoriteFilterBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.ResourceVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class MapController extends RMDBaseController {
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private AuthorizationService authorizationService;
	@Autowired
	private MapService mapObj;
	@Autowired
	ApplicationContext appContext;

	/**
	 * @Author:
	 * @return
	 * @Description: Displays the pinpoint map page(pinPointMap) of the RMD
	 *               application
	 */
	@RequestMapping(value = AppConstants.VIEW_MAP, method = RequestMethod.GET)
	public String getMap(final HttpServletRequest request,final Model model,final Locale locale) throws Exception {
		boolean assetSectionPrivilege = false;
		boolean rxSectionPrivilege = false;
		boolean legendComponentPrivilege=false;
		String roleName=RMDCommonConstants.EMPTY_STRING;
		final HttpSession session = request.getSession(false);
		try{
			
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			String assetSectionTooltip = authorizationService
					.getLookUpValueForName(AppConstants.MAP_TOOLTIP_ASSET);
			String rxSectionTooltip = authorizationService
					.getLookUpValueForName(AppConstants.MAP_TOOLTIP_OPENRX);
			/*For timezone issue*/ 
			final String defaultTimezone=(String)request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
			String applicationTimezone=RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone());
			/*For timezone issue*/
			//used to bring the component name from lookup
			String legendComponenet = authorizationService
			.getLookUpValueForName(AppConstants.LEGEND_MAP);
			List<ResourceVO> lstLegends=new ArrayList<ResourceVO>();
            
			assetSectionPrivilege = RMDCommonUtil.componentValue(
					userVO.getComponentList(), assetSectionTooltip);
			rxSectionPrivilege = RMDCommonUtil.componentValue(
					userVO.getComponentList(), rxSectionTooltip);
			
			Map<String, String> componentList = new HashMap<String, String>();
			componentList.put(AppConstants.RX_FILTER_URGENCY_MAP_PRIVILEGE,
					AppConstants.RX_FILTER_URGENCY);
			componentList.put(AppConstants.RX_FILTER_ESTREPTIME_MAP_PRIVILEGE,
					AppConstants.RX_FILTER_ESTREPTIME);
			componentList.put(AppConstants.RX_FILTER_RXTITLES_MAP_PRIVILEGE,
					AppConstants.RX_FILTER_APPROVEDRXTITLES);
			/*For case Type*/
			componentList.put(
					AppConstants.FILTER_CASETYPE_MAP_PRIVILEGE,
					AppConstants.RX_FILTER_CASETYPE);
			/*For case Type*/
			//For Fleet
			componentList.put(AppConstants.RX_FILTER_FLEET_MAP_PRIVILEGE,
					AppConstants.RX_FILTER_FLEET);
			//For Model
			componentList.put(AppConstants.RX_FILTER_MODEL_MAP_PRIVILEGE,
					AppConstants.RX_FILTER_MODEL);
			componentList.put(AppConstants.DEFAULT_FILTER_MAP_PRIVILEGE,
					AppConstants.DEFAULT_FILTER);
			componentList.put(AppConstants.RX_FILTER_ACTIONABLE_RXTYPE_FLEET_PRIVILEGE,
					AppConstants.RX_FILTER_ACTIONABLE_RXTYPE);
			// used to bring the component name from lookup
			getComponentPrivilege(componentList,userVO,request);
			legendComponentPrivilege = RMDCommonUtil.componentValue(
					userVO.getComponentList(), legendComponenet);
			// if legend component is present in the user component list we will
			// bring the legends
			if (legendComponentPrivilege) { 
				// used to bring the roleName for coreesponding ruleID
				roleName = RMDCommonUtil.getRoleName(userVO.getRolesVOLst(),
						userVO.getRoleId());
				if (!RMDCommonUtility.isNullOrEmpty(roleName)) {
					// used to bring the list of legends for the particular role
					// and user
					lstLegends = authorizationService
					.getLegendsForMap(AppConstants.MAP_LEGEND);
				}
			}
			// setting the lst of legends in model attribute(sprint 1 Phase 2)
			model.addAttribute(AppConstants.LEGENDS, lstLegends);
			request.setAttribute(AppConstants.MAP_TOOLTIPASSET,
					assetSectionPrivilege);
			request.setAttribute(AppConstants.MAP_TOOLTIPRX, rxSectionPrivilege);
			//Added for favorite filter story
			Map<String,Object> componentMap =new HashMap<String,Object>();
			componentMap.put(AppConstants.URGENCY_FAV_FILTER, request.getAttribute(AppConstants.RX_FILTER_URGENCY));
			componentMap.put(AppConstants.EST_REPAIR_TIME, request.getAttribute(AppConstants.RX_FILTER_ESTREPTIME));
			componentMap.put(AppConstants.RX_TITLE, request.getAttribute(AppConstants.RX_FILTER_APPROVEDRXTITLES));
			componentMap.put(AppConstants.COMPONENT_CASE_TYPE, request.getAttribute(AppConstants.RX_FILTER_CASETYPE));
			componentMap.put(AppConstants.COMPONENT_FLEET, request.getAttribute(AppConstants.RX_FILTER_FLEET));
			componentMap.put(AppConstants.COMPONENT_MODEL, request.getAttribute(AppConstants.RX_FILTER_MODEL));
			componentMap.put(AppConstants.RX_ACTIONABLE_TYPE, request.getAttribute(AppConstants.RX_FILTER_ACTIONABLE_RXTYPE));
			
			String favoriteFilters=getFavoriteFilters(AppConstants.MAP_OVERVIEW,userVO,componentMap);
			if(null!=favoriteFilters && !favoriteFilters.equals(AppConstants.EMPTY_STRING)&& (Boolean)request.getAttribute(AppConstants.DEFAULT_FILTER)){
				request.setAttribute(AppConstants.FAVORITE_FILTER, favoriteFilters);
				}	
		}catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getMap() method ",
					rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		}catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getMap method ",
					ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		}
		//Added for favorite filter story
		request.setAttribute(AppConstants.SELECTED_TAB, AppConstants.MAP_OVERVIEW);
		return AppConstants.RET_STR_MAP;

	}
	
	/**
	 * @Author:
	 * @return
	 * @Description: Displays the pinpoint map page(pinPointMap) of the RMD
	 *               application
	 */
	@RequestMapping(value = AppConstants.GET_MAP_REFRESH_DATE, method = RequestMethod.GET, produces = "text/html")
	public @ResponseBody
		String getMapRefreshDate(final HttpServletRequest request)
			throws Exception {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
			.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String defaultTimezone =EsapiUtil.stripXSSCharacters((String)request.getAttribute(AppConstants.DEFAULT_TIMEZONE));
	        String applicationTimezone = EsapiUtil.stripXSSCharacters(RMDCommonUtil.getTimezone(defaultTimezone, userVO.getTimeZone()));
		String customerId=EsapiUtil.stripXSSCharacters(userVO.getCustomerId());
		String lastRefreshTime = mapObj.getLastRefreshTime(
				AppConstants.MAP_LAST_REFRESH_TIME, applicationTimezone,customerId);
		return lastRefreshTime;
	}

	/**
	 * @Author:
	 * @return
	 * @Description: Displays the pinpoint map page(pinPointMap) of the RMD
	 *               application
	 */
	@RequestMapping(value = AppConstants.GET_MAP_ASSETS, method = RequestMethod.POST)
	public @ResponseBody
	List<MapServiceVO> getAssetStatus(
			final HttpServletRequest request,
			@RequestParam(value = AppConstants.QUERY_PARAM_URGENCY) final String urgency,
			@RequestParam(value = AppConstants.QUERY_PARAM_ESTREPTIME) final String estRepTime,
			@RequestParam(value = AppConstants.QUERY_PARAM_RX_IDS) final String rxIds,
			@RequestParam(value = AppConstants.QUERY_PARAM_FAV_FILTER) final String favFilter,
			@RequestParam(value = AppConstants.CASE_TYPE) final String caseType,
			@RequestParam(value = AppConstants.FLEET) final String fleet,
			@RequestParam(value = AppConstants.MODEL) final String model,
			@RequestParam(value = AppConstants.RX_TYPE) final String rxType)
			throws Exception {
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		/*For timezone issue*/ 
		final String defaultTimezone=EsapiUtil.stripXSSCharacters((String)request.getAttribute(AppConstants.DEFAULT_TIMEZONE));
		String applicationTimezone=RMDCommonUtil.getTimezone(defaultTimezone,userVO.getTimeZone());
		/*For timezone issue*/
		MapBean mapBean = new MapBean();
		Map<String, MapServiceVO> collectiveResponse = null;
		List<MapServiceVO> objMapServiceLst = new ArrayList<MapServiceVO>();
		FavoriteFilterBean favFilterBean=new FavoriteFilterBean();
		HashMap<String,String> columnTypes=new HashMap<String,String>();		
		HashMap<String,String> columnValues=new HashMap<String,String>();
		Long linkUserRoleSeqId=null;
		String filterId="";
		favFilterBean.setScreenName(AppConstants.MAP_OVERVIEW);
		try {
			mapBean.setUserLanguage(userVO.getStrUserLanguage());
			mapBean.setTimeZone(applicationTimezone);
			mapBean.setCustomerId(userVO.getCustomerId());
			mapBean.setTimeZoneChk(userVO.getTimeZone());
			if(null!=userVO.getProducts()&& !userVO.getProducts().isEmpty()){
				mapBean.setProducts(userVO.getProducts());
			}
			
			/**
			 * Based on the value in urgency and estRepTime keys, choosing the
			 * service method for filter
			 */
			if (null != urgency
					&& !RMDCommonConstants.EMPTY_STRING.equals(urgency)){
				mapBean.setUrgency(urgency);
				//Adding urgency criteria information for favorite filter
				columnTypes.put(AppConstants.URGENCY_FAV_FILTER, AppConstants.TEXT);
				columnValues.put(AppConstants.URGENCY_FAV_FILTER, urgency);
				}
			
			if (null != rxType
					&& !RMDCommonConstants.EMPTY_STRING.equals(rxType)&&!AppConstants.ZERO.equals(rxType)){
				mapBean.setActionableRxType(rxType);
				//Adding rxType criteria information for favorite filter
				columnTypes.put(AppConstants.RX_TYPE_FAV_FILTER, AppConstants.NUMBER);
				columnValues.put(AppConstants.RX_TYPE_FAV_FILTER, rxType);
				}
			if (null != estRepTime
					&& !RMDCommonConstants.EMPTY_STRING.equals(estRepTime)){
				mapBean.setEstRepTime(estRepTime);
				//Adding Estimated repair time criteria information for favorite filter
				columnTypes.put(AppConstants.EST_REPAIR_TIME, AppConstants.NUMBER);
				columnValues.put(AppConstants.EST_REPAIR_TIME, estRepTime);
			}
			if (null != rxIds
					&& !RMDCommonConstants.EMPTY_STRING.equals(rxIds)){
				mapBean.setRxIds(rxIds);
				//Adding RX Ids criteria information for favorite filter
				columnTypes.put(AppConstants.RX_TITLE, AppConstants.NUMBER);
				columnValues.put(AppConstants.RX_TITLE, rxIds);
			}
			
			if (null != caseType
					&& !RMDCommonConstants.EMPTY_STRING.equals(caseType)){
				mapBean.setCaseType(caseType);
				//Adding Case Type criteria information for favorite filter
				columnTypes.put(AppConstants.COMPONENT_CASE_TYPE, AppConstants.NUMBER);
				columnValues.put(AppConstants.COMPONENT_CASE_TYPE, caseType);
			}
			if (null != fleet
					&& !RMDCommonConstants.EMPTY_STRING.equals(fleet)){
				mapBean.setFleet(fleet);
				//Adding Fleet criteria information for favorite filter
				columnTypes.put(AppConstants.COMPONENT_FLEET, AppConstants.NUMBER);
				columnValues.put(AppConstants.COMPONENT_FLEET, fleet);
			}
			if (null != model
					&& !RMDCommonConstants.EMPTY_STRING.equals(model)){
				mapBean.setModel(model);
				//Adding Model criteria information for favorite filter
				columnTypes.put(AppConstants.COMPONENT_MODEL, AppConstants.NUMBER);
				columnValues.put(AppConstants.COMPONENT_MODEL, model);
			}
			//Call generic favorite filter method if atleast one column available
			if (!columnTypes.isEmpty()) {
				
				favFilterBean.setColumnType(columnTypes);
				favFilterBean.setColumnValue(columnValues);
			}

			filterId=getFilterId(AppConstants.MAP_OVERVIEW, userVO);
			if(null!=filterId && !filterId.equals(AppConstants.EMPTY_STRING)){
			favFilterBean.setFilterId(filterId);
			}
			favFilterBean.setFavFilterFlag(favFilter+"");
			linkUserRoleSeqId = getLinkUsrRoleSeqId(userVO.getRolesVOLst(),
					userVO.getRoleId());
			favFilterBean.setLinkUserRoleSeqId(linkUserRoleSeqId);
			callFavoriteFilter(favFilterBean);
			if(null!=userVO.getProducts()&& !userVO.getProducts().isEmpty()){
				collectiveResponse = mapObj.getMapPage(mapBean, userVO.getCustomerId());
				
				Collection collObject = collectiveResponse.values();
	
				// obtain an Iterator for Collection
				Iterator<MapServiceVO> itr = collObject.iterator();
	
				// iterate through HashMap values iterator to add the values in list
				while (itr.hasNext()) {
					objMapServiceLst.add(itr.next());
				}
				/*
				 * It sorts the assets based on the urgency
				 * We are setting the plotOrder for each asset based on their urgency
				 * and is used in ordering of assets. If open rx list of an asset is null, then
				 * irrespective of its urgency, the asset will be given lowest priority order
				 */
				for (int i = 0; i < objMapServiceLst.size(); i++) {
					for (int j = i + 1; j < objMapServiceLst.size(); j++) {
						if (objMapServiceLst.get(i).getOpenRxList() != null && 
								objMapServiceLst.get(j).getOpenRxList() == null) {
							MapServiceVO mapServiceVO = objMapServiceLst.get(j);
							objMapServiceLst.set(j, objMapServiceLst.get(i));
							objMapServiceLst.set(i, mapServiceVO);						
						}
						if (null != objMapServiceLst.get(i).getOpenRxList()
								&& null != objMapServiceLst.get(j).getOpenRxList()
								&& objMapServiceLst.get(i).getAssetPlotOrder() > 
								objMapServiceLst.get(j).getAssetPlotOrder()) {
							MapServiceVO mapServiceVO = objMapServiceLst.get(j);
							objMapServiceLst.set(j, objMapServiceLst.get(i));
							objMapServiceLst.set(i, mapServiceVO);						
						}
					}
				}
				rmdWebLogger.debug("MapController : collectiveResponse.size::: "
						+ collectiveResponse.size());
			}

		

			request.setAttribute(AppConstants.MAP_RESPONSE, objMapServiceLst);
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"RMDWebException occured in getAssetStatus() method ",
					rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);

		}
		return objMapServiceLst;

	}

}
