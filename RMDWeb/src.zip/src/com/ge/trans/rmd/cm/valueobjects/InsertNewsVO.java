package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

import com.ge.trans.rmd.common.valueobjects.BaseVO;

public class InsertNewsVO extends BaseVO {
	
	private static final long serialVersionUID = 1L;
	private List <String> customerarray;
    private String newsDesc;
    private String expiryDate;
    private String userId;
    private RecommDelvDocVO docDetails;
    private RecommDelvDocVO imgDetails;
    private String objId;
    private String status;
    private String fileRemoved;
    
    
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<String> getCustomerarray() {
		return customerarray;
	}
	public void setCustomerarray(List<String> customerarray) {
		this.customerarray = customerarray;
	}
	public String getNewsDesc() {
		return newsDesc;
	}
	public void setNewsDesc(String newsDesc) {
		this.newsDesc = newsDesc;
	}
	public String getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}
    public RecommDelvDocVO getDocDetails() {
        return docDetails;
    }
    public void setDocDetails(RecommDelvDocVO docDetails) {
        this.docDetails = docDetails;
    }
    public RecommDelvDocVO getImgDetails() {
        return imgDetails;
    }
    public void setImgDetails(RecommDelvDocVO imgDetails) {
        this.imgDetails = imgDetails;
    }
    public String getObjId() {
        return objId;
    }
    public void setObjId(String objId) {
        this.objId = objId;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public String getFileRemoved() {
        return fileRemoved;
    }
    public void setFileRemoved(String fileRemoved) {
        this.fileRemoved = fileRemoved;
    }
	
	
    
    
}
