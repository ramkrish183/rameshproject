package com.ge.trans.rmd.cm.valueobjects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.common.vo.RMDBaseVO;

/**
 * A custom POJO that will be automatically converted to JSON format. 
 * <p>We can use this to send generic messages to our DataScreen, whether a request is successful or not.
 * Of course, you will use plain JavaScript to parse the JSON response. 
 */
@SuppressWarnings("serial")
public class CreateCasesVO extends RMDBaseVO {

	private String solutionID;
	private String solutionTitle;
	private String solutionStatus;
	private String model;
	private String urgRepair;
	private String estmTimeRepair;
	private String version;
	private String assetNumber;
	private String customerId;
	private String customerName;
	private String assetGrpName;
	private String note;
	private List<String> assetList; 
	private String userFirstName;
	private String userLastName;
	private String userId;
	private String userLanguage;
	private String caseType;
	private SolutionDetailVO objSolutionDetailVO;
	private String isMassApplyRx;
	private String msdcNotes;
	private List<RecommDelvDocVO> arlRecommDelDocVO=new ArrayList<RecommDelvDocVO>();
	
	public List<RecommDelvDocVO> getArlRecommDelDocVO() {
		return arlRecommDelDocVO;
	}
	public void setArlRecommDelDocVO(List<RecommDelvDocVO> arlRecommDelDocVO) {
		this.arlRecommDelDocVO = arlRecommDelDocVO;
	}
	public String getMsdcNotes() {
		return msdcNotes;
	}
	public void setMsdcNotes(String msdcNotes) {
		this.msdcNotes = msdcNotes;
	}
	
	public String getIsMassApplyRx() {
		return isMassApplyRx;
	}
	public void setIsMassApplyRx(String isMassApplyRx) {
		this.isMassApplyRx = isMassApplyRx;
	}
	public SolutionDetailVO getObjSolutionDetailVO() {
		return objSolutionDetailVO;
	}
	public void setObjSolutionDetailVO(SolutionDetailVO objSolutionDetailVO) {
		this.objSolutionDetailVO = objSolutionDetailVO;
	}
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public String getUserLanguage() {
		return userLanguage;
	}
	public void setUserLanguage(String userLanguage) {
		this.userLanguage = userLanguage;
	}
	public String getUserFirstName() {
		return userFirstName;
	}
	public void setUserFirstName(String userFirstName) {
		this.userFirstName = userFirstName;
	}
	public String getUserLastName() {
		return userLastName;
	}
	public void setUserLastName(String userLastName) {
		this.userLastName = userLastName;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public List<String> getAssetList() {
		return assetList;
	}
	public void setAssetList(List<String> assetList) {
		this.assetList = assetList;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getNote() {
		return note;
	}
	public void setNote(String note) {
		this.note = note;
	}
	public String getAssetNumber() {
		return assetNumber;
	}
	public void setAssetNumber(String assetNumber) {
		this.assetNumber = assetNumber;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getAssetGrpName() {
		return assetGrpName;
	}
	public void setAssetGrpName(String assetGrpName) {
		this.assetGrpName = assetGrpName;
	}
	private Map<String, String> errorMsg;
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	
	public String getSolutionID() {
		return solutionID;
	}
	public void setSolutionID(String solutionID) {
		this.solutionID = solutionID;
	}
	public String getSolutionTitle() {
		return solutionTitle;
	}
	public void setSolutionTitle(String solutionTitle) {
		this.solutionTitle = solutionTitle;
	}
	public String getSolutionStatus() {
		return solutionStatus;
	}
	public void setSolutionStatus(String solutionStatus) {
		this.solutionStatus = solutionStatus;
	}
	public String getUrgRepair() {
		return urgRepair;
	}
	public void setUrgRepair(String urgRepair) {
		this.urgRepair = urgRepair;
	}
	public String getEstmTimeRepair() {
		return estmTimeRepair;
	}
	public void setEstmTimeRepair(String estmTimeRepair) {
		this.estmTimeRepair = estmTimeRepair;
	}
	public Map<String, String> getErrorMsg() {
		return errorMsg;
	}
	public void setErrorMsg(Map<String, String> errorMsg) {
		this.errorMsg = errorMsg;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	

	
}
