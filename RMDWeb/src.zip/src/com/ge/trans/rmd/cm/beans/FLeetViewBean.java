package com.ge.trans.rmd.cm.beans;

import com.ge.trans.rmd.common.beans.RMDBaseBean;

@SuppressWarnings("serial")
public class FLeetViewBean extends RMDBaseBean{

	private String customerId;
	private String kpiName;
	private String numDays;
	private String assetNoFrom;
	private String assetNoTo;
	private String noteType;
	private String timezone;
	private String urgencies;
	private String estRepTime;
	private String rxIds;
	private String caseType;
	private String fleet;
	private String model;
	private String actionableRxType;
	private boolean isLastFalult;
	
	public boolean isLastFalult() {
		return isLastFalult;
	}

	public void setLastFalult(boolean isLastFalult) {
		this.isLastFalult = isLastFalult;
	}

	public String getFleet() {
		return fleet;
	}

	public void setFleet(String fleet) {
		this.fleet = fleet;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getCaseType() {
		return caseType;
	}

	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}

	public String getRxIds() {
		return rxIds;
	}

	public void setRxIds(String rxIds) {
		this.rxIds = rxIds;
	}

	public String getUrgencies() {
		return urgencies;
	}

	public void setUrgencies(String urgencies) {
		this.urgencies = urgencies;
	}

	public String getEstRepTime() {
		return estRepTime;
	}

	public void setEstRepTime(String estRepTime) {
		this.estRepTime = estRepTime;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public String getKpiName() {
		return kpiName;
	}

	public void setKpiName(final String kpiName) {
		this.kpiName = kpiName;
	}

	public String getNumDays() {
		return numDays;
	}

	public void setNumDays(final String numDays) {
		this.numDays = numDays;
	}

	public String getAssetNoFrom() {
		return assetNoFrom;
	}

	public void setAssetNoFrom(final String assetNoFrom) {
		this.assetNoFrom = assetNoFrom;
	}

	public String getAssetNoTo() {
		return assetNoTo;
	}

	public void setAssetNoTo(final String assetNoTo) {
		this.assetNoTo = assetNoTo;
	}

	public String getNoteType() {
		return noteType;
	}

	public void setNoteType(final String noteType) {
		this.noteType = noteType;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(final String customerId) {
		this.customerId = customerId;
	}

	public String getActionableRxType() {
		return actionableRxType;
	}

	public void setActionableRxType(String actionableRxType) {
		this.actionableRxType = actionableRxType;
	}

	
}
