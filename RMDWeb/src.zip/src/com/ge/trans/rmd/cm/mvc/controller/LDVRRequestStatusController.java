package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.AssetOverviewService;
import com.ge.trans.rmd.cm.service.LDVRAssetStatusService;
import com.ge.trans.rmd.cm.service.LDVRRequestsService;
import com.ge.trans.rmd.cm.valueobjects.ActiveLcvLDVRCamDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.AssetLDVRDataVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetStatusRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetStatusResponseVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;

@Controller
@SessionAttributes
public class LDVRRequestStatusController extends RMDBaseController {
	final private RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private ApplicationContext appContext;
	@Autowired
	private LDVRRequestsService ldvrRequestsService;
	@Autowired
	private LDVRAssetStatusService ldvrAssetStatusService;
	@Autowired
	private AssetOverviewService asstOvwService;
	

	final SimpleDateFormat dateFormat = new SimpleDateFormat(RMDCommonConstants.ddMMyyyyHHmmss);
	/**
	 * @Author:
	 * @return
	 * @throws Exception
	 * @Description:
	 * 
	 */

	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description:
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_STATUS_PAGE, method = RequestMethod.GET)
	public ModelAndView getLDVRStatusPage(final HttpServletRequest request)
			throws RMDWebException {
		rmdWebLogger.info("Inside getLDVRStatusPage method");
		String fromDate;
		String toDate;
		
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String defaultTimezone =EsapiUtil.stripXSSCharacters( (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE));

		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());		
		
		final String strAssetNumber = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String strAssetGroup = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_GROUP_NAME));
		
		String strCustomerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_CUSID));
		
		dateFormat.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
		Calendar fromDtCal = Calendar.getInstance();
		fromDtCal.add(Calendar.DATE, -Integer.parseInt(RMDCommonConstants.THREE));
		fromDate = dateFormat.format(fromDtCal.getTime());
		rmdWebLogger.info("fromDate in getLDVRStatusPage " + fromDate);

		toDate = dateFormat.format(new Date());
		rmdWebLogger.info("toDate in getLDVRStatusPage " + toDate);		
	
		if(RMDCommonUtility.isNullOrEmpty(strCustomerId)){
			strCustomerId = asstOvwService.getCustomerId(strAssetNumber, strAssetGroup);			
		}		
		final String roadInitial = ldvrRequestsService.getRoadInitial(
				strCustomerId, strAssetNumber, strAssetGroup);

		request.setAttribute(AppConstants.REQ_PARAM_ASSTNUM, strAssetNumber);
		request.setAttribute(AppConstants.ASSET_GROUP_NAME, strAssetGroup);
		request.setAttribute(AppConstants.WS_PARAM_CUSTID, strCustomerId);
		request.setAttribute(AppConstants.LDVR_ROAD_INITIAL, roadInitial);
		request.setAttribute(AppConstants.FROM_DATE, fromDate);
		request.setAttribute(AppConstants.TO_DATE, toDate);		

		return new ModelAndView(AppConstants.VIEW_LDVR_STATUS);
	}

	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_STATUS, method = RequestMethod.POST)
	@ResponseBody public LDVRAssetStatusResponseVO getLDVRStatus(
			final HttpServletRequest request) throws Exception {
		rmdWebLogger.info("Inside getLDVRStatus method");
		LDVRAssetStatusResponseVO ldvrAssetStatusResponseVO = null;
		final String strAssetNumber = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String strRoadInitial =EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.LDVR_ROAD_INITIAL));
		final String strCustomerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_CUSID));
		final String strDaysToView = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.LDVR_STATUS_DAYS));
		final String strStatusFrom = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FROM_DATE));
		final String strStatusTo = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TO_DATE));

		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String defaultTimezone =EsapiUtil.stripXSSCharacters( (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE));

		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());		
		LDVRAssetStatusRequestVO ldvrAssetStatusRequestVO = new LDVRAssetStatusRequestVO();
		ldvrAssetStatusRequestVO.setAssetOwnerId(strCustomerId);
		if (RMDCommonUtility.isNullOrEmpty(strDaysToView))
		{			
			Date fromDt = RMDCommonUtility.stringToDate(strStatusFrom,
					RMDCommonConstants.ddMMyyyyHHmmss);

			Date toDt = RMDCommonUtility.stringToDate(strStatusTo,
					RMDCommonConstants.ddMMyyyyHHmmss);
			long diff = toDt.getTime() - fromDt.getTime();
			long days = TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);
			
			ldvrAssetStatusRequestVO.setDaysToView(String.valueOf(days));
		}else
			ldvrAssetStatusRequestVO.setDaysToView(strDaysToView);
		ldvrAssetStatusRequestVO.setDevice(AppConstants.LCV_DEVICE_TYPE);
		ldvrAssetStatusRequestVO.setRoadInitial(strRoadInitial);
		ldvrAssetStatusRequestVO.setRoadNumber(strAssetNumber);
		ldvrAssetStatusRequestVO.setTimeZone(applicationTimezone);
		try {
			ldvrAssetStatusResponseVO = ldvrAssetStatusService
					.getAssetLdvrStatus(ldvrAssetStatusRequestVO);

		}catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLDVRStatus  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}		
		return ldvrAssetStatusResponseVO;
	}
	/**
	  * 
	  * @param request
	  * @param response
	  * @param locale
	  * @throws RMDWebException
	  * @throws Exception
	  */
	@RequestMapping(value=AppConstants.EXPORT_LDVR_STATUS, method = RequestMethod.POST)
	@ResponseBody public void exportLDVRStatus(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws RMDWebException, Exception {
		LDVRAssetStatusResponseVO ldvrAssetStatusResponseVO = null;
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		try {
			ldvrAssetStatusResponseVO = getLDVRStatus(request);
			csvContent = convertToCSVLDVRStatus(ldvrAssetStatusResponseVO,
					locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.LDVR_STATUS_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);
			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);
			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error("Exception occured in exportLDVRStatus method ",
					rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in exportLDVRStatus method ",
					ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}

	/**
	 * @Description:This method is used convert ldvr status into csv format
	 * @return: String
	 * @param:List<LDVRAssetStatusResponseVO> ldvrAssetStatusResponseVO, Locale locale
	 * @throws RMDWebException 
	 * @throws GenericAjaxException 
	 */
	private String convertToCSVLDVRStatus(
			LDVRAssetStatusResponseVO ldvrAssetStatusResponseVO, Locale locale) throws GenericAjaxException, RMDWebException {
		String csvContent = null;
		StringBuilder strBuilderAssetHeader = new StringBuilder();
		try {
			strBuilderAssetHeader.append(appContext.getMessage(
					AppConstants.LDVR_STATUS_HEADER, null, locale));

			strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);

			AssetLDVRDataVO assetLDVRDataVO = ldvrAssetStatusResponseVO
						.getAssetLDVRData();

				if (null != assetLDVRDataVO) {
				

					List<ActiveLcvLDVRCamDetailsVO> activeLcvLDVRCamDetails = assetLDVRDataVO
							.getActiveLcvLDVRCamDetails();
					if (!CollectionUtils.isEmpty(activeLcvLDVRCamDetails)) {

						for (ActiveLcvLDVRCamDetailsVO assetCamDetails : assetLDVRDataVO
								.getActiveLcvLDVRCamDetails()) {
						
							if (assetCamDetails.getCameraNumber() != null) {
								strBuilderAssetHeader
										.append( AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ assetCamDetails
														.getCameraNumber()
												+ AppConstants.QUOTE);

							} else {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}

							if (assetCamDetails.getLdvrStatusTime() != null) {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ assetCamDetails
														.getLdvrStatusTime()
												+ AppConstants.QUOTE);

							} else {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}

							if (assetCamDetails.getLocation() != null) {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ assetCamDetails.getLocation()
												+ AppConstants.QUOTE);

							} else {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}

							if (assetCamDetails.getZeroSpeedStopped() != null) {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ assetCamDetails
														.getZeroSpeedStopped()
												+ AppConstants.QUOTE);

							} else {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}

							if (assetCamDetails.getExtDriveRemotelyStopped() != null) {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ assetCamDetails
														.getExtDriveRemotelyStopped()
												+ AppConstants.QUOTE);

							} else {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}

							if (assetCamDetails.getGpsSourceLoss() != null) {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ assetCamDetails
														.getGpsSourceLoss()
												+ AppConstants.QUOTE);

							} else {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}

							if (assetCamDetails.getSpeedSourceLoss() != null) {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ assetCamDetails
														.getSpeedSourceLoss()
												+ AppConstants.QUOTE);

							} else {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}

							if (assetCamDetails.getRecordingStatus() != null) {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ assetCamDetails
														.getRecordingStatus()
												+ AppConstants.QUOTE);

							} else {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}

							if (assetCamDetails.getExtDriveLatestFileTime() != null) {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ assetCamDetails
														.getExtDriveLatestFileTime()
												+ AppConstants.QUOTE);

							} else {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}
							
							if (assetCamDetails.getIntDriveKBFree() != null) {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ assetCamDetails
														.getIntDriveKBFree()
												+ AppConstants.QUOTE);

							} else {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}

							if (assetCamDetails.getExtDriveKBFree() != null) {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ assetCamDetails
														.getExtDriveKBFree()
												+ AppConstants.QUOTE);

							} else {
								strBuilderAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}
							
							strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);
							
							

						}
					}
				}
				
				csvContent = strBuilderAssetHeader.toString();
				
		} catch (Exception exception) {
			rmdWebLogger.error("Export to CSV LDVR Status :"
					+ exception.getMessage());
			RMDWebErrorHandler.handleException(exception);
		}
		return csvContent;
	}
	@RequestMapping(value=AppConstants.LDVR_STATUS_DATE_CHECK, method = RequestMethod.POST)
	 @ResponseBody public String checkStatusDate(final HttpServletRequest request)throws RMDWebException, Exception {
	
		try {

			final String strStatusFrom = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.FROM_DATE));
			final String strStatusTo =EsapiUtil.stripXSSCharacters( request
					.getParameter(AppConstants.TO_DATE));

			Date currentDate = RMDCommonUtility.stringToDate(
					dateFormat.format(new Date()),
					RMDCommonConstants.ddMMyyyyHHmmss);

			String standardDate = "01/01/1970 01:01:01";

			Date oldDate = RMDCommonUtility.stringToDate(standardDate,
					RMDCommonConstants.ddMMyyyyHHmmss);

			Date fromDt = RMDCommonUtility.stringToDate(strStatusFrom,
					RMDCommonConstants.ddMMyyyyHHmmss);

			Date toDt = RMDCommonUtility.stringToDate(strStatusTo,
					RMDCommonConstants.ddMMyyyyHHmmss);

			if (fromDt.compareTo(toDt) == 0) {
				throw new RMDWebException("01", "InvalidDateException",
						"statusFromDate and statusToDate should not be same ");
			}
			if (toDt.compareTo(fromDt) < 0) {
				throw new RMDWebException("01", "InvalidDateException",
						"statusFromDate should be less than statusToDate");
			}
			if (fromDt.compareTo(oldDate) < 0) {
				throw new RMDWebException("01", "InvalidDateException",
						"statusFromDate should not be before 01/01/1970");
			}

			Date nextStartTime = new Date(fromDt.getTime());
			Date nextEndTime = new Date(toDt.getTime());
			if (nextStartTime.after(currentDate)) {
				throw new RMDWebException("01", "InvalidDateException",
						"statusFromDate should not be future date");
			}
			if (nextEndTime.after(currentDate)) {
				throw new RMDWebException("01", "InvalidDateException",
						"statusToDate should not be future date");
			}
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in checkStatusDate  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return RMDCommonConstants.VALID;
	}
}

