package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.ConfigMaintenanceService;
import com.ge.trans.rmd.cm.valueobjects.AddEditEDPDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.ConfigTemplateDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.EDPHeaderDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.EDPParamDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.EDPSearchParamVO;
import com.ge.trans.rmd.cm.valueobjects.EFIDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.FFDDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.FRDDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.FaultFilterDefDetails;
import com.ge.trans.rmd.cm.valueobjects.FaultRangeDefDetails;
import com.ge.trans.rmd.cm.valueobjects.TemplateReportBean;
import com.ge.trans.rmd.cm.valueobjects.VerifyCfgTemplateVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
public class ConfigMaintenanceController extends RMDBaseController {

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());
	@Autowired
	ApplicationContext appContext;
	@Autowired
	ConfigMaintenanceService configMaintenanceService;
	@Autowired
    MassApplyCfgController massApplyCfgController;

	@RequestMapping(AppConstants.REQ_URI_CONFIG_MAINTENANCE)
	public ModelAndView showConfigMaintenancePage(
			final HttpServletRequest request) {
		rmdWebLogger
				.debug("Inside showConfigMaintenancePage method of ConfigMaintenanceController");
		return new ModelAndView(AppConstants.CONFIG_MAINTENANCE);
	}

	@RequestMapping(AppConstants.REQ_URI_CREATE_EFI)
	public ModelAndView showCreateEFIPage(final HttpServletRequest request) {
		rmdWebLogger
				.debug("Inside showCreateEFIPage method of ConfigMaintenanceController");
		return new ModelAndView(AppConstants.CREATE_EFI);
	}

	@RequestMapping(AppConstants.REQ_URI_ADD_UPADTE_EDP_TEMPLATE)
	public ModelAndView showEDPTemplatePage(final HttpServletRequest request)
			throws RMDWebException {
		rmdWebLogger
				.debug("Inside showEDPTemplatePage method of ConfigMaintenanceController");
		String ctrlCfgName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CTRL_CFG_NAME));
		String ctrlCfgObjId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CTRL_CFG_OBJ_ID));
		String cfgFileName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CFG_FILE_NAME));
		String currTempNo = configMaintenanceService.getMaxTemplateNumber(
				ctrlCfgObjId, cfgFileName);
		int newTempNo = (Integer.parseInt(currTempNo)) + 1;
		int versionNo = AppConstants.INT_ONE;
		request.setAttribute(AppConstants.CTRL_CFG_NAME, EsapiUtil.stripXSSCharacters(ctrlCfgName));
		request.setAttribute(AppConstants.CTRL_CFG_OBJ_ID, EsapiUtil.stripXSSCharacters(ctrlCfgObjId));
		request.setAttribute(AppConstants.CFG_FILE_NAME, EsapiUtil.stripXSSCharacters(cfgFileName));
		request.setAttribute(AppConstants.TEMPLATE_NO, newTempNo);
		request.setAttribute(AppConstants.VERSION_NO, versionNo);
		request.setAttribute(
				AppConstants.EDP_MAX_PARAMS,
				findNumberOfRecords(AppConstants.MAX_CONFIG_FILE_PARAMS_ALLOWED));
		return new ModelAndView(AppConstants.ADD_UPDATE_EDP);
	}

	@RequestMapping(AppConstants.REQ_URI_OPEN_EDP_TEMPLATE)
	public ModelAndView openEDPTemplate(final HttpServletRequest request)
			throws RMDWebException {
		EDPHeaderDetailsVO templateHeader = null;
		rmdWebLogger
				.debug("Inside openEDPTemplate method of ConfigMaintenanceController");
		String ctrlCfgName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CTRL_CFG_NAME));
		String ctrlCfgObjId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CTRL_CFG_OBJ_ID));
		String cfgFileName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CFG_FILE_NAME));
		String tempObjId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.TEMP_OBJ_ID));
		String templateNo = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.TEMPLATE_NO));
		String versionNo = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.VERSION_NO));
		String title = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.TITLE));

		templateHeader = configMaintenanceService.getPreNextEDPDetails(
				cfgFileName, templateNo, versionNo, ctrlCfgObjId);
		String status = templateHeader.getStatus();
		String maxVersion = configMaintenanceService.getTempMaxVerNumber(
				ctrlCfgObjId, cfgFileName, templateNo);
		request.setAttribute(AppConstants.CTRL_CFG_NAME, EsapiUtil.stripXSSCharacters(ctrlCfgName));
		request.setAttribute(AppConstants.CTRL_CFG_OBJ_ID, EsapiUtil.stripXSSCharacters(ctrlCfgObjId));
		request.setAttribute(AppConstants.CFG_FILE_NAME, EsapiUtil.stripXSSCharacters(cfgFileName));
		request.setAttribute(AppConstants.TEMP_OBJ_ID, EsapiUtil.stripXSSCharacters(tempObjId));
		request.setAttribute(AppConstants.TEMPLATE_NO, EsapiUtil.stripXSSCharacters(templateNo));
		request.setAttribute(AppConstants.VERSION_NO, EsapiUtil.stripXSSCharacters(versionNo));
		request.setAttribute(AppConstants.TITLE, EsapiUtil.stripXSSCharacters(title));
		request.setAttribute(AppConstants.MAX_VERSION, EsapiUtil.stripXSSCharacters(maxVersion));
		request.setAttribute(AppConstants.STATUS, EsapiUtil.stripXSSCharacters(status));
		request.setAttribute(AppConstants.IS_OPEN_TEMPLATE, true);
		request.setAttribute(
				AppConstants.EDP_MAX_PARAMS,
				findNumberOfRecords(AppConstants.MAX_CONFIG_FILE_PARAMS_ALLOWED));
		templateHeader = null;
		return new ModelAndView(AppConstants.ADD_UPDATE_EDP);
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the all controller configs
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_CONTROLLER_CONFIGS)
	@ResponseBody
	public Map<String, String> getControllerConfigs() throws RMDWebException {
		Map<String, String> ctrlCfgMap = new LinkedHashMap<String, String>();
		try {
			ctrlCfgMap = configMaintenanceService.getControllerConfigs();
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getControllerConfigs() method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return ctrlCfgMap;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the all controller config
	 *               files
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_CONTROLLER_CONFIG_FILES)
	@ResponseBody
	public Map<String, String> getConfigFiles() throws RMDWebException {
		Map<String, String> ctrlCfgMap = new LinkedHashMap<String, String>();
		try {
			ctrlCfgMap = configMaintenanceService.getConfigFiles();
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getConfigFiles() method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return ctrlCfgMap;
	}

	/**
	 * 
	 * @param ctrlCfgObjId
	 *            , cfgFile
	 * @return ConfigTemplateDetailsVO
	 * @throws RMDWebException
	 * @Description This method is used to get the Templates for the selected
	 *              Controller Config and Config File.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_CONFIG_TEMPLATE_DETAILS, method = RequestMethod.GET)
	@ResponseBody
	public List<ConfigTemplateDetailsVO> getCtrlCfgTemplates(
			@RequestParam(value = AppConstants.CTRL_CFG_OBJ_ID) final String ctrlCfgObjId,
			@RequestParam(value = AppConstants.CFG_FILE_NAME) final String cfgFileName,
			final HttpServletRequest request) throws RMDWebException {
		List<ConfigTemplateDetailsVO> templateList = null;
		try {
			if (!RMDCommonUtility.isNullOrEmpty(ctrlCfgObjId)
					&& !RMDCommonUtility.isNullOrEmpty(cfgFileName)) {
				templateList = configMaintenanceService.getCtrlCfgTemplates(
						EsapiUtil.stripXSSCharacters(ctrlCfgObjId),
						EsapiUtil.stripXSSCharacters(cfgFileName));
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getCtrlCfgTemplates method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return templateList;

	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the existing EFI templates
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_EFI_DETAILS)
	@ResponseBody
	public List<EFIDetailsVO> getEFIDetails() throws RMDWebException {
		List<EFIDetailsVO> efiList = null;
		try {
			efiList = configMaintenanceService.getEFIDetails();
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getEFIDetails() method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return efiList;
	}

	/**
	 * @Author:
	 * @param:userName
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for creating new EFI templates
	 */
	@RequestMapping(value = AppConstants.CREATE_NEW_EFI, method = RequestMethod.POST)
	@ResponseBody
	public String createNewEFI(final HttpServletRequest request)
			throws RMDWebException {
		String result = AppConstants.FAILURE;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			result = configMaintenanceService.createNewEFI(EsapiUtil
					.stripXSSCharacters(userVO.getCmAliasName()));
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in createNewEFI() method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the status for EDP
	 *               templates
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_CTRL_CFG_STATUS)
	@ResponseBody
	public Map<String, String> getCtrlCfgStatus() throws RMDWebException {
		Map<String, String> ctrlCfgStatusMap = new LinkedHashMap<String, String>();
		try {
			ctrlCfgStatusMap = configMaintenanceService.getCtrlCfgStatus();
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getCtrlCfgStatus() method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return ctrlCfgStatusMap;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the SearchBy dropdown
	 *               values for EDP templates
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_EDP_SEARCH_BY_LIST)
	@ResponseBody
	public Map<String, String> getEDPSearchByOptions() throws RMDWebException {
		Map<String, String> edpSearchgMap = new LinkedHashMap<String, String>();
		try {
			edpSearchgMap = configMaintenanceService.getEDPSearchByOptions();
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getEDPSearchByOptions() method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return edpSearchgMap;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the Condition dropdown
	 *               values for EDP template
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_EDP_CONDITION_LIST)
	@ResponseBody
	public Map<String, String> getEDPConditionOptions() throws RMDWebException {
		Map<String, String> edpConditionMap = new LinkedHashMap<String, String>();
		try {
			edpConditionMap = configMaintenanceService.getEDPConditionOptions();
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getEDPConditionOptions() method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return edpConditionMap;
	}

	/**
	 * @Author:
	 * @param:ctrlCfgObjId, cfgFileName
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the latest template Number
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_MAX_TEMPLATE_NUMBER)
	@ResponseBody public
	String getMaxTemplateNumber(
			@RequestParam(value = AppConstants.CTRL_CFG_OBJ_ID) final String ctrlCfgObjId,
			@RequestParam(value = AppConstants.CFG_FILE_NAME) final String cfgFileName,
			final HttpServletRequest request) throws RMDWebException {
		String maxtempNo = null;
		try {
			maxtempNo = configMaintenanceService.getMaxTemplateNumber(
					EsapiUtil.stripXSSCharacters(ctrlCfgObjId),
					EsapiUtil.stripXSSCharacters(cfgFileName));
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getMaxTemplateNumber() method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return maxtempNo;
	}

	/**
	 * @Author:
	 * @param:ctrlCfgObjId, cfgFileName,templateNo
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the latest version number
	 *               of the opened template
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_TEMPLATE_MAX_VER_NUMBER)
	@ResponseBody
	public String getTempMaxVerNumber(
			@RequestParam(value = AppConstants.CTRL_CFG_OBJ_ID) final String ctrlCfgObjId,
			@RequestParam(value = AppConstants.CFG_FILE_NAME) final String cfgFileName,
			@RequestParam(value = AppConstants.TEMPLATE_NO) final String templateNo,
			final HttpServletRequest request) throws RMDWebException {
		String tempMaxVerNo = null;
		try {
			tempMaxVerNo = configMaintenanceService.getTempMaxVerNumber(
					EsapiUtil.stripXSSCharacters(ctrlCfgObjId),
					EsapiUtil.stripXSSCharacters(cfgFileName),
					EsapiUtil.stripXSSCharacters(templateNo));
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getTempMaxVerNumber() method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return tempMaxVerNo;
	}

	/**
	 * 
	 * @param searchBy
	 *            ,condition,searchVal,ctrlCfgObjId, cfgFile
	 * @return List<ConfigTemplateDetailsVO>
	 * @throws RMDWebException
	 * @Description This method is used to get the parameters that can be added
	 *              for EDP templates.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_EDP_PARAM_DETAILS, method = RequestMethod.POST)
	@ResponseBody
	public List<EDPParamDetailsVO> getEDPParameters(
			@RequestParam(value = AppConstants.SEARCH_BY) final String searchBy,
			@RequestParam(value = AppConstants.CONDITION) final String condition,
			@RequestParam(value = AppConstants.SEARCH_VAL) final String searchVal,
			@RequestParam(value = AppConstants.CTRL_CFG_OBJ_ID) final String ctrlCfgObjId,
			@RequestParam(value = AppConstants.CFG_FILE_NAME) final String cfgFileName,
			final HttpServletRequest request) throws RMDWebException {

		EDPSearchParamVO objEDPSearchParamVO = new EDPSearchParamVO();
		List<EDPParamDetailsVO> paramList = null;
		try {

			if (!RMDCommonUtility.isNullOrEmpty(searchBy)) {
				objEDPSearchParamVO.setSearchBy(EsapiUtil
						.stripXSSCharacters(searchBy));
			}
			if (!RMDCommonUtility.isNullOrEmpty(condition)) {
				objEDPSearchParamVO.setCondition(EsapiUtil
						.stripXSSCharacters(condition));
			}
			if (!RMDCommonUtility.isNullOrEmpty(searchVal)) {
				objEDPSearchParamVO.setSearchVal(EsapiUtil
						.stripXSSCharacters(searchVal));
			}
			if (!RMDCommonUtility.isNullOrEmpty(ctrlCfgObjId)) {
				objEDPSearchParamVO.setCtrlCfgObjId(EsapiUtil
						.stripXSSCharacters(ctrlCfgObjId));
			}
			if (!RMDCommonUtility.isNullOrEmpty(cfgFileName)) {
				objEDPSearchParamVO.setCfgFileName(EsapiUtil
						.stripXSSCharacters(cfgFileName));
			}

			paramList = configMaintenanceService
					.getEDPParameters(objEDPSearchParamVO);

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getEDPParameters method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return paramList;

	}

	/**
	 * @Author:
	 * @param:tempObjId
	 * @return:List< EDPParamDetailsVO >
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the opened template added
	 *               parameters
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_ADDED_EDP_PARAMS)
	@ResponseBody
	public List<EDPParamDetailsVO> getAddedEDPParams(
			@RequestParam(value = AppConstants.TEMP_OBJ_ID) final String tempObjId,
			final HttpServletRequest request) throws RMDWebException {
		List<EDPParamDetailsVO> paramList = null;
		try {
			paramList = configMaintenanceService.getAddedEDPParams(EsapiUtil
					.stripXSSCharacters(tempObjId));
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getAddedEDPParams() method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return paramList;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for creating or updating EDP templates
	 */
	@RequestMapping(value = AppConstants.ADD_UPDATE_EDP_TEMPLATE, method = RequestMethod.POST)
	@ResponseBody
	public String saveEDPTemplate(
			@RequestParam(value = AppConstants.TEMP_OBJ_ID) final String tempObjId,
			@RequestParam(value = AppConstants.CTRL_CFG_OBJ_ID) final String ctrlCfgObjId,
			@RequestParam(value = AppConstants.CFG_FILE_NAME) final String cfgFileName,
			@RequestParam(value = AppConstants.PARAM_OBJ_ID) final String paramObjId,
			@RequestParam(value = AppConstants.ADDED_PARAM_OBJ_ID) final String addedObjId,
			@RequestParam(value = AppConstants.REMOVED_PARAM_OBJ_ID) final String removedObjId,
			@RequestParam(value = AppConstants.TEMPLATE_NO) final String templateNo,
			@RequestParam(value = AppConstants.VERSION_NO) final String versionNo,
			@RequestParam(value = AppConstants.STATUS) final String status,
			@RequestParam(value = AppConstants.TITLE) final String title,
			@RequestParam(value = AppConstants.WHAT_NEW) final String whatNew,
			final HttpServletRequest request) throws RMDWebException {
		String result = AppConstants.FAILURE;
		AddEditEDPDetailsVO objAddEditEDPDetailsVO = new AddEditEDPDetailsVO();
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {

			if (!RMDCommonUtility.isNullOrEmpty(tempObjId)) {
				objAddEditEDPDetailsVO.setTempObjId(EsapiUtil
						.stripXSSCharacters(tempObjId));
			}
			if (!RMDCommonUtility.isNullOrEmpty(ctrlCfgObjId)) {
				objAddEditEDPDetailsVO.setCtrlCfgObjId(EsapiUtil
						.stripXSSCharacters(ctrlCfgObjId));
			}
			if (!RMDCommonUtility.isNullOrEmpty(cfgFileName)) {
				objAddEditEDPDetailsVO.setCfgFileName(EsapiUtil
						.stripXSSCharacters(cfgFileName));
			}
			if (!RMDCommonUtility.isNullOrEmpty(paramObjId)) {
				objAddEditEDPDetailsVO.setParamObjId(EsapiUtil
						.stripXSSCharacters(paramObjId));
			}
			if (!RMDCommonUtility.isNullOrEmpty(addedObjId)) {
				objAddEditEDPDetailsVO.setAddedParamObjId(EsapiUtil
						.stripXSSCharacters(addedObjId));
			}
			if (!RMDCommonUtility.isNullOrEmpty(removedObjId)) {
				objAddEditEDPDetailsVO.setRemovedParamObjId(EsapiUtil
						.stripXSSCharacters(removedObjId));
			}
			if (!RMDCommonUtility.isNullOrEmpty(templateNo)) {
				objAddEditEDPDetailsVO.setTemplateNo(EsapiUtil
						.stripXSSCharacters(templateNo));
			}
			if (!RMDCommonUtility.isNullOrEmpty(versionNo)) {
				objAddEditEDPDetailsVO.setVersionNo(EsapiUtil
						.stripXSSCharacters(versionNo));
			}
			if (!RMDCommonUtility.isNullOrEmpty(status)) {
				objAddEditEDPDetailsVO.setStatus(EsapiUtil
						.stripXSSCharacters(status));
			}
			if (!RMDCommonUtility.isNullOrEmpty(title)) {
				objAddEditEDPDetailsVO.setTitle(EsapiUtil
						.stripXSSCharacters(title));
			}
			if (!RMDCommonUtility.isNullOrEmpty(whatNew)) {
				objAddEditEDPDetailsVO.setWhatNew(EsapiUtil
						.stripXSSCharacters(whatNew));
			}
			objAddEditEDPDetailsVO.setUserName(userVO.getCmAliasName());
			result = configMaintenanceService
					.saveEDPTemplate(objAddEditEDPDetailsVO);
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in saveEDPTemplate() method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:EDPHeaderDetailsVO
	 * @throws:RMDWebException
	 * @Description: This method is used for getting the Next/Previous EDP
	 *               template templates
	 */
	@RequestMapping(value = AppConstants.GET_PRE_NEXT_EDP_DETAILS, method = RequestMethod.GET)
	@ResponseBody
	public EDPHeaderDetailsVO getPreNextEDPDetails(
			@RequestParam(value = AppConstants.CFG_FILE_NAME) final String cfgFileName,
			@RequestParam(value = AppConstants.TEMPLATE_NO) final String templateNo,
			@RequestParam(value = AppConstants.VERSION_NO) final String versionNo,
			@RequestParam(value = AppConstants.CTRL_CFG_OBJ_ID) final String ctrlCfgObjId,
			final HttpServletRequest request) throws RMDWebException {
		EDPHeaderDetailsVO templateHeader = null;
		try {
			templateHeader = configMaintenanceService.getPreNextEDPDetails(
					EsapiUtil.stripXSSCharacters(cfgFileName),
					EsapiUtil.stripXSSCharacters(templateNo),
					EsapiUtil.stripXSSCharacters(versionNo),
					EsapiUtil.stripXSSCharacters(ctrlCfgObjId));
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getPreNextEDPDetails() method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return templateHeader;
	}

	/**
	 * @Author:
	 * @param:HttpServletRequest request
	 * @return:
	 * @throws:RMDWebException
	 * @Description: This method is used for exporting Template details to CSV
	 *               Format.
	 */

	@RequestMapping(AppConstants.EXPORT_CFG_TEMPLATES)
	@ResponseBody
	public void exportCfgTemplateDetails(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws RMDWebException, Exception {
		List<ConfigTemplateDetailsVO> templateList = null;
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		try {
			final String ctrlCfgObjId = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.CTRL_CFG_OBJ_ID));
			final String cfgFileName = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.CFG_FILE_NAME));
			templateList = configMaintenanceService.getCtrlCfgTemplates(
					ctrlCfgObjId, cfgFileName);
			if (null != templateList && !templateList.isEmpty()) {
				request.setAttribute(AppConstants.TEMPLATE_LIST, templateList);
				csvContent = convertToCSVTemplateReport(templateList, locale);
				response.setContentType(AppConstants.CONTENT_TYPE);
				response.setHeader(AppConstants.CONTENT,
						AppConstants.ATTACH_FILENAME
								+ AppConstants.CFG_TEMPLATE_EXPORT_FILENAME);
				objServletOutputStream = response.getOutputStream();
				ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
						csvContent.getBytes());
				objBufferedInputStream = new BufferedInputStream(
						objByteArrayInputStream);
				objBufferedOutputStream = new BufferedOutputStream(
						objServletOutputStream);
				byte[] byteArr = new byte[2048];
				int bytesread;

				while ((bytesread = objBufferedInputStream.read(byteArr, 0,
						byteArr.length)) != -1) {
					objBufferedOutputStream.write(byteArr, 0, bytesread);
					objBufferedOutputStream.flush();
				}
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in exportProximityDetails() method ",
							rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in exportProximityDetails method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}

	private String convertToCSVTemplateReport(
			List<ConfigTemplateDetailsVO> templateList, Locale locale) {
		StringBuilder strTempDetailsBuffer = new StringBuilder();
		String csvContent = null;
		try {

			strTempDetailsBuffer.append(appContext
					.getMessage(AppConstants.CTRL_CFG_TEMPLATES_REPORT_HEADER,
							null, locale));

			strTempDetailsBuffer.append(RMDCommonConstants.NEWLINE);
			if (RMDCommonUtility.isCollectionNotEmpty(templateList)) {
				for (ConfigTemplateDetailsVO objConfigTemplateDetailsVO : templateList) {

					strTempDetailsBuffer
							.append(RMDCommonUtil
									.removeHtmlandNullValues(objConfigTemplateDetailsVO
											.getTemplateNo())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objConfigTemplateDetailsVO
													.getVersionNo())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objConfigTemplateDetailsVO
													.getTitle())
									+ RMDCommonConstants.COMMMA_SEPARATOR
									+ RMDCommonUtil
											.removeHtmlandNullValues(objConfigTemplateDetailsVO
													.getStatus()));

					strTempDetailsBuffer.append(RMDCommonConstants.NEWLINE);
				}

			}

			csvContent = strTempDetailsBuffer.toString();
		} catch (Exception ex) {
			
			rmdWebLogger.error("Export to CSV convertToCSVTemplateReport"
					+ ex);
		}
		return csvContent;
	}
	
	private String convertToCSV(
			List<ConfigTemplateDetailsVO> templateList, Locale locale) {
		StringBuilder strTempDetailsBuffer = new StringBuilder();
		String csvContent = null;
		try {
			rmdWebLogger.debug("Start convertToCSV() Template Report Screen");
			strTempDetailsBuffer.append(appContext
					.getMessage(AppConstants.TEMPLATES_REPORT_HEADER,
							null, locale));
			strTempDetailsBuffer.append(RMDCommonConstants.NEWLINE);
			if (RMDCommonUtility.isCollectionNotEmpty(templateList)) {
				for (ConfigTemplateDetailsVO objConfigTemplateDetailsVO : templateList) {
					strTempDetailsBuffer.append(RMDCommonUtil.removeHtmlandNullValues(objConfigTemplateDetailsVO.getCustomerId()));
					strTempDetailsBuffer.append(RMDCommonConstants.COMMMA_SEPARATOR);
					strTempDetailsBuffer.append(RMDCommonUtil.removeHtmlandNullValues(objConfigTemplateDetailsVO.getRoadNumberHdr()));
					strTempDetailsBuffer.append(RMDCommonConstants.COMMMA_SEPARATOR);
					strTempDetailsBuffer.append(RMDCommonUtil.removeHtmlandNullValues(objConfigTemplateDetailsVO.getRoadNumber()));
					strTempDetailsBuffer.append(RMDCommonConstants.COMMMA_SEPARATOR);
					strTempDetailsBuffer.append(RMDCommonUtil.removeHtmlandNullValues(objConfigTemplateDetailsVO.getControllerConfig()));
					strTempDetailsBuffer.append(RMDCommonConstants.COMMMA_SEPARATOR);
					strTempDetailsBuffer.append(RMDCommonUtil.removeHtmlandNullValues(objConfigTemplateDetailsVO.getConfigFile()));
					strTempDetailsBuffer.append(RMDCommonConstants.COMMMA_SEPARATOR);
					strTempDetailsBuffer.append(RMDCommonUtil.removeHtmlandNullValues(objConfigTemplateDetailsVO.getTemplateNo()));
					strTempDetailsBuffer.append(RMDCommonConstants.COMMMA_SEPARATOR);
					strTempDetailsBuffer.append(RMDCommonUtil.removeHtmlandNullValues(objConfigTemplateDetailsVO.getVersionNo()));
					strTempDetailsBuffer.append(RMDCommonConstants.COMMMA_SEPARATOR);
					strTempDetailsBuffer.append(RMDCommonUtil.removeHtmlandNullValues(objConfigTemplateDetailsVO.getTitle()));
					strTempDetailsBuffer.append(RMDCommonConstants.COMMMA_SEPARATOR);
					strTempDetailsBuffer.append(RMDCommonUtil.removeHtmlandNullValues(objConfigTemplateDetailsVO.getStatus()));
					strTempDetailsBuffer.append(RMDCommonConstants.COMMMA_SEPARATOR);
					strTempDetailsBuffer.append(RMDCommonUtil.removeHtmlandNullValues(objConfigTemplateDetailsVO.getOffBoardStatus()));
					strTempDetailsBuffer.append(RMDCommonConstants.COMMMA_SEPARATOR);
					strTempDetailsBuffer.append(RMDCommonUtil.removeHtmlandNullValues(objConfigTemplateDetailsVO.getOnBoardStatus()));
					strTempDetailsBuffer.append(RMDCommonConstants.COMMMA_SEPARATOR);
					strTempDetailsBuffer.append(RMDCommonUtil.removeHtmlandNullValues(objConfigTemplateDetailsVO.getOnBoardStatusDate()));
					strTempDetailsBuffer.append(RMDCommonConstants.NEWLINE);
				}

			}
			rmdWebLogger.debug("End convertToCSV() Template Report Screen");
			csvContent = strTempDetailsBuffer.toString();
		} catch (Exception ex) {			
			rmdWebLogger.error("Export to CSV convertToCSV"
					+ ex);
		}
		return csvContent;
	}

	@RequestMapping(AppConstants.REQ_URI_VIEW_FFD_TEMPLATE_PAGE)
	public ModelAndView viewFFDTemplatePage(final HttpServletRequest request) {
		rmdWebLogger
				.debug("Inside ViewFFDTemplatePage method of ConfigMaintenanceController");

		request.setAttribute(AppConstants.CONFIG_VALUE,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CONFIG_VALUE)));
		request.setAttribute(AppConstants.CONFIG_ID,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CONFIG_ID)));
		request.setAttribute(AppConstants.TEMPLATE_ID,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TEMPLATE_ID)));
		request.setAttribute(AppConstants.VERSION_ID,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.VERSION_ID)));
		request.setAttribute(AppConstants.TITLE,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TITLE)));
		request.setAttribute(AppConstants.STATUS,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.STATUS)));
		request.setAttribute(AppConstants.CONFIG_FILE,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CONFIG_FILE)));
		request.setAttribute(AppConstants.FLAG,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG)));
		return new ModelAndView(AppConstants.FAULT_FILTER_DEF);
	}

	@RequestMapping(AppConstants.REQ_URI_VIEW_FRD_TEMPLATE_PAGE)
	public ModelAndView ViewFRDTemplatePage(final HttpServletRequest request) {
		rmdWebLogger
				.debug("Inside ViewFRDTemplatePage method of ConfigMaintenanceController");
		Map<String, String> components = new HashMap<String, String>();
		components.put(AppConstants.CONFIG_VALUE,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CONFIG_VALUE)));
		components.put(AppConstants.CONFIG_ID,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CONFIG_ID)));
		components.put(AppConstants.TEMPLATE_ID,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TEMPLATE_ID)));
		components.put(AppConstants.VERSION_ID,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.VERSION_ID)));
		components.put(AppConstants.TITLE,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TITLE)));
		components.put(AppConstants.STATUS,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.STATUS)));
		components.put(AppConstants.CONFIG_FILE,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CONFIG_FILE)));
		components.put(AppConstants.FLAG,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG)));
		components.put(AppConstants.TEMP_OBJ_ID,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TEMP_OBJ_ID)));
		request.setAttribute(AppConstants.DATASET, components);
		return new ModelAndView(AppConstants.FAULT_RANGE_DEF);
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching parameter title value
	 */
	@RequestMapping(value = AppConstants.GET_PARAMETER_TITLE)
	@ResponseBody
	public Map<String, String> getParameterTitle(HttpServletRequest request)
			throws RMDWebException {
		String configId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CONFIGID));
		Map<String, String> parameterTitle = null;
		Map<String, String> sortParameterTitle = new LinkedHashMap<String, String>();
		try {
			parameterTitle = configMaintenanceService
					.getParameterTitle(configId);
			sortParameterTitle = SortMapKey(parameterTitle);
		} catch (Exception e) {
			rmdWebLogger.error(
					"Exception occured in getConfigItemsList method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		finally
		{
			parameterTitle = null;
		}
		return sortParameterTitle;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching operator list values from
	 *               Look up table
	 */
	@RequestMapping(value = AppConstants.GET_OPERATOR_LIST)
	@ResponseBody
	public Map<String, String> getOperatorList() throws RMDWebException {
		Map<String, String> operatorList = null;
		try {
			operatorList = configMaintenanceService.getOperatorList();
		} catch (Exception e) {
			rmdWebLogger.error("Exception occured in operatorList method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return operatorList;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching conjunction list values
	 *               from Look up table
	 */
	@RequestMapping(value = AppConstants.GET_CONJUNCTION_LIST)
	@ResponseBody
	public Map<String, String> getConjunctionList() throws RMDWebException {
		Map<String, String> conjunctionList = null;
		try {
			conjunctionList = configMaintenanceService.getConjunctionList();
		} catch (Exception e) {
			rmdWebLogger.error(
					"Exception occured in getConjunctionList method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return conjunctionList;
	}

	/**
	 * 
	 * @param
	 * @return List<FaultFilterDefDetails>
	 * @throws RMDWebException
	 * @Description * This method is used for fetching FFD Template details.
	 *              This method will be invoked through ajax call.
	 * 
	 */
	@RequestMapping(value = AppConstants.POPULATE_FFD_DETAILS)
	@ResponseBody
	public java.util.List<FaultFilterDefDetails> populateFFDDetails(
			@RequestParam(value = AppConstants.CONFIG_ID) final String configId,
			@RequestParam(value = AppConstants.TEMPLATE_ID) final String templateId,
			@RequestParam(value = AppConstants.VERSION_ID) final String versionId,
			final HttpServletRequest request) throws RMDWebException {
		List<FaultFilterDefDetails> faultFilterDefDetails = new ArrayList<FaultFilterDefDetails>();
		try {
			faultFilterDefDetails = configMaintenanceService
					.populateFFDDetails(EsapiUtil.stripXSSCharacters(configId),
							EsapiUtil.stripXSSCharacters(templateId),
							EsapiUtil.stripXSSCharacters(versionId));

		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in populateFFDDetails() method - ConfigMaintenanceController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return faultFilterDefDetails;

	}

	/**
	 * 
	 * @param
	 * @return List<FaultRangeDefDetails>
	 * @throws RMDWebException
	 * @Description * This method is used for fetching FRD Template details.
	 *              This method will be invoked through ajax call.
	 * 
	 */
	@RequestMapping(value = AppConstants.POPULATE_FRD_DETAILS)
	@ResponseBody
	public java.util.List<FaultRangeDefDetails> populateFRDDetails(
			@RequestParam(value = AppConstants.GET_PARAMETER_STRING) final String parameterString,
			final HttpServletRequest request) throws RMDWebException {
		List<FFDDetailsVO> frdDetailsVO = new ArrayList<FFDDetailsVO>();
		List<FaultRangeDefDetails> faultRangeDefDetails = new ArrayList<FaultRangeDefDetails>();
		final ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			FFDDetailsVO[] arrFFDDetailsVO = mapper.readValue(
					EsapiUtil.stripXSSCharacters(parameterString),
					FFDDetailsVO[].class);
			frdDetailsVO = Arrays.asList(arrFFDDetailsVO);
			faultRangeDefDetails = configMaintenanceService
					.populateFRDDetails(frdDetailsVO);

		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in populateFRDDetails() method - ConfigMaintenanceController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return faultRangeDefDetails;

	}

	/**
	 * 
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description * This method is used for save FFD Template details in
	 *              database. This method will be invoked through ajax call.
	 * 
	 */
	@RequestMapping(value = AppConstants.SAVE_FFD_TEMPLATE)
	@ResponseBody
	public String saveFFDTemplate(
			@RequestParam(value = AppConstants.GET_PARAMETER_STRING) final String parameterString,
			final HttpServletRequest request) throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<FaultFilterDefDetails> faultFilterDefDetails = new ArrayList<FaultFilterDefDetails>();
		final ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			FaultFilterDefDetails[] arrFaultFilterDefDetails = mapper
					.readValue(EsapiUtil.stripXSSCharacters(parameterString),
							FaultFilterDefDetails[].class);
			faultFilterDefDetails = Arrays.asList(arrFaultFilterDefDetails);
			status = configMaintenanceService
					.saveFFDTemplate(faultFilterDefDetails);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("RMDWebException occured in saveFFDTemplate() method - ConfigMaintenanceController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return status;

	}

	/**
	 * 
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description * This method is used for save FRD Template details in
	 *              database. This method will be invoked through ajax call.
	 * 
	 */
	@RequestMapping(value = AppConstants.SAVE_FRD_TEMPLATE)
	@ResponseBody
	public String saveFRDTemplate(
			@RequestParam(value = AppConstants.GET_PARAMETER_STRING) final String parameterString,
			final HttpServletRequest request) throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<FaultRangeDefDetails> faultRangeDefDetails = new ArrayList<FaultRangeDefDetails>();
		final ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			FaultRangeDefDetails[] arrFaultRangeDefDetails = mapper.readValue(
					EsapiUtil.stripXSSCharacters(parameterString),
					FaultRangeDefDetails[].class);
			faultRangeDefDetails = Arrays.asList(arrFaultRangeDefDetails);
			status = configMaintenanceService
					.saveFRDTemplate(faultRangeDefDetails);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("RMDWebException occured in saveFRDTemplate() method - ConfigMaintenanceController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return status;

	}

	/**
	 * 
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description * This method is used for remove FRD Template details in
	 *              database. This method will be invoked through ajax call.
	 * 
	 */
	@RequestMapping(value = AppConstants.REMOVE_FRD_TEMPLATE)
	@ResponseBody
	public String removeFRDTemplate(
			@RequestParam(value = AppConstants.GET_PARAMETER_STRING) final String parameterString,
			final HttpServletRequest request) throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<FFDDetailsVO> objFFDDetailsVO = new ArrayList<FFDDetailsVO>();
		final ObjectMapper mapper = new ObjectMapper();

		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			FFDDetailsVO[] arrFFDDetailsVO = mapper.readValue(
					EsapiUtil.stripXSSCharacters(parameterString),
					FFDDetailsVO[].class);
			objFFDDetailsVO = Arrays.asList(arrFFDDetailsVO);
			status = configMaintenanceService
					.removeFRDTemplate(objFFDDetailsVO);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("RMDWebException occured in removeFRDTemplate() method - ConfigMaintenanceController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return status;

	}

	/**
	 * 
	 * @param
	 * @return String
	 * @throws RMDWebException
	 * @Description * This method is used for remove FFD Template details in
	 *              database. This method will be invoked through ajax call.
	 * 
	 */
	@RequestMapping(value = AppConstants.REMOVE_FFD_TEMPLATE)
	@ResponseBody
	public String removeFFDTemplate(
			@RequestParam(value = AppConstants.GET_PARAMETER_STRING) final String parameterString,
			final HttpServletRequest request) throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<FFDDetailsVO> objFFDDetailsVO = new ArrayList<FFDDetailsVO>();
		final ObjectMapper mapper = new ObjectMapper();

		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			FFDDetailsVO[] arrFFDDetailsVO = mapper.readValue(
					EsapiUtil.stripXSSCharacters(parameterString),
					FFDDetailsVO[].class);
			objFFDDetailsVO = Arrays.asList(arrFFDDetailsVO);
			status = configMaintenanceService
					.removeFFDTemplate(objFFDDetailsVO);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("RMDWebException occured in removeFFDTemplate() method - ConfigMaintenanceController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return status;

	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching EDP template list
	 */
	@RequestMapping(value = AppConstants.GET_EDP_TEMPLATE)
	@ResponseBody
	public Map<String, String> getEDPTemplate(HttpServletRequest request)
			throws RMDWebException {
		String configId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CONFIGID));
		Map<String, String> edpTemplate = null;
		Map<String, String> sortEDPTemplate = new LinkedHashMap<String, String>();
		try {
			edpTemplate = configMaintenanceService.getEDPTemplate(configId);
			sortEDPTemplate = SortMapValues(edpTemplate);
		} catch (Exception e) {
			rmdWebLogger
					.error("Exception occured in getEDPTemplate method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		finally
		{
			edpTemplate = null;
		}
		return sortEDPTemplate;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Map<String,String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching Fault Source value list.
	 */
	@RequestMapping(value = AppConstants.GET_FAULT_SOURCE)
	@ResponseBody
	public Map<String, String> getFaultSource(HttpServletRequest request)
			throws RMDWebException {
		String configId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CONFIGID));
		String configValue = EsapiUtil.stripXSSCharacters(request
				.getParameter("config_value"));
		Map<String, String> faultSourceId = null;
		Map<String, String> sortFaultSourceId = new LinkedHashMap<String, String>();
		try {
			faultSourceId = configMaintenanceService.getFaultSource(configId,
					configValue);
			sortFaultSourceId = SortMapValues(faultSourceId);
		} catch (Exception e) {
			rmdWebLogger
					.error("Exception occured in getFaultSource method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		finally
		{
			faultSourceId = null;
		}
		return sortFaultSourceId;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:List<FRDDetailsVO>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching default values of
	 *               pre,post,bias details.
	 */
	@RequestMapping(value = AppConstants.GET_DEFAULT_VALUES_RANGE)
	@ResponseBody
	public List<FRDDetailsVO> getDefaultValuesRange() throws RMDWebException {
		List<FRDDetailsVO> frdDetailsVO = null;
		try {
			frdDetailsVO = configMaintenanceService.getDefaultValuesRange();
		} catch (Exception e) {
			rmdWebLogger.error(
					"Exception occured in getDefaultValuesRange method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return frdDetailsVO;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Integer
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching maximum version value
	 */
	@RequestMapping(value = AppConstants.GET_MAX_VERSION)
	@ResponseBody
	public int getMaxVersion(HttpServletRequest request)
			throws RMDWebException {
		String configId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CONFIG_ID));
		String templateId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.TEMPLATE_ID));
		String configFile = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CONFIG_FILE));
		int maxVersionNum = 0;
		try {
			maxVersionNum = configMaintenanceService.getMaximumVersion(
					configId, templateId, configFile);
		} catch (Exception e) {
			rmdWebLogger.error("Exception occured in getMaxVersion method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return maxVersionNum;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Integer
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching current template value
	 */
	@RequestMapping(value = AppConstants.GET_CURRENT_TEMPLATE)
	@ResponseBody
	public int getCurrentTemplete(HttpServletRequest request)
			throws RMDWebException {
		String configId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CONFIG_ID));
		String configFile = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CONFIG_FILE));
		int currentTemplate = 0;
		try {
			currentTemplate = configMaintenanceService.getCurrentTemplate(
					configId, configFile);
		} catch (Exception e) {
			rmdWebLogger.error(
					"Exception occured in getCurrentTemplete method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return currentTemplate;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching current status value
	 */
	@RequestMapping(value = AppConstants.GET_CURRENT_STATUS)
	@ResponseBody
	public String getCurrentStatus(HttpServletRequest request)
			throws RMDWebException {
		String configId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CONFIG_ID));
		String templateId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.TEMPLATE_ID));
		String versionId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.VERSION_ID));
		String status = null;
		try {
			status = configMaintenanceService.getCurrentStatus(configId,
					templateId, versionId);
		} catch (Exception e) {
			rmdWebLogger.error("Exception occured in getMaxVersion method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return status;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching title value
	 */
	@RequestMapping(value = AppConstants.GET_TITLE)
	@ResponseBody
	public String getTitle(HttpServletRequest request) throws RMDWebException {
		String configId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CONFIG_ID));
		String templateId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.TEMPLATE_ID));
		String versionId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.VERSION_ID));
		String title = null;
		try {
			title = configMaintenanceService.getTitle(configId, templateId,
					versionId);
		} catch (Exception e) {
			rmdWebLogger.error("Exception occured in getTitle method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return title;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Integer
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching status of template
	 */
	@RequestMapping(value = AppConstants.GET_STATUS_DETAILS)
	@ResponseBody
	public List<FFDDetailsVO> getStatusDetails(HttpServletRequest request)
			throws RMDWebException {
		String configId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CONFIG_ID));
		String templateId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.TEMPLATE_ID));
		String versionId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.VERSION_ID));
		List<FFDDetailsVO> status = null;
		try {
			status = configMaintenanceService.getStatusDetails(configId,
					templateId, versionId);
		} catch (Exception e) {
			rmdWebLogger.error("Exception occured in getStatusDetails method ",
					e);
			RMDWebErrorHandler.handleException(e);
		}
		return status;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:String
	 * @throws:RMDWebException
	 * @Description: This method is used for check the fault range details
	 */
	@RequestMapping(value = AppConstants.CHECK_FAULT_RANGE)
	@ResponseBody public
	String checkFaultRange(
			@RequestParam(value = AppConstants.GET_PARAMETER_STRING) final String parameterString,
			final HttpServletRequest request) throws RMDWebException {
		String status = AppConstants.FAILURE;
		List<FaultRangeDefDetails> objFRDDetailsVO = new ArrayList<FaultRangeDefDetails>();
		final ObjectMapper mapper = new ObjectMapper();

		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			FaultRangeDefDetails[] arrFFDDetailsVO = mapper.readValue(
					EsapiUtil.stripXSSCharacters(parameterString), FaultRangeDefDetails[].class);
			objFRDDetailsVO = Arrays.asList(arrFFDDetailsVO);
			status = configMaintenanceService.checkFaultRange(objFRDDetailsVO);

		} catch (Exception ex) {
			status = AppConstants.FAILURE;
			rmdWebLogger
					.error("RMDWebException occured in removeFFDTemplate() method - ConfigMaintenanceController.java",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return status;
	}

	/**
	 * @Author:
	 * @param:
	 * @return:Integer
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching maximum parameter allowed
	 *               for template count
	 */
	@RequestMapping(value = AppConstants.GET_MAX_PARAMETER_COUNT)
	@ResponseBody public
	String getMaxParameterCount(HttpServletRequest request)
			throws RMDWebException {
		String maxParameterCount = null;
		try {
			maxParameterCount = configMaintenanceService.getMaxParameterCount();
		} catch (Exception e) {
			rmdWebLogger.error(
					"Exception occured in getMaxParameterCount method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return maxParameterCount;
	}
	
	@RequestMapping(AppConstants.REQ_URI_TEMPLATE_REPORT)
	public ModelAndView showtemplateReportScreen(@RequestParam(value = AppConstants.CTRL_CFG_OBJ_ID) final String ctrlCfgObjId,
			@RequestParam(value = AppConstants.CONFIG_FILE) final String configFileName,Model model, HttpServletRequest request) {
		rmdWebLogger.debug("Inside showtemplateReportScreen method of ConfigMaintenanceController");
		int versionNo = AppConstants.INT_ONE;
		model.addAttribute(AppConstants.VERSION_NO, versionNo);
		model.addAttribute(RMDCommonConstants.CTRL_CFG_OBJID,ctrlCfgObjId);
		model.addAttribute(AppConstants.CONFIG_FILE,configFileName);
		model.addAttribute(AppConstants.SCREEN_NAME,AppConstants.ONLOAD);
		return new ModelAndView(AppConstants.TEMPLATE_REPORT);
	}
	
	/**
	 * 
	 * @param controllerId
	 * @param configType
	 * @return ConfigTemplateDetailsVO
	 * @throws RMDWebException
	 * @Description This method is used to get the Templates for the selected
	 *              Controller Config and Config File.
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_TEMPLATE_REPORT, method = RequestMethod.GET)
	@ResponseBody
	public List<ConfigTemplateDetailsVO> getTemplateReport(@RequestParam(value = RMDCommonConstants.TEMPLATE_REPORT_FORMDATA, required = true) final String templateSearchFormValues,
			@RequestParam(value = RMDCommonConstants.CONTROLLER_ID) final String controllerId,
			@RequestParam(value = RMDCommonConstants.CONFIG_TYPE) final String configType,
			@RequestParam(value = RMDCommonConstants.SCREENNAME) final String action)
			throws RMDWebException {
		List<ConfigTemplateDetailsVO> templateList = null;
		final ObjectMapper mapper = new ObjectMapper();
		TemplateReportBean templateReportBean =null;
		try {
			
			if(action!=null && action.equals(AppConstants.ONLOAD)){
				templateReportBean =new TemplateReportBean();
				templateReportBean.setControllerConfigId(controllerId);
				templateReportBean.setConfigFile(configType);
			}
			else{
				mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
				templateReportBean  = mapper.readValue(templateSearchFormValues,
						TemplateReportBean.class);				
			}			
			
			if (!RMDCommonUtility.checkNull(templateReportBean)) {
				templateList = configMaintenanceService.getTemplateReport(templateReportBean);
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getCtrlCfgTemplates method of ConfigMaintenanceController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return templateList;

	}
	
	
	/**
	 * @Author:
	 * @param:HttpServletRequest request
	 * @return:
	 * @throws:RMDWebException
	 * @Description: This method is used for downloading Template report to CSV
	 *               Format.
	 */

	@RequestMapping(AppConstants.DOWNLOAD_TEMPLATE_REPORT)
	@ResponseBody
	public void downloadTemplateReport(
			@RequestParam(value = RMDCommonConstants.TEMPLATE_REPORT_FORMDATA, required = true) final String templateSearchFormValues,
			final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws RMDWebException, Exception {
		List<ConfigTemplateDetailsVO> templateList = null;
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		final ObjectMapper mapper = new ObjectMapper();
		TemplateReportBean templateReportBean =null;
		rmdWebLogger.info("START downloadTemplateReport() - TemplateReport Screen");
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			System.out.println(templateSearchFormValues);
			templateReportBean  = mapper.readValue(templateSearchFormValues,
					TemplateReportBean.class);		
			if (!RMDCommonUtility.checkNull(templateReportBean)) {
				templateList = configMaintenanceService.getTemplateReport(templateReportBean);
			}
			if(RMDCommonUtility.isCollectionNotEmpty(templateList)){
				request.setAttribute(AppConstants.TEMPLATE_LIST, templateList);
				csvContent = convertToCSV(templateList, locale);
				response.setContentType(AppConstants.CONTENT_TYPE);
				response.setHeader(AppConstants.CONTENT,
						AppConstants.ATTACH_FILENAME
								+ AppConstants.TEMPLATE_REPORT_FILENAME);
				objServletOutputStream = response.getOutputStream();
				ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
						csvContent.getBytes());
				objBufferedInputStream = new BufferedInputStream(
						objByteArrayInputStream);
				objBufferedOutputStream = new BufferedOutputStream(
						objServletOutputStream);
				byte[] byteArr = new byte[2048];
				int bytesread;
				while ((bytesread = objBufferedInputStream.read(byteArr, 0,
						byteArr.length)) != -1) {
					objBufferedOutputStream.write(byteArr, 0, bytesread);
					objBufferedOutputStream.flush();
				}
			}
			rmdWebLogger.info("END downloadTemplateReport() - TemplateReport Screen");
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error("RMDWebException occured in downloadTemplateReport() method ",
							rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in downloadTemplateReport method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}
		}

	}
	
	@RequestMapping(AppConstants.REQ_URI_CREATE_RCI_TEMPLATE)
    public ModelAndView showRCITemplatePage(final HttpServletRequest request)
            throws RMDWebException {
        rmdWebLogger
                .debug("Inside showRCITemplatePage method of ConfigMaintenanceController");
        String ctrlCfgName = EsapiUtil.stripXSSCharacters(request
                .getParameter(AppConstants.CTRL_CFG_NAME));
        String ctrlCfgObjId = EsapiUtil.stripXSSCharacters(request
                .getParameter(AppConstants.CTRL_CFG_OBJ_ID));
        String cfgFileName = EsapiUtil.stripXSSCharacters(request
                .getParameter(AppConstants.CFG_FILE_NAME));
        request.setAttribute(AppConstants.CTRL_CFG_NAME, EsapiUtil.stripXSSCharacters(ctrlCfgName));
        request.setAttribute(AppConstants.CTRL_CFG_OBJ_ID, EsapiUtil.stripXSSCharacters(ctrlCfgObjId));
        request.setAttribute(AppConstants.CFG_FILE_NAME, EsapiUtil.stripXSSCharacters(cfgFileName));
        return new ModelAndView(AppConstants.ADD_UPDATE_RCI);
    }
	
	@RequestMapping(AppConstants.REQ_URI_OPEN_RCI_TEMPLATE)
    public ModelAndView openRCITemplate(final HttpServletRequest request)
            throws RMDWebException {
        rmdWebLogger
                .debug("Inside openRCITemplate method of ConfigMaintenanceController");
        String ctrlCfgName = EsapiUtil.stripXSSCharacters(request
                .getParameter(AppConstants.CTRL_CFG_NAME));
        String ctrlCfgObjId = EsapiUtil.stripXSSCharacters(request
                .getParameter(AppConstants.CTRL_CFG_OBJ_ID));
        String cfgFileName = EsapiUtil.stripXSSCharacters(request
                .getParameter(AppConstants.CFG_FILE_NAME));
        String tempObjId = EsapiUtil.stripXSSCharacters(request
                .getParameter(AppConstants.TEMP_OBJ_ID));
        String templateNo = EsapiUtil.stripXSSCharacters(request
                .getParameter(AppConstants.TEMPLATE_NO));
        String versionNo = EsapiUtil.stripXSSCharacters(request
                .getParameter(AppConstants.VERSION_NO));
        
        List<VerifyCfgTemplateVO> arlRCIVo=massApplyCfgController.verifyConfigTemplates("", "", "", "", tempObjId, "", "", request);
 
        request.setAttribute(AppConstants.CTRL_CFG_NAME, ctrlCfgName);
        request.setAttribute(AppConstants.CTRL_CFG_OBJ_ID, ctrlCfgObjId);
        request.setAttribute(AppConstants.CFG_FILE_NAME, cfgFileName);
        request.setAttribute(AppConstants.TEMP_OBJ_ID, tempObjId);
        request.setAttribute(AppConstants.TEMPLATE_NO, templateNo);
        request.setAttribute(AppConstants.VERSION_NO, versionNo);
        request.setAttribute(AppConstants.TITLE, EsapiUtil.stripXSSCharacters(arlRCIVo.get(0).getTitle()));
        request.setAttribute(AppConstants.STATUS, EsapiUtil.stripXSSCharacters(arlRCIVo.get(0).getStatus()));
        request.setAttribute(AppConstants.FAULT_CODE, EsapiUtil.stripXSSCharacters(arlRCIVo.get(0).getFaultCode()));
        request.setAttribute(AppConstants.FILENAME, EsapiUtil.stripXSSCharacters(arlRCIVo.get(0).getFileName()));
        request.setAttribute(AppConstants.FILE_CONTENT, EsapiUtil.stripXSSCharacters(arlRCIVo.get(0).getFileContent()));
        //request.setAttribute("objTemp", arlRCIVo.get(0));
        request.setAttribute(AppConstants.IS_OPEN_TEMPLATE, true);
        
        return new ModelAndView(AppConstants.ADD_UPDATE_RCI);
    }
	
	
	@RequestMapping(value="/saveRCITemplate",method=RequestMethod.POST)
    @ResponseBody
    public String saveRCITemplate(@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString,
            final HttpServletRequest request) throws RMDWebException{
        final ObjectMapper mapper = new ObjectMapper();
        TemplateReportBean templateReportBean = null;   
        String status = AppConstants.FAILURE;
        final HttpSession session = request.getSession(false);
        final UserVO userVO = (UserVO) session
                .getAttribute(AppConstants.ATTR_USER_OBJECT);
        try {
            mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
            templateReportBean = mapper.readValue(EsapiUtil.stripXSSCharacters(parameterString),
                    TemplateReportBean.class);
            if(null!=templateReportBean){ 
                templateReportBean.setUserName(userVO.getCmAliasName());
                status=configMaintenanceService.saveRCITemplate(templateReportBean);
            }
        } catch (Exception ex) {
            status = AppConstants.FAILURE;
            rmdWebLogger
                    .error("RMDWebException occured in saveRCITemplate() method - ConfigMaintenanceController.java",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }   
        return status;
    }
	
	/**
     * @Author :
     * @return :String
     * @param : String tempObjId
     * @throws :RMDWebException
     * @Description: This method is Responsible for updating the RCI template
     * 
     */
    @RequestMapping(AppConstants.UPDATE_RCI_TEMPLATE)
    @ResponseBody
    public String deleteRCITemplate(@RequestParam(value=AppConstants.TEMP_OBJ_ID) String tempObjId,
            @RequestParam(value=AppConstants.TEMPLATE_NO) String templateNo,
            @RequestParam(value=AppConstants.VERSION_NO) String versionNo,
            @RequestParam(value=AppConstants.STATUS) String status,
            final HttpServletRequest request) throws RMDWebException{
        String result = RMDCommonConstants.EMPTY_STRING;
        final HttpSession session = request.getSession(false);
        final UserVO userVO = (UserVO) session
                .getAttribute(AppConstants.ATTR_USER_OBJECT);
        try{
                result = configMaintenanceService.updateRCITemplate(tempObjId,templateNo,versionNo,userVO.getCmAliasName(),status);
            
        }catch(Exception ex) {
            rmdWebLogger.error("Exception occured in updateRCITemplate() method ",ex);
            RMDWebErrorHandler.handleException(ex);
            
        }
        
        return result;
        
    }
    
    /**
     * 
     * @param controllerId
     * @param configType
     * @return ConfigTemplateDetailsVO
     * @throws RMDWebException
     * @Description This method is used to get the Templates for the selected
     *              Controller Config and Config File.
     * 
     */
    @RequestMapping(value = AppConstants.REQ_URI_GET_RCI_APPLIED_ASSETS, method = RequestMethod.GET)
    @ResponseBody
    public List<ConfigTemplateDetailsVO> getRCIAppliedAssets(
            @RequestParam(value = RMDCommonConstants.CFG_FILE_NAME) final String cfgFileName,
            @RequestParam(value = RMDCommonConstants.CTRL_CFG_OBJID) final String ctrlCfgObjId,
            @RequestParam(value = RMDCommonConstants.TEMPLATE_NO) final String templateNo,
            @RequestParam(value = RMDCommonConstants.VERSION_NO) final String versionNo)
            throws RMDWebException {
        List<ConfigTemplateDetailsVO> arlAppliedAssets = null;
        TemplateReportBean templateReportBean =null;
        try {
            
                templateReportBean =new TemplateReportBean();
                templateReportBean.setControllerConfigId(ctrlCfgObjId);
                templateReportBean.setConfigFile(cfgFileName);
                templateReportBean.setTemplateNumber(templateNo);
                templateReportBean.setTemplateVersion(versionNo);
                    
            
            if (!RMDCommonUtility.checkNull(templateReportBean)) {
                arlAppliedAssets = configMaintenanceService.getTemplateReport(templateReportBean);
            }
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getRCIAppliedAssets method of ConfigMaintenanceController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }

        return arlAppliedAssets;

    }
	

}
