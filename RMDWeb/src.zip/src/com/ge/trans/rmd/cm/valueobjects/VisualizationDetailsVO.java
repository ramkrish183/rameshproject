package com.ge.trans.rmd.cm.valueobjects;

import java.util.ArrayList;
import java.util.List;

public class VisualizationDetailsVO {

	private String parmNumber;
	private String parmDescription;
	private List<VisualizationParmDetailsVO> arlParmdetails=new ArrayList<VisualizationParmDetailsVO>();
	public String getParmNumber() {
		return parmNumber;
	}
	public void setParmNumber(String parmNumber) {
		this.parmNumber = parmNumber;
	}
	public String getParmDescription() {
		return parmDescription;
	}
	public void setParmDescription(String parmDescription) {
		this.parmDescription = parmDescription;
	}
	public List<VisualizationParmDetailsVO> getArlParmdetails() {
		return arlParmdetails;
	}
	public void setArlParmdetails(List<VisualizationParmDetailsVO> arlParmdetails) {
		this.arlParmdetails = arlParmdetails;
	}
	
	
	
}
