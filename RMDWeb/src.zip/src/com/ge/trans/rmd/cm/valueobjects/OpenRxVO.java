package com.ge.trans.rmd.cm.valueobjects;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.ge.trans.rmd.common.vo.RMDBaseVO;

@JsonSerialize(include=JsonSerialize.Inclusion.NON_NULL)
public class OpenRxVO extends RMDBaseVO{

	private static final long serialVersionUID = 1L;
	private String 	rxcaseid;
	private String 	caseId;
	private String rxTitle;
	private String creationDate;
	private String repairTime;
	private String locoImpact;
	private String owner;
	private String delvDate;
	private String age;
	private String rxUrgency;

	
	public String getRxUrgency() {
		return rxUrgency;
	}
	public void setRxUrgency(String rxUrgency) {
		this.rxUrgency = rxUrgency;
	}
	public String getCaseId() {
		return caseId;
	}
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getDelvDate() {
		return delvDate;
	}
	public void setDelvDate(String delvDate) {
		this.delvDate = delvDate;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	
	
	public String getRxcaseid() {
		return rxcaseid;
	}
	public void setRxcaseid(String rxcaseid) {
		this.rxcaseid = rxcaseid;
	}
	public String getRxTitle() {
		return rxTitle;
	}
	public void setRxTitle(String rxTitle) {
		this.rxTitle = rxTitle;
	}
	public String getCreationDate() {
		return creationDate;
	}
	public void setCreationDate(String creationDate) {
		this.creationDate = creationDate;
	}
	public String getRepairTime() {
		return repairTime;
	}
	public void setRepairTime(String repairTime) {
		this.repairTime = repairTime;
	}
	public String getLocoImpact() {
		return locoImpact;
	}
	public void setLocoImpact(String locoImpact) {
		this.locoImpact = locoImpact;
	}
	/**
	 * 
	 */
	
	
	
}
