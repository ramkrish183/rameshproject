package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.valueobjects.MdscStartUpControllersVO;
import com.ge.trans.rmd.cm.valueobjects.VehicleCfgTemplateVO;
import com.ge.trans.rmd.cm.valueobjects.VehicleCfgVO;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface VehicleCfgService {
	
	public List<VehicleCfgVO> getVehicleBOMConfigs (String customer,String rnh,String roadNumber) throws RMDWebException;
    public List<String> getMDSCStartUpControllerNames() throws RMDWebException;
    public MdscStartUpControllersVO getMDSCStartUpControllersInfo(String customer,String rnh,String roadNumber) throws RMDWebException;
    public String saveVehicleBOMConfigs(List<VehicleCfgVO> VehicleCfgTemplate,CaseBean objcaseBean ,String isCaseVehicleConfig) throws RMDWebException;
    public List<VehicleCfgTemplateVO> getVehicleCfgTemplates(String customer,String rnh,String roadNumber) throws RMDWebException;
		/**
	 * @Author :
	 * @return :String
	 * @param : VehicleCfgTemplateVO
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for Deleting vehicle
	 *               Configuration Template.
	 * 
	 */

	public String deleteVehicleCfgTemplate(
			VehicleCfgTemplateVO objVehicleCfgTemplateVO)
			throws RMDWebException;
	
	/**
	 * @Author :
	 * @return :List<String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for Deleting vehicle
	 *               Configuration Template.
	 * 
	 */
	
	public List<String> getConfigFiles() throws RMDWebException;

	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching controller configs
	 * 
	 */
	public Map<String, String> getControllerConfigs() throws RMDWebException;

	/**
	 * @Author :
	 * @return :List<VehicleCfgTemplateVO>
	 * @param : String,String
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching controller configs
	 *               templates
	 * 
	 */
	public List<VehicleCfgTemplateVO> getControllerConfigTemplates(
			String cntrlCnfg, String cnfgFile) throws RMDWebException;

	/**
	 * @Author :
	 * @return :String
	 * @param : List<VehicleCfgTemplateVO>
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for Deleting vehicle
	 *               Configuration Template.
	 * 
	 */
	public String deleteVehicleCfg(List<VehicleCfgTemplateVO> tempList)
			throws RMDWebException;
	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching Lookup value tooltip
	 * 
	 */
	public Map<String, String> getLookupValueTooltip() throws RMDWebException;
	
	/**
     * @Author :
     * @return :String
     * @param : String
     * @throws :RMDWebException
     * @Description: This method is Responsible for reApply vehicle
     *               Configuration Template.
     * 
     */
    public String reApplyTemplate(VehicleCfgTemplateVO objVehicleCfgTemplateVO)throws RMDWebException;
    
    /**
     * @Author :
     * @return :String
     * @param : String vehStatusObjId,String userId
     * @throws :RMDWebException
     * @Description: This method is Responsible for re notify vehicle
     *               Configuration Template.
     * 
     */
    public String reNotifyTemplateAssociation(String vehStatusObjId,String userId) throws RMDWebException;

}
