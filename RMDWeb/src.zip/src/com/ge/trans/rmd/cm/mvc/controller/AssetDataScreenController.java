/**
 /**
 * ============================================================
 * Classification: GE Confidential
 * File : AssetDataScreenController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.cm.controller;
 * Author : iGATE Global Solutions Ltd.
 * Last Edited By :
 * Version : 1.0
 * Created on : February 14, 2012
 * History
 * Modified By : iGATE
 *
 * Copyright (C) 2012 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.Future;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.trans.rmd.cm.beans.AssetFaultDataBean;
import com.ge.trans.rmd.cm.mvc.model.ColModel;
import com.ge.trans.rmd.cm.mvc.model.LatestCases;
import com.ge.trans.rmd.cm.mvc.model.RuleBean;
import com.ge.trans.rmd.cm.service.AssetCasesService;
import com.ge.trans.rmd.cm.service.AssetDataScreenService;
import com.ge.trans.rmd.cm.service.AssetOverviewService;
import com.ge.trans.rmd.cm.valueobjects.AssetDataResponseVO;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.CaseBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;

@Controller
public class AssetDataScreenController extends RMDBaseController {

	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());
	@Autowired
	private AssetDataScreenService objAssetDataScreenService;
	@Autowired
	private AuthorizationService authService;
	@Autowired
	private CachedService cachedService;
	
	@Autowired
	private AssetOverviewService asstOvwService;
	@Autowired
	private AssetCasesService assetCasesService;
	
	@Value("${" + AppConstants.FAULT_ANALYSIS_MANUAL_URL + "}")
	String faultAnalysisManualUrl;
	@Value("${" + AppConstants.ESERVICES_URL + "}")
	String eServicesUrl;
	@Value("${" + AppConstants.EDIT_RX_URL + "}")
	String editRxUrl;
	/**
	 * Rule Def Url Changes
	 */
	@Value("${"+AppConstants.RULE_DEF_URL+"}")
	String ruleDefUrl;
	/**
	 * Retrieves the JSP page that contains our DataScreen
	 * @throws Exception 
	 */
	@RequestMapping(value = AppConstants.ASSET_FAULT, method = RequestMethod.GET)
	public String getDataScreensPage(final HttpServletRequest request)
			throws Exception {
		HttpSession session = request.getSession(false);
		UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		AssetFaultDataBean objAssetFaultDataBean = new AssetFaultDataBean();
		String strAssetId = request.getParameter(AppConstants.ASSET_NUMBER);     // Asset No
		String strCustomerId = null;   // Cust ID
		String strGrpName = request.getParameter(AppConstants.ASSET_GROUP_NAME); // Road Initial
		String fromDate = request.getParameter(AppConstants.FROM_DATE);          // From Date
		String toDate = request.getParameter(AppConstants.TO_DATE);              // To Date
		final String caseId = request.getParameter(AppConstants.CASE_ID);        // Case ID
		final String caseType = request.getParameter(AppConstants.CASE_TYPE);    // Case Type
		String customerName = request.getParameter(AppConstants.CUSTOMER_NAME);
		final String caseObjid = request.getParameter(AppConstants.CASE_OBJID);
		String locoId = request.getParameter(AppConstants.LOCO_ID);
		Map<String,String> customerMap = null;
		//Added for linking datascreen to revamped remote data response
		//Raj.S (212687474)
		final String isForRDR = request.getParameter(AppConstants.IS_FOR_RDR);
		//Added for Reclsoe changes
		final String caseCondition = request.getParameter(AppConstants.CASE_CONDITION);
		AssetOverviewBean assetBean = new AssetOverviewBean();
		Map<String, String> ddRoleNameMap = null;
		Map<String, String> timeBasedFilterMap = null;
		final Map<String, String> listName = new LinkedHashMap<String, String>();
		listName.put(AppConstants.LIST_NAME, AppConstants.RMD_DD_ROLENAME);
		final Map<String, String> timeBasedFilterListName = new LinkedHashMap<String, String>();
		timeBasedFilterListName.put(AppConstants.LIST_NAME, AppConstants.DS_TIME_BASED_FILTER);
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(AppConstants.TO_DATE_FORMAT);		
		if (cachedService.getSDCustLookup().get(userVO.getCustomerId()) != null
                && cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat() != null
                && !cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat().trim().equals("")) {
			dateFormat = new SimpleDateFormat(cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat());
			request.setAttribute("dateFormat", cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat().replaceAll("HH", "hh"));
		} else {
			request.setAttribute("dateFormat", AppConstants.TO_DATE_FORMAT.replaceAll("HH", "hh"));
		}
		
		String filterDatascreen = null;
		String multiSelectDD = null;
		String rightDropdown = null;
		String defaultFilter = null;
		
		boolean filterDD = false;
		boolean multiDD = false;
		boolean admrghtDrpdown =false;
		boolean isDefaultFavFilter = false;
		String vvfLimitedCustParam = null;
		boolean isVvfLimitedCustParam = false;
		String vvfHideFSS = null;
		boolean isVvfHideFSS = false;
				
		String allDataSetPrivilege = null;
		String vehcileDataSetPrivilege = null;
		String dpeabDataSetPrivilege = null;
		String equipmentDataSetPrivilege = null;
		String dhmsDataSetPrivilege = null;
		String incidentDataSetPrivilege = null;
		String rapidDataSetPrivilege = null;
		Boolean showAutoHCPrivilege = null;
		Boolean showEserviceHistoryPrivilege = null;
		Boolean vehicleFaultsPrivilege = null;
		AssetOverviewBean futureGetAssets = new AssetOverviewBean();
		List<String> noOfDaysList = null;
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		/*Begin of Changes for fetching customer Id from Webservices */
		try {
			strCustomerId = asstOvwService
					.getCustomerId(strAssetId, strGrpName);
		}catch (Exception e) {
			logger.error(
					"Exception occured in getDataScreensPage() While fetching customer Id",
					e);
			RMDWebErrorHandler.handleException(e);
		}
		if(customerName == null || (AppConstants.EMPTY_STRING).equals(customerName)){
			try {
				customerMap = cachedService
						.getCustomers();
				customerName = customerMap.get(strCustomerId);
			}catch (Exception e) {
				logger.error(
						"Exception occured in getDataScreensPage() While fetching customer Id",
						e);
				RMDWebErrorHandler.handleException(e);
			}
			}
		/*End of Changes*/
		try {
			// Raj.S (212687474)
			if (isForRDR != null) {
				request.setAttribute(AppConstants.RDR_DATASCREEN_FLAG, true);
			}
			if (caseId != null && caseType != null && !caseId.trim().equals("") && !caseType.trim().equals("")) {
				request.setAttribute(AppConstants.CASE_DATASCREEN_FLAG, true);
				request.setAttribute(AppConstants.CASE_ID, caseId);
				request.setAttribute(AppConstants.CASE_TYPE, caseType);
				
				noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.CASE_DROPDOWN_DAYS);
				request.setAttribute(AppConstants.DATA_SCREEN_NO_OF_DAYS_DROPDOWN, noOfDaysList);
			} else {				
				ddRoleNameMap = objAssetDataScreenService.getDDRoleName(listName);
				String ddRoleName = null;
				if (ddRoleNameMap != null && !ddRoleNameMap.isEmpty()) {
					for (Map.Entry<String, String> entry : ddRoleNameMap.entrySet()) {
						ddRoleName = (String) entry.getValue();
					}
				}
				request.setAttribute(AppConstants.DIESELDOCTOR_ROLENAME, ddRoleName);
				
				filterDatascreen = authService.getLookUpValueForName(AppConstants.DD_FILTER_DATASCREEN);
				multiSelectDD = authService.getLookUpValueForName(AppConstants.DD_MULTISELECT_DROPDOWN);
				rightDropdown = authService.getLookUpValueForName(AppConstants.DD_RIGHT_DROPDOWN);
				defaultFilter = authService.getLookUpValueForName(AppConstants.DEFAULT_FILTER_DATASCREEN_PRIVILEGE);

				allDataSetPrivilege = authService.getLookUpValueForName(AppConstants.ALL_DATASET_DATASCREEN_PRIVILEGE);			
				vehcileDataSetPrivilege = authService.getLookUpValueForName(AppConstants.VEHICLE_DATASET_DATASCREEN_PRIVILEGE);
				dpeabDataSetPrivilege = authService.getLookUpValueForName(AppConstants.DPEAB_DATASET_DATASCREEN_PRIVILEGE);
				equipmentDataSetPrivilege = authService.getLookUpValueForName(AppConstants.EQUIPMENT_DATASET_DATASCREEN_PRIVILEGE);
				dhmsDataSetPrivilege = authService.getLookUpValueForName(AppConstants.DHMS_DATASET_DATASCREEN_PRIVILEGE);
				incidentDataSetPrivilege = authService.getLookUpValueForName(AppConstants.INCIDENT_DATASET_DATASCREEN_PRIVILEGE);
				rapidDataSetPrivilege = authService.getLookUpValueForName(AppConstants.RAPID_DATASET_DATASCREEN_PRIVILEGE);
				
				filterDD = RMDCommonUtil.componentValue(userVO.getComponentList(), filterDatascreen);
				multiDD = RMDCommonUtil.componentValue(userVO.getComponentList(), multiSelectDD);
				admrghtDrpdown = RMDCommonUtil.componentValue(userVO.getComponentList(), rightDropdown);
				isDefaultFavFilter = RMDCommonUtil.componentValue(userVO.getComponentList(), defaultFilter);
				
				boolean isAllDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), allDataSetPrivilege);
				boolean isVehicleDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), vehcileDataSetPrivilege);
				boolean isDPEABDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), dpeabDataSetPrivilege);
				boolean isEquipmentDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), equipmentDataSetPrivilege);
				boolean isDhmsDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), dhmsDataSetPrivilege);
				boolean isIncidentDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), incidentDataSetPrivilege);
				boolean isRapidDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), rapidDataSetPrivilege);
				
				if ((isAllDataSetPrivileged || isDPEABDataSetPrivileged || isEquipmentDataSetPrivileged
						|| isDhmsDataSetPrivileged || isIncidentDataSetPrivileged) && !isRapidDataSetPrivileged) {
					request.setAttribute(AppConstants.SCREEN_DROPDOWN_DATASCREEN, true);
				}
				if (isRapidDataSetPrivileged && isAllDataSetPrivileged) {
					request.setAttribute(AppConstants.SCREEN_DROPDOWN_DATASCREEN, true);
				}
				if (isVehicleDataSetPrivileged && (isEquipmentDataSetPrivileged || isDPEABDataSetPrivileged
						|| isDhmsDataSetPrivileged || isIncidentDataSetPrivileged)) {
					request.setAttribute(AppConstants.SCREEN_DROPDOWN_DATASCREEN, true);
				}				
				String defaultLookUpValue = authService.getLookUpValueForName(AppConstants.DATA_SCREEN_DEFAULT_NO_OF_DAYS);			
				request.setAttribute(AppConstants.DATA_SCREEN_DEFAULT_NO_OF_DAYS,defaultLookUpValue);
				
				if (fromDate == null && toDate == null) {
					Calendar cal = Calendar.getInstance();
					cal.set(Calendar.SECOND, 0);
					toDate = dateFormat.format(cal.getTime());
					cal.set(Calendar.SECOND, 0);
					cal.add(Calendar.DAY_OF_MONTH, -1 * Integer.parseInt(defaultLookUpValue));
					fromDate = dateFormat.format(cal.getTime());
				}
				
				if (filterDD){
					timeBasedFilterMap = objAssetDataScreenService.getTimeBasedFilter(timeBasedFilterListName);
					request.setAttribute(AppConstants.TIME_BASED_FILTER_MAP, timeBasedFilterMap);
				}		
				
				vvfLimitedCustParam = authService.getLookUpValueForName(AppConstants.DS_VVF_LIMITED_CUST_PARAM);
				isVvfLimitedCustParam = RMDCommonUtil.componentValue(userVO.getComponentList(), vvfLimitedCustParam);
				
				vvfHideFSS = authService.getLookUpValueForName(AppConstants.DATASCREEN_VVF_HIDE_FSS);
				isVvfHideFSS = RMDCommonUtil.componentValue(userVO.getComponentList(), vvfHideFSS);
				
				request.setAttribute(AppConstants.DD_FILTER, filterDD);
				request.setAttribute(AppConstants.DD_FILTER_MULTISELECT, multiDD);
				request.setAttribute(AppConstants.DATASCREEN_DROPDOWN, admrghtDrpdown);
				request.setAttribute(AppConstants.DS_VVF_LIMITED_CUST_PARAM, isVvfLimitedCustParam);
				request.setAttribute(AppConstants.DATASCREEN_VVF_HIDE_FSS, isVvfHideFSS);
				request.setAttribute(AppConstants.DEFAULT_FILTER, isDefaultFavFilter);	
				
				request.setAttribute(AppConstants.ALL_DATASET_DATASCREEN_REQ_ATTRIBUTE, isAllDataSetPrivileged);
				request.setAttribute(AppConstants.VEHICLE_DATASET_DATASCREEN_REQ_ATTRIBUTE, isVehicleDataSetPrivileged);
				request.setAttribute(AppConstants.DPEAB_DATASET_DATASCREEN_REQ_ATTRIBUTE, isDPEABDataSetPrivileged);
				request.setAttribute(AppConstants.EQUIP_DATASET_DATASCREEN_REQ_ATTRIBUTE, isEquipmentDataSetPrivileged);
				request.setAttribute(AppConstants.DHMS_DATASET_DATASCREEN_REQ_ATTRIBUTE, isDhmsDataSetPrivileged);
				request.setAttribute(AppConstants.INCIDENT_DATASET_DATASCREEN_REQ_ATTRIBUTE, isIncidentDataSetPrivileged);
				request.setAttribute(AppConstants.RAPID_DATASET_DATASCREEN_REQ_ATTRIBUTE, isRapidDataSetPrivileged);
				
				if (isRapidDataSetPrivileged) {
					noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.RR_VEHICLE_FAULT_DROPDOWN_DAYS);	
				} else {
					noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.VEHICLE_FAULT_DROPDOWN_DAYS);	
				}			
				request.setAttribute(AppConstants.DATA_SCREEN_NO_OF_DAYS_DROPDOWN, noOfDaysList);
				
				Map<String, Object> componentMap = new HashMap<String, Object>();
				componentMap.put(AppConstants.FILTER_NO_OF_DAYS, filterDD);
				String favoriteFilters = getFavoriteFilters(AppConstants.ASSETOVERVIEW_DATASCREEN, userVO, componentMap);
				if (null != favoriteFilters && !favoriteFilters.equals(AppConstants.EMPTY_STRING) && isDefaultFavFilter) {
					request.setAttribute(AppConstants.FAVORITE_FILTER, favoriteFilters);
				}
				request.setAttribute(AppConstants.FROM_DATE, fromDate);
				request.setAttribute(AppConstants.TO_DATE, toDate);
				request.setAttribute(AppConstants.SELECTED_TAB,	AppConstants.ASSETOVERVIEW_DATASCREEN);
				
			}
		} catch (Exception e) {
			logger.error("Exception occured in getDataScreensPage()", e);
		}
		
		final Map<String, String> jsonMap = new LinkedHashMap<String, String>();
		objAssetFaultDataBean.setUserLanguage(userVO.getStrUserLanguage());
		objAssetFaultDataBean.setAssetNumber(strAssetId);
		objAssetFaultDataBean.setAssetGrpName(strGrpName);
		objAssetFaultDataBean.setCustomerId(strCustomerId);
		try {
			if (true == admrghtDrpdown){
				final List<LatestCases> caseIdLst = objAssetDataScreenService
						.getLatestCases(objAssetFaultDataBean);
				request.setAttribute(AppConstants.CASE_ID_LST, caseIdLst);
				String strCases = AppConstants.EMPTY_STRING;
				if (caseIdLst != null) {
					logger.debug("caseIdLst  " + caseIdLst.size());
					List<RuleBean> latestCasesRuleList = null;
					final 	List<String> rules = new ArrayList<String>();
					for (LatestCases latestCase : caseIdLst) {
						strCases = latestCase.getCaseId();
						if (latestCase.getLstCaseRules() != null)
							latestCasesRuleList = latestCase.getLstCaseRules()
									.get(strCases);

						if (latestCasesRuleList != null) {
							logger.debug("latestCasesRuleList  "
									+ latestCasesRuleList.size());
							for (int i = 0; i < latestCasesRuleList.size(); i++) {
								rules.add(AppConstants.RULE
										+ latestCasesRuleList.get(i).getRuleId()
										+ AppConstants.SYMBOL_OR
										+ latestCasesRuleList.get(i).getRuleDefId());
							}
						} else {
							rules.add(AppConstants.NO_RULES);
						}
	
	            final String csvString = convertListToCSV(rules);
						jsonMap.put(strCases, csvString);
						latestCasesRuleList = null;
						rules.clear();
					}
					request.setAttribute(AppConstants.DROPDOWN_JSON, jsonMap);
				}
			}
		} catch (RMDWebException rmdEx) {
			logger.error(rmdEx);
		} catch (Exception e) {
			logger.error("Exception occured in getDataScreensPage()", e);
		}
		request.setAttribute(AppConstants.ASSET_NUMBER, strAssetId);
		request.setAttribute(AppConstants.CUSTOMER_ID, strCustomerId);
		request.setAttribute(AppConstants.ASSET_GROUP_NAME, strGrpName);
		request.setAttribute(AppConstants.CASE_OBJID,caseObjid);
		request.setAttribute(AppConstants.CUSTOMER_NAME,customerName);
		request.setAttribute(AppConstants.STR_FAULT_ANALYSIS_MANUAL_URL, faultAnalysisManualUrl);
		showEserviceHistoryPrivilege =RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.DATA_SCREEN_SHOW_ESERVICE_HISTORY_LINK);
		if(showEserviceHistoryPrivilege){
		if(locoId == null || AppConstants.EMPTY_STRING.equals(locoId)){
		assetBean.setAsset(strAssetId);
		assetBean.setAssetGroup(strGrpName);
		assetBean.setCustomer(strCustomerId);
		assetBean.setUserLanguage(userVO.getStrUserLanguage());
		assetBean.setUserTimeZone(applicationTimezone);
		assetBean.setUserLanguage(userVO.getStrUserLanguage());
		assetBean.setDefaultTimeZone(defaultTimezone);
		locoId = objAssetDataScreenService.getLocoId(assetBean);
		request.setAttribute(AppConstants.LOCO_ID,locoId);
		}
		else
		{
		request.setAttribute(AppConstants.LOCO_ID,locoId);
		}
		}
		request.setAttribute(AppConstants.STR_ESERVICES_URL, eServicesUrl);
		request.setAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE, userVO.getIsCMPrivilege());
		//Added for KM Screen Changes
		request.setAttribute(AppConstants.STR_EDIT_RX_URL,editRxUrl);
		request.setAttribute(AppConstants.STR_RULE_DEF_URL,ruleDefUrl);
		//Added for Reclsoe changes
		request.setAttribute(AppConstants.CASE_CONDITION,caseCondition);
		showAutoHCPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.DATA_SCREEN_SHOW_AUTO_HC);
		request.setAttribute(AppConstants.SHOW_AUTO_HC, showAutoHCPrivilege);
		vehicleFaultsPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.DATA_SCREEN_VEHICLE);
		request.setAttribute(AppConstants.VEHICLE_FAULTS, vehicleFaultsPrivilege);
		request.setAttribute(AppConstants.DATA_SCREEN_SHOW_ESERVICE_HISTORY_LINK, showEserviceHistoryPrivilege);
		return AppConstants.ASSET_DATASCREEN;
	}
	
	
	
	@RequestMapping(value = AppConstants.ASSET_FAULT_NEW, method = RequestMethod.GET)
	public String getDataScreensPageNew(final HttpServletRequest request)
			throws Exception {
		HttpSession session = request.getSession(false);
		UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		AssetFaultDataBean objAssetFaultDataBean = new AssetFaultDataBean();
		String strAssetId = request.getParameter(AppConstants.ASSET_NUMBER);     // Asset No
		String strCustomerId = null;   // Cust ID
		String strGrpName = request.getParameter(AppConstants.ASSET_GROUP_NAME); // Road Initial
		String fromDate = request.getParameter(AppConstants.FROM_DATE);          // From Date
		String toDate = request.getParameter(AppConstants.TO_DATE);              // To Date
		final String caseId = request.getParameter(AppConstants.CASE_ID);        // Case ID
		final String caseType = request.getParameter(AppConstants.CASE_TYPE);    // Case Type
		String customerName = request.getParameter(AppConstants.CUSTOMER_NAME);
		final String caseObjid = request.getParameter(AppConstants.CASE_OBJID);
		String locoId = request.getParameter(AppConstants.LOCO_ID);
		Map<String,String> customerMap = null;
		//Added for Reclsoe changes
		final String caseCondition = request.getParameter(AppConstants.CASE_CONDITION);
		AssetOverviewBean assetBean = new AssetOverviewBean();
		Map<String, String> ddRoleNameMap = null;
		Map<String, String> timeBasedFilterMap = null;
		final Map<String, String> listName = new LinkedHashMap<String, String>();
		listName.put(AppConstants.LIST_NAME, AppConstants.RMD_DD_ROLENAME);
		final Map<String, String> timeBasedFilterListName = new LinkedHashMap<String, String>();
		timeBasedFilterListName.put(AppConstants.LIST_NAME, AppConstants.DS_TIME_BASED_FILTER);
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(AppConstants.TO_DATE_FORMAT);		
		if (cachedService.getSDCustLookup().get(userVO.getCustomerId()) != null
                && cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat() != null
                && !cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat().trim().equals("")) {
			dateFormat = new SimpleDateFormat(cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat());
			request.setAttribute("dateFormat", cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat().replaceAll("HH", "hh"));
		} else {
			request.setAttribute("dateFormat", AppConstants.TO_DATE_FORMAT.replaceAll("HH", "hh"));
		}
		
		String filterDatascreen = null;
		String multiSelectDD = null;
		String rightDropdown = null;
		String defaultFilter = null;
		
		boolean filterDD = false;
		boolean multiDD = false;
		boolean admrghtDrpdown =false;
		boolean isDefaultFavFilter = false;
		String vvfLimitedCustParam = null;
		boolean isVvfLimitedCustParam = false;
		String vvfHideFSS = null;
		boolean isVvfHideFSS = false;
				
		String allDataSetPrivilege = null;
		String vehcileDataSetPrivilege = null;
		String dpeabDataSetPrivilege = null;
		String equipmentDataSetPrivilege = null;
		String dhmsDataSetPrivilege = null;
		String incidentDataSetPrivilege = null;
		String rapidDataSetPrivilege = null;
		
		List<String> noOfDaysList = null;
		Boolean showAutoHCPrivilege = null;
		Boolean showEserviceHistoryPrivilege = null;
		Boolean vehicleFaultsPrivilege = null;

		AssetOverviewBean futureGetAssets = new AssetOverviewBean();
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		/*Begin of Changes for fetching customer Id from Webservices */
		try {
			strCustomerId = asstOvwService
					.getCustomerId(strAssetId, strGrpName);
		}catch (Exception e) {
			logger.error(
					"Exception occured in getDataScreensPage() While fetching customer Id",
					e);
			RMDWebErrorHandler.handleException(e);
		}
		if(customerName == null || (AppConstants.EMPTY_STRING).equals(customerName)){
			try {
				customerMap = cachedService
						.getCustomers();
				customerName = customerMap.get(strCustomerId);
			}catch (Exception e) {
				logger.error(
						"Exception occured in getDataScreensPage() While fetching customer Id",
						e);
				RMDWebErrorHandler.handleException(e);
			}
			}
		
		/*End of Changes*/
		try {
			if (caseId != null && caseType != null && !caseId.trim().equals("") && !caseType.trim().equals("")) {
				request.setAttribute(AppConstants.CASE_DATASCREEN_FLAG, true);
				request.setAttribute(AppConstants.CASE_ID, caseId);
				request.setAttribute(AppConstants.CASE_TYPE, caseType);
				
				noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.CASE_DROPDOWN_DAYS);
				request.setAttribute(AppConstants.DATA_SCREEN_NO_OF_DAYS_DROPDOWN, noOfDaysList);
			} else {				
				ddRoleNameMap = objAssetDataScreenService.getDDRoleName(listName);
				String ddRoleName = null;
				if (ddRoleNameMap != null && !ddRoleNameMap.isEmpty()) {
					for (Map.Entry<String, String> entry : ddRoleNameMap.entrySet()) {
						ddRoleName = (String) entry.getValue();
					}
				}
				request.setAttribute(AppConstants.DIESELDOCTOR_ROLENAME, ddRoleName);
				
				filterDatascreen = authService.getLookUpValueForName(AppConstants.DD_FILTER_DATASCREEN);
				multiSelectDD = authService.getLookUpValueForName(AppConstants.DD_MULTISELECT_DROPDOWN);
				rightDropdown = authService.getLookUpValueForName(AppConstants.DD_RIGHT_DROPDOWN);
				defaultFilter = authService.getLookUpValueForName(AppConstants.DEFAULT_FILTER_DATASCREEN_PRIVILEGE);

				allDataSetPrivilege = authService.getLookUpValueForName(AppConstants.ALL_DATASET_DATASCREEN_PRIVILEGE);			
				vehcileDataSetPrivilege = authService.getLookUpValueForName(AppConstants.VEHICLE_DATASET_DATASCREEN_PRIVILEGE);
				dpeabDataSetPrivilege = authService.getLookUpValueForName(AppConstants.DPEAB_DATASET_DATASCREEN_PRIVILEGE);
				equipmentDataSetPrivilege = authService.getLookUpValueForName(AppConstants.EQUIPMENT_DATASET_DATASCREEN_PRIVILEGE);
				dhmsDataSetPrivilege = authService.getLookUpValueForName(AppConstants.DHMS_DATASET_DATASCREEN_PRIVILEGE);
				incidentDataSetPrivilege = authService.getLookUpValueForName(AppConstants.INCIDENT_DATASET_DATASCREEN_PRIVILEGE);
				rapidDataSetPrivilege = authService.getLookUpValueForName(AppConstants.RAPID_DATASET_DATASCREEN_PRIVILEGE);
				
				filterDD = RMDCommonUtil.componentValue(userVO.getComponentList(), filterDatascreen);
				multiDD = RMDCommonUtil.componentValue(userVO.getComponentList(), multiSelectDD);
				admrghtDrpdown = RMDCommonUtil.componentValue(userVO.getComponentList(), rightDropdown);
				isDefaultFavFilter = RMDCommonUtil.componentValue(userVO.getComponentList(), defaultFilter);
				
				boolean isAllDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), allDataSetPrivilege);
				boolean isVehicleDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), vehcileDataSetPrivilege);
				boolean isDPEABDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), dpeabDataSetPrivilege);
				boolean isEquipmentDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), equipmentDataSetPrivilege);
				boolean isDhmsDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), dhmsDataSetPrivilege);
				boolean isIncidentDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), incidentDataSetPrivilege);
				boolean isRapidDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), rapidDataSetPrivilege);
				
				if ((isAllDataSetPrivileged || isDPEABDataSetPrivileged || isEquipmentDataSetPrivileged
						|| isDhmsDataSetPrivileged || isIncidentDataSetPrivileged) && !isRapidDataSetPrivileged) {
					request.setAttribute(AppConstants.SCREEN_DROPDOWN_DATASCREEN, true);
				}
				if (isRapidDataSetPrivileged && isAllDataSetPrivileged) {
					request.setAttribute(AppConstants.SCREEN_DROPDOWN_DATASCREEN, true);
				}
				if (isVehicleDataSetPrivileged && (isEquipmentDataSetPrivileged || isDPEABDataSetPrivileged
						|| isDhmsDataSetPrivileged || isIncidentDataSetPrivileged)) {
					request.setAttribute(AppConstants.SCREEN_DROPDOWN_DATASCREEN, true);
				}				
				String defaultLookUpValue = authService.getLookUpValueForName(AppConstants.DATA_SCREEN_DEFAULT_NO_OF_DAYS);			
				request.setAttribute(AppConstants.DATA_SCREEN_DEFAULT_NO_OF_DAYS,defaultLookUpValue);
				
				if (fromDate == null && toDate == null) {
					Calendar cal = Calendar.getInstance();
					cal.set(Calendar.SECOND, 0);
					toDate = dateFormat.format(cal.getTime());
					cal.set(Calendar.SECOND, 0);
					cal.add(Calendar.DAY_OF_MONTH, -1 * Integer.parseInt(defaultLookUpValue));
					fromDate = dateFormat.format(cal.getTime());
				}
				
				if (filterDD){
					timeBasedFilterMap = objAssetDataScreenService.getTimeBasedFilter(timeBasedFilterListName);
					request.setAttribute(AppConstants.TIME_BASED_FILTER_MAP, timeBasedFilterMap);
				}		
				
				vvfLimitedCustParam = authService.getLookUpValueForName(AppConstants.DS_VVF_LIMITED_CUST_PARAM);
				isVvfLimitedCustParam = RMDCommonUtil.componentValue(userVO.getComponentList(), vvfLimitedCustParam);
				
				vvfHideFSS = authService.getLookUpValueForName(AppConstants.DATASCREEN_VVF_HIDE_FSS);
				isVvfHideFSS = RMDCommonUtil.componentValue(userVO.getComponentList(), vvfHideFSS);
				
				request.setAttribute(AppConstants.DD_FILTER, filterDD);
				request.setAttribute(AppConstants.DD_FILTER_MULTISELECT, multiDD);
				request.setAttribute(AppConstants.DATASCREEN_DROPDOWN, admrghtDrpdown);
				request.setAttribute(AppConstants.DS_VVF_LIMITED_CUST_PARAM, isVvfLimitedCustParam);
				request.setAttribute(AppConstants.DATASCREEN_VVF_HIDE_FSS, isVvfHideFSS);
				request.setAttribute(AppConstants.DEFAULT_FILTER, isDefaultFavFilter);	
				
				request.setAttribute(AppConstants.ALL_DATASET_DATASCREEN_REQ_ATTRIBUTE, isAllDataSetPrivileged);
				request.setAttribute(AppConstants.VEHICLE_DATASET_DATASCREEN_REQ_ATTRIBUTE, isVehicleDataSetPrivileged);
				request.setAttribute(AppConstants.DPEAB_DATASET_DATASCREEN_REQ_ATTRIBUTE, isDPEABDataSetPrivileged);
				request.setAttribute(AppConstants.EQUIP_DATASET_DATASCREEN_REQ_ATTRIBUTE, isEquipmentDataSetPrivileged);
				request.setAttribute(AppConstants.DHMS_DATASET_DATASCREEN_REQ_ATTRIBUTE, isDhmsDataSetPrivileged);
				request.setAttribute(AppConstants.INCIDENT_DATASET_DATASCREEN_REQ_ATTRIBUTE, isIncidentDataSetPrivileged);
				request.setAttribute(AppConstants.RAPID_DATASET_DATASCREEN_REQ_ATTRIBUTE, isRapidDataSetPrivileged);
				
				if (isRapidDataSetPrivileged) {
					noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.RR_VEHICLE_FAULT_DROPDOWN_DAYS);	
				} else {
					noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.VEHICLE_FAULT_DROPDOWN_DAYS);	
				}			
				request.setAttribute(AppConstants.DATA_SCREEN_NO_OF_DAYS_DROPDOWN, noOfDaysList);
				
				Map<String, Object> componentMap = new HashMap<String, Object>();
				componentMap.put(AppConstants.FILTER_NO_OF_DAYS, filterDD);
				String favoriteFilters = getFavoriteFilters(AppConstants.ASSETOVERVIEW_DATASCREEN, userVO, componentMap);
				if (null != favoriteFilters && !favoriteFilters.equals(AppConstants.EMPTY_STRING) && isDefaultFavFilter) {
					request.setAttribute(AppConstants.FAVORITE_FILTER, favoriteFilters);
				}
				request.setAttribute(AppConstants.FROM_DATE, fromDate);
				request.setAttribute(AppConstants.TO_DATE, toDate);
				request.setAttribute(AppConstants.SELECTED_TAB,	AppConstants.ASSETOVERVIEW_DATASCREEN);
				
			}
		} catch (Exception e) {
			logger.error("Exception occured in getDataScreensPage()", e);
		}
		
		final Map<String, String> jsonMap = new LinkedHashMap<String, String>();
		objAssetFaultDataBean.setUserLanguage(userVO.getStrUserLanguage());
		objAssetFaultDataBean.setAssetNumber(strAssetId);
		objAssetFaultDataBean.setAssetGrpName(strGrpName);
		objAssetFaultDataBean.setCustomerId(strCustomerId);
		try {
			if (true == admrghtDrpdown){
				final List<LatestCases> caseIdLst = objAssetDataScreenService
						.getLatestCases(objAssetFaultDataBean);
				request.setAttribute(AppConstants.CASE_ID_LST, caseIdLst);
				String strCases = AppConstants.EMPTY_STRING;
				if (caseIdLst != null) {
					logger.debug("caseIdLst  " + caseIdLst.size());
					List<RuleBean> latestCasesRuleList = null;
					final 	List<String> rules = new ArrayList<String>();
					for (LatestCases latestCase : caseIdLst) {
						strCases = latestCase.getCaseId();
						if (latestCase.getLstCaseRules() != null)
							latestCasesRuleList = latestCase.getLstCaseRules()
									.get(strCases);

						if (latestCasesRuleList != null) {
							logger.debug("latestCasesRuleList  "
									+ latestCasesRuleList.size());
							for (int i = 0; i < latestCasesRuleList.size(); i++) {
								rules.add(AppConstants.RULE
										+ latestCasesRuleList.get(i).getRuleId()
										+ AppConstants.SYMBOL_OR
										+ latestCasesRuleList.get(i).getRuleDefId());
							}
						} else {
							rules.add(AppConstants.NO_RULES);
						}
	
	            final String csvString = convertListToCSV(rules);
						jsonMap.put(strCases, csvString);
						latestCasesRuleList = null;
						rules.clear();
					}
					request.setAttribute(AppConstants.DROPDOWN_JSON, jsonMap);
				}
			}
		} catch (RMDWebException rmdEx) {
			logger.error(rmdEx);
		} catch (Exception e) {
			logger.error("Exception occured in getDataScreensPage()", e);
		}
		request.setAttribute(AppConstants.ASSET_NUMBER, strAssetId);
		request.setAttribute(AppConstants.CUSTOMER_ID, strCustomerId);
		request.setAttribute(AppConstants.ASSET_GROUP_NAME, strGrpName);
		request.setAttribute(AppConstants.CASE_OBJID,caseObjid);
		request.setAttribute(AppConstants.CUSTOMER_NAME,customerName);
		request.setAttribute(AppConstants.STR_FAULT_ANALYSIS_MANUAL_URL, faultAnalysisManualUrl);
		showEserviceHistoryPrivilege =RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.DATA_SCREEN_NEW_SHOW_ESERVICE_HISTORY_LINK);
		if(showEserviceHistoryPrivilege){
		if(locoId == null || AppConstants.EMPTY_STRING.equals(locoId)){
			assetBean.setAsset(strAssetId);
			assetBean.setAssetGroup(strGrpName);
			assetBean.setCustomer(strCustomerId);
			assetBean.setUserLanguage(userVO.getStrUserLanguage());
			assetBean.setUserTimeZone(applicationTimezone);
			assetBean.setUserLanguage(userVO.getStrUserLanguage());
			assetBean.setDefaultTimeZone(defaultTimezone);
			locoId = objAssetDataScreenService.getLocoId(assetBean);
			request.setAttribute(AppConstants.LOCO_ID,locoId);
			}
			else
			{
			request.setAttribute(AppConstants.LOCO_ID,locoId);
			}
		}
		request.setAttribute(AppConstants.STR_ESERVICES_URL, eServicesUrl);
		request.setAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE, userVO.getIsCMPrivilege());
		//Added for KM Screen Changes
		request.setAttribute(AppConstants.STR_EDIT_RX_URL,editRxUrl);
		request.setAttribute(AppConstants.STR_RULE_DEF_URL,ruleDefUrl);
		//Added for Reclsoe changes
		request.setAttribute(AppConstants.CASE_CONDITION,caseCondition);
		showAutoHCPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.DATA_SCREEN_NEW_SHOW_AUTO_HC);
		request.setAttribute(AppConstants.SHOW_AUTO_HC, showAutoHCPrivilege);
		vehicleFaultsPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.DATA_SCREEN_NEW_VEHICLE);
		request.setAttribute(AppConstants.VEHICLE_FAULTS, vehicleFaultsPrivilege);
		request.setAttribute(AppConstants.DATA_SCREEN_NEW_SHOW_ESERVICE_HISTORY_LINK, showEserviceHistoryPrivilege);
		return AppConstants.ASSET_DATASCREEN_NEW;
	}

	@RequestMapping(value = AppConstants.ASSET_FAULT_POPOUT, method = RequestMethod.GET)
	public String getDataScreensPagePopout(final HttpServletRequest request)
			throws Exception {
		HttpSession session = request.getSession(false);
		UserVO userVO = (UserVO) session.getAttribute(AppConstants.ATTR_USER_OBJECT);
		AssetFaultDataBean objAssetFaultDataBean = new AssetFaultDataBean();
		String strAssetId = request.getParameter(AppConstants.ASSET_NUMBER);     // Asset No
		String strCustomerId = null;   // Cust ID
		String strGrpName = request.getParameter(AppConstants.ASSET_GROUP_NAME); // Road Initial
		String fromDate = request.getParameter(AppConstants.FROM_DATE);          // From Date
		String toDate = request.getParameter(AppConstants.TO_DATE);              // To Date
		final String caseId = request.getParameter(AppConstants.CASE_ID);        // Case ID
		final String caseType = request.getParameter(AppConstants.CASE_TYPE);    // Case Type
		final String customerName = request.getParameter(AppConstants.CUSTOMER_NAME);
		final String caseObjid = request.getParameter(AppConstants.CASE_OBJID);
		final String locoId = request.getParameter(AppConstants.LOCO_ID);
		//Added for Reclsoe changes
		final String caseCondition = request.getParameter(AppConstants.CASE_CONDITION);

		Map<String, String> ddRoleNameMap = null;
		Map<String, String> timeBasedFilterMap = null;
		final Map<String, String> listName = new LinkedHashMap<String, String>();
		listName.put(AppConstants.LIST_NAME, AppConstants.RMD_DD_ROLENAME);
		final Map<String, String> timeBasedFilterListName = new LinkedHashMap<String, String>();
		timeBasedFilterListName.put(AppConstants.LIST_NAME, AppConstants.DS_TIME_BASED_FILTER);
		
		SimpleDateFormat dateFormat = new SimpleDateFormat(AppConstants.TO_DATE_FORMAT);		
		if (cachedService.getSDCustLookup().get(userVO.getCustomerId()) != null
                && cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat() != null
                && !cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat().trim().equals("")) {
			dateFormat = new SimpleDateFormat(cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat());
			request.setAttribute("dateFormat", cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat().replaceAll("HH", "hh"));
		} else {
			request.setAttribute("dateFormat", AppConstants.TO_DATE_FORMAT.replaceAll("HH", "hh"));
		}
		
		String filterDatascreen = null;
		String multiSelectDD = null;
		String rightDropdown = null;
		String defaultFilter = null;
		
		boolean filterDD = false;
		boolean multiDD = false;
		boolean admrghtDrpdown =false;
		boolean isDefaultFavFilter = false;
		String vvfLimitedCustParam = null;
		boolean isVvfLimitedCustParam = false;
		String vvfHideFSS = null;
		boolean isVvfHideFSS = false;
				
		String allDataSetPrivilege = null;
		String vehcileDataSetPrivilege = null;
		String dpeabDataSetPrivilege = null;
		String equipmentDataSetPrivilege = null;
		String dhmsDataSetPrivilege = null;
		String incidentDataSetPrivilege = null;
		String rapidDataSetPrivilege = null;
		Boolean showAutoHCPrivilege = null;
		Boolean vehicleFaultsPrivilege = null;
		
		List<String> noOfDaysList = null;
		/*Begin of Changes for fetching customer Id from Webservices */
		try {
			strCustomerId = asstOvwService
					.getCustomerId(strAssetId, strGrpName);
		}catch (Exception e) {
			logger.error(
					"Exception occured in getDataScreensPage() While fetching customer Id",
					e);
			RMDWebErrorHandler.handleException(e);
		}
		/*End of Changes*/
		try {
			if (caseId != null && caseType != null && !caseId.trim().equals("") && !caseType.trim().equals("")) {
				request.setAttribute(AppConstants.CASE_DATASCREEN_FLAG, true);
				request.setAttribute(AppConstants.CASE_ID, caseId);
				request.setAttribute(AppConstants.CASE_TYPE, caseType);
				
				noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.CASE_DROPDOWN_DAYS);
				request.setAttribute(AppConstants.DATA_SCREEN_NO_OF_DAYS_DROPDOWN, noOfDaysList);
			} else {				
				ddRoleNameMap = objAssetDataScreenService.getDDRoleName(listName);
				String ddRoleName = null;
				if (ddRoleNameMap != null && !ddRoleNameMap.isEmpty()) {
					for (Map.Entry<String, String> entry : ddRoleNameMap.entrySet()) {
						ddRoleName = (String) entry.getValue();
					}
				}
				request.setAttribute(AppConstants.DIESELDOCTOR_ROLENAME, ddRoleName);
				
				filterDatascreen = authService.getLookUpValueForName(AppConstants.DD_FILTER_DATASCREEN);
				multiSelectDD = authService.getLookUpValueForName(AppConstants.DD_MULTISELECT_DROPDOWN);
				rightDropdown = authService.getLookUpValueForName(AppConstants.DD_RIGHT_DROPDOWN);
				defaultFilter = authService.getLookUpValueForName(AppConstants.DEFAULT_FILTER_DATASCREEN_PRIVILEGE);

				allDataSetPrivilege = authService.getLookUpValueForName(AppConstants.ALL_DATASET_DATASCREEN_PRIVILEGE);			
				vehcileDataSetPrivilege = authService.getLookUpValueForName(AppConstants.VEHICLE_DATASET_DATASCREEN_PRIVILEGE);
				dpeabDataSetPrivilege = authService.getLookUpValueForName(AppConstants.DPEAB_DATASET_DATASCREEN_PRIVILEGE);
				equipmentDataSetPrivilege = authService.getLookUpValueForName(AppConstants.EQUIPMENT_DATASET_DATASCREEN_PRIVILEGE);
				dhmsDataSetPrivilege = authService.getLookUpValueForName(AppConstants.DHMS_DATASET_DATASCREEN_PRIVILEGE);
				incidentDataSetPrivilege = authService.getLookUpValueForName(AppConstants.INCIDENT_DATASET_DATASCREEN_PRIVILEGE);
				rapidDataSetPrivilege = authService.getLookUpValueForName(AppConstants.RAPID_DATASET_DATASCREEN_PRIVILEGE);
				
				filterDD = RMDCommonUtil.componentValue(userVO.getComponentList(), filterDatascreen);
				multiDD = RMDCommonUtil.componentValue(userVO.getComponentList(), multiSelectDD);
				admrghtDrpdown = RMDCommonUtil.componentValue(userVO.getComponentList(), rightDropdown);
				isDefaultFavFilter = RMDCommonUtil.componentValue(userVO.getComponentList(), defaultFilter);
				
				boolean isAllDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), allDataSetPrivilege);
				boolean isVehicleDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), vehcileDataSetPrivilege);
				boolean isDPEABDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), dpeabDataSetPrivilege);
				boolean isEquipmentDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), equipmentDataSetPrivilege);
				boolean isDhmsDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), dhmsDataSetPrivilege);
				boolean isIncidentDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), incidentDataSetPrivilege);
				boolean isRapidDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), rapidDataSetPrivilege);
				
				if ((isAllDataSetPrivileged || isDPEABDataSetPrivileged || isEquipmentDataSetPrivileged
						|| isDhmsDataSetPrivileged || isIncidentDataSetPrivileged) && !isRapidDataSetPrivileged) {
					request.setAttribute(AppConstants.SCREEN_DROPDOWN_DATASCREEN, true);
				}
				if (isRapidDataSetPrivileged && isAllDataSetPrivileged) {
					request.setAttribute(AppConstants.SCREEN_DROPDOWN_DATASCREEN, true);
				}
				if (isVehicleDataSetPrivileged && (isEquipmentDataSetPrivileged || isDPEABDataSetPrivileged
						|| isDhmsDataSetPrivileged || isIncidentDataSetPrivileged)) {
					request.setAttribute(AppConstants.SCREEN_DROPDOWN_DATASCREEN, true);
				}				
				String defaultLookUpValue = authService.getLookUpValueForName(AppConstants.DATA_SCREEN_DEFAULT_NO_OF_DAYS);			
				request.setAttribute(AppConstants.DATA_SCREEN_DEFAULT_NO_OF_DAYS,defaultLookUpValue);
				
				if (fromDate == null && toDate == null) {
					Calendar cal = Calendar.getInstance();
					cal.set(Calendar.SECOND, 0);
					toDate = dateFormat.format(cal.getTime());
					cal.set(Calendar.SECOND, 0);
					cal.add(Calendar.DAY_OF_MONTH, -1 * Integer.parseInt(defaultLookUpValue));
					fromDate = dateFormat.format(cal.getTime());
				}
				
				if (filterDD){
					timeBasedFilterMap = objAssetDataScreenService.getTimeBasedFilter(timeBasedFilterListName);
					request.setAttribute(AppConstants.TIME_BASED_FILTER_MAP, timeBasedFilterMap);
				}		
				
				vvfLimitedCustParam = authService.getLookUpValueForName(AppConstants.DS_VVF_LIMITED_CUST_PARAM);
				isVvfLimitedCustParam = RMDCommonUtil.componentValue(userVO.getComponentList(), vvfLimitedCustParam);
				
				vvfHideFSS = authService.getLookUpValueForName(AppConstants.DATASCREEN_VVF_HIDE_FSS);
				isVvfHideFSS = RMDCommonUtil.componentValue(userVO.getComponentList(), vvfHideFSS);
				
				request.setAttribute(AppConstants.DD_FILTER, filterDD);
				request.setAttribute(AppConstants.DD_FILTER_MULTISELECT, multiDD);
				request.setAttribute(AppConstants.DATASCREEN_DROPDOWN, admrghtDrpdown);
				request.setAttribute(AppConstants.DS_VVF_LIMITED_CUST_PARAM, isVvfLimitedCustParam);
				request.setAttribute(AppConstants.DATASCREEN_VVF_HIDE_FSS, isVvfHideFSS);
				request.setAttribute(AppConstants.DEFAULT_FILTER, isDefaultFavFilter);	
				
				request.setAttribute(AppConstants.ALL_DATASET_DATASCREEN_REQ_ATTRIBUTE, isAllDataSetPrivileged);
				request.setAttribute(AppConstants.VEHICLE_DATASET_DATASCREEN_REQ_ATTRIBUTE, isVehicleDataSetPrivileged);
				request.setAttribute(AppConstants.DPEAB_DATASET_DATASCREEN_REQ_ATTRIBUTE, isDPEABDataSetPrivileged);
				request.setAttribute(AppConstants.EQUIP_DATASET_DATASCREEN_REQ_ATTRIBUTE, isEquipmentDataSetPrivileged);
				request.setAttribute(AppConstants.DHMS_DATASET_DATASCREEN_REQ_ATTRIBUTE, isDhmsDataSetPrivileged);
				request.setAttribute(AppConstants.INCIDENT_DATASET_DATASCREEN_REQ_ATTRIBUTE, isIncidentDataSetPrivileged);
				request.setAttribute(AppConstants.RAPID_DATASET_DATASCREEN_REQ_ATTRIBUTE, isRapidDataSetPrivileged);
				
				if (isRapidDataSetPrivileged) {
					noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.RR_VEHICLE_FAULT_DROPDOWN_DAYS);	
				} else {
					noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.VEHICLE_FAULT_DROPDOWN_DAYS);	
				}			
				request.setAttribute(AppConstants.DATA_SCREEN_NO_OF_DAYS_DROPDOWN, noOfDaysList);
				
				Map<String, Object> componentMap = new HashMap<String, Object>();
				componentMap.put(AppConstants.FILTER_NO_OF_DAYS, filterDD);
				String favoriteFilters = getFavoriteFilters(AppConstants.ASSETOVERVIEW_DATASCREEN, userVO, componentMap);
				if (null != favoriteFilters && !favoriteFilters.equals(AppConstants.EMPTY_STRING) && isDefaultFavFilter) {
					request.setAttribute(AppConstants.FAVORITE_FILTER, favoriteFilters);
				}
				request.setAttribute(AppConstants.FROM_DATE, fromDate);
				request.setAttribute(AppConstants.TO_DATE, toDate);
				request.setAttribute(AppConstants.SELECTED_TAB,	AppConstants.ASSETOVERVIEW_DATASCREEN);
				
			}
		} catch (Exception e) {
			logger.error("Exception occured in getDataScreensPage()", e);
		}
		
		final Map<String, String> jsonMap = new LinkedHashMap<String, String>();
		objAssetFaultDataBean.setUserLanguage(userVO.getStrUserLanguage());
		objAssetFaultDataBean.setAssetNumber(strAssetId);
		objAssetFaultDataBean.setAssetGrpName(strGrpName);
		objAssetFaultDataBean.setCustomerId(strCustomerId);
		try {
			if (true == admrghtDrpdown){
				final List<LatestCases> caseIdLst = objAssetDataScreenService
						.getLatestCases(objAssetFaultDataBean);
				request.setAttribute(AppConstants.CASE_ID_LST, caseIdLst);
				String strCases = AppConstants.EMPTY_STRING;
				if (caseIdLst != null) {
					logger.debug("caseIdLst  " + caseIdLst.size());
					List<RuleBean> latestCasesRuleList = null;
					final 	List<String> rules = new ArrayList<String>();
					for (LatestCases latestCase : caseIdLst) {
						strCases = latestCase.getCaseId();
						if (latestCase.getLstCaseRules() != null)
							latestCasesRuleList = latestCase.getLstCaseRules()
									.get(strCases);

						if (latestCasesRuleList != null) {
							logger.debug("latestCasesRuleList  "
									+ latestCasesRuleList.size());
							for (int i = 0; i < latestCasesRuleList.size(); i++) {
								rules.add(AppConstants.RULE
										+ latestCasesRuleList.get(i).getRuleId()
										+ AppConstants.SYMBOL_OR
										+ latestCasesRuleList.get(i).getRuleDefId());
							}
						} else {
							rules.add(AppConstants.NO_RULES);
						}
	
	            final String csvString = convertListToCSV(rules);
						jsonMap.put(strCases, csvString);
						latestCasesRuleList = null;
						rules.clear();
					}
					request.setAttribute(AppConstants.DROPDOWN_JSON, jsonMap);
				}
			}
		} catch (RMDWebException rmdEx) {
			logger.error(rmdEx);
		} catch (Exception e) {
			logger.error("Exception occured in getDataScreensPage()", e);
		}
		request.setAttribute(AppConstants.ASSET_NUMBER, strAssetId);
		request.setAttribute(AppConstants.CUSTOMER_ID, strCustomerId);
		request.setAttribute(AppConstants.ASSET_GROUP_NAME, strGrpName);
		request.setAttribute(AppConstants.CASE_OBJID,caseObjid);
		request.setAttribute(AppConstants.CUSTOMER_NAME,customerName);
		request.setAttribute(AppConstants.STR_FAULT_ANALYSIS_MANUAL_URL, faultAnalysisManualUrl);
		request.setAttribute(AppConstants.LOCO_ID,locoId);
		request.setAttribute(AppConstants.STR_ESERVICES_URL, eServicesUrl);
		request.setAttribute(AppConstants.IS_CASE_MGMT_PRIVILEGE, userVO.getIsCMPrivilege());
		//Added for KM Screen Changes
		request.setAttribute(AppConstants.STR_EDIT_RX_URL,editRxUrl);
		request.setAttribute(AppConstants.STR_RULE_DEF_URL,ruleDefUrl);
		//Added for Reclsoe changes
		request.setAttribute(AppConstants.CASE_CONDITION,caseCondition);
		showAutoHCPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.DATA_SCREEN_NEW_SHOW_AUTO_HC);
		request.setAttribute(AppConstants.SHOW_AUTO_HC, showAutoHCPrivilege);
		vehicleFaultsPrivilege = RMDCommonUtil.componentValue(userVO.getComponentList(), AppConstants.DATA_SCREEN_NEW_VEHICLE);
		request.setAttribute(AppConstants.VEHICLE_FAULTS, vehicleFaultsPrivilege);

		return AppConstants.ASSET_DATASCREEN_POPOUT;
	}
	/*
	 * This method is used for fetching the data from DB for multiselect
	 * dropdown
	 */

	@RequestMapping(value =AppConstants.GET_DROPDOWN, method = RequestMethod.GET)
	public @ResponseBody
	Map<String, String> getDropdownData() throws Exception {
		/* Added for diesel doctor datascreen story */
		Map<String, String> ddDropdownVal = null;
		try {
			final Map<String, String> listName = new LinkedHashMap<String, String>();
			listName.put(AppConstants.LIST_NAME,
					AppConstants.RMD_DD_LOOKUPVALUE);
			ddDropdownVal = objAssetDataScreenService.getDDDropdown(listName);
			return ddDropdownVal;
		} catch (Exception ex) {
			logger.error("Exception occured in getDropdownData method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return ddDropdownVal;
		/* Added for diesel doctor datascreen story */
	}

	/**
	 * The default method when a request to /assetFault is made. This
	 * essentially retrieves all assetDataScreen, which are wrapped inside a
	 * AssetDataResponse object. The object is automatically converted to JSON
	 * when returning back the response. The @ResponseBody is responsible for
	 * this behavior.
	 */
	@RequestMapping(value = AppConstants.GET_COLUMNS_AND_MODEL, method = RequestMethod.GET)
	public @ResponseBody
	AssetDataResponseVO getColumnsAndModel(final HttpServletRequest request)
			throws Exception {
		final long startTime = System.currentTimeMillis();
		final UserVO userVO = (UserVO) request.getSession(false).getAttribute(
				AppConstants.ATTR_USER_OBJECT);
		SimpleDateFormat dateFormat = new SimpleDateFormat(AppConstants.TO_DATE_FORMAT);
		if (cachedService.getSDCustLookup().get(userVO.getCustomerId()) != null
                && cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat() != null
                && !cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat().trim().equals("")) {
			dateFormat = new SimpleDateFormat(cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat());
			request.setAttribute("dateFormat", cachedService.getSDCustLookup().get(userVO.getCustomerId()).getDateFormat().replaceAll("HH", "hh"));
		} else {
			request.setAttribute("dateFormat", AppConstants.TO_DATE_FORMAT.replaceAll("HH", "hh"));
		}
		AssetDataResponseVO objAssetDataResponse = new AssetDataResponseVO();
		final AssetFaultDataBean objAssetFaultDataBean = new AssetFaultDataBean();
		List<Map<String, String>> lsAssetFaultData = null;
		List<String> noOfDaysList = null;
		String vvfLimitedCustParam = null;
		String vvfHideL3Faults = null;
		boolean isVvfLimitedCustParam = false;
		boolean isVvfHideL3Faults = false;
		String roleName = null;
		
		try {
			roleName = RMDCommonUtil.getRoleName(userVO);
			if (roleName.equalsIgnoreCase(AppConstants.DIESEL_DOCTOR)){
				objAssetFaultDataBean.setDieselDoctor(true);
			} else {
				objAssetFaultDataBean.setDieselDoctor(false);
			}
			objAssetFaultDataBean.setRoleName(roleName);
			objAssetFaultDataBean.setUserTimeZone(userVO.getTimeZone());
			objAssetFaultDataBean.setUserTimeZoneCode(userVO.getTimeZoneCode());
			objAssetFaultDataBean.setEnableCustomColumns(RMDCommonUtil.componentValue(userVO.getComponentList(), "DATASCREEN_CUSTOM_COLUMNS"));
			if (request.getParameter(AppConstants.ASSET_NUMBER) != null
					&& !AppConstants.EMPTY_STRING.equalsIgnoreCase(request
							.getParameter(AppConstants.ASSET_NUMBER))) {				
				final String strAssetTabID = request.getParameter(AppConstants.ASSET_TAB_ID);
				final String strAssetID = request.getParameter(AppConstants.ASSET_NUMBER);
				final String strCustID = request.getParameter(AppConstants.CUSTOMER_ID);
				final String strAsstGrpName = request.getParameter(AppConstants.ASSET_GROUP_NAME);
				final String fromDate = request.getParameter(AppConstants.FROM_DATE);
				final String toDate = request.getParameter(AppConstants.TO_DATE);
				final String strDays = request.getParameter(AppConstants.DROPDOWN_DAYS);
				final String sortOrder = request.getParameter(AppConstants.SORT_ORDER);
				final String fetchHc = request.getParameter(AppConstants.FETCH_HC);
				final String equipmentType = request.getParameter(AppConstants.EQUIPMENT_TYPE);
				final String dataSets = request.getParameter(AppConstants.DATASET);
				final String caseId = request.getParameter(AppConstants.CASE_ID);
				final String caseType = request.getParameter(AppConstants.CASE_TYPE);
				final String caseFrom = request.getParameter(AppConstants.CASE_FROM);
				final String startRow = request.getParameter(AppConstants.START_ROW);
				final String ruleId = request.getParameter(AppConstants.RULE_ID);
				final String ruleType = request.getParameter(AppConstants.RULE_TYPE);
				final String initialLoad = request.getParameter(AppConstants.INITIAL_LOAD);
				final String notch8 = request.getParameter(AppConstants.NOTCH_8);
				final String allData = request.getParameter(AppConstants.DS_ALL_RECORDS);
				
				objAssetFaultDataBean.setUserLanguage(userVO.getStrUserLanguage());
				objAssetFaultDataBean.setAssetNumber(strAssetID);                      // Asset Number
				objAssetFaultDataBean.setAssetGrpName(strAsstGrpName);                 // Asset Group name 
				objAssetFaultDataBean.setCustomerId(strCustID);                        // Cust ID
				if (initialLoad != null) {
					objAssetFaultDataBean.setInitLoad(initialLoad);                    // Init Load
				}
				if (fromDate != null) {
					objAssetFaultDataBean.setFromDate(fromDate);                       // From Date
				}
				if (toDate != null) {
					objAssetFaultDataBean.setToDate(toDate);                           // To Date
				}
				if (strDays != null) {
					objAssetFaultDataBean.setDropdownDays(strDays);
				}
				if (allData != null && allData.trim().equalsIgnoreCase("TRUE")) {
					objAssetFaultDataBean.setAllRecords("Y");					   // All Records - Y or N
				}
				if (caseId != null) {
					objAssetFaultDataBean.setCaseId(caseId);						   // Case ID	
				}
				if (caseType != null) {
					objAssetFaultDataBean.setCaseType(caseType);					   // Case Type	
				}
				if (caseFrom != null) {
					objAssetFaultDataBean.setStrCaseFrom(caseFrom);					   // Case From	
				}
				if (sortOrder != null) {
					objAssetFaultDataBean.setSortOption(sortOrder);					   // Sort Option	
				}
				if (fetchHc != null) {
					objAssetFaultDataBean.setHealthCheck(fetchHc);					   // Health Check
				}
				if (startRow != null) {
					objAssetFaultDataBean.setStartRow(startRow);					   // Start Row
				}
				if (ruleId != null) {
					objAssetFaultDataBean.setRuleId(ruleId);					   	   // Rule ID
				}
				if (ruleType != null) {
					objAssetFaultDataBean.setRuleType(ruleType);		   		   	   // Rule Type (JDPAD, CBR, CF)
				}
				if (notch8 != null && notch8.trim().equalsIgnoreCase("Y")) {
					objAssetFaultDataBean.setNotch8("Y");                              // Notch 8
				}
				DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
				String defaultTimezone  = (String) request.getAttribute(AppConstants.DEFAULT_TIMEZONE);
				String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone, userVO.getTimeZone());
				zoneFormater.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
				
				DateFormat gmtZoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
				gmtZoneFormater.setTimeZone(TimeZone.getTimeZone("GMT"));
				
				DateFormat estZoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
				estZoneFormater.setTimeZone(TimeZone.getTimeZone("US/Eastern"));				
				
				if (sortOrder != null && sortOrder.trim().equals(AppConstants.OCCUR_DATE) && fromDate != null && toDate != null) { 
					Calendar fromDtCal = Calendar.getInstance();
					fromDtCal.setTime(zoneFormater.parse(fromDate));
					objAssetFaultDataBean.setFromDate(gmtZoneFormater.format(fromDtCal.getTime()));
					
					Calendar toDtCal = Calendar.getInstance();
					toDtCal.setTime(zoneFormater.parse(toDate));
					objAssetFaultDataBean.setToDate(gmtZoneFormater.format(toDtCal.getTime()));
					
				} else if (sortOrder != null && sortOrder.trim().equals("OFFBOARD_LOAD_DATE") && fromDate != null && toDate != null) { 
					Calendar fromDtCal = Calendar.getInstance();
					fromDtCal.setTime(zoneFormater.parse(fromDate));
					objAssetFaultDataBean.setFromDate(estZoneFormater.format(fromDtCal.getTime()));
					
					Calendar toDtCal = Calendar.getInstance();
					toDtCal.setTime(zoneFormater.parse(toDate));
					objAssetFaultDataBean.setToDate(estZoneFormater.format(toDtCal.getTime()));
					
				}
				vvfLimitedCustParam = authService.getLookUpValueForName(AppConstants.DS_VVF_LIMITED_CUST_PARAM);
				isVvfLimitedCustParam = RMDCommonUtil.componentValue(userVO.getComponentList(), vvfLimitedCustParam);

				if (isVvfLimitedCustParam) {
					objAssetFaultDataBean.setLimitedParam(true);
				}	
				vvfHideL3Faults = authService.getLookUpValueForName(AppConstants.DATASCREEN_VVF_HIDE_L3_FAULTS);
				isVvfHideL3Faults = RMDCommonUtil.componentValue(userVO.getComponentList(), vvfHideL3Faults);

				if (isVvfHideL3Faults) {
					objAssetFaultDataBean.setHideL3Faults(true);
				}
				
				if (dataSets != null && !dataSets.isEmpty()) {
					if (equipmentType != null && !equipmentType.trim().equals("") 
							 && dataSets.trim().indexOf("EQUIP") > -1) {
						objAssetFaultDataBean.setDataSet(dataSets + "-" + equipmentType);
					} else {
						objAssetFaultDataBean.setDataSet(dataSets);						
					}
				} else if (caseId != null && caseType != null) {
					objAssetFaultDataBean.setDataSet("CASE");	
				} else {
					String rapidDataSetPrivilege = authService.getLookUpValueForName(AppConstants.RAPID_DATASET_DATASCREEN_PRIVILEGE);
					boolean isRapidDataSetPrivileged = RMDCommonUtil.componentValue(userVO.getComponentList(), rapidDataSetPrivilege);
					if (isRapidDataSetPrivileged) {
						objAssetFaultDataBean.setDataSet("RR-VEHICLE");
					} else {
						objAssetFaultDataBean.setDataSet("VEHICLE");	
					}					
				}
				
				String defNoOfDays = null;
				String maxDateRange = null;
				String screenFromDt = null;
				
				if (objAssetFaultDataBean.getDataSet().indexOf("RR-VEHICLE") > -1) {
					defNoOfDays = authService.getLookUpValueForName(AppConstants.RAPID_VEHICLE_FAULT_DEFAULT_NO_OF_DAYS);
					noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.RR_VEHICLE_FAULT_DROPDOWN_DAYS);
				} else if (objAssetFaultDataBean.getDataSet().equals("VEHICLE")) {
					defNoOfDays = authService.getLookUpValueForName(AppConstants.VEHICLE_FAULT_DEFAULT_NO_OF_DAYS);
					maxDateRange = authService.getLookUpValueForName(AppConstants.VEHICLE_FAULT_MAX_DATE_LIMIT);
					noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.VEHICLE_FAULT_DROPDOWN_DAYS);
				} else if (objAssetFaultDataBean.getDataSet().indexOf("RR-EQUIP") > -1) {
					defNoOfDays = authService.getLookUpValueForName(AppConstants.RAPID_EQUIPMENT_FAULT_DEFAULT_NO_OF_DAYS);
					noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.RR_EQUIPMENT_FAULT_DROPDOWN_DAYS);
				} else if (objAssetFaultDataBean.getDataSet().indexOf("EQUIP") > -1) {
					defNoOfDays = authService.getLookUpValueForName(AppConstants.EQUIPMENT_FAULT_DEFAULT_NO_OF_DAYS);	
					maxDateRange = authService.getLookUpValueForName(AppConstants.EQUIPMENT_FAULT_MAX_DATE_LIMIT);
					noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.EQUIPMENT_FAULT_DROPDOWN_DAYS);
				} else if (objAssetFaultDataBean.getDataSet().equals("DP/EAB")) {
					defNoOfDays = authService.getLookUpValueForName(AppConstants.DPEAB_FAULT_DEFAULT_NO_OF_DAYS);
					maxDateRange = authService.getLookUpValueForName(AppConstants.DPEAB_FAULT_MAX_DATE_LIMIT);
					noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.DPEAB_FAULT_DROPDOWN_DAYS);
				} else if (objAssetFaultDataBean.getDataSet().equals("DHMS")) {
					defNoOfDays = authService.getLookUpValueForName(AppConstants.DHMS_DEFAULT_NO_OF_DAYS);
					maxDateRange = authService.getLookUpValueForName(AppConstants.DHMS_FAULT_MAX_DATE_LIMIT);
					noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.DHMS_FAULT_DROPDOWN_DAYS);
				} else if (objAssetFaultDataBean.getDataSet().equals("INCIDENT")) {
					defNoOfDays = authService.getLookUpValueForName(AppConstants.INCIDENT_FAULT_DEFAULT_NO_OF_DAYS);
					maxDateRange = authService.getLookUpValueForName(AppConstants.INCIDENT_FAULT_MAX_DATE_LIMIT);
					noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.INCIDENT_FAULT_DROPDOWN_DAYS);
				} else if (objAssetFaultDataBean.getDataSet().indexOf("CASE") > -1) {
					noOfDaysList = objAssetDataScreenService.getNoOfDaysDropdownValues(AppConstants.CASE_DROPDOWN_DAYS);
				}				
				if (caseId == null && strDays == null && fromDate == null && toDate == null && defNoOfDays != null) {
					objAssetFaultDataBean.setDropdownDays(defNoOfDays);
				}

				objAssetDataResponse = objAssetDataScreenService.getAssetFaultData(objAssetFaultDataBean, userVO.getCustomerId());
				
				objAssetDataResponse.setAssetNumber(strAssetID);
				objAssetDataResponse.setAssetGrpName(strAsstGrpName);
				objAssetDataResponse.setCustomerId(strCustID);
				objAssetDataResponse.setAssetTabId(strAssetTabID);
				objAssetDataResponse.setCustomerId(strCustID);
				objAssetDataResponse.setAssetGrpName(strAsstGrpName);
				if (objAssetDataResponse.getFlagFAM() != null && objAssetDataResponse.getFlagFAM().equals("Y")) {
					objAssetDataResponse.setLinkFAM(faultAnalysisManualUrl);
				}
				
				Calendar cal = Calendar.getInstance();					
				
				cal.set(Calendar.SECOND, 0);
				String screenToDt = dateFormat.format(cal.getTime());				
				
				if (defNoOfDays != null) {
					objAssetDataResponse.setDefaultNoOfDays(defNoOfDays);
					cal.add(Calendar.DAY_OF_MONTH, -1 * Integer.parseInt(defNoOfDays));
					cal.set(Calendar.SECOND, 0);
					screenFromDt = dateFormat.format(cal.getTime());
					
					objAssetDataResponse.setDefaultFromDt(screenFromDt);
					objAssetDataResponse.setDefaultToDt(screenToDt);
				}
				if (noOfDaysList != null) {
					objAssetDataResponse.setNoOfDaysList(noOfDaysList);
				}
				if (maxDateRange != null) {
					objAssetDataResponse.setMaxDateRange(maxDateRange);
				}
				lsAssetFaultData = objAssetDataResponse.getLsFaultAssetValuePart();
				if (null != lsAssetFaultData) {
					objAssetDataResponse.setRows(lsAssetFaultData);
					objAssetDataResponse.setRecords(String.valueOf(lsAssetFaultData.size()));
					objAssetDataResponse.setPage(AppConstants.INDEX_1);
					objAssetDataResponse.setTotal(AppConstants.INDEX_10);
				}
				objAssetDataResponse.setLsFaultAssetValuePart(null);
			}
			boolean isHeatMapEnabled = RMDCommonUtil.componentValue(userVO.getComponentList(), "DATASCREEN_HEATMAP");
			objAssetDataResponse.setHeatMapEnabled(isHeatMapEnabled);
			final long endTime = System.currentTimeMillis();
			logger.debug("############ Class: DataGridController - Method: getColumnsAndModel() >> START TIME: "
					+ startTime + "ms  END TIME: " + endTime + "ms Columns & Model Difference: "
					+ (endTime - startTime) + "ms");
		} catch (Exception ex) {
			
			logger.error("Exception occured in getColumnsAndModel method ", ex);
			RMDWebErrorHandler.handleException(ex);
			
		}
		return objAssetDataResponse;
	}

	

	/*
	 * This method is added for Data Screen: Display Data drop down This method
	 * will convert the list to comma separated string
	 * 
	 * @param List<String> strValues
	 * 
	 * @return String
	 * 
	 * */
	public String convertListToCSV(final List<String> strValues) {
		final 	StringBuilder csvString = new StringBuilder();
		for (String value : strValues) {
			if (csvString.length() == 0) {
				csvString.append(AppConstants.SINGLE_QTE + value + AppConstants.SINGLE_QTE);
			} else {
				csvString.append(AppConstants.SEMI_QOUTE_SYMBOL + value + AppConstants.SINGLE_QTE);
			}
		}
		return csvString.toString();
	}
	//Method added for validation framework to validate caseId and ruleId
	public Map<String,String> validateCaseRule(final String caseId,final String ruleId,final List caseLst,final List<String> ruleList){
	
		final Map<String,String> failures = new HashMap<String, String>();
		if(caseId != null && ! caseId.isEmpty()){
			if(!caseLst.contains(caseId))
				failures.put(AppConstants.CASE_ID,AppConstants.INVALID);
		}
		if(ruleId != null && !ruleId.isEmpty()){
			if(!ruleList.contains(ruleId))
				failures.put(AppConstants.RULE_ID,AppConstants.INVALID);
		}
		return failures;
	}
	
	
	
	/**
	 * @Description:This method is used for looping through the list of
	 *                   datascreen records and will covert to csv content
	 * @return: String
	 * @param:collectiveResponse,Locale locale
	 */

	public String convertToCSVDataScreen(AssetDataResponseVO objAssetDataResponse, String userCustomer)
			throws Exception {

		String csvContent = null;
		StringBuilder strBufferDataScreen = new StringBuilder();
		List<ColModel> lstColModel = null;
		List<Map<String, String>> rows = null;
		try {
			List<ColModel> lstHeader = objAssetDataResponse.getColModel();;
			// loop through the headers and remove the html tags in headers and
			// form a comma seperated value
			HashMap<String, String> exportColumnMap = getExportColumn();
			HashMap<String, String> exportArznColumnMap = getExportArznColumn();
			
			for (Iterator<ColModel> iterlstHeader = lstHeader.iterator(); iterlstHeader.hasNext();) {
				ColModel column = (ColModel) iterlstHeader.next();
				if (userCustomer != null && userCustomer.trim().equals("ARZN")) {
					if (exportArznColumnMap.get(column.getIndex()) != null) {
						strBufferDataScreen.append(exportArznColumnMap.get(column.getIndex())
								+ RMDCommonConstants.COMMMA_SEPARATOR);		
					} else if (exportColumnMap.get(column.getIndex()) != null) {
						strBufferDataScreen.append(exportColumnMap.get(column.getIndex())
								+ RMDCommonConstants.COMMMA_SEPARATOR);		
					} else {
						strBufferDataScreen.append(RMDCommonUtil.removeDSHtmlandNullValues(column.getHeaderName())
								+ RMDCommonConstants.COMMMA_SEPARATOR);
					}
				} else if (exportColumnMap.get(column.getIndex()) != null) {
					strBufferDataScreen.append(exportColumnMap.get(column.getIndex())
							+ RMDCommonConstants.COMMMA_SEPARATOR);					
				} else {
					strBufferDataScreen.append(RMDCommonUtil.removeDSHtmlandNullValues(column.getHeaderName())
						+ RMDCommonConstants.COMMMA_SEPARATOR);
				}
			}
			strBufferDataScreen.append(RMDCommonConstants.NEWLINE);

			// loop through the rows and column name and forms the comma
			// seperated value
			lstColModel = objAssetDataResponse.getColModel();

			rows = objAssetDataResponse.getRows();
			for (Iterator<Map<String, String>> iterRows = rows.iterator(); iterRows.hasNext();) {
				Map<String, String> rowsMap = (Map<String, String>) iterRows
						.next();
				for (Iterator<ColModel> iterlstColModel = lstColModel.iterator(); iterlstColModel
						.hasNext();) {
					ColModel colModel = (ColModel) iterlstColModel.next();

					if (rowsMap.containsKey(colModel.getName())) {
						if (null != rowsMap.get(colModel.getName())) {
							strBufferDataScreen.append(RMDCommonUtil
									.removeHtmlandNullValuesWithSpace(rowsMap
											.get(colModel.getName()))
									+ RMDCommonConstants.COMMMA_SEPARATOR);
						} else {
							strBufferDataScreen
									.append(RMDCommonConstants.EMPTY_STRING
											+ RMDCommonConstants.COMMMA_SEPARATOR);
						}
					}
					else{
						strBufferDataScreen.append(RMDCommonConstants.EMPTY_STRING + RMDCommonConstants.COMMMA_SEPARATOR);
					}
				}
				strBufferDataScreen.append(RMDCommonConstants.NEWLINE);

			}

			csvContent = strBufferDataScreen.toString();

		} catch (Exception e) {
			logger.error(e);

		}
		return csvContent;

	}
	
	public HashMap<String, String> getExportArznColumn() {
		HashMap<String, String> dsArznHeaderMap = new HashMap<String, String>();
		dsArznHeaderMap.put("loco_speed", "Loco speed (Km/h)");
		dsArznHeaderMap.put("water_temp", "Water Temp (C)");
		dsArznHeaderMap.put("oil_temp", "Oil temp (C)");
		dsArznHeaderMap.put("hp", "HP (Kw)");
		dsArznHeaderMap.put("BASIC_LOCO_SPEED", "Loco speed (Km/h)");
		dsArznHeaderMap.put("BASIC_BP_PSI", "BP (kPa)");
		dsArznHeaderMap.put("BASIC_BC_PSI", "BC (kPa)");
		dsArznHeaderMap.put("BASIC_EFP", "EFP (kPa)");
		dsArznHeaderMap.put("BASIC_MAP", "MAP (kPa)");
		dsArznHeaderMap.put("BASIC_CCOP", "CCOP (cmH2O)");
		dsArznHeaderMap.put("BASIC_EWOP", "EWIP (kPa)");
		dsArznHeaderMap.put("BASIC_ELIP", "ELIP (kPa)");
		dsArznHeaderMap.put("BASIC_EWIT", "EWIT (C)");
		dsArznHeaderMap.put("BASIC_EWOT", "EWOT (C)");
		dsArznHeaderMap.put("BASIC_ELIT", "ELIT (C)");
		dsArznHeaderMap.put("BASIC_ELOT", "ELOT (C)");
		dsArznHeaderMap.put("BASIC_MAT", "MAT (C)");
		dsArznHeaderMap.put("BASIC_AT", "AT (C)");
		dsArznHeaderMap.put("BASIC_PTLT", "PTLT (C)");
		dsArznHeaderMap.put("BASIC_PTRT", "PTRT (C)");
		dsArznHeaderMap.put("ENGINE_GROSS_HP", "Gross HP (Kw)");
		dsArznHeaderMap.put(AppConstants.ENGINE_HP_AVAILABLE, "HP Available (Kw)");
		dsArznHeaderMap.put("ENGINE_LOAD_POT_HP", "Load Pot HP (Kw)");
		dsArznHeaderMap.put("PROP_TE_FDBK1", "TEFdbk1 (kN)");
		dsArznHeaderMap.put("PROP_TE_FDBK2", "TEFdbk2 (kN)");
		dsArznHeaderMap.put("PROP_TE_FDBK3", "TEFdbk3 (kN)");
		dsArznHeaderMap.put("PROP_TE_FDBK4", "TEFdbk4 (kN)");
		dsArznHeaderMap.put("PROP_TE_FDBK5", "TEFdbk5 (kN)");
		dsArznHeaderMap.put("PROP_TE_FDBK6", "TEFdbk6 (kN)");
		dsArznHeaderMap.put(AppConstants.AUX_MR1_PSI, "MR1 (kPa)"); 
		return dsArznHeaderMap;
	}
	
	public HashMap<String, String> getExportColumn() {
		HashMap<String, String> dsHeaderMap = new HashMap<String, String>();
		dsHeaderMap.put("PROP_GRID_BLWRS_SPD_BP", "Grid Blwrs Spd bp");
		dsHeaderMap.put("Supervisor_Level", "Supervisor Level");
		dsHeaderMap.put("ToolRunInd", "ToolRunInd");
		dsHeaderMap.put("AUX_AA_STATE", "AA State");
		dsHeaderMap.put("FAULT_RESET_MODE", "Manual Reset");
		dsHeaderMap.put("REC_TYPE", "Record Type");
		dsHeaderMap.put("FAULT_CLASSIFICATION", "Critical Fault");
		dsHeaderMap.put("FAULT2CFG_DEF", "Sample Rate (Sec)");
		dsHeaderMap.put("STD_EDP_DIRECT", "Direct");
		dsHeaderMap.put("STD_EDP_NOTCH", "Notch");
		dsHeaderMap.put("STD_EDP_VOLTS", "Volts");
		dsHeaderMap.put("STD_EDP_CALL", "Call");
		dsHeaderMap.put("STD_EDP_BLOWER", "Blower");
		dsHeaderMap.put("STD_EDP_RAD_FAN", "Rad Fan");
		dsHeaderMap.put("STD_EDP_BF", "B F");
		dsHeaderMap.put("BASIC_CAMW", "CAM W");
		dsHeaderMap.put("BASIC_EXC_STATE", "EXC State");
		dsHeaderMap.put("BASIC_AUX_STATE", "AUX State");
		dsHeaderMap.put("BASIC_ACTIVE_TMS", "Active TMS");
		dsHeaderMap.put("ENGINE_OKTOFIRE", "OktoFire");
		dsHeaderMap.put("ENGINE_ACTIVE_CRANK", "Active Crank");
		dsHeaderMap.put("ENGINE_NUM_ACT_CYL", "Num Act Cyl");
		dsHeaderMap.put("ENGINE_ENGINE_SPEED", "Engine Speed");
		dsHeaderMap.put("ENGINE_CRANK1_SPEED", "Crank1 Speed");
		dsHeaderMap.put("ENGINE_CRANK2_SPEED", "Crank2 Speed");
		dsHeaderMap.put("ENGINE_CAM_SPEED", "CAM Speed");
		dsHeaderMap.put("PROP_BCP", "BCP %");
		dsHeaderMap.put("AUX_AUX_ALT_VOLTS", "Aux Alt Volts");
		dsHeaderMap.put("AUX_AUX_FLD_AMPS", "Aux Fld Amps");
		dsHeaderMap.put("AUX_EBHI_AMPS", "Ebhi Amps");
		dsHeaderMap.put("AUX_EBLO_AMPS", "Eblo Amps");
		dsHeaderMap.put("AUX_RFHI_AMPS", "Rfhi Amps");
		dsHeaderMap.put("AUX_RFLO_AMPS", "Rflo Amps");
		dsHeaderMap.put("RES_MAX_ALLOW_NOTCH", "Max Allow Notch");
		dsHeaderMap.put("RES_HP_DERATION", "HP Deration");		
		dsHeaderMap.put("BASIC_WHL_SLP_DERATION", "Wheel Slipping Deration");
		dsHeaderMap.put("RES_ENG_COLD", "Eng Cold");
		dsHeaderMap.put("RES_ENG_VERY_COLD", "Eng Very Cold");
		dsHeaderMap.put("RES_ENG_VERY_HOT", "Eng Very Hot");
		dsHeaderMap.put("RES_LOW_H2O_PRESS", "Low H2O Pres");
		dsHeaderMap.put("RES_LOW_OIL_PRESS", "Low Oil Pres");		
		dsHeaderMap.put("RES_BATTERY_JOG", "Battery Jog");
		dsHeaderMap.put("RES_CRANK", "Crank");
		dsHeaderMap.put("RES_SELF_LOAD", "Self Load");
		dsHeaderMap.put("RES_SELF_LOAD_UNLOAD", "Self Load Unloaded");
		dsHeaderMap.put("RES_DYN_BRAKE", "DynBrake");
		dsHeaderMap.put("RES_MOTORING", "Monitoring");		
		dsHeaderMap.put("RES_ISOLATE", "Isolate");
		dsHeaderMap.put("RES_SELF_TEST", "SelfTest");
		dsHeaderMap.put("RES_PROP_GND", "PropGnd");
		dsHeaderMap.put("RES_TRAC_MOTOR1", "TM1");
		dsHeaderMap.put("RES_TRAC_MOTOR2", "TM2");
		dsHeaderMap.put("RES_TRAC_MOTOR3", "TM3");		
		dsHeaderMap.put("RES_TRAC_MOTOR4", "TM4");
		dsHeaderMap.put("RES_TRAC_MOTOR5", "TM5");
		dsHeaderMap.put("RES_TRAC_MOTOR6", "TM6");
		dsHeaderMap.put("RES_MAIN_ALT", "Main Alt");
		dsHeaderMap.put("RES_AUX_ALT", "Aux Alt");
		dsHeaderMap.put("RES_BATT_CHARGER", "Battery Charger");		
		dsHeaderMap.put("RES_AIR_COMPRESS", "Air Compressor");
		dsHeaderMap.put("RES_FAULT_LEVEL_1", "Fault Level 1");
		dsHeaderMap.put("RES_FAULT_LEVEL_2", "Fault Level 2");
		dsHeaderMap.put("RES_FAULT_LEVEL_3", "Fault Level 3");
		dsHeaderMap.put("FAULT_SKIP_COUNT", "Fault Skip Info");
		dsHeaderMap.put("FAULT_INDEX", "Fault Index");
		dsHeaderMap.put("fault_index", "Fault Index");
		dsHeaderMap.put("Fault_Index", "Index");
		dsHeaderMap.put("FRD_STATUS", "FRD Status");
		dsHeaderMap.put("SMART_EXCLUDE_STATUS", "Smart Exclude Status");
		dsHeaderMap.put("OIL_FILTER_STATUS", "Flt Filter Status");
		
		dsHeaderMap.put("LOCO_SPEED", AppConstants.LOCO_SPEED);
		dsHeaderMap.put("AUX_BATT_VOLTS", AppConstants.BATT_VOLTS);
		dsHeaderMap.put("BF", "B F");
		dsHeaderMap.put("FAULT_CODE", "Fault Code");
		dsHeaderMap.put("oil_temp", AppConstants.OIL_TMP);
		dsHeaderMap.put("basic_baro_pressure", "Baro Pres");
		dsHeaderMap.put("aux_mr1_psi", "MR1 psi");
		dsHeaderMap.put("BASIC_BRAKE_PERC", "B r a k e  %");
		dsHeaderMap.put("BASIC_BATT_VOLTS_BCC", AppConstants.BATT_VOLTS);
		dsHeaderMap.put("BASIC_BP_PSI", "BP PSI");
		dsHeaderMap.put(AppConstants.ENGINE_HP_AVAILABLE, AppConstants.HP_AVAILABLE);
		dsHeaderMap.put("AUX_TMB_SPD_CMD", "Tmb Spd Cmd");
		dsHeaderMap.put("BASIC_DP_ENABLED", "DP Enabled");
		dsHeaderMap.put("BASIC_LCCB", "L C C B");
		dsHeaderMap.put("BASIC_ECU_CIO_DTC_NET_STATUS", "ECU CIO DTC Net Status");
		dsHeaderMap.put("ENGINE_ECU_ENG_STATE", "ECU Eng State");
		dsHeaderMap.put("PROP_TRQ_CMD6", "Trq Cmd6");
		dsHeaderMap.put("AUX_AAC_PH_ANGLE", "AAC Ph Angle");
		dsHeaderMap.put("AUX_RF2_SPD_CMD", "RF2 spd cmd");
		dsHeaderMap.put("AUX_RF2_A_AMPS", "RF2 A Amps");
		dsHeaderMap.put("RFV1_PHC_CURR", "RFV1 Ph C curr");
		dsHeaderMap.put("ABM_PHASE_A_AMPS", "ABM Phase A Amps");
		dsHeaderMap.put("PROP_LINK_AVG_VOLTS", "Link Avg Volts");
		dsHeaderMap.put("PROXIMITY_LABEL", "Location");
		dsHeaderMap.put("WATER_TEMP", AppConstants.WAT_TMP);
		dsHeaderMap.put("info", "I n f o");
		dsHeaderMap.put("aux_batt_volts", AppConstants.BATT_VOLTS);
		dsHeaderMap.put("ENGINE_LOAD_POT_HP", "Load Pot HP");
		dsHeaderMap.put("ENGINE_MAX_HP_LIMIT", "Max HP Limit");
		dsHeaderMap.put("PROP_TM1_ARM_AMPS", "TM1 Arm Amps");
		dsHeaderMap.put("PROP_TM_FLD_AMPS", "TM Fld Amps");
		dsHeaderMap.put("AUX_AA_PHASE_B_CURR", "AA PhaseB Curr");
		dsHeaderMap.put("PROP_LINK_AVG_VOLTS", "Link Avg Volts");
		dsHeaderMap.put("PROP_INV5_MPH", "Inv 5 MPH");
		dsHeaderMap.put("AUX_RF1_C_AMPS", "RF1 C Amps");
		dsHeaderMap.put("AUX_LPS_POS_15_VOLT", "LPS Pos 15 Volt");
		dsHeaderMap.put("ENGINE_ECU_MODE", "ECU Mode");
		dsHeaderMap.put("PROP_LOCO_SPD_HEALTH", "Loco Spd Health");
		dsHeaderMap.put("PROP_SAS_MGR_STATE", "Sas mgr state");
		dsHeaderMap.put("PROP_TRQ_CMD1", "Trq Cmd1");
		dsHeaderMap.put("PROP_INV_MODE_TM1", "Inv Mode TM1");
		dsHeaderMap.put("PROP_REF_SPD_TGS_AXLE", "RefSpd TgsAxle");
		dsHeaderMap.put("PROP_MAX_PM_TEMP", "Max PM Temp");
		dsHeaderMap.put("PROP_DB_CONTACTORS_BP", "DB Contactors bp");
		dsHeaderMap.put("PROP_TAP_CURRENT", "TAP Curr");
		dsHeaderMap.put("AUX_RFC1_SPD_MODE_SBR", "RFC1 Spc Mode SBR");
		dsHeaderMap.put("Grid_Leg_2_Volts", "Grid Leg 2 Volts");
		dsHeaderMap.put("PROXIMITY_LABEL", "Location");
		dsHeaderMap.put("EGR_A_pos_fdbk", "EGR Bypass Pos fdbk");
		dsHeaderMap.put("ENGINE_TURBO_SPEED_LEFT", "Turbo Speed Left");
		dsHeaderMap.put("direct", "D i r e c t");
		dsHeaderMap.put("eng_speed", "Eng Speed");
		dsHeaderMap.put("blower", "B l o w e r");
		dsHeaderMap.put("basic_amb_deg", "Ambf Def");
		dsHeaderMap.put("aux_batt_curr", "Batt Curr");
		dsHeaderMap.put(AppConstants.BASIC_LOCO_STATE, AppConstants.LOCO_STATE);
		dsHeaderMap.put("PROP_TM6_ARM_AMPS", "TM6 Arm Amps");
		dsHeaderMap.put("PROP_MEAS_GND_LEAK_CURR", "Meas Gnd Leak Curr");
		dsHeaderMap.put("PROP_BARRIER_BAR", "Barrier Bar");
		dsHeaderMap.put("AUX_TMB_C_AMPS", "Tmb C Amps");
		dsHeaderMap.put("AUX_BATT_POS_GND_DC", "Batt + Gnd DC");
		dsHeaderMap.put("AUX_LPS_NEG_15_VOLT", "LPS -15 Volt");
		dsHeaderMap.put("PROP_TE_FDBK4", "TE Fdbk4");
		dsHeaderMap.put("PROP_INV3_MPH", "Inv 3 MPH");
		dsHeaderMap.put("AUX_AAC_IN_VOLTS", "AAC In Volts");
		dsHeaderMap.put("AUX_RF1_SPD_CMD", "RF1 Spd Cmd");
		dsHeaderMap.put("BASIC_DP_LR", "D P  L / R");
		dsHeaderMap.put("BASIC_NTWK_0_RECON", "Ntwk 0 Recon");
		dsHeaderMap.put("ENGINE_ENG_SPD_DEMAND", "EngSpd Demand");
		dsHeaderMap.put("ENGINE_FUEL_VALUE", "Fuel Value");
		dsHeaderMap.put("ENGINE_DUR_ANGLE", "Dur Angle");
		dsHeaderMap.put("ENGINE_ECU_PH6", "ECU Ph 6");
		dsHeaderMap.put("PROP_LOCO_SPD_QLTY", "Loco Spd qlty");
		dsHeaderMap.put("PROP_RTC_INV_RUN_CMDS", "Rtc inv run Cmds");
		dsHeaderMap.put("PROP_TRQ_CMD2", "Trq Cmd2");
		dsHeaderMap.put("PROP_TRQ_CMD4", "Trq Cmd4");
		dsHeaderMap.put("DIAM5AND6INCHES", "wheel dia 5 & 6 Inches");
		dsHeaderMap.put("TMD_MOT_TST_REQ_NV", "TMD Mot Tst Req NV");
		dsHeaderMap.put("PROP_TAC_PH_ANGLE", "TAC Ph Angle");
		dsHeaderMap.put("AUX_RF1_I2T_COUNTS", "RF1 i2t Counts");
		dsHeaderMap.put("LOCO_LATITUDE", "Loco Latitude");
		dsHeaderMap.put("Grid_Leg_4_Volts", "Grid Leg 4 Volts");
		dsHeaderMap.put("Grid_Leg_1_Volts", "Grid Leg 1 Volts");
		dsHeaderMap.put("WAT_TMP_C", AppConstants.WAT_TMP);
		dsHeaderMap.put(AppConstants.BASIC_LOCO_STATE, AppConstants.LOCO_STATE);
		dsHeaderMap.put(AppConstants.ENGINE_HP_AVAILABLE, AppConstants.HP_AVAILABLE);
		dsHeaderMap.put(AppConstants.BASIC_LOCO_STATE, AppConstants.LOCO_STATE);
		dsHeaderMap.put(AppConstants.BASIC_DIR_CALL, AppConstants.DIR_CALL);
		dsHeaderMap.put("PROP_SAND_STATE", "Sand State");
		dsHeaderMap.put("BASIC_AMB_DEG", "Ambf Deg");
		dsHeaderMap.put(AppConstants.AUX_MR1_PSI, "MR1 psi");
		dsHeaderMap.put("NOTCH", AppConstants.NOTCH_WITH_SPACE);
		dsHeaderMap.put("ALT_AMPS", "Alt Amps");
		dsHeaderMap.put("BLOWER", "B l o w e r");
		dsHeaderMap.put("occur_date", "Occur Date");
		dsHeaderMap.put("volts", "V o l t s");
		dsHeaderMap.put("water_temp", AppConstants.WAT_TMP);
		dsHeaderMap.put("aux_ac_rpm ", "A/C rpm");
		dsHeaderMap.put("BASIC_ENG_SPEED", "Engine Speed");
		dsHeaderMap.put("BASIC_TAC_LINK_VOLTS", "TAC Link Volts");
		dsHeaderMap.put(AppConstants.BASIC_DIR_CALL, AppConstants.DIR_CALL);
		dsHeaderMap.put("BASIC_ALT_LOAD_AMPS", "Alt Load Amps");
		dsHeaderMap.put("BASIC_LEAD_TRAIL", "L e a d / T r a i l");
		dsHeaderMap.put("AUX_RF1_A_AMPS", "RF 1A Amps");
		dsHeaderMap.put("BASIC_TAC_FIELD_CURRENT", "TAC Field Curr");
		dsHeaderMap.put("PROP_INV1_MPH", "Inv 1 MPH");
		dsHeaderMap.put("PROP_INV2_MPH", "Inv 2 MPH");
		dsHeaderMap.put("PROP_GND_DC_OHMS", "Gnd DC Ohms");
		dsHeaderMap.put("BASIC_CYC_SKIP_NET_STATUS", "Cyc Skip Net Status");
		dsHeaderMap.put("ENGINE_ADAP_FUEL_LIMIT", "Adap Fuel Limit");
		dsHeaderMap.put("DIAM1AND2INCHES", "wheel dia 1 & 2 Inches");
		dsHeaderMap.put("PROP_TMC_456_NET_STAT", "TMC456 NetStat");
		dsHeaderMap.put("AUX_RF_1_HP", "RF1 HP");
		dsHeaderMap.put("ENGINE_UNIVALVE_MODE", "Cool Valve CMD");
		dsHeaderMap.put("ENGINE_FUEL_RAIL_LEFT_PRESS", "Fuel Rail Left Press");
		dsHeaderMap.put("FUEL_RAIL_LT_PRESS", "Fuel Rail Left Press");
		dsHeaderMap.put("ENG_FUEL_PRES_K_C2", "Fuel Pres K");
		dsHeaderMap.put("OIL_TMP", AppConstants.OIL_TMP);
		dsHeaderMap.put("A_COMP", "A i r  C o m p");
		dsHeaderMap.put("LP_Turbo_Speed", "LP Turbo Speed");
		dsHeaderMap.put("HP_TURBO_BYPASS_VALVE_POS_FDBK", "HP turbine Bypass Valve Position fdbk");
		dsHeaderMap.put("ENG_SPEED", "Eng Speed");
		dsHeaderMap.put("BASIC_TAC_FIELD_CURR", "TAC Field Curr");
		dsHeaderMap.put("BASIC_BC_PSI", "BC PSI");
		dsHeaderMap.put("PROP_ACTIVE_AXLES", "Active Axles");
		dsHeaderMap.put("AUX_AA_FIELD_AMPS", "AA Field Amps");
		dsHeaderMap.put("AUX_AA_PHASE_A_CURR", "AA PhaseA Curr");
		dsHeaderMap.put("AUX_TMB_A_AMPS", "Tmb A Amps");
		dsHeaderMap.put(AppConstants.AUX_MR1_PSI, "MR1 PSI");
		dsHeaderMap.put("PROP_TE_FDBK2", "TE Fdbk2");
		dsHeaderMap.put("PROP_TE_FDBK5", "TE Fdbk5");
		dsHeaderMap.put("PROP_TE_FDBK6", "TE Fdbk6");
		dsHeaderMap.put("PROP_INV4_MPH", "Inv 4 MPH");
		dsHeaderMap.put("PROP_INV6_MPH", "Inv 6 MPH");
		dsHeaderMap.put("PROP_SLIP_SLIDES_BP", "Slip slides");
		dsHeaderMap.put("PROP_GND_AC_OHMS", "Gnd AC Ohms");
		dsHeaderMap.put("AUX_BATT_POS_GND_DC", "Batt Pos Gnd DC");
		dsHeaderMap.put("BASIC_PT_NET_STATUS", "PT Net Status");
		dsHeaderMap.put("ENGINE_ECU_PH5", "ECU Ph 5");
		dsHeaderMap.put("PROP_MOTORS_TURNING_BP", "Motors turning");
		dsHeaderMap.put("PROP_INV_LOCO_SPD", "Inv Loco Spd");
		dsHeaderMap.put("PROP_RUN_ELAD_CMDS", "Run Elad Cmds");
		dsHeaderMap.put("PROP_TRQ_CMD3", "Trq Cmd3");
		dsHeaderMap.put("PROP_CTS", "CTS");
		dsHeaderMap.put("PROP_PROP_VOLT_LIM", "Prop Volt Lim");
		dsHeaderMap.put("PROP_TAC_EST_JUNC_TEMP", "TAC Est Junc temp");
		dsHeaderMap.put("AUX_AIR_COMP_STATE", "Air Comp State");
		dsHeaderMap.put("ENGINE_FUEL_RAIL_RIGHT_PRESS", "Fuel Rail Right Press");
		dsHeaderMap.put("FUEL_RAIL_RT_PRESS", "Fuel Rail Right Press");
		dsHeaderMap.put("AUX_TBC_SPD_MODE_SBR", "Tbc Spd Mode Sbr");
		dsHeaderMap.put("ABM_PHASE_C_AMPS", "ABM Phase C Amps");
		dsHeaderMap.put("EX_SNAPSHOT_FLG", "Extra Polated Snapshot");
		dsHeaderMap.put(AppConstants.PROP_ACTIVE_TACHS, AppConstants.ACTIVE_TACHS);
		dsHeaderMap.put(AppConstants.ENGINE_HP_AVAILABLE, AppConstants.HP_AVAILABLE);
		dsHeaderMap.put("EGR_Metering_Pos_cmd", "EGR Metering Pos cmd");
		dsHeaderMap.put("EGR_Metering_Pos_fdbk", "EGR Metering Pos fdbk");
		dsHeaderMap.put("PROP_ACTIVE_AXLES", "Active Axles");
		dsHeaderMap.put(AppConstants.OCCUR_DATE, "Occur Date");
		dsHeaderMap.put("DIRECT", "D i r e c t");
		dsHeaderMap.put("CALL", "C a l l");
		dsHeaderMap.put("loco_speed", AppConstants.LOCO_SPEED);
		dsHeaderMap.put("ENGINE_GROSS_HP", "Gross HP");
		dsHeaderMap.put("PROP_TM3_ARM_AMPS", "TM3 Arm Amps");
		dsHeaderMap.put("PROP_TM5_ARM_AMPS", "TM5 Arm Amps");
		dsHeaderMap.put(AppConstants.PROP_ACTIVE_TACHS, AppConstants.ACTIVE_TACHS);
		dsHeaderMap.put("PROP_TRAC_EFF_FDBK_TOT_LB", "TE Fdbk Tot Lb");
		dsHeaderMap.put("AUX_AAC_IN_VOLTS", "AA In Volts");
		dsHeaderMap.put("AUX_RF1_B_AMPS", "RF1B Amps");
		dsHeaderMap.put("AUX_BCC_IN_VOLTS", "BCC In Volts");
		dsHeaderMap.put("AUX_LPS_POS_15_VOLT", "LPS +15 Volt");
		dsHeaderMap.put("AUX_AUX_HP", "Aux HP");
		dsHeaderMap.put("AUX_RF1_B_AMPS", "RF1 B Amps");
		dsHeaderMap.put("AUX_LPS_POS_5_VOLT", "LPS Pos 5 Volt");
		dsHeaderMap.put("ENGINE_FUEL_LIMIT", "Fuel Limit");
		dsHeaderMap.put("ENGINE_FPR_BDBK_ECU", "Fpr Fdbk ECU");
		dsHeaderMap.put("PROP_INV_MODE_TM4", "Inv Mode TM4");
		dsHeaderMap.put("PROP_INV_MODE_TM5", "Inv Mode TM5");
		dsHeaderMap.put("PROP_MAX_MOTOR_TEMP", "Max Motor Temp");
		dsHeaderMap.put("AUX_AAC_JUNC_TEMP", "AAC Junc Temp");
		dsHeaderMap.put("AUX_AUX_EXC_AC_GND", "Aux Exc AC Gnd");
		dsHeaderMap.put("LOCO_LONGITUDE", "Loco Longitude");
		dsHeaderMap.put("SAMPLE_NO", "SampleNo");
		dsHeaderMap.put("BAROMETRIC_PRES_K_C2", "Baro Pres K");
		dsHeaderMap.put("HP_Turbo_Speed", "HP Turbo Speed");
		dsHeaderMap.put("HP_TURBO_BYPASS_VALVE_POS_CMD", "HP turbine Bypass Valve Position CMD");
		dsHeaderMap.put("OIL_TEMP", AppConstants.OIL_TMP);
		dsHeaderMap.put("SUB_ID", "S u b I D");
		dsHeaderMap.put("fault_reset_date", "Reset Date");
		dsHeaderMap.put("rad_fan", "R a d  F a n");
		dsHeaderMap.put("notch", AppConstants.NOTCH_WITH_SPACE);
		dsHeaderMap.put("ENGINE_TURBO_SPEED", "Turbo Speed");
		dsHeaderMap.put("PROP_SAND_STATE", "Sand State");
		dsHeaderMap.put("AUX_AA_PHASE_C_CURR", "AA PhaseC Curr");
		dsHeaderMap.put("PROP_TE_FDBK1", "TE Fdbk1");
		dsHeaderMap.put("AUX_RF1_A_AMPS", "RF1 A Amps");
		dsHeaderMap.put("AUX_LPS_NEG_15_VOLT", "LPS Neg 15 Volt");
		dsHeaderMap.put(AppConstants.AUX_MR1_PSI, "MR1 Psi");
		dsHeaderMap.put("BASIC_DP_LINKED", "DP Linked");
		dsHeaderMap.put("BASIC_PH_CTRL_NET_STATUS", "PH Ctrl Net Status");
		dsHeaderMap.put("BASIC_NTWK_1_RECON", "Ntwk 1 Recon");
		dsHeaderMap.put("ENGINE_FUEL_DEMAND", "Fuel Demand");
		dsHeaderMap.put("PROP_TRQ_CMD5", "Trq Cmd5");
		dsHeaderMap.put("DIAM3AND4INCHES", "wheel dia 3 & 4 Inches");
		dsHeaderMap.put("TMD_MOT_TYPE_NV", "TMD Mot Type NV");
		dsHeaderMap.put("PROP_INV_TOT_HP", "Inv Tot Hp");
		dsHeaderMap.put("AUX_RF2_C_AMPS", "RF2 C Amps");
		dsHeaderMap.put("ABM_PHASE_B_AMPS", "ABM Phase B Amps");
		dsHeaderMap.put("Grid_Leg_5_Volts", "Grid Leg 5 Volts");
		dsHeaderMap.put("BATT_V", AppConstants.BATT_VOLTS);
		dsHeaderMap.put(AppConstants.BASIC_DIR_CALL, AppConstants.DIR_CALL);
		dsHeaderMap.put("PROP_BARRIER_BAR", "Barrier Bar");
		dsHeaderMap.put("TAC_Link_Volt_Ref", "TAC Link Ref");
		dsHeaderMap.put("RAD_FAN", "R a d  F a n");
		dsHeaderMap.put("FAULT_RESET_DATE", "Reset Date");
		dsHeaderMap.put("VOLTS", "V o l t s");
		dsHeaderMap.put("ALT_FIELD", "Alt Field");
		dsHeaderMap.put("INFO", "I n f o");
		dsHeaderMap.put("bf", "B  F");
		dsHeaderMap.put(AppConstants.OCCUR_DATE, "Occur Time(GMT)");
		dsHeaderMap.put("BASIC_LOCO_SPEED", AppConstants.LOCO_SPEED);
		dsHeaderMap.put("BASIC_NOTCH", AppConstants.NOTCH_WITH_SPACE);
		dsHeaderMap.put("BASIC_AA_VHZ", "AA (v/hz)");
		dsHeaderMap.put("BASIC_BCC_AMPS", "BCC Amps");
		dsHeaderMap.put("PROP_TM2_ARM_AMPS", "TM2 Arm Amps");
		dsHeaderMap.put("PROP_TM4_ARM_AMPS", "TM4 Arm Amps");
		dsHeaderMap.put("AUX_RF1_C_AMPS", "RF1C Amps");
		dsHeaderMap.put("AUX_TMB_B_AMPS", "Tmb B Amps");
		dsHeaderMap.put("AUX_LPS_POS_5_VOLT", "LPS +5 Volt");
		dsHeaderMap.put("AUX_AIR_COMP_SPD", "Air Comp Spd");
		dsHeaderMap.put("PROP_TE_FDBK3", "TE Fdbk3");
		dsHeaderMap.put("BASIC_LOCO_ACCEL", "Loco Accel");
		dsHeaderMap.put("ENGINE_ADV_ANGLE", "Adv Angle");
		dsHeaderMap.put("PROP_SAS_TRQ_STATE", "Sas trq state");
		dsHeaderMap.put("PROP_INV_MODE_TM2", "Inv Mode TM2");
		dsHeaderMap.put("PROP_INV_MODE_TM3", "Inv Mode TM3");
		dsHeaderMap.put("PROP_INV_MODE_TM6", "Inv Mode TM6");
		dsHeaderMap.put("PROP_TMC_123_NET_STAT", "TMC123 Net Stat");
		dsHeaderMap.put("PROP_PWR_REG_ERR", "Pwr Reg Err");
		dsHeaderMap.put("AUX_AA_MTR_VOLTS", "AA Mtr Volts");
		dsHeaderMap.put("AUX_RF2_B_AMPS", "RF2 B Amps");
		dsHeaderMap.put("AUX_RF2_I2T_COUNTS", "RF2 i2t Counts");
		dsHeaderMap.put("AUX_BCC_PH_ANGLE", "BCC Ph Angle");
		dsHeaderMap.put("AUX_BATT_POS_GND_AC", "Batt Pos Gnd AC");
		dsHeaderMap.put("AUX_BATT_VOLTS_EP", AppConstants.BATT_VOLTS);
		dsHeaderMap.put("Grid_Leg_3_Volts", "Grid Leg 3 Volts");
		dsHeaderMap.put("LOCO_SPEED_KPH", AppConstants.LOCO_SPEED);
		dsHeaderMap.put("MAX_POWER_LIMIT", "Max PWR Limit");
		dsHeaderMap.put("EGR_A_pos_cmd", "EGR Bypass Pos cmd");
		dsHeaderMap.put(AppConstants.PROP_ACTIVE_TACHS, AppConstants.ACTIVE_TACHS);

		return dsHeaderMap;
	}

	/**
	 * @Description:This method retrieves all assetDataScreen for downloading
	 *                   the datscreen records
	 * @return void
	 * @param HttpServletRequest
	 *            request,HttpServletResponse response
	 */
	@RequestMapping(value = AppConstants.EXPORT_DATA_DATASCREEN, method = {
			RequestMethod.POST, RequestMethod.GET })
	public void exportDataForDataScreen(final HttpServletRequest request,
			final HttpServletResponse response) throws Exception {

		AssetDataResponseVO objAssetDataResponse = new AssetDataResponseVO();
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		try {
			objAssetDataResponse=getColumnsAndModel(request);			

			final UserVO userVO = (UserVO) request.getSession(false).getAttribute(
					AppConstants.ATTR_USER_OBJECT);
			objServletOutputStream = response.getOutputStream();
			// calling converToCSVDataScreen method to convert the
			// listCaseResponseVO to comma seperated value
			csvContent = convertToCSVDataScreen(objAssetDataResponse, userVO.getCustomerId());
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.DATASCREEN_EXPORT_FILENAME);
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(objByteArrayInputStream);

			objBufferedOutputStream = new BufferedOutputStream(objServletOutputStream);

			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0, byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}

		} catch (Exception ex) {
			logger.error("Exception occured in exportToCSVDataScreen method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}

	/**
	 * @Author:
	 * @param:HttpServletRequest
	 * @return:Map<String, String>
	 * @throws RMDWebException
	 * @Description: This method used for fetching unit configuration details in
	 *               data screen.
	 */
	@RequestMapping(value = AppConstants.UNIT_CONFIG)
	public @ResponseBody
	Map<String, List<String>> getUnitConfigDetails(
			final HttpServletRequest request) throws RMDWebException {
		logger.debug("AssetCases Controller : getUnitConfig() method Starts");
		final String locoId = request
				.getParameter(AppConstants.ESERVICES_LOCO_ID);
		final String caseId = request.getParameter(AppConstants.CASE_Id);
		Map<String, List<String>> unitConfigMap = null;
		CaseBean objCaseBean = null;
		try {
			if (null != locoId
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(locoId)
					&& null != caseId
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(caseId)) {
				objCaseBean = new CaseBean();
				objCaseBean.setLocoId(locoId);
				objCaseBean.setCaseId(caseId);
				unitConfigMap = objAssetDataScreenService
						.getUnitConfigDetails(objCaseBean);
			}
		} catch (Exception ex) {
			logger.error("Exception occured in unit config method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return unitConfigMap;

	}

}
