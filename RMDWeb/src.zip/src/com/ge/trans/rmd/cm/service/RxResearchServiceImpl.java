package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.RxRepairCodeDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.RxResearchVO;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.assets.valueobjects.RxRepairResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.RxResearchResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
@Service
public class RxResearchServiceImpl implements RxResearchService{
	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	WebServiceInvoker webServiceInvoker;
	@Override
	public List<String> getSearchSolution(RxResearchVO rxResearchVO)
			throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		RxResearchResponseType[] objRxResearchResponseType = null;
		List<String> map = new ArrayList<String>();
		try {
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getSelectBy())) {
					queryParams.put(AppConstants.SELECT_BY_OPTIONS,rxResearchVO.getSelectBy());
				} else {
					queryParams.put(AppConstants.SELECT_BY_OPTIONS,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getCondition())) {
					queryParams.put(AppConstants.CONDITION,rxResearchVO.getCondition());
				} else {
					queryParams.put(AppConstants.CONDITION,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getSearchVal())) {
					queryParams.put(AppConstants.SEARCH_VAL,rxResearchVO.getSearchVal());
				} else {
					queryParams.put(AppConstants.SEARCH_VAL,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getRxType())) {
					queryParams.put(AppConstants.RX_TYPE,rxResearchVO.getRxType());
				} else {
					queryParams.put(AppConstants.RX_TYPE,AppConstants.EMPTY_STRING);
				}
				objRxResearchResponseType = (RxResearchResponseType[]) webServiceInvoker
						.get(ServiceConstants.GET_RXRESEARCH_SEARCH_SOLUTION, null,
								queryParams, null, RxResearchResponseType[].class);
				if (null != objRxResearchResponseType && objRxResearchResponseType.length > 0) {
					for (RxResearchResponseType rxResearchResponseType : objRxResearchResponseType) {
						map.add(rxResearchResponseType.getRxTitle());

					}
				}
				objRxResearchResponseType = null;
				

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getSearchSolution method of RxResearchServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return map;
	}
	@Override
	public List<RxResearchVO> getGraphicalData(RxResearchVO rxResearchVO)
			throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		RxResearchResponseType[] objRxResearchGraphicalResponseType = null;
		List<RxResearchVO> graphList = new ArrayList<RxResearchVO>();
		RxResearchVO list = null;
		try {
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getSelectBy())) {
					queryParams.put(AppConstants.SELECT_BY_OPTIONS,rxResearchVO.getSelectBy());
				} else {
					queryParams.put(AppConstants.SELECT_BY_OPTIONS,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getCondition())) {
					queryParams.put(AppConstants.CONDITION,rxResearchVO.getCondition());
				} else {
					queryParams.put(AppConstants.CONDITION,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getSearchVal())) {
					queryParams.put(AppConstants.SEARCH_VAL,rxResearchVO.getSearchVal());
				} else {
					queryParams.put(AppConstants.SEARCH_VAL,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getRxType())) {
					queryParams.put(AppConstants.RX_TYPE,rxResearchVO.getRxType());
				} else {
					queryParams.put(AppConstants.RX_TYPE,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getStartDate())) {
					queryParams.put(AppConstants.FROM_DATE,rxResearchVO.getStartDate());
				} else {
					queryParams.put(AppConstants.FROM_DATE,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getEndDate())) {
					queryParams.put(AppConstants.TO_DATE,rxResearchVO.getEndDate());
				} else {
					queryParams.put(AppConstants.TO_DATE,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getCaseType())) {
					queryParams.put(AppConstants.CASE_TYPE,rxResearchVO.getCaseType());
				} else {
					queryParams.put(AppConstants.CASE_TYPE,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getCustomerId())) {
					queryParams.put(AppConstants.CUSTOMER_ID,rxResearchVO.getCustomerId());
				} else {
					queryParams.put(AppConstants.CUSTOMER_ID,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getFleet())) {
					queryParams.put(AppConstants.FLEET,rxResearchVO.getFleet());
				} else {
					queryParams.put(AppConstants.FLEET,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getModel())) {
					queryParams.put(AppConstants.MODEL,rxResearchVO.getModel());
				} else {
					queryParams.put(AppConstants.MODEL,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getRnh())) {
					queryParams.put(AppConstants.RNH,rxResearchVO.getRnh());
				} else {
					queryParams.put(AppConstants.RNH,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getIsGoodFdbk())) {
					queryParams.put(AppConstants.ISGOODFDBK,rxResearchVO.getIsGoodFdbk());
				} else {
					queryParams.put(AppConstants.ISGOODFDBK,AppConstants.EMPTY_STRING);
				}
				objRxResearchGraphicalResponseType = (RxResearchResponseType[]) webServiceInvoker
						.get(ServiceConstants.GET_RXRESEARCH_GET_GRAPH_DATA, null,
								queryParams, null, RxResearchResponseType[].class);
				if (null != objRxResearchGraphicalResponseType && objRxResearchGraphicalResponseType.length > 0) {
					for (RxResearchResponseType rxResearchResponseType : objRxResearchGraphicalResponseType) {
						list = new RxResearchVO();
						list.setRepairCode(rxResearchResponseType.getRepairCode());
						list.setRxCount(rxResearchResponseType.getRxCount());
						list.setRepairDesc(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(rxResearchResponseType.getRepairDesc())));
						graphList.add(list);
					}
				}
				objRxResearchGraphicalResponseType = null;
				

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getGraphicalData method of RxResearchServiceImpl ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return graphList;
	}
	@Override
	public List<RxRepairCodeDetailsVO> populateRepairCodeDetails(
			RxResearchVO rxResearchVO) throws RMDWebException {
		final Map<String, String> queryParams = new LinkedHashMap<String, String>();
		RxRepairResponseType[] objRxRepairResponseType = null;
		List<RxRepairCodeDetailsVO> rxRepairCodeDetailsVOList = new ArrayList<RxRepairCodeDetailsVO>();
		RxRepairCodeDetailsVO rxRepairCodeDetailsVO = null;
		try {
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getRepairCode())) {
					queryParams.put(AppConstants.REPAIR_CODE,rxResearchVO.getRepairCode());
				} else {
					queryParams.put(AppConstants.REPAIR_CODE,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getSearchVal())) {
					queryParams.put(AppConstants.SEARCH_VAL,rxResearchVO.getSearchVal());
				} else {
					queryParams.put(AppConstants.SEARCH_VAL,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getRxType())) {
					queryParams.put(AppConstants.RX_TYPE,rxResearchVO.getRxType());
				} else {
					queryParams.put(AppConstants.RX_TYPE,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getStartDate())) {
					queryParams.put(AppConstants.FROM_DATE,rxResearchVO.getStartDate());
				} else {
					queryParams.put(AppConstants.FROM_DATE,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getEndDate())) {
					queryParams.put(AppConstants.TO_DATE,rxResearchVO.getEndDate());
				} else {
					queryParams.put(AppConstants.TO_DATE,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getCaseType())) {
					queryParams.put(AppConstants.CASE_TYPE,rxResearchVO.getCaseType());
				} else {
					queryParams.put(AppConstants.CASE_TYPE,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getCustomerId())) {
					queryParams.put(AppConstants.CUSTOMER_ID,rxResearchVO.getCustomerId());
				} else {
					queryParams.put(AppConstants.CUSTOMER_ID,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getFleet())) {
					queryParams.put(AppConstants.FLEET,rxResearchVO.getFleet());
				} else {
					queryParams.put(AppConstants.FLEET,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getModel())) {
					queryParams.put(AppConstants.MODEL,rxResearchVO.getModel());
				} else {
					queryParams.put(AppConstants.MODEL,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getRnh())) {
					queryParams.put(AppConstants.RNH,rxResearchVO.getRnh());
				} else {
					queryParams.put(AppConstants.RNH,AppConstants.EMPTY_STRING);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getInitFlag())) {
					queryParams.put(AppConstants.INIT_LOAD,rxResearchVO.getInitFlag());
				} else {
					queryParams.put(AppConstants.INIT_LOAD,AppConstants.NO_FLAG);
				}
				if (!RMDCommonUtility.isNullOrEmpty(rxResearchVO.getIsGoodFdbk())) {
					queryParams.put(AppConstants.ISGOODFDBK,rxResearchVO.getIsGoodFdbk());
				} else {
					queryParams.put(AppConstants.ISGOODFDBK,AppConstants.EMPTY_STRING);
				}
				
				objRxRepairResponseType = (RxRepairResponseType[]) webServiceInvoker
						.get(ServiceConstants.POPULATE_REPAIRCODE_SOLUTION_DETAILS, null,
								queryParams, null, RxRepairResponseType[].class);
				if (null != objRxRepairResponseType && objRxRepairResponseType.length > 0) {
					for (RxRepairResponseType rxRxRepairResponseType : objRxRepairResponseType) {
						rxRepairCodeDetailsVO = new RxRepairCodeDetailsVO();
						rxRepairCodeDetailsVO.setRxCaseID(rxRxRepairResponseType.getRxCaseID());
						rxRepairCodeDetailsVO.setCustomerId(rxRxRepairResponseType.getCustomerId());
						rxRepairCodeDetailsVO.setVehicleNo(rxRxRepairResponseType.getVehicleNo());
						rxRepairCodeDetailsVO.setCaseSuccess(rxRxRepairResponseType.getCaseSuccess());
						rxRepairCodeDetailsVO.setRepairCode(rxRxRepairResponseType.getRepairCode());
						rxRepairCodeDetailsVO.setMissCode(rxRxRepairResponseType.getMissCode());
						rxRepairCodeDetailsVO.setGoodFdbk(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(rxRxRepairResponseType.getGoodFdbk())));
						rxRepairCodeDetailsVO.setRxTitle(rxRxRepairResponseType.getRxTitle());
						rxRepairCodeDetailsVO.setRxUrgency(rxRxRepairResponseType.getRxUrgency());
						rxRepairCodeDetailsVO.setCaseType(rxRxRepairResponseType.getCaseType());
						rxRepairCodeDetailsVO.setRxOpenDate(rxRxRepairResponseType.getRxOpenDate());
						rxRepairCodeDetailsVO.setRxCloseDate(rxRxRepairResponseType.getRxCloseDate());
						rxRepairCodeDetailsVO.setRxFeedback(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(rxRxRepairResponseType.getRxFeedback())));
						rxRepairCodeDetailsVO.setRepairCodeDesc(EsapiUtil.resumeSpecialChars(ESAPI.encoder().decodeForHTML(rxRxRepairResponseType.getRepairCodeDesc())));
						rxRepairCodeDetailsVOList.add(rxRepairCodeDetailsVO);

					}
				}
				objRxRepairResponseType = null;
				

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in populateRepairCodeDetails method of RxResearchServiceImpl ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return rxRepairCodeDetailsVOList;
	}

}
