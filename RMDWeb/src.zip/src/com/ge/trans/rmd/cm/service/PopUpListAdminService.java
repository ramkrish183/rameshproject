package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;


import com.ge.trans.rmd.cm.valueobjects.LookupSearchServiceVO;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.valueobjects.GetSysLookupMultilangVO;
import com.ge.trans.rmd.common.valueobjects.GetSysLookupVO;
import com.ge.trans.rmd.exception.RMDServiceException;

public interface PopUpListAdminService {

	
	
	/**
	 * @Author:
	 * @param objLookupServiceSearch
	 * @return
	 * @throws RMDServiceException
	 * @Description:
	 */
	List<GetSysLookupVO> getPopupList(LookupSearchServiceVO objLookupServiceSearch) throws RMDServiceException;
	
	/**
	 * @Author:
	 * @param sysLookupVO
	 * @return
	 * @throws RMDServiceException
	 * @Description:
	 */
	String savePopupList(GetSysLookupVO sysvo)  throws RMDWebException,Exception;
	List<GetSysLookupVO> getPopupListValues(GetSysLookupVO sysvo) throws RMDServiceException;
	
	
	
	/**
	 * @Author:
	 * @param sysLookupVO
	 * @return
	 * @throws RMDServiceException
	 * @Description:
	 */
	String updatePopupList(GetSysLookupVO sysvo)  throws RMDWebException,Exception;
	
	/**
	 * @Author:
	 * @param sysvo
	 * @throws RMDServiceException
	 * @Description:
	 */
	String deletePopupList(GetSysLookupVO sysvo) throws RMDServiceException,Exception;
	
	/**
	 * @Author:
	 * @param sysvo
	 * @throws RMDServiceException
	 * @Description:
	 */
	//void deletePopupListValue(GetSysLookupVO sysvo) throws RMDServiceException;
	
	/**
	 * @Author:
	 * @param sysvo1
	 * @param sysvo2
	 * @return
	 * @throws RMDServiceException
	 * @Description:
	 */
	public String updatePopupListValues(List<GetSysLookupVO> list, String userId) throws RMDServiceException,Exception;
	/**
	 * @Author:
	 * @param sysLookupVO
	 * @return
	 * @throws RMDServiceException
	 * @Description:
	 */
	String savePopupListlookvalue(GetSysLookupVO sysvo)  throws RMDWebException,Exception;
	
	/**
	 * @Author:
	 * @param sysvo
	 * @throws RMDServiceException
	 * @Description:
	 */
	String removePopupListlookvalue(GetSysLookupVO sysvo) throws RMDServiceException,Exception;


	
	
	
	



}
