package com.ge.trans.rmd.cm.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FilenameUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.codehaus.jackson.map.type.TypeFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.LDVRGeofenceRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRGeofenceResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRGeofenceVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRSaveGeofenceRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRSaveGeofenceResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRSaveGeofenceStatus;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRGeofenceRequestType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRGeofenceResponseType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRGeofenceType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRSaveGeofenceRequest;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRSaveGeofenceRequestType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRSaveGeofenceResponseType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRSaveGeofenceStatusType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class LDVRGeofenceServiceImpl implements LDVRGeofenceService {

	private final RMDWebLogger rmdWebLogger = RMDWebLogger.getLogger(getClass());

	@Autowired
	private WebServiceInvoker webServiceInvoker;

	@Autowired
	private LDVRRequestsService ldvrRequestsService;

	@Value("${" + AppConstants.HEALH_CHECK_SEND_MESSAGE_SERVICE_USERNAME + "}")
	String mcsGetNumCamerasUsername;
	@Value("${" + AppConstants.HEALH_CHECK_SEND_MESSAGE_SERVICE_PASSWORD + "}")
	String mcsGetNumCamerasPassowrd;

	@Value("${" + AppConstants.LDVR_MCS_GET_GEOZONES_URL + "}")
	String getLDVRGeoZonesURL;

	@Value("${" + AppConstants.LDVR_MCS_SAVEUPDATE_GEOZONES_URL + "}")
	String saveUpdateLDVRGeoZones;

	@Autowired
	private AuthorizationService authorizationService;

	public LDVRGeofenceResponseVO getLDVRGeoZones(LDVRGeofenceRequestVO ldvrGeofenceRequestVO) throws RMDWebException,Exception {
		
		rmdWebLogger
				.info("Inside LDVRGeofenceServiceImpl in getLDVRGeoZones Method");

		LDVRGeofenceResponseVO ldvrGeofenceResponseVO = new LDVRGeofenceResponseVO();
		LDVRGeofenceResponseType ldvrGeofenceResponseType = new LDVRGeofenceResponseType();

		try {
			LDVRGeofenceRequestType ldvrGeofenceRequestType = new LDVRGeofenceRequestType();
			ldvrGeofenceRequestType.setActiveFlag(ldvrGeofenceRequestVO
					.getActiveFlag());
			ldvrGeofenceRequestType.setAssetOwnerId(ldvrGeofenceRequestVO
					.getAssetOwnerId());
			ldvrGeofenceRequestType.setGeozoneName(ldvrGeofenceRequestVO
					.getGeofenceName());

			ObjectWriter ow = new ObjectMapper().writer()
					.withDefaultPrettyPrinter();
			String inputJson = ow.writeValueAsString(ldvrGeofenceRequestType);
			rmdWebLogger.info(inputJson);

			String responseJson = (String) webServiceInvoker.postMCSWebService(
					mcsGetNumCamerasUsername, mcsGetNumCamerasPassowrd,
					getLDVRGeoZonesURL, inputJson, String.class);
			ObjectMapper mapper = new ObjectMapper();
			List<LDVRGeofenceType> geofenceList = mapper.readValue(
					responseJson,
					TypeFactory.defaultInstance().constructCollectionType(
							List.class, LDVRGeofenceType.class));
			rmdWebLogger.info("getGeozones res:" + responseJson);
			ldvrGeofenceResponseType.setLdvrGeoZones(geofenceList);
			LDVRGeofenceVO geofenceVO;
			ldvrGeofenceResponseVO
					.setLdvrGeoZones(new ArrayList<LDVRGeofenceVO>());
			for (LDVRGeofenceType geofenceType : ldvrGeofenceResponseType
					.getLdvrGeoZones()) {
				geofenceVO = new LDVRGeofenceVO();
				geofenceVO.setAssetOwnerId(geofenceType.getAssetOwnerId());
				geofenceVO.setGeozoneId(geofenceType.getGeoZoneId());
				geofenceVO.setGeozoneName(geofenceType.getGeoZoneName());
				geofenceVO.setGeozoneObjid(geofenceType.getGeozoneObjid());

				geofenceVO.setLattitude1(geofenceType.getLatitude1());
				geofenceVO.setLattitude3(geofenceType.getLatitude3());
				geofenceVO.setLongitude1(geofenceType.getLongitude1());
				geofenceVO.setLongitude3(geofenceType.getLongitude3());
				geofenceVO.setObsolete(geofenceType.getObsolete());
				geofenceVO.setActive(geofenceType.getActive());
				if ("Y".equalsIgnoreCase(geofenceType.getActive())) {
					geofenceVO.setGeozoneStatus(AppConstants.ACTIVE);
				} else
					geofenceVO.setGeozoneStatus(AppConstants.INACTIVE);
				ldvrGeofenceResponseVO.getLdvrGeoZones().add(geofenceVO);
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger
					.error(AppConstants.EXCEPTION_IN_LDVR_GEOZONE_METHOD,
							rmdEx);
			throw rmdEx;

		} catch (Exception ex) {
			rmdWebLogger
					.error(AppConstants.EXCEPTION_IN_LDVR_GEOZONE_METHOD,
							ex);
			throw ex;
		}
		rmdWebLogger
				.info("Inside  LDVRGeofenceServiceImpl in getLDVRGeoZones Method Done");

		return ldvrGeofenceResponseVO;
	}

	public LDVRSaveGeofenceResponseVO saveUpdateLDVRGeoZones(
			List<LDVRSaveGeofenceRequestVO> ldvrSaveGeofenceRequestVOs)
			throws RMDWebException, Exception {
		rmdWebLogger
				.info("Inside LDVRGeofenceServiceImpl in getLDVRGeoZones Method");
		LDVRSaveGeofenceRequestType ldvrSaveGeofenceRequestType = new LDVRSaveGeofenceRequestType();
		ldvrSaveGeofenceRequestType
				.setListLdvrGeozoneSaveRequestVO(new ArrayList<LDVRSaveGeofenceRequest>());
		LDVRSaveGeofenceRequest ldvrSaveGeofenceRequest;
		NumberFormat formatter = new DecimalFormat(AppConstants.GEOFORMAT);
		for (LDVRSaveGeofenceRequestVO ldvrSaveGeofenceRequestVO : ldvrSaveGeofenceRequestVOs) {
			ldvrSaveGeofenceRequest = new LDVRSaveGeofenceRequest();
			ldvrSaveGeofenceRequest.setActiveFlag(ldvrSaveGeofenceRequestVO
					.getActive());
			ldvrSaveGeofenceRequest.setAssetOwnerId(ldvrSaveGeofenceRequestVO
					.getAssetOwnerId());
			ldvrSaveGeofenceRequest.setGeozoneId(ldvrSaveGeofenceRequestVO
					.getGeozoneId());
			ldvrSaveGeofenceRequest.setGeozoneName(ldvrSaveGeofenceRequestVO
					.getGeozoneName());
			ldvrSaveGeofenceRequest.setGeozoneObjId(ldvrSaveGeofenceRequestVO
					.getGeozoneObjId());

			ldvrSaveGeofenceRequest.setLattitude1(formatter
					.format(ldvrSaveGeofenceRequestVO.getLattitude1()));
			ldvrSaveGeofenceRequest.setLattitude3(formatter
					.format(ldvrSaveGeofenceRequestVO.getLattitude3()));
			ldvrSaveGeofenceRequest.setLongitude1(formatter
					.format(ldvrSaveGeofenceRequestVO.getLongitude1()));
			ldvrSaveGeofenceRequest.setLongitude3(formatter
					.format(ldvrSaveGeofenceRequestVO.getLongitude3()));

			ldvrSaveGeofenceRequest.setUserName(ldvrSaveGeofenceRequestVO
					.getUserName());
			ldvrSaveGeofenceRequestType.getListLdvrGeozoneSaveRequestVO().add(
					ldvrSaveGeofenceRequest);
		}
		LDVRSaveGeofenceResponseVO ldvrSaveGeofenceResponseVO = new LDVRSaveGeofenceResponseVO();
		LDVRSaveGeofenceStatus geofenceStatus = null;
		LDVRSaveGeofenceResponseType ldvrSaveGeofenceResponseType = null;
		try {
				ObjectWriter ow = new ObjectMapper().writer().withDefaultPrettyPrinter();
				String inputJson = ow.writeValueAsString(ldvrSaveGeofenceRequestType);
				rmdWebLogger
				.info("LDVRGeofenceService Request ::: " + inputJson);

			ldvrSaveGeofenceResponseType = (LDVRSaveGeofenceResponseType) webServiceInvoker
					.postMCSWebService(mcsGetNumCamerasUsername,
							mcsGetNumCamerasPassowrd, saveUpdateLDVRGeoZones,
							inputJson, LDVRSaveGeofenceResponseType.class);

			ldvrSaveGeofenceResponseVO.setStatus(ldvrSaveGeofenceResponseType
					.getStatus());
			if (ldvrSaveGeofenceResponseType.getLdvrSaveGeofenceStatus() != null
					&& ldvrSaveGeofenceResponseType.getLdvrSaveGeofenceStatus()
							.size() != 0) {
				ldvrSaveGeofenceResponseVO
						.setLdvrSaveGeofenceStatus(new ArrayList<LDVRSaveGeofenceStatus>());
				for (LDVRSaveGeofenceStatusType statusType : ldvrSaveGeofenceResponseType
						.getLdvrSaveGeofenceStatus()) {
					geofenceStatus = new LDVRSaveGeofenceStatus();
					geofenceStatus
							.setAssetOwnerId(statusType.getAssetOwnerId());
					ldvrSaveGeofenceResponseVO.getLdvrSaveGeofenceStatus().add(
							geofenceStatus);
				}
			}
		} catch (RMDWebException rmdEx) {
			String errorMsgCustom = ldvrRequestsService.getLookupValueForError(
					rmdEx.getErrorCode(), rmdEx.getErrorType());
			if (!RMDCommonUtility.isNullOrEmpty(errorMsgCustom)) {
				rmdEx.setErrorType(errorMsgCustom);
			}
			rmdWebLogger
					.error(AppConstants.EXCEPTION_IN_LDVR_GEOZONE_METHOD,
							rmdEx);
			throw rmdEx;

		} catch (Exception ex) {
			rmdWebLogger
					.error(AppConstants.EXCEPTION_IN_LDVR_GEOZONE_METHOD,
							ex);
			throw ex;
		}
		rmdWebLogger
				.info("Inside  LDVRGeofenceServiceImpl in getLDVRGeoZones Method Done");

		return ldvrSaveGeofenceResponseVO;
	}

	public List<LDVRSaveGeofenceRequestVO> readXLS(File file, String userName,
			String customerId) throws Exception {

		FileInputStream excelFileToRead = null;
		List<LDVRSaveGeofenceRequestVO> ldvrSaveGeofenceRequestVOs = new ArrayList<LDVRSaveGeofenceRequestVO>();

		XSSFWorkbook wbXSSF; // Declare XSSF WorkBook
		HSSFWorkbook wbHSSF; // Declare HSSF WorkBook
		Sheet sheet = null; // sheet for WorkBook
		try {
			if (FilenameUtils.isExtension(file.getName(), "xls")) {
				excelFileToRead = new FileInputStream(file);
				wbHSSF = new HSSFWorkbook(excelFileToRead);
				sheet = (Sheet) wbHSSF.getSheetAt(0);
				ldvrSaveGeofenceRequestVOs = readFromExcel(sheet, userName,
						customerId);

			} else if (FilenameUtils.isExtension(file.getName(), "xlsx")) {
				excelFileToRead = new FileInputStream(file);
				wbXSSF = new XSSFWorkbook(excelFileToRead);
				sheet = wbXSSF.getSheetAt(0);
				ldvrSaveGeofenceRequestVOs = readFromExcel(sheet, userName,
						customerId);
			}
		} catch (RMDWebException rmdEx) {
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger
			.error("Invalid values in the import file , please check the file !!",ex);
			throw ex;					
		} finally {
			try {
				if(excelFileToRead != null)
				excelFileToRead.close();
			} catch (IOException ioe) {
				rmdWebLogger
				.error(AppConstants.EXCEPTION_IN_LDVR_GEOZONE_METHOD_WHILE_IMPORTING,
						ioe);
			}
		}

		return ldvrSaveGeofenceRequestVOs;
	}

public List<LDVRSaveGeofenceRequestVO> readFromExcel(Sheet sheet,
			String userName, String customerId) throws Exception {
		StringBuilder excelContent;
		List<LDVRSaveGeofenceRequestVO> ldvrSaveGeofenceRequestVOs = new ArrayList<LDVRSaveGeofenceRequestVO>();
		LDVRSaveGeofenceRequestVO sgl = null;

		try {

			Iterator<Row> rowIterator = sheet.rowIterator();
			while (rowIterator.hasNext()) {
				Row row = rowIterator.next();
				sgl = new LDVRSaveGeofenceRequestVO();
				sgl.setUserName(userName);
				Iterator<Cell> cellIterator = row.cellIterator();
				excelContent = new StringBuilder();
				int cellindex = 0;
				if (row.getRowNum() != 0) {
					while (cellIterator.hasNext()) {
						sgl.setUserName(userName);
						sgl.setAssetOwnerId(customerId);
						sgl.setActive(AppConstants.YES_FLAG);
						Cell cell = cellIterator.next();
						switch (cell.getCellType()) {
						
						case Cell.CELL_TYPE_BLANK:
							throw new Exception("Invalid values in the import file , please check the file !!");
						case Cell.CELL_TYPE_STRING:
							excelContent.append(cell.getStringCellValue()
									.trim() + " ");
							switch (cellindex) {
							case 0:
								if(RMDCommonUtility.isNullOrEmpty(cell.getStringCellValue())){
									throw new Exception("Import file has incorrect value :Geozone Name");
								}else
								sgl.setGeozoneName(cell.getStringCellValue()
										.trim());
								break;
							case 1:
								if(RMDCommonUtility.isNullOrEmpty(cell.getStringCellValue())){
									throw new Exception("Import file has incorrect value :GPS Upper Left Lat");
								}else
								sgl.setLattitude1(Double.parseDouble(cell
										.getStringCellValue().trim()));
								break;
							case 2:
								if(RMDCommonUtility.isNullOrEmpty(cell
										.getStringCellValue())){
									throw new Exception("Import file has incorrect value :GPS Upper Left Long");
								}else
								sgl.setLongitude1(Double.parseDouble(cell
										.getStringCellValue().trim()));
								break;
							case 3:
								if(RMDCommonUtility.isNullOrEmpty(cell
										.getStringCellValue())){
									throw new Exception("Import file has incorrect value :GPS Upper Right Lat");
								}else
								sgl.setLattitude3(Double.parseDouble(cell
										.getStringCellValue().trim()));
								break;

							case 4:
								if(RMDCommonUtility.isNullOrEmpty(cell
										.getStringCellValue())){
									throw new Exception("Import file has incorrect value :GPS Upper Right Long");
								}else
								sgl.setLongitude3(Double.parseDouble(cell
										.getStringCellValue().trim()));
								break;
							}
							break;
						case Cell.CELL_TYPE_NUMERIC:
							excelContent.append(("" + cell
									.getNumericCellValue()).trim() + " ");
							switch (cellindex) {
							case 0:
								if(RMDCommonUtility.isNullOrEmpty(String.valueOf(cell.getNumericCellValue()))){
									throw new Exception("Import file has incorrect value :Geozone Name");
								}else
								sgl.setGeozoneName(""
										+ cell.getNumericCellValue());
								break;
							case 1:
								if(RMDCommonUtility.isNullOrEmpty(String.valueOf(cell.getNumericCellValue()))){
									throw new Exception("Import file has incorrect value :GPS Upper Left Lat");
								}else
								sgl.setLattitude1(cell.getNumericCellValue());
								break;
							case 2:
								if(RMDCommonUtility.isNullOrEmpty(String.valueOf(cell.getNumericCellValue()))){
									throw new Exception("Import file has incorrect value :GPS Upper Left Long");
								}else
								sgl.setLongitude1(cell.getNumericCellValue());
								break;
							case 3:
								if(RMDCommonUtility.isNullOrEmpty(String.valueOf(cell.getNumericCellValue()))){
									throw new Exception("Import file has incorrect value :GPS Upper Right Lat");
								}else
								sgl.setLattitude3(cell.getNumericCellValue());
								break;
							case 4:
								if(RMDCommonUtility.isNullOrEmpty(String.valueOf(cell.getNumericCellValue()))){
									throw new Exception("Import file has incorrect value :GPS Upper Right Long");
								}else
								sgl.setLongitude3(cell.getNumericCellValue());
								break;
							}
							break;
						}
						cellindex++;
					}
					ldvrSaveGeofenceRequestVOs.add(sgl);
					rmdWebLogger.info(excelContent.toString());
				}

			}
		} catch (Exception ex) {
			
			/*rmdWebLogger
			.error("Unexpected Error occurred while reading the excel file,please check values in the excel sheet!!",ex);*/
		
			rmdWebLogger
			.error(ex);
			throw ex;					
		}
		return ldvrSaveGeofenceRequestVOs;
	}

}
