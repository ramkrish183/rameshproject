package com.ge.trans.rmd.cm.valueobjects;

public class CustomerFdbkVO 
{
	private String custFdbkObjId;
	private String ServiceReqId;
	private String isRxPresent;
	private String rxCloseDate;
	private String caseSuccess;
	private String rxFdbk;
	private String rxCaseId;
	
	public String getCustFdbkObjId() {
		return custFdbkObjId;
	}
	public void setCustFdbkObjId(String custFdbkObjId) {
		this.custFdbkObjId = custFdbkObjId;
	}
	public String getServiceReqId() {
		return ServiceReqId;
	}
	public void setServiceReqId(String serviceReqId) {
		ServiceReqId = serviceReqId;
	}
	public String getRxCloseDate() {
		return rxCloseDate;
	}
	public void setRxCloseDate(String rxCloseDate) {
		this.rxCloseDate = rxCloseDate;
	}
	public String getCaseSuccess() {
		return caseSuccess;
	}
	public void setCaseSuccess(String caseSuccess) {
		this.caseSuccess = caseSuccess;
	}
	public String getRxFdbk() {
		return rxFdbk;
	}
	public void setRxFdbk(String rxFdbk) {
		this.rxFdbk = rxFdbk;
	}
	public String getIsRxPresent() {
		return isRxPresent;
	}
	public void setIsRxPresent(String isRxPresent) {
		this.isRxPresent = isRxPresent;
	}
	public String getRxCaseId() {
		return rxCaseId;
	}
	public void setRxCaseId(String rxCaseId) {
		this.rxCaseId = rxCaseId;
	}
	
}
