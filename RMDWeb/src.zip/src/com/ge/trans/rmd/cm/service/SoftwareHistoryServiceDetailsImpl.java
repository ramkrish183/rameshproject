package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.common.valueobjects.SoftwareHistoryVO;
import com.ge.trans.rmd.services.assets.valueobjects.SotwareHistoryResponceType;
import com.ge.trans.rmd.tools.keys.util.CommonUtils;

@Service
public class SoftwareHistoryServiceDetailsImpl extends RMDBaseServiceImpl implements SoftwareHistoryService{
	
	private final RMDWebLogger logger = RMDWebLogger.getLogger(getClass());	

	@Autowired
	private WebServiceInvoker rsInvoker;
	
	@Override
	public List<SoftwareHistoryVO> viewSoftwareHistory(String strAssetId, String strCustomerId) throws RMDWebException, Exception {
		// TODO Auto-generated method stub
		//rsInvoker = new WebServiceInvoker();
		logger.info("SoftwareHistoryServiceDetailsImpl class of viewSoftwareHistory method start");
		List<SoftwareHistoryVO> softwareHistoryResponseVOs= new ArrayList<SoftwareHistoryVO>();
		SoftwareHistoryVO historyVO = null;
		SotwareHistoryResponceType[] sotwareHistoryResponceType = null;
		Map<String, String> queryParamMap = new HashMap<String, String>();
		queryParamMap.put(AppConstants.ASSET_NUMBER, strAssetId);
		queryParamMap.put(AppConstants.CUSTOMER_ID, strCustomerId);
		try{
			/*sotwareHistoryResponceType = (SotwareHistoryResponceType[])(rsInvoker.post(
					ServiceConstants.GET_SOFTWARE_HISTORY_DETAILS, softwareHistoryRequestType,
					SotwareHistoryResponceType[].class));*/
			
			sotwareHistoryResponceType = (SotwareHistoryResponceType[]) rsInvoker
					.get(ServiceConstants.GET_SOFTWARE_HISTORY_DETAILS, null,
							queryParamMap, null,SotwareHistoryResponceType[].class);
			if (null != sotwareHistoryResponceType
	                && sotwareHistoryResponceType.length > 0) {				
				for(SotwareHistoryResponceType historyResponceType : sotwareHistoryResponceType) {
					historyVO = new SoftwareHistoryVO();
					historyVO.setActive(historyResponceType.getActive().toString());
					String configFile = historyResponceType.getConfigurationFile();
					if(configFile != null){
						String foutByteString  = configFile.substring(54, 62);
						String  swappedValue = CommonUtils.getSwappedValue(foutByteString);
						Integer decimal=Integer.parseInt(swappedValue,16);  
						historyVO.setConfigurationFile(decimal.toString());
					}else{
						historyVO.setConfigurationFile("");
					}
					historyVO.setDataSyncHdr(historyResponceType.getDataSyncHdr());
					historyVO.setDataSyncRd(historyResponceType.getDataSyncRd());
					historyVO.setDeviceReporting(historyResponceType.getDeviceReporting());
					historyVO.setSdisVersion(historyResponceType.getSdisVersion());
					String startDateString =historyResponceType.getDataSoftwarewasReported();
					DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS"); 
					SimpleDateFormat sm = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				    Date startDate;
				    startDate = df.parse(startDateString);
				    String newDateString = sm.format(startDate);
				    historyVO.setDataSoftwarewasReported(newDateString);
					historyVO.setUpdatedBy(historyResponceType.getUpdatedBy());
					softwareHistoryResponseVOs.add(historyVO);
				 }
				}
			logger.info("SoftwareHistoryServiceDetailsImpl class of viewSoftwareHistory method END");
			
		}catch (Exception e) {
			// TODO: handle exception
			 logger.error(
		                "Exception occured in viewSoftwareHistory in SoftwareHistoryServiceDetailsImpl:",e);
		        		RMDWebErrorHandler.handleException(e);
		}
		
		
	
		return softwareHistoryResponseVOs;
	}

}
