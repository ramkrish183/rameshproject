/**
 * 
 */
package com.ge.trans.rmd.cm.valueobjects;

/**
 * @author 212338353
 *
 */
public class CloseSummaryVO {
	 
	private String caseId;
    private String caseTitle;
    private String repairCode;
    private String repairCdDesc;
    private String rxTitle;
    private String toolId;
    
	public String getRxTitle() {
		return rxTitle;
	}
	public void setRxTitle(String rxTitle) {
		this.rxTitle = rxTitle;
	}
	public String getToolId() {
		return toolId;
	}
	public void setToolId(String toolId) {
		this.toolId = toolId;
	}
	/**
	 * @return the caseId
	 */
	public String getCaseId() {
		return caseId;
	}
	/**
	 * @param caseId the caseId to set
	 */
	public void setCaseId(String caseId) {
		this.caseId = caseId;
	}
	/**
	 * @return the caseTitle
	 */
	public String getCaseTitle() {
		return caseTitle;
	}
	/**
	 * @param caseTitle the caseTitle to set
	 */
	public void setCaseTitle(String caseTitle) {
		this.caseTitle = caseTitle;
	}
	/**
	 * @return the repairCode
	 */
	public String getRepairCode() {
		return repairCode;
	}
	/**
	 * @param repairCode the repairCode to set
	 */
	public void setRepairCode(String repairCode) {
		this.repairCode = repairCode;
	}
	/**
	 * @return the repairCdDesc
	 */
	public String getRepairCdDesc() {
		return repairCdDesc;
	}
	/**
	 * @param repairCdDesc the repairCdDesc to set
	 */
	public void setRepairCdDesc(String repairCdDesc) {
		this.repairCdDesc = repairCdDesc;
	}
	
}
