package com.ge.trans.rmd.cm.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;
import org.codehaus.jackson.map.type.TypeFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.ge.trans.rmd.cm.valueobjects.DataSetVO;
import com.ge.trans.rmd.cm.valueobjects.DataVO;
import com.ge.trans.rmd.cm.valueobjects.LDVREventVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRGeofenceResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRGeofenceVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRMPVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRMasterDataRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRMasterDataResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRSaveTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRSaveTemplateResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRTemplateDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRTemplateResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRTimeFrameVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.locovision.valueobjects.DataSetType;
import com.ge.trans.rmd.services.locovision.valueobjects.DataType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRMPType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRMasterDataRequestType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRMasterDataResponseType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRSaveTemplateResponseType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRTemplateGeofences;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRTemplateRequestType;
import com.ge.trans.rmd.services.locovision.valueobjects.LDVRTemplateResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class ManageLDVRRequestsServiceImpl extends RMDBaseServiceImpl implements
		ManageLDVRRequestsService {

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private WebServiceInvoker webServiceInvoker;
	@Value("${" + AppConstants.LDVR_GET_TEMPLATE_URL + "}")
	String mcsGetTemplateURL;
	@Value("${" + AppConstants.LDVR_SAVE_TEMPLATE_URL + "}")
	String mcsSaveTemplateURL;	
	@Value("${" + AppConstants.LDVR_GET_MASTER_DATA_URL + "}")
	String mcsGetMasterDataURL;
	@Value("${" + AppConstants.HEALH_CHECK_SEND_MESSAGE_SERVICE_USERNAME + "}")
	String mcsGetNumCamerasUsername;
	@Value("${" + AppConstants.HEALH_CHECK_SEND_MESSAGE_SERVICE_PASSWORD + "}")
	String mcsGetNumCamerasPassowrd;

	// 
	public List<LDVRTemplateResponseVO> getLDVRTemplateList(
			LDVRTemplateRequestVO ldvrTemplateRequestVO)
			throws RMDWebException, Exception {
		rmdWebLogger
				.info("Inside ManageLDVRRequestsServiceImpl in getLDVRTemplateList Method Done");
		List<LDVRTemplateResponseVO> lstLDVRTemplateResponseVO = new ArrayList<LDVRTemplateResponseVO>();
		LDVRTemplateDetailsVO templateDetailsVO = null;
		LDVRTimeFrameVO ldvrTimeframeVO = null;
		LDVRMPVO ldvrMPVO = null;
		LDVRGeofenceVO ldvrGeofenceVO = null;
		
		LDVRTemplateResponseVO ldvrTemplateResponseVO = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			LDVRTemplateRequestType ldvrTemplateRequestType = new LDVRTemplateRequestType();
			
			ldvrTemplateRequestType
					.setApplicationId(RMDCommonConstants.LDVR_MCS_APPLICATION_ID);
			ldvrTemplateRequestType.setMessageId(ldvrTemplateRequestVO
					.getMessageId());
			ldvrTemplateRequestType.setDescription(ldvrTemplateRequestVO
					.getTemplateDescription());
			if (!RMDCommonUtility.isNullOrEmpty(ldvrTemplateRequestVO
					.getTemplateNumber())){
				ldvrTemplateRequestType.setTemplateNumber(Long.valueOf(
						ldvrTemplateRequestVO.getTemplateNumber()));
			}else{
				ldvrTemplateRequestType.setTemplateNumber(null);
			}
			if (!RMDCommonUtility.isNullOrEmpty(ldvrTemplateRequestVO
					.getTemplateVersion())){
				ldvrTemplateRequestType.setTemplateVersion(Long.valueOf(
						ldvrTemplateRequestVO.getTemplateVersion()));
			}else{
				ldvrTemplateRequestType.setTemplateVersion(null);
			}
			ldvrTemplateRequestType.setTemplateStatus(ldvrTemplateRequestVO
					.getTemplateStatus());			
			ldvrTemplateRequestType.setCustomerId(ldvrTemplateRequestVO
					.getCustomerId());
			ldvrTemplateRequestType.setDevice(ldvrTemplateRequestVO.getDevice());
			//Added for AGT template
			ldvrTemplateRequestType.setCategory(ldvrTemplateRequestVO.getCategory());
			ldvrTemplateRequestType.setControllerConfiguration(ldvrTemplateRequestVO.getCtrlCfgName());

			String requestJson = mapper.writer().withDefaultPrettyPrinter()
					.writeValueAsString(ldvrTemplateRequestType);

			rmdWebLogger
					.info("Inside ManageLDVRRequestsServiceImpl in getLDVRTemplateList Method request "
							+ requestJson);

			String responseJson = (String) webServiceInvoker.postMCSWebService(
					mcsGetNumCamerasUsername, mcsGetNumCamerasPassowrd,
					mcsGetTemplateURL, requestJson, String.class);

			rmdWebLogger
					.info("Inside ManageLDVRRequestsServiceImpl in getLDVRTemplateList Method request :: "
							+ ldvrTemplateRequestType.toString());

			List<LDVRTemplateResponseType> ldvrTemplateList = mapper.readValue(
					responseJson,
					TypeFactory.defaultInstance().constructCollectionType(
							List.class, LDVRTemplateResponseType.class));
			if (ldvrTemplateList != null) {
				for (LDVRTemplateResponseType templateResponseType : ldvrTemplateList) {
					LDVREventVO ldvrEventVO = new LDVREventVO();
					LDVRGeofenceResponseVO ldvrGeoRespVO = new LDVRGeofenceResponseVO();
					ldvrTemplateResponseVO = new LDVRTemplateResponseVO();
					templateDetailsVO = new LDVRTemplateDetailsVO();
					ldvrTemplateResponseVO
							.setTemplateCategoryName(templateResponseType
									.getTemplateCategoryName());
					/*
					 * Added for LocoVision for Rally Id - US225688:Aurizon - LCV - Validation 
					 * for MP's to be fixed both at MCS and OMD
					 */
					/*ldvrTemplateResponseVO
							.setTemplateTypeName(templateResponseType
									.getTemplateTypeName());*/
					if (!RMDCommonUtility.isNullOrEmpty(templateResponseType
							.getTemplateTypeName())
							&& AppConstants.LDVR_PRESERVATION_DOWNLOAD_TEMPLATE
									.equalsIgnoreCase(templateResponseType
											.getTemplateTypeName())) {
						ldvrTemplateResponseVO
								.setTemplateTypeName(AppConstants.PRESERVE_VIDEO_AUDIO_TEMPLATE);
					}
				
					ldvrTemplateResponseVO
							.setTemplateObjId(templateResponseType
									.getTemplateObjId());
					ldvrTemplateResponseVO
							.setApplicationId(templateResponseType
									.getApplicationId());
					ldvrTemplateResponseVO.setMessageId(templateResponseType
							.getMessageId());
					ldvrTemplateResponseVO
							.setTemplateNumber(templateResponseType
									.getTemplateNumber());
					ldvrTemplateResponseVO
							.setTemplateVersion(templateResponseType
									.getTemplateVersion());
					ldvrTemplateResponseVO.setDescription(templateResponseType
							.getDescription());
					ldvrTemplateResponseVO
							.setTemplateStatus(templateResponseType
									.getTemplateStatus());
					ldvrTemplateResponseVO.setCreatedBy(templateResponseType
							.getCreatedBy());
					if (!RMDCommonUtility.isNullOrEmpty(templateResponseType
							.getCreatedDate()))
						ldvrTemplateResponseVO.setCreatedDate(RMDCommonUtility
						.convertDateFormatTimezone(templateResponseType
								.getCreatedDate(),
								RMDCommonConstants.MMddyyyyhhmmssa,
								RMDCommonConstants.ddMMyyyyHHmmss,
								ldvrTemplateRequestVO.getTimeZone()));
					
					ldvrTemplateResponseVO
							.setLastUpdatedBy(templateResponseType
									.getLastUpdatedBy());
					if (!RMDCommonUtility.isNullOrEmpty(templateResponseType
							.getLastUpdatedDate()))
						ldvrTemplateResponseVO.setLastUpdatedDate(RMDCommonUtility
								.convertDateFormatTimezone(templateResponseType
										.getLastUpdatedDate(),
										RMDCommonConstants.MMddyyyyhhmmssa,
										RMDCommonConstants.ddMMyyyyHHmmss,
										ldvrTemplateRequestVO.getTimeZone()));
							

					if (null != templateResponseType.getLdvrTemplateDetType()) {
						if (null != templateResponseType
								.getLdvrTemplateDetType().getTimeframe()) {
							ldvrTimeframeVO = new LDVRTimeFrameVO();
							if (!RMDCommonUtility.isNullOrEmpty(templateResponseType
									.getLdvrTemplateDetType()
									.getTimeframe()
									.getRequestedStartTime()))							
								ldvrTimeframeVO
										.setRequestedStartTime(RMDCommonUtility
												.convertDateFormatTimezone(templateResponseType
														.getLdvrTemplateDetType()
														.getTimeframe()
														.getRequestedStartTime(),
														RMDCommonConstants.MMddyyyyhhmma,
														RMDCommonConstants.ddMMyyyyHHmmss,
														ldvrTemplateRequestVO.getTimeZone()));
							templateDetailsVO.setTimeframe(ldvrTimeframeVO);
						}
						ldvrEventVO.setMps(new ArrayList<LDVRMPVO>());
						ldvrGeoRespVO.setLdvrGeoZones(new ArrayList<LDVRGeofenceVO>());
						if (null != templateResponseType
								.getLdvrTemplateDetType().getEvent()) {
							ldvrEventVO
							.setPreTriggerAndPostTrigger(templateResponseType
									.getLdvrTemplateDetType()
									.getEvent()
									.getPreTriggerAndPostTrigger());		
							
							for (LDVRMPType eventType : templateResponseType
									.getLdvrTemplateDetType().getEvent()
									.getMps()) {
								ldvrMPVO = new LDVRMPVO();
								ldvrMPVO.setMpOperator(eventType
										.getMpOperator());
								ldvrMPVO.setMpParams(eventType.getMpParams());
								ldvrMPVO.setMpValue(eventType.getMpValue());
								ldvrEventVO.getMps().add(ldvrMPVO);
							}
							
						}
						if (null != templateResponseType
								.getLdvrTemplateDetType().getGeoZone()) {
							for (LDVRTemplateGeofences geofenceType : templateResponseType
									.getLdvrTemplateDetType().getGeoZone()
									.getGeoZones()) {
								ldvrGeofenceVO = new LDVRGeofenceVO();
								ldvrGeofenceVO.setGeozoneId(geofenceType
										.getGeoZoneId());
								ldvrGeofenceVO.setGeozoneName(geofenceType
										.getGeoZoneName());
								ldvrGeofenceVO.setGeozoneObjid(geofenceType
										.getGeozoneObjid());
								ldvrGeofenceVO.setAssetOwnerId(geofenceType
										.getAssetOwnerId());
								ldvrGeofenceVO.setLattitude1(geofenceType
										.getLatitude1());
								ldvrGeofenceVO.setLattitude3(geofenceType
										.getLatitude3());
								ldvrGeofenceVO.setLongitude1(geofenceType
										.getLongitude1());
								ldvrGeofenceVO.setLongitude3(geofenceType
										.getLongitude3());
								ldvrGeofenceVO.setActive(geofenceType
										.getActive());
								ldvrGeoRespVO.getLdvrGeoZones().add(
										ldvrGeofenceVO);
							}
							
						}
						templateDetailsVO.setGeoZone(ldvrGeoRespVO);
						templateDetailsVO.setEvent(ldvrEventVO);
						templateDetailsVO.setCameraList(templateResponseType
								.getLdvrTemplateDetType().getCameraList());
						templateDetailsVO.setDeletionType(templateResponseType
								.getLdvrTemplateDetType().getDeletionType());
						templateDetailsVO.setImportance(templateResponseType
								.getLdvrTemplateDetType().getImportance());
						if (!RMDCommonUtility.isNullOrEmpty(templateResponseType
								.getLdvrTemplateDetType()
								.getRequestedEndTime()))
							templateDetailsVO
									.setRequestedEndTime(RMDCommonUtility
											.convertDateFormatTimezone(templateResponseType
													.getLdvrTemplateDetType()
													.getRequestedEndTime(),
													RMDCommonConstants.MMddyyyyhhmma,
													RMDCommonConstants.ddMMyyyyHHmmss,
													ldvrTemplateRequestVO.getTimeZone()));

					}
					//Added for AGT - Apply functionality
					if(RMDCommonConstants.AGT_GROUP.equals(ldvrTemplateRequestVO.getCategory())){
					    List<String> inDevice = Arrays.asList(ldvrTemplateRequestVO.getDevice().split(RMDCommonConstants.COMMMA_SEPARATOR));
					    if(inDevice.size()>1){
					        List<String> outDevice = templateResponseType.getDevices();
					        if(outDevice.size()>1){
					            if(outDevice.contains(RMDCommonConstants.CMU)){
					                ldvrTemplateResponseVO.setDevice(RMDCommonConstants.CMU);
					            }else if(outDevice.contains(RMDCommonConstants.LCV)){
					                ldvrTemplateResponseVO.setDevice(RMDCommonConstants.LCV);
					            }else if(outDevice.contains(RMDCommonConstants.HPEAP)){
					                ldvrTemplateResponseVO.setDevice(RMDCommonConstants.HPEAP);
                                }else{
                                    ldvrTemplateResponseVO.setDevice(outDevice.get(0));
                                }
					            
					        }else{
					            ldvrTemplateResponseVO.setDevice(outDevice.get(0));
					        }
					    }else{
					        ldvrTemplateResponseVO.setDevice(inDevice.get(0));
					    }
					
					}else{
    					ldvrTemplateResponseVO.setCustomerId(ldvrTemplateRequestVO
    							.getCustomerId().get(0));
					}
					ldvrTemplateResponseVO
							.setCustomerName(ldvrTemplateRequestVO
									.getCustomerName());
					ldvrTemplateResponseVO
							.setLdvrTemplateDetails(templateDetailsVO);
					lstLDVRTemplateResponseVO.add(ldvrTemplateResponseVO);
				}
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"Exception occured in getLDVRTemplateList method ", rmdEx);
			throw rmdEx;

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLDVRTemplateList method ", ex);
			throw ex;
		}

		return lstLDVRTemplateResponseVO;
	}

	
	public LDVRSaveTemplateResponseVO saveUpdateLDVRTemplate(
			LDVRSaveTemplateRequestVO ldvrTemplateRequestVO,String timeZone,String userId) 
			throws RMDWebException, Exception {
		LDVRSaveTemplateResponseVO respVO = null;
		final SimpleDateFormat dateFormat = new SimpleDateFormat(
				RMDCommonConstants.ddMMyyyyHHmmss);
		
		try {
			ObjectMapper mapper = new ObjectMapper();

			String requestJson = mapper.writer().withDefaultPrettyPrinter()
					.writeValueAsString(ldvrTemplateRequestVO);

			rmdWebLogger
					.info("Inside ManageLDVRRequestsServiceImpl in saveUpdateLDVRTemplate Method request "
							+ requestJson);

			String ldvrResponseJson = (String) webServiceInvoker
					.postMCSWebService(mcsGetNumCamerasUsername,
							mcsGetNumCamerasPassowrd, mcsSaveTemplateURL,
							requestJson, String.class);

			LDVRSaveTemplateResponseType ldvrResponse = mapper.readValue(
					ldvrResponseJson, LDVRSaveTemplateResponseType.class);

			if (ldvrResponse != null) {
				respVO = new LDVRSaveTemplateResponseVO();
				respVO.setStatus(ldvrResponse.getStatus());
				respVO.setTemplateNumber(ldvrResponse.getTemplateNumber());
				respVO.setTemplateVersion(ldvrResponse.getTemplateVersion());
				respVO.setLastUpdatedBy(ldvrTemplateRequestVO.getUserName());
				respVO.setTemplateObjid(ldvrResponse.getTemplateObjid());
				Date date = Calendar.getInstance().getTime();
				dateFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
				respVO.setLastUpdatedDate(dateFormat.format(date));
			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"Exception occured in Save/UpdateLDVRTemplateList method ",
					rmdEx);
			throw rmdEx;

		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in Save/UpdateDVRTemplateList method ",
					ex);
			throw ex;
		}

		return respVO;

	}
	
/*
 * getMasterData Method
 * 
 */
	public LDVRMasterDataResponseVO getMasterData(
			LDVRMasterDataRequestVO ldvrMasterDataRequestVO)
			throws RMDWebException, Exception {
		rmdWebLogger
				.info("Inside ManageLDVRRequestsServiceImpl in getMasterData Method");
		LDVRMasterDataRequestType ldvrMasterDataRequestType = null;
		LDVRMasterDataResponseVO ldvrMasterDataResponseVO = null;
		LDVRMasterDataResponseType ldvrMasterDataResponseType = null;

		try {
			ldvrMasterDataRequestType = new LDVRMasterDataRequestType();
			List<String> masterData = ldvrMasterDataRequestVO
					.getMasterDataSet();
			
			ldvrMasterDataRequestType.setMasterDataSet(masterData);

			ObjectWriter ow = new ObjectMapper().writer()
					.withDefaultPrettyPrinter();
			String inputJson = ow.writeValueAsString(ldvrMasterDataRequestType);

			rmdWebLogger.info("getMasterData input:::" + inputJson);

			ldvrMasterDataResponseType = (LDVRMasterDataResponseType) webServiceInvoker
					.postMCSWebService(mcsGetNumCamerasUsername,
							mcsGetNumCamerasPassowrd, mcsGetMasterDataURL,
							inputJson, LDVRMasterDataResponseType.class);

			if (ldvrMasterDataResponseType != null) {
				ldvrMasterDataResponseVO = new LDVRMasterDataResponseVO();
				DataSetVO voDataSet;
				DataVO voData;

				DataSetType[] dataSetType = ldvrMasterDataResponseType
						.getDataSet();

				List<DataSetType> listDataSets;
				listDataSets = Arrays.asList(dataSetType);
				List<DataSetVO> listVODataSets = new ArrayList<DataSetVO>();

				if (!CollectionUtils.isEmpty(listDataSets)) {

					for (DataSetType dSetTypes : dataSetType) {

						voDataSet = new DataSetVO();
						voDataSet.setDataSetName(dSetTypes.getDataSetName());
						voDataSet
								.setParentSetName(dSetTypes.getParentSetName());

						DataType[] dataTypes = dSetTypes.getData();
						List<DataType> listDataTypes =  Arrays.asList(dataTypes);

						List<DataVO> voDataList = new ArrayList<DataVO>();

						if (!CollectionUtils.isEmpty(listDataTypes)) {

							for (DataType dataTypes1 : listDataTypes) {

								voData = new DataVO();

								voData.setId(dataTypes1.getId());
								voData.setName(dataTypes1.getName());
								voData.setValue(dataTypes1.getValue());
								voData.setDescription(dataTypes1
										.getDescription());
								voData.setOrder(dataTypes1.getOrder());
								voData.setActive(dataTypes1.getActive());

								voDataList.add(voData);

							}
							DataVO[] dataVOArray = voDataList.toArray(new DataVO[voDataList.size()]);
								voDataSet.setData(dataVOArray);

						}

						listVODataSets.add(voDataSet);

					}
					
					DataSetVO[] dataSetVOArray =listVODataSets.toArray(new DataSetVO[listVODataSets.size()]);
						ldvrMasterDataResponseVO.setDataSet(dataSetVOArray);
				}

			}

		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error("Exception occured in getMasterData method ",
					rmdEx);
			throw rmdEx;

		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getMasterData method ", ex);
			throw ex;
		}

		return ldvrMasterDataResponseVO;

	}

	public String convertDateFormat(String date, String timeZone)
			throws Exception {
		try {
			final SimpleDateFormat dateFormatFrom = new SimpleDateFormat(
					"MM-dd-yyyy hh:mm:ss a");
			SimpleDateFormat toDateFormat = new SimpleDateFormat(
					RMDCommonConstants.ddMMyyyyHHmmss);
			Date statusDateTimeD = dateFormatFrom.parse(date);

			dateFormatFrom.setTimeZone(TimeZone.getTimeZone(timeZone));
			return toDateFormat.format(statusDateTimeD.getTime());
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in convertDateFormat in getTemplate method ",
							ex);
			throw ex;
		}

	}
	public String convertRequestDateFormat(String date, String timeZone)
			throws Exception {
		try {
			final SimpleDateFormat dateFormatFrom = new SimpleDateFormat(
					"MM-dd-yyyy hh:mm a");
			SimpleDateFormat toDateFormat = new SimpleDateFormat(
					RMDCommonConstants.ddMMyyyyHHmmss);
			Date statusDateTimeD = dateFormatFrom.parse(date);

			dateFormatFrom.setTimeZone(TimeZone.getTimeZone(timeZone));
			return toDateFormat.format(statusDateTimeD.getTime());
			
			
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in convertDateFormat in getTemplate method ",
							ex);
			throw ex;
		}

	}


}
