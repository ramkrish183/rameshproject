/**
 * 
 */
package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

/**
 * @author MSHIRAJUDDIN
 *
 */
public class LDVRAssetTempReapplyRemoveResponseVO {
	
	
	private List<LDVRAssetTempReapplyRemoveStatusVO> lstAssetTempReapplyRemoveStatusVo;

	/**
	 * @return the lstAssetTempReapplyRemoveStatusVo
	 */
	public List<LDVRAssetTempReapplyRemoveStatusVO> getLstAssetTempReapplyRemoveStatusVo() {
		return lstAssetTempReapplyRemoveStatusVo;
	}

	/**
	 * @param lstAssetTempReapplyRemoveStatusVo the lstAssetTempReapplyRemoveStatusVo to set
	 */
	public void setLstAssetTempReapplyRemoveStatusVo(
			List<LDVRAssetTempReapplyRemoveStatusVO> lstAssetTempReapplyRemoveStatusVo) {
		this.lstAssetTempReapplyRemoveStatusVo = lstAssetTempReapplyRemoveStatusVo;
	}
	

}
