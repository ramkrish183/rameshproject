package com.ge.trans.rmd.cm.service;

import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.cm.valueobjects.BOMConfigVO;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface BOMService {
	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching config controller
	 *               list from database
	 * 
	 */
	public Map<String, String> getConfigList() throws RMDWebException;

	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for populating config controller
	 *               details from database
	 * 
	 */
	public List<BOMConfigVO> populateConfigDetails(String configId)
			throws RMDWebException;

	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param : configId
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching parameter details
	 *               from database
	 * 
	 */
	public Map<String, String> getParameterList(String configId)
			throws RMDWebException;

	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for fetching config
	 *               items list from database
	 * 
	 */
	public Map<String, String> getConfigItemsList() throws RMDWebException;

	/**
	 * @Author :
	 * @return :Map<String,String>
	 * @param :
	 * @throws :RMDWebException
	 * @Description: This method is Responsible for Add and Update BOM details in database
	 * 
	 */
	public String saveBOMDetails(List<BOMConfigVO> bOMConfigVO)
			throws RMDWebException;

}
