package com.ge.trans.rmd.cm.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.Future;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.beans.FLeetViewBean;
import com.ge.trans.rmd.cm.service.FleetServiceCallWrapper;
import com.ge.trans.rmd.cm.valueobjects.FleetViewVO;
import com.ge.trans.rmd.cm.valueobjects.ToolTipVO;
import com.ge.trans.rmd.common.beans.NotesBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.assets.valueobjects.AssetLocatorResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AssetResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.VehicleCommStatusResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CaseResponseType;
import com.ge.trans.rmd.services.cases.valueobjects.CasesRequestType;
import com.ge.trans.rmd.services.cases.valueobjects.SolutionInfoType;
import com.ge.trans.rmd.services.kpi.valueobjects.KpiAssetCountsResponseType;
import com.ge.trans.rmd.services.kpi.valueobjects.ParameterInfoType;
import com.ge.trans.rmd.services.notes.valueobjects.NotesInfo;
import com.ge.trans.rmd.services.notes.valueobjects.NotesRequestType;
import com.ge.trans.rmd.services.notes.valueobjects.NotesResponseType;
import com.ge.trans.rmd.services.solutions.valueobjects.UrgencyResponseType;
import com.ge.trans.rmd.utilities.AppSecUtil;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class FleetViewServiceImpl extends RMDBaseServiceImpl implements
		FleetViewService {

	private final RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	@Autowired
	private WebServiceInvoker rsInvoker;

	@Autowired
	private FleetServiceCallWrapper fleetCallWrapper;

	@Autowired
	private CachedService cachedService;
	/**
	 * Serviceimpl method to get filtered fleets with open RX for given keys
	 * urgency and estimated reopair time.
	 */
	@Override
	public Map<String, FleetViewVO> getFilteredFleetView(
			final FLeetViewBean fleetViewBean, final String userCustomer) throws RMDWebException,
			Exception {
		//logger.debug("FleetViewServiceImpl : Inside getFleetView() method:::START");
		Long startTime = System.currentTimeMillis();
		//logger.debug("Perf: getFleetView StartTime: " + startTime);
		final Map<String, String> headerParams = getHeaderMap(fleetViewBean);
		/*
		 * collectiveResponse is the map that contains FleetViewVO for each key
		 * where key is the combination of assetNumber|assetGroupName|customerId
		 */
		final Map<String, FleetViewVO> collectiveResponse = new HashMap<String, FleetViewVO>();
		Map<String, FleetViewVO> assetCollectiveResponse = new HashMap<String, FleetViewVO>();
		Map<String, FleetViewVO> finalCollectiveResponse = new HashMap<String, FleetViewVO>();
		Future<AssetLocatorResponseType[]> futureAssetLocResponse = null;
		Future<KpiAssetCountsResponseType[]> futureKpiAssetCountsResponse = null;
		Future<NotesResponseType[]> futureNotesresponse = null;

		AssetLocatorResponseType[] assetLocResponseType = null;
		KpiAssetCountsResponseType[] kpiAssetCountsResponseType = null;
		NotesResponseType[] notesresponseType = null;
		Future<CaseResponseType[]> futureCaseResponse=null;		
		CaseResponseType[] objCaseResponseType=null;
		Map<String, List<ToolTipVO>> toolTipCases=null;
		try {
			
			futureCaseResponse=fleetCallWrapper.getCases(fleetViewBean);
			futureAssetLocResponse = fleetCallWrapper.getAssetLocation(
					fleetViewBean, headerParams);			
			/*
			 * The below code has been commented as part of OMD Perf Changes.The
			 * below commented code is related to fetching Worst Urgency from DB
			 */
			
/*			if ((null == fleetViewBean.getUrgencies() || fleetViewBean
					.getUrgencies().equals(AppConstants.EMPTY_STRING))
					&& (null == fleetViewBean.getEstRepTime() || fleetViewBean
							.getEstRepTime().equals(AppConstants.EMPTY_STRING))
					&& (null == fleetViewBean.getRxIds() || fleetViewBean
							.getRxIds().equals(AppConstants.EMPTY_STRING))) {
				futureUrgencyResponse = fleetCallWrapper.getUrgencyResponse(
						fleetViewBean, headerParams);
			}*/
			futureKpiAssetCountsResponse = fleetCallWrapper.getAssetKPICounts(
					fleetViewBean, headerParams);

			futureNotesresponse = fleetCallWrapper.getNotes(fleetViewBean,
					headerParams);
			/*
			 * The below code has been commented as part of OMD Perf Changes.The
			 * below commented code is related to fetching Worst Urgency from DB
			 */
			
/*			if ((null == fleetViewBean.getUrgencies() || fleetViewBean
					.getUrgencies().equals(AppConstants.EMPTY_STRING))
					&& (null == fleetViewBean.getEstRepTime() || fleetViewBean
							.getEstRepTime().equals(AppConstants.EMPTY_STRING))
					&& (null == fleetViewBean.getRxIds() || fleetViewBean
							.getRxIds().equals(AppConstants.EMPTY_STRING))) {
				urgencyResponseType = futureUrgencyResponse.get();
			}*/
			kpiAssetCountsResponseType = futureKpiAssetCountsResponse.get();
			assetLocResponseType = futureAssetLocResponse.get();
			notesresponseType = futureNotesresponse.get();
			objCaseResponseType=futureCaseResponse.get();
			toolTipCases = populateVOFromGetCases(objCaseResponseType);
			/*
			 * The below code has been commented as part of OMD Perf Changes.The
			 * below commented code is related to fetching Worst Urgency from DB
			 */
			
/*			if ((null == fleetViewBean.getUrgencies() || fleetViewBean
					.getUrgencies().equals(AppConstants.EMPTY_STRING))
					&& (null == fleetViewBean.getEstRepTime() || fleetViewBean
							.getEstRepTime().equals(AppConstants.EMPTY_STRING))
					&& (null == fleetViewBean.getRxIds() || fleetViewBean
							.getRxIds().equals(AppConstants.EMPTY_STRING))) {
				populateVOFromUrgencyResponse(urgencyResponseType,
						collectiveResponse,fleetViewBean);
			}*/
			
			populateVOFromKpiAssetCountsResponse(kpiAssetCountsResponseType,
					collectiveResponse,fleetViewBean);
			populateVOFromNotesResponse(notesresponseType, collectiveResponse,fleetViewBean);
			assetCollectiveResponse=populateVOFromAssetLocResponse(assetLocResponseType,
					collectiveResponse,fleetViewBean, userCustomer);			
			finalCollectiveResponse = populateVOFromCasesResponse(toolTipCases,
					assetCollectiveResponse, fleetViewBean);

		} catch (RMDWebException e) {
			logger.error("Exception occured in getFleetView method "
					+ e.getMessage());
			// throw e;
		} catch (Exception e) {
			logger.error("Exception occured in getFleetView method "
					+ e.getMessage());
			throw e;
		}
		//logger.debug("FleetViewServiceImpl : Inside getFleetView() method:::END");
		Long endTime = System.currentTimeMillis();
		//logger.debug("Perf: getFleetView endTime: " + endTime);
		//logger.debug("Perf: getFleetView Execution Time: "+ (endTime - startTime) + "ms");

		return finalCollectiveResponse;
	}

	/*
	 * populates fleetview map by opearting on KpiAssetCountsResponse we will
	 * populate kpiname, totalcount and each rxcounts from
	 * KpiAssetCountsResponse
	 */
	public Map<String, FleetViewVO> populateVOFromKpiAssetCountsResponse(
			final KpiAssetCountsResponseType[] kpiAssetCountsRespType,
			final Map<String, FleetViewVO> fleetViewMap,final FLeetViewBean fleetViewBean)
			throws RMDWebException, Exception {
		String assetNumber = null;
		String assetGroupName = null;
		String customerId = null;
		String key = null;
		FleetViewVO fleetviewVO = null;

		if (kpiAssetCountsRespType != null && kpiAssetCountsRespType.length > 0) {
			for (KpiAssetCountsResponseType eachResponseType : kpiAssetCountsRespType) {
				assetGroupName = eachResponseType.getAssetGroupName();
				assetNumber = eachResponseType.getAssetNumber();
				customerId = eachResponseType.getCustomerId();

				key = assetNumber + AppConstants.SYMBOL_OR + assetGroupName
						+ AppConstants.SYMBOL_OR + customerId;
					if (fleetViewMap.containsKey(key)) {
						fleetviewVO = fleetViewMap.get(key);
					} else {
						fleetviewVO = new FleetViewVO();
					}

					fleetviewVO.setAssetNumber(assetNumber);
					fleetviewVO.setAssetGrpName(assetGroupName);
					fleetviewVO.setCustomer(customerId);

					fleetviewVO = setKpiAssetCountsResponseDetails(
							eachResponseType, fleetviewVO);
					fleetViewMap.put(key, fleetviewVO);
			}
		} else {
			logger.debug("null found in populateVOFromKpiAssetCountsResponse()");
		}

		return fleetViewMap;
	}

	/*
	 * populates fleetview map by opearting on assetlocatorresponse we will
	 * populate latitude, longitude and maxoccurtime from assetlocatorresponse
	 */
	
	public Map<String, FleetViewVO> populateVOFromAssetLocResponse(
			final AssetLocatorResponseType[] assetLocatorResponseType,
			Map<String, FleetViewVO> fleetViewMap,FLeetViewBean fleetBean, String userCustomer)
			throws RMDWebException, Exception {
		String assetNumber = null;
		String assetGroupName = null;
		String customerId = null;
		String key = null;
		FleetViewVO fleetviewVO = null;
		Map<String, FleetViewVO> filteredFleetMap=new LinkedHashMap<String, FleetViewVO>();
		if (assetLocatorResponseType != null && assetLocatorResponseType.length > 0) {
			
			/*Changed for redesign of Fleets and Models*/
			
				for (AssetLocatorResponseType eachResponseType : assetLocatorResponseType) {
					assetGroupName = eachResponseType.getAssetGrpName();
					assetNumber = eachResponseType.getAssetNumber();
					customerId = eachResponseType.getCustomerId();

					key = assetNumber + AppConstants.SYMBOL_OR + assetGroupName
							+ AppConstants.SYMBOL_OR + customerId;

					if (fleetViewMap.containsKey(key)) {
						fleetviewVO = fleetViewMap.get(key);
					} else {
						fleetviewVO = new FleetViewVO();
					}
					
						fleetviewVO.setAssetNumber(assetNumber);
						fleetviewVO.setAssetGrpName(assetGroupName);
						fleetviewVO.setCustomer(customerId);
						fleetviewVO = setAssetLocatorResponseDetails(eachResponseType,
								fleetviewVO,fleetBean.getTimezone(), userCustomer);

						filteredFleetMap.put(key, fleetviewVO);
					} 
				fleetViewMap=filteredFleetMap;
				
				
			
			/*Changed for redesign of Fleets and Models*/
		} else {
				fleetViewMap=filteredFleetMap;
		}
		return fleetViewMap;
	}

	/*
	 * populates fleetview map by opearting on urgencyresponse we will populate
	 * worsturgency from urgencyresponse
	 */
	public Map<String, FleetViewVO> populateVOFromUrgencyResponse(
			final UrgencyResponseType[] urgencyResponseType,
			final Map<String, FleetViewVO> fleetViewMap, final FLeetViewBean fleetViewBean)
			throws RMDWebException, Exception {
		String assetNumber = null;
		String assetGroupName = null;
		String customerId = null;
		String key = null;
		FleetViewVO fleetviewVO = null;
		String prevOccuredUrgency = null;

		if (urgencyResponseType != null && urgencyResponseType.length > 0) {
			for (UrgencyResponseType eachResponseType : urgencyResponseType) {
				assetGroupName = eachResponseType.getAssetGroupName();
				assetNumber = eachResponseType.getAssetNumber();
				customerId = eachResponseType.getCustomerId();

				key = assetNumber + AppConstants.SYMBOL_OR + assetGroupName
						+ AppConstants.SYMBOL_OR + customerId;
					if (fleetViewMap.containsKey(key)) {
						fleetviewVO = fleetViewMap.get(key);
						prevOccuredUrgency = fleetviewVO.getWorstUrgency();
					} else {
						fleetviewVO = new FleetViewVO();
					}

					fleetviewVO = setUrgencyResponseDetails(eachResponseType,
							fleetviewVO);

					fleetviewVO.setAssetNumber(assetNumber);
					fleetviewVO.setAssetGrpName(assetGroupName);
					fleetviewVO.setCustomer(customerId);
					fleetViewMap.put(key, fleetviewVO);
					
			}
		} else {
			logger.debug("null found in populateVOFromUrgencyResponse()");
		}

		return fleetViewMap;
	}

	
	
	/*
	 * populates fleetview map by opearting on assetresponse we will populate
	 * model,location,customername, assetgroupnumber and fleet from
	 * assetresponse
	 */
	
	public Map<String, FleetViewVO> populateVOFromAssetResponse(
			final AssetResponseType[] assetResponseType,
			Map<String, FleetViewVO> fleetViewMap,FLeetViewBean fleetBean)
			throws RMDWebException, Exception {
		String assetNumber = null;
		String assetGroupName = null;
		String customerId = null;
		String key = null;
		FleetViewVO fleetviewVO = null;
		Map<String, FleetViewVO> filteredFleetMap=new LinkedHashMap<String, FleetViewVO>();
		if (assetResponseType != null && assetResponseType.length > 0) {
			
			/*Changed for redesign of Fleets and Models*/
			
				for (AssetResponseType eachResponseType : assetResponseType) {
					assetGroupName = eachResponseType.getAssetGroupName();
					assetNumber = eachResponseType.getAssetNumber();
					customerId = eachResponseType.getCustomerID();

					key = assetNumber + AppConstants.SYMBOL_OR + assetGroupName
							+ AppConstants.SYMBOL_OR + customerId;

					if (fleetViewMap.containsKey(key)) {
						fleetviewVO = fleetViewMap.get(key);
					} else {
						fleetviewVO = new FleetViewVO();
					}
					
						fleetviewVO = setAssetResponseDetails(eachResponseType,
								fleetviewVO);

						fleetviewVO.setAssetNumber(assetNumber);
						fleetviewVO.setAssetGrpName(assetGroupName);
						fleetviewVO.setCustomer(customerId);

						filteredFleetMap.put(key, fleetviewVO);
					} 
				fleetViewMap=filteredFleetMap;
				
				
			
			/*Changed for redesign of Fleets and Models*/
		} else {
				fleetViewMap=filteredFleetMap;
		}
		return fleetViewMap;
	}

	/*
	 * populates fleetviewmap by operating on notesresponsetype we will populate
	 * noteseqid, notetype, notedescription and notecreationdate from
	 * notesresponsetype and combining the results of fleets and cases
	 */
	public Map<String, FleetViewVO> populateVOFromCasesResponse(
			final Map<String, List<ToolTipVO>> toolTipCases,
			final Map<String, FleetViewVO> fleetViewMap,
			final FLeetViewBean fleetBean) {

		Map<String, FleetViewVO> finalFleetViewMap = new HashMap<String, FleetViewVO>();

		if (toolTipCases != null && toolTipCases.size() > 0) {
			for (Map.Entry<String, List<ToolTipVO>> toolTipentry : toolTipCases
					.entrySet()) {
				if ((null == fleetBean.getUrgencies() || fleetBean
						.getUrgencies().equals(AppConstants.EMPTY_STRING))
						&& (null == fleetBean.getEstRepTime() || fleetBean
								.getEstRepTime().equals(
										AppConstants.EMPTY_STRING))
						&& (null == fleetBean.getRxIds() || fleetBean
								.getRxIds().equals(AppConstants.EMPTY_STRING))
								&& (null == fleetBean.getCaseType() || fleetBean
								.getCaseType().equals(AppConstants.EMPTY_STRING))&& (null == fleetBean.getFleet() || fleetBean
										.getFleet().equals(AppConstants.EMPTY_STRING))&& (null == fleetBean.getModel() || fleetBean
												.getModel().equals(AppConstants.EMPTY_STRING))) {
					if(null != fleetViewMap && !fleetViewMap.isEmpty()){
					if (fleetViewMap.containsKey(toolTipentry.getKey())) {
						fleetViewMap.get(toolTipentry.getKey()).setToolTipList(
								toolTipentry.getValue());
						getWorstUrgency(fleetViewMap, toolTipentry.getKey());
						
					}
					}
				}
				/*Added for fleet and model resdesign*/
				else if((null == fleetBean.getUrgencies() || fleetBean
						.getUrgencies().equals(AppConstants.EMPTY_STRING))
						&& (null == fleetBean.getEstRepTime() || fleetBean
								.getEstRepTime().equals(
										AppConstants.EMPTY_STRING))
						&& (null == fleetBean.getRxIds() || fleetBean
								.getRxIds().equals(AppConstants.EMPTY_STRING))
								&& (null == fleetBean.getCaseType() || fleetBean
								.getCaseType().equals(AppConstants.EMPTY_STRING))){
					
					if(!(null == fleetBean.getFleet() || fleetBean
							.getFleet().equals(AppConstants.EMPTY_STRING)) || !(null == fleetBean.getModel() || fleetBean
							.getModel().equals(AppConstants.EMPTY_STRING))){
						if(null != fleetViewMap && !fleetViewMap.isEmpty()){
						if (fleetViewMap.containsKey(toolTipentry.getKey())) {
							fleetViewMap.get(toolTipentry.getKey()).setToolTipList(
									toolTipentry.getValue());
							getWorstUrgency(fleetViewMap, toolTipentry.getKey());
							
						}
						}
					}
				}
				/*Added for fleet and model resdesign*/
				else
				{
					if (fleetViewMap.containsKey(toolTipentry.getKey())) {
						fleetViewMap.get(toolTipentry.getKey()).setToolTipList(
								toolTipentry.getValue());
						finalFleetViewMap.put(toolTipentry.getKey(),
								fleetViewMap.get(toolTipentry.getKey()));

						getWorstUrgency(finalFleetViewMap, toolTipentry.getKey());

					}
				}
			}
		} else {
			logger.debug("null found in populateVOFromNotesResponse()");
		}
		if ((null == fleetBean.getUrgencies() || fleetBean
				.getUrgencies().equals(AppConstants.EMPTY_STRING))
				&& (null == fleetBean.getEstRepTime() || fleetBean
						.getEstRepTime().equals(
								AppConstants.EMPTY_STRING))
				&& (null == fleetBean.getRxIds() || fleetBean
						.getRxIds().equals(AppConstants.EMPTY_STRING))
						&& (null == fleetBean.getCaseType() || fleetBean
						.getCaseType().equals(AppConstants.EMPTY_STRING))) {
			return fleetViewMap;		
			}
		else{
			return finalFleetViewMap;
		}
		
	
		
	
	}
	
	
	public void getWorstUrgency(final Map<String, FleetViewVO> finalFleetViewMap,String key){
		
		List<String> urgencyList = new ArrayList<String>();

		for (int i = 0; i < finalFleetViewMap
				.get(key).getToolTipList()
				.size(); i++) {
			urgencyList.add(finalFleetViewMap
					.get(key)
					.getToolTipList().get(i).getUrgency());

		}
		if (urgencyList.contains(AppConstants.URGENCY_R))
			finalFleetViewMap.get(key)
					.setWorstUrgency(AppConstants.URGENCY_R);
		else if (urgencyList.contains(AppConstants.URGENCY_Y))
			finalFleetViewMap.get(key)
					.setWorstUrgency(AppConstants.URGENCY_Y);
		else if (urgencyList.contains(AppConstants.URGENCY_B))
			finalFleetViewMap.get(key)
			.setWorstUrgency(AppConstants.URGENCY_B);
		else
			finalFleetViewMap.get(key)
					.setWorstUrgency(AppConstants.EMPTY_STRING);		
		
	}


	/*
	 * populates fleetviewmap by operating on notesresponsetype we will populate
	 * noteseqid, notetype, notedescription and notecreationdate from
	 * notesresponsetype
	 */
	public Map<String, FleetViewVO> populateVOFromNotesResponse(
			final NotesResponseType[] notesResponseType,
			final Map<String, FleetViewVO> fleetViewMap,FLeetViewBean fLeetViewBean) {
		String assetNumber = null;
		String assetGroupName = null;
		String customerId = null;
		String key = null;
		FleetViewVO fleetviewVO = null;

		if (notesResponseType != null && notesResponseType.length > 0) {
			for (NotesResponseType eachResponseType : notesResponseType) {
				assetGroupName = eachResponseType.getAssetGroupName();
				assetNumber = eachResponseType.getAssetNumber();
				customerId = eachResponseType.getCustomerId();

				key = assetNumber + AppConstants.SYMBOL_OR + assetGroupName
						+ AppConstants.SYMBOL_OR + customerId;
					if (fleetViewMap.containsKey(key)) {
						fleetviewVO = fleetViewMap.get(key);
					} else {
						fleetviewVO = new FleetViewVO();
					}

					fleetviewVO = setNotesResponseDetails(eachResponseType,
							fleetviewVO);

					fleetviewVO.setAssetNumber(assetNumber);
					fleetviewVO.setAssetGrpName(assetGroupName);
					fleetviewVO.setCustomer(customerId);

					fleetViewMap.put(key, fleetviewVO);
			}
		} else {
			logger.debug("null found in populateVOFromNotesResponse()");
		}
		return fleetViewMap;
	}

	/*
	 * populates fleetview map by opearting on vehiclecommresponse we will
	 * populate lastprocessdate and lastdownloaddate from vehiclecommresponse
	 */
	public Map<String, FleetViewVO> populateVOFromVehicleCommResponse(
			final VehicleCommStatusResponseType[] vehicleCommStatusRespType,
			final Map<String, FleetViewVO> fleetViewMap, String timeZone,FLeetViewBean fLeetViewBean, String userCustomer)
			throws RMDWebException, Exception {
		String assetNumber = null;
		String assetGroupName = null;
		String customerId = null;
		String key = null;
		FleetViewVO fleetviewVO = null;

		if (vehicleCommStatusRespType != null
				&& vehicleCommStatusRespType.length > 0) {
			for (VehicleCommStatusResponseType eachResponseType : vehicleCommStatusRespType) {
				assetGroupName = eachResponseType.getAssetGrpName();
				assetNumber = eachResponseType.getAssetNumber();
				customerId = eachResponseType.getCustomerId();

				key = assetNumber + AppConstants.SYMBOL_OR + assetGroupName
						+ AppConstants.SYMBOL_OR + customerId;
					if (fleetViewMap.containsKey(key)) {
						fleetviewVO = fleetViewMap.get(key);
					} else {
						fleetviewVO = new FleetViewVO();
					}

					fleetviewVO = setVehicleCommResponseDetails(
							eachResponseType, fleetviewVO, timeZone, userCustomer);

					fleetviewVO.setAssetNumber(assetNumber);
					fleetviewVO.setAssetGrpName(assetGroupName);
					fleetviewVO.setCustomer(customerId);

					fleetViewMap.put(key, fleetviewVO);
				
			}
			
		} else {
			logger.debug("null found in populateVOFromVehicleCommResponse()");
		}

		return fleetViewMap;
	}

	/*
	 * populate fleetview vo from vehiclecomm response type
	 */
	public FleetViewVO setVehicleCommResponseDetails(
			final VehicleCommStatusResponseType vehicleCommStatusRespType,
			final FleetViewVO fleetViewVO, String timeZone, String userCustomer) throws RMDWebException, Exception {
		DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		if (cachedService.getSDCustLookup().get(userCustomer) != null
                && cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
                && !cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim().equals("")) 
		{
          zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat());
		}
		final TimeZone firstTime = TimeZone.getTimeZone(timeZone);
		zoneFormater.setTimeZone(firstTime);
		if (vehicleCommStatusRespType != null) {
			if (vehicleCommStatusRespType.getLastProcessedDate() != null) {
				final XMLGregorianCalendar processedDate = vehicleCommStatusRespType
						.getLastProcessedDate();

				fleetViewVO.setDtLastProcessedDate(zoneFormater
						.format(processedDate.toGregorianCalendar().getTime()));
			}
			if (vehicleCommStatusRespType.getLastFaultReceivedTime() != null) {
				final XMLGregorianCalendar downloadDate = vehicleCommStatusRespType
						.getLastFaultReceivedTime();

				fleetViewVO.setDtLastFaultDate(zoneFormater
						.format(downloadDate.toGregorianCalendar().getTime()));

			}
		} else {
			logger.debug("null found in setVehicleCommResponseDetails()");
		}
		return fleetViewVO;
	}

	/*
	 * populate fleetview vo from asset response type
	 */
	public FleetViewVO setAssetResponseDetails(
			final AssetResponseType assetResponseType,
			final FleetViewVO fleetViewVO) {
		if (assetResponseType != null) {
			fleetViewVO.setModel(assetResponseType.getModel());
			fleetViewVO.setLocation(assetResponseType.getLocation());
			fleetViewVO.setFleet(assetResponseType.getFleet());
			fleetViewVO.setCustomerName(assetResponseType.getCustomerName());
			fleetViewVO.setAssetGrpNumber(assetResponseType
					.getAssetGroupNumber());
		} else {
			logger.debug("null found in setAssetResponseDetails()");
		}
		return fleetViewVO;
	}

	/*
	 * populate fleetview vo from notes response type
	 */
	@SuppressWarnings("unused")
	public FleetViewVO setNotesResponseDetails(
			final NotesResponseType notesResponseType,
			final FleetViewVO fleetViewVO) {
		if (notesResponseType != null) {
			fleetViewVO.setNoteSeqID(notesResponseType.getNoteSeqID());
			fleetViewVO.setNoteDescription(AppSecUtil.decodeString(AppSecUtil
					.revertEncode(notesResponseType.getNoteDescription())));
			fleetViewVO.setNoteType(notesResponseType.getNoteType());
			fleetViewVO
					.setNoteCreationDate(RMDCommonUtility
							.convertObjectToString(notesResponseType
									.getCreationDate()));
		} else {
			logger.debug("null found in setNotesResponseDetails()");
		}
		return fleetViewVO;
	}

	/*
	 * populate fleetview vo from urgency response type
	 */
	public FleetViewVO setUrgencyResponseDetails(
			final UrgencyResponseType urgencyResponseType,
			final FleetViewVO fleetViewVO) {
		if (urgencyResponseType != null) {
			fleetViewVO.setWorstUrgency(urgencyResponseType.getWorstUrgency());
		} else {
			logger.debug("null found in setUrgencyResponseDetails()");
		}
		return fleetViewVO;
	}

	/*
	 * populate fleetview vo from assetLocator response type
	 */
	public FleetViewVO setAssetLocatorResponseDetails(
			final AssetLocatorResponseType assetLocatorResponseType,
			final FleetViewVO fleetViewVO, String timezone, String userCustomer) throws Exception {
		DateFormat zoneFormater = new SimpleDateFormat(AppConstants.DATE_FORMAT_24HRS);
		if (cachedService.getSDCustLookup().get(userCustomer) != null
                && cachedService.getSDCustLookup().get(userCustomer).getDateFormat() != null
                && !cachedService.getSDCustLookup().get(userCustomer).getDateFormat().trim().equals("")) 
		{
          zoneFormater = new SimpleDateFormat(cachedService.getSDCustLookup().get(userCustomer).getDateFormat());
		}
		
		final TimeZone firstTime = TimeZone.getTimeZone(timezone);
		zoneFormater.setTimeZone(firstTime);
		if (assetLocatorResponseType != null) {

			if (assetLocatorResponseType.getLatitude() != null
					&& assetLocatorResponseType.getLongitude() != null) {
				try {
					float latitude = Float.parseFloat(assetLocatorResponseType
							.getLatitude());
					float longitude = Float.parseFloat(assetLocatorResponseType
							.getLongitude());
					if (latitude >= -90.0 && latitude <= 90.0
							&& longitude >= -180.0 && longitude <= 180.0) {
						fleetViewVO.setLatitude(assetLocatorResponseType
								.getLatitude());
						fleetViewVO.setLongitude(assetLocatorResponseType
								.getLongitude());
					}
				} catch (Exception e) {
					logger.error("In FleetViewServiceImpl : Error occured in setAssetLocatorResponseDetails method Unparsable latitude or longitude "
							+ e.getMessage());
					
				}
			}
			fleetViewVO.setModel(assetLocatorResponseType.getModelName());
			if (assetLocatorResponseType.getLstPrcddt() != null) {
				XMLGregorianCalendar processedDate = assetLocatorResponseType
						.getLstPrcddt();

				fleetViewVO.setDtLastProcessedDate(zoneFormater
						.format(processedDate.toGregorianCalendar().getTime()));
			}
			if (assetLocatorResponseType.getLstFaultdt() != null) {
				XMLGregorianCalendar lastFaultDate = assetLocatorResponseType
						.getLstFaultdt();

				fleetViewVO.setDtLastFaultDate(zoneFormater
						.format(lastFaultDate.toGregorianCalendar().getTime()));

			}
			fleetViewVO.setMaxOccurTime(RMDCommonUtility
					.convertXMLDateToString(assetLocatorResponseType
							.getMaxOccurTime()));
		} else {
			logger.debug("null found in setAssetLocatorResponseDetails()");
		}
		return fleetViewVO;
	}

	/*
	 * populate fleetview vo from KpiAssetCount response type
	 */
	@SuppressWarnings("unused")
	public FleetViewVO setKpiAssetCountsResponseDetails(
			final KpiAssetCountsResponseType kpiAssetCountsResponse,
			final FleetViewVO fleetViewVO) {
		if (kpiAssetCountsResponse != null) {
			List<ParameterInfoType> parameterInfo = kpiAssetCountsResponse
					.getParameter();

			fleetViewVO.setKpiName(kpiAssetCountsResponse.getKpiName());
			fleetViewVO
					.setKpiTotalCount(kpiAssetCountsResponse.getTotalCount());

			for (ParameterInfoType parameter : parameterInfo) {
				if (parameter.getParameterName().equalsIgnoreCase(
						AppConstants.FLEET_R)) {
					fleetViewVO.setRedRx(parameter.getParameterCount());
				} else if (parameter.getParameterName().equalsIgnoreCase(
						AppConstants.YES_FLAG)) {
					fleetViewVO.setYellowRx(parameter.getParameterCount());
				}
				/* Adding the below change for blueRx story Phase2 Sprint1 */
				else if (parameter.getParameterName().equalsIgnoreCase(
						AppConstants.FLEET_B)) {
					fleetViewVO.setBlueRx(parameter.getParameterCount());
				}
				/* Adding the below change for blueRx story Phase2 Sprint1 */
				else if (parameter.getParameterName().equalsIgnoreCase(
						AppConstants.FLEET_W)) {
					fleetViewVO.setWhiteRx(parameter.getParameterCount());
				}
			}
		} else {
			logger.debug("null found in setKpiAssetCountsResponseDetails()");
		}
		return fleetViewVO;
	}

	@Override
	public Map<String, List<ToolTipVO>> getCases(
			final FLeetViewBean fleetViewBean) throws RMDWebException,
			Exception {

		CaseResponseType[] caseResponseType = null;
		Map<String, List<ToolTipVO>> resultToolTipMap = new HashMap<String, List<ToolTipVO>>();
		final Map<String, String> headerParams = getHeaderMap(fleetViewBean);
		CasesRequestType objCasesReqType=new CasesRequestType();
		try {
			objCasesReqType.setCustomerId(fleetViewBean.getCustomerId());
			objCasesReqType.setUserLanguage(fleetViewBean.getUserLanguage());
			objCasesReqType.setSolutionStatus(AppConstants.STATUS_OPEN);
			parseProducts(fleetViewBean.getProducts(),objCasesReqType);

			if (null != fleetViewBean.getUrgencies()
					&& !RMDCommonConstants.EMPTY_STRING.equals(fleetViewBean
							.getUrgencies()))
				objCasesReqType.setUrgency(fleetViewBean.getUrgencies());
			if (null != fleetViewBean.getEstRepTime()
					&& !RMDCommonConstants.EMPTY_STRING.equals(fleetViewBean
							.getEstRepTime()))
				objCasesReqType.setEstRepTm(fleetViewBean.getEstRepTime());

			/* For CaseType */
			if (null != fleetViewBean.getCaseType()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(fleetViewBean.getCaseType())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(fleetViewBean.getCaseType())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(fleetViewBean.getCaseType())) {

				objCasesReqType.setCaseType(fleetViewBean.getCaseType());
			}
			/*For Fleet*/
			if (null != fleetViewBean.getFleet()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(fleetViewBean.getFleet())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(fleetViewBean.getFleet())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(fleetViewBean.getFleet())) {

				objCasesReqType.setFleetId(fleetViewBean.getFleet());
			}
			/*For Model*/
			if (null != fleetViewBean.getModel()
					&& !RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(fleetViewBean.getModel())
					&& !RMDCommonConstants.SELECT
							.equalsIgnoreCase(fleetViewBean.getModel())
					&& !AppConstants.UNDEFINED
							.equalsIgnoreCase(fleetViewBean.getModel())) {

				objCasesReqType.setModelId(fleetViewBean.getModel());
			}
			/*For CaseType*/
			if (null != fleetViewBean.getRxIds() && !RMDCommonConstants.EMPTY_STRING.equals(fleetViewBean.getRxIds())) {
				//String[] totalRxIdsArr = fleetViewBean.getRxIds().split(",");
				//String[] subRxIdsArr = null;
				//int limitOfRxIds = 1000;
				//String rxIdForWS = "";
				//int countToIterate = totalRxIdsArr.length / limitOfRxIds;
				/*if (countToIterate > 0) {
					CaseResponseType[] combinedCaseResponse = null;
					for (int i = 0; i <= countToIterate; i++) {
						rxIdForWS = "";
						/* copying 1000 or less rx ids to new array */
						/*if (totalRxIdsArr.length - (i * limitOfRxIds) >= limitOfRxIds) {
							subRxIdsArr = new String[limitOfRxIds];
							System.arraycopy(totalRxIdsArr, i * limitOfRxIds,
									subRxIdsArr, 0, subRxIdsArr.length);
						} else {
							subRxIdsArr = new String[totalRxIdsArr.length
									- (i * limitOfRxIds)];
							System.arraycopy(totalRxIdsArr, i * limitOfRxIds,
									subRxIdsArr, 0, totalRxIdsArr.length
											- (i * limitOfRxIds));
						}
						for (int j = 0; j < subRxIdsArr.length; j++) {

							rxIdForWS = rxIdForWS + subRxIdsArr[j];
							if (j < subRxIdsArr.length)
								rxIdForWS = rxIdForWS + ",";
						}
						objCasesReqType.setRxId(rxIdForWS);
						try {
							caseResponseType = (CaseResponseType[]) rsInvoker
									.post(ServiceConstants.CASES_SERVICE_LITE_GETDELCASES,
											objCasesReqType,
											CaseResponseType[].class);
						} catch (Exception e) {

							if (e instanceof RMDWebException) {

								RMDWebException rmdEx = (RMDWebException) e;
								if (AppConstants.EXCEPTION_EOA_101
										.equalsIgnoreCase(rmdEx.getErrorCode())) {
									continue;
								} else
									throw e;
							}

						}

						combinedCaseResponse = (CaseResponseType[]) ArrayUtils
								.addAll(combinedCaseResponse, caseResponseType);

					}
					caseResponseType = combinedCaseResponse;
				} else { */
					objCasesReqType.setRxId(fleetViewBean.getRxIds());
					caseResponseType = (CaseResponseType[]) rsInvoker.post(
							ServiceConstants.CASES_SERVICE_LITE_GETDELCASES, objCasesReqType, CaseResponseType[].class);
				//}

			} else {
				caseResponseType = (CaseResponseType[]) rsInvoker.post(
						ServiceConstants.CASES_SERVICE_LITE_GETDELCASES,objCasesReqType, CaseResponseType[].class);
			}
			resultToolTipMap = populateVOFromGetCases(caseResponseType);
		

		} catch (Exception ex) {
			logger.error("Exception occured in getCases method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return resultToolTipMap;
	}

	public Map<String, List<ToolTipVO>> populateVOFromGetCases(
			final CaseResponseType[] caseResponseType) throws RMDWebException,
			Exception {
		logger.debug("====================Start populateVOFromGetCases========");
		String assetNumber = null;
		String assetGroupName = null;
		String customerId = null;
		String key = null;
		ToolTipVO toolTipVO = null;
		final Map<String, List<ToolTipVO>> toolTipMap = new HashMap<String, List<ToolTipVO>>();
		if (caseResponseType != null && caseResponseType.length > 0) {
			for (CaseResponseType eachResponseType : caseResponseType) {
				if (eachResponseType != null) {
					assetGroupName = eachResponseType.getAssetGrpName();
					assetNumber = eachResponseType.getAssetNumber();
					customerId = eachResponseType.getCustomerName();
					List<ToolTipVO> urgencyTitleList = new ArrayList<ToolTipVO>();
					key = assetNumber + AppConstants.SYMBOL_OR + assetGroupName
							+ AppConstants.SYMBOL_OR + customerId;

					if (!toolTipMap.containsKey(key)) {

						if (eachResponseType.getSolutionInfo() != null
								&& eachResponseType.getSolutionInfo().size() > 0) {
							final List<SolutionInfoType> solutionInfoType = eachResponseType
									.getSolutionInfo();

							for (SolutionInfoType eachsolutionInfo : solutionInfoType) {
								toolTipVO = new ToolTipVO();
								if (eachsolutionInfo.getUrgency() != null) {
									toolTipVO.setUrgency(eachsolutionInfo
											.getUrgency());
								}
								if (eachsolutionInfo.getSolutionTitle() != null) {
									toolTipVO.setRxTitle(eachsolutionInfo
											.getSolutionTitle());
								}
								urgencyTitleList.add(toolTipVO);
							}
						}

						toolTipMap.put(key, urgencyTitleList);
					} else {
						urgencyTitleList = toolTipMap.get(key);
						if (eachResponseType.getSolutionInfo() != null
								&& eachResponseType.getSolutionInfo().size() > 0) {
							final List<SolutionInfoType> solutionInfoType = eachResponseType
									.getSolutionInfo();

							for (SolutionInfoType eachsolutionInfo : solutionInfoType) {
								toolTipVO = new ToolTipVO();
								if (eachsolutionInfo.getUrgency() != null) {
									toolTipVO.setUrgency(eachsolutionInfo
											.getUrgency());
								}
								if (eachsolutionInfo.getSolutionTitle() != null) {
									toolTipVO.setRxTitle(eachsolutionInfo
											.getSolutionTitle());
								}
								urgencyTitleList.add(toolTipVO);
							}
						}
						toolTipMap.put(key, urgencyTitleList);
					}
				}
			}
		} else {
			logger.debug("null found in populateVOFromUrgencyResponse()");
		}

		logger.debug("====================end populateVOFromGetCases========");
		return toolTipMap;
	}

	/*
	 * saves the notes info for particular asset
	 */
	@Override
	public String fleetSaveNotes(final NotesBean notesBean)
			throws RMDWebException, Exception {
		final Map<String, String> headerParams = getHeaderMap(notesBean);
		final NotesRequestType notesRequestType = new NotesRequestType();
		final NotesInfo notesInfo = new NotesInfo();
		String returnStr = AppConstants.FAILURE;
		try {
			notesInfo.setAssetNumber(notesBean.getAssetNumber());
			notesRequestType.setFromPage(AppConstants.LOCO);
			notesRequestType.setSticky(AppConstants.NO);
			notesRequestType.setFromAsset(notesBean.getAssetNumber());
			notesRequestType.setToAsset(notesBean.getAssetNumber());
			notesRequestType.setNotes(notesBean.getNoteDescription());
			notesRequestType.setNotesInfo(notesInfo);
			notesRequestType.setAssetGrpName(notesBean.getAssetGroup());
			notesRequestType.setCustomerID(notesBean.getCustomerId());

			rsInvoker.put(ServiceConstants.POST_NOTES, notesRequestType,
					headerParams);
			returnStr = AppConstants.SUCCESS;
		} catch (Exception ex) {
			logger.error("Exception occured in fleetSaveNotes method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return returnStr;
	}

}
