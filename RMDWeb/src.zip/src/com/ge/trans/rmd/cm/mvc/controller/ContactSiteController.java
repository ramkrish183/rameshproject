package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.ContactSiteService;
import com.ge.trans.rmd.cm.valueobjects.AddRemoveSecondarySiteVO;
import com.ge.trans.rmd.cm.valueobjects.AddressDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.AddressSearchVO;
import com.ge.trans.rmd.cm.valueobjects.ContactDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.ContactSearchVO;
import com.ge.trans.rmd.cm.valueobjects.ContactSiteDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.SiteDetailsVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.AuthorizationService;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.AppSecUtil;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
public class ContactSiteController {

    private final RMDWebLogger rmdWebLogger = RMDWebLogger
            .getLogger(getClass());
    @Autowired
    ApplicationContext appContext;
    @Autowired
    ContactSiteService contactSiteService;
    @Autowired
	private AuthorizationService authService;
    
    @RequestMapping(AppConstants.REQ_URI_VIEW_CONTACT_SCREEN)
    public ModelAndView showContactScreen() {
        rmdWebLogger
                .debug("Inside showContactScreen() method of ContactSiteController");
        return new ModelAndView(AppConstants.ADD_EDIT_CONTACT);
    }

    @RequestMapping(AppConstants.REQ_URI_OPEN_SECONDARY_SITE_WINDOW)
    public ModelAndView openSecondarySiteWindow(final HttpServletRequest request)
            throws RMDWebException {
        rmdWebLogger
                .debug("Inside openSecondarySiteWindow method of ContactSiteController");
        String contactObjId = EsapiUtil.stripXSSCharacters(request
                .getParameter(AppConstants.CONTACT_OBJID));
        request.setAttribute(AppConstants.CONTACT_OBJID, EsapiUtil.stripXSSCharacters(contactObjId));
        return new ModelAndView(AppConstants.SECONDARY_SITE_PAGE);
    }

    @RequestMapping(AppConstants.REQ_URI_VIEW_ADDRESS_SCREEN)
    public ModelAndView showAddressScreen() {
        rmdWebLogger
                .debug("Inside showAddressScreen() method of ContactSiteController");
        return new ModelAndView(AppConstants.ADD_EDIT_ADDRESS);
    }

    /**
     * 
     * @param
     * @return List<ContactDetailsVO>
     * @throws RMDWebException
     * @Description This method is used to get the contact details for the given
     *              search combination.
     * 
     */
    @RequestMapping(AppConstants.REQ_URI_GET_CONTACTS)
    @ResponseBody
    public List<ContactDetailsVO> getContacts(
            @RequestParam(value = AppConstants.FIRST_NAME) final String firstName,
            @RequestParam(value = AppConstants.LAST_NAME) final String lastName,
            @RequestParam(value = AppConstants.SITE_ID) final String siteId,
            @RequestParam(value = AppConstants.SITE_NAME) final String siteName,
            @RequestParam(value = AppConstants.PH_NO) final String phNo,
            @RequestParam(value = AppConstants.CONTACT_STATUS) final String contactStatus)
            throws RMDWebException {

        List<ContactDetailsVO> contactDetailsList = null;
        ContactSearchVO objContactSearchVO = new ContactSearchVO();
        try {
            if (null != firstName) {
                objContactSearchVO.setFirstName(firstName);
            }
            if (null != lastName) {
                objContactSearchVO.setLastName(lastName);
            }
            if (null != siteId) {
                objContactSearchVO.setSiteId(siteId);
            }
            if (null != siteName) {
                objContactSearchVO.setSiteName(siteName);
            }
            if (null != phNo) {
                objContactSearchVO.setPhNo(phNo);
            }
            if (null != contactStatus) {
                objContactSearchVO.setContactStatus(contactStatus);
            }
            contactDetailsList = contactSiteService
                    .getContacts(objContactSearchVO);
        } catch (Exception ex) {
            rmdWebLogger
                    .error("RMDWebException occured in getContacts() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            objContactSearchVO = null;
        }

        return contactDetailsList;

    }

    /**
     * 
     * @param contactObjId
     * @return ContactSiteDetailsVO
     * @throws RMDWebException
     * @Description This method is used to get the all details for the selected
     *              contact
     * 
     */
    @RequestMapping(AppConstants.REQ_URI_VIEW_CONTACT_DETAILS)
    @ResponseBody
    public ContactSiteDetailsVO viewContactDetails(
            @RequestParam(value = AppConstants.CONTACT_OBJID) final String contactObjId)
            throws RMDWebException {
        ContactSiteDetailsVO objContactSiteDetailsVO = null;
        try {
            if (!RMDCommonUtility.isNullOrEmpty(contactObjId)) {
                objContactSiteDetailsVO = contactSiteService
                        .viewContactDetails(EsapiUtil.stripXSSCharacters(contactObjId));
            }
        } catch (Exception ex) {
            rmdWebLogger
                    .error("RMDWebException occured in viewContactDetails() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return objContactSiteDetailsVO;

    }

    /**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:RMDWebException
     * @Description: This method is used for fetching the contact status
     */
    @RequestMapping(value = AppConstants.REQ_URI_GET_CONTACT_STATUS)
    @ResponseBody
    public Map<String, String> getContactStatus() throws RMDWebException {
        Map<String, String> contactStatusMap = new LinkedHashMap<String, String>();
        try {
            contactStatusMap = contactSiteService.getContactStatus();
        } catch (Exception ex) {
            rmdWebLogger
                    .error("RMDWebException occured in getContactStatus() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return contactStatusMap;
    }

    /**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:RMDWebException
     * @Description: This method is used for fetching the contact roles
     */
    @RequestMapping(value = AppConstants.REQ_URI_GET_CONTACT_ROLES)
    @ResponseBody
    public Map<String, String> getContactRole() throws RMDWebException {
        Map<String, String> contactRolesMap = new LinkedHashMap<String, String>();
        try {
            contactRolesMap = contactSiteService.getContactRoles();
        } catch (Exception ex) {
            rmdWebLogger
                    .error("RMDWebException occured in getContactRole() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return contactRolesMap;
    }

    /**
     * 
     * @param contactObjId
     * @return List<SiteDetailsVO>
     * @throws RMDWebException
     * @Description This method is used to get the secondary site details
     * 
     */
    @RequestMapping(AppConstants.REQ_URI_GET_CONTACT_SECONDARY_SITES)
    @ResponseBody
    public List<SiteDetailsVO> getContactSecondarySites(
            @RequestParam(value = AppConstants.CONTACT_OBJID) final String contactObjId)
            throws RMDWebException {
        List<SiteDetailsVO> siteDetailsList = null;
        try {
            if (!RMDCommonUtility.isNullOrEmpty(contactObjId)) {
                siteDetailsList = contactSiteService
                        .getContactSecondarySites(contactObjId);
            }
        } catch (Exception ex) {
            rmdWebLogger
                    .error("RMDWebException occured in getContactSecondarySites() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return siteDetailsList;

    }

    /**
     * 
     * @param AddRemoveSecondarySiteVO
     * @return String
     * @throws RMDWebException
     * @Description This method is used to add the secondary site to a contact
     * 
     */
    @RequestMapping(AppConstants.REQ_URI_ADD_CONTACT_SECONDARY_SITE)
    @ResponseBody
    public String addContactSecondarySite(
            @RequestParam(value = AppConstants.CONTACT_OBJID) final String contactObjId,
            @RequestParam(value = AppConstants.SITE_OBJID) final String siteObjId,
            @RequestParam(value = AppConstants.CONTACT_ROLE) final String contactRole)
            throws RMDWebException {
        String status = AppConstants.FAILURE;
        AddRemoveSecondarySiteVO objAddRemoveSecondarySiteVO = null;
        try {
            if (!RMDCommonUtility.isNullOrEmpty(contactObjId)
                    && !RMDCommonUtility.isNullOrEmpty(siteObjId)
                    && !RMDCommonUtility.isNullOrEmpty(contactRole)) {
                objAddRemoveSecondarySiteVO = new AddRemoveSecondarySiteVO();
                objAddRemoveSecondarySiteVO.setContactObjId(EsapiUtil.stripXSSCharacters(contactObjId));
                objAddRemoveSecondarySiteVO.setSiteObjId(EsapiUtil.stripXSSCharacters(siteObjId));
                objAddRemoveSecondarySiteVO.setContactRole(EsapiUtil.stripXSSCharacters(contactRole));
                status = contactSiteService
                        .addContactSecondarySite(objAddRemoveSecondarySiteVO);
            } else {
                rmdWebLogger.error("Failed to add Secondary site "
                        + AppConstants.MISSING_SOME_INPUT_PARAMS);
                status = AppConstants.MISSING_SOME_INPUT_PARAMS;
            }
        } catch (Exception ex) {
            status = AppConstants.FAILURE;
            rmdWebLogger
                    .error("RMDWebException occured in addContactSecondarySite() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return status;

    }

    /**
     * 
     * @param ParameterString
     *            ,HttpServletRequest request
     * @return String
     * @throws RMDWebException
     * @Description This method is used to remove the secondary sites from the
     *              contact
     * 
     */
    @RequestMapping(AppConstants.REQ_URI_REMOVE_CONTACT_SECONDARY_SITE)
    @ResponseBody
    public String removeContactSecondarySite(
            @RequestParam(value = AppConstants.GET_PARAMETER_STRING) final String parameterString)
            throws RMDWebException {
        String status = AppConstants.FAILURE;
        final ObjectMapper mapper = new ObjectMapper();
        List<AddRemoveSecondarySiteVO> removeSecondarySiteVOList = null;
        try {
            mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
            AddRemoveSecondarySiteVO[] arrRemoveSecSiteVo = mapper.readValue(
                    EsapiUtil.stripXSSCharacters(parameterString),
                    AddRemoveSecondarySiteVO[].class);
            if (null != arrRemoveSecSiteVo && arrRemoveSecSiteVo.length != 0) {
                removeSecondarySiteVOList = Arrays.asList(arrRemoveSecSiteVo);
                status = contactSiteService
                        .removeContactSecondarySite(removeSecondarySiteVOList);
            } else {
                rmdWebLogger
                        .error("No Secondary Sites are selected for the contact to remove");
                status = AppConstants.NO_SECONDARY_SITES_SELECTED;
            }
        } catch (Exception ex) {
            status = AppConstants.FAILURE;
            rmdWebLogger
                    .error("RMDWebException occured in removeContactSecondarySite() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            removeSecondarySiteVOList = null;
        }
        return status;
    }

    /**
     * 
     * @param ParameterString
     *            ,HttpServletRequest request
     * @return String
     * @throws RMDWebException
     * @Description This method is used to add or update the Contact details
     * 
     */
    @RequestMapping(AppConstants.REQ_URI_ADD_OR_UPDATE_CONTACT)
    @ResponseBody
    public String addOrUpdateContact(
            @RequestParam(value = AppConstants.GET_PARAMETER_STRING) final String parameterString)
            throws RMDWebException {
        String status = AppConstants.FAILURE;
        final ObjectMapper mapper = new ObjectMapper();
        ContactSiteDetailsVO objContactSiteDetailsVO = null;
        try {
            mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
            objContactSiteDetailsVO = mapper.readValue(
                    EsapiUtil.stripXSSCharacters(parameterString),
                    ContactSiteDetailsVO.class);
            if (null != objContactSiteDetailsVO) {
            	String emailRegEx = authService.getLookUpValueForName(AppConstants.EMAIL_REGEX);
        		if(!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO.getEmailId()) && !AppSecUtil.validateEmailAddress(objContactSiteDetailsVO.getEmailId(), emailRegEx)){
        			status = AppConstants.EMAIL_NOT_VALID;
        		} else {
        			status = contactSiteService
                        .addOrUpdateContact(objContactSiteDetailsVO);
        		}
            } else {
                rmdWebLogger.error("Failed to Add or  Update the Contact");
                status = AppConstants.FAILURE;
            }
        } catch (Exception ex) {
            status = AppConstants.FAILURE;
            rmdWebLogger
                    .error("RMDWebException occured in addOrUpdateContact() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            objContactSiteDetailsVO = null;
        }
        return status;
    }
    
    /**
     * @Author:
     * @param:HttpServletRequest request
     * @return:
     * @throws:RMDWebException
     * @Description: This method is used for exporting Contact details to CSV
     *               Format.
     */

    @RequestMapping(AppConstants.EXPORT_CONTACTS)
    @ResponseBody
    public void exportContacts(final HttpServletRequest request,
            final HttpServletResponse response, final Locale locale)
            throws RMDWebException, Exception {
        List<ContactDetailsVO> contactDetailsList = null;
        String csvContent = null;
        ServletOutputStream objServletOutputStream = null;
        BufferedInputStream objBufferedInputStream = null;
        BufferedOutputStream objBufferedOutputStream = null;
        ContactSearchVO objContactSearchVO = null;
        try {
            final String firstName = request
                    .getParameter(AppConstants.FIRST_NAME);
            final String lastName = request
                    .getParameter(AppConstants.LAST_NAME);
            final String siteId = request.getParameter(AppConstants.SITE_ID);
            final String siteName = request
                    .getParameter(AppConstants.SITE_NAME);
            final String phNo = request.getParameter(AppConstants.PH_NO);
            final String contactStatus = request
                    .getParameter(AppConstants.CONTACT_STATUS);
            objContactSearchVO = new ContactSearchVO();
            if (null != firstName) {
                objContactSearchVO.setFirstName(firstName);
            }
            if (null != lastName) {
                objContactSearchVO.setLastName(lastName);
            }
            if (null != siteId) {
                objContactSearchVO.setSiteId(siteId);
            }
            if (null != siteName) {
                objContactSearchVO.setSiteName(siteName);
            }
            if (null != phNo) {
                objContactSearchVO.setPhNo(phNo);
            }
            if (null != contactStatus) {
                objContactSearchVO.setContactStatus(contactStatus);
            }
            contactDetailsList = contactSiteService
                    .getContacts(objContactSearchVO);

            if (null != contactDetailsList && !contactDetailsList.isEmpty()) {
                request.setAttribute(AppConstants.CONTACT_DETAILS_LIST,
                        contactDetailsList);
                csvContent = convertToCSVTemplateReport(contactDetailsList,
                        locale);
                response.setContentType(AppConstants.CONTENT_TYPE);
                response.setHeader(AppConstants.CONTENT,
                        AppConstants.ATTACH_FILENAME
                                + AppConstants.CONTACT_EXPORT_FILENAME);
                objServletOutputStream = response.getOutputStream();
                ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
                        csvContent.getBytes());
                objBufferedInputStream = new BufferedInputStream(
                        objByteArrayInputStream);
                objBufferedOutputStream = new BufferedOutputStream(
                        objServletOutputStream);
                byte[] byteArr = new byte[2048];
                int bytesread;

                while ((bytesread = objBufferedInputStream.read(byteArr, 0,
                        byteArr.length)) != -1) {
                    objBufferedOutputStream.write(byteArr, 0, bytesread);
                    objBufferedOutputStream.flush();
                }
            }
        } catch (RMDWebException rmdEx) {
            rmdWebLogger
                    .error("RMDWebException occured in exportContacts() method of ContactSiteController",
                            rmdEx);
            request.setAttribute(AppConstants.ERRORMSG,
                    AppConstants.UNKNOWN_EXCEPTION);
            throw rmdEx;
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in exportContacts() method of ContactSiteController",
                            ex);
            request.setAttribute(AppConstants.ERRORMSG,
                    AppConstants.UNKNOWN_EXCEPTION);
            throw ex;
        } finally {
            if (objBufferedInputStream != null) {
                objBufferedInputStream.close();
            }
            if (objBufferedOutputStream != null) {
                objBufferedOutputStream.close();
                objServletOutputStream.close();
                objServletOutputStream = null;
            }

        }

    }

    private String convertToCSVTemplateReport(
            List<ContactDetailsVO> contactDetailsList, Locale locale) {
        StringBuilder strContactDetailsBuffer = new StringBuilder();
        String csvContent = null;
        try {

            strContactDetailsBuffer.append(appContext.getMessage(
                    AppConstants.CONTACTS_REPORT_HEADER, null, locale));

            strContactDetailsBuffer.append(RMDCommonConstants.NEWLINE);
            if (RMDCommonUtility.isCollectionNotEmpty(contactDetailsList)) {
                for (ContactDetailsVO objContactDetailsVO : contactDetailsList) {

                    strContactDetailsBuffer
                            .append(RMDCommonUtil
                                    .removeHtmlandNullValues(objContactDetailsVO
                                            .getFirstName())
                                    + RMDCommonConstants.COMMMA_SEPARATOR
                                    + RMDCommonUtil
                                            .removeHtmlandNullValues(objContactDetailsVO
                                                    .getLastName())
                                    + RMDCommonConstants.COMMMA_SEPARATOR
                                    + RMDCommonUtil
                                            .removeHtmlandNullValues(objContactDetailsVO
                                                    .getPhNo())
                                    + RMDCommonConstants.COMMMA_SEPARATOR
                                    + RMDCommonUtil
                                            .removeHtmlandNullValues(objContactDetailsVO
                                                    .getSiteName())
                                    + RMDCommonConstants.COMMMA_SEPARATOR
                                    + RMDCommonUtil
                                            .removeHtmlandNullValues(objContactDetailsVO
                                                    .getCity())
                                    + RMDCommonConstants.COMMMA_SEPARATOR
                                    + RMDCommonUtil
                                            .removeHtmlandNullValues(objContactDetailsVO
                                                    .getCountry())
                                    + RMDCommonConstants.COMMMA_SEPARATOR
                                    + RMDCommonUtil
                                            .removeHtmlandNullValues(objContactDetailsVO
                                                    .getContactRole()));

                    strContactDetailsBuffer.append(RMDCommonConstants.NEWLINE);
                }

            }

            csvContent = strContactDetailsBuffer.toString();
        } catch (Exception ex) {

            rmdWebLogger
                    .error("Export to CSV convertToCSVTemplateReport() method of ContactSiteController"
                            + ex);
        }
        return csvContent;
    }

    /**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:RMDWebException
     * @Description: This method is used for fetching the address search filter
     *               options
     */
    @RequestMapping(value = AppConstants.REQ_URI_GET_ADDRESS_FILTER_OPTIONS)
    @ResponseBody
    public Map<String, String> getAddressFilterOptions() throws RMDWebException {
        Map<String, String> contactStatusMap = new LinkedHashMap<String, String>();
        try {
            contactStatusMap = contactSiteService.getAddressFilterOptions();
        } catch (Exception ex) {
            rmdWebLogger
                    .error("RMDWebException occured in getAddressFilterOptions() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return contactStatusMap;
    }

    /**
     * 
     * @param
     * @return List<AddressDetailsVO>
     * @throws RMDWebException
     * @Description This method is used to get the address details for the given
     *              search combination.
     * 
     */
    @RequestMapping(AppConstants.REQ_URI_GET_ADDRESS)
    @ResponseBody
    public List<AddressDetailsVO> getAddress(
            @RequestParam(value = AppConstants.ADDRESS) final String address,
            @RequestParam(value = AppConstants.CITY) final String city,
            @RequestParam(value = AppConstants.STATE) final String state,
            @RequestParam(value = AppConstants.ZIP_CODE) final String zipCode,
            @RequestParam(value = AppConstants.ADDRESS_FILTER) final String addrFilter,
            @RequestParam(value = AppConstants.CITY_FILTER) final String cityFilter,
            @RequestParam(value = AppConstants.STATE_FILTER) final String stateFilter,
            @RequestParam(value = AppConstants.ZIPCODE_FILTER) final String zipCodeFilter)
            throws RMDWebException {

        List<AddressDetailsVO> addressDetailsList = null;
        AddressSearchVO objAdressSearchVO = new AddressSearchVO();
        try {
            if (null != address) {
                objAdressSearchVO.setAddress(address);
            }
            if (null != city) {
                objAdressSearchVO.setCity(city);
            }
            if (null != state) {
                objAdressSearchVO.setState(state);
            }
            if (null != zipCode) {
                objAdressSearchVO.setZipCode(zipCode);
            }
            if (null != addrFilter) {
                objAdressSearchVO.setAddrFilter(addrFilter);
            }
            if (null != cityFilter) {
                objAdressSearchVO.setCityFilter(cityFilter);
            }
            if (null != stateFilter) {
                objAdressSearchVO.setStateFilter(stateFilter);
            }
            if (null != zipCodeFilter) {
                objAdressSearchVO.setZipCodeFilter(zipCodeFilter);
            }
            addressDetailsList = contactSiteService
                    .getAddress(objAdressSearchVO);
        } catch (Exception ex) {
            rmdWebLogger
                    .error("RMDWebException occured in getAddress() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            objAdressSearchVO = null;
        }

        return addressDetailsList;

    }

    /**
     * 
     * @param addrObjId
     * @return AddressDetailsVO
     * @throws RMDWebException
     * @Description This method is used to get the all details for the selected
     *              address
     * 
     */
    @RequestMapping(AppConstants.REQ_URI_VIEW_ADDRESS_DETAILS)
    @ResponseBody
    public AddressDetailsVO viewAddressDetails(
            @RequestParam(value = AppConstants.ADDRESS_OBJID) final String addrObjId)
            throws RMDWebException {
        AddressDetailsVO objAddressDetailsVO = null;
        try {
            if (!RMDCommonUtility.isNullOrEmpty(addrObjId)) {
                objAddressDetailsVO = contactSiteService
                        .viewAddressDetails(EsapiUtil.stripXSSCharacters(addrObjId));
            }
        } catch (Exception ex) {
            rmdWebLogger
                    .error("RMDWebException occured in viewAddressDetails() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return objAddressDetailsVO;

    }

    /**
     * 
     * @param
     * @return List<String>
     * @throws RMDWebException
     * @Description This method is used to get the all country List
     * 
     */
    @RequestMapping(AppConstants.REQ_URI_COUNTRY_LIST)
    @ResponseBody
    public List<String> getCountryList() throws RMDWebException {
        List<String> arCountryList = null;
        try {
            arCountryList = contactSiteService.getCountryList();
        } catch (Exception ex) {
            rmdWebLogger
                    .error("RMDWebException occured in getCountryList() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return arCountryList;

    }

    /**
     * 
     * @param String
     *            country
     * @return List<String>
     * @throws RMDWebException
     * @Description This method is used to get the states for the selected
     *              Country
     * 
     */
    @RequestMapping(AppConstants.REQ_URI_GET_COUNTRY_STATES)
    @ResponseBody
    public List<String> getCountryStates(
            @RequestParam(value = AppConstants.COUNTRY) final String country)
            throws RMDWebException {
        List<String> stateList = null;
        try {
            stateList = contactSiteService.getCountryStates(EsapiUtil.stripXSSCharacters(country));
        } catch (Exception ex) {
            rmdWebLogger
                    .error("RMDWebException occured in getCountryStates() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return stateList;
    }

    /**
     * 
     * @param String
     *            country
     * @return List<String>
     * @throws RMDWebException
     * @Description This method is used to get the time zones for the selected
     *              Country
     * 
     */
    @RequestMapping(AppConstants.REQ_URI_GET_COUNTRY_TIMEZONES)
    @ResponseBody
    public List<String> getCountryTimeZones(
            @RequestParam(value = AppConstants.COUNTRY) final String country)
            throws RMDWebException {
        List<String> stateList = null;
        try {
            stateList = contactSiteService.getCountryTimeZones(EsapiUtil.stripXSSCharacters(country));
        } catch (Exception ex) {
            rmdWebLogger
                    .error("RMDWebException occured in getCountryTimeZones() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return stateList;
    }

    /**
     * 
     * @param ParameterString
     *            ,HttpServletRequest request
     * @return String
     * @throws RMDWebException
     * @Description This method is used to add or update the Address details
     * 
     */
    @RequestMapping(AppConstants.REQ_URI_ADD_OR_UPDATE_ADDRESS)
    @ResponseBody
    public String addOrUpdateAddress(
            @RequestParam(value = AppConstants.GET_PARAMETER_STRING) final String parameterString)
            throws RMDWebException {
        String status = AppConstants.FAILURE;
        final ObjectMapper mapper = new ObjectMapper();
        AddressDetailsVO objAddressDetailsVO = null;
        try {
            mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
            objAddressDetailsVO = mapper.readValue(
                    EsapiUtil.stripXSSCharacters(parameterString),
                    AddressDetailsVO.class);
            if (null != objAddressDetailsVO) {
                status = contactSiteService
                        .addOrUpdateAddress(objAddressDetailsVO);
            } else {
                rmdWebLogger.error("Failed to Add or  Update the Address");
                status = AppConstants.FAILURE;
            }
        } catch (Exception ex) {
            status = AppConstants.FAILURE;
            rmdWebLogger
                    .error("RMDWebException occured in addOrUpdateAddress() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            objAddressDetailsVO = null;
        }
        return status;
    }

    /**
     * @Author:
     * @param:HttpServletRequest request
     * @return:
     * @throws:RMDWebException
     * @Description: This method is used for exporting Address details to CSV
     *               Format.
     */

    @RequestMapping(AppConstants.EXPORT_ADDRESS)
    @ResponseBody
    public void exportAddress(final HttpServletRequest request,
            final HttpServletResponse response, final Locale locale)
            throws RMDWebException, Exception {
        List<AddressDetailsVO> addrDetailsList = null;
        String csvContent = null;
        ServletOutputStream objServletOutputStream = null;
        BufferedInputStream objBufferedInputStream = null;
        BufferedOutputStream objBufferedOutputStream = null;
        AddressSearchVO objAddressSearchVO = null;
        try {
            final String address = request.getParameter(AppConstants.ADDRESS);
            final String addrFilter = request
                    .getParameter(AppConstants.ADDRESS_FILTER);
            final String city = request.getParameter(AppConstants.CITY);
            final String cityFilter = request
                    .getParameter(AppConstants.CITY_FILTER);
            final String state = request.getParameter(AppConstants.STATE);
            final String stateFilter = request
                    .getParameter(AppConstants.STATE_FILTER);
            final String zipCode = request.getParameter(AppConstants.ZIP_CODE);
            final String zipCodeFilter = request
                    .getParameter(AppConstants.ZIPCODE_FILTER);
            objAddressSearchVO = new AddressSearchVO();

            if (null != address) {
                objAddressSearchVO.setAddress(address);
            }
            if (null != city) {
                objAddressSearchVO.setCity(city);
            }
            if (null != state) {
                objAddressSearchVO.setState(state);
            }
            if (null != zipCode) {
                objAddressSearchVO.setZipCode(zipCode);
            }
            if (null != addrFilter) {
                objAddressSearchVO.setAddrFilter(addrFilter);
            }
            if (null != cityFilter) {
                objAddressSearchVO.setCityFilter(cityFilter);
            }
            if (null != stateFilter) {
                objAddressSearchVO.setStateFilter(stateFilter);
            }
            if (null != zipCodeFilter) {
                objAddressSearchVO.setZipCodeFilter(zipCodeFilter);
            }
            addrDetailsList = contactSiteService.getAddress(objAddressSearchVO);

            if (null != addrDetailsList && !addrDetailsList.isEmpty()) {
                request.setAttribute(AppConstants.ADDRESS_DETAILS_LIST,
                        addrDetailsList);
                csvContent = addrConvertToCSVTemplateReport(addrDetailsList,
                        locale);
                response.setContentType(AppConstants.CONTENT_TYPE);
                response.setHeader(AppConstants.CONTENT,
                        AppConstants.ATTACH_FILENAME
                                + AppConstants.ADDRESS_EXPORT_FILENAME);
                objServletOutputStream = response.getOutputStream();
                ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
                        csvContent.getBytes());
                objBufferedInputStream = new BufferedInputStream(
                        objByteArrayInputStream);
                objBufferedOutputStream = new BufferedOutputStream(
                        objServletOutputStream);
                byte[] byteArr = new byte[2048];
                int bytesread;

                while ((bytesread = objBufferedInputStream.read(byteArr, 0,
                        byteArr.length)) != -1) {
                    objBufferedOutputStream.write(byteArr, 0, bytesread);
                    objBufferedOutputStream.flush();
                }
            }
        } catch (RMDWebException rmdEx) {
            rmdWebLogger
                    .error("RMDWebException occured in exportAddress() method of ContactSiteController",
                            rmdEx);
            request.setAttribute(AppConstants.ERRORMSG,
                    AppConstants.UNKNOWN_EXCEPTION);
            throw rmdEx;
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in exportAddress() method of ContactSiteController",
                            ex);
            request.setAttribute(AppConstants.ERRORMSG,
                    AppConstants.UNKNOWN_EXCEPTION);
            throw ex;
        } finally {
            if (objBufferedInputStream != null) {
                objBufferedInputStream.close();
            }
            if (objBufferedOutputStream != null) {
                objBufferedOutputStream.close();
                objServletOutputStream.close();
                objServletOutputStream = null;
            }

        }

    }

    private String addrConvertToCSVTemplateReport(
            List<AddressDetailsVO> addrDetailsList, Locale locale) {
        StringBuilder strAddrDetailsBuffer = new StringBuilder();
        String csvContent = null;
        try {

            strAddrDetailsBuffer.append(appContext.getMessage(
                    AppConstants.ADDRESS_REPORT_HEADER, null, locale));

            strAddrDetailsBuffer.append(RMDCommonConstants.NEWLINE);
            if (RMDCommonUtility.isCollectionNotEmpty(addrDetailsList)) {
                for (AddressDetailsVO objAddressDetailsVO : addrDetailsList) {

                    strAddrDetailsBuffer
                            .append(RMDCommonUtil
                                    .removeHtmlandNullValues(objAddressDetailsVO
                                            .getAddress1())
                                    + RMDCommonConstants.COMMMA_SEPARATOR
                                    + RMDCommonUtil
                                            .removeHtmlandNullValues(objAddressDetailsVO
                                                    .getCity())
                                    + RMDCommonConstants.COMMMA_SEPARATOR
                                    + RMDCommonUtil
                                            .removeHtmlandNullValues(objAddressDetailsVO
                                                    .getState())
                                    + RMDCommonConstants.COMMMA_SEPARATOR
                                    + RMDCommonUtil
                                            .removeHtmlandNullValues(objAddressDetailsVO
                                                    .getZipCode()));

                    strAddrDetailsBuffer.append(RMDCommonConstants.NEWLINE);
                }
            }
            csvContent = strAddrDetailsBuffer.toString();
        } catch (Exception ex) {

            rmdWebLogger
                    .error("Export to CSV addrConvertToCSVTemplateReport() method of ContactSiteController"
                            + ex);
        }
        return csvContent;
    }
    
    /**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:RMDWebException
     * @Description: This method is used for fetching the contact status
     */
    @RequestMapping(value = AppConstants.REQ_URI_GET_CONTACT_ISD_CODE)
    @ResponseBody
    public Map<String, String> getISDCodes() throws RMDWebException {
        Map<String, String> contactStatusMap = new LinkedHashMap<String, String>();
        try {
            contactStatusMap = contactSiteService.getContactISDList();
        } catch (Exception ex) {
            rmdWebLogger
                    .error("RMDWebException occured in getContactStatus() method of ContactSiteController",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return contactStatusMap;
    }
}
