package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.owasp.esapi.ESAPI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.RepairFacilityDetailsVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.CustomerSiteResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.RepairFacilityDetailsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.RepairFacilityRequestType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class RepairFacilityServiceImpl extends RMDBaseServiceImpl implements RepairFacilityService{

	private final RMDWebLogger rmdWebLogger = RMDWebLogger
	.getLogger(getClass());

	@Autowired
	WebServiceInvoker webServiceInvoker;
	
	/**
	 * @Author:
	 * @param:customerId
	 * @return:Map<String, String>
	 * @throws:RMDWebException
	 * @Description: This method is used for fetching the sites for the selected
	 *               customer
	 */
	public Map<String, String> getCustomerSites(String customerId)
			throws RMDWebException {
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		final Map<String, String> siteMap = new TreeMap<String, String>();
		try {
			queryParamMap.put(AppConstants.CUSTOMER_ID, customerId);
			CustomerSiteResponseType[] siteResponse = (CustomerSiteResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_CUST_SITES, null, queryParamMap,
							null, CustomerSiteResponseType[].class);
			if (null != siteResponse) {
				for (int i = 0; i < siteResponse.length; i++) {
					siteMap.put(siteResponse[i].getSiteObjId(),
							siteResponse[i].getSiteName());
				}
				siteResponse=null;
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getCustomerSites() method in RepairFacilityServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return siteMap;
	}
	
	/**
	 * 
	 * @param customerId
	 *            ,site,status
	 * @return RepairFacilityDetailsVO
	 * @throws RMDWebException
	 * @Description This method is used to get the Repair Facility Details.
	 * 
	 */
	@Override
	public List<RepairFacilityDetailsVO> getRepairFacilityDetails(
			String customerId, String site, String status)
			throws RMDWebException {
		List<RepairFacilityDetailsVO> arlRepairFacilityDetailsVO = new ArrayList<RepairFacilityDetailsVO>();
		final Map<String, String> queryParamMap = new LinkedHashMap<String, String>();
		try {
			queryParamMap.put(AppConstants.CUSTOMER_ID, customerId);
			queryParamMap.put(AppConstants.SITE, site);
			queryParamMap.put(AppConstants.STATUS, status);
			RepairFacilityDetailsResponseType[] arrRepairFacilityDetailsResponseType = (RepairFacilityDetailsResponseType[]) webServiceInvoker
					.get(ServiceConstants.GET_REPAIR_FACILITY_DETAILS, null,
							queryParamMap, null,
							RepairFacilityDetailsResponseType[].class);
			if (null != arrRepairFacilityDetailsResponseType
					&& arrRepairFacilityDetailsResponseType.length > 0) {
				arlRepairFacilityDetailsVO = new ArrayList<RepairFacilityDetailsVO>(arrRepairFacilityDetailsResponseType.length);
				for (RepairFacilityDetailsResponseType objRepairFacilityDetailsResponseType : arrRepairFacilityDetailsResponseType) {
					RepairFacilityDetailsVO objRepairFacilityDetailsVO = new RepairFacilityDetailsVO();
					objRepairFacilityDetailsVO
							.setObjId(objRepairFacilityDetailsResponseType
									.getObjId());
					objRepairFacilityDetailsVO.setRailWayDesigCode(ESAPI
							.encoder().decodeForHTML(
									objRepairFacilityDetailsResponseType
											.getRailWayDesigCode()));
					objRepairFacilityDetailsVO.setRepairLocation(ESAPI
							.encoder().decodeForHTML(
									objRepairFacilityDetailsResponseType
											.getRepairLocation()));
					objRepairFacilityDetailsVO.setLocationCode(ESAPI.encoder()
							.decodeForHTML(
									objRepairFacilityDetailsResponseType
											.getLocationCode()));
					objRepairFacilityDetailsVO
							.setStatus(objRepairFacilityDetailsResponseType
									.getStatus());
					arlRepairFacilityDetailsVO.add(objRepairFacilityDetailsVO);
				}
				arrRepairFacilityDetailsResponseType =null;
			}
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in getRepairFacilityDetails() method of RepairFacilityServiceImpl",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return arlRepairFacilityDetailsVO;
	}

	/**
	 * 
	 * @param RepairFacilityBean
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used to insert new repair/site location
	 *              details.
	 * 
	 */
	@Override
	public String insertRepairSiteLoc(
			RepairFacilityDetailsVO repairFacilityDetailsVO)
			throws RMDWebException {

		String result = AppConstants.FAILURE;
		RepairFacilityRequestType objRepairFacilityRequestType = new RepairFacilityRequestType();
		try {
			if (!RMDCommonUtility.isNullOrEmpty(repairFacilityDetailsVO
					.getCustomerId())) {
				objRepairFacilityRequestType
						.setCustomerId(repairFacilityDetailsVO.getCustomerId());
			}
			if (!RMDCommonUtility.isNullOrEmpty(repairFacilityDetailsVO
					.getSite())) {

				objRepairFacilityRequestType.setSite(repairFacilityDetailsVO
						.getSite());
			}
			if (!RMDCommonUtility.isNullOrEmpty(repairFacilityDetailsVO
					.getRailWayDesigCode())) {
				objRepairFacilityRequestType.setRailwayDesigCode(ESAPI
						.encoder().encodeForXML(
								repairFacilityDetailsVO.getRailWayDesigCode()));
			}
			if (!RMDCommonUtility.isNullOrEmpty(repairFacilityDetailsVO
					.getRepairLocation())) {
				objRepairFacilityRequestType.setRepairLocation(ESAPI.encoder()
						.encodeForXML(
								repairFacilityDetailsVO.getRepairLocation()));
			}
			if (!RMDCommonUtility.isNullOrEmpty(repairFacilityDetailsVO
					.getLocationCode())) {
				objRepairFacilityRequestType
						.setLocationCode(ESAPI.encoder().encodeForXML(
								repairFacilityDetailsVO.getLocationCode()));
			}
			if (!RMDCommonUtility.isNullOrEmpty(repairFacilityDetailsVO
					.getStatus())) {
				objRepairFacilityRequestType.setStatus(repairFacilityDetailsVO
						.getStatus());
			}
			if (!RMDCommonUtility.isNullOrEmpty(repairFacilityDetailsVO
					.getUserName())) {
				objRepairFacilityRequestType
						.setUserName(repairFacilityDetailsVO.getUserName());
			}
			result = (String) webServiceInvoker.post(
					ServiceConstants.INSERT_REPAIR_SITE_LOCATION,
					objRepairFacilityRequestType, String.class);
		} catch (Exception ex) {
			rmdWebLogger
					.error("Exception occured in insertRepairSiteLoc() method of RepairFacilityServiceImpl",
							ex);
			result = AppConstants.FAILURE;
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * 
	 * @param List
	 *            <RepairFacilityDetailsVO>
	 * @return String
	 * @throws RMDWebException
	 * @Description This method is used to update existing repair/site location
	 *              details.
	 * 
	 */
	@Override
	public String updateRepairSiteLoc(
			List<RepairFacilityDetailsVO> repairFacilityDetailsVOList)
			throws RMDWebException {
		String result = AppConstants.FAILURE;
		List<RepairFacilityRequestType> repairFacilityRequestTypeList = new ArrayList<RepairFacilityRequestType>();
		RepairFacilityRequestType objRepairFacilityRequestType = new RepairFacilityRequestType();
		try {
			for (RepairFacilityDetailsVO objRepairFacilityDetailsVO : repairFacilityDetailsVOList) {
				RepairFacilityRequestType repairFacilityRequestType = new RepairFacilityRequestType();

				if (!RMDCommonUtility.isNullOrEmpty(objRepairFacilityDetailsVO
						.getCustomerId())) {
					repairFacilityRequestType
							.setCustomerId(objRepairFacilityDetailsVO
									.getCustomerId());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objRepairFacilityDetailsVO
						.getObjId())) {
					repairFacilityRequestType
							.setObjId(objRepairFacilityDetailsVO.getObjId());
				}
				if (!RMDCommonUtility.isNullOrEmpty(objRepairFacilityDetailsVO
						.getRailWayDesigCode())) {
					repairFacilityRequestType.setRailwayDesigCode(ESAPI
							.encoder().encodeForXML(
									objRepairFacilityDetailsVO
											.getRailWayDesigCode()));
				}
				if (!RMDCommonUtility.isNullOrEmpty(objRepairFacilityDetailsVO
						.getRepairLocation())) {
					repairFacilityRequestType.setRepairLocation(ESAPI.encoder()
							.encodeForXML(
									objRepairFacilityDetailsVO
											.getRepairLocation()));
				}
				if (!RMDCommonUtility.isNullOrEmpty(objRepairFacilityDetailsVO
						.getLocationCode())) {
					repairFacilityRequestType.setLocationCode(ESAPI.encoder()
							.encodeForXML(
									objRepairFacilityDetailsVO
											.getLocationCode()));
				}

				if (!RMDCommonUtility.isNullOrEmpty(objRepairFacilityDetailsVO
						.getStatus())) {
					repairFacilityRequestType
							.setStatus(objRepairFacilityDetailsVO.getStatus());
				}

				if (!RMDCommonUtility.isNullOrEmpty(objRepairFacilityDetailsVO
						.getUserName())) {
					repairFacilityRequestType
							.setUserName(objRepairFacilityDetailsVO
									.getUserName());
				}

				repairFacilityRequestTypeList.add(repairFacilityRequestType);

			}
			objRepairFacilityRequestType
					.setArlRepairFaciityRequestType(repairFacilityRequestTypeList);
			result = (String) webServiceInvoker.post(
					ServiceConstants.UPDATE_REPAIR_LOCATION_DETAILS,
					objRepairFacilityRequestType, String.class);

		} catch (Exception ex) {
			result = AppConstants.FAILURE;
			rmdWebLogger
					.error("Exception occured in updateRepairSilteLoc() method of RepairFacilityServiceImpl ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return result;
	}

	/**
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Description * This method is used to fetch the values from lookup table
	 *              to populate the rail code status values in drop down.
	 */
	public Map<String, String> getRepairFacilityStatus() throws RMDWebException {
		Map<String, String> statusMap = new LinkedHashMap<String, String>();
		String repairStatus = null;
		try {
			final Map<String, String> pathParams = new LinkedHashMap<String, String>();
			pathParams.put(AppConstants.LIST_NAME,
					AppConstants.REPAIR_FACILITY_STATUS_TYPE_LIST);
			final ApplicationParametersResponseType[] applParamResponseType = getLookupValue(pathParams);
			if (null != applParamResponseType) {
				for (int i = 0; i < applParamResponseType.length; i++) {
					repairStatus = applParamResponseType[i].getLookupValue();
					statusMap.put(repairStatus, repairStatus);
				}
			}
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getCfgStatusList method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return statusMap;
	}

}
