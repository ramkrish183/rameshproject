/**
 * ============================================================
 * File : VisualizationController.java
 * Description : 
 * 
 * Package : com.ge.trans.rmd.cm.mvc.controller
 * Author : iGATE Patni
 * Last Edited By :
 * Version : 1.0
 * Created on : Feb 8, 2012
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2011 General Electric Company. All rights reserved
 *
 * ============================================================
 */

package com.ge.trans.rmd.cm.mvc.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.AssetOverviewService;
import com.ge.trans.rmd.cm.service.VisualizationService;
import com.ge.trans.rmd.cm.valueobjects.RxVisualizationPlotInfoVO;
import com.ge.trans.rmd.cm.valueobjects.VisualizationDataResponseVO;
import com.ge.trans.rmd.cm.valueobjects.VisualizationDetailsBean;
import com.ge.trans.rmd.cm.valueobjects.VisualizationEventDataResponseVO;
import com.ge.trans.rmd.cm.valueobjects.VisualizationEventDataVO;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.km.util.KMConstants;
import com.ge.trans.rmd.pp.beans.AssetBean;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

/*******************************************************************************
 * 
 * @Author : iGATE
 * @Version : 1.0
 * @Date Created: July 21, 2011
 * @Date Modified : July 25, 2011
 * @Modified By :
 * @Contact :
 * @Description : Controller class for fetching the details related to
 *              visualization screen
 * @History :
 * 
 ******************************************************************************/
@Controller
public class VisualizationController extends RMDBaseController {

	@Autowired
	private VisualizationService visualService;

	@Autowired
	private AssetOverviewService asstOvwService;

	
	final private RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	/**
	 * @Author:
	 * @return
	 * @Description: Displays the Visualization page of the RMD application
	 */
	@RequestMapping(AppConstants.REQ_URI_VISUALIZATION)
	public ModelAndView showCharts(final HttpServletRequest request)
			throws RMDWebException, Exception {
		final String strAssetId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.WS_PARAM_ASSTNUM));
		String strCustomerId = null;
		final String strGrpName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_GROUP_NAME));
		String controllerCfg = null;
		String family=null;
		request.setAttribute(AppConstants.WS_PARAM_ASSTNUM, strAssetId);
		request.setAttribute(AppConstants.ASSET_GROUP_NAME, strGrpName);
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		AssetOverviewBean assetOverviewBean = new AssetOverviewBean();
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		Map<String, String> graphNames = new LinkedHashMap<String, String>();

		try {
			/*Begin of Changes for fetching customer Id from Webservices */
			strCustomerId=asstOvwService.getCustomerId(strAssetId, strGrpName);
			/*End of Changes*/
			assetOverviewBean.setAsset(strAssetId);
			assetOverviewBean.setUserTimeZone(applicationTimezone);
			assetOverviewBean.setUserLanguage(userVO.getStrUserLanguage());
			assetOverviewBean.setCustomer(strCustomerId);
			assetOverviewBean.setAssetGroup(strGrpName);
			assetOverviewBean = asstOvwService.getAssets(assetOverviewBean);
			controllerCfg = assetOverviewBean.getControllerConfig();
			final String fleet=assetOverviewBean.getFleet();
			final String fleetId=assetOverviewBean.getFleetId();
			request.setAttribute(AppConstants.FLEET,
					fleet);
			request.setAttribute(AppConstants.FLEET_ID,
					fleetId);
			request.setAttribute(AppConstants.CUSTOMER_NAME, assetOverviewBean.getCustomer());
			String model=assetOverviewBean.getModel();
			
			family=visualService.getVizAssetFamily(model);
			
			request.setAttribute(AppConstants.CONTROLLER_CONFIG, controllerCfg);
			request.setAttribute(AppConstants.FAMILY, family);
			final Map<String, String> sourceMap = getVisualizationSource();
			final Map<String, String> sourceTypeMap = getVisualizationSourceType();
			final Map<String, String> controllerTypeMap = getControllerType();
			final Map<String, String> sourceCodeTypeMap = getVisualizationSourceTypeCode();
			final String sourceDefault = visualService
					.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_SOURCE_DEFAULT);
			final String sourceTypeDefault = visualService
					.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_SOURCE_TYPE_DEFAULT);
			final String controllerTypeDefault = visualService
					.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_CONTROLLER_TYPE_DEFAULT);
			final String faultCodeDefault = visualService
			.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_FAULT_CODE_DEFAULT);
			final String notchDefault = visualService
			.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_NOTCH_DEFAULT);
			
			final String engineGHPDefaultSelect = visualService
			.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_ENGINE_GHP_DEFAULT_SELECT);
			
			final String engineGHPDefaultValue1 = visualService
			.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_ENGINE_GHP_DEFAULT_VALUE1);
			
			//added for Anomaly visualization
			final String oilInletDefaultSelect = visualService
			.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_OIL_INLET_DEFAULT_SELECT);			
			final String oilInletDefaultValue1 = visualService
			.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_OIL_INLET_DEFAULT_VALUE1);			
			final String oilInletDefaultValue2 = visualService
			.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_OIL_INLET_DEFAULT_VALUE2);			
			final String hpAvailableDefaultSelect = visualService
			.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_HP_AVAILABLE_DEFAULT_SELECT);			
			final String hpAvailableDefaultValue1 = visualService
			.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_HP_AVAILABLE_DEFAULT_VALUE1);			
			final String hpAvailableDefaultValue2 = visualService
			.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_HP_AVAILABLE_DEFAULT_VALUE2);			
			final String barometricPressDefaultSelect = visualService
			.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_BAROMETRIC_DEFAULT_SELECT);			
			final String barometricPressDefaultValue1 = visualService
			.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_BAROMETRIC_DEFAULT_VALUE1);			
			final String barometricPressDefaultValue2 = visualService
			.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_BAROMETRIC_DEFAULT_VALUE2);
//			final String sourceTypeCodeDefault = visualService
//			.getVisualizationDefaultValues(AppConstants.OMD_VISUALIZATION_SOURCE_TYPE_CD_DEFAULT);
			final Map<String, String> rangeSelector = getRangeSelector();
			final Map<String, Map<String, String>> graphDetails = visualService
					.getGraphName(controllerCfg, sourceDefault,
							sourceTypeDefault);
			final int noOfDays = getNumberOfDays();
			final int dateDiffValidation = getNumberOfDaysValidation();
			if (graphDetails.containsKey(controllerCfg
					+ RMDCommonConstants.UNDERSCORE + sourceTypeDefault)) {
				graphNames.put(AppConstants.CANNED_LABEL, AppConstants.EMPTY_STRING);
			    graphNames.putAll(graphDetails.get(controllerCfg
					+ RMDCommonConstants.UNDERSCORE + sourceTypeDefault));
			}
			
			if (null != graphNames && graphNames.size() > 0) {
				request.setAttribute(AppConstants.LISTOFGRAPH, graphNames);
			} else {
				graphNames = new HashMap<String, String>();
				graphNames.put(AppConstants.CANNED_NOT_AVAILABLE,
						AppConstants.EMPTY_STRING);
				request.setAttribute(AppConstants.LISTOFGRAPH, graphNames);
			}

			request.setAttribute(AppConstants.VISUALIZATION_SOURCE_DEFAULT,
					sourceDefault);
			request.setAttribute(AppConstants.VISUALIZATION_SOURCE_DEFAULT,
					sourceDefault);
			request.setAttribute(
					AppConstants.VISUALIZATION_SOURCE_TYPE_DEFAULT,
					sourceTypeDefault);
			request.setAttribute(AppConstants.VISUALIZATION_SOURCE, sourceMap);
			request.setAttribute(AppConstants.VISUALIZATION_SOURCE_TYPE,
					sourceTypeMap);
			request.setAttribute(AppConstants.CONTROLLER_TYPE,
					controllerTypeMap);
			request.setAttribute(AppConstants.SOURCE_TYPE_CD,
					sourceCodeTypeMap);
			request.setAttribute(AppConstants.CONTROLLER_TYPE_DEFAULT,
					controllerTypeDefault);
//			request.setAttribute(AppConstants.SOURCE_TYPE_CD_DEFAULT,
//					sourceTypeCodeDefault);
			request.setAttribute(AppConstants.VISUALIZATION_DEFAULT_NO_OF_DAYS,
					noOfDays);
			request.setAttribute(
					AppConstants.VISUALIZATION_DATE_DIFF_VALIDATION_DAYS,
					dateDiffValidation);
			request.setAttribute(AppConstants.VISUALIZATION_RANGESELECTOR,
					rangeSelector);
			request.setAttribute(AppConstants.FAULT_CODE_DEFAULT,
					faultCodeDefault);
			request.setAttribute(AppConstants.NOTCH_DEFAULT,
					notchDefault);
			request.setAttribute(AppConstants.ENGINE_GHP_DEFAULT_SELECT,
					engineGHPDefaultSelect);
			request.setAttribute(AppConstants.ENGINE_GHP_DEFAULT_VALUE1,
					engineGHPDefaultValue1);
			
			//added by Anomaly Visualization
			
			request.setAttribute(AppConstants.OIL_INLET_DEFAULT_SELECT,
					oilInletDefaultSelect);
			request.setAttribute(AppConstants.OIL_INLET_DEFAULT_VALUE1,
					oilInletDefaultValue1);
			request.setAttribute(AppConstants.OIL_INLET_DEFAULT_VALUE2,
					oilInletDefaultValue2);
			request.setAttribute(AppConstants.HP_AVAILABLE_DEFAULT_SELECT,
					hpAvailableDefaultSelect);
			request.setAttribute(AppConstants.HP_AVAILABLE_DEFAULT_VALUE1,
					hpAvailableDefaultValue1);
			request.setAttribute(AppConstants.HP_AVAILABLE_DEFAULT_VALUE2,
					hpAvailableDefaultValue2);
			request.setAttribute(AppConstants.BAROMETRIC_DEFAULT_SELECT,
					barometricPressDefaultSelect);
			request.setAttribute(AppConstants.BAROMETRIC_DEFAULT_VALUE1,
					barometricPressDefaultValue1);
			request.setAttribute(AppConstants.BAROMETRIC_DEFAULT_VALUE2,
					barometricPressDefaultValue2);
			
			request.setAttribute(AppConstants.CUSTOMER_ID, strCustomerId);
			return new ModelAndView(AppConstants.VIEW_VISUALIZATION);

		} catch (Exception ex) {
			logger.error("Exception occured in showCharts method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		logger.debug("Visualization Controller : showCharts() method Ends");

		return new ModelAndView(AppConstants.VIEW_VISUALIZATION);
	}

	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @throws Exception
	 * @Description: This method is used to fetch the values for source dropdown
	 *               from lookup table
	 * 
	 */

	@RequestMapping(value = AppConstants.REQ_URI_GET_VISUALIZATION_SOURCE)
	public @ResponseBody
	java.util.Map<String, String> getVisualizationSource()
			throws RMDWebException {

		Map<String, String> visualSource = new HashMap<String, String>();

		try {
			visualSource = visualService
					.getVisualizationLookUps(AppConstants.OMD_VISUALIZATION_SOURCE);

		} catch (Exception e) {

			RMDWebErrorHandler.handleException(e);
		}
		return visualSource;
	}

	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @throws Exception
	 * @Description: This method is used to fetch the values for Controller Type
	 *               dropdown from lookup table
	 * 
	 */

	@RequestMapping(value = AppConstants.REQ_URI_GET_VISUALIZATION_CONTROLLER_TYPE)
	public @ResponseBody
	java.util.Map<String, String> getControllerType() throws RMDWebException {

		Map<String, String> controllerType = new HashMap<String, String>();

		try {
			controllerType = visualService
					.getVisualizationLookUps(AppConstants.OMD_VISUALIZATION_CONTROLLER_TYPE);

		} catch (Exception e) {

			RMDWebErrorHandler.handleException(e);
		}
		return controllerType;
	}
	
	
	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @throws Exception
	 * @Description: This method is used to fetch the values for sourceCodeType
	 *               dropdown from lookup table
	 * 
	 */

	@RequestMapping(value = AppConstants.REQ_URI_GET_VISUALIZATION_SOURCE_TYPE_CD)
	public @ResponseBody
	java.util.Map<String, String> getVisualizationSourceTypeCode() throws RMDWebException {

		Map<String, String> sourceTypeCode = new HashMap<String, String>();

		try {
			sourceTypeCode = visualService
					.getVisualizationLookUps(AppConstants.OMD_VISUALIZATION_SOURCE_TYPE_CD);

		} catch (Exception e) {

			RMDWebErrorHandler.handleException(e);
		}
		return sourceTypeCode;
	}

	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @throws Exception
	 * @Description: This method is used to fetch the values for notch list
	 *               dropdown from lookup table
	 * 
	 */

	@RequestMapping(value = AppConstants.REQ_URI_GET_VISUALIZATION_NOTCH_LIST)
	public @ResponseBody
	java.util.Map<String, String> getNotchList() throws RMDWebException {

		Map<String, String> notchList = new HashMap<String, String>();

		try {
			notchList = visualService
					.getLookUpValuesWithDescription(AppConstants.OMD_VISUALIZATION_NOTCH_LIST);

		} catch (Exception e) {

			RMDWebErrorHandler.handleException(e);
		}
		return notchList;
	}
	
	@RequestMapping(value = AppConstants.REQ_URI_GET_VISUALIZATION_RANGE_SELECTOR)
	public @ResponseBody
	java.util.Map<String, String> getRangeSelector() throws RMDWebException {

		Map<String, String> dateRangeSelector = new LinkedHashMap<String, String>();

		try {
			dateRangeSelector = visualService
					.getLookUpValuesWithDescription(AppConstants.OMD_VISUALIZATION_RANGE_SELECTOR);


		} catch (Exception e) {

			RMDWebErrorHandler.handleException(e);
		}
		return dateRangeSelector;
	}

	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @throws Exception
	 * @Description: This method is used to fetch the values for logical
	 *               operators dropdown from lookup table
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_LOGICAL_OPERATOR)
	public @ResponseBody
	java.util.Map<String, String> getLogicalOperator() throws RMDWebException {

		Map<String, Map<String, String>> logicalOperator = new HashMap<String, Map<String, String>>();
		Map<String, String> notchLogicalOperators = new HashMap<String, String>();
		try {
			logicalOperator = visualService.getLogicalOperators();
			notchLogicalOperators = logicalOperator
					.get(AppConstants.SIMPLE_OPERATORS);
			if (null != logicalOperator.get(AppConstants.COMPLEX_OPERATORS)) {
				notchLogicalOperators.putAll(logicalOperator
						.get(AppConstants.COMPLEX_OPERATORS));
			}
		} catch (Exception e) {

			RMDWebErrorHandler.handleException(e);
		}
		return notchLogicalOperators;
	}

	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @throws Exception
	 * @Description: This method is used to fetch the values for complex logical
	 *               operators dropdown from lookup table
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_COMP_LOGICAL_OPERATOR)
	public @ResponseBody
	java.util.List<String> getComplexLogicalOperator() throws RMDWebException {

		Map<String, Map<String, String>> logicalOperator = new HashMap<String, Map<String, String>>();
		Map<String, String> compLogicalOperators = new HashMap<String, String>();
		List<String> complexOp = null;
		try {
			logicalOperator = visualService.getLogicalOperators();
			compLogicalOperators = logicalOperator
					.get(AppConstants.COMPLEX_OPERATORS);
			complexOp = new ArrayList<String>(compLogicalOperators.values());
		} catch (Exception e) {

			RMDWebErrorHandler.handleException(e);
		}
		return complexOp;
	}

	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @throws Exception
	 * @Description: This method is used to fetch the values for locostate
	 *               dropdown from lookup table
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_LOCO_STATE)
	public @ResponseBody
	java.util.Map<String, String> getLocoState() throws RMDWebException {

		Map<String, String> locoState = new HashMap<String, String>();

		try {
			locoState = visualService
					.getLookUpValuesWithDescription(AppConstants.OMD_VISUALIZATION_LOCO_STATE_LIST);

		} catch (Exception e) {

			RMDWebErrorHandler.handleException(e);
		}
		return locoState;
	}

	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @throws Exception
	 * @Description: This method is used to fetch the values for sourceType
	 *               dropdown from lookup table
	 * 
	 */

	@RequestMapping(value = AppConstants.REQ_URI_GET_VISUALIZATION_SOURCETYPE)
	public @ResponseBody
	java.util.Map<String, String> getVisualizationSourceType()
			throws RMDWebException {
		Map<String, String> visualSourceType = new HashMap<String, String>();

		try {
			visualSourceType = visualService
					.getVisualizationLookUps(AppConstants.OMD_VISUALIZATION_SOURCE_TYPE);

		} catch (Exception e) {

			RMDWebErrorHandler.handleException(e);
		}
		return visualSourceType;
	}

	/**
	 * @Author:
	 * @param
	 * @return Map<String, String>
	 * @throws Exception
	 * @Description: This method is used to fetch the values for faultcode
	 *               autocomplete
	 * 
	 * 
	 */

	@RequestMapping(value = AppConstants.REQ_URI_GET_FAULT_CODES)
	public @ResponseBody
	java.util.Map<String, String> getFaultCode(
			@RequestParam(value = AppConstants.OMD_VISUALIZATION_FAULT_CODE, required = true) final String faultCode,
			@RequestParam(value = AppConstants.CONTROLLER_CONFIG, required = true) final String controllerCfg,
			final HttpServletRequest request) throws RMDWebException {
		Map<String, String> faultCodeDetails = new HashMap<String, String>();

		try {
			faultCodeDetails = visualService.getFaultCode(EsapiUtil.stripXSSCharacters(faultCode),
					EsapiUtil.stripXSSCharacters(controllerCfg));

		} catch (Exception e) {

			RMDWebErrorHandler.handleException(e);
		}
		return faultCodeDetails;
	}

	/**
	 * @Author:
	 * @param request
	 * @return java.util.Map<String, String>
	 * @throws Exception
	 * @Description:This method is used for fetching the records from lookup
	 *                   table for the Number Of Days
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_NUMBER_OF_DAYS)
	public @ResponseBody
	int getNumberOfDays() throws Exception {
		int numOfDaysMap = 0;
		try {
			numOfDaysMap = visualService
					.getVisualizationNoOfDays(AppConstants.OMD_VISUALIZATION_LOOKBACK_DAYS);
		} catch (Exception e) {
			logger.error("Exception occured in getNumberOfDays method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return numOfDaysMap;
	}

	/**
	 * @Author:
	 * @param request
	 * @return java.util.Map<String, String>
	 * @throws Exception
	 * @Description:This method is used for fetching the records from lookup
	 *                   table for the Number Of Days validation
	 * 
	 */
	public int getNumberOfDaysValidation() throws Exception {
		int numOfDaysMap = 0;
		try {
			numOfDaysMap = visualService
					.getVisualizationNoOfDays(AppConstants.OMD_VISUALIZATION_LOOKBACK_DAYS_VALIDATION);
		} catch (Exception e) {
			logger.error("Exception occured in getNumberOfDays method ", e);
			RMDWebErrorHandler.handleException(e);
		}
		return numOfDaysMap;
	}

	/**
	 * @Author:
	 * @param request
	 * @return java.util.Map<String, String>
	 * @throws Exception
	 * @Description:This method is used for fetching the graphNames
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_VISUALIZATION_GRAPHNAMES)
	public @ResponseBody
	java.util.Map<String, String> getGraphNames(final HttpServletRequest request)
			throws RMDWebException {

		Map<String, String> visualGraphNames = new LinkedHashMap<String, String>();
		Map<String, Map<String, String>> visualizationGraphMap = null;
		final String controllerCfg = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CONTROLLER_CONFIG));
		final String datasource = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.DATASOURCE));
		final String sourceType = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.VISUALIZATION_SOURCE_TYPE));

		try {
			visualizationGraphMap = visualService.getGraphName(controllerCfg,
					datasource, sourceType);
			if (visualizationGraphMap.containsKey(controllerCfg
					+ RMDCommonConstants.UNDERSCORE + sourceType)) {
				visualGraphNames.put(AppConstants.CANNED_LABEL,
						AppConstants.EMPTY_STRING);
			visualGraphNames.putAll(visualizationGraphMap.get(controllerCfg
					+ RMDCommonConstants.UNDERSCORE + sourceType));
			}
			
						
			if (null == visualGraphNames || visualGraphNames.size() == 0) {
				visualGraphNames = new HashMap<String, String>();
				visualGraphNames.put(AppConstants.CANNED_NOT_AVAILABLE,
						AppConstants.EMPTY_STRING);
			}

		} catch (Exception e) {

			RMDWebErrorHandler.handleException(e);
		}
		return visualGraphNames;
	}

	/**
	 * @Author:
	 * @param request
	 * @return java.util.Map<String, String>
	 * @throws Exception
	 * @Description:This method is used for fetching the records for
	 *                   visualization screen high chart
	 * 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_VISUALIZATION_DATA, method = {RequestMethod.GET,RequestMethod.POST})
	public @ResponseBody
	VisualizationDataResponseVO getColumnsAndData(
			final HttpServletRequest request,@RequestParam("parameterString") String parameterString) throws Exception {
		VisualizationDataResponseVO response = new VisualizationDataResponseVO();
		final ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			final 	VisualizationDetailsBean objVisualizationBean = mapper.readValue(EsapiUtil.stripXSSCharacters(parameterString),
					VisualizationDetailsBean.class);
			final Map<String, String> result = validateUserInputForVisualization(
					request,objVisualizationBean);
			if (!result.isEmpty() && null != result) {
				response.setErrorMsgs(result);
			} else {
				
				Calendar currCal = Calendar.getInstance();
				SimpleDateFormat obDateFormat = new SimpleDateFormat(
						AppConstants.DATE_FORMAT_24HRS);

				if (null != objVisualizationBean.getToDate()
						&& !objVisualizationBean.getToDate()
								.equalsIgnoreCase(AppConstants.NULL_STRING)) {
					objVisualizationBean.setToDate(objVisualizationBean.getToDate());
				} else {
					objVisualizationBean.setToDate(obDateFormat.format(currCal
							.getTime()));
				}

				if (null != objVisualizationBean.getFromDate()
						&& !objVisualizationBean.getFromDate()
								.equalsIgnoreCase(AppConstants.NULL_STRING)) {
					objVisualizationBean.setFromDate(objVisualizationBean.getFromDate());
				} else {
					currCal.add(Calendar.DATE, -getNumberOfDays());
					objVisualizationBean.setFromDate(obDateFormat
							.format(currCal.getTime()));
				}

				response = visualService
						.getVisualizationDetails(objVisualizationBean);
				
			}
			return response;

		} catch (Exception ex) {
			logger.error("Exception occured in getColumnsAndData method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return response;
	}

	/**
	 * 
	 * @param request
	 * @param urgency
	 *            ,estRepairTime
	 * @param model
	 * @param fleet
	 * @return Map<String, String>
	 * @throws RMDWebException
	 * @Desription:This method is used to validate UserInput for Visualization
	 *                  details
	 */
	public Map<String, String> validateUserInputForVisualization(
			HttpServletRequest request,
			VisualizationDetailsBean objVisualizationBean) {
		final Map<String, String> result = new HashMap<String, String>();
		try {
			List<String> arlComplexOperators = getComplexLogicalOperator();
			if (null == objVisualizationBean.getMpNumbers()
					|| RMDCommonConstants.EMPTY_STRING
							.equalsIgnoreCase(objVisualizationBean.getMpNumbers())) {
				result.put(AppConstants.GRAPH_INVALID, KMConstants.INVALID);
			}
			if (null != objVisualizationBean.getFromDate()
					&& !objVisualizationBean.getFromDate().equalsIgnoreCase(AppConstants.UNDEFINED)
					&& !objVisualizationBean.getFromDate().equalsIgnoreCase(AppConstants.NULL_STRING)
					&& null != objVisualizationBean.getToDate()
					&& !objVisualizationBean.getToDate().equalsIgnoreCase(AppConstants.UNDEFINED)
					&& !objVisualizationBean.getToDate().equalsIgnoreCase(AppConstants.NULL_STRING)) {
				if (AppConstants.EMPTY_STRING.equalsIgnoreCase(objVisualizationBean.getFromDate())) {
					result.put(AppConstants.FROM_DATE_EMPTY,
							KMConstants.INVALID);
				} else if (AppConstants.EMPTY_STRING
						.equalsIgnoreCase(objVisualizationBean.getToDate())) {
					result.put(AppConstants.TO_DATE_EMPTY, KMConstants.INVALID);
				} else {

					SimpleDateFormat format = new SimpleDateFormat(
							AppConstants.DATE_FORMAT);
					Date d1 = null;
					Date d2 = null;
					d1 = format.parse(objVisualizationBean.getFromDate());
					d2 = format.parse(objVisualizationBean.getToDate());
					long diff = d2.getTime() - d1.getTime();
					long diffSeconds = diff / (1000);
					long diffDays = diff / (24 * 60 * 60 * 1000);
					if (diffSeconds <= 0) {
						result.put(AppConstants.FROM_DATE_GREATER,
								KMConstants.INVALID);
					} else if (diffDays > getNumberOfDaysValidation()) {
						result.put(AppConstants.DATE_DIFF_GREATER,
								KMConstants.INVALID);
					}
				}

			}
			
			
			if(objVisualizationBean.getSourceType().equalsIgnoreCase(AppConstants.ENGINERECORDER)){

				if (objVisualizationBean.getSourceTypeCd()
						.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {
					result.put(AppConstants.SOURCE_TYPE_CD_INVALID,
							KMConstants.INVALID);
				}

				if (objVisualizationBean.getControllerType()
						.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)||objVisualizationBean.getControllerType()
						.equalsIgnoreCase(RMDCommonConstants.SELECT)) {
					result.put(AppConstants.CONTROLLER_TYPE_CD_INVALID,
							KMConstants.INVALID);
				}
			
			}
			
			
			

			if (!objVisualizationBean.getAmbientTmpOp()
					.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {

				if (objVisualizationBean.getAmbientTmpVal1()
						.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {
					result.put(AppConstants.AMB_TEMP_VALUE1_INVALID,
							KMConstants.INVALID);
				}else if(!RMDCommonUtility.isNumericWithNegative(objVisualizationBean.getAmbientTmpVal1())){
					
					result.put(AppConstants.AMB_TEMP_VALUE1_INVALID_NON_INTEGER,
							KMConstants.INVALID);
					
				}

				if (arlComplexOperators.contains(objVisualizationBean
						.getAmbientTmpOp())
						&& objVisualizationBean.getAmbientTmpVal2()
								.equalsIgnoreCase(
										RMDCommonConstants.EMPTY_STRING)) {
					result.put(AppConstants.AMB_TEMP_VALUE2_INVALID,
							KMConstants.INVALID);
				}else if(arlComplexOperators.contains(objVisualizationBean
						.getAmbientTmpOp())&&!RMDCommonUtility.isNumericWithNegative(objVisualizationBean.getAmbientTmpVal2())){
					
					result.put(AppConstants.AMB_TEMP_VALUE2_INVALID_NON_INTEGER,
							KMConstants.INVALID);
					
				}

			}

			if (!objVisualizationBean.getEngGHPOp().equalsIgnoreCase(
					RMDCommonConstants.EMPTY_STRING)) {

				if (objVisualizationBean.getEngGHPVal1().equalsIgnoreCase(
						RMDCommonConstants.EMPTY_STRING)) {
					result.put(AppConstants.ENG_GHP_VALUE1_INVALID,
							KMConstants.INVALID);
				}else if(!RMDCommonUtility.isNumericWithNegative(objVisualizationBean.getEngGHPVal1())){
					
					result.put(AppConstants.ENG_GHP_VALUE1_INVALID_NON_INTEGER,
							KMConstants.INVALID);
					
				}

				if (arlComplexOperators.contains(objVisualizationBean
						.getEngGHPOp())
						&& objVisualizationBean.getEngGHPVal2()
								.equalsIgnoreCase(
										RMDCommonConstants.EMPTY_STRING)) {
					result.put(AppConstants.ENG_GHP_VALUE2_INVALID,
							KMConstants.INVALID);
				}else if(arlComplexOperators.contains(objVisualizationBean
						.getEngGHPOp())&&!RMDCommonUtility.isNumericWithNegative(objVisualizationBean.getEngGHPVal2())){
					
					result.put(AppConstants.ENG_GHP_VALUE2_INVALID_NON_INTEGER,
							KMConstants.INVALID);
					
				}

			}

			if (!objVisualizationBean.getEngSpeedOp()
					.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {

				if (objVisualizationBean.getEngSpeedVal1()
						.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {
					result.put(AppConstants.ENG_SPEED_VALUE1_INVALID,
							KMConstants.INVALID);
				}else if(!RMDCommonUtility.isNumericWithNegative(objVisualizationBean.getEngSpeedVal1())){
					
					result.put(AppConstants.ENG_SPEED_VALUE1_INVALID_NON_INTEGER,
							KMConstants.INVALID);
					
				}

				if (arlComplexOperators.contains(objVisualizationBean
						.getEngSpeedOp())
						&& objVisualizationBean.getEngSpeedVal2()
								.equalsIgnoreCase(
										RMDCommonConstants.EMPTY_STRING)) {
					result.put(AppConstants.ENG_SPEED_VALUE2_INVALID,
							KMConstants.INVALID);
				}else if(arlComplexOperators.contains(objVisualizationBean
						.getEngSpeedOp())&&!RMDCommonUtility.isNumericWithNegative(objVisualizationBean.getEngSpeedVal2())){
					
					result.put(AppConstants.ENG_SPEED_VALUE2_INVALID_NON_INTEGER,
							KMConstants.INVALID);
					
				}

			}
			
			
			
			if (!objVisualizationBean.getOilInletOp()
					.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {

				if (objVisualizationBean.getOilInletVal1()
						.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {
					result.put(AppConstants.OIL_INLET_VALUE1_INVALID,
							KMConstants.INVALID);
				}else if(!RMDCommonUtility.isNumericWithNegative(objVisualizationBean.getOilInletVal1())){
					
					result.put(AppConstants.OIL_INLET_VALUE1_INVALID_NON_INTEGER,
							KMConstants.INVALID);
					
				}

				if (arlComplexOperators.contains(objVisualizationBean
						.getOilInletOp())
						&& objVisualizationBean.getOilInletVal2()
								.equalsIgnoreCase(
										RMDCommonConstants.EMPTY_STRING)) {
					result.put(AppConstants.OIL_INLET_VALUE2_INVALID,
							KMConstants.INVALID);
				}else if(arlComplexOperators.contains(objVisualizationBean
						.getOilInletOp())&&!RMDCommonUtility.isNumericWithNegative(objVisualizationBean.getOilInletVal2())){
					
					result.put(AppConstants.OIL_INLET_VALUE2_INVALID_NON_INTEGER,
							KMConstants.INVALID);
					
				}

			}
			
			
			if (!objVisualizationBean.getHpAvailableOp()
					.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {

				if (objVisualizationBean.getHpAvailableVal1()
						.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {
					result.put(AppConstants.HP_AVAILABLE_VALUE1_INVALID,
							KMConstants.INVALID);
				}else if(!RMDCommonUtility.isNumericWithNegative(objVisualizationBean.getHpAvailableVal1())){
					
					result.put(AppConstants.HP_AVAILABLE_VALUE1_INVALID_NON_INTEGER,
							KMConstants.INVALID);
					
				}

				if (arlComplexOperators.contains(objVisualizationBean
						.getHpAvailableOp())
						&& objVisualizationBean.getHpAvailableVal2()
								.equalsIgnoreCase(
										RMDCommonConstants.EMPTY_STRING)) {
					result.put(AppConstants.HP_AVAILABLE_VALUE2_INVALID,
							KMConstants.INVALID);
				}else if(arlComplexOperators.contains(objVisualizationBean
						.getHpAvailableOp())&&!RMDCommonUtility.isNumericWithNegative(objVisualizationBean.getHpAvailableVal2())){
					
					result.put(AppConstants.HP_AVAILABLE_VALUE2_INVALID_NON_INTEGER,
							KMConstants.INVALID);
					
				}

			}
			
			
			if (!objVisualizationBean.getBarometricPressOp()
					.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {

				if (objVisualizationBean.getBarometricPressVal1()
						.equalsIgnoreCase(RMDCommonConstants.EMPTY_STRING)) {
					result.put(AppConstants.BAROMETRIC_VALUE1_INVALID,
							KMConstants.INVALID);
				}else if(!RMDCommonUtility.isNumericWithNegative(objVisualizationBean.getBarometricPressVal1())){
					
					result.put(AppConstants.BAROMETRIC_VALUE1_INVALID_NON_INTEGER,
							KMConstants.INVALID);
					
				}

				if (arlComplexOperators.contains(objVisualizationBean
						.getBarometricPressOp())
						&& objVisualizationBean.getBarometricPressVal2()
								.equalsIgnoreCase(
										RMDCommonConstants.EMPTY_STRING)) {
					result.put(AppConstants.BAROMETRIC_VALUE2_INVALID,
							KMConstants.INVALID);
				}else if(arlComplexOperators.contains(objVisualizationBean
						.getBarometricPressOp())&&!RMDCommonUtility.isNumericWithNegative(objVisualizationBean.getBarometricPressVal2())){
					
					result.put(AppConstants.BAROMETRIC_VALUE2_INVALID_NON_INTEGER,
							KMConstants.INVALID);
					
				}

			}
			

		} catch (Exception exception) {
			logger.error(exception.getMessage());
		}

		return result;

	}

	/**
	 * @Author:
	 * @param request
	 * @return java.util.Map<String, String>
	 * @throws Exception
	 * @Description:This method is used for fetching the Mp Parm numbers
	 *                   
	 * 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_VISUALIZATION_MPPARMNUM, method = RequestMethod.GET)
	public @ResponseBody
	java.util.Map<String, String> getMPParmNumbers(
			final HttpServletRequest request) throws Exception {
		Map<String, String> parmNumbers = new LinkedHashMap<String, String>();
		try {
			Map<String, Map<String, String>> parmdetails = new LinkedHashMap<String, Map<String, String>>();

			String controllerCfg = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.CONTROLLER_CONFIG));
			final String source = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.DATASOURCE));
			final String sourceType = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.VISUALIZATION_SOURCE_TYPE));
			final String controllerType = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.CONTROLLER_TYPE));
			if ((AppConstants.CCA.equalsIgnoreCase(controllerType) || AppConstants.ECU
					.equalsIgnoreCase(controllerType))
					&& AppConstants.ENGINERECORDER.equalsIgnoreCase(sourceType)) {
				controllerCfg = controllerType;

			}

			else if (AppConstants.ENGINERECORDER.equalsIgnoreCase(sourceType)) {
				controllerCfg = visualService
						.getVisualizationDefaultValues(controllerCfg
								+ RMDCommonConstants.UNDERSCORE
								+ AppConstants.ENGINE_RECORDER);
			}

			parmdetails = visualService.getVisualizationParmNumbers(source,
					sourceType, controllerCfg);
			parmNumbers = parmdetails.get(controllerCfg);

		} catch (Exception ex) {
			logger.error("Exception occured in getColumnsAndData method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return parmNumbers;
	}
	
	
	/**
	 * @Author:
	 * @param request
	 * @return java.util.Map<String, String>
	 * @throws Exception
	 * @Description:This method is used for fetching the event records for visualization screen
	 *                   
	 * 
	 * 
	 */
	
	@RequestMapping(value = AppConstants.REQ_URI_VISUALIZATION_EVENT_DATA, method = {
			RequestMethod.GET, RequestMethod.POST })
	public @ResponseBody
	VisualizationEventDataResponseVO getAssetVisualizationEventData(
			final HttpServletRequest request,
			@RequestParam("parameterString") String parameterString)
			throws Exception {
		final VisualizationEventDataResponseVO response = new VisualizationEventDataResponseVO();
		final ObjectMapper mapper = new ObjectMapper();
		try {
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			final VisualizationDetailsBean objVisualizationBean = mapper
					.readValue(parameterString, VisualizationDetailsBean.class);

			final Map<String, String> result = validateUserInputForVisualization(
					request, objVisualizationBean);
			if (!result.isEmpty() && null != result) {
				response.setErrorMsgs(result);
			} else {

				VisualizationEventDataVO objVisualizationEventDataVO = new VisualizationEventDataVO();

				Calendar currCal = Calendar.getInstance();
				SimpleDateFormat obDateFormat = new SimpleDateFormat(
						AppConstants.DATE_FORMAT_24HRS);

				if (null != objVisualizationBean.getToDate()
						&& !objVisualizationBean.getToDate().equalsIgnoreCase(
								AppConstants.NULL_STRING)) {
					objVisualizationEventDataVO.setToDate(objVisualizationBean
							.getToDate());
				} else {
					objVisualizationEventDataVO.setToDate(obDateFormat
							.format(currCal.getTime()));
				}

				if (null != objVisualizationBean.getFromDate()
						&& !objVisualizationBean.getFromDate()
								.equalsIgnoreCase(AppConstants.NULL_STRING)) {
					objVisualizationEventDataVO
							.setFromDate(objVisualizationBean.getFromDate());
				} else {
					currCal.add(Calendar.DATE, -getNumberOfDays());
					objVisualizationEventDataVO.setFromDate(obDateFormat
							.format(currCal.getTime()));
				}

				objVisualizationEventDataVO
						.setAssetGroupName(objVisualizationBean
								.getAssetGroupName());
				objVisualizationEventDataVO.setAssetNumber(objVisualizationBean
						.getAssetNumber());
				objVisualizationEventDataVO
						.setControllerCfg(objVisualizationBean
								.getControllerCfg());
				objVisualizationEventDataVO.setCustomerId(objVisualizationBean
						.getCustomerId());
				objVisualizationEventDataVO.setNoOfDays(objVisualizationBean.getNoOfDays());
				final List<VisualizationEventDataVO> arlVisualizationEventDataVO = visualService
						.getAssetVisualizationEventData(objVisualizationEventDataVO);
				response.setArlVisualizationEventDataVO(arlVisualizationEventDataVO);

			}

		} catch (Exception ex) {
			logger.error("Exception occured in getColumnsAndData method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return response;
	}
	
	/**
	 * @Author:
	 * @param request
	 * @return java.util.Map<String, String>
	 * @throws Exception
	 * @Description:This method is used for fetching the virtual parameters
	 *                   
	 * 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_VISUALIZATION_VIRTUAL_PARM_NUM, method = RequestMethod.GET)
	public @ResponseBody
	java.util.Map<String, String> getVizVirtualParameters(
			final HttpServletRequest request) throws Exception {
		Map<String, String> virtualParmNumbers = new LinkedHashMap<String, String>();
		try {
			Map<String, Map<String, String>> virtualParmdetails = new LinkedHashMap<String, Map<String, String>>();
			//final String family = request.getParameter(AppConstants.FAMILY);
			final String family = EsapiUtil.stripXSSCharacters((String)request.getParameter(AppConstants.FAMILY));
			//final String database = request.getParameter(AppConstants.DATASOURCE);
			final String database = EsapiUtil.stripXSSCharacters((String)request.getParameter(AppConstants.DATASOURCE));
			//final String sourceType = request.getParameter(AppConstants.VISUALIZATION_SOURCE_TYPE);
			final String sourceType = EsapiUtil.stripXSSCharacters((String)request.getParameter(AppConstants.VISUALIZATION_SOURCE_TYPE));
			if (null != sourceType
					&& sourceType.equalsIgnoreCase(AppConstants.SNAPSHOT)) {
				virtualParmdetails = visualService.getVizVirtualParameters(
						family, database);

			}
			virtualParmNumbers = virtualParmdetails.get(family);
		} catch (Exception ex) {
			logger.error("Exception occured in getColumnsAndData method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return virtualParmNumbers;
	}
	
	
	
	/**
	 * 
	 * @param customerId
	 * @param assetGroup
	 * @param assetNumber
	 * @param request
	 * @param model
	 * @return
	 * @Description This method will return the list of asset numbers for given
	 *              keys like customerId, fleetId
	 */
	@RequestMapping(value = AppConstants.REQ_URI_VIZ_GET_ASSETS, method = RequestMethod.GET)
	public @ResponseBody
	java.util.Map<String,String> getAssetNumbers(
			@RequestParam(value = AppConstants.CUSTOMER_ID, required = true) final String customerId,
			@RequestParam(value = AppConstants.FLEET_ID, required = true) final String fleetId,			
			final HttpServletRequest request, final Model model) throws RMDWebException {
		
		Map<String, String> assetNumbers = new LinkedHashMap<String, String>();
		AssetBean assetBean;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
		.getAttribute(AppConstants.ATTR_USER_OBJECT);
		try {
			assetBean = new AssetBean();
			assetBean.setUserFirstName(userVO.getStrFirstName());
			assetBean.setUserLastName(userVO.getStrLastName());
			assetBean.setUserId(userVO.getUserId());
			assetBean.setUserLanguage(userVO.getStrUserLanguage());
			assetBean.setFleetId(EsapiUtil.stripXSSCharacters(fleetId));
			assetBean.setCustomerId(EsapiUtil.stripXSSCharacters(customerId));
			
			assetNumbers = visualService.getAssets(assetBean);

		} catch (Exception ex) {
			logger.error("Exception occured in getAssetNumbers method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return assetNumbers;

	}
	
	
	/**
	 * 
	 * @param model
	 * @return :Merge screen for RX .
	 */
	@RequestMapping(value =AppConstants.RX_VISUALIZATION_WIN, 
			        method = RequestMethod.GET)
	public ModelAndView getRxVisualizationWin(final Model model,
			
			@RequestParam(value = "solutionId", required = true) final String solutionId,			
			@RequestParam(value = AppConstants.CUSTOMERID,    required = false) final String customerID,
			@RequestParam(value = AppConstants.ROAD_NUMBER,    required = false) final String roadNo,
			@RequestParam(value = AppConstants.ROAD_INITIAL,    required = false) final String roadInitial,
			@RequestParam(value = AppConstants.CASE_ID,    required = false) final String caseId
			) {
		
		model.addAttribute("solutionId",solutionId);		
		model.addAttribute(AppConstants.CUSTOMERID,customerID);
		model.addAttribute(AppConstants.ROAD_NUMBER,roadNo);
		model.addAttribute(AppConstants.ROAD_INITIAL,roadInitial);
		model.addAttribute(AppConstants.CASE_ID,caseId);
		return new ModelAndView(AppConstants.RX_VISUALIZATION_SCREEN_WIN);
	}
	
	/**
	 * @Author:
	 * @param request
	 * @return java.util.Map<String, String>
	 * @throws Exception
	 * @Description:This method is used for fetching the records for
	 *                   visualization screen high chart
	 * 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_RX_VISUALIZATION_DATA, method = {RequestMethod.GET,RequestMethod.POST})
	public @ResponseBody
	VisualizationDataResponseVO getRxVizPlotData(
			final HttpServletRequest request,@RequestParam(value = "solutionId", required = true) final String solutionId,			
			@RequestParam(value = AppConstants.CUSTOMERID,    required = false) final String customerID,
			@RequestParam(value = AppConstants.ROAD_NUMBER,    required = false) final String roadNo,
			@RequestParam(value = AppConstants.ROAD_INITIAL,    required = false) final String roadInitial) throws Exception {
		VisualizationDataResponseVO response = new VisualizationDataResponseVO();
		try {
			
			VisualizationDetailsBean objVisualizationBean = new VisualizationDetailsBean();
			objVisualizationBean.setCustomerId(customerID);
			objVisualizationBean.setAssetNumber(roadNo);
			objVisualizationBean.setAssetGroupName(roadInitial);
			objVisualizationBean.setRxObjid(solutionId);
			Calendar currCal = Calendar.getInstance();
			SimpleDateFormat obDateFormat = new SimpleDateFormat(
					AppConstants.DATE_FORMAT_24HRS);
				objVisualizationBean.setToDate(obDateFormat.format(currCal
						.getTime()));
				currCal.add(Calendar.DATE, -30);
				objVisualizationBean.setFromDate(obDateFormat
						.format(currCal.getTime()));
			response = visualService
						.getRxVizPlotData(objVisualizationBean);
			

		} catch (Exception ex) {
			logger.error("Exception occured in getColumnsAndData method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return response;
	}
	
	
	/**
	 * @Author:
	 * @param request
	 * @return java.util.Map<String, String>
	 * @throws Exception
	 * @Description:This method is used for fetching the records for
	 *                   visualization screen high chart
	 * 
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_RX_VISUALIZATION_PLOT_INFO, method = {RequestMethod.GET,RequestMethod.POST})
	public @ResponseBody
	RxVisualizationPlotInfoVO getRxVizPlotInformations(
			final HttpServletRequest request,@RequestParam(value = "solutionId", required = true) final String solutionId			
			) throws Exception {
		RxVisualizationPlotInfoVO response = null;
		try {
			response = visualService
						.getRxVizPlotInfo(solutionId);
		} catch (Exception ex) {
			logger.error("Exception occured in getColumnsAndData method ", ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return response;
	}
	
}
