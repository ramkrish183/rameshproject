/**
 * ============================================================

 * Classification		: GE Confidential
 * File 				: VerifyCfgTempaltesVO.java
 * Description 			:
 * Package 				: com.ge.trans.rmd.cm.valueobjects;
 * Author 				: Capgemini India.
 * Last Edited By 		:
 * Version 				: 1.0
 * Created on 			:
 * History				:
 * Modified By 			: Initial Release
 *
 * Copyright (C) 2009 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.valueobjects;
/*******************************************************************************
 * 
 * @Author 			:
 * @Version 		: 1.0
 * @Date Created	:
 * @Date Modified 	:
 * @Modified By 	:
 * @Contact 		:
 * @Description 	:This is plain POJO class which contains queueId,queueName
 *             		 Declarations along with their respective getters and setters.
 * @History 		:
 * 
 ******************************************************************************/
public class VerifyCfgTemplateVO {

	
	private String objid;
	private String template;
	private String version;
	private String  title;
	private String  cfgType;
	private String customer;
	private String configFile;
	private String status;
	private String device;
	private String faultCode;
	private String fileName;
	private String fileContent;
	
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getConfigFile() {
		return configFile;
	}
	public void setConfigFile(String configFile) {
		this.configFile = configFile;
	}
	public String getObjid() {
		return objid;
	}
	public void setObjid(String objid) {
		this.objid = objid;
	}
	public String getTemplate() {
		return template;
	}
	public void setTemplate(String template) {
		this.template = template;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCfgType() {
		return cfgType;
	}
	public void setCfgType(String cfgType) {
		this.cfgType = cfgType;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
    public String getDevice() {
        return device;
    }
    public void setDevice(String device) {
        this.device = device;
    }
    public String getFaultCode() {
        return faultCode;
    }
    public void setFaultCode(String faultCode) {
        this.faultCode = faultCode;
    }
    public String getFileName() {
        return fileName;
    }
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }
    public String getFileContent() {
        return fileContent;
    }
    public void setFileContent(String fileContent) {
        this.fileContent = fileContent;
    }
    
    
	

}
