package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.AssetOverviewService;
import com.ge.trans.rmd.cm.service.ManageLDVRRequestsService;
import com.ge.trans.rmd.cm.valueobjects.LDVRMasterDataRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRMasterDataResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRSaveTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRSaveTemplateResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRTemplateRequestTimeVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRTemplateResponseVO;
import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.GenericAjaxException;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class ManageLDVRRequestController extends RMDBaseController {
	private final  RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private ApplicationContext appContext;
	@Autowired
	private LDVRRequestController ldvrRequestController;
	@Autowired
	private ManageLDVRRequestsService manageLDVRRequestsService;
	
	@Autowired
	private AssetOverviewService asstOvwService;	

	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description:
	 * 
	 */
@RequestMapping(value = AppConstants.REQ_URI_GET_MANAGE_LDVR_REQUEST, method = RequestMethod.GET)
	public ModelAndView getManageLDVRRequestPage(
			final HttpServletRequest request) throws RMDWebException {
		rmdWebLogger.info("Inside getManageLDVRRequestPage method");
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		
		final SimpleDateFormat dateFormat = new SimpleDateFormat(RMDCommonConstants.ddMMyyyyHHmmss);
		
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);

		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());

		

		dateFormat.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
		Calendar fromDtCal = Calendar.getInstance();
		fromDtCal.add(Calendar.MINUTE, -40);
		String fromDate = dateFormat.format(fromDtCal.getTime());
		rmdWebLogger.info("fromDate in getLDVRRequestPage " + fromDate);

		String toDate = dateFormat.format(new Date());
		rmdWebLogger.info("toDate in getLDVRRequestPage " + toDate);

		request.setAttribute(AppConstants.FROM_DATE, fromDate);
		request.setAttribute(AppConstants.TO_DATE, toDate);
		return new ModelAndView(AppConstants.VIEW_MANAGE_LDVR_REQUEST);
	}


	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_TEMPLATE_LIST, method = RequestMethod.POST)
	@ResponseBody public  List<LDVRTemplateResponseVO> getLDVRTemplateList(
			final HttpServletRequest request) throws RMDWebException {
		rmdWebLogger.info("Inside  getLDVRTemplateList Method");
		List<LDVRTemplateResponseVO> lstLDVRTemplateResponseVO = null;
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
		
		String applicationTimezone = RMDCommonUtil.getTimezone(
				defaultTimezone, userVO.getTimeZone());
		
		final String assetOwnerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_CUSID));

		final String templateNumber = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.LDVR_TEMPLATE_NUMBER));

		final String templateVersion = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.LDVR_TEMPLATE_VERSION));

		final String templateDescription = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.LDVR_TEMPLATE_DESCRIPTION));

		final String templateStatus = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.LDVR_TEMPLATE_STATUS));
		
		final String customerName = EsapiUtil.stripXSSCharacters( request
				.getParameter(AppConstants.CUSTOMER_NAME));
		
		final String assetNumber = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String groupName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.WS_PARAM_ASSTGRP));
		try {
			LDVRTemplateRequestVO ldvrTemplateRequestVO = new LDVRTemplateRequestVO();
			ldvrTemplateRequestVO.setTemplateDescription(templateDescription);
			ldvrTemplateRequestVO.setTemplateNumber(templateNumber);
			ldvrTemplateRequestVO.setTemplateVersion(templateVersion);
			ldvrTemplateRequestVO.setTemplateStatus(templateStatus);
			List<String> customerIdLst = new ArrayList<String>();
			customerIdLst.add(assetOwnerId);
			ldvrTemplateRequestVO.setCustomerId(customerIdLst);
			ldvrTemplateRequestVO.setDevice(AppConstants.LCV_DEVICE_TYPE);
			ldvrTemplateRequestVO.setMessageId(ldvrRequestController
					.getLDVRMessageID(AppConstants.LDVR_TEMPLATE_REQUEST_TYPE));
			ldvrTemplateRequestVO.setTimeZone(applicationTimezone);
			if(!RMDCommonUtility.isNullOrEmpty(customerName))
				ldvrTemplateRequestVO.setCustomerName(customerName);
			else{
				AssetOverviewBean assetOverviewBean = new AssetOverviewBean();
				assetOverviewBean.setAsset(assetNumber);
				assetOverviewBean.setAssetGroup(groupName);
				assetOverviewBean.setCustomer(assetOwnerId);	
				assetOverviewBean = asstOvwService.getAssets(assetOverviewBean);
				ldvrTemplateRequestVO.setCustomerName(assetOverviewBean.getCustomer());
			}
			lstLDVRTemplateResponseVO = manageLDVRRequestsService
					.getLDVRTemplateList(ldvrTemplateRequestVO);

		} catch (RMDWebException ex) {
			rmdWebLogger.error(
					"RMDWebException occured in getLDVRTemplateList  method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getLDVRTemplateList  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lstLDVRTemplateResponseVO;

	}

	/**
	 * getMasterData Method
	 * 
	 * @param request
	 * @return
	 * @throws RMDWebException
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_MASTER_DATA, method = RequestMethod.POST)
	@ResponseBody public  LDVRMasterDataResponseVO getMasterData(
			final HttpServletRequest request) throws RMDWebException {
		rmdWebLogger.info("Inside  getMasterData Method");
		LDVRMasterDataResponseVO lstLDVRMasterDataResponseVO = null;
		List<String> masterDataSet = new ArrayList<String>(Arrays.asList(
				"LDVR_PRESERVATION_DELETION_POLICY",
				"LDVR_PRESERVATION_OFFLOAD_PRIORITY", "LCV_MP_PARAMETERS",
				"LCV_MP_CONDITIONS", "LCV_MP_PARAMETER_VALIDATION","MESSAGE_DIRECTION",
				"MESSAGE_DELIVERY_STATUSES"));

		try {
			LDVRMasterDataRequestVO ldvrMasterDataRequestVO = new LDVRMasterDataRequestVO();

			ldvrMasterDataRequestVO.setMasterDataSet(masterDataSet);

			lstLDVRMasterDataResponseVO = manageLDVRRequestsService
					.getMasterData(ldvrMasterDataRequestVO);
			rmdWebLogger.info(" getMasterData Input is : "
					+ ldvrMasterDataRequestVO.toString());
			rmdWebLogger.info(" getMasterData  Input is : "
					+ lstLDVRMasterDataResponseVO.getDataSet().toString());

		} catch (RMDWebException ex) {
			rmdWebLogger.error(
					"RMDWebException occured in getMasterData  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getMasterData  method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return lstLDVRMasterDataResponseVO;

	}

	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_SAVE_UPDATE_TEMPLATE, method = RequestMethod.POST)
	@ResponseBody public  LDVRSaveTemplateResponseVO saveUpdateLDVRTemplate(
			@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString,
			final HttpServletRequest request) throws RMDWebException {
		Date date = null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(
				"yyyy-MM-dd HH:mm:ss");
		final SimpleDateFormat dateFormatReqTime = new SimpleDateFormat(
				"MM-dd-yyyy hh:mm a");
		final SimpleDateFormat dateFormat = new SimpleDateFormat(
				RMDCommonConstants.ddMMyyyyHHmmss);
		final ObjectMapper mapper = new ObjectMapper();

		LDVRSaveTemplateResponseVO respVo = null;
		try {
			rmdWebLogger
					.info("Inside saveUpdateLDVRTemplate method input from js "
							+ parameterString);
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			
			final String defaultTimezone = (String) request
					.getAttribute(AppConstants.DEFAULT_TIMEZONE);
					
			String applicationTimezone = RMDCommonUtil.getTimezone(
					defaultTimezone, userVO.getTimeZone());
			
			if (!RMDCommonUtility.isNullOrEmpty(parameterString)) {
				mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);

				Calendar cal = Calendar.getInstance();

				LDVRSaveTemplateRequestVO objTemplateReqVO = mapper.readValue(
						parameterString, LDVRSaveTemplateRequestVO.class);

				objTemplateReqVO.setApplicationId(RMDCommonConstants.LDVR_MCS_APPLICATION_ID);			
				objTemplateReqVO.setMessageId(ldvrRequestController
						.getLDVRMessageID(AppConstants.LDVR_TEMPLATE_REQUEST_TYPE));
				
				date = cal.getTime();
				if (objTemplateReqVO.getTemplateObjid() == null) {
					objTemplateReqVO.setCreatedDate(simpleDateFormat
							.format(date));
					objTemplateReqVO.setLastUpdatedDate(simpleDateFormat
							.format(date));
				} else {
					if (RMDCommonUtility.isNullOrEmpty(objTemplateReqVO
							.getCreatedDate())) {
						objTemplateReqVO.setCreatedDate(simpleDateFormat
								.format(date));
					} else {
						objTemplateReqVO.setCreatedDate(objTemplateReqVO
								.getCreatedDate());
					}
					objTemplateReqVO.setLastUpdatedDate(simpleDateFormat
							.format(date));
				}
				if (objTemplateReqVO.getTemplateDetails().getTimeframe() == null
						|| RMDCommonUtility.isNullOrEmpty(objTemplateReqVO
								.getTemplateDetails().getTimeframe()
								.getRequestedStartTime())) {
					objTemplateReqVO.getTemplateDetails().setTimeframe(null);

				} else {
					String requestStartTime = formatDate(objTemplateReqVO
							.getTemplateDetails().getTimeframe()
							.getRequestedStartTime(), dateFormat,
							dateFormatReqTime,applicationTimezone);
					objTemplateReqVO.getTemplateDetails().getTimeframe()
							.setRequestedStartTime(requestStartTime);
				}

				if (objTemplateReqVO.getTemplateDetails().getGeoZone() == null
						|| objTemplateReqVO.getTemplateDetails().getGeoZone()
								.getGeoZoneIds().size() == 0) {
					objTemplateReqVO.getTemplateDetails().setGeoZone(null);
				}
				if (objTemplateReqVO.getTemplateDetails().getEvent() == null
						|| objTemplateReqVO.getTemplateDetails().getEvent()
								.getMps().size() == 0) {
					objTemplateReqVO.getTemplateDetails().setEvent(null);
				}
				String requestEndTime = formatDate(objTemplateReqVO
						.getTemplateDetails().getRequestedEndTime(),
						dateFormat, dateFormatReqTime,applicationTimezone);
				
				objTemplateReqVO.getTemplateDetails().setRequestedEndTime(
						requestEndTime);
				objTemplateReqVO.setUserName(userVO.getUserId());
				
				rmdWebLogger
						.info("Inside saveUpdateLDVRTemplate method LDVRSaveTemplateRequesVO class "
								+ objTemplateReqVO.toString());
				respVo = manageLDVRRequestsService
						.saveUpdateLDVRTemplate(objTemplateReqVO,applicationTimezone,userVO.getUserId());
			}

		} catch (RMDWebException ex) {
			rmdWebLogger
					.error("RMDWebException occured in saveUpdateLDVRTemplate  method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in saveUpdateLDVRTemplate  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return respVo;
	}

	public String formatDate(String date, SimpleDateFormat dateFromFormat,
			SimpleDateFormat dateFormatTo,String timeZone) throws RMDWebException {
		String formattedDate = null;
		try {
			dateFromFormat.setTimeZone(TimeZone.getTimeZone(timeZone));
			dateFormatTo.setTimeZone(TimeZone.getTimeZone("US/Eastern"));
			formattedDate = dateFormatTo.format(dateFromFormat.parse(date));
		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getLDVRTime() method - ManageLDVRRequestController",
							ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return formattedDate;
	}

	/**
	 * @param request
	 * @return Map<String,String>
	 * @throws RMDWebException
	 * @Description Function to get user preferred timezone date.
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_TIME, method = RequestMethod.GET)
	@ResponseBody public  LDVRTemplateRequestTimeVO getLDVRTime(
			final HttpServletRequest request) throws RMDWebException {
		LDVRTemplateRequestTimeVO reqTimeVO = null;
		try {

			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			final SimpleDateFormat dateFormat = new SimpleDateFormat(
					RMDCommonConstants.ddMMyyyyHHmmss);
			final String defaultTimezone = (String) request
					.getAttribute(AppConstants.DEFAULT_TIMEZONE);
			String applicationTimezone = RMDCommonUtil.getTimezone(
					defaultTimezone, userVO.getTimeZone());
			dateFormat.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
			reqTimeVO = new LDVRTemplateRequestTimeVO();
			reqTimeVO.setRequestEndTime(dateFormat.format(new Date()));
			Calendar fromDtCal = Calendar.getInstance();
			fromDtCal.add(Calendar.MINUTE, -40);
			reqTimeVO
					.setRequestStartTime(dateFormat.format(fromDtCal.getTime()));

		} catch (Exception ex) {
			rmdWebLogger
					.error("RMDWebException occured in getLDVRTime() method - ManageLDVRRequestController",
							ex);
			RMDWebErrorHandler.handleException(ex);

		}
		return reqTimeVO;
	}
	
	@RequestMapping(AppConstants.EXPORT_MANAGE_LDVR_REQUESTS)
	@ResponseBody public  void exportManageLDVRRequests(
			final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws RMDWebException, Exception {
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;		
		try {
			 List<LDVRTemplateResponseVO>   ldvrTemplateResponseVO = getLDVRTemplateList(request);
			csvContent = convertToCSVManageLDVR(
					ldvrTemplateResponseVO,
					locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.MANAGE_LDVR_REQUESTS_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);
			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);
			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error(
					"Exception occured in exportManageLDVRRequests method ", rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in exportManageLDVR method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}
	
	/**
	 * @Description:This method is used to export manage ldvr template list to CSV
	 * @return: String
	 * @param:List<LDVRTemplateResponseVO> templateList, Locale locale
	 * @throws RMDWebException 
	 * @throws GenericAjaxException 
	 */
	private String convertToCSVManageLDVR(
			List<LDVRTemplateResponseVO> ldvrTemplateResponseVO,
			Locale locale) throws RMDWebException {
		String csvContent = null;
		StringBuilder strBuilderAssetHeader = new StringBuilder();
		try {
			strBuilderAssetHeader.append(appContext.getMessage(
					AppConstants.MANAGE_LDVR_REQUESTS_HEADER, null, locale));

			strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);
			
			if (ldvrTemplateResponseVO != null){

			for (LDVRTemplateResponseVO ldvrTempltVO : ldvrTemplateResponseVO) {
				
				
			
				if (ldvrTempltVO.getTemplateCategoryName() != null) {
					strBuilderAssetHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE + ldvrTempltVO.getTemplateCategoryName()
							+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (ldvrTempltVO.getTemplateNumber() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ldvrTempltVO.getTemplateNumber()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				
				if (ldvrTempltVO.getTemplateVersion() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ldvrTempltVO.getTemplateVersion()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				
				if (ldvrTempltVO.getDescription()!= null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ ldvrTempltVO.getDescription()
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (ldvrTempltVO.getLastUpdatedBy() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ ldvrTempltVO.getLastUpdatedBy()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (ldvrTempltVO.getLastUpdatedDate() != null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ ldvrTempltVO.getLastUpdatedDate()
									+ AppConstants.QUOTE);
				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				if (ldvrTempltVO.getTemplateStatus()!= null) {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ ldvrTempltVO.getTemplateStatus()
									+ AppConstants.QUOTE);

				} else {
					strBuilderAssetHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}
				
				strBuilderAssetHeader.append(RMDCommonConstants.NEWLINE);
			}

				
			}
			csvContent = strBuilderAssetHeader.toString();
		} catch (Exception exception) {
			rmdWebLogger.error("Export to CSV Manage LDVR Request List"
					+ exception.getMessage());
			RMDWebErrorHandler.handleException(exception);
		}
		return csvContent;
	}
}
