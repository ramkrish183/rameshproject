/**
 * ============================================================
 * File : AssetLifeStatisticsService.java
 * Description : 
 * 
 * Package :  com.ge.trans.rmd.cm.service
 * Author : iGATE 
 * Last Edited By :
 * Version : 1.0
 * Created on : Nov 21, 2014
 * History
 * Modified By : Initial Release
 * Classification : iGATE Sensitive
 * Copyright (C) 2013 General Electric Company. All rights reserved
 *
 * ============================================================
 */
package com.ge.trans.rmd.cm.service;



import com.ge.trans.rmd.common.beans.AssetOverviewBean;
import com.ge.trans.rmd.common.beans.LifeStatisticsVO;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface AssetLifeStatisticsService {

	/**
	 * @return:ModelAndView
	 * @Description: Displays the life statistics page of the RMD application
	 */
	LifeStatisticsVO getassetLifeStatistics(AssetOverviewBean assetOverviewBean, String userCustomer) throws RMDWebException, Exception;

}
