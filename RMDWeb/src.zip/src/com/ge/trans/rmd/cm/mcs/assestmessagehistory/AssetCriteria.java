
package com.ge.trans.rmd.cm.mcs.assestmessagehistory;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for assetCriteria complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="assetCriteria">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="assetOwnerName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="roadInitial" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="roadNumberFrom" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="roadNumberTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "assetCriteria", propOrder = {
    "assetOwnerName",
    "roadInitial",
    "roadNumberFrom",
    "roadNumberTo",
    "device"
})
public class AssetCriteria {

    protected String assetOwnerName;
    protected String roadInitial;
    protected String roadNumberFrom;
    protected String roadNumberTo;
    protected String device;

    public String getDevice() {
		return device;
	}

	public void setDevice(String device) {
		this.device = device;
	}

	/**
     * Gets the value of the assetOwnerName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAssetOwnerName() {
        return assetOwnerName;
    }

    /**
     * Sets the value of the assetOwnerName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAssetOwnerName(String value) {
        this.assetOwnerName = value;
    }

    /**
     * Gets the value of the roadInitial property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoadInitial() {
        return roadInitial;
    }

    /**
     * Sets the value of the roadInitial property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoadInitial(String value) {
        this.roadInitial = value;
    }

    /**
     * Gets the value of the roadNumberFrom property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoadNumberFrom() {
        return roadNumberFrom;
    }

    /**
     * Sets the value of the roadNumberFrom property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoadNumberFrom(String value) {
        this.roadNumberFrom = value;
    }

    /**
     * Gets the value of the roadNumberTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRoadNumberTo() {
        return roadNumberTo;
    }

    /**
     * Sets the value of the roadNumberTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRoadNumberTo(String value) {
        this.roadNumberTo = value;
    }

}
