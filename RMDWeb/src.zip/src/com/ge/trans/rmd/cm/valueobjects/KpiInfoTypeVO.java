/**
 * ============================================================
 * File 			: KpiInfoTypeVO.java
 * Description 		: Value Object for KPI RxCount Display  
 * Package 			: com.ge.trans.rmd.cm.valueobjects
 * Author 			: UST
 * Last Edited By 	:
 * Version 			: 1.0
 * Created on 		: April 30, 2012
 * History
 * Modified By 		: Initial Release
 * Copyright (C) 2012 General Electric Company. All rights reserved
 * ============================================================
 */

package com.ge.trans.rmd.cm.valueobjects;

public class KpiInfoTypeVO {

	private String parameterName;

	private int parameterCount;
	
	private String percentage;

	
	public String getPercentage() {
		return percentage;
	}

	public void setPercentage(String percentage) {
		this.percentage = percentage;
	}

	public String getParameterName() {
		return parameterName;
	}

	public void setParameterName(String parameterName) {
		this.parameterName = parameterName;
	}

	public int getParameterCount() {
		return parameterCount;
	}

	public void setParameterCount(int parameterCount) {
		this.parameterCount = parameterCount;
	}

}
