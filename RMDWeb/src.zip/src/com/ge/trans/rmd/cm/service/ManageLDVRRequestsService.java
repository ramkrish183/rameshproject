package com.ge.trans.rmd.cm.service;

import java.util.List;

import com.ge.trans.rmd.cm.valueobjects.LDVRMasterDataRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRMasterDataResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRSaveTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRSaveTemplateResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRTemplateResponseVO;
import com.ge.trans.rmd.common.exception.RMDWebException;

public interface ManageLDVRRequestsService {

	public List<LDVRTemplateResponseVO> getLDVRTemplateList(
			LDVRTemplateRequestVO ldvrTemplateRequestVO) throws RMDWebException,Exception;

	public LDVRSaveTemplateResponseVO saveUpdateLDVRTemplate(
			LDVRSaveTemplateRequestVO ldvrTemplateRequestVO,String timeZone,String userId) throws RMDWebException,Exception;
	
	public LDVRMasterDataResponseVO getMasterData(
			LDVRMasterDataRequestVO ldvrMasterDataRequestVO) throws RMDWebException,Exception ;

}
