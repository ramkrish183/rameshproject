package com.ge.trans.rmd.cm.service;

import java.util.List;

import com.ge.trans.rmd.cm.valueobjects.LDVRApplyTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRApplyTemplateResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetStatusRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetStatusResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTempReapplyRemoveRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTempReapplyRemoveResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTempReapplyRemoveStatusVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTemplateResponseVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.cm.valueobjects.AssetsVO;

public interface LDVRAssetStatusService {
	
	public LDVRAssetStatusResponseVO getAssetLdvrStatus(LDVRAssetStatusRequestVO ldvrAssetStatusResquestVO) throws RMDWebException,Exception ;
	public LDVRApplyTemplateResponseVO ldvrAssetGroupApplyTemplate(LDVRApplyTemplateRequestVO ldvrApplyTemplateRequestVO) throws RMDWebException,Exception ;
	public LDVRAssetTemplateResponseVO getAssetTemplateList(LDVRAssetTemplateRequestVO ldvrAssetTemplateRequestVO) throws RMDWebException,Exception ;
	public List<LDVRAssetTempReapplyRemoveStatusVO> ldvrReApplyRemoveAssetTemplate(LDVRAssetTempReapplyRemoveRequestVO ldvrAssetTempReapplyRemoveRequestVO) throws RMDWebException,Exception ;
	public List<AssetsVO> getRoadInitialHDR(String customerId) throws RMDWebException, Exception;
}
