package com.ge.trans.rmd.cm.mvc.model;

/**
 * A simple POJO to represent our user domain  
 *
 */
public class DataGrid {

	private Long id;
	private String firstName;
	private String lastName;
	private int age;
	
	public Long getId() {
		return id;
	}
	public void setId(final Long id) {
		this.id = id;
	}
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(final String firstName) {
		this.firstName = firstName;
	}
	
	public String getLastName() {
		return lastName;
	}
	public void setLastName(final String lastName) {
		this.lastName = lastName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(final int age) {
		this.age = age;
	}

}
