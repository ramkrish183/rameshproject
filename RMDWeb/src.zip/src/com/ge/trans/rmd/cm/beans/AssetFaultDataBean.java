package com.ge.trans.rmd.cm.beans;

import com.ge.trans.rmd.common.beans.RMDBaseBean;

@SuppressWarnings("serial")
public class AssetFaultDataBean extends RMDBaseBean {
	private String assetNumber;
	private String assetTabId;
	private String toDate;
	private String fromDate;
	private String dropdownDays;
	private String dataSet;
	private String dateFormat;
	private String assetGrpName;
	private String selectType;
	private String caseId;
	private String ruleId;
	private String graphParameterValues;
	private String strControllerCfg;
	private boolean isDieselDoctor;
	private String isDateDiffSelected;
	private boolean isLimitedParam = false;
	private String startRow;
	private String sortOption;
	private String allRecords;
	private String caseType;
	private String healthCheck;
	private String ruleType;
	private String initLoad;
	private String notch8;
	private boolean hideL3Faults;
	// Added for timebased filter for datascreen
	private String strCaseFrom = null;
	private boolean isHeatMap;
	private String customerId;
	private String roleName;
	private String userTimeZone;
	private String userTimeZoneCode;
	private boolean enableCustomColumns;
	
	public String getNotch8() {
		return notch8;
	}
	public void setNotch8(String notch8) {
		this.notch8 = notch8;
	}
	public String getInitLoad() {
		return initLoad;
	}
	public void setInitLoad(String initLoad) {
		this.initLoad = initLoad;
	}
	public boolean isHideL3Faults() {
		return hideL3Faults;
	}
	public void setHideL3Faults(boolean hideL3Faults) {
		this.hideL3Faults = hideL3Faults;
	}
	public String getRuleType() {
		return ruleType;
	}
	public void setRuleType(String ruleType) {
		this.ruleType = ruleType;
	}
	public String getHealthCheck() {
		return healthCheck;
	}
	public void setHealthCheck(String healthCheck) {
		this.healthCheck = healthCheck;
	}
	public String getCaseType() {
		return caseType;
	}
	public void setCaseType(String caseType) {
		this.caseType = caseType;
	}
	public String getAllRecords() {
		return allRecords;
	}
	public void setAllRecords(String allRecords) {
		this.allRecords = allRecords;
	}
	public String getSortOption() {
		return sortOption;
	}
	public void setSortOption(String sortOption) {
		this.sortOption = sortOption;
	}
	public String getStartRow() {
		return startRow;
	}
	public void setStartRow(String startRow) {
		this.startRow = startRow;
	}
	public boolean isLimitedParam() {
		return isLimitedParam;
	}
	public void setLimitedParam(boolean isLimitedParam) {
		this.isLimitedParam = isLimitedParam;
	}
	public String getIsDateDiffSelected() {
		return isDateDiffSelected;
	}
	public void setIsDateDiffSelected(String isDateDiffSelected) {
		this.isDateDiffSelected = isDateDiffSelected;
	}
	
	
	public String getStrControllerCfg() {
		return strControllerCfg;
	}
	public void setStrControllerCfg(String strControllerCfg) {
		this.strControllerCfg = strControllerCfg;
	}	
		
		
	public boolean isHeatMap() {
		return isHeatMap;
	}
	public void setHeatMap(boolean isHeatMap) {
		this.isHeatMap = isHeatMap;
	}
	public String getStrCaseFrom() {
		return strCaseFrom;
	}
	public void setStrCaseFrom(String strCaseFrom) {
		this.strCaseFrom = strCaseFrom;
	}
	public boolean isDieselDoctor() {
		return isDieselDoctor;
	}
	
	public void setDieselDoctor(boolean isDieselDoctor) {
		this.isDieselDoctor = isDieselDoctor;
	}
	
	public String getDateFormat() {
		return dateFormat;
	}
	
	public void setDateFormat(String dateFormat) {
		this.dateFormat = dateFormat;
	}
	
	public String getDropdownDays() {
		return dropdownDays;
	}
	
	public void setDropdownDays(String dropdownDays) {
		this.dropdownDays = dropdownDays;
	}
	
	
	public String getDataSet() {
		return dataSet;
	}
	
	public void setDataSet(String dataSet) {
		this.dataSet = dataSet;
	}
	
	public String getAssetGrpName() {
		return assetGrpName;
	}
	
	public void setAssetGrpName(final String assetGrpName) {
		this.assetGrpName = assetGrpName;
	}
	
	public String getCustomerId() {
		return customerId;
	}
	
	public void setCustomerId(final String customerId) {
		this.customerId = customerId;
	}
	
	public String getToDate() {
		return toDate;
	}
	
	public void setToDate(final String toDate) {
		this.toDate = toDate;
	}
	
	public String getFromDate() {
		return fromDate;
	}
	
	public void setFromDate(final String fromDate) {
		this.fromDate = fromDate;
	}
	
	public void setAssetNumber(final String assetNumber) {
		this.assetNumber = assetNumber;
	}
	
	public String getAssetNumber() {
		return assetNumber;
	}
	
	public String getAssetTabId() {
		return assetTabId;
	}
	
	public void setAssetTabId(final String assetTabId) {
		this.assetTabId = assetTabId;
	}
	
	public String getSelectType() {
		return selectType;
	}
	
	public void setSelectType(final String selectType) {
		this.selectType = selectType;
	}
	
	public String getCaseId() {
		return caseId;
	}
	
	public void setCaseId(final String caseId) {
		this.caseId = caseId;
	}
	
	public String getRuleId() {
		return ruleId;
	}
	
	public void setRuleId(final String ruleId) {
		this.ruleId = ruleId;
	}
	public String getGraphParameterValues() {
		return graphParameterValues;
	}
	
	public void setGraphParameterValues(final String graphParameterValues) {
		this.graphParameterValues = graphParameterValues;
	}
	public String getRoleName() {
		return roleName;
	}
	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}
	public String getUserTimeZone() {
		return userTimeZone;
	}
	public void setUserTimeZone(String userTimeZone) {
		this.userTimeZone = userTimeZone;
	}
	public String getUserTimeZoneCode() {
		return userTimeZoneCode;
	}
	public void setUserTimeZoneCode(String userTimeZoneCode) {
		this.userTimeZoneCode = userTimeZoneCode;
	}
	public boolean isEnableCustomColumns() {
		return enableCustomColumns;
	}
	public void setEnableCustomColumns(boolean enableCustomColumns) {
		this.enableCustomColumns = enableCustomColumns;
	}
	
}
