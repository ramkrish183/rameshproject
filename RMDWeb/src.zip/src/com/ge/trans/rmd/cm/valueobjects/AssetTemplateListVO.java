/**
 * 
 */
package com.ge.trans.rmd.cm.valueobjects;

import java.util.List;

/**
 * @author MSHIRAJUDDIN
 *
 */
public class AssetTemplateListVO {
	
private String templateCategory;
private String agtMessage;
	
private List<AssetTemplateVO> templateList ;

	public String getTemplateCategory() {
		return templateCategory;
	}

	public void setTemplateCategory(String templateCategory) {
		this.templateCategory = templateCategory;
	}

	public List<AssetTemplateVO> getTemplates() {
		return templateList;
	}

	public void setTemplates(List<AssetTemplateVO> templateList) {
		this.templateList = templateList;
	}

	/**
	 * @return the agtMessage
	 */
	public String getAgtMessage() {
		return agtMessage;
	}

	/**
	 * @param agtMessage the agtMessage to set
	 */
	public void setAgtMessage(String agtMessage) {
		this.agtMessage = agtMessage;
	}


}
