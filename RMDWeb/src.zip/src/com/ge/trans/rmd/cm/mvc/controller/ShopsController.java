package com.ge.trans.rmd.cm.mvc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;

@Controller
@SessionAttributes
public class ShopsController extends RMDBaseController {
	
	
	@RequestMapping(AppConstants.REQ_URI_SHOPS)
	public ModelAndView showShops(final HttpServletRequest request) {
		request.setAttribute(AppConstants.FILTERFLAG, EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG)));
		return new ModelAndView(AppConstants.VIEW_SHOPS);
	}
}
