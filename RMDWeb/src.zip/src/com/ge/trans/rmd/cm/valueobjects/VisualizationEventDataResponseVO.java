package com.ge.trans.rmd.cm.valueobjects;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.ge.trans.rmd.common.vo.RMDBaseVO;

@SuppressWarnings("serial")
public class VisualizationEventDataResponseVO extends RMDBaseVO{

	private List<VisualizationEventDataVO> arlVisualizationEventDataVO;
	private Map<String,String> errorMsgs;
	
	public Map<String, String> getErrorMsgs() {
		return errorMsgs;
	}
	public void setErrorMsgs(Map<String, String> errorMsgs) {
		this.errorMsgs = errorMsgs;
	}
	public List<VisualizationEventDataVO> getArlVisualizationEventDataVO() {
		return arlVisualizationEventDataVO;
	}
	public void setArlVisualizationEventDataVO(
			List<VisualizationEventDataVO> arlVisualizationEventDataVO) {
		this.arlVisualizationEventDataVO = arlVisualizationEventDataVO;
	}
	
	
	

}
