package com.ge.trans.rmd.cm.valueobjects;

public class KPIRequestVO {
private String kpiName;
private long noOfDays;
public String getKpiName() {
	return kpiName;
}
public void setKpiName(String kpiName) {
	this.kpiName = kpiName;
}
public long getNoOfDays() {
	return noOfDays;
}
public void setNoOfDays(long noOfDays) {
	this.noOfDays = noOfDays;
}


}
