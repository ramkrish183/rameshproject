package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.MapUtils;
import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ge.trans.eoa.services.security.service.valueobjects.UserServiceVO;
import com.ge.trans.rmd.alert.valueobjects.ModelVO;
import com.ge.trans.rmd.cm.service.RxChangeService;
import com.ge.trans.rmd.cm.valueobjects.RecommDeliverVO;
import com.ge.trans.rmd.cm.valueobjects.RxChangeAdminVO;
import com.ge.trans.rmd.cm.valueobjects.RxChangeSearchVO;
import com.ge.trans.rmd.cm.valueobjects.RxChangeVO;
import com.ge.trans.rmd.common.beans.RxChangeBean;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.CustomerVO;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

/**
 * @author 307009968
 *
 */
@Controller
@SessionAttributes
public class RxChangeController extends RMDBaseController {

	@Autowired
	private RxChangeService rxChangeService;
	
	@Autowired
	private CallLogNotesController callLogNotesController;
	
	@Autowired
	private ApplicationContext appContext;	

	private final RMDWebLogger logger = RMDWebLogger.getLogger(getClass());

	@Value("${" + RMDCommonConstants.DELV_RX_PDF_PATH + "}")
	String delvRxPDFPath;
	@Value("${" + RMDCommonConstants.PDF_URL + "}")
	String pdfURL;

	/**
	 * 
	 * @param request
	 * @return
	 * @throws RMDWebException
	 */
@RequestMapping(value = AppConstants.REQ_URI_RXCHANGE_OVERVIEW_DATA, method = RequestMethod.POST)
	public @ResponseBody List<RxChangeVO> getRxChangeOverviewData(
			final HttpServletRequest request) throws RMDWebException {
	
		final HttpSession session = request.getSession(false);
		List<RxChangeVO> rxChangeOverviewVO = null;
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);
		final String customerId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_CUSID));
		final String fromDate = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.FROM_DATE));
		final String toDate = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.TO_DATE));
		final String model = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.MODEL));
		String status = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.STATUS));
		String typeOfChangeReq = EsapiUtil.stripXSSCharacters(request
                .getParameter(AppConstants.TYPE_OF_RX_CHANGE));
		final String rxTitle = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.RXTITLE));
		final String defaultTimezone = (String) request
				.getAttribute(AppConstants.DEFAULT_TIMEZONE);
        
		String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
				userVO.getTimeZone());
		try {
			RxChangeSearchVO rxChangeSearchVO = new RxChangeSearchVO();
			if(!userVO.getIsRxChangeAdminPrivilege()){
				rxChangeSearchVO.setUserId(userVO.getUserId());	
			}else{
				if (RMDCommonUtility.isNullOrEmpty(status)) {
					Map<String, String> requestorMap = rxChangeService
							.getRxChangeLookUp(AppConstants.RX_CHANGE_OVERVIEW_STATUS);
					if (!MapUtils.isEmpty(requestorMap)) {
						for (Map.Entry<String, String> entry : requestorMap
								.entrySet()) {
							if (AppConstants.SUBMITTED.equals(
							        entry.getValue())
									|| AppConstants.UNDERREVIEW.equals(entry.getValue()
											)) {
								if (RMDCommonUtility.isNullOrEmpty(status))
									status = entry.getKey();
								else
									status += "," + entry.getKey();
							}
						}
					}
				}
			}
				
			if (!RMDCommonUtility.isNullOrEmpty(customerId)) {
				List<String> customerIdLst = new ArrayList<String>(
						Arrays.asList(customerId.split(AppConstants.COMMA)));
				rxChangeSearchVO.setCustomerIdLst(customerIdLst);
			}
			if (!RMDCommonUtility.isNullOrEmpty(model)) {
				List<String> modelLst = new ArrayList<String>(
						Arrays.asList(model.split(AppConstants.COMMA)));
				rxChangeSearchVO.setModelLst(modelLst);
			}
			if (!RMDCommonUtility.isNullOrEmpty(fromDate)) {
				rxChangeSearchVO.setFromDate(RMDCommonUtility
						.convertDateFormatAndTimezone(fromDate,
								AppConstants.TO_DATE_FORMAT,
								AppConstants.HEATMAP_DB_DATE_FORMAT,
								applicationTimezone,
								AppConstants.TIMEZONE_EASTERN));
			}
			if (!RMDCommonUtility.isNullOrEmpty(toDate)) {
				rxChangeSearchVO.setToDate(RMDCommonUtility
						.convertDateFormatAndTimezone(toDate,
								AppConstants.TO_DATE_FORMAT,
								AppConstants.HEATMAP_DB_DATE_FORMAT,
								applicationTimezone,
								AppConstants.TIMEZONE_EASTERN));
			}
			if (!RMDCommonUtility.isNullOrEmpty(status)) {
				List<String> statusLst = new ArrayList<String>(
						Arrays.asList(status.split(AppConstants.COMMA)));
				rxChangeSearchVO.setStatus(statusLst);
			}
			
			if (!RMDCommonUtility.isNullOrEmpty(typeOfChangeReq)) {
                List<String> typeOfChangeReqLst = new ArrayList<String>(
                        Arrays.asList(typeOfChangeReq.split(AppConstants.COMMA)));
                rxChangeSearchVO.setTypeOfChangeReqLst(typeOfChangeReqLst);
                rxChangeSearchVO.setTypeOfChangeReq(typeOfChangeReq);
            }
			if (!RMDCommonUtility.isNullOrEmpty(rxTitle)) {
				rxChangeSearchVO.setRxTitle(rxTitle);
			}
			rxChangeSearchVO.setUserTimeZone(applicationTimezone);	
			
			rxChangeOverviewVO = rxChangeService
					.getRxChangeOverviewData(rxChangeSearchVO);
			
		} catch (RMDWebException e) {
			logger.error(
					"RMDWebException occured in getRxChangeOverviewData Method",
					e);
			RMDWebErrorHandler.handleException(e);

		} catch (Exception ex) {
			logger.error("Exception occured in getRxChangeOverviewData Method",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return rxChangeOverviewVO;
	}

/**
 * 
 * @param request
 * @return
 * @throws RMDWebException
 */
	@RequestMapping(value = AppConstants.REQ_URI_RXCHANGE_REQUEST, method = RequestMethod.GET)
	public String getRxChangeRequestPage(final HttpServletRequest request) throws RMDWebException {
		try {
			String fromDate = null;
			String toDate = null;
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			final SimpleDateFormat dateFormat = new SimpleDateFormat(
					AppConstants.TO_DATE_FORMAT);

			final String defaultTimezone = (String) request
					.getAttribute(AppConstants.DEFAULT_TIMEZONE);

			String applicationTimezone = RMDCommonUtil.getTimezone(
					defaultTimezone, userVO.getTimeZone());
			
			String defaultDays = callLogNotesController.getDefaultDays();
			dateFormat.setTimeZone(TimeZone.getTimeZone(applicationTimezone));
			Calendar fromDtCal = Calendar.getInstance();
			fromDtCal.add(Calendar.DATE, -Integer.parseInt(defaultDays));
			fromDate = dateFormat.format(fromDtCal.getTime());
			toDate = dateFormat.format(new Date());
			List<RxChangeVO> lstRxChangeVO = getRxChangeOverviewData(request);
			
			request.setAttribute(AppConstants.FROM_DATE, fromDate);
			request.setAttribute(AppConstants.TO_DATE, toDate);
			request.setAttribute(AppConstants.RX_CHANGE_OVERVIEW_LIST, lstRxChangeVO);
							
		} catch (RMDWebException e) {
			logger.error(
					"RMDWebException occured in getRxChangeRequestPage Method",
					e);
			RMDWebErrorHandler.handleException(e);

		} catch (Exception ex) {
			logger.error("Exception occured in getRxChangeRequestPage Method",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return AppConstants.VIEW_RX_CHANGE_REQUEST;
	}
	
	/**
	 * 
	 * @param request
	 * @return
	 * @throws Exception
	 */
	
	@RequestMapping(value = AppConstants.REQ_URI_SAVE_EDIT_RXCHANGE, method = RequestMethod.POST)
	public @ResponseBody String saveRxChangeReqDetails(final HttpServletRequest request) 
            throws Exception {
        logger.debug("START : RxChangeController : saveRxChangeDetails()");
       
        final HttpSession session = request.getSession(false);
        final RxChangeBean rxChangeBean = new RxChangeBean();
        List<String> customerIds= null;
        List<String> modelIds = null;
        String resultString = null;
        String statusVal = null;
        try{
        final UserVO userVO = (UserVO) session
                .getAttribute(AppConstants.ATTR_USER_OBJECT);
        
        final String reqObjId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.OBJID));
        final String notes = request.getParameter(AppConstants.NOTES_DESC);
        final String requestOwner = request.getParameter(AppConstants.REQUEST_OWNER);
        rxChangeBean.setUserId(userVO.getUserId());
       
        System.out.println("notes :: "+notes);
        
        if(!RMDCommonUtility.isNullOrEmpty(reqObjId)){  
        	 final String actionType = request.getParameter(AppConstants.ACTION_TYPE);
        	  rxChangeBean.setObjId(reqObjId);
        	  
        	if(AppConstants.ACTION_TYPE_PENDING_REQUESTOR
                    .equalsIgnoreCase(actionType) && !RMDCommonUtility.isNullOrEmpty(notes))
        		rxChangeBean.setNotes(notes);
        	else
        	    rxChangeBean.setChangesSuggested(notes);
        	
            if(!RMDCommonUtility.isNullOrEmpty(requestOwner)){
            	rxChangeBean.setRequestOwner(requestOwner);
            }
          
            if(!RMDCommonUtility.isNullOrEmpty(actionType)){ 
					if (AppConstants.ACTION_TYPE_TAKE_OWNERSHIP.equalsIgnoreCase(actionType)) {
						statusVal = AppConstants.ACTION_TYPE_REVIEW;
					}
					if (AppConstants.ACTION_TYPE_YANK
							.equalsIgnoreCase(actionType)) {
						statusVal = AppConstants.ACTION_TYPE_REVIEW;
					}
					if (AppConstants.ACTION_TYPE_PENDING_REQUESTOR
							.equalsIgnoreCase(actionType)) {
						statusVal = AppConstants.ACTION_TYPE_REVIEW;
					}
					if (AppConstants.ACTION_TYPE_REQUEST_ADDITIONAL_INFORMATION
							.equalsIgnoreCase(actionType)) {
						statusVal = RMDCommonConstants.RX_CHANGE_STATUS_PENDING_REQUESTOR;
					}
					if (AppConstants.ACTION_TYPE_REJECTED
							.equalsIgnoreCase(actionType)) {
						statusVal = RMDCommonConstants.RX_CHANGE_STATUS_REJECTED;
					}
					if ( AppConstants.ACTION_TYPE_APPROVED
							.equalsIgnoreCase(actionType)) {
						statusVal = RMDCommonConstants.RX_CHANGE_STATUS_APPROVED;
					}
					
            	if (!RMDCommonUtility.isNullOrEmpty(statusVal)) {
            		Map<String, String> requestorMap = rxChangeService
    						.getRxChangeLookUp(AppConstants.RX_CHANGE_OVERVIEW_STATUS);
    				if (!MapUtils.isEmpty(requestorMap)) {
    					for (Map.Entry<String, String> entry : requestorMap
    							.entrySet()) {
    						if (entry.getValue().equalsIgnoreCase(statusVal)) {
    							rxChangeBean.setStatusObjId(Long.parseLong(entry.getKey()));
    						}
    					}
    				}
            	}
            }         
         resultString = rxChangeService.saveRxChangeReqDetails(rxChangeBean);
        }
        else{
        rxChangeBean.setStatusObjId(getLookUpObjidForName(AppConstants.RX_CHANGE_OVERVIEW_STATUS));
    	//String fileName = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.RX_CHANGE_ATTACHMENT_TITLE));
    	String fileData = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.RX_CHANGE_ATTACHMENT_DATA));    	
    	String screenName = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.SCREEN_NAME));
        final String customerId = request.getParameter(AppConstants.CUSTOMERID);
        if (null != customerId
                && !RMDCommonConstants.ALL_CUSTOMER.equals(customerId)
                && !RMDCommonConstants.NULL_STRING.equals(customerId)) {
            String[] customerIdArr = customerId.split(AppConstants.SYMBOL_COMMA);
            
            customerIds = new ArrayList<String>();
            for (String currentCustomerId : customerIdArr) {
                customerIds.add((currentCustomerId.split(AppConstants.UNDERSCORE))[0]);
            }
            if (null != customerIds && customerIds.size() > 1) {
                customerIds.remove(RMDCommonConstants.ALL_CUSTOMER);
            }
            rxChangeBean.setCustomerIdList(customerIds);
        }

        final String modelId = request.getParameter(AppConstants.MODEL_ID);

        if (null != modelId && !RMDCommonConstants.ALL_MODEL.equals(modelId)
                && !RMDCommonConstants.NULL_STRING.equals(modelId)) {
            String[] modelIdArr = modelId.split(AppConstants.SYMBOL_COMMA);
            modelIds = new ArrayList<String>();
            for (String currentModelId : modelIdArr) {
                modelIds.add(currentModelId);
            }

            if (null != modelIds && modelIds.size() > 1) {
                modelIds.remove(RMDCommonConstants.ALL_MODEL);
            }
            rxChangeBean.setModelIdList(modelIds);
        }

        final String requestor = request.getParameter(AppConstants.REQUESTOR);
        final String revisionType = request.getParameter(AppConstants.REVISIONTYPE);
        final String specificRxTitle = request.getParameter(AppConstants.SPECIFICRXTITLE);
        final String generalRxTitle = request.getParameter(AppConstants.GENERALRXTITLE);
        final String roadNumber = request.getParameter(AppConstants.ROAD_NUMBER);
        final String caseId = request.getParameter(AppConstants.CASE_ID);
        final String changesSuggested = request.getParameter(AppConstants.CHANGES_SUGGESTED);
        final String typeOfRxChange = request.getParameter(AppConstants.TYPE_OF_RX_CHANGE);

		if (!RMDCommonUtility.isNullOrEmpty(requestor)
						&& (requestor.contains(AppConstants.UNDERSCORE))) {
					rxChangeBean.setRequestor((requestor
							.split(AppConstants.UNDERSCORE))[0]);
		}
        rxChangeBean.setRevisionType(revisionType);
        if(null == specificRxTitle || RMDCommonConstants.NULL_STRING.equals(specificRxTitle))
        {
            rxChangeBean.setSpecificRxTitle(RMDCommonConstants.EMPTY_STRING);
        }else{
            rxChangeBean.setSpecificRxTitle(specificRxTitle);
        }
        
        rxChangeBean.setGeneralRxTitle(generalRxTitle);
        if(null == roadNumber || RMDCommonConstants.NULL_STRING.equals(roadNumber))
        {
            rxChangeBean.setRoadNumber(RMDCommonConstants.EMPTY_STRING);
        }else{
        rxChangeBean.setRoadNumber(roadNumber);
        }
        
        rxChangeBean.setCaseId(caseId);
        rxChangeBean.setChangesSuggested(changesSuggested);
        rxChangeBean.setCustomerIdList(customerIds);
        rxChangeBean.setModelIdList(modelIds);
        
        rxChangeBean.setStatus(RMDCommonConstants.RX_CHANGE_STATUS_PENDING);
        
        if (!RMDCommonUtility.isNullOrEmpty(typeOfRxChange)) {
			List<String> typeOfRxChangeLst = new ArrayList<String>(
					Arrays.asList(typeOfRxChange.split(AppConstants.COMMA)));
			 rxChangeBean.setTypeOfRxChange(typeOfRxChangeLst);
		}       
        /**
		 * US293725	Customers : Rx Update Workflow - Save multiple attachments in Add Rx Change Request Page Start
		 */
      /*  if(!RMDCommonUtility.isNullOrEmpty(fileName)){
        	rxChangeBean.setFileName(fileName);
        }*/
        if(!RMDCommonUtility.isNullOrEmpty(fileData)){        	
        	final ObjectMapper mapper = new ObjectMapper();
    		mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    		mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
    		RecommDeliverVO objRecommDeliverVO = mapper.readValue(
    				fileData, RecommDeliverVO.class);		
    		    	
        	/*
        	if(fileName.toLowerCase().endsWith(".exe")){
        		return AppConstants.INVALID_FILE_NAME;
        	}  
        	rxChangeBean.setFileData(fileData.getBytes());
        	String filePath = uploadRxAttachment(fileData, fileName);
        	rxChangeBean.setFilePath(filePath);*/
			rxChangeBean.setArlRecommDelDocVO(objRecommDeliverVO
							.getArlRecommDelDocVO());    		
		}
        rxChangeBean.setScreenName(screenName);
        /**
		 * US293725	Customers : Rx Update Workflow - Save multiple attachments in Add Rx Change Request Page End
		 */
				resultString = rxChangeService
						.saveRxChangeReqDetails(rxChangeBean);
			}
		} catch (Exception ex) {
			resultString = RMDCommonConstants.FAILURE_MSG;
			logger.error("Exception occured in getuserManagementPage method ",ex);
			RMDWebErrorHandler.handleException(ex);
		}
        logger.debug("END : RxChangeController : saveRxChangeDetails()");
        return resultString;
    }	

	/**
	 * 
	 * @param request
	 * @return
	 * @throws RMDWebException
	 */
    @RequestMapping(value = AppConstants.REQ_URI_RXCHANGE_REQUESTORS, method = RequestMethod.GET)
    @ResponseBody public 
    Map<String, String> getRequestorDetails(final HttpServletRequest request) throws  RMDWebException {
        logger.debug("Inside RxChangeController in getRequestorDetails Method");
        Map<String, String> requestorMap = new HashMap<String, String>();
        final HttpSession session = request.getSession(false);
        final UserVO userVO = (UserVO) session
                .getAttribute(AppConstants.ATTR_USER_OBJECT);
        
        Boolean rxChangeAdminPrivilege = userVO.getIsRxChangeAdminPrivilege();
       try {
            if (rxChangeAdminPrivilege) {
                String fName = EsapiUtil.stripXSSCharacters(request.getParameter(RMDCommonConstants.FIRST_NAME));
                String lName = EsapiUtil.stripXSSCharacters(request.getParameter(RMDCommonConstants.LAST_NAME));
                String userId = EsapiUtil.stripXSSCharacters(request.getParameter(RMDCommonConstants.USER_ID));

                if (!RMDCommonUtility.isNullOrEmpty(fName) || !RMDCommonUtility.isNullOrEmpty(lName)
                        || !RMDCommonUtility.isNullOrEmpty(userId)) {
                    requestorMap = rxChangeService.getRequestorDetails(fName, lName, userId);
                    
                } 
            }
            else{
                requestorMap.put(userVO.getUserId(), userVO.getStrLastName()+""+userVO.getStrFirstName()+"( "+userVO.getUserId() +")");
            }
            
        } catch (Exception rmdEx) {
            logger.error("RMDWebException occured in getRequestorDetails() method - RxChangeController",
                            rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }
        return requestorMap;
    }
    
    /**
     * 
     * @param request
     * @return
     * @throws RMDWebException
     */
    @RequestMapping(value = AppConstants.REQ_URI_RXCHANGE_LOOKUP, method = RequestMethod.GET)
    @ResponseBody public 
    Map<String, String> getRxChangeLookUp(final HttpServletRequest request) throws  RMDWebException {
        Map<String, String> requestorMap = new HashMap<String, String>();
        final String lookupListName = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.LOOKUP_NAME)); 
        try {
              requestorMap = rxChangeService.getRxChangeLookUp(lookupListName);
        } catch (Exception rmdEx) {
            logger.error("RMDWebException occured in getRequestorDetails() method - RxChangeController",
                            rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }
        return requestorMap;
    }
    
    /**
     * 
     * @param request
     * @return
     * @throws RMDWebException
     * @Description: This method gets the customer details for the user
     */
    @RequestMapping(value = AppConstants.REQ_URI_RXCHANGE_CUSTOMERS, method = RequestMethod.GET)
    @ResponseBody public 
    Map<String, String> getCustomerDetails(final HttpServletRequest request)
            throws  RMDWebException {
        final String userId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID));
        Map<String, String> customerMap = new HashMap<String, String>();
        try {
            if(!RMDCommonUtility.isNullOrEmpty(userId)){
            customerMap = rxChangeService.getCustomerDetails(userId);
            }
        } catch (Exception rmdEx) {
            logger.error("RMDWebException occured in getCustomerDetails() method - RxChangeController",
                            rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }
        return customerMap;
    }
    
    /**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for fetching the Model values for particular Customer.
     */
    @RequestMapping(value = AppConstants.REQ_URI_RXCHANGE_MODELS, method = RequestMethod.GET)
    @ResponseBody public 
    Map<String, String> getModelDetails(final HttpServletRequest request)
            throws  RMDWebException {
         Map<String, String> modelMap = new HashMap<String, String>();
        final String customerId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CUSTOMER_ID));
       try {
    	   
    	   /**
    	    * Fixing DE85985 UAT issue Ben Rx Change Request : Overview and Details screen implementation changes
    	    */
            //if(!RMDCommonUtility.isNullOrEmpty(customerId)){
            modelMap = rxChangeService.getModelDetails(EsapiUtil.stripXSSCharacters(customerId));
            //}
        } catch (Exception rmdEx) {
            logger.error("RMDWebException occured in getModelDetails() method - RxChangeController",
                            rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }
        return modelMap;
    }
    
    /**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for fetching the Rx Title's.
     */
    @RequestMapping(value = AppConstants.REQ_URI_RXCHANGE_RXTITLE, method = RequestMethod.GET)
    @ResponseBody public 
    Map<String, String> getRxTitles(final HttpServletRequest request)
            throws  RMDWebException {
        logger.debug("Inside RxChangeController in getRxTitles Method");
        Map<String, String> rxTitleMap = new HashMap<String, String>();
        
        final String modelId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.MODEL_ID));
        final String searchVal = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.SEARCH_VAL));
        System.out.println("modelId :: "+modelId);
        try {
            if(!RMDCommonUtility.isNullOrEmpty(searchVal)){
            rxTitleMap = rxChangeService.getRxTitles(searchVal, modelId);
            }
        } catch (Exception rmdEx) {
            logger.error("RMDWebException occured in getRxTitles() method - RxChangeController",
                            rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }
        return rxTitleMap;
    }
    
    /**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for fetching the Road numbers for particular Customer, Model and the search value.
     */
    @RequestMapping(value = AppConstants.REQ_URI_RXCHANGE_ROADNUMBERS, method = RequestMethod.GET)
    @ResponseBody public 
    Map<String, String> getRoadNumbers(String customerId, String modelId, String searchString)
            throws  RMDWebException {
        logger.debug("Inside RxChangeController in getRoadNumbers Method");
        Map<String, String> roadNumberMap = new HashMap<String, String>();
        try {
            if (!RMDCommonUtility.isNullOrEmpty(customerId) || !RMDCommonUtility.isNullOrEmpty(modelId)
                    || !RMDCommonUtility.isNullOrEmpty(searchString)) {
            roadNumberMap = rxChangeService.getRoadNumbers(EsapiUtil.stripXSSCharacters(customerId), EsapiUtil.stripXSSCharacters(modelId),searchString);
        }
        }catch (Exception rmdEx) {
            logger.error("RMDWebException occured in getRoadNumbers() method - RxChangeController",
                            rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }
        return roadNumberMap;
    }
    
    /**
     * @Author:
     * @param:
     * @return:boolean
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used to check is the case ID is valid.
     */
    
    @RequestMapping(value = AppConstants.REQ_URI_RXCHANGE_CASEID, method = RequestMethod.GET)
    @ResponseBody public 
    boolean getCaseId(final HttpServletRequest request)
            throws  RMDWebException {
       
        final String userId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.USER_ID));
        final String caseSearchString = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CASE_SEARCH_STR));
        
        boolean result = AppConstants.FALSE;
        try {
            if (!RMDCommonUtility.isNullOrEmpty(userId) || !RMDCommonUtility.isNullOrEmpty(caseSearchString)){
            result = rxChangeService.getCaseId(userId, caseSearchString);
            }
        } catch (Exception rmdEx) {
            logger.error("RMDWebException occured in getCaseId() method - RxChangeController",
                            rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }
        return result;
    }
    
    /**
     * @Author:
     * @param:
     * @return:List<ModelVO>
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for fetching the Model values for particular Rx title.
     */
    @RequestMapping(value = AppConstants.REQ_URI_RXCHANGE_MODEL_RXTITLE, method = RequestMethod.POST)
    @ResponseBody public 
    List<ModelVO> getModelForRxTitle(final HttpServletRequest request)
            throws  RMDWebException {        
        List<ModelVO> lstModel = null;
        try {
        	RxChangeSearchVO rxChangeSearchVO = new RxChangeSearchVO();
        	final String recomObjId = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.RECOM_ID));
        	rxChangeSearchVO.setRecomObjId(recomObjId);
        	lstModel = rxChangeService.getModelForRxTitle(rxChangeSearchVO);
        } catch (Exception rmdEx) {
            logger.error("RMDWebException occured in getModelForRxTitle() method - RxChangeController",
                            rmdEx);
            RMDWebErrorHandler.handleException(rmdEx);
        }
        return lstModel;
    }

    /**
     * @Author:
     * @param:
     * @return:RxChangeAdminVO
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for fetching the Rx change admin data.
     */
	@RequestMapping(value = AppConstants.REQ_URI_RXCHANGE_ADMIN_DATA, method = RequestMethod.POST)
	@ResponseBody
	public RxChangeAdminVO getRxChangeAdminData(final HttpServletRequest request)
			throws RMDWebException {
		RxChangeAdminVO rxChangeAdminVO = null;
		try {
			  
			RxChangeSearchVO rxChangeSearchVO = new RxChangeSearchVO();
			rxChangeSearchVO.setRxChangeReqObjId(EsapiUtil
					.stripXSSCharacters(request
							.getParameter(AppConstants.RX_CHANGE_REQ_OBJ_ID)));
			rxChangeSearchVO.setRxChangeProcObjId(EsapiUtil
					.stripXSSCharacters(request
							.getParameter(AppConstants.RX_CHANGE_PROC_OBJ_ID)));			
			rxChangeAdminVO = rxChangeService
					.getRxChangeAdminData(rxChangeSearchVO);
		} catch (RMDWebException e) {
			logger.error(
					"RMDWebException occured in getRxChangeAdminData Method", e);
			RMDWebErrorHandler.handleException(e);

		} catch (Exception ex) {
			logger.error("Exception occured in getRxChangeAdminData Method", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return rxChangeAdminVO;
	}
	
	/**
     * @Author:
     * @param:
     * @return:String
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for Saving / Updating the Rx Change Request Admin Details.
     */
	@RequestMapping(value = AppConstants.REQ_URI_RXCHANGE_SAVE_UPDATE_ADMIN, method = RequestMethod.POST)
	public @ResponseBody String saveUpdateRxChangeAdminDetails(
			final HttpServletRequest request) throws RMDWebException {
		String strResult = null;
		try {
			
			String strrxChangeAdminVO = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.GET_PARAMETER_STRING));
			final ObjectMapper mapper = new ObjectMapper();
			mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
			mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
			RxChangeAdminVO objRxChangeAdminVO = mapper.readValue(strrxChangeAdminVO,
					RxChangeAdminVO.class);
			if (!RMDCommonUtility.isNullOrEmpty(objRxChangeAdminVO
					.getActionType())
					&& AppConstants.ACTION_TYPE_SAVE_AS_DRAFT_ADMIN.equalsIgnoreCase(
					        objRxChangeAdminVO.getActionType())) {
				objRxChangeAdminVO.setSaveAsDraft(AppConstants.YES_FLAG);
			}	else
				objRxChangeAdminVO.setSaveAsDraft(null);	
			
			//if any model,customer,rxtitle is newly inserted/removed
			strResult = rxChangeService.saveUpdateRxChangeAdminDetails(objRxChangeAdminVO);		
			
		} catch (RMDWebException e) {
			logger.error(
					"RMDWebException occured in saveUpdateRxChangeAdminDetails Method", e);
			RMDWebErrorHandler.handleException(e);

		} catch (Exception ex) {
			logger.error("Exception occured in saveUpdateRxChangeAdminDetails Method", ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return strResult;
	}
	
	/**
     * @Author:
     * @param:
     * @return:List<CustomerVO>
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for fetching cutsomer infomation based on the models .
     */
	@RequestMapping(value = AppConstants.REQ_URI_RXCHANGE_CUSTOMER_MODEL, method = RequestMethod.POST)
	@ResponseBody
	public List<CustomerVO> getCustomerForModel(final HttpServletRequest request)
			throws RMDWebException {
		List<CustomerVO> lstCustomer = null;
		List<CustomerVO> newlstCustomer = null;
		try {
			final String model = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.MODEL));
					
			lstCustomer = rxChangeService.getCustomerForModel(model);
			//Removing duplicates from customerList
			newlstCustomer = lstCustomer;
			/*for(CustomerVO customerVO : lstCustomer)
			{
			    for(CustomerVO customerVOnew : lstCustomer)
			    {
			        if(customerVO.equals(customerVOnew)){
			        	newlstCustomer.remove(customerVO); // or list.remove(obj2);
			        }
			    }
			}*/
			newlstCustomer = new ArrayList(new LinkedHashSet(lstCustomer));			
		} catch (Exception rmdEx) {
			logger.error(
					"RMDWebException occured in getCustomerForModel() method - RxChangeController",
					rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		}
		return newlstCustomer;
	}
	
	/**
     * @Author:
     * @param:
     * @return: 
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for exporting the Rx Change Request Details.
     */
	@RequestMapping(AppConstants.EXPORT_RX_CHANGE_OVERVIEW_DATA)
	public @ResponseBody
	void exportRxChangeOverviewData(final HttpServletRequest request,final HttpServletResponse response,final Locale locale)
			throws Exception {
		List<RxChangeVO> lstRxChangeVO = null;
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		try {		
			lstRxChangeVO = getRxChangeOverviewData(request);
			csvContent = convertToCSVQueueCases(lstRxChangeVO, locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.RX_CHANGE_OVERVIEW_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);
			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);
			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (RMDWebException rmdEx) {
			logger
			.error("Exception occured in exportOverviewData method ", rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			logger
					.error("Exception occured in exportOverviewData method ", ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		}
		finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}
		
	}
	
	/**
     * @Author:
     * @param:
     * @return: String
     * @throws:
     * @Description: 
     */
	private String convertToCSVQueueCases(List<RxChangeVO> rxChangeVOLst,Locale locale) {
		String csvContent = null;
		StringBuilder strBufferHeader = new StringBuilder();
		try {
			strBufferHeader.append(appContext.getMessage(
					AppConstants.RX_CHANGE_OVERVIEW_HEADER, null, locale));
			strBufferHeader.append(RMDCommonConstants.NEWLINE);
			for (RxChangeVO rxChangeVO : rxChangeVOLst) {
							
				if (null != rxChangeVO.getRequestId()) {
					strBufferHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ rxChangeVO.getRequestId() + AppConstants.QUOTE);
				} else {
					strBufferHeader.append(AppConstants.QUOTE
							+ AppConstants.EMPTY_SPACE
							+ AppConstants.QUOTE);
				}
						
				if (null != rxChangeVO.getUserName()) {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ rxChangeVO.getUserName()
									+ AppConstants.QUOTE);
				} else {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}	
				if (null != rxChangeVO.getRequestOwner()) {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ rxChangeVO.getRequestOwner()
									+ AppConstants.QUOTE);
				} else {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}	
				if (null != rxChangeVO.getRevisionType()) {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ rxChangeVO.getRevisionType()
									+ AppConstants.QUOTE);
				} else {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}	
				if (null != rxChangeVO.getRxTitle()) {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ rxChangeVO.getRxTitle()
									+ AppConstants.QUOTE);
				} else {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}	
				if (null != rxChangeVO.getTypeOfChangeReq()) {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ rxChangeVO.getTypeOfChangeReq()
									+ AppConstants.QUOTE);
				} else {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}	
				if (null != rxChangeVO.getRequestLoggedDate()) {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ rxChangeVO.getRequestLoggedDate()
									+ AppConstants.QUOTE);
				} else {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}	
				if (null != rxChangeVO.getStatus()) {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ rxChangeVO.getStatus()
									+ AppConstants.QUOTE);
				} else {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}	
				if (null != rxChangeVO.getCustomer()) {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ rxChangeVO.getCustomer()
									+ AppConstants.QUOTE);
				} else {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}	
				if (null != rxChangeVO.getModel()) {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ rxChangeVO.getModel()
									+ AppConstants.QUOTE);
				} else {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}	
				if (null != rxChangeVO.getRoadNumber()) {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ rxChangeVO.getRoadNumber()
									+ AppConstants.QUOTE);
				} else {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}	
				if (null != rxChangeVO.getCaseId()) {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ rxChangeVO.getCaseId()
									+ AppConstants.QUOTE);
				} else {
					strBufferHeader
							.append(RMDCommonConstants.COMMMA_SEPARATOR
									+ AppConstants.QUOTE
									+ AppConstants.EMPTY_SPACE
									+ AppConstants.QUOTE);
				}

				strBufferHeader.append(RMDCommonConstants.NEWLINE);
			}
			csvContent = strBufferHeader.toString();
		} catch (Exception exception) {
			logger.error("Export to CSV Rx Change Overview Data"
					+ exception);
		}
		return csvContent;
	}
	
	/**
     * @Author:
     * @param:
     * @return: None
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for downloading the attcahments.
     */
	@RequestMapping(AppConstants.DOWNLOAD_RX_CHANGE_ATTACHMENT)
	@ResponseBody
	public void downloadRxChangeAttachment(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws Exception {
		ServletOutputStream out = null;
		FileInputStream in = null;
		try {
			/*String filePath = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.RX_CHANGE_ATTACHMENT_FILE_PATH));*/
			final String fileName = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.RX_CHANGE_ATTACHMENT_FILE_NAME));
			String requestId = EsapiUtil.stripXSSCharacters(request
					.getParameter(RMDCommonConstants.RX_CHANGE_REQ_OBJ_ID));
			out = response.getOutputStream();
			in = new FileInputStream(delvRxPDFPath + File.separator
					+ "RxChangeAttachments" + File.separator + requestId +File.separator +fileName);			
			response.setContentType(AppConstants.FILE_CONTENT_DISPOSITION);
			response.addHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME + fileName);
			int octet;
			while ((octet = in.read()) != -1)
				out.write(octet);
			
		} catch (Exception rmdEx) {
			logger.error(
					"RMDWebException occured in downloadRxAttachment() method - RxChangeController",
					rmdEx);
			RMDWebErrorHandler.handleException(rmdEx);
		} finally {
			in.close();
			out.close();
		}

	}

	/**
     * @Author:
     * @param:
     * @return: List<UserServiceVO>
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for getting Admin users list.
     */
	@RequestMapping(AppConstants.GET_RXCHANGE_ADMIN_USERS)
    @ResponseBody
	public List<UserServiceVO> getRxChangeAdminUsers(final HttpServletRequest request) throws Exception {

        List<UserServiceVO> arlResponse = new ArrayList<UserServiceVO>();

        try{
            arlResponse = rxChangeService.getRxChangeAdminUsers(); 
            
            }
        catch (Exception ex) {
            logger.error(
                    "RMDWebException occured in getRxChangeAdminUsers() method - RxChangeController",
                    ex);
            RMDWebErrorHandler.handleException(ex);
        }
        
        return arlResponse;
    }
	
	/**
     * @Author:
     * @param:
     * @return: List<UserServiceVO>
     * @throws:GenericAjaxException,RMDWebException
     * @Description: This method is used for getting Admin users list.
     */
    @RequestMapping(AppConstants.GET_RX_CHANGE_HISTORY)
    @ResponseBody
    public List<RxChangeVO> getRxChangeAuditTrailInfo(final HttpServletRequest request) throws Exception {

        List<RxChangeVO> rxChangeVOLst = new ArrayList<RxChangeVO>();

        try{
            final HttpSession session = request.getSession(false);
            final UserVO userVO = (UserVO) session
                    .getAttribute(AppConstants.ATTR_USER_OBJECT);
            
            String rxChngObjid = EsapiUtil.stripXSSCharacters(request
                    .getParameter(AppConstants.RX_CHANGE_REQ_OBJ_ID));
            
            rxChangeVOLst = rxChangeService.getRxChangeAuditTrailInfo(rxChngObjid, userVO.getTimeZone());
            }
        catch (Exception ex) {
            logger.error(
                    "RMDWebException occured in getRxChangeAdminUsers() method - RxChangeController",
                    ex);
            RMDWebErrorHandler.handleException(ex);
        }
        
        return rxChangeVOLst;
    }
	/**
	 * 
	 * @param request
	 * @return
	 * @throws RMDWebException
	 */
	@RequestMapping(value = AppConstants.REQ_URI_TECHNICIAN_RX_CHANGE_MODELS)
	@ResponseBody
	public java.util.Map<String, String> getModelForTechnicianScreen(
			@RequestParam(value = AppConstants.CUSTOMER) final String customer,
			@RequestParam(value = AppConstants.FLEET) final String fleet,
			@RequestParam(value = AppConstants.RNH) final String rnh,
			@RequestParam(value = AppConstants.ASSET_LIST) final String assetList,
			HttpServletRequest request) throws RMDWebException {
		Map<String, String> modelMap = null;
		Map<String, String> sortedMap = new LinkedHashMap<String, String>();
		try {
			if ((customer != null && !customer
					.equals(AppConstants.EMPTY_STRING))
					|| (fleet != null && !fleet
							.equals(AppConstants.EMPTY_STRING))
					|| (rnh != null && !rnh.equals(AppConstants.EMPTY_STRING))
					|| (assetList != null && !assetList
							.equals(AppConstants.EMPTY_STRING))) {
				modelMap = rxChangeService.getModelForTechnicianScreen(
						EsapiUtil.stripXSSCharacters(customer),
						EsapiUtil.stripXSSCharacters(fleet),
						EsapiUtil.stripXSSCharacters(rnh),
						EsapiUtil.stripXSSCharacters(assetList));
				sortedMap = SortMapValues(modelMap);
			}
		}
		catch (Exception e) {
			logger.error(
					"RMDWebException occured in getModelForTechnicianScreen() method - RxChangeController",
					e);
			RMDWebErrorHandler.handleException(e);
		} finally {
			modelMap = null;
		}
		return sortedMap;
	}
}
