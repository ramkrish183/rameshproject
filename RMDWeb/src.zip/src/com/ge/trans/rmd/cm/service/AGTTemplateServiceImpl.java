package com.ge.trans.rmd.cm.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.AssetTemplateListVO;
import com.ge.trans.rmd.cm.valueobjects.AssetTemplateVO;
import com.ge.trans.rmd.cm.valueobjects.AssetsVO;
import com.ge.trans.rmd.cm.valueobjects.ConfigSearchVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRApplyTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRApplyTemplateResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTemplateResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRTemplateResponseVO;
import com.ge.trans.rmd.cm.valueobjects.MassApplyCfgVO;
import com.ge.trans.rmd.cm.valueobjects.VerifyCfgTemplateVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.services.assets.valueobjects.ApplyCfgTemplateRequestType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class AGTTemplateServiceImpl implements AGTTemplateService {

    @Autowired
    private ManageLDVRRequestsService manageLDVRRequestsService;
    @Autowired
    private LDVRAssetStatusService ldvrAssetStatusService;
    
 

    private final RMDWebLogger rmdWebLogger = RMDWebLogger
            .getLogger(getClass());

    @Override
    public List<MassApplyCfgVO> getAGTTemplates(ConfigSearchVO objConfigSearchVO) {
        List<MassApplyCfgVO> arlMassApplyCfgVO = new ArrayList<MassApplyCfgVO>();
        LDVRTemplateRequestVO ldvrTemplateRequestVO = null;
        List<LDVRTemplateResponseVO> arlLDVRTemplateResponseVO = null;
        LDVRAssetTemplateResponseVO objLDVRAssetTemplateResponseVO = null;
        MassApplyCfgVO objMassApplyCfgVO = null;
        List<String> objIdList = new ArrayList<String>();

        try {
            // To get all the templates having status as Approved
            try {
                ldvrTemplateRequestVO = new LDVRTemplateRequestVO();
                ldvrTemplateRequestVO.setCategory(objConfigSearchVO
                        .getCatagory());
                ldvrTemplateRequestVO.setDevice(objConfigSearchVO.getDevice());
                ldvrTemplateRequestVO.setCustomerId(Arrays.asList(objConfigSearchVO
                        .getAssetOwnerId().split(RMDCommonConstants.COMMMA_SEPARATOR)));
                ldvrTemplateRequestVO.setTemplateStatus(objConfigSearchVO
                        .getTemplateStatus());
                ldvrTemplateRequestVO.setCtrlCfgName(objConfigSearchVO
                        .getCtrlcfgObjId());
                ldvrTemplateRequestVO.setTimeZone(objConfigSearchVO
                        .getTimeZone());
                arlLDVRTemplateResponseVO = manageLDVRRequestsService
                        .getLDVRTemplateList(ldvrTemplateRequestVO);

                for (LDVRTemplateResponseVO obj : arlLDVRTemplateResponseVO) {
                    objMassApplyCfgVO = new MassApplyCfgVO();
                    objIdList.add(obj.getTemplateObjId());
                    objMassApplyCfgVO.setObjId(obj.getTemplateObjId());
                    objMassApplyCfgVO.setTemplate(obj.getTemplateNumber()
                            .toString());
                    objMassApplyCfgVO.setVersion(obj.getTemplateVersion()
                            .toString());
                    objMassApplyCfgVO.setTitle(obj.getDescription());
                    objMassApplyCfgVO.setCfgStatus(obj.getTemplateStatus());
                    objMassApplyCfgVO.setDevice(obj.getDevice());
                    arlMassApplyCfgVO.add(objMassApplyCfgVO);
                }

            } catch (Exception e) {
                rmdWebLogger
                        .error("Exception occured in getLDVRTemplateList() "
                                + e.getMessage());
            }
            // To get all the templates that are associated with the selected
            // asset
            try {
                LDVRAssetTemplateRequestVO ldvrAssetTemplateRequestVO = new LDVRAssetTemplateRequestVO();
                ldvrAssetTemplateRequestVO.setAssetOwnerId(objConfigSearchVO
                        .getAssetOwnerId());
                ldvrAssetTemplateRequestVO.setRoadInitial(objConfigSearchVO
                        .getRoadInitial());
                ldvrAssetTemplateRequestVO.setRoadNumber(objConfigSearchVO
                        .getRoadNumber());
                ldvrAssetTemplateRequestVO.setLstDevice(Arrays
                        .asList(objConfigSearchVO.getDevice().split(
                                RMDCommonConstants.COMMMA_SEPARATOR)));
                ldvrAssetTemplateRequestVO.setRequestType(objConfigSearchVO
                        .getRequestType());
                ldvrAssetTemplateRequestVO.setTimeZone(objConfigSearchVO
                        .getTimeZone());
                ldvrAssetTemplateRequestVO.setTemplateView(objConfigSearchVO
                        .getTemplateView());
                objLDVRAssetTemplateResponseVO = ldvrAssetStatusService
                        .getAssetTemplateList(ldvrAssetTemplateRequestVO);

                for (AssetTemplateListVO obj : objLDVRAssetTemplateResponseVO
                        .getAssetTemplateLists()) {
                    for (AssetTemplateVO obj1 : obj.getTemplates()) {
                        objMassApplyCfgVO = new MassApplyCfgVO();                        
                        objMassApplyCfgVO.setObjId(obj1.getTemplateId());
                        objMassApplyCfgVO.setTemplate(obj1.getTemplateNumber()
                                .toString());
                        objMassApplyCfgVO.setVersion(obj1.getTemplateVersion()
                                .toString());
                        objMassApplyCfgVO.setTitle(obj1.getTitle());
                        objMassApplyCfgVO.setDevice(objLDVRAssetTemplateResponseVO.getDevice());
                        objMassApplyCfgVO.setVehicleStatus(obj1.getStrActive());
                        objMassApplyCfgVO.setVehicleStatusDate(RMDCommonUtility
                        .convertDateFormatTimezone(
                                obj1.getInstallationDate(),
                                 RMDCommonConstants.ddMMyyyyHHmmss,
                                RMDCommonConstants.DATE_FORMAT_24HRS, 
                                ldvrAssetTemplateRequestVO
                                        .getTimeZone()));
                        if (objIdList.contains(obj1.getStrTemplateID())) {
                            objMassApplyCfgVO
                                    .setCfgStatus(RMDCommonConstants.APPROVED);
                        } else {
                            objMassApplyCfgVO
                                    .setCfgStatus(RMDCommonConstants.OBSOLETE);
                        }
                        arlMassApplyCfgVO.add(objMassApplyCfgVO);

                    }
                }

            } catch (Exception e) {
                rmdWebLogger
                        .info("Exception occured in getAssetTemplateLists() "
                                + e.getMessage());

            }

            Collections.sort(arlMassApplyCfgVO,
                    new Comparator<MassApplyCfgVO>() {

                        @Override
                        public int compare(MassApplyCfgVO o1, MassApplyCfgVO o2) {
                            if (Integer.parseInt(o1.getTemplate()) == Integer
                                    .parseInt(o2.getTemplate()))
                                return Integer.parseInt(o1.getVersion())
                                        - Integer.parseInt(o2.getVersion());
                            else
                                return Integer.parseInt(o1.getTemplate())
                                        - Integer.parseInt(o2.getTemplate());
                        }

                    });

        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in getAGTTemplates() "
                    + e.getMessage());
        }

        return arlMassApplyCfgVO;
    }
    
    @Override
    public VerifyCfgTemplateVO getSelectedAGTTemplate(String tempNoVer,String timeZone) {
        LDVRTemplateRequestVO ldvrTemplateRequestVO = null;
        List<LDVRTemplateResponseVO> arlLDVRTemplateResponseVO = null;
        VerifyCfgTemplateVO objVerifyCfgTemplateVO = null;

        try {
                ldvrTemplateRequestVO = new LDVRTemplateRequestVO();
                ldvrTemplateRequestVO.setCategory(RMDCommonConstants.AGT_GROUP);
                ldvrTemplateRequestVO.setDevice(tempNoVer.substring(0,tempNoVer.indexOf(RMDCommonConstants.DOLLAR_SEPARATOR)));
                ldvrTemplateRequestVO.setTemplateNumber(tempNoVer.substring(tempNoVer.indexOf(RMDCommonConstants.DOLLAR_SEPARATOR)+1, tempNoVer.indexOf(RMDCommonConstants.UNDERSCORE)));
                ldvrTemplateRequestVO.setTemplateVersion(tempNoVer.substring(tempNoVer.indexOf(RMDCommonConstants.UNDERSCORE)+1));
                ldvrTemplateRequestVO.setTimeZone(timeZone);
                ldvrTemplateRequestVO.setTemplateStatus(RMDCommonConstants.APPROVED);
                arlLDVRTemplateResponseVO = manageLDVRRequestsService
                        .getLDVRTemplateList(ldvrTemplateRequestVO);
                
               
                 if(null!=arlLDVRTemplateResponseVO && !arlLDVRTemplateResponseVO.isEmpty()) {
                    
                    objVerifyCfgTemplateVO = new VerifyCfgTemplateVO();
                    objVerifyCfgTemplateVO.setConfigFile(RMDCommonConstants.AGT_TEMPLATE);
                    objVerifyCfgTemplateVO.setDevice(arlLDVRTemplateResponseVO.get(0).getDevice());
                    objVerifyCfgTemplateVO.setObjid(arlLDVRTemplateResponseVO.get(0)
                            .getTemplateObjId());
                    objVerifyCfgTemplateVO.setTemplate(arlLDVRTemplateResponseVO.get(0)
                            .getTemplateNumber().toString());
                    objVerifyCfgTemplateVO.setTitle(arlLDVRTemplateResponseVO.get(0)
                            .getDescription());
                    objVerifyCfgTemplateVO.setVersion(arlLDVRTemplateResponseVO.get(0)
                            .getTemplateVersion().toString());
                 }
                    
               

        } catch (Exception e) {
            rmdWebLogger.error("Exception occured in getSelectedAGTTemplate() "
                    + e.getMessage());
        }

        return objVerifyCfgTemplateVO;
    }

    @Override
    public String applyAGTTemplate(
            ApplyCfgTemplateRequestType objApplyCfgTemplateRequestType) {

        LDVRApplyTemplateRequestVO ldvrApplyTemplateRequestVO=null;
        String result=RMDCommonConstants.EMPTY_STRING;
        List<Long> tempObjId =null;
        AssetsVO objAssetsVO=null;
        LDVRApplyTemplateResponseVO objLDVRApplyTemplateResponseVO =null;
        SimpleDateFormat sdf = new SimpleDateFormat(
                RMDCommonConstants.DateConstants.MMddyyyyHHmmssSSS);
        String logMsgTxt = RMDCommonConstants.EMPTY_STRING;
        try{
            
            if(null!=objApplyCfgTemplateRequestType){
                
                logMsgTxt = "  :: AGT :: Template "+objApplyCfgTemplateRequestType.getCfgAGTTemplateList().get(0).getTemplate() +" Version "+objApplyCfgTemplateRequestType.getCfgAGTTemplateList().get(0).getVersion()+" :: ";
                ldvrApplyTemplateRequestVO=new LDVRApplyTemplateRequestVO();
                tempObjId = new ArrayList<Long>();
                tempObjId.add(Long.parseLong( objApplyCfgTemplateRequestType.getCfgAGTTemplateList().get(0).getObjid()));
                ldvrApplyTemplateRequestVO.setDevice(objApplyCfgTemplateRequestType.getDevice());
                ldvrApplyTemplateRequestVO.setTemplateObjid(tempObjId);
                ldvrApplyTemplateRequestVO.setAssets(new ArrayList<AssetsVO>());

                objAssetsVO = new AssetsVO();
                objAssetsVO.setAssetOwnerId(objApplyCfgTemplateRequestType.getCustomerId());
                objAssetsVO.setRoadInitial(objApplyCfgTemplateRequestType.getVehHdrNo());
                objAssetsVO.setRoadNumberFrom(objApplyCfgTemplateRequestType.getArlAssetSearchRequestTypes().get(0).getAssetNumbers().get(0));
                objAssetsVO.setRoadNumberTo(objApplyCfgTemplateRequestType.getArlAssetSearchRequestTypes().get(0).getAssetNumbers().get(0));
                ldvrApplyTemplateRequestVO.getAssets().add(objAssetsVO);
                    
                ldvrApplyTemplateRequestVO.setUserId(objApplyCfgTemplateRequestType.getUserId());
                
                objLDVRApplyTemplateResponseVO=ldvrAssetStatusService.ldvrAssetGroupApplyTemplate(ldvrApplyTemplateRequestVO);
                
                if(RMDCommonUtility.isCollectionNotEmpty(objLDVRApplyTemplateResponseVO.getMessageStatus()))
                    result=sdf.format(new Date()) +logMsgTxt+objLDVRApplyTemplateResponseVO.getMessageStatus().get(0).getMessageStatus();
                else if(RMDCommonUtility.isCollectionNotEmpty(objLDVRApplyTemplateResponseVO.getSkipTemplates()))
                    result=sdf.format(new Date()) +logMsgTxt+objLDVRApplyTemplateResponseVO.getSkipTemplates().get(0).getMessageStatus();
                else if(RMDCommonUtility.isCollectionNotEmpty(objLDVRApplyTemplateResponseVO.getExcludedAssets()))
                    result=sdf.format(new Date()) +logMsgTxt+objLDVRApplyTemplateResponseVO.getExcludedAssets().get(0).getReason();
                   
            
            }else{
                result=sdf.format(new Date()) +"  :: AGT ::" +RMDCommonConstants.NO_DATA_FOUND_TO_APPLY_AGT;
            }
            
            
        }catch(RMDWebException e){
            rmdWebLogger.error("Exception occured in applyAGTTemplate() ",
                    e);
            result=sdf.format(new Date()) +"  :: AGT :: Error info :: "+e.getErrorType();
        }
        catch(Exception e){
            rmdWebLogger.error("Exception occured in applyAGTTemplate() ",
                    e);
            result=sdf.format(new Date()) +"  :: AGT :: Error "+e.getMessage();
            
        }
        
        return result;
    }

}
