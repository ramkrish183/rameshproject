package com.ge.trans.rmd.cm.valueobjects;

import com.ge.trans.rmd.common.vo.RMDBaseVO;

public class ToolTipVO extends RMDBaseVO{

	private String urgency;
	private String rxTitle;
	public String getUrgency() {
		return urgency;
	}
	public void setUrgency(final String urgency) {
		this.urgency = urgency;
	}
	public String getRxTitle() {
		return rxTitle;
	}
	public void setRxTitle(final String rxTitle) {
		this.rxTitle = rxTitle;
	}
}
