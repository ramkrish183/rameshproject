package com.ge.trans.rmd.cm.mvc.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.AutoHCTemplateService;
import com.ge.trans.rmd.cm.service.ConfigMaintenanceService;
import com.ge.trans.rmd.cm.service.ReportsService;
import com.ge.trans.rmd.cm.valueobjects.AutoHCTemplateDetails;
import com.ge.trans.rmd.cm.valueobjects.EDPHeaderDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.EDPParamDetailsVO;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.valueobjects.TruckVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Controller
@SessionAttributes
public class AutoHCTemplateController extends RMDBaseController  {

    private final RMDWebLogger rmdWebLogger = RMDWebLogger
            .getLogger(getClass());
    
    @Autowired
    AutoHCTemplateService autoHCTemplateService;
    @Autowired
	ConfigMaintenanceService configMaintenanceService;

    @RequestMapping(AppConstants.REQ_URI_AUTO_HC_TEMPLATE)
    public ModelAndView showAutoHCTemplateScreen(
            final HttpServletRequest request) throws RMDWebException {
    	
    	EDPHeaderDetailsVO templateHeader = null;
    	Map<String,String> tempDet = new LinkedHashMap<String, String>();
    	String ctrlCfgName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CTRL_CFG_NAME));
		String ctrlCfgObjId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CTRL_CFG_OBJ_ID));
		String cfgFileName = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.CFG_FILE_NAME));
		String tempObjId = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.TEMP_OBJ_ID));
		String templateNo = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.TEMPLATE_NO));
		String versionNo = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.VERSION_NO));
		String title = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.TITLE));
		
		String status = new String();
		tempDet = autoHCTemplateService.getComAHCDetails(
				 templateNo, versionNo, ctrlCfgObjId);
		
		
		
		templateHeader = configMaintenanceService.getPreNextEDPDetails(
				cfgFileName, templateNo, versionNo, ctrlCfgObjId);
		if(!RMDCommonUtility.isNullOrEmpty(templateHeader.getStatus())){
			status = templateHeader.getStatus();
		}
		String maxVersion = configMaintenanceService.getTempMaxVerNumber(
				ctrlCfgObjId, cfgFileName, templateNo);
		if(!RMDCommonUtility.isNullOrEmpty(maxVersion)){
			request.setAttribute(AppConstants.MAX_VERSION, EsapiUtil.stripXSSCharacters(maxVersion));
		}
		request.setAttribute(AppConstants.CTRL_CFG_NAME, EsapiUtil.stripXSSCharacters(ctrlCfgName));
		request.setAttribute(AppConstants.CTRL_CFG_OBJ_ID, EsapiUtil.stripXSSCharacters(ctrlCfgObjId));
		request.setAttribute(AppConstants.CFG_FILE_NAME, EsapiUtil.stripXSSCharacters(cfgFileName));
		request.setAttribute(AppConstants.TEMP_OBJ_ID, EsapiUtil.stripXSSCharacters(tempObjId));
		request.setAttribute(AppConstants.TEMPLATE_NO, EsapiUtil.stripXSSCharacters(templateNo));
		request.setAttribute(AppConstants.VERSION_NO, EsapiUtil.stripXSSCharacters(versionNo));
		request.setAttribute(AppConstants.TITLE, EsapiUtil.stripXSSCharacters(title));
		request.setAttribute(AppConstants.STATUS, EsapiUtil.stripXSSCharacters(status));
		request.setAttribute(AppConstants.AH_FREQUENCY, EsapiUtil.stripXSSCharacters(tempDet.get(AppConstants.AH_FREQUENCY)));
		request.setAttribute(AppConstants.AH_POST_SAMPLES, EsapiUtil.stripXSSCharacters(tempDet.get(AppConstants.AH_POST_SAMPLES)));
		request.setAttribute(AppConstants.AH_SAMPLE_RATE, EsapiUtil.stripXSSCharacters(tempDet.get(AppConstants.AH_SAMPLE_RATE)));
		request.setAttribute(AppConstants.AH_FCRT_OBJID, EsapiUtil.stripXSSCharacters(tempDet.get(AppConstants.AH_FCRT_OBJID)));
		request.setAttribute(AppConstants.AH_EDP_TEMP_OBJID, EsapiUtil.stripXSSCharacters(tempDet.get(AppConstants.AH_TEMPLATE_OBJ_ID)));
		request.setAttribute(AppConstants.IS_OPEN_TEMPLATE, true);
		request.setAttribute(
				AppConstants.AHC_MAX_PARAMS,
				findNumberOfRecords(AppConstants.MAX_CONFIG_FILE_PARAMS_ALLOWED));
        return new ModelAndView(AppConstants.AUTO_HC_TEMPLATE);
    }
    
    @RequestMapping(value = AppConstants.TEMPLATE_DATA)
	@ResponseBody
	public List<String> getTemplateDropDwn(
			@RequestParam(value = AppConstants.CTRL_CONFIG_HC) final String ctrlConfig,
			@RequestParam(value = AppConstants.CONFIG_FILE_HC) final String configFile,
			final HttpServletRequest request) throws RMDWebException {
    	List<String> tempInfo = new ArrayList<String>();
		try{
			tempInfo = autoHCTemplateService.getTemplateDropDwn(EsapiUtil.stripXSSCharacters(ctrlConfig), EsapiUtil.stripXSSCharacters(configFile));
		} catch (Exception ex) {
			rmdWebLogger
			.error("Exception occured in getTemplateDropDwn  method in AutoHCTemplateController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return tempInfo;
	}
    
    @RequestMapping(value = AppConstants.FAULT_CODE_REC_TYPE_DATA)
	@ResponseBody
	public List<String> getFaultCodeRecTypeDropDwn(
			@RequestParam(value = AppConstants.CTRL_CONFIG_HC) final String ctrlConfig,
			@RequestParam(value = AppConstants.CONFIG_FILE_HC) final String configFile,
			final HttpServletRequest request) throws RMDWebException {
    	List<String> tempInfo = new ArrayList<String>();
		try{
			tempInfo = autoHCTemplateService.getFaultCodeRecTypeDropDwn(EsapiUtil.stripXSSCharacters(ctrlConfig), EsapiUtil.stripXSSCharacters(configFile));
		} catch (Exception ex) {
			rmdWebLogger
			.error("Exception occured in getFaultCodeRecTypeDropDwn  method in AutoHCTemplateController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return tempInfo;
	}
    
    @RequestMapping(value = AppConstants.MSG_DEF_ID_DATA)
	@ResponseBody
	public List<String> getMessageDefIdDropDwn(
			final HttpServletRequest request) throws RMDWebException {
    	List<String> tempInfo = new ArrayList<String>();
		try{
			tempInfo = autoHCTemplateService.getMessageDefIdDropDwn();
		} catch (Exception ex) {
			rmdWebLogger
			.error("Exception occured in getMessageDefIdDropDwn  method in AutoHCTemplateController",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return tempInfo;
	}
    @RequestMapping(AppConstants.REQ_URI_AHC_NEW_TEMPLATE)
    public ModelAndView showAutoHCNewTemplateScreen(
            final HttpServletRequest request) throws RMDWebException {
    	
    	Map<String, String> components = new HashMap<String, String>();
		components.put(AppConstants.CONFIG_VALUE,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CONFIG_VALUE)));
		components.put(AppConstants.CONFIG_ID,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CONFIG_ID)));
		components.put(AppConstants.TEMPLATE_ID,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TEMPLATE_ID)));
		components.put(AppConstants.VERSION_ID,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.VERSION_ID)));
		components.put(AppConstants.TITLE,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TITLE)));
		components.put(AppConstants.STATUS,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.STATUS)));
		components.put(AppConstants.CONFIG_FILE,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.CONFIG_FILE)));
		components.put(AppConstants.FLAG,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.FLAG)));
		components.put(AppConstants.TEMP_OBJ_ID,
		        EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.TEMP_OBJ_ID)));
		request.setAttribute(AppConstants.DATASET, components);
		
        return new ModelAndView(AppConstants.AUTO_HC_TEMPLATE);
    }
    
    @RequestMapping(value = AppConstants.REQ_URI_POST_NEW_TEMPLATE_DETAILS, method = RequestMethod.POST)
	@ResponseBody
	public String postAutoHCNewTemplate(
			
			@RequestParam(value = AppConstants.AH_TEMPLATE_OBJ_ID) final String tempObjId,
			@RequestParam(value = AppConstants.AH_SAMPLE_RATE) final String sampleRate,
			@RequestParam(value = AppConstants.AH_POST_SAMPLES) final String postSamples,
			@RequestParam(value = AppConstants.AH_FREQUENCY) final String frequency,
			@RequestParam(value = AppConstants.AH_FCRT_OBJID) final String fcrtObjid,
			@RequestParam(value = AppConstants.AH_TEMPLATE_NO) final String templateNo,
			@RequestParam(value = AppConstants.AH_VERSION_NO) final String versionNo,
			@RequestParam(value = AppConstants.AH_TITLE) final String title,
			@RequestParam(value = AppConstants.AH_STATUS) final String status,
			@RequestParam(value = AppConstants.AH_CTRL_CONFIG_OBJID) final String configCtrlObjid,
			
			final HttpServletRequest request) throws RMDWebException {
    		String result = new String();
    		AutoHCTemplateDetails tempDet = new AutoHCTemplateDetails();
    		try {

    			if (!RMDCommonUtility.isNullOrEmpty(tempObjId)) {
    				tempDet.setTempObjId(EsapiUtil
    						.stripXSSCharacters(tempObjId));
    			}
    			if (!RMDCommonUtility.isNullOrEmpty(sampleRate)) {
    				tempDet.setSampleRate(EsapiUtil
    						.stripXSSCharacters(sampleRate));
    			}
    			if (!RMDCommonUtility.isNullOrEmpty(postSamples)) {
    				tempDet.setPostSamples(EsapiUtil
    						.stripXSSCharacters(postSamples));
    			}
    			if (!RMDCommonUtility.isNullOrEmpty(frequency)) {
    				tempDet.setFrequency(EsapiUtil
    						.stripXSSCharacters(frequency));
    			}
    			if (!RMDCommonUtility.isNullOrEmpty(fcrtObjid)) {
    				tempDet.setFcrtObjid(EsapiUtil
    						.stripXSSCharacters(fcrtObjid));
    			}
    			if (!RMDCommonUtility.isNullOrEmpty(templateNo)) {
    				tempDet.setTemplateNo(EsapiUtil
    						.stripXSSCharacters(templateNo));
    			}
    			if (!RMDCommonUtility.isNullOrEmpty(versionNo)) {
    				tempDet.setVersionNo(EsapiUtil
    						.stripXSSCharacters(versionNo));
    			}
    			if (!RMDCommonUtility.isNullOrEmpty(title)) {
    				tempDet.setTitle(EsapiUtil
    						.stripXSSCharacters(title));
    			}
    			if (!RMDCommonUtility.isNullOrEmpty(status)) {
    				tempDet.setStatus(EsapiUtil
    						.stripXSSCharacters(status));
    			}
    			if (!RMDCommonUtility.isNullOrEmpty(configCtrlObjid)) {
    				tempDet.setConfigCtrlObjid(EsapiUtil
    						.stripXSSCharacters(configCtrlObjid));
    			}

    			result = autoHCTemplateService.postAutoHCNewTemplate(tempDet);
    					

    		} catch (Exception ex) {
    			rmdWebLogger
    					.error("Exception occured in postAutoHCNewTemplate method of autoHCTemplateController",
    							ex);
    			RMDWebErrorHandler.handleException(ex);
    		}

    		
    		return result;
    }
    
    @RequestMapping(value = AppConstants.GET_COMPLETE_AHC_DATA)
   	@ResponseBody
   	public Map<String,String> getComAHCDetails(
   			@RequestParam(value = AppConstants.AH_TEMPLATE_NO) final String templateNo,
			@RequestParam(value = AppConstants.AH_VERSION_NO) final String versionNo,
			@RequestParam(value = AppConstants.CTRL_CFG_OBJ_ID) final String ctrlCfgObjId,
			final HttpServletRequest request) throws RMDWebException {
       	Map<String,String> tempInfo = new HashMap<String, String>();
   		try{
   			tempInfo = autoHCTemplateService.getComAHCDetails(
   				 templateNo, versionNo, ctrlCfgObjId);
   		} catch (Exception ex) {
   			rmdWebLogger
   			.error("Exception occured in getComAHCDetails  method in AutoHCTemplateController",
   					ex);
   			RMDWebErrorHandler.handleException(ex);
   		}
   		return tempInfo;
   	}
}
