package com.ge.trans.rmd.cm.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ge.trans.rmd.cm.valueobjects.AddRemoveSecondarySiteVO;
import com.ge.trans.rmd.cm.valueobjects.AddressDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.AddressSearchVO;
import com.ge.trans.rmd.cm.valueobjects.ContactDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.ContactSearchVO;
import com.ge.trans.rmd.cm.valueobjects.ContactSiteDetailsVO;
import com.ge.trans.rmd.cm.valueobjects.SiteDetailsVO;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.service.CachedService;
import com.ge.trans.rmd.common.service.RMDBaseServiceImpl;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.util.ServiceConstants;
import com.ge.trans.rmd.common.util.WebServiceInvoker;
import com.ge.trans.rmd.services.admin.valueobjects.ApplicationParametersResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.AddEditAddressRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.AddRemoveSecondarySiteRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.AddUpdateContactRequestType;
import com.ge.trans.rmd.services.assets.valueobjects.AddressDetailsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ContactDetailsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ContactSiteDetailsResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.ISDCodeResponseType;
import com.ge.trans.rmd.services.assets.valueobjects.SecondarySiteDetailsResponseType;
import com.ge.trans.rmd.utilities.RMDCommonUtility;

@Service
public class ContactSiteServiceImpl extends RMDBaseServiceImpl implements
        ContactSiteService {

    private final RMDWebLogger rmdWebLogger = RMDWebLogger
            .getLogger(getClass());

    @Autowired
    private CachedService cachedService;
    @Autowired
    WebServiceInvoker webServiceInvoker;

    /**
     * 
     * @param objContactSearchVO
     * @return List<ContactDetailsVO>
     * @throws RMDWebException
     * @Description This method is used to get the contact details for the given
     *              search combination.
     * 
     */
    @Override
    public List<ContactDetailsVO> getContacts(ContactSearchVO objContactSearchVO)
            throws RMDWebException {
        List<ContactDetailsVO> contactDetailsVOList = null;
        ContactDetailsResponseType[] arrContactDetailsResponseType = null;
        Map<String, String> queryParamMap = null;
        ContactDetailsVO objContactDetailsVO = null;

        try {

            queryParamMap = new LinkedHashMap<String, String>();
            queryParamMap.put(AppConstants.FIRST_NAME,
                    objContactSearchVO.getFirstName());
            queryParamMap.put(AppConstants.LAST_NAME,
                    objContactSearchVO.getLastName());
            queryParamMap.put(AppConstants.PH_NO, objContactSearchVO.getPhNo());
            queryParamMap.put(AppConstants.SITE_ID,
                    objContactSearchVO.getSiteId());
            queryParamMap.put(AppConstants.SITE_NAME,
                    objContactSearchVO.getSiteName());
            queryParamMap.put(AppConstants.CONTACT_STATUS,
                    objContactSearchVO.getContactStatus());
            arrContactDetailsResponseType = (ContactDetailsResponseType[]) webServiceInvoker
                    .get(ServiceConstants.GET_CONTACTS, null, queryParamMap,
                            null, ContactDetailsResponseType[].class);
            if (null != arrContactDetailsResponseType
                    && arrContactDetailsResponseType.length > 0) {
                contactDetailsVOList = new ArrayList<ContactDetailsVO>(
                        arrContactDetailsResponseType.length);
                for (ContactDetailsResponseType contactDetailsResponse : arrContactDetailsResponseType) {
                    objContactDetailsVO = new ContactDetailsVO();
                    objContactDetailsVO.setContactObjId(contactDetailsResponse
                            .getContactObjId());
                    objContactDetailsVO.setFirstName(contactDetailsResponse
                            .getFirstName());
                    objContactDetailsVO.setLastName(contactDetailsResponse
                            .getLastName());
                    objContactDetailsVO.setPhNo(contactDetailsResponse
                            .getPhNo());
                    objContactDetailsVO.setSiteName(contactDetailsResponse
                            .getSiteName());
                    objContactDetailsVO.setCity(contactDetailsResponse
                            .getCity());
                    objContactDetailsVO.setCountry(contactDetailsResponse
                            .getCountry());
                    objContactDetailsVO.setContactRole(contactDetailsResponse
                            .getContactRole());
                    contactDetailsVOList.add(objContactDetailsVO);
                    objContactDetailsVO = null;
                }
            }

        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getContacts() method of ContactSiteServiceImpl",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            queryParamMap = null;
            arrContactDetailsResponseType = null;
        }
        return contactDetailsVOList;
    }

    /**
     * 
     * @param contactObjId
     * @return ContactSiteDetailsVO
     * @throws RMDWebException
     * @Description This method is used to get the all details for the selected
     *              contact
     * 
     */
    @Override
    public ContactSiteDetailsVO viewContactDetails(String contactObjId)
            throws RMDWebException {
        ContactSiteDetailsResponseType objContactSiteDetailsResponseType = null;
        Map<String, String> queryParamMap = null;
        ContactSiteDetailsVO objContactSiteDetailsVO = null;
        try {
            queryParamMap = new LinkedHashMap<String, String>();
            queryParamMap.put(AppConstants.CONTACT_OBJID, contactObjId);
            objContactSiteDetailsResponseType = (ContactSiteDetailsResponseType) webServiceInvoker
                    .get(ServiceConstants.VIEW_CONTACT_DETAILS, null,
                            queryParamMap, null,
                            ContactSiteDetailsResponseType.class);
            if (null != objContactSiteDetailsResponseType) {
                objContactSiteDetailsVO = new ContactSiteDetailsVO();
                objContactSiteDetailsVO
                        .setContactObjId(objContactSiteDetailsResponseType
                                .getContactObjId());
                objContactSiteDetailsVO
                        .setJobTitle(objContactSiteDetailsResponseType
                                .getJobTitle());
                objContactSiteDetailsVO
                        .setContactStatus(objContactSiteDetailsResponseType
                                .getContactStatus());
                objContactSiteDetailsVO
                        .setFirstName(objContactSiteDetailsResponseType
                                .getFirstName());
                objContactSiteDetailsVO
                        .setLastName(objContactSiteDetailsResponseType
                                .getLastName());
                objContactSiteDetailsVO
                        .setPhNo(objContactSiteDetailsResponseType.getPhNo());
                objContactSiteDetailsVO
                        .setFax(objContactSiteDetailsResponseType.getFax());
                objContactSiteDetailsVO
                        .setEmailId(objContactSiteDetailsResponseType
                                .getEmailId());
                objContactSiteDetailsVO
                        .setTimeZone(objContactSiteDetailsResponseType
                                .getTimeZone());
                objContactSiteDetailsVO
                        .setSiteId(objContactSiteDetailsResponseType
                                .getSiteId());
                objContactSiteDetailsVO
                        .setSiteName(objContactSiteDetailsResponseType
                                .getSiteName());
                objContactSiteDetailsVO
                        .setSiteType(objContactSiteDetailsResponseType
                                .getSiteType());
                objContactSiteDetailsVO
                        .setAddress1(objContactSiteDetailsResponseType
                                .getAddress1());
                objContactSiteDetailsVO
                        .setAddress2(objContactSiteDetailsResponseType
                                .getAddress2());
                objContactSiteDetailsVO
                        .setCity(objContactSiteDetailsResponseType.getCity());
                objContactSiteDetailsVO
                        .setState(objContactSiteDetailsResponseType.getState());
                objContactSiteDetailsVO
                        .setCountry(objContactSiteDetailsResponseType
                                .getCountry());
                objContactSiteDetailsVO
                        .setZipCode(objContactSiteDetailsResponseType
                                .getZipCode());
                objContactSiteDetailsVO
                        .setSalutation(objContactSiteDetailsResponseType
                                .getSalutation());
                objContactSiteDetailsVO
                        .setContactRole(objContactSiteDetailsResponseType
                                .getContactRole());
                objContactSiteDetailsVO
                        .setDailComm(objContactSiteDetailsResponseType
                                .getDailComm());
                objContactSiteDetailsVO
                        .setHomePh(objContactSiteDetailsResponseType
                                .getHomePh());
                objContactSiteDetailsVO
                        .setCellPh(objContactSiteDetailsResponseType
                                .getCellPh());
                objContactSiteDetailsVO
                        .setLocObjId(objContactSiteDetailsResponseType
                                .getLocObjId());
                objContactSiteDetailsVO
                        .setVoiceMail(objContactSiteDetailsResponseType
                                .getVoiceMail());
            }

        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getContacts() method of ContactSiteServiceImpl",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            queryParamMap = null;
            objContactSiteDetailsResponseType = null;
        }
        return objContactSiteDetailsVO;
    }

    /**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:RMDWebException
     * @Description: This method is used for fetching the contact status
     */
    @Override
    public Map<String, String> getContactStatus() throws RMDWebException {
        Map<String, String> contactStatusMap = new LinkedHashMap<String, String>();
        Map<String, String> pathParams = new LinkedHashMap<String, String>();
        String contactStatus = null;
        ApplicationParametersResponseType[] applParamResponseType = null;
        try {
            pathParams.put(AppConstants.LIST_NAME,
                    AppConstants.CONTACT_STATUS_LIST);
            applParamResponseType = getLookupValue(pathParams);
            if (null != applParamResponseType) {
                contactStatusMap = new LinkedHashMap<String, String>(
                        applParamResponseType.length);
                for (int i = 0; i < applParamResponseType.length; i++) {
                    contactStatus = applParamResponseType[i].getLookupValue();
                    contactStatusMap.put(contactStatus, contactStatus);
                }
            }
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getContactStatus() method of ContactSiteServiceImpl ",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            applParamResponseType = null;
            pathParams = null;
        }
        return contactStatusMap;
    }

    /**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:RMDWebException
     * @Description: This method is used for fetching the contact roles
     */
    @Override
    public Map<String, String> getContactRoles() throws RMDWebException {
        Map<String, String> contactRolesMap = new LinkedHashMap<String, String>();
        Map<String, String> pathParams = new LinkedHashMap<String, String>();
        String contactRole = null;
        ApplicationParametersResponseType[] applParamResponseType = null;
        try {
            pathParams.put(AppConstants.LIST_NAME,
                    AppConstants.CONTACT_ROLE_LIST);
            applParamResponseType = getLookupValue(pathParams);
            if (null != applParamResponseType) {
                contactRolesMap = new LinkedHashMap<String, String>(
                        applParamResponseType.length);
                for (int i = 0; i < applParamResponseType.length; i++) {
                    contactRole = applParamResponseType[i].getLookupValue();
                    contactRolesMap.put(contactRole, contactRole);
                }
            }
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getContactRoles() method of ContactSiteServiceImpl ",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            applParamResponseType = null;
            pathParams = null;
        }
        return contactRolesMap;
    }

    /**
     * 
     * @param contactObjId
     * @return List<SiteDetailsVO>
     * @throws RMDWebException
     * @throws
     * @Description This method is used to get the secondary site details
     * 
     */
    public List<SiteDetailsVO> getContactSecondarySites(String contactObjId)
            throws RMDWebException {
        List<SiteDetailsVO> siteDetailsVOList = null;
        SecondarySiteDetailsResponseType[] arrSiteDetailsResponseType = null;
        Map<String, String> queryParamMap = null;
        SiteDetailsVO objSiteDetailsVO = null;
        try {
            queryParamMap = new LinkedHashMap<String, String>();
            queryParamMap.put(AppConstants.CONTACT_OBJID, contactObjId);
            arrSiteDetailsResponseType = (SecondarySiteDetailsResponseType[]) webServiceInvoker
                    .get(ServiceConstants.GET_CONTACT_SECONDARY_SITES, null,
                            queryParamMap, null,
                            SecondarySiteDetailsResponseType[].class);
            if (null != arrSiteDetailsResponseType
                    && arrSiteDetailsResponseType.length > 0) {
                siteDetailsVOList = new ArrayList<SiteDetailsVO>(
                        arrSiteDetailsResponseType.length);
                for (SecondarySiteDetailsResponseType siteDetailsResponse : arrSiteDetailsResponseType) {
                    objSiteDetailsVO = new SiteDetailsVO();
                    objSiteDetailsVO.setSiteObjId(siteDetailsResponse
                            .getSiteObjId());
                    objSiteDetailsVO.setContactRole(siteDetailsResponse
                            .getContactRole());
                    objSiteDetailsVO.setSiteId(siteDetailsResponse.getSiteId());
                    objSiteDetailsVO.setSiteName(siteDetailsResponse
                            .getSiteName());
                    objSiteDetailsVO.setAddress(siteDetailsResponse
                            .getAddress());
                    objSiteDetailsVO.setCity(siteDetailsResponse.getCity());
                    objSiteDetailsVO.setState(siteDetailsResponse.getState());
                    objSiteDetailsVO.setZipCode(siteDetailsResponse
                            .getZipCode());
                    siteDetailsVOList.add(objSiteDetailsVO);
                    objSiteDetailsVO = null;
                }
            }
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getContactSecondarySites() method of ContactSiteServiceImpl",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            queryParamMap = null;
            arrSiteDetailsResponseType = null;
        }
        return siteDetailsVOList;

    }

    /**
     * 
     * @param AddRemoveSecondarySiteVO
     * @return String
     * @throws RMDWebException
     * @Description This method is used to add the secondary site to a contact
     * 
     */
    public String addContactSecondarySite(
            AddRemoveSecondarySiteVO objAddRemoveSecondarySiteVO)
            throws RMDWebException {
        String status = AppConstants.FAILURE;        
        AddRemoveSecondarySiteRequestType objAddRemoveSecondarySiteRequestType = null;
        try {
            if (null != objAddRemoveSecondarySiteVO) {
                objAddRemoveSecondarySiteRequestType = new AddRemoveSecondarySiteRequestType();
                objAddRemoveSecondarySiteRequestType
                        .setContactObjId(objAddRemoveSecondarySiteVO
                                .getContactObjId());
                objAddRemoveSecondarySiteRequestType
                        .setSiteObjId(objAddRemoveSecondarySiteVO
                                .getSiteObjId());
                objAddRemoveSecondarySiteRequestType
                        .setContactRole(objAddRemoveSecondarySiteVO
                                .getContactRole());
                status = (String) (webServiceInvoker.post(
                        ServiceConstants.ADD_CONTACT_SECONDARY_SITE,
                        objAddRemoveSecondarySiteRequestType, String.class));
            }
        } catch (Exception ex) {
            status = AppConstants.FAILURE;
            rmdWebLogger
                    .error("Exception occured in getContactSecondarySites() method of ContactSiteServiceImpl",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            objAddRemoveSecondarySiteRequestType = null;

        }
        return status;

    }

    /**
     * 
     * @param List
     *            <AddRemoveSecondarySiteVO>
     * @return String
     * @throws RMDWebException
     * @Description This method is used to remove the secondary sites from the
     *              contact
     * 
     */
    @Override
    public String removeContactSecondarySite(
            List<AddRemoveSecondarySiteVO> removeSecondarySiteVOList)
            throws RMDWebException {
        String status = AppConstants.FAILURE;
        AddRemoveSecondarySiteRequestType addRemoveSecondarySiteRequestType = null;
        AddRemoveSecondarySiteRequestType objAddRemoveSecondarySiteRequestType = null;
        List<AddRemoveSecondarySiteRequestType> addRemoveSecondarySiteRequestTypeList = null;
        try {
            if (null != removeSecondarySiteVOList
                    && !removeSecondarySiteVOList.isEmpty()) {
                addRemoveSecondarySiteRequestTypeList = new ArrayList<AddRemoveSecondarySiteRequestType>(
                        removeSecondarySiteVOList.size());
                objAddRemoveSecondarySiteRequestType = new AddRemoveSecondarySiteRequestType();
                for (AddRemoveSecondarySiteVO objAddRemoveSecondarySiteVO : removeSecondarySiteVOList) {
                    addRemoveSecondarySiteRequestType = new AddRemoveSecondarySiteRequestType();
                    if (!RMDCommonUtility
                            .isNullOrEmpty(objAddRemoveSecondarySiteVO
                                    .getContactObjId())) {
                        addRemoveSecondarySiteRequestType
                                .setContactObjId(objAddRemoveSecondarySiteVO
                                        .getContactObjId());
                    }
                    if (!RMDCommonUtility
                            .isNullOrEmpty(objAddRemoveSecondarySiteVO
                                    .getSiteObjId())) {
                        addRemoveSecondarySiteRequestType
                                .setSiteObjId(objAddRemoveSecondarySiteVO
                                        .getSiteObjId());
                    }
                    if (!RMDCommonUtility
                            .isNullOrEmpty(objAddRemoveSecondarySiteVO
                                    .getContactRole())) {
                        addRemoveSecondarySiteRequestType
                                .setContactRole(objAddRemoveSecondarySiteVO
                                        .getContactRole());
                    }
                    addRemoveSecondarySiteRequestTypeList
                            .add(addRemoveSecondarySiteRequestType);
                    addRemoveSecondarySiteRequestType = null;
                }
                objAddRemoveSecondarySiteRequestType
                        .setArlAddRemoveSecondarySiteRequestType(addRemoveSecondarySiteRequestTypeList);
                status = (String) (webServiceInvoker.post(
                        ServiceConstants.REMOVE_CONTACT_SECONDARY_SITE,
                        objAddRemoveSecondarySiteRequestType, String.class));

            }
        } catch (Exception ex) {
            status = AppConstants.FAILURE;
            rmdWebLogger
                    .error("Exception occured in removeContactSecondarySite() method of ContactSiteServiceImpl",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            objAddRemoveSecondarySiteRequestType = null;
            addRemoveSecondarySiteRequestTypeList = null;

        }
        return status;
    }

    /**
     * 
     * @param ContactSiteDetailsVO
     * @return String
     * @throws RMDWebException
     * @Description This method is used to add or update the Contact details
     * 
     */
    @Override
    public String addOrUpdateContact(
            ContactSiteDetailsVO objContactSiteDetailsVO)
            throws RMDWebException {
        String status = AppConstants.FAILURE;
        AddUpdateContactRequestType objAddUpdateContactRequestType = null;
        try {
            if (null != objContactSiteDetailsVO) {
                objAddUpdateContactRequestType = new AddUpdateContactRequestType();
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getContactObjId())) {
                    objAddUpdateContactRequestType
                            .setContactObjId(objContactSiteDetailsVO
                                    .getContactObjId());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getJobTitle())) {
                    objAddUpdateContactRequestType
                            .setJobTitle(objContactSiteDetailsVO.getJobTitle());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getContactStatus())) {
                    objAddUpdateContactRequestType
                            .setContactStatus(objContactSiteDetailsVO
                                    .getContactStatus());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getFirstName())) {
                    objAddUpdateContactRequestType
                            .setFirstName(objContactSiteDetailsVO
                                    .getFirstName());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getLastName())) {
                    objAddUpdateContactRequestType
                            .setLastName(objContactSiteDetailsVO.getLastName());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getPhNo())) {
                    objAddUpdateContactRequestType
                            .setPhNo(objContactSiteDetailsVO.getPhNo());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getFax())) {
                    objAddUpdateContactRequestType
                            .setFax(objContactSiteDetailsVO.getFax());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getEmailId())) {
                    objAddUpdateContactRequestType
                            .setEmailId(objContactSiteDetailsVO.getEmailId());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getTimeZone())) {
                    objAddUpdateContactRequestType
                            .setTimeZone(objContactSiteDetailsVO.getTimeZone());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getSiteId())) {
                    objAddUpdateContactRequestType
                            .setSiteId(objContactSiteDetailsVO.getSiteId());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getSiteName())) {
                    objAddUpdateContactRequestType
                            .setSiteName(objContactSiteDetailsVO.getSiteName());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getSiteType())) {
                    objAddUpdateContactRequestType
                            .setSiteType(objContactSiteDetailsVO.getSiteType());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getAddress1())) {
                    objAddUpdateContactRequestType
                            .setAddress1(objContactSiteDetailsVO.getAddress1());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getAddress2())) {
                    objAddUpdateContactRequestType
                            .setAddress2(objContactSiteDetailsVO.getAddress2());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getCity())) {
                    objAddUpdateContactRequestType
                            .setCity(objContactSiteDetailsVO.getCity());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getState())) {
                    objAddUpdateContactRequestType
                            .setState(objContactSiteDetailsVO.getState());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getCountry())) {
                    objAddUpdateContactRequestType
                            .setCountry(objContactSiteDetailsVO.getCountry());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getZipCode())) {
                    objAddUpdateContactRequestType
                            .setZipCode(objContactSiteDetailsVO.getZipCode());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getSalutation())) {
                    objAddUpdateContactRequestType
                            .setSalutation(objContactSiteDetailsVO
                                    .getSalutation());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getContactRole())) {
                    objAddUpdateContactRequestType
                            .setContactRole(objContactSiteDetailsVO
                                    .getContactRole());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getDailComm())) {
                    objAddUpdateContactRequestType
                            .setDailComm(objContactSiteDetailsVO.getDailComm());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getHomePh())) {
                    objAddUpdateContactRequestType
                            .setHomePh(objContactSiteDetailsVO.getHomePh());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getCellPh())) {
                    objAddUpdateContactRequestType
                            .setCellPh(objContactSiteDetailsVO.getCellPh());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getLocObjId())) {
                    objAddUpdateContactRequestType
                            .setLocObjId(objContactSiteDetailsVO.getLocObjId());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getVoiceMail())) {
                    objAddUpdateContactRequestType
                            .setVoiceMail(objContactSiteDetailsVO
                                    .getVoiceMail());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getCreater())) {
                    objAddUpdateContactRequestType
                            .setCreater(objContactSiteDetailsVO.getCreater());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getActionFrom())) {
                    objAddUpdateContactRequestType
                            .setActionFrom(objContactSiteDetailsVO
                                    .getActionFrom());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getCheckDupContact())) {
                    objAddUpdateContactRequestType
                            .setCheckDupContact(objContactSiteDetailsVO
                                    .getCheckDupContact());
                }
                objAddUpdateContactRequestType
                        .setRoleChanged(objContactSiteDetailsVO.isRoleChanged());
                objAddUpdateContactRequestType
                        .setSiteChanged(objContactSiteDetailsVO.isSiteChanged());
                if (!RMDCommonUtility.isNullOrEmpty(objContactSiteDetailsVO
                        .getOldLocObjId())) {
                    objAddUpdateContactRequestType
                            .setOldLocObjId(objContactSiteDetailsVO
                                    .getOldLocObjId());
                }

                status = (String) (webServiceInvoker.post(
                        ServiceConstants.ADD_OR_UPDATE_CONTACT,
                        objAddUpdateContactRequestType, String.class));

            }

        } catch (Exception ex) {
            status = AppConstants.FAILURE;
            rmdWebLogger
                    .error("Exception occured in addOrUpdateContact() method of ContactSiteServiceImpl",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            objAddUpdateContactRequestType = null;

        }
        return status;
    }

    /**
     * @Author:
     * @param:
     * @return:Map<String, String>
     * @throws:RMDWebException
     * @Description: This method is used for fetching the address search filter
     *               options
     */
    @Override
    public Map<String, String> getAddressFilterOptions() throws RMDWebException {
        Map<String, String> filterMap = new LinkedHashMap<String, String>();
        Map<String, String> pathParams = new LinkedHashMap<String, String>();
        String filterOption = null;
        ApplicationParametersResponseType[] applParamResponseType = null;
        try {
            pathParams.put(AppConstants.LIST_NAME,
                    AppConstants.ADDRESS_FILTER_LIST);
            applParamResponseType = getLookupValue(pathParams);
            if (null != applParamResponseType) {
                filterMap = new LinkedHashMap<String, String>(
                        applParamResponseType.length);
                for (int i = 0; i < applParamResponseType.length; i++) {
                    filterOption = applParamResponseType[i].getLookupValue();
                    filterMap.put(filterOption, filterOption);
                }
            }
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getAddressFilterOptions() method of ContactSiteServiceImpl ",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            applParamResponseType = null;
            pathParams = null;
        }
        return filterMap;
    }

    /**
     * 
     * @param
     * @return List<AddressDetailsVO>
     * @throws RMDWebException
     * @Description This method is used to get the address details for the given
     *              search combination.
     * 
     */
    @Override
    public List<AddressDetailsVO> getAddress(AddressSearchVO objAdressSearchVO)
            throws RMDWebException {
        List<AddressDetailsVO> addressDetailsVOList = null;
        AddressDetailsResponseType[] arrAddressDetailsResponseType = null;
        Map<String, String> queryParamMap = null;
        AddressDetailsVO objAddressDetailsVO = null;

        try {

            queryParamMap = new LinkedHashMap<String, String>();
            queryParamMap.put(AppConstants.ADDRESS,
                    objAdressSearchVO.getAddress());
            queryParamMap.put(AppConstants.CITY, objAdressSearchVO.getCity());
            queryParamMap.put(AppConstants.STATE, objAdressSearchVO.getState());
            queryParamMap.put(AppConstants.ZIP_CODE,
                    objAdressSearchVO.getZipCode());
            queryParamMap.put(AppConstants.ADDRESS_FILTER,
                    objAdressSearchVO.getAddrFilter());
            queryParamMap.put(AppConstants.CITY_FILTER,
                    objAdressSearchVO.getCityFilter());
            queryParamMap.put(AppConstants.STATE_FILTER,
                    objAdressSearchVO.getStateFilter());
            queryParamMap.put(AppConstants.ZIPCODE_FILTER,
                    objAdressSearchVO.getZipCodeFilter());
            arrAddressDetailsResponseType = (AddressDetailsResponseType[]) webServiceInvoker
                    .get(ServiceConstants.GET_ADDRESS, null, queryParamMap,
                            null, AddressDetailsResponseType[].class);
            if (null != arrAddressDetailsResponseType
                    && arrAddressDetailsResponseType.length > 0) {
                addressDetailsVOList = new ArrayList<AddressDetailsVO>(
                        arrAddressDetailsResponseType.length);
                for (AddressDetailsResponseType addrDetailsResponse : arrAddressDetailsResponseType) {
                    objAddressDetailsVO = new AddressDetailsVO();
                    objAddressDetailsVO
                            .setObjId(addrDetailsResponse.getObjId());
                    objAddressDetailsVO.setAddress1(addrDetailsResponse
                            .getAddress1());
                    objAddressDetailsVO.setAddress2(addrDetailsResponse
                            .getAddress2());
                    objAddressDetailsVO.setCity(addrDetailsResponse.getCity());
                    objAddressDetailsVO
                            .setState(addrDetailsResponse.getState());
                    objAddressDetailsVO.setZipCode(addrDetailsResponse
                            .getZipCode());
                    objAddressDetailsVO.setCountry(addrDetailsResponse
                            .getCountry());
                    addressDetailsVOList.add(objAddressDetailsVO);
                    objAddressDetailsVO = null;
                }
            }

        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getAddress() method of ContactSiteServiceImpl",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            queryParamMap = null;
            arrAddressDetailsResponseType = null;
        }
        return addressDetailsVOList;
    }

    /**
     * 
     * @param addrObjId
     * @return AddressDetailsVO
     * @throws RMDWebException
     * @Description This method is used to get the all details for the selected
     *              address
     * 
     */
    @Override
    public AddressDetailsVO viewAddressDetails(String addrObjId)
            throws RMDWebException {
        AddressDetailsResponseType objAddressDetailsResponseType = null;
        Map<String, String> queryParamMap = null;
        AddressDetailsVO objAddressDetailsVO = null;
        try {
            queryParamMap = new LinkedHashMap<String, String>();
            queryParamMap.put(AppConstants.ADDRESS_OBJID, addrObjId);
            objAddressDetailsResponseType = (AddressDetailsResponseType) webServiceInvoker
                    .get(ServiceConstants.VIEW_ADDRESS_DETAILS, null,
                            queryParamMap, null,
                            AddressDetailsResponseType.class);
            if (null != objAddressDetailsResponseType) {
                objAddressDetailsVO = new AddressDetailsVO();
                objAddressDetailsVO.setObjId(objAddressDetailsResponseType
                        .getObjId());
                objAddressDetailsVO.setAddress1(objAddressDetailsResponseType
                        .getAddress1());
                objAddressDetailsVO.setAddress2(objAddressDetailsResponseType
                        .getAddress2());
                objAddressDetailsVO.setCity(objAddressDetailsResponseType
                        .getCity());
                objAddressDetailsVO.setState(objAddressDetailsResponseType
                        .getState());
                objAddressDetailsVO.setCountry(objAddressDetailsResponseType
                        .getCountry());
                objAddressDetailsVO.setZipCode(objAddressDetailsResponseType
                        .getZipCode());
                objAddressDetailsVO.setTimeZone(objAddressDetailsResponseType
                        .getTimeZone());

            }
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in viewAddressDetails() method of ContactSiteServiceImpl",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            queryParamMap = null;
            objAddressDetailsResponseType = null;
        }
        return objAddressDetailsVO;
    }

    /**
     * 
     * @param
     * @return List<String>
     * @throws RMDWebException
     * @Description This method is used to get the all country List
     * 
     */
    @Override
    public List<String> getCountryList() throws RMDWebException {
        List<String> arlCountryList = null;
        try {
            arlCountryList = cachedService.getCountryList();
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getCountryList() method of ContactSiteServiceImpl",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return arlCountryList;
    }

    /**
     * 
     * @param String
     *            country
     * @return List<String>
     * @throws RMDWebException
     * @Description This method is used to get the states for the selected
     *              Country
     * 
     */
    @Override
    public List<String> getCountryStates(String country) throws RMDWebException {
        List<String> arlStateList = null;
        try {
            arlStateList = cachedService.getCountryStates(country);
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getCountryStates() method of ContactSiteServiceImpl",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return arlStateList;
    }

    /**
     * 
     * @param String
     *            country
     * @return List<String>
     * @throws RMDWebException
     * @Description This method is used to get the time zones for the selected
     *              Country
     * 
     */
    @Override
    public List<String> getCountryTimeZones(String country)
            throws RMDWebException {
        List<String> arlTimeZoneList = null;
        try {
            arlTimeZoneList = cachedService.getCountryTimeZones(country);
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getCountryTimeZones() method of ContactSiteServiceImpl",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return arlTimeZoneList;
    }

    /**
     * 
     * @param AddressDetailsVO
     * @return String
     * @throws RMDWebException
     * @Description This method is used to add or update the Address details
     * 
     */
    @Override
    public String addOrUpdateAddress(AddressDetailsVO objAddressDetailsVO)
            throws RMDWebException {
        String status = AppConstants.FAILURE;
        AddEditAddressRequestType objAddEditAddressRequestType = null;
        try {
            if (null != objAddressDetailsVO) {
                objAddEditAddressRequestType = new AddEditAddressRequestType();
                if (!RMDCommonUtility.isNullOrEmpty(objAddressDetailsVO
                        .getObjId())) {
                    objAddEditAddressRequestType.setObjId(objAddressDetailsVO
                            .getObjId());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objAddressDetailsVO
                        .getAddress1())) {
                    objAddEditAddressRequestType
                            .setAddress1(objAddressDetailsVO.getAddress1());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objAddressDetailsVO
                        .getAddress2())) {
                    objAddEditAddressRequestType
                            .setAddress2(objAddressDetailsVO.getAddress2());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objAddressDetailsVO
                        .getCity())) {
                    objAddEditAddressRequestType.setCity(objAddressDetailsVO
                            .getCity());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objAddressDetailsVO
                        .getState())) {
                    objAddEditAddressRequestType.setState(objAddressDetailsVO
                            .getState());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objAddressDetailsVO
                        .getCountry())) {
                    objAddEditAddressRequestType.setCountry(objAddressDetailsVO
                            .getCountry());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objAddressDetailsVO
                        .getTimeZone())) {
                    objAddEditAddressRequestType
                            .setTimeZone(objAddressDetailsVO.getTimeZone());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objAddressDetailsVO
                        .getZipCode())) {
                    objAddEditAddressRequestType.setZipCode(objAddressDetailsVO
                            .getZipCode());
                }
                if (!RMDCommonUtility.isNullOrEmpty(objAddressDetailsVO
                        .getFromScreen())) {
                    objAddEditAddressRequestType
                            .setFromScreen(objAddressDetailsVO.getFromScreen());
                }

                status = (String) (webServiceInvoker.post(
                        ServiceConstants.ADD_OR_UPDATE_ADDRESS,
                        objAddEditAddressRequestType, String.class));

            }

        } catch (Exception ex) {
            status = AppConstants.FAILURE;
            rmdWebLogger
                    .error("Exception occured in addOrUpdateAddress() method of ContactSiteServiceImpl",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        } finally {
            objAddEditAddressRequestType = null;

        }
        return status;
    }

    /**
     * @Author:
     * @param:
     * @return 
     * @return:Map<String, String>
     * @throws:RMDWebException
     * @Description: This method is used for fetching the ISD code list
     */
	@Override
    public  Map<String, String> getContactISDList() throws RMDWebException {
    	ISDCodeResponseType[] contactISDArr = null;
    	Map<String, String> responseMap = new LinkedHashMap<String, String>();
    	try {
        	contactISDArr = (ISDCodeResponseType[]) webServiceInvoker.get(
					ServiceConstants.GET_ISD_CODE, null, null, null,
					ISDCodeResponseType[].class);
        	for(ISDCodeResponseType contactISD: contactISDArr){
        		responseMap.put(contactISD.getCountryName(), contactISD.getIsdCode());
        	}
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getContactISDList() method of ContactSiteServiceImpl ",
                            ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return responseMap;
    }
}
