/**
 * 
 */
package com.ge.trans.rmd.cm.valueobjects;

/**
 * @author MSHIRAJUDDIN
 *
 */
public class LDVRAssetTempReapplyRemoveStatusVO {
	
	private String actionType;
	private ResponseStatusVO responseStatusVO;	


		
	/**
	 * @return the actionType
	 */
	public String getActionType() {
		return actionType;
	}
	/**
	 * @param actionType the actionType to set
	 */
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	/**
	 * @return the responseStatusVO
	 */
	public ResponseStatusVO getResponseStatusVO() {
		return responseStatusVO;
	}
	/**
	 * @param responseStatusVO the responseStatusVO to set
	 */
	public void setResponseStatusVO(ResponseStatusVO responseStatusVO) {
		this.responseStatusVO = responseStatusVO;
	}


}
