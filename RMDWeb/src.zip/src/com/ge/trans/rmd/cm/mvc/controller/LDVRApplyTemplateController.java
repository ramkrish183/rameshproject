package com.ge.trans.rmd.cm.mvc.controller;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.collections.CollectionUtils;
import org.codehaus.jackson.map.DeserializationConfig.Feature;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.cm.service.AssetOverviewService;
import com.ge.trans.rmd.cm.service.LDVRAssetStatusService;
import com.ge.trans.rmd.cm.service.LDVRRequestsService;
import com.ge.trans.rmd.cm.valueobjects.AssetTemplateListVO;
import com.ge.trans.rmd.cm.valueobjects.AssetTemplateVO;
import com.ge.trans.rmd.cm.valueobjects.AssetsVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRApplyTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRApplyTemplateResponseVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTempReapplyRemoveRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTempReapplyRemoveStatusVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTemplateRequestVO;
import com.ge.trans.rmd.cm.valueobjects.LDVRAssetTemplateResponseVO;
import com.ge.trans.rmd.common.constants.RMDCommonConstants;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;
import com.ge.trans.rmd.utilities.RMDCommonUtility;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;

@Controller
@SessionAttributes
public class LDVRApplyTemplateController extends RMDBaseController {
	private final  RMDWebLogger rmdWebLogger = RMDWebLogger
			.getLogger(getClass());

	@Autowired
	private ApplicationContext appContext;

	@Autowired
	private LDVRAssetStatusService ldvrAssetStatusService;

	@Autowired
	private LDVRRequestsService ldvrRequestsService;
			
	@Autowired
	private AssetOverviewService asstOvwService;

	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description:
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_APPLY_TEMPLATE_PAGE, method = RequestMethod.GET)
	public ModelAndView getLDVRApplyTemplatePage(
			final HttpServletRequest request) throws RMDWebException {
		rmdWebLogger.info("Inside getLDVRApplyTemplatePage method");
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);

		request.setAttribute(AppConstants.USERNAME, userVO.getUserId());
		return new ModelAndView(AppConstants.VIEW_LDVR_APPLY_TEMPLATE);
	}

	/**
	 * @Author:
	 * @return
	 * @throws RMDWebException
	 * @Description:
	 * 
	 */
	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_ASSET_APPLY_TEMPLATE_PAGE, method = RequestMethod.GET)
	public ModelAndView getLDVRAssetApplyTemplatePage(
			final HttpServletRequest request) throws RMDWebException {
		rmdWebLogger.info("Inside getLDVRAssetApplyTemplatePage method");
		final HttpSession session = request.getSession(false);
		final UserVO userVO = (UserVO) session
				.getAttribute(AppConstants.ATTR_USER_OBJECT);

		final String strAssetNumber = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		final String strAssetGroup = EsapiUtil.stripXSSCharacters(request
				.getParameter(AppConstants.ASSET_GROUP_NAME));
		String strCustomerId =EsapiUtil.stripXSSCharacters( request
				.getParameter(AppConstants.REQ_PARAM_CUSID));
		
		if(RMDCommonUtility.isNullOrEmpty(strCustomerId)){
			strCustomerId = asstOvwService.getCustomerId(strAssetNumber, strAssetGroup);
			//request.setAttribute(AppConstants.WS_PARAM_CUSTID, strCustomerId);
		}


		final String roadInitial = ldvrRequestsService.getRoadInitial(
				strCustomerId, strAssetNumber, strAssetGroup);

		request.setAttribute(AppConstants.USERNAME, userVO.getUserId());
		request.setAttribute(AppConstants.REQ_PARAM_ASSTNUM, strAssetNumber);
		request.setAttribute(AppConstants.ASSET_GROUP_NAME, strAssetGroup);
		request.setAttribute(AppConstants.WS_PARAM_CUSTID, strCustomerId);
		request.setAttribute(AppConstants.LDVR_ROAD_INITIAL, roadInitial);
		request.setAttribute(AppConstants.USERNAME, userVO.getUserId());

		return new ModelAndView(AppConstants.VIEW_LDVR_ASSET_APPLY_TEMPLATE);
	}

	@RequestMapping(value = AppConstants.REQ_URI_GET_ASSET_GROUP_APPLY_TEMPLATE, method = RequestMethod.POST)
	@ResponseBody public  LDVRApplyTemplateResponseVO ldvrAssetGroupApplyTemplate(
			@RequestParam(AppConstants.GET_PARAMETER_STRING) String parameterString)
			throws Exception {
		rmdWebLogger.info("Inside ldvrAssetGroupApplyTemplate method");
		LDVRApplyTemplateResponseVO ldvrApplyTemplateResponseVO = null;
		final ObjectMapper mapper = new ObjectMapper();
		try {

			if (!RMDCommonUtility.isNullOrEmpty(parameterString)) {

				mapper.configure(Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);
				mapper.configure(Feature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);

				LDVRApplyTemplateRequestVO objApplyTemplateReqVO = mapper
						.readValue(EsapiUtil.stripXSSCharacters(parameterString),
								LDVRApplyTemplateRequestVO.class);

				ldvrApplyTemplateResponseVO = ldvrAssetStatusService
						.ldvrAssetGroupApplyTemplate(objApplyTemplateReqVO);
			}

		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in getLDVRStatus  method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		}
		return ldvrApplyTemplateResponseVO;
	}

	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_ASSET_TEMPLATE_LIST, method = RequestMethod.POST)
	@ResponseBody public  LDVRAssetTemplateResponseVO getAssetTemplateList(
			final HttpServletRequest request) throws RMDWebException{
			
		LDVRAssetTemplateResponseVO ldvrAssetTemplateResponseVO = null;

		try {
			
			final String strRoadInitial = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.LDVR_ROAD_INITIAL));
			final String assetOwnerId = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_CUSID));
			final String roadNumber = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_ASSTNUM));
		
			final HttpSession session = request.getSession(false);
			final UserVO userVO = (UserVO) session
					.getAttribute(AppConstants.ATTR_USER_OBJECT);
			
			
			final String defaultTimezone = (String) request
					.getAttribute(AppConstants.DEFAULT_TIMEZONE);

			String applicationTimezone = RMDCommonUtil.getTimezone(defaultTimezone,
					userVO.getTimeZone());

			
			List<String> devices = new ArrayList<String>();
			devices.add(AppConstants.LCV_DEVICE_TYPE);

			LDVRAssetTemplateRequestVO ldvrAssetTemplateRequestVO = new LDVRAssetTemplateRequestVO();
			ldvrAssetTemplateRequestVO.setAssetOwnerId(assetOwnerId);
			ldvrAssetTemplateRequestVO.setRoadInitial(strRoadInitial);
			ldvrAssetTemplateRequestVO.setRoadNumber(roadNumber);
			ldvrAssetTemplateRequestVO.setLstDevice(devices);
			ldvrAssetTemplateRequestVO.setRequestType(AppConstants.TEMPLATE_REQUEST_TYPE);
			ldvrAssetTemplateRequestVO.setTimeZone(applicationTimezone);
			ldvrAssetTemplateRequestVO.setTemplateView(RMDCommonConstants.LDVR_PQ);
			rmdWebLogger.info("Request getAssetTemplateList :: "
					+ ldvrAssetTemplateRequestVO.toString());

			ldvrAssetTemplateResponseVO = ldvrAssetStatusService
					.getAssetTemplateList(ldvrAssetTemplateRequestVO);

		} catch (RMDWebException ex) {
			rmdWebLogger.error(
					"RMDWebException occured in getAssetTemplateList  method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getAssetTemplateList  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return ldvrAssetTemplateResponseVO;
	}
	/**
	 * 
	 * @param parameterString
	 * @param request
	 * @param ldvrAssetTempReapplyRemoveRequestVO
	 * @return
	 * @throws RMDWebException
	 */
	@RequestMapping(value = AppConstants.REQ_URI_REAPPLY_REMOVE_ASSET_TEMPLATE, method = RequestMethod.POST)
	@ResponseBody public List<LDVRAssetTempReapplyRemoveStatusVO> ldvrReApplyRemoveAssetTemplate(
			final HttpServletRequest request) throws RMDWebException {

		List<LDVRAssetTempReapplyRemoveStatusVO>  listLDVRAssetTempReapplyRemoveResponseVO = null;
		
		try {
			
			
			final String assetOwnerId = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_CUSID));
			
			final String roadNumber = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_ASSTNUM));	
		
			final String roadInitial = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.ROAD_INITIAL));	
		
			final String userName =EsapiUtil.stripXSSCharacters( request
					.getParameter(AppConstants.USERNAME));

			final String device = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.LDVR_DEVICE));
			
			final String lstReApplyTemplateIDs = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REAPPLY_TEMPIDS));
			
			final String lstRemoveTemplateIDs = EsapiUtil.stripXSSCharacters(request.getParameter(AppConstants.REMOVE_TEMPIDS));
			
			LDVRAssetTempReapplyRemoveRequestVO ldvrAssetTempReapplyRemoveRequestVO = new LDVRAssetTempReapplyRemoveRequestVO();
			ldvrAssetTempReapplyRemoveRequestVO.setAssetOwnerId(assetOwnerId);
			ldvrAssetTempReapplyRemoveRequestVO.setRoadInitial(roadInitial);
			ldvrAssetTempReapplyRemoveRequestVO.setRoadNumber(roadNumber);
			ldvrAssetTempReapplyRemoveRequestVO.setDevice(device);
			ldvrAssetTempReapplyRemoveRequestVO.setLstReApplyTemplateIDs(lstReApplyTemplateIDs);
			ldvrAssetTempReapplyRemoveRequestVO.setLstRemoveTemplateIDs(lstRemoveTemplateIDs);
			 ldvrAssetTempReapplyRemoveRequestVO.setUserName(userName);
			

			rmdWebLogger.info("Request reApplyRemoveAssetTemplate :: "
					+ ldvrAssetTempReapplyRemoveRequestVO.toString());
			
			
			listLDVRAssetTempReapplyRemoveResponseVO = ldvrAssetStatusService.ldvrReApplyRemoveAssetTemplate(ldvrAssetTempReapplyRemoveRequestVO);
			

		} catch (RMDWebException ex) {
			rmdWebLogger
					.error("RMDWebException occured in reApplyRemoveAssetTemplate  method ",
							ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in reApplyRemoveAssetTemplate  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return listLDVRAssetTempReapplyRemoveResponseVO;
	}

	/**
	  * 
	  * @param request
	  * @param response
	  * @param locale
	  * @throws RMDWebException
	  * @throws Exception
	  */
	@RequestMapping(value=AppConstants.EXPORT_ASSET_LDVR_APPLY_TEMPLATE, method = RequestMethod.POST)
	public @ResponseBody
	void exportLDVRAssetApplyTemplate(final HttpServletRequest request,
			final HttpServletResponse response, final Locale locale)
			throws RMDWebException, Exception {
		LDVRAssetTemplateResponseVO ldvrAssetTemplateResponseVO = null;
		String csvContent = null;
		ServletOutputStream objServletOutputStream = null;
		BufferedInputStream objBufferedInputStream = null;
		BufferedOutputStream objBufferedOutputStream = null;
		try {
			ldvrAssetTemplateResponseVO = getAssetTemplateList(request);
			csvContent = convertToCSVLDVRAssetApplyTemplate(ldvrAssetTemplateResponseVO,
					locale);
			response.setContentType(AppConstants.CONTENT_TYPE);
			response.setHeader(AppConstants.CONTENT,
					AppConstants.ATTACH_FILENAME
							+ AppConstants.LDVR_ASSET_APPLY_TEMPLATE_EXPORT_FILENAME);
			objServletOutputStream = response.getOutputStream();
			ByteArrayInputStream objByteArrayInputStream = new ByteArrayInputStream(
					csvContent.getBytes());
			objBufferedInputStream = new BufferedInputStream(
					objByteArrayInputStream);
			objBufferedOutputStream = new BufferedOutputStream(
					objServletOutputStream);
			byte[] byteArr = new byte[2048];
			int bytesread;

			while ((bytesread = objBufferedInputStream.read(byteArr, 0,
					byteArr.length)) != -1) {
				objBufferedOutputStream.write(byteArr, 0, bytesread);
				objBufferedOutputStream.flush();
			}
		} catch (RMDWebException rmdEx) {
			rmdWebLogger.error("Exception occured in exportLDVRAssetApplyTemplate method ",
					rmdEx);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw rmdEx;
		} catch (Exception ex) {
			rmdWebLogger.error("Exception occured in exportLDVRAssetApplyTemplate method ",
					ex);
			request.setAttribute(AppConstants.ERRORMSG,
					AppConstants.UNKNOWN_EXCEPTION);
			throw ex;
		} finally {
			if (objBufferedInputStream != null) {
				objBufferedInputStream.close();
			}
			if (objBufferedOutputStream != null) {
				objBufferedOutputStream.close();
				objServletOutputStream.close();
				objServletOutputStream = null;
			}

		}

	}

	/**
	 * @Description:This method is used convert ldvr status into csv format
	 * @return: String
	 * @param:List<LDVRAssetStatusResponseVO> ldvrAssetStatusResponseVO, Locale locale
	 */
	private String convertToCSVLDVRAssetApplyTemplate(
			LDVRAssetTemplateResponseVO ldvrAssetTemplateResponseVO, Locale locale) {
		String csvContent = null;
		StringBuilder strBufferAssetHeader = new StringBuilder();
		try {
			strBufferAssetHeader.append(appContext.getMessage(
					AppConstants.LDVR_ASSET_TEMPLATE_HEADER, null, locale));

			strBufferAssetHeader.append(RMDCommonConstants.NEWLINE);

			List<AssetTemplateListVO> lstAssetTemplateListVO = ldvrAssetTemplateResponseVO
						.getAssetTemplateLists();

				if (!CollectionUtils.isEmpty(lstAssetTemplateListVO)) {							

					
				for (AssetTemplateListVO assetTempListVO : lstAssetTemplateListVO) {
					List<AssetTemplateVO> assetTempVOLst = assetTempListVO
							.getTemplates();
					if (!CollectionUtils.isEmpty(assetTempVOLst)) {
						for (AssetTemplateVO assetTemplateVO : assetTempVOLst) {
					
							if (assetTemplateVO.getTitle() != null) {
										strBufferAssetHeader.append(AppConstants.QUOTE
										+ AppConstants.EMPTY_SPACE
										+ assetTemplateVO.getTitle()
										+ AppConstants.QUOTE);

							} else {
								strBufferAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}

							if (assetTemplateVO.getTemplateNumber() != null) {
								strBufferAssetHeader.append(
										RMDCommonConstants.COMMMA_SEPARATOR
										+ AppConstants.QUOTE
										+ AppConstants.EMPTY_SPACE
										+ assetTemplateVO.getTemplateNumber()									
										+ AppConstants.QUOTE);

							} else {
								strBufferAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}
							

							if (assetTemplateVO.getTemplateVersion() != null) {
								strBufferAssetHeader.append(
										RMDCommonConstants.COMMMA_SEPARATOR
										+ AppConstants.QUOTE
										+ AppConstants.EMPTY_SPACE
										+ assetTemplateVO.getTemplateVersion()
										+ AppConstants.QUOTE);

							} else {
								strBufferAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}
							if (assetTemplateVO.getStrActive() != null) {
								strBufferAssetHeader.append(
										RMDCommonConstants.COMMMA_SEPARATOR
										+ AppConstants.QUOTE
										+ AppConstants.EMPTY_SPACE
										+ assetTemplateVO.getStrActive()
										+ AppConstants.QUOTE);

							} else {
								strBufferAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}
							
							if (assetTemplateVO.getInstallationDate() != null) {
								strBufferAssetHeader.append(
										RMDCommonConstants.COMMMA_SEPARATOR
										+ AppConstants.QUOTE
										+ AppConstants.EMPTY_SPACE
										+ assetTemplateVO.getInstallationDate()
										+ AppConstants.QUOTE);

							} else {
								strBufferAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}
							if (assetTemplateVO.getOffboardStatus() != null) {
								strBufferAssetHeader.append(
										RMDCommonConstants.COMMMA_SEPARATOR
										+ AppConstants.QUOTE
										+ AppConstants.EMPTY_SPACE
										+ assetTemplateVO.getOffboardStatus()
										+ AppConstants.QUOTE);

							} else {
								strBufferAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}
							if (assetTemplateVO.getOffboardStatusDate() != null) {
								strBufferAssetHeader.append(
										RMDCommonConstants.COMMMA_SEPARATOR
										+ AppConstants.QUOTE
										+ AppConstants.EMPTY_SPACE
										+ assetTemplateVO.getOffboardStatusDate()
										+ AppConstants.QUOTE);

							} else {
								strBufferAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}
							if (assetTemplateVO.getTemplateRemove() != null) {
								strBufferAssetHeader.append(
										RMDCommonConstants.COMMMA_SEPARATOR
										+ AppConstants.QUOTE
										+ AppConstants.EMPTY_SPACE
										+ assetTemplateVO.getTemplateRemove()
										+ AppConstants.QUOTE);

							} else {
								strBufferAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}
							if (assetTemplateVO.getTemplateReapply() != null) {
								strBufferAssetHeader.append(
										RMDCommonConstants.COMMMA_SEPARATOR
										+ AppConstants.QUOTE
										+ AppConstants.EMPTY_SPACE
										+ assetTemplateVO.getTemplateReapply()
										+ AppConstants.QUOTE);

							} else {
								strBufferAssetHeader
										.append(RMDCommonConstants.COMMMA_SEPARATOR
												+ AppConstants.QUOTE
												+ AppConstants.EMPTY_SPACE
												+ AppConstants.QUOTE);
							}

							strBufferAssetHeader
									.append(RMDCommonConstants.NEWLINE);

						}
					}
					
				}
			}
			csvContent = strBufferAssetHeader.toString();
		} catch (Exception exception) {
			rmdWebLogger.error("Export to CSV LDVR Status :"
					+ exception.getMessage());
		}
		return csvContent;
	}
	
	@RequestMapping(value = AppConstants.REQ_URI_GET_LDVR_ROAD_INITIALS, method = RequestMethod.POST)
	@ResponseBody public  List<AssetsVO> getRoadInitialHDR(
			final HttpServletRequest request) throws RMDWebException{
			
		List<AssetsVO> assetsVOLst = null;
		try {
			
			final String customerId = EsapiUtil.stripXSSCharacters(request
					.getParameter(AppConstants.REQ_PARAM_CUSID));
			
			assetsVOLst = ldvrAssetStatusService
					.getRoadInitialHDR(customerId);

		} catch (RMDWebException ex) {
			rmdWebLogger.error(
					"RMDWebException occured in getRoadInitialHDR  method ",
					ex);
			RMDWebErrorHandler.handleException(ex);
		} catch (Exception ex) {
			rmdWebLogger.error(
					"Exception occured in getRoadInitialHDR  method ", ex);
			RMDWebErrorHandler.handleException(ex);
		}

		return assetsVOLst;
	}
}
