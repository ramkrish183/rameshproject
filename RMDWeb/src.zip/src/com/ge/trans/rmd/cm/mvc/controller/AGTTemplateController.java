package com.ge.trans.rmd.cm.mvc.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ge.trans.rmd.cm.service.AGTTemplateService;
import com.ge.trans.rmd.cm.valueobjects.ConfigSearchVO;
import com.ge.trans.rmd.cm.valueobjects.MassApplyCfgVO;
import com.ge.trans.rmd.common.esapi.util.EsapiUtil;
import com.ge.trans.rmd.common.exception.RMDWebException;
import com.ge.trans.rmd.common.util.AppConstants;
import com.ge.trans.rmd.common.util.RMDCommonUtil;
import com.ge.trans.rmd.common.util.RMDWebErrorHandler;
import com.ge.trans.rmd.common.util.RMDWebLogger;
import com.ge.trans.rmd.common.vo.UserVO;


@Controller
public class AGTTemplateController {
    
    @Autowired
    AGTTemplateService aGTTemplateService;
    private final RMDWebLogger rmdWebLogger = RMDWebLogger
            .getLogger(getClass());
    /**
     * @Author :
     * @return :List<MassApplyCfgVO>
     * @param :String category,String device,templateStatus ctrlCfgName
     * @throws :RMDWebException
     * @Description: This method is Responsible for fetching template of
     *               Type AGT.
     * 
     */
    
    @RequestMapping(AppConstants.GET_AGT_TEMPLATES)
    @ResponseBody
    public List<MassApplyCfgVO> getAGTTemplates(
            @RequestParam(AppConstants.CATEGORY) String category,
            @RequestParam(value=AppConstants.DEVICE,required = false) String device,
            @RequestParam(AppConstants.TEMPLATE_STATUS) String templateStatus,
            @RequestParam(AppConstants.CTRL_CFG_NAME) String ctrlCfgName,
            @RequestParam(AppConstants.FROM_AGT) String fromAGT,
            @RequestParam(AppConstants.REQUEST_TYPE) String requestType,
            @RequestParam(value = AppConstants.ROAD_NUMBER, required = false) String roadNumber,
            @RequestParam(value = AppConstants.ROAD_INITIAL, required = false) String vehHdrNo,
            @RequestParam(value = AppConstants.CUSTOMER_ID, required = false) String customerId,
            @RequestParam(value = AppConstants.TEMPLATE_VIEW, required = false) String templateView,
            final HttpServletRequest request) throws RMDWebException {
        ConfigSearchVO objConfigSearchVO = new ConfigSearchVO();
        List<MassApplyCfgVO> arlAHCConCfgVOs = null;
        final HttpSession session = request.getSession(false);
        final UserVO userVO = (UserVO) session
                .getAttribute(AppConstants.ATTR_USER_OBJECT);
        final String defaultTimezone =  EsapiUtil.stripXSSCharacters((String) request
                .getAttribute(AppConstants.DEFAULT_TIMEZONE));
        String applicationTimezone =  EsapiUtil.stripXSSCharacters(RMDCommonUtil.getTimezone(defaultTimezone,
                 EsapiUtil.stripXSSCharacters(userVO.getTimeZone())));
        try {
            objConfigSearchVO.setCatagory(category);
            objConfigSearchVO.setDevice(device);
            objConfigSearchVO.setTemplateStatus(templateStatus);
            objConfigSearchVO.setTimeZone(applicationTimezone);
            objConfigSearchVO.setDefaultTimeZone(defaultTimezone);
            objConfigSearchVO.setCtrlcfgObjId(ctrlCfgName);
            objConfigSearchVO.setFromAgt(fromAGT);
            objConfigSearchVO.setRequestType(requestType);
            objConfigSearchVO.setRoadNumber(roadNumber);
            objConfigSearchVO.setRoadInitial(vehHdrNo);
            objConfigSearchVO.setAssetOwnerId(customerId);
            objConfigSearchVO.setTemplateView(templateView);
            arlAHCConCfgVOs = aGTTemplateService
                    .getAGTTemplates(objConfigSearchVO);
        } catch (Exception ex) {
            rmdWebLogger
                    .error("Exception occured in getAGTTemplates method ", ex);
            RMDWebErrorHandler.handleException(ex);
        }
        return arlAHCConCfgVOs;
    }
}
