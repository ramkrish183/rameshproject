package com.ge.trans.rmd.asset.panel.mvc.controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ge.trans.rmd.common.mvc.controller.RMDBaseController;
import com.ge.trans.rmd.common.util.AppConstants;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

@Controller
@SessionAttributes
public class AssetPanelController extends RMDBaseController {
	@Value("${" + AppConstants.ASSET_PANEL_IMAGES_PATH + "}")
	private String ASSET_PANEL_IMAGES_PATH;
	
	@RequestMapping(value = AppConstants.ASSET_PANEL_PAGE,method =RequestMethod.GET)
	public ModelAndView viewAssetPanel(final HttpServletRequest request)  throws Exception
	{
		request.setAttribute("sdisQuantity",5);
		return new ModelAndView(AppConstants.ASSET_PANEL_VIEW);
	}
	
	@RequestMapping(value = AppConstants.ASSET_PANEL_POPOUT_PAGE,method =RequestMethod.GET)
	public ModelAndView viewAssetPanelPopout(final HttpServletRequest request)  throws Exception
	{
		return new ModelAndView(AppConstants.ASSET_PANEL_POPOUT_VIEW);
	}
	
	@RequestMapping(value = AppConstants.ASSET_PANEL_FILE_NAME,method =RequestMethod.GET)
	@ResponseBody public List<String> viewAssetPanelFileName(String customerId, String assetNumber,String sdisQuantity) throws Exception
	{
		int quantity = Integer.parseInt(sdisQuantity),i,j,k;
		List<String> fileInfo = new ArrayList<String>();
		File folder = null;
		File[] listOfFiles;
		String fileNamesStr = null;
		for(i=0;i<quantity;i++)
		{
			j=i+1;
			folder = new File(ASSET_PANEL_IMAGES_PATH + customerId + "/" + assetNumber + "/" + AppConstants.ASSET_PANEL_FOLDER + "/SDIS" + j);
			listOfFiles = folder.listFiles();
			if(listOfFiles != null && listOfFiles.length > 0)
			{
				fileNamesStr = listOfFiles[0].getName();
				for (k=1;k<listOfFiles.length;k++)
					if(convertToTime(listOfFiles[k].getName()) > convertToTime(fileNamesStr))
						fileNamesStr = listOfFiles[k].getName();
			BufferedImage image = ImageIO.read(new File(ASSET_PANEL_IMAGES_PATH + customerId + "/" + assetNumber + "/" + AppConstants.ASSET_PANEL_FOLDER + "/SDIS" + j + "/" + fileNamesStr));	    	
	    	ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write(image, "png", baos);
			byte[] res = baos.toByteArray();
			String encodedImage = Base64.encode(res);
			fileInfo.add(j + "~" + fileNamesStr + "~" + encodedImage);
			}
		}
		return fileInfo;
	}
	
	@RequestMapping(value = AppConstants.ASSET_PANEL_FILE_NAME_PER_IMAGE,method =RequestMethod.GET)
	@ResponseBody public String viewAssetPanelFileNamePerImage(String customerId, String assetNumber,String sdisQuantity,String sdisNo) throws Exception
	{
		int k;
		String fileInfo = "";
		File folder = null;
		File[] listOfFiles;
		String fileNamesStr = null;
		folder = new File(ASSET_PANEL_IMAGES_PATH + customerId + "/" + assetNumber + "/" + AppConstants.ASSET_PANEL_FOLDER + "/SDIS"+sdisNo);
		listOfFiles = folder.listFiles();
		if(listOfFiles != null && listOfFiles.length > 0)
		{
			fileNamesStr = listOfFiles[0].getName();
			for (k=1;k<listOfFiles.length;k++)
				if(convertToTime(listOfFiles[k].getName()) > convertToTime(fileNamesStr))
					fileNamesStr = listOfFiles[k].getName();
		BufferedImage image = ImageIO.read(new File(ASSET_PANEL_IMAGES_PATH + customerId + "/" + assetNumber + "/" + AppConstants.ASSET_PANEL_FOLDER + "/SDIS" + sdisNo + "/" + fileNamesStr));	    	
    	ByteArrayOutputStream baos = new ByteArrayOutputStream();
		ImageIO.write(image, "png", baos);
		byte[] res = baos.toByteArray();
		String encodedImage = Base64.encode(res);
		fileInfo = fileNamesStr + "~" + encodedImage;
		}
		return fileInfo;
	}
	
	public int convertToTime(String date)
	{
		String date1[] = date.split("\\.");
		String dateArr[] = (date1[0]).split("_");
		int time = Integer.parseInt(dateArr[1]);
		return time;
	}
		
	
}
